/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-30 14:36
   Version 4.0.0x5 - SVN rev. 12341
   macosx-unix-gnu-ppc [ dload ptables applyhook ]
   compiled 2008-11-03 on apfel (Darwin)
   command line: optimizer.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[262];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12713)
static void C_ccall f_12713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_12721)
static void C_ccall f_12721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12726)
static void C_fcall f_12726(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12771)
static void C_ccall f_12771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12775)
static void C_ccall f_12775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12736)
static void C_ccall f_12736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12760)
static void C_ccall f_12760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12745)
static void C_fcall f_12745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11664)
static void C_ccall f_11664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_11710)
static void C_ccall f_11710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11698)
static void C_ccall f_11698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11693)
static void C_ccall f_11693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11685)
static void C_ccall f_11685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11812)
static void C_ccall f_11812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11822)
static void C_fcall f_11822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12121)
static void C_ccall f_12121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11826)
static void C_ccall f_11826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12116)
static void C_ccall f_12116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11829)
static void C_ccall f_11829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12111)
static void C_ccall f_12111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11832)
static void C_ccall f_11832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12102)
static void C_ccall f_12102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11850)
static void C_ccall f_11850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12097)
static void C_ccall f_12097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11853)
static void C_ccall f_11853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12092)
static void C_ccall f_12092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11856)
static void C_ccall f_11856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11886)
static void C_ccall f_11886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11915)
static void C_fcall f_11915(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12075)
static void C_ccall f_12075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11919)
static void C_ccall f_11919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12070)
static void C_ccall f_12070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11922)
static void C_ccall f_11922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12065)
static void C_ccall f_12065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11925)
static void C_ccall f_11925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12056)
static void C_ccall f_12056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12048)
static void C_ccall f_12048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12043)
static void C_ccall f_12043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12035)
static void C_ccall f_12035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12030)
static void C_ccall f_12030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11931)
static void C_fcall f_11931(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11984)
static void C_ccall f_11984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11974)
static void C_ccall f_11974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11982)
static void C_ccall f_11982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11959)
static void C_ccall f_11959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11954)
static void C_ccall f_11954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12171)
static void C_ccall f_12171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_12184)
static void C_ccall f_12184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12226)
static void C_ccall f_12226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12210)
static void C_ccall f_12210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12214)
static void C_ccall f_12214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12201)
static void C_ccall f_12201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12202)
static void C_ccall f_12202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12392)
static void C_ccall f_12392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_12405)
static void C_ccall f_12405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12411)
static void C_ccall f_12411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12463)
static void C_ccall f_12463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12455)
static void C_ccall f_12455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12439)
static void C_ccall f_12439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12443)
static void C_ccall f_12443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12447)
static void C_ccall f_12447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12431)
static void C_ccall f_12431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11305)
static void C_ccall f_11305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_11327)
static void C_ccall f_11327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11407)
static void C_ccall f_11407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11365)
static void C_ccall f_11365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11399)
static void C_ccall f_11399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11403)
static void C_ccall f_11403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11391)
static void C_ccall f_11391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11382)
static void C_ccall f_11382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11386)
static void C_ccall f_11386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11374)
static void C_ccall f_11374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11363)
static void C_ccall f_11363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11355)
static void C_ccall f_11355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11350)
static void C_ccall f_11350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11342)
static void C_ccall f_11342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11501)
static void C_ccall f_11501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_11521)
static void C_ccall f_11521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11530)
static void C_ccall f_11530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11525)
static void C_ccall f_11525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11513)
static void C_ccall f_11513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11184)
static void C_ccall f_11184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11187)
static void C_ccall f_11187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11190)
static void C_ccall f_11190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11193)
static void C_ccall f_11193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11196)
static void C_ccall f_11196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11199)
static void C_ccall f_11199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11276)
static void C_ccall f_11276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11202)
static void C_ccall f_11202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11205)
static void C_ccall f_11205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11208)
static void C_ccall f_11208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11270)
static void C_ccall f_11270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11211)
static void C_ccall f_11211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11214)
static void C_ccall f_11214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11267)
static void C_ccall f_11267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10096)
static void C_fcall f_10096(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10114)
static void C_ccall f_10114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10120)
static void C_ccall f_10120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10100)
static void C_ccall f_10100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11217)
static void C_ccall f_11217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11259)
static void C_ccall f_11259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11257)
static void C_ccall f_11257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11220)
static void C_ccall f_11220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11223)
static void C_ccall f_11223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11226)
static void C_ccall f_11226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11250)
static void C_ccall f_11250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11229)
static void C_ccall f_11229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11232)
static void C_ccall f_11232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11235)
static void C_ccall f_11235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11238)
static void C_ccall f_11238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11241)
static void C_ccall f_11241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11244)
static void C_ccall f_11244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11012)
static void C_fcall f_11012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11018)
static void C_ccall f_11018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11177)
static void C_ccall f_11177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11022)
static void C_ccall f_11022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11172)
static void C_ccall f_11172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11025)
static void C_ccall f_11025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11167)
static void C_ccall f_11167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11159)
static void C_ccall f_11159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11135)
static void C_ccall f_11135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11144)
static void C_ccall f_11144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11147)
static void C_ccall f_11147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11122)
static void C_ccall f_11122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11121)
static void C_ccall f_11121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11037)
static void C_ccall f_11037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11042)
static void C_fcall f_11042(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11083)
static void C_fcall f_11083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11080)
static void C_ccall f_11080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11065)
static void C_ccall f_11065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11076)
static void C_ccall f_11076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11072)
static void C_ccall f_11072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10895)
static void C_fcall f_10895(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10901)
static void C_ccall f_10901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11006)
static void C_ccall f_11006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10905)
static void C_ccall f_10905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11001)
static void C_ccall f_11001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10908)
static void C_ccall f_10908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10996)
static void C_ccall f_10996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10911)
static void C_ccall f_10911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10988)
static void C_ccall f_10988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10987)
static void C_ccall f_10987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10979)
static void C_ccall f_10979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10978)
static void C_ccall f_10978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10962)
static void C_ccall f_10962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10958)
static void C_ccall f_10958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10923)
static void C_ccall f_10923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10931)
static void C_ccall f_10931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10930)
static void C_ccall f_10930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10590)
static void C_fcall f_10590(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10746)
static void C_ccall f_10746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10745)
static void C_ccall f_10745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10604)
static void C_ccall f_10604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10611)
static void C_ccall f_10611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10614)
static void C_ccall f_10614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10733)
static void C_ccall f_10733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10732)
static void C_ccall f_10732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10623)
static void C_ccall f_10623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10630)
static void C_ccall f_10630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10633)
static void C_ccall f_10633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10720)
static void C_ccall f_10720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10719)
static void C_ccall f_10719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10770)
static void C_ccall f_10770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10889)
static void C_ccall f_10889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10777)
static void C_ccall f_10777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10879)
static void C_ccall f_10879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10780)
static void C_ccall f_10780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10856)
static void C_ccall f_10856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10875)
static void C_ccall f_10875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10871)
static void C_ccall f_10871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10837)
static void C_ccall f_10837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10826)
static void C_ccall f_10826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10813)
static void C_ccall f_10813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10796)
static void C_ccall f_10796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10789)
static void C_ccall f_10789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10755)
static void C_ccall f_10755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10636)
static void C_ccall f_10636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10711)
static void C_ccall f_10711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10699)
static void C_ccall f_10699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10695)
static void C_ccall f_10695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10687)
static void C_ccall f_10687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10682)
static void C_ccall f_10682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10673)
static void C_ccall f_10673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10665)
static void C_ccall f_10665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10656)
static void C_ccall f_10656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10648)
static void C_ccall f_10648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10602)
static void C_ccall f_10602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10374)
static void C_fcall f_10374(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10576)
static void C_ccall f_10576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10531)
static void C_ccall f_10531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10536)
static void C_ccall f_10536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10574)
static void C_ccall f_10574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10383)
static void C_ccall f_10383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10387)
static void C_ccall f_10387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10442)
static void C_ccall f_10442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10390)
static void C_ccall f_10390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10437)
static void C_ccall f_10437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10393)
static void C_ccall f_10393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10421)
static void C_ccall f_10421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10426)
static void C_ccall f_10426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10403)
static void C_ccall f_10403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10381)
static void C_ccall f_10381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10566)
static void C_ccall f_10566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10552)
static void C_ccall f_10552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10550)
static void C_ccall f_10550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10456)
static void C_ccall f_10456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10524)
static void C_ccall f_10524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10522)
static void C_ccall f_10522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10510)
static void C_ccall f_10510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10476)
static void C_ccall f_10476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10500)
static void C_ccall f_10500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10498)
static void C_ccall f_10498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10494)
static void C_ccall f_10494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10486)
static void C_ccall f_10486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10130)
static void C_fcall f_10130(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10136)
static void C_fcall f_10136(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10140)
static void C_ccall f_10140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10363)
static void C_ccall f_10363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10143)
static void C_ccall f_10143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10358)
static void C_ccall f_10358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10146)
static void C_ccall f_10146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10155)
static void C_fcall f_10155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10332)
static void C_ccall f_10332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10252)
static void C_ccall f_10252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10323)
static void C_ccall f_10323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10322)
static void C_ccall f_10322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10314)
static void C_ccall f_10314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10268)
static void C_ccall f_10268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10298)
static void C_ccall f_10298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10302)
static void C_ccall f_10302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10288)
static void C_ccall f_10288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10241)
static void C_ccall f_10241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10246)
static void C_ccall f_10246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10217)
static void C_ccall f_10217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10229)
static void C_ccall f_10229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10166)
static void C_fcall f_10166(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10187)
static void C_ccall f_10187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10134)
static void C_ccall f_10134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9871)
static void C_fcall f_9871(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9877)
static void C_fcall f_9877(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10034)
static void C_ccall f_10034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9881)
static void C_ccall f_9881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10029)
static void C_ccall f_10029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9884)
static void C_ccall f_9884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10024)
static void C_ccall f_10024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9887)
static void C_ccall f_9887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9896)
static void C_fcall f_9896(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9998)
static void C_ccall f_9998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9989)
static void C_ccall f_9989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9955)
static void C_fcall f_9955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9964)
static void C_ccall f_9964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9976)
static void C_ccall f_9976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9907)
static void C_fcall f_9907(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9928)
static void C_ccall f_9928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9925)
static void C_ccall f_9925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9875)
static void C_ccall f_9875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9772)
static void C_fcall f_9772(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9778)
static void C_ccall f_9778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9827)
static void C_fcall f_9827(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9834)
static void C_ccall f_9834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9861)
static void C_ccall f_9861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9857)
static void C_ccall f_9857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9849)
static void C_ccall f_9849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9812)
static void C_ccall f_9812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9790)
static void C_ccall f_9790(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9797)
static void C_ccall f_9797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9550)
static void C_fcall f_9550(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9719)
static void C_ccall f_9719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9766)
static void C_ccall f_9766(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9757)
static void C_ccall f_9757(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9756)
static void C_ccall f_9756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9734)
static void C_ccall f_9734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9738)
static void C_ccall f_9738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9717)
static void C_ccall f_9717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9553)
static void C_fcall f_9553(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9710)
static void C_ccall f_9710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9557)
static void C_ccall f_9557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9705)
static void C_ccall f_9705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9560)
static void C_ccall f_9560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9700)
static void C_ccall f_9700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9563)
static void C_ccall f_9563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9692)
static void C_ccall f_9692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9675)
static void C_ccall f_9675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9687)
static void C_ccall f_9687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9621)
static void C_fcall f_9621(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9645)
static void C_ccall f_9645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9639)
static void C_ccall f_9639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9603)
static void C_ccall f_9603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9578)
static void C_fcall f_9578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9581)
static void C_fcall f_9581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9586)
static void C_ccall f_9586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9444)
static void C_fcall f_9444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9536)
static void C_ccall f_9536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9531)
static void C_ccall f_9531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9481)
static void C_fcall f_9481(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9485)
static void C_ccall f_9485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9489)
static void C_ccall f_9489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9448)
static void C_ccall f_9448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9436)
static void C_ccall f_9436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8179)
static void C_fcall f_8179(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8183)
static void C_ccall f_8183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8186)
static void C_ccall f_8186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8315)
static void C_ccall f_8315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8235)
static void C_ccall f_8235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8241)
static void C_ccall f_8241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8204)
static void C_ccall f_8204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8356)
static void C_fcall f_8356(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8801)
static void C_ccall f_8801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8808)
static void C_ccall f_8808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_fcall f_8359(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8788)
static void C_ccall f_8788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8366)
static void C_ccall f_8366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8749)
static void C_ccall f_8749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8760)
static void C_ccall f_8760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8716)
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8682)
static void C_ccall f_8682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8681)
static void C_ccall f_8681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8672)
static void C_ccall f_8672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8661)
static void C_ccall f_8661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8660)
static void C_ccall f_8660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8651)
static void C_ccall f_8651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8635)
static void C_fcall f_8635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8607)
static void C_fcall f_8607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8612)
static void C_ccall f_8612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8554)
static void C_ccall f_8554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8560)
static void C_fcall f_8560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8565)
static void C_ccall f_8565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8513)
static void C_ccall f_8513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8519)
static void C_fcall f_8519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8524)
static void C_ccall f_8524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8497)
static void C_ccall f_8497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_ccall f_8493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8463)
static void C_ccall f_8463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8426)
static void C_ccall f_8426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8408)
static void C_ccall f_8408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8810)
static void C_fcall f_8810(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_9426)
static void C_ccall f_9426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9424)
static void C_ccall f_9424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8814)
static void C_ccall f_8814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9410)
static void C_ccall f_9410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8818)
static void C_ccall f_8818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8824)
static void C_ccall f_8824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8830)
static void C_fcall f_8830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8836)
static void C_ccall f_8836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8839)
static void C_ccall f_8839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8845)
static void C_ccall f_8845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9374)
static void C_ccall f_9374(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9373)
static void C_ccall f_9373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9084)
static void C_ccall f_9084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9365)
static void C_ccall f_9365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9088)
static void C_ccall f_9088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9360)
static void C_ccall f_9360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9091)
static void C_ccall f_9091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9338)
static void C_ccall f_9338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9312)
static void C_ccall f_9312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9109)
static void C_ccall f_9109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9307)
static void C_ccall f_9307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9112)
static void C_ccall f_9112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9302)
static void C_ccall f_9302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9301)
static void C_ccall f_9301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9276)
static void C_ccall f_9276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9279)
static void C_ccall f_9279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9128)
static void C_ccall f_9128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9251)
static void C_ccall f_9251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9183)
static void C_ccall f_9183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9186)
static void C_ccall f_9186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9229)
static void C_ccall f_9229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9189)
static void C_ccall f_9189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9212)
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9203)
static void C_ccall f_9203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9192)
static void C_ccall f_9192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9143)
static void C_ccall f_9143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8848)
static void C_ccall f_8848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9066)
static void C_ccall f_9066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9002)
static void C_ccall f_9002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9005)
static void C_ccall f_9005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9029)
static void C_ccall f_9029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9020)
static void C_ccall f_9020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8851)
static void C_ccall f_8851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8860)
static void C_ccall f_8860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8863)
static void C_ccall f_8863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8912)
static void C_ccall f_8912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8977)
static void C_ccall f_8977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8964)
static void C_ccall f_8964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8940)
static void C_ccall f_8940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8959)
static void C_ccall f_8959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8944)
static void C_ccall f_8944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8948)
static void C_ccall f_8948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8949)
static void C_ccall f_8949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8936)
static void C_ccall f_8936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8928)
static void C_ccall f_8928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8866)
static void C_ccall f_8866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8869)
static void C_ccall f_8869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8874)
static void C_ccall f_8874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8910)
static void C_ccall f_8910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static void C_ccall f_8881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8898)
static void C_ccall f_8898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8888)
static void C_ccall f_8888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8893)
static void C_ccall f_8893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8892)
static void C_ccall f_8892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8167)
static void C_ccall f_8167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8038)
static void C_ccall f_8038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8093)
static void C_fcall f_8093(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_fcall f_5855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8113)
static void C_ccall f_8113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8117)
static void C_ccall f_8117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8087)
static void C_ccall f_8087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8073)
static void C_ccall f_8073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8071)
static void C_ccall f_8071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8058)
static void C_ccall f_8058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8059)
static void C_ccall f_8059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7958)
static void C_ccall f_7958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8010)
static void C_ccall f_8010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_ccall f_7994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7924)
static void C_ccall f_7924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7763)
static void C_ccall f_7763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7769)
static void C_ccall f_7769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7912)
static void C_ccall f_7912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_ccall f_7904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7875)
static void C_ccall f_7875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7830)
static void C_ccall f_7830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7740)
static void C_ccall f_7740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7678)
static void C_ccall f_7678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7719)
static void C_ccall f_7719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7709)
static void C_ccall f_7709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7686)
static void C_ccall f_7686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7630)
static void C_ccall f_7630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7629)
static void C_ccall f_7629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7621)
static void C_ccall f_7621(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7620)
static void C_ccall f_7620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7576)
static void C_ccall f_7576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7574)
static void C_ccall f_7574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7423)
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7409)
static void C_fcall f_7409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7393)
static void C_ccall f_7393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7287)
static void C_ccall f_7287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7329)
static void C_fcall f_7329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7312)
static void C_ccall f_7312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7304)
static void C_ccall f_7304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7243)
static void C_ccall f_7243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7182)
static void C_ccall f_7182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7208)
static void C_ccall f_7208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7199)
static void C_ccall f_7199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7200)
static void C_ccall f_7200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7111)
static void C_ccall f_7111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7030)
static void C_fcall f_7030(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6992)
static void C_ccall f_6992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6970)
static void C_ccall f_6970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6971)
static void C_ccall f_6971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6864)
static void C_fcall f_6864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6875)
static void C_ccall f_6875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6824)
static void C_ccall f_6824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6782)
static void C_ccall f_6782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6790)
static void C_ccall f_6790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6794)
static void C_ccall f_6794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6774)
static void C_ccall f_6774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6725)
static void C_ccall f_6725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_fcall f_6607(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_fcall f_6610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6688)
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6647)
static void C_ccall f_6647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6642)
static void C_ccall f_6642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6593)
static void C_ccall f_6593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6496)
static void C_ccall f_6496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6488)
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6429)
static void C_ccall f_6429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6329)
static void C_ccall f_6329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6238)
static void C_ccall f_6238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6136)
static void C_ccall f_6136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6130)
static void C_ccall f_6130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_ccall f_6122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6072)
static void C_fcall f_6072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6092)
static void C_ccall f_6092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6061)
static void C_ccall f_6061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5904)
static void C_ccall f_5904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5685)
static void C_ccall f_5685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5708)
static void C_ccall f_5708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5543)
static void C_fcall f_5543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5650)
static void C_ccall f_5650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5594)
static void C_ccall f_5594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_fcall f_5456(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5462)
static void C_fcall f_5462(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5403)
static void C_ccall f_5403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_fcall f_5194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_fcall f_5209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5316)
static void C_ccall f_5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5221)
static void C_fcall f_5221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_fcall f_5230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_ccall f_5237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_fcall f_5145(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5141)
static C_word C_fcall f_5141(C_word t0);
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_fcall f_5018(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3825)
static void C_fcall f_3825(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_fcall f_4963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_fcall f_4923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4933)
static void C_ccall f_4933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4884)
static void C_ccall f_4884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4872)
static void C_ccall f_4872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_fcall f_4403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_fcall f_4424(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_fcall f_4659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_fcall f_4501(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_fcall f_4287(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4093)
static void C_ccall f_4093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_fcall f_3934(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3850)
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_fcall f_3895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3578)
static void C_ccall f_3578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3819)
static void C_ccall f_3819(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_fcall f_3689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_fcall f_3481(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_fcall f_3524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static C_word C_fcall f_3477(C_word t0);
C_noret_decl(f_3462)
static void C_fcall f_3462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_fcall f_3441(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3265)
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_fcall f_3317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_fcall f_3290(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3222)
static void C_ccall f_3222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_12726)
static void C_fcall trf_12726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12726(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12726(t0,t1,t2);}

C_noret_decl(trf_12745)
static void C_fcall trf_12745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12745(t0,t1);}

C_noret_decl(trf_11822)
static void C_fcall trf_11822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11822(t0,t1,t2,t3);}

C_noret_decl(trf_11915)
static void C_fcall trf_11915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11915(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_11915(t0,t1,t2,t3,t4);}

C_noret_decl(trf_11931)
static void C_fcall trf_11931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11931(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11931(t0,t1);}

C_noret_decl(trf_10096)
static void C_fcall trf_10096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10096(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10096(t0,t1,t2,t3);}

C_noret_decl(trf_11012)
static void C_fcall trf_11012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11012(t0,t1,t2);}

C_noret_decl(trf_11042)
static void C_fcall trf_11042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11042(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11042(t0,t1,t2,t3);}

C_noret_decl(trf_11083)
static void C_fcall trf_11083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11083(t0,t1);}

C_noret_decl(trf_10895)
static void C_fcall trf_10895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10895(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10895(t0,t1,t2);}

C_noret_decl(trf_10590)
static void C_fcall trf_10590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10590(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10590(t0,t1,t2,t3);}

C_noret_decl(trf_10374)
static void C_fcall trf_10374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10374(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10374(t0,t1,t2);}

C_noret_decl(trf_10130)
static void C_fcall trf_10130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10130(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10130(t0,t1,t2);}

C_noret_decl(trf_10136)
static void C_fcall trf_10136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10136(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10136(t0,t1,t2,t3);}

C_noret_decl(trf_10155)
static void C_fcall trf_10155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10155(t0,t1);}

C_noret_decl(trf_10166)
static void C_fcall trf_10166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10166(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10166(t0,t1,t2,t3);}

C_noret_decl(trf_9871)
static void C_fcall trf_9871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9871(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9871(t0,t1,t2);}

C_noret_decl(trf_9877)
static void C_fcall trf_9877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9877(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9877(t0,t1,t2,t3);}

C_noret_decl(trf_9896)
static void C_fcall trf_9896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9896(t0,t1);}

C_noret_decl(trf_9955)
static void C_fcall trf_9955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9955(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9955(t0,t1);}

C_noret_decl(trf_9907)
static void C_fcall trf_9907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9907(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9907(t0,t1,t2,t3);}

C_noret_decl(trf_9772)
static void C_fcall trf_9772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9772(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9772(t0,t1,t2,t3);}

C_noret_decl(trf_9827)
static void C_fcall trf_9827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9827(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9827(t0,t1,t2,t3);}

C_noret_decl(trf_9550)
static void C_fcall trf_9550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9550(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9550(t0,t1,t2);}

C_noret_decl(trf_9553)
static void C_fcall trf_9553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9553(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9553(t0,t1,t2,t3);}

C_noret_decl(trf_9621)
static void C_fcall trf_9621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9621(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9621(t0,t1,t2,t3);}

C_noret_decl(trf_9578)
static void C_fcall trf_9578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9578(t0,t1);}

C_noret_decl(trf_9581)
static void C_fcall trf_9581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9581(t0,t1);}

C_noret_decl(trf_9444)
static void C_fcall trf_9444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9444(t0,t1);}

C_noret_decl(trf_9481)
static void C_fcall trf_9481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9481(t0,t1);}

C_noret_decl(trf_8179)
static void C_fcall trf_8179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8179(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8179(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8356)
static void C_fcall trf_8356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8356(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8356(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8359)
static void C_fcall trf_8359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8359(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8359(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8635)
static void C_fcall trf_8635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8635(t0,t1);}

C_noret_decl(trf_8607)
static void C_fcall trf_8607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8607(t0,t1);}

C_noret_decl(trf_8560)
static void C_fcall trf_8560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8560(t0,t1);}

C_noret_decl(trf_8519)
static void C_fcall trf_8519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8519(t0,t1);}

C_noret_decl(trf_8810)
static void C_fcall trf_8810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8810(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8810(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8830)
static void C_fcall trf_8830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8830(t0,t1);}

C_noret_decl(trf_8093)
static void C_fcall trf_8093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8093(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8093(t0,t1,t2,t3);}

C_noret_decl(trf_5855)
static void C_fcall trf_5855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5855(t0,t1);}

C_noret_decl(trf_7409)
static void C_fcall trf_7409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7409(t0,t1);}

C_noret_decl(trf_7329)
static void C_fcall trf_7329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7329(t0,t1);}

C_noret_decl(trf_7030)
static void C_fcall trf_7030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7030(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7030(t0,t1);}

C_noret_decl(trf_6864)
static void C_fcall trf_6864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6864(t0,t1);}

C_noret_decl(trf_6607)
static void C_fcall trf_6607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6607(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6607(t0,t1);}

C_noret_decl(trf_6610)
static void C_fcall trf_6610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6610(t0,t1);}

C_noret_decl(trf_6072)
static void C_fcall trf_6072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6072(t0,t1);}

C_noret_decl(trf_5543)
static void C_fcall trf_5543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5543(t0,t1);}

C_noret_decl(trf_5456)
static void C_fcall trf_5456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5456(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5456(t0,t1,t2,t3);}

C_noret_decl(trf_5462)
static void C_fcall trf_5462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5462(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5462(t0,t1,t2,t3);}

C_noret_decl(trf_5194)
static void C_fcall trf_5194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5194(t0,t1);}

C_noret_decl(trf_5209)
static void C_fcall trf_5209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5209(t0,t1);}

C_noret_decl(trf_5221)
static void C_fcall trf_5221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5221(t0,t1);}

C_noret_decl(trf_5230)
static void C_fcall trf_5230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5230(t0,t1);}

C_noret_decl(trf_5145)
static void C_fcall trf_5145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5145(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5145(t0,t1,t2,t3);}

C_noret_decl(trf_5018)
static void C_fcall trf_5018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5018(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5018(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3825)
static void C_fcall trf_3825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3825(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3825(t0,t1,t2);}

C_noret_decl(trf_4963)
static void C_fcall trf_4963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4963(t0,t1);}

C_noret_decl(trf_4923)
static void C_fcall trf_4923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4923(t0,t1);}

C_noret_decl(trf_4403)
static void C_fcall trf_4403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4403(t0,t1);}

C_noret_decl(trf_4424)
static void C_fcall trf_4424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4424(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4424(t0,t1);}

C_noret_decl(trf_4659)
static void C_fcall trf_4659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4659(t0,t1);}

C_noret_decl(trf_4501)
static void C_fcall trf_4501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4501(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4501(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4287)
static void C_fcall trf_4287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4287(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4287(t0,t1);}

C_noret_decl(trf_3934)
static void C_fcall trf_3934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3934(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3934(t0,t1);}

C_noret_decl(trf_3850)
static void C_fcall trf_3850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3850(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3850(t0,t1,t2);}

C_noret_decl(trf_3895)
static void C_fcall trf_3895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3895(t0,t1);}

C_noret_decl(trf_3689)
static void C_fcall trf_3689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3689(t0,t1);}

C_noret_decl(trf_3481)
static void C_fcall trf_3481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3481(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3481(t0,t1,t2);}

C_noret_decl(trf_3524)
static void C_fcall trf_3524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3524(t0,t1);}

C_noret_decl(trf_3462)
static void C_fcall trf_3462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3462(t0,t1);}

C_noret_decl(trf_3441)
static void C_fcall trf_3441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3441(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3441(t0,t1,t2,t3);}

C_noret_decl(trf_3265)
static void C_fcall trf_3265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3265(t0,t1,t2,t3);}

C_noret_decl(trf_3317)
static void C_fcall trf_3317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3317(t0,t1);}

C_noret_decl(trf_3290)
static void C_fcall trf_3290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3290(t0,t1);}

C_noret_decl(trf_3253)
static void C_fcall trf_3253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3253(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3253(t0,t1,t2,t3);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1941)){
C_save(t1);
C_rereclaim2(1941*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,262);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],8,"\003sysput!");
lf[2]=C_h_intern(&lf[2],9,"\003syserror");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],21,"\010compileralways-bound");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],18,"\010compilerdebugging");
lf[7]=C_h_intern(&lf[7],1,"o");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[9]=C_h_intern(&lf[9],13,"\004corevariable");
lf[10]=C_h_intern(&lf[10],2,"if");
lf[11]=C_h_intern(&lf[11],3,"let");
lf[12]=C_h_intern(&lf[12],6,"append");
lf[13]=C_h_intern(&lf[13],6,"lambda");
lf[14]=C_h_intern(&lf[14],13,"\004corecallunit");
lf[15]=C_h_intern(&lf[15],9,"\004corecall");
lf[16]=C_h_intern(&lf[16],4,"set!");
lf[17]=C_h_intern(&lf[17],9,"\004corecond");
lf[18]=C_h_intern(&lf[18],11,"\004coreswitch");
lf[19]=C_h_intern(&lf[19],30,"call-with-current-continuation");
lf[20]=C_h_intern(&lf[20],1,"p");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[22]=C_h_intern(&lf[22],24,"\010compilersimplifications");
lf[23]=C_h_intern(&lf[23],23,"\010compilersimplified-ops");
lf[24]=C_h_intern(&lf[24],41,"\010compilerperform-high-level-optimizations");
lf[25]=C_h_intern(&lf[25],12,"\010compilerget");
lf[26]=C_h_intern(&lf[26],5,"quote");
lf[27]=C_h_intern(&lf[27],10,"alist-cons");
lf[28]=C_h_intern(&lf[28],4,"caar");
lf[29]=C_h_intern(&lf[29],7,"\003sysmap");
lf[30]=C_h_intern(&lf[30],19,"\010compilermatch-node");
lf[31]=C_h_intern(&lf[31],3,"any");
lf[32]=C_h_intern(&lf[32],18,"\003syshash-table-ref");
lf[33]=C_h_intern(&lf[33],30,"\010compilerbroken-constant-nodes");
lf[34]=C_h_intern(&lf[34],11,"lset-adjoin");
lf[35]=C_h_intern(&lf[35],3,"eq\077");
lf[36]=C_h_intern(&lf[36],4,"node");
lf[37]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[38]=C_h_intern(&lf[38],14,"\010compilerqnode");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[40]=C_h_intern(&lf[40],4,"eval");
lf[41]=C_h_intern(&lf[41],22,"with-exception-handler");
lf[42]=C_h_intern(&lf[42],5,"every");
lf[43]=C_h_intern(&lf[43],9,"foldable\077");
lf[44]=C_h_intern(&lf[44],7,"\003sysget");
lf[45]=C_h_intern(&lf[45],18,"\010compilerintrinsic");
lf[46]=C_h_intern(&lf[46],5,"value");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[48]=C_h_intern(&lf[48],16,"\010compilervarnode");
lf[49]=C_h_intern(&lf[49],11,"collapsable");
lf[50]=C_h_intern(&lf[50],10,"replacable");
lf[51]=C_h_intern(&lf[51],9,"replacing");
lf[52]=C_h_intern(&lf[52],12,"contractable");
lf[53]=C_h_intern(&lf[53],9,"removable");
lf[54]=C_h_intern(&lf[54],11,"\004corelambda");
lf[55]=C_h_intern(&lf[55],6,"unused");
lf[56]=C_h_intern(&lf[56],9,"partition");
lf[57]=C_h_intern(&lf[57],26,"\010compilerbuild-lambda-list");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[59]=C_h_intern(&lf[59],13,"explicit-rest");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[61]=C_h_intern(&lf[61],30,"\010compilerdecompose-lambda-list");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[63]=C_h_intern(&lf[63],21,"has-unused-parameters");
lf[64]=C_h_intern(&lf[64],31,"\010compilerinline-lambda-bindings");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[66]=C_h_intern(&lf[66],24,"\010compilercheck-signature");
lf[67]=C_h_intern(&lf[67],30,"\010compilerconstant-declarations");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[69]=C_h_intern(&lf[69],14,"\004coreundefined");
lf[70]=C_h_intern(&lf[70],1,"x");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[72]=C_h_intern(&lf[72],37,"\010compilerexpression-has-side-effects\077");
lf[73]=C_h_intern(&lf[73],8,"assigned");
lf[74]=C_h_intern(&lf[74],10,"references");
lf[75]=C_h_intern(&lf[75],7,"unknown");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000#procedure can be inlined (globally)");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure can be inlined");
lf[79]=C_h_intern(&lf[79],1,"i");
lf[80]=C_h_intern(&lf[80],22,"\010compilerinline-global");
lf[81]=C_h_intern(&lf[81],14,"append-reverse");
lf[82]=C_h_intern(&lf[82],6,"gensym");
lf[83]=C_h_intern(&lf[83],1,"t");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[85]=C_h_intern(&lf[85],8,"split-at");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[87]=C_h_intern(&lf[87],20,"\004coreinline_allocate");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[89]=C_h_intern(&lf[89],23,"\010compilerinline-locally");
lf[90]=C_h_intern(&lf[90],3,"yes");
lf[91]=C_h_intern(&lf[91],2,"no");
lf[92]=C_h_intern(&lf[92],24,"\010compilerinline-max-size");
lf[93]=C_h_intern(&lf[93],15,"\010compilerinline");
lf[94]=C_h_intern(&lf[94],9,"inlinable");
lf[95]=C_h_intern(&lf[95],6,"simple");
lf[96]=C_h_intern(&lf[96],11,"local-value");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[98]=C_h_intern(&lf[98],26,"\010compilervariable-visible\077");
lf[99]=C_h_intern(&lf[99],6,"global");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[103]=C_h_intern(&lf[103],5,"print");
lf[104]=C_h_intern(&lf[104],7,"newline");
lf[105]=C_h_intern(&lf[105],6,"print*");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[109]=C_h_intern(&lf[109],34,"\010compilerperform-pre-optimization!");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[111]=C_h_intern(&lf[111],24,"node-subexpressions-set!");
lf[112]=C_h_intern(&lf[112],7,"reverse");
lf[113]=C_h_intern(&lf[113],20,"node-parameters-set!");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[115]=C_h_intern(&lf[115],3,"not");
lf[116]=C_h_intern(&lf[116],10,"call-sites");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[118]=C_h_intern(&lf[118],24,"register-simplifications");
lf[119]=C_h_intern(&lf[119],19,"\003syshash-table-set!");
lf[120]=C_h_intern(&lf[120],38,"\010compilerreorganize-recursive-bindings");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[122]=C_h_intern(&lf[122],10,"fold-right");
lf[123]=C_h_intern(&lf[123],4,"fold");
lf[124]=C_h_intern(&lf[124],25,"\010compilertopological-sort");
lf[125]=C_h_intern(&lf[125],6,"lset<=");
lf[126]=C_h_intern(&lf[126],10,"filter-map");
lf[127]=C_h_intern(&lf[127],6,"filter");
lf[128]=C_h_intern(&lf[128],10,"append-map");
lf[129]=C_h_intern(&lf[129],28,"\010compilerscan-used-variables");
lf[130]=C_h_intern(&lf[130],8,"for-each");
lf[131]=C_h_intern(&lf[131],3,"map");
lf[132]=C_h_intern(&lf[132],4,"cons");
lf[133]=C_h_intern(&lf[133],27,"\010compilersubstitution-table");
lf[134]=C_h_intern(&lf[134],16,"\010compilerrewrite");
lf[135]=C_h_intern(&lf[135],28,"\010compilersimplify-named-call");
lf[136]=C_h_intern(&lf[136],37,"\010compilerinline-substitutions-enabled");
lf[137]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[138]=C_h_intern(&lf[138],11,"\004coreinline");
lf[139]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[140]=C_h_intern(&lf[140],6,"unsafe");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[142]=C_h_intern(&lf[142],6,"vector");
lf[143]=C_h_intern(&lf[143],14,"rest-parameter");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[145]=C_h_intern(&lf[145],11,"number-type");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[150]=C_h_intern(&lf[150],6,"fixnum");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[152]=C_h_intern(&lf[152],21,"\010compilerfold-boolean");
lf[153]=C_h_intern(&lf[153],6,"flonum");
lf[154]=C_h_intern(&lf[154],7,"generic");
lf[155]=C_h_intern(&lf[155],5,"cons*");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[157]=C_h_intern(&lf[157],9,"\004coreproc");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_h_intern(&lf[166],19,"\010compilerfold-inner");
lf[167]=C_h_intern(&lf[167],6,"remove");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[172]=C_h_intern(&lf[172],5,"fifth");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[174]=C_h_intern(&lf[174],13,"\010compilerbomb");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[176]=C_h_intern(&lf[176],34,"\010compilertransform-direct-lambdas!");
lf[177]=C_h_intern(&lf[177],19,"\010compilercopy-node!");
lf[178]=C_h_intern(&lf[178],16,"\004coredirect_call");
lf[179]=C_h_intern(&lf[179],4,"quit");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[181]=C_h_intern(&lf[181],15,"lset-difference");
lf[182]=C_h_intern(&lf[182],15,"node-class-set!");
lf[183]=C_h_intern(&lf[183],12,"\004corerecurse");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[185]=C_h_intern(&lf[185],4,"take");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[188]=C_h_intern(&lf[188],11,"\004corereturn");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[190]=C_h_intern(&lf[190],18,"\004coredirect_lambda");
lf[191]=C_h_intern(&lf[191],6,"cdaddr");
lf[192]=C_h_intern(&lf[192],6,"caaddr");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[195]=C_h_intern(&lf[195],6,"unzip1");
lf[196]=C_h_intern(&lf[196],16,"\003sysmake-promise");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[198]=C_h_intern(&lf[198],5,"boxed");
lf[199]=C_h_intern(&lf[199],15,"\004coreinline_ref");
lf[200]=C_h_intern(&lf[200],37,"\010compilerestimate-foreign-result-size");
lf[201]=C_h_intern(&lf[201],19,"\004coreinline_loc_ref");
lf[202]=C_h_intern(&lf[202],5,"lset=");
lf[203]=C_h_intern(&lf[203],6,"delete");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[205]=C_h_intern(&lf[205],32,"\010compilerperform-lambda-lifting!");
lf[206]=C_h_intern(&lf[206],23,"\003syshash-table-for-each");
lf[207]=C_h_intern(&lf[207],1,"+");
lf[208]=C_h_intern(&lf[208],17,"delete-duplicates");
lf[209]=C_h_intern(&lf[209],14,"\004coreprimitive");
lf[210]=C_h_intern(&lf[210],7,"delete!");
lf[211]=C_h_intern(&lf[211],11,"concatenate");
lf[212]=C_h_intern(&lf[212],5,"count");
lf[213]=C_h_intern(&lf[213],22,"\010compilerhide-variable");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[217]=C_h_intern(&lf[217],12,"pretty-print");
lf[218]=C_h_intern(&lf[218],1,"l");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[229]=C_h_intern(&lf[229],11,"make-vector");
lf[230]=C_h_intern(&lf[230],3,"var");
lf[231]=C_h_intern(&lf[231],1,"y");
lf[232]=C_h_intern(&lf[232],2,"d2");
lf[233]=C_h_intern(&lf[233],1,"z");
lf[234]=C_h_intern(&lf[234],2,"d3");
lf[235]=C_h_intern(&lf[235],2,"d1");
lf[236]=C_h_intern(&lf[236],2,"op");
lf[237]=C_h_intern(&lf[237],5,"clist");
lf[238]=C_h_intern(&lf[238],34,"\010compilermembership-test-operators");
lf[239]=C_h_intern(&lf[239],32,"\010compilermembership-unfold-limit");
lf[240]=C_h_intern(&lf[240],4,"var1");
lf[241]=C_h_intern(&lf[241],4,"var0");
lf[242]=C_h_intern(&lf[242],6,"const1");
lf[243]=C_h_intern(&lf[243],4,"var2");
lf[244]=C_h_intern(&lf[244],6,"const2");
lf[245]=C_h_intern(&lf[245],4,"rest");
lf[246]=C_h_intern(&lf[246],5,"body2");
lf[247]=C_h_intern(&lf[247],5,"body1");
lf[248]=C_h_intern(&lf[248],27,"\010compilereq-inline-operator");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[250]=C_h_intern(&lf[250],19,"\010compilerimmediate\077");
lf[251]=C_h_intern(&lf[251],5,"const");
lf[252]=C_h_intern(&lf[252],1,"n");
lf[253]=C_h_intern(&lf[253],7,"clauses");
lf[254]=C_h_intern(&lf[254],4,"body");
lf[255]=C_h_intern(&lf[255],1,"d");
lf[256]=C_h_intern(&lf[256],4,"more");
lf[257]=C_h_intern(&lf[257],4,"args");
lf[258]=C_h_intern(&lf[258],1,"a");
lf[259]=C_h_intern(&lf[259],1,"b");
lf[260]=C_h_intern(&lf[260],1,"c");
lf[261]=C_h_intern(&lf[261],4,"cdar");
C_register_lf2(lf,262,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3166 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3169 in k3166 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3172 in k3169 in k3166 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3185,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 140  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[229]+1)))(4,*((C_word*)lf[229]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! simplifications ...) */,t1);
t3=C_set_block_item(lf[23] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[24]+1 /* (set! perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3438,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[109]+1 /* (set! perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5138,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[118]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5435,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[258],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[9],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[259],lf[260]);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[255],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[15],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[255],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[260],t15);
t17=(C_word)C_a_i_cons(&a,2,lf[259],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[258],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12713,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t18,t20);
t22=(C_word)C_a_i_cons(&a,2,t14,t21);
/* optimizer.scm: 502  register-simplifications */
((C_proc4)C_retrieve_symbol_proc(lf[118]))(4,*((C_word*)lf[118]+1),t7,lf[15],t22);}

/* a12712 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_12713,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12721,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 508  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t7,C_retrieve(lf[133]),t3);}

/* k12719 in a12712 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12721,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_12726(t6,((C_word*)t0)[2],t2);}

/* loop in k12719 in a12712 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_12726(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12726,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12736,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12771,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 510  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[28]+1)))(3,*((C_word*)lf[28]+1),t4,t2);}}

/* k12769 in loop in k12719 in a12712 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12775,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 510  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[261]+1)))(3,*((C_word*)lf[261]+1),t2,((C_word*)t0)[2]);}

/* k12773 in k12769 in loop in k12719 in a12712 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 510  simplify-named-call */
((C_proc9)C_retrieve_symbol_proc(lf[135]))(9,*((C_word*)lf[135]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12734 in loop in k12719 in a12712 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12736,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[23]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12745,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_12745(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12760,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 515  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[23]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 517  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_12726(t3,((C_word*)t0)[4],t2);}}

/* k12758 in k12734 in loop in k12719 in a12712 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[23]+1 /* (set! simplified-ops ...) */,t1);
t3=((C_word*)t0)[2];
f_12745(t3,t2);}

/* k12743 in k12734 in loop in k12719 in a12712 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_12745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[9],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[26],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,t4,t12);
t14=(C_word)C_a_i_cons(&a,2,lf[138],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[9],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[9],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[26],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t22,t26);
t28=(C_word)C_a_i_cons(&a,2,t19,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[138],t28);
t30=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[9],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[245],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[246],t33);
t35=(C_word)C_a_i_cons(&a,2,t32,t34);
t36=(C_word)C_a_i_cons(&a,2,lf[232],t35);
t37=(C_word)C_a_i_cons(&a,2,lf[10],t36);
t38=(C_word)C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t29,t38);
t40=(C_word)C_a_i_cons(&a,2,t18,t39);
t41=(C_word)C_a_i_cons(&a,2,lf[11],t40);
t42=(C_word)C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=(C_word)C_a_i_cons(&a,2,lf[247],t42);
t44=(C_word)C_a_i_cons(&a,2,t17,t43);
t45=(C_word)C_a_i_cons(&a,2,lf[235],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[10],t45);
t47=(C_word)C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=(C_word)C_a_i_cons(&a,2,t14,t47);
t49=(C_word)C_a_i_cons(&a,2,t3,t48);
t50=(C_word)C_a_i_cons(&a,2,lf[11],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[245],C_SCHEME_END_OF_LIST);
t52=(C_word)C_a_i_cons(&a,2,lf[232],t51);
t53=(C_word)C_a_i_cons(&a,2,lf[235],t52);
t54=(C_word)C_a_i_cons(&a,2,lf[246],t53);
t55=(C_word)C_a_i_cons(&a,2,lf[247],t54);
t56=(C_word)C_a_i_cons(&a,2,lf[244],t55);
t57=(C_word)C_a_i_cons(&a,2,lf[242],t56);
t58=(C_word)C_a_i_cons(&a,2,lf[236],t57);
t59=(C_word)C_a_i_cons(&a,2,lf[243],t58);
t60=(C_word)C_a_i_cons(&a,2,lf[240],t59);
t61=(C_word)C_a_i_cons(&a,2,lf[241],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12392,tmp=(C_word)a,a+=2,tmp);
t63=(C_word)C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=(C_word)C_a_i_cons(&a,2,t61,t63);
t65=(C_word)C_a_i_cons(&a,2,t50,t64);
t66=(C_word)C_a_i_cons(&a,2,lf[230],C_SCHEME_END_OF_LIST);
t67=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t68=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t69=(C_word)C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=(C_word)C_a_i_cons(&a,2,lf[9],t69);
t71=(C_word)C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t72=(C_word)C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=(C_word)C_a_i_cons(&a,2,lf[26],t72);
t74=(C_word)C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=(C_word)C_a_i_cons(&a,2,t70,t74);
t76=(C_word)C_a_i_cons(&a,2,t67,t75);
t77=(C_word)C_a_i_cons(&a,2,lf[138],t76);
t78=(C_word)C_a_i_cons(&a,2,lf[230],C_SCHEME_END_OF_LIST);
t79=(C_word)C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=(C_word)C_a_i_cons(&a,2,lf[9],t79);
t81=(C_word)C_a_i_cons(&a,2,lf[252],C_SCHEME_END_OF_LIST);
t82=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t83=(C_word)C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=(C_word)C_a_i_cons(&a,2,lf[9],t83);
t85=(C_word)C_a_i_cons(&a,2,t84,lf[253]);
t86=(C_word)C_a_i_cons(&a,2,t81,t85);
t87=(C_word)C_a_i_cons(&a,2,lf[18],t86);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[254],t88);
t90=(C_word)C_a_i_cons(&a,2,t80,t89);
t91=(C_word)C_a_i_cons(&a,2,lf[255],t90);
t92=(C_word)C_a_i_cons(&a,2,lf[10],t91);
t93=(C_word)C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=(C_word)C_a_i_cons(&a,2,t77,t93);
t95=(C_word)C_a_i_cons(&a,2,t66,t94);
t96=(C_word)C_a_i_cons(&a,2,lf[11],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[253],C_SCHEME_END_OF_LIST);
t98=(C_word)C_a_i_cons(&a,2,lf[252],t97);
t99=(C_word)C_a_i_cons(&a,2,lf[254],t98);
t100=(C_word)C_a_i_cons(&a,2,lf[255],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[251],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[241],t101);
t103=(C_word)C_a_i_cons(&a,2,lf[236],t102);
t104=(C_word)C_a_i_cons(&a,2,lf[230],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12171,tmp=(C_word)a,a+=2,tmp);
t106=(C_word)C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=(C_word)C_a_i_cons(&a,2,t104,t106);
t108=(C_word)C_a_i_cons(&a,2,t96,t107);
t109=(C_word)C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=(C_word)C_a_i_cons(&a,2,lf[69],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[256],C_SCHEME_END_OF_LIST);
t113=(C_word)C_a_i_cons(&a,2,t111,t112);
t114=(C_word)C_a_i_cons(&a,2,t109,t113);
t115=(C_word)C_a_i_cons(&a,2,lf[11],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[256],C_SCHEME_END_OF_LIST);
t117=(C_word)C_a_i_cons(&a,2,lf[240],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11812,tmp=(C_word)a,a+=2,tmp);
t119=(C_word)C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,t117,t119);
t121=(C_word)C_a_i_cons(&a,2,t115,t120);
t122=(C_word)C_a_i_cons(&a,2,lf[230],C_SCHEME_END_OF_LIST);
t123=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,t123,lf[257]);
t125=(C_word)C_a_i_cons(&a,2,lf[138],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[230],C_SCHEME_END_OF_LIST);
t127=(C_word)C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=(C_word)C_a_i_cons(&a,2,lf[9],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,lf[70],t129);
t131=(C_word)C_a_i_cons(&a,2,t128,t130);
t132=(C_word)C_a_i_cons(&a,2,lf[255],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[10],t132);
t134=(C_word)C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=(C_word)C_a_i_cons(&a,2,t125,t134);
t136=(C_word)C_a_i_cons(&a,2,t122,t135);
t137=(C_word)C_a_i_cons(&a,2,lf[11],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t139=(C_word)C_a_i_cons(&a,2,lf[70],t138);
t140=(C_word)C_a_i_cons(&a,2,lf[255],t139);
t141=(C_word)C_a_i_cons(&a,2,lf[257],t140);
t142=(C_word)C_a_i_cons(&a,2,lf[236],t141);
t143=(C_word)C_a_i_cons(&a,2,lf[230],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11664,tmp=(C_word)a,a+=2,tmp);
t145=(C_word)C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=(C_word)C_a_i_cons(&a,2,t143,t145);
t147=(C_word)C_a_i_cons(&a,2,t137,t146);
/* optimizer.scm: 520  register-simplifications */
((C_proc7)C_retrieve_symbol_proc(lf[118]))(7,*((C_word*)lf[118]+1),t2,lf[11],t65,t108,t121,t147);}

/* a11663 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_11664,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[248])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11710,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t1,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 655  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t9,t2,t3,lf[74]);}}

/* k11708 in a11663 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11710,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11693,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11698,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[138],t5,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_11698 in k11708 in a11663 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11698,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11691 in k11708 in a11663 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11693,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11685,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[10],((C_word*)t0)[2],t2);}

/* f_11685 in k11691 in k11708 in a11663 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11685,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11812,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11822,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_11822(t9,t1,t5,t4);}

/* loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_11822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11822,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11826,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12121,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_12121 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12121,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12116,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12116 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12116,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12111,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12111 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12111,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11832,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t1);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11850,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12102,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_12102 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12102,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12097,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12097 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12097,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11856,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12092,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12092 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12092,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11856,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[69]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* optimizer.scm: 601  loop1 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_11822(t6,((C_word*)t0)[5],t4,t5);}
else{
t3=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11886,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 603  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t4,((C_word*)t0)[8]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11886,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11915,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_11915(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_11915(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11915,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11919,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12075,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* f_12075 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12075,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11922,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12070,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_12070 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12070,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11925,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12065,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_12065 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12065,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11931,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12056,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 614  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t5,((C_word*)t0)[2],t6,lf[74]);}
else{
t5=t2;
f_11931(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_11931(t4,C_SCHEME_FALSE);}}

/* k12054 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12056,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_11931(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12048,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
f_11931(t2,C_SCHEME_FALSE);}}}

/* f_12048 in k12054 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12048,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12041 in k12054 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12043,2,t0,t1);}
t2=(C_word)C_eqp(lf[16],t1);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12030,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12035,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_11931(t3,C_SCHEME_FALSE);}}

/* f_12035 in k12041 in k12054 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12035,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12028 in k12041 in k12054 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
f_11931(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k11929 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_11931(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11931,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11954,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11959,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11974,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11984,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a11983 in k11929 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11984,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a11973 in k11929 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 623  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2]);}

/* k11980 in a11973 in k11929 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 623  reorganize-recursive-bindings */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_11959 in k11929 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11959,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11952 in k11929 in k11923 in k11920 in k11917 in loop2 in k11884 in k11854 in k11851 in k11848 in k11830 in k11827 in k11824 in loop1 in a11811 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11954,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 618  loop2 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_11915(t6,((C_word*)t0)[2],t3,t4,t5);}

/* a12170 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_12171,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[248])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12184,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 567  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k12182 in a12170 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12184,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12226,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 568  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12224 in k12182 in a12170 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12226,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12201,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 572  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12208 in k12224 in k12182 in a12170 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 573  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k12212 in k12208 in k12224 in k12182 in a12170 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 572  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[155]))(6,*((C_word*)lf[155]+1),((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12199 in k12224 in k12182 in a12170 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12202,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[18],((C_word*)t0)[2],t1);}

/* f_12202 in k12199 in k12224 in k12182 in a12170 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12202,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_12392,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[248])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12405,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 540  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k12403 in a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12405,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 541  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[250]))(3,*((C_word*)lf[250]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12409 in k12403 in a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12411,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12463,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 542  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12461 in k12409 in k12403 in a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12463,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12455,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 543  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[74]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12453 in k12461 in k12409 in k12403 in a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12455,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 547  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12437 in k12453 in k12461 in k12409 in k12403 in a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12443,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 548  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k12441 in k12437 in k12453 in k12461 in k12409 in k12403 in a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 550  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k12445 in k12441 in k12437 in k12453 in k12461 in k12409 in k12403 in a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12447,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12431,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[18],lf[249],t2);}

/* f_12431 in k12445 in k12441 in k12437 in k12453 in k12461 in k12409 in k12403 in a12391 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_12431(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12431,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[230],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[9],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[232],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[15],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[230],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[9],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t12,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[234],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[15],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t9,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[70],t18);
t20=(C_word)C_a_i_cons(&a,2,lf[235],t19);
t21=(C_word)C_a_i_cons(&a,2,lf[10],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[230],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[233],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[231],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[70],t24);
t26=(C_word)C_a_i_cons(&a,2,lf[234],t25);
t27=(C_word)C_a_i_cons(&a,2,lf[232],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[235],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11501,tmp=(C_word)a,a+=2,tmp);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t28,t30);
t32=(C_word)C_a_i_cons(&a,2,t21,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,lf[26],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[70],t37);
t39=(C_word)C_a_i_cons(&a,2,t33,t38);
t40=(C_word)C_a_i_cons(&a,2,lf[138],t39);
t41=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t42=(C_word)C_a_i_cons(&a,2,lf[231],t41);
t43=(C_word)C_a_i_cons(&a,2,t40,t42);
t44=(C_word)C_a_i_cons(&a,2,lf[235],t43);
t45=(C_word)C_a_i_cons(&a,2,lf[10],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t47=(C_word)C_a_i_cons(&a,2,lf[231],t46);
t48=(C_word)C_a_i_cons(&a,2,lf[237],t47);
t49=(C_word)C_a_i_cons(&a,2,lf[70],t48);
t50=(C_word)C_a_i_cons(&a,2,lf[236],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[235],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11305,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t45,t54);
/* optimizer.scm: 662  register-simplifications */
((C_proc5)C_retrieve_symbol_proc(lf[118]))(5,*((C_word*)lf[118]+1),t2,lf[10],t32,t55);}

/* a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_11305,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[238]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[239]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11327,a[2]=t6,a[3]=t3,a[4]=t8,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 693  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11327,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11350,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11363,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11365,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11407,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 710  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t8,C_SCHEME_FALSE);}

/* k11405 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 702  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a11364 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11365,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11382,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11399,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 707  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,((C_word*)t0)[2]);}

/* k11397 in a11364 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 707  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k11401 in k11397 in a11364 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11403,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11391,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[138],((C_word*)t0)[2],t2);}

/* f_11391 in k11401 in k11397 in a11364 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11391,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11380 in a11364 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 708  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,C_SCHEME_TRUE);}

/* k11384 in k11380 in a11364 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11386,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11374,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[17],C_SCHEME_END_OF_LIST,t2);}

/* f_11374 in k11384 in k11380 in a11364 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11374,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11361 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11363,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11355,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[10],((C_word*)t0)[2],t2);}

/* f_11355 in k11361 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11355,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11348 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11350,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11342,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_11342 in k11348 in k11325 in a11304 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11342,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a11500 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11501(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_11501,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[136]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11521,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 678  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11519 in a11500 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11525,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11530,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[17],C_SCHEME_END_OF_LIST,t3);}

/* f_11530 in k11519 in a11500 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11530,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11523 in k11519 in a11500 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11525,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11513,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t2);}

/* f_11513 in k11523 in k11519 in a11500 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11513,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1 /* (set! reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5450,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5808,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 805  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[229]+1)))(4,*((C_word*)lf[229]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5808,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1 /* (set! substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[134]+1 /* (set! rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5810,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[135]+1 /* (set! simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5830,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[176]+1 /* (set! transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8176,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[205]+1 /* (set! perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9441,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9441,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9444,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9550,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9772,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9871,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10374,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10590,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10895,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11012,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11184,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1781 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t15,lf[20],lf[228]);}

/* k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11187,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1782 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_9444(t3,t2);}

/* k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11190,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1783 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[227]);}

/* k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1784 build-call-graph */
t3=((C_word*)t0)[2];
f_9550(t3,t2,((C_word*)t0)[3]);}

/* k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11196,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1785 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[226]);}

/* k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11199,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1786 eliminate */
t3=((C_word*)t0)[4];
f_9772(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11202,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11276,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1787 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,lf[218],lf[225]);}

/* k11274 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1787 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[217]))(3,*((C_word*)lf[217]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11202(2,t2,C_SCHEME_UNDEFINED);}}

/* k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1788 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[224]);}

/* k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1789 collect-accessibles */
t3=((C_word*)t0)[2];
f_9871(t3,t2,((C_word*)t0)[3]);}

/* k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11270,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1790 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,lf[218],lf[223]);}

/* k11268 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1790 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[217]))(3,*((C_word*)lf[217]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11211(2,t2,C_SCHEME_UNDEFINED);}}

/* k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1791 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[222]);}

/* k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11217,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11267,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1792 eliminate4 */
t4=((C_word*)t0)[3];
f_10130(t4,t3,((C_word*)t0)[2]);}

/* k11265 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11267,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10096,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10096(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k11265 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_10096(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10096,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10100,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10114,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1586 filter */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t4,t5,t2);}

/* a10113 in loop in k11265 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10114,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1586 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t1,t3,t4);}

/* a10119 in a10113 in loop in k11265 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10120,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k10098 in loop in k11265 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1590 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10096(t5,((C_word*)t0)[3],t1,t2);}}

/* k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11257,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11259,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t5=*((C_word*)lf[196]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a11258 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11259,2,t0,t1);}
/* optimizer.scm: 1793 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),t1,((C_word*)t0)[2]);}

/* k11255 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1793 debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],lf[7],lf[221],t1);}

/* k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1794 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[220]);}

/* k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1795 compute-extra-variables */
t3=((C_word*)t0)[2];
f_10374(t3,t2,((C_word*)t0)[5]);}

/* k11224 in k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11250,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1796 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,lf[218],lf[219]);}

/* k11248 in k11224 in k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1796 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[217]))(3,*((C_word*)lf[217]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11229(2,t2,C_SCHEME_UNDEFINED);}}

/* k11227 in k11224 in k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1797 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[216]);}

/* k11230 in k11227 in k11224 in k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1798 extend-call-sites! */
t3=((C_word*)t0)[2];
f_10895(t3,t2,((C_word*)t0)[4]);}

/* k11233 in k11230 in k11227 in k11224 in k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1799 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[215]);}

/* k11236 in k11233 in k11230 in k11227 in k11224 in k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1800 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_11012(t3,t2,((C_word*)t0)[4]);}

/* k11239 in k11236 in k11233 in k11230 in k11227 in k11224 in k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1801 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[214]);}

/* k11242 in k11239 in k11236 in k11233 in k11230 in k11227 in k11224 in k11221 in k11218 in k11215 in k11212 in k11209 in k11206 in k11203 in k11200 in k11197 in k11194 in k11191 in k11188 in k11185 in k11182 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1802 reconstruct! */
t2=((C_word*)t0)[5];
f_10590(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_11012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11012,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11018,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11018(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11018,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11022,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11177,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_11177 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11177,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11172,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11172 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11172,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11028,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11167,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11167 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11167,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11028,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11037,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11121,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11122,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[16]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11135,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11158,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11159,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t1);}}}

/* f_11159 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11159,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11156 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k11133 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11135,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1776 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t3,((C_word*)t0)[2],lf[69]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k11142 in k11133 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1777 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11145 in k11142 in k11133 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1778 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* f_11122 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11122,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11119 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k11035 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11037,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11042,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_11042(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop3058 in k11035 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_11042(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11042,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1766 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[177]))(4,*((C_word*)lf[177]+1),t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11065,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11080,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1768 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11083,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_11083(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_11083(t12,t11);}}}

/* k11081 in doloop3058 in k11035 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_11083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_11042(t4,((C_word*)t0)[2],t2,t3);}

/* k11078 in doloop3058 in k11035 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1768 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11063 in doloop3058 in k11035 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11072,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11076,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1769 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k11074 in k11063 in doloop3058 in k11035 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1769 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11070 in k11063 in doloop3058 in k11035 in k11026 in k11023 in k11020 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1769 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_10895(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10895,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10901,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10901(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10901,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10905,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11006,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_11006 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11006,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11001,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11001 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_11001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11001,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10911,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10996,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_10996 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10996,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10911,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[15]);
if(C_truep(t2)){
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10987,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10988,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],t1);}}

/* f_10988 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10988,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10985 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10987,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10979,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[4];
f_10923(2,t3,C_SCHEME_UNDEFINED);}}

/* f_10979 in k10985 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10979,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10976 in k10985 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10978,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(C_word)C_i_set_car(((C_word*)t0)[6],C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10962,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t3);
/* map */
t8=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,C_retrieve(lf[48]),t7);}
else{
t4=((C_word*)t0)[4];
f_10923(2,t4,C_SCHEME_UNDEFINED);}}

/* k10960 in k10976 in k10985 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1748 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[2],t1,t2);}

/* k10956 in k10976 in k10985 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10958,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1746 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10921 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10931,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10931 in k10921 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10931,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10928 in k10921 in k10909 in k10906 in k10903 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_10590(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10590,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10602,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10604,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10745,a[2]=t2,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10746,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}

/* f_10746 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10746,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10743 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 1682 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10604,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10611,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1685 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t5,((C_word*)t0)[2],t4,lf[46]);}

/* k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10614,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1686 hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),t2,((C_word*)t0)[5]);}

/* k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10733,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_10733 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10733,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10732,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1687 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t2,t3);}

/* a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10623,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10630,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[82]),t6);}

/* k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10633,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1692 map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[131]+1)))(5,*((C_word*)lf[131]+1),t2,*((C_word*)lf[132]+1),((C_word*)t0)[5],t1);}

/* k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10719,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10720,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* f_10720 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10720,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10719,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10755,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10770,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10770(3,t8,((C_word*)t0)[2],t2);}

/* walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10770,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10774,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10889,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10889 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10889,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10884,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_10884 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10884,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10780,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10879,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_10879 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10879,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10780,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10789,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10796,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[9]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10813,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1721 rename */
t6=((C_word*)t0)[3];
f_10755(3,t6,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[16]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10826,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10837,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1723 rename */
t8=((C_word*)t0)[3];
f_10755(3,t8,t6,t7);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1726 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],t6,t7);}
else{
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],t1);}}}}}

/* a10855 in k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10856,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10871,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10875,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k10873 in a10855 in k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1729 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10869 in a10855 in k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1730 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10770(3,t4,((C_word*)t0)[2],t3);}

/* k10835 in k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10837,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1723 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10824 in k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10811 in k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10813,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1721 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10794 in k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1718 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10787 in k10778 in k10775 in k10772 in walk in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k10717 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10755,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1695 gensym */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t2,lf[83]);}

/* k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10711,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10656,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10673,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10695,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10699,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1701 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10697 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1701 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k10693 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10695,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10681,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10687,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_10687 in k10693 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10687,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10679 in k10693 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10682,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],((C_word*)t0)[2],t1);}

/* f_10682 in k10679 in k10693 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10682,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k10671 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10673,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10665,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[16],((C_word*)t0)[2],t2);}

/* f_10665 in k10671 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10665,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k10654 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10656,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10648,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_10648 in k10654 in k10709 in k10634 in k10631 in k10628 in a10622 in k10730 in k10612 in k10609 in a10603 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10648(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10648,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k10600 in reconstruct! in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10602,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1679 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_10374(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10374,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10454,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10576,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a10575 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10576,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10454,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10456,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10531,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10536,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10536,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10574,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1668 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t4,((C_word*)t0)[2],t3,lf[46]);}

/* k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10574,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10383,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10383(3,t8,t4,t1);}

/* walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10383,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10387,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10447,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10447 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10447,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10385 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10442,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10442 in k10385 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10442,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10388 in k10385 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10393,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10437,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10437 in k10388 in k10385 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10391 in k10388 in k10385 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10393,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10403,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1644 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10421,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1647 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[4],t4,t5);}
else{
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);}}}

/* a10420 in k10391 in k10388 in k10385 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10421,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10426,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1650 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k10424 in a10420 in k10391 in k10388 in k10385 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1651 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10383(3,t4,((C_word*)t0)[2],t3);}

/* k10401 in k10391 in k10388 in k10385 in walk in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10379 in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10381,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10550,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10552,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10566,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1674 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t5,t6,*((C_word*)lf[35]+1));}

/* k10564 in k10379 in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1670 remove */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10551 in k10379 in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10552,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k10548 in k10379 in k10572 in a10535 in k10529 in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10550,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10456,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10524,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1659 count */
((C_proc4)C_retrieve_symbol_proc(lf[212]))(4,*((C_word*)lf[212]+1),t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a10523 in walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10524,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k10520 in walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10522,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10476,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a10509 in k10520 in walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10510,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1662 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10456(3,t4,t1,t3);}

/* k10474 in k10520 in walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10476,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10486,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10494,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10498,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10500,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a10499 in k10474 in k10520 in walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10500,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k10496 in k10474 in k10520 in walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1664 concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[211]))(3,*((C_word*)lf[211]+1),((C_word*)t0)[2],t1);}

/* k10492 in k10474 in k10520 in walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1664 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10484 in k10474 in k10520 in walk in k10452 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_10130(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10130,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10134,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10136,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10136(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_10136(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10136,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10140,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10368,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10368 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10368,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10363,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10363 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10363,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10358,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10358 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10358,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10146,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10155,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_10155(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[26]);
if(C_truep(t4)){
t5=t3;
f_10155(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[69]);
if(C_truep(t5)){
t6=t3;
f_10155(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[209]);
t7=t3;
f_10155(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[7],lf[157])));}}}}

/* k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_10155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10155,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10166,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_10166(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10217,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1609 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[15]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10252,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1615 call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10332,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a10331 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10332,3,t0,t1,t2);}
/* optimizer.scm: 1630 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10136(t3,t1,t2,((C_word*)t0)[2]);}

/* a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10322,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10323,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_10323 in a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10323,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10320 in a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10322,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10314,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* f_10314 in k10320 in a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10314,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10311 in k10320 in a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10313,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_10268(3,t6,((C_word*)t0)[2],t2);}

/* loop in k10311 in k10320 in a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10268,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10288,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10298,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1624 lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t7,*((C_word*)lf[35]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k10296 in loop in k10311 in k10320 in a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10298,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10288(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10302,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1626 delete! */
((C_proc5)C_retrieve_symbol_proc(lf[210]))(5,*((C_word*)lf[210]+1),t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[35]+1));}}

/* k10300 in k10296 in loop in k10311 in k10320 in a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1627 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k10286 in loop in k10311 in k10320 in a10251 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k10239 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10245 in k10239 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10246,3,t0,t1,t2);}
/* optimizer.scm: 1629 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10136(t3,t1,t2,((C_word*)t0)[2]);}

/* a10216 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10217(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10217,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10229,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1612 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t6,t2,((C_word*)t0)[2]);}

/* k10227 in a10216 in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1612 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10136(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_10166(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10166,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10184,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1604 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10187,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1606 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_10136(t6,t4,t5,((C_word*)t0)[3]);}}

/* k10185 in loop in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1607 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10166(t4,((C_word*)t0)[2],t2,t3);}

/* k10182 in loop in k10153 in k10144 in k10141 in k10138 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1604 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10136(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10132 in eliminate4 in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9871(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9871,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9875,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9877,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_9877(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9877(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9877,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10034,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10034 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10034,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10029,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_10029 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10029,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10024,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_10024 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_10024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10024,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9887,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t4=t3;
f_9896(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[10],lf[26]);
if(C_truep(t4)){
t5=t3;
f_9896(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[69]);
if(C_truep(t5)){
t6=t3;
f_9896(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[10],lf[209]);
t7=t3;
f_9896(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[10],lf[157])));}}}}

/* k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9896,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[11]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9907,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9907(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9955,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9989,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1561 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_9955(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_9955(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9998,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a9997 in k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9998,3,t0,t1,t2);}
/* optimizer.scm: 1567 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9877(t3,t1,t2,((C_word*)t0)[2]);}

/* k9987 in k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9955(t3,t2);}

/* k9953 in k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9955,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1562 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t2,t3);}

/* a9963 in k9953 in k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9964,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9976,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1565 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t6,t2,((C_word*)t0)[2]);}

/* k9974 in a9963 in k9953 in k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1565 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9877(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9907(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9907,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9925,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1552 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9928,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1554 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9877(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9926 in loop in k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1555 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9907(t4,((C_word*)t0)[2],t2,t3);}

/* k9923 in loop in k9894 in k9885 in k9882 in k9879 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1552 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9877(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9873 in collect-accessibles in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9772(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9772,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9778,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1522 remove */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t1,t4,t3);}

/* a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9778,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9812,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9822,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1532 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),t6,t5);}

/* k9820 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9822,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9827,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9827(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k9820 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9827(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9827,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9834,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1535 lset-difference */
((C_proc6)C_retrieve_symbol_proc(lf[181]))(6,*((C_word*)lf[181]+1),t5,*((C_word*)lf[35]+1),t6,t3,((C_word*)t0)[2]);}

/* k9832 in count in k9820 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9861,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1536 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t2,t3,*((C_word*)lf[35]+1));}

/* k9859 in k9832 in count in k9820 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9861,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1537 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9855 in k9859 in k9832 in count in k9820 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9847,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9849,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a9848 in k9855 in k9859 in k9832 in count in k9820 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9849,3,t0,t1,t2);}
/* optimizer.scm: 1538 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9827(t3,t1,t2,((C_word*)t0)[2]);}

/* k9845 in k9855 in k9859 in k9832 in count in k9820 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1538 fold */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[3],*((C_word*)lf[207]+1),((C_word*)t0)[2],t1);}

/* k9810 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9812,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1525 any */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),((C_word*)t0)[5],t3,t4);}}

/* a9789 in k9810 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9790(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9790,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9797,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1526 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t3,((C_word*)t0)[2],t2,lf[73]);}

/* k9795 in a9789 in k9810 in a9777 in eliminate in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9550(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9550,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9553,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9717,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9719,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t14=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a9718 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9719,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9765,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9766,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* f_9766 in a9718 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9766(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9766,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9763 in a9718 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9765,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9734,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1511 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t5,t2,t6);}

/* a9743 in k9763 in a9718 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9744,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9756,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9757,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* f_9757 in a9743 in k9763 in a9718 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9757(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9757,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9754 in a9743 in k9763 in a9718 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 1514 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9553(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k9732 in k9763 in a9718 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9738,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1515 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k9736 in k9732 in k9763 in a9718 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9715 in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9553(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9553,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9557,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9710,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_9710 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9710,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9705,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9705 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9705,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9700,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9700 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9700,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9563,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[9]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[10],lf[16]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9578,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_memq(t4,((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9603,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_9603(2,t8,t6);}
else{
/* optimizer.scm: 1487 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t7,((C_word*)t0)[2],t4,lf[99]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[10],lf[11]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9621,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_9621(t8,((C_word*)t0)[6],((C_word*)t0)[9],t1);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[13]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9675,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1499 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9692,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],t6,t1);}}}}

/* a9691 in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9692,3,t0,t1,t2);}
/* optimizer.scm: 1502 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9553(t3,t1,t2,((C_word*)t0)[2]);}

/* a9674 in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9675,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9687,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1501 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t6,t2,((C_word*)t0)[2]);}

/* k9685 in a9674 in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1501 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9553(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9621(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9621,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9639,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1494 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9645,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1496 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_9553(t7,t5,t6,((C_word*)t0)[3]);}}

/* k9643 in loop in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1497 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9621(t4,((C_word*)t0)[2],t2,t3);}

/* k9637 in loop in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1494 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9553(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9601 in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9603,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9578(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_9578(t4,t3);}}

/* k9576 in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9578,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9581,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_9581(t5,t4);}
else{
t3=t2;
f_9581(t3,C_SCHEME_UNDEFINED);}}

/* k9579 in k9576 in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9581,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9586,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9585 in k9579 in k9576 in k9561 in k9558 in k9555 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9586,3,t0,t1,t2);}
/* optimizer.scm: 1490 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9553(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9444,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9448,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9450,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1458 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),t4,t5,((C_word*)t0)[2]);}

/* a9449 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9450,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[46],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[74],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[116],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9481,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[75],t3))){
t10=t9;
f_9481(t10,C_SCHEME_FALSE);}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9531,a[2]=t8,a[3]=t6,a[4]=t9,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(t4);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9536,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* f_9536 in a9449 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9536,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9529 in a9449 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[13],t1);
if(C_truep(t2)){
if(C_truep((C_word)C_i_assq(lf[99],((C_word*)t0)[5]))){
t3=((C_word*)t0)[4];
f_9481(t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_length(t3);
t5=((C_word*)t0)[4];
f_9481(t5,(C_word)C_eqp(((C_word*)t0)[2],t4));}}
else{
t3=((C_word*)t0)[4];
f_9481(t3,C_SCHEME_FALSE);}}

/* k9479 in a9449 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_9481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9481,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1469 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9483 in k9479 in a9449 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9485,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9489,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1470 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k9487 in k9483 in k9479 in a9449 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9446 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8176,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8810,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8356,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8179,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9436,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1437 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t17,lf[20],lf[204]);}

/* k9434 in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9439,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1438 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8179(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9437 in k9434 in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8179(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8179,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=t3,a[11]=t1,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8350,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* f_8350 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8350,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8345,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_8345 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8345,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8340,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_8340 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8340,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8187 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8189,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t2)){
t3=(C_word)C_i_caddr(((C_word*)t0)[14]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8204,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[10])){
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[14]))){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=t3,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1229 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t5,((C_word*)t0)[2],((C_word*)t0)[10],lf[75]);}
else{
t5=t4;
f_8204(2,t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8204(2,t5,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[14]);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 1239 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8179(t6,((C_word*)t0)[12],t4,t5,C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8315,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[14]);
t7=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 1241 walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_8179(t8,t5,t6,t7,((C_word*)t0)[11]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[12],t5,((C_word*)t0)[5]);}}}}

/* a8334 in k8187 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8335,3,t0,t1,t2);}
/* optimizer.scm: 1243 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8179(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8313 in k8187 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1242 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8179(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8287 in k8187 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8289,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_8204(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1231 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[46]);}
else{
t2=((C_word*)t0)[9];
f_8204(2,t2,C_SCHEME_FALSE);}}}

/* k8233 in k8287 in k8187 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8235,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1232 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[74]);}
else{
t2=((C_word*)t0)[4];
f_8204(2,t2,C_SCHEME_FALSE);}}

/* k8239 in k8233 in k8287 in k8187 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8241,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1233 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[116]);}
else{
t2=((C_word*)t0)[4];
f_8204(2,t2,C_SCHEME_FALSE);}}

/* k8245 in k8239 in k8233 in k8287 in k8187 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8247,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1236 scan */
t9=((C_word*)t0)[4];
f_8356(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_8204(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_8204(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_8204(2,t2,C_SCHEME_FALSE);}}

/* k8202 in k8187 in k8184 in k8181 in walk in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1237 transform */
t2=((C_word*)t0)[11];
f_8810(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1238 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8179(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8356(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8356,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8359,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8801,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1322 rec */
t18=((C_word*)t12)[1];
f_8359(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k8799 in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8801,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8808,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1323 delete */
((C_proc5)C_retrieve_symbol_proc(lf[203]))(5,*((C_word*)lf[203]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[35]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8806 in k8799 in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1323 lset= */
((C_proc5)C_retrieve_symbol_proc(lf[202]))(5,*((C_word*)lf[202]+1),((C_word*)t0)[3],*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8359(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8359,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8363,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t5,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t3,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8788,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* f_8788 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8788,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t1,tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8783,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8783 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8783,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_8369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8778,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8778 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8778,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8369,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8408,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=t3,a[6]=((C_word*)t0)[18],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1254 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t4,((C_word*)t0)[14],t3,lf[198]);}
else{
t3=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t3)){
if(C_truep(((C_word*)t0)[13])){
t4=(C_word)C_i_caddr(((C_word*)t0)[19]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8426,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1262 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[18],t4,t5);}
else{
t4=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_eqp(t1,lf[87]);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[16])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[19]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[15])[1],t6);
t8=C_mutate(((C_word *)((C_word*)t0)[15])+1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8463,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1271 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[18],t9,((C_word*)t0)[11]);}}
else{
t5=(C_word)C_eqp(t1,lf[190]);
if(C_truep(t5)){
if(C_truep(((C_word*)t0)[8])){
if(C_truep(((C_word*)t0)[7])){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8497,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[11]);
/* optimizer.scm: 1274 scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t6,t7,((C_word*)t0)[9]);}
else{
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t1,lf[199]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8513,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cadr(((C_word*)t0)[19]);
/* optimizer.scm: 1279 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[200]))(3,*((C_word*)lf[200]+1),t7,t8);}
else{
t7=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8554,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_i_car(((C_word*)t0)[19]);
/* optimizer.scm: 1287 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[200]))(3,*((C_word*)lf[200]+1),t8,t9);}
else{
t8=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t8)){
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8681,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[18],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8682,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[178]);
if(C_truep(t9)){
t10=(C_word)C_i_cadddr(((C_word*)t0)[19]);
t11=(C_word)C_eqp(t10,C_fix(0));
if(C_truep(t11)){
t12=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t12=((C_word*)((C_word*)t0)[16])[1];
if(C_truep(t12)){
t13=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[15])[1],t10);
t14=C_mutate(((C_word *)((C_word*)t0)[15])+1,t13);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8716,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1313 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[18],t15,((C_word*)t0)[11]);}}}
else{
t10=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t10)){
t11=(C_word)C_i_car(((C_word*)t0)[11]);
t12=(C_word)C_i_car(((C_word*)t0)[19]);
/* optimizer.scm: 1314 rec */
t13=((C_word*)((C_word*)t0)[10])[1];
f_8359(t13,((C_word*)t0)[18],t11,t12,C_SCHEME_FALSE,((C_word*)t0)[9]);}
else{
t11=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8749,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_car(((C_word*)t0)[11]);
t14=(C_word)C_i_car(((C_word*)t0)[19]);
/* optimizer.scm: 1316 rec */
t15=((C_word*)((C_word*)t0)[10])[1];
f_8359(t15,t12,t13,t14,((C_word*)t0)[2],((C_word*)t0)[9]);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8773,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1318 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[18],t12,((C_word*)t0)[11]);}}}}}}}}}}}

/* a8772 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8773,3,t0,t1,t2);}
/* optimizer.scm: 1318 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8359(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8747 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8749,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8760,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1317 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8758 in k8747 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1317 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8359(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a8715 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8716,3,t0,t1,t2);}
/* optimizer.scm: 1313 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8359(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* f_8682 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8682,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8681,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8673,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_8673 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8673,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8670 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8672,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8607,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8635,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8660,a[2]=t6,a[3]=t7,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8661,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t6=t3;
f_8607(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8607(t5,(C_word)C_eqp(t2,((C_word*)t0)[2]));}}

/* f_8661 in k8670 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8661,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8658 in k8670 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8660,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8651,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8652,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_8635(t3,C_SCHEME_UNDEFINED);}}

/* f_8652 in k8658 in k8670 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8652,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8649 in k8658 in k8670 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8651,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_8635(t5,t4);}

/* k8633 in k8670 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_8607(t3,C_SCHEME_TRUE);}

/* k8605 in k8670 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8607,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8612,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1306 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8611 in k8605 in k8670 in k8679 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8612,3,t0,t1,t2);}
/* optimizer.scm: 1306 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8359(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8552 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8554,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8560(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8560(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8560(t7,C_SCHEME_TRUE);}}}

/* k8558 in k8552 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8560,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8565,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1293 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8564 in k8558 in k8552 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8565,3,t0,t1,t2);}
/* optimizer.scm: 1293 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8359(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8511 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8513,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8519,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8519(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8519(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8519(t7,C_SCHEME_TRUE);}}}

/* k8517 in k8511 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8519,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8524,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1285 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8523 in k8517 in k8511 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8524,3,t0,t1,t2);}
/* optimizer.scm: 1285 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8359(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8495 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8497,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8493,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1276 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8491 in k8495 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a8462 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8463,3,t0,t1,t2);}
/* optimizer.scm: 1271 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8359(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a8425 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8426(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8426,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8442,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1266 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t8,t2,((C_word*)t0)[2]);}

/* k8440 in a8425 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1266 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8359(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k8406 in k8367 in k8364 in k8361 in rec in scan in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8810(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8810,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8814,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=t1,a[8]=t5,a[9]=t6,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9424,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9426,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t11=*((C_word*)lf[196]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1328 debugging */
((C_proc6)C_retrieve_symbol_proc(lf[6]))(6,*((C_word*)lf[6]+1),t8,lf[7],lf[197],t3,t7);}}

/* a9425 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9426,2,t0,t1);}
/* optimizer.scm: 1327 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),t1,((C_word*)t0)[2]);}

/* k9422 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1327 debugging */
((C_proc7)C_retrieve_symbol_proc(lf[6]))(7,*((C_word*)lf[6]+1),((C_word*)t0)[4],lf[7],lf[194],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8814,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9410,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* f_9410 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9410,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8818,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_length(t2);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1333 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t6,((C_word*)t0)[2],((C_word*)t0)[5],lf[116]);}

/* k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8824,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t5=(C_word)C_i_length(((C_word*)t0)[11]);
t6=(C_word)C_eqp(t5,C_fix(4));
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
t8=t4;
f_8830(t8,(C_word)C_i_listp(t7));}
else{
t7=t4;
f_8830(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8830(t5,C_SCHEME_FALSE);}}

/* k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8830,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1337 caaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[192]+1)))(3,*((C_word*)lf[192]+1),t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 1435 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[10],lf[193],((C_word*)t0)[13]);}}

/* k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1338 cdaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[191]+1)))(3,*((C_word*)lf[191]+1),t2,((C_word*)t0)[14]);}

/* k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8839,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1342 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t4,((C_word*)t0)[2],lf[190]);}

/* k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8848,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9373,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9374,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_9374 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9374(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9374,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9373,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9084,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_9084(3,t6,((C_word*)t0)[2],t2);}

/* rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9084,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9365,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_9365 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9365,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9091,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9360,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* f_9360 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9360,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9355,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}

/* f_9355 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9355,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9094,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(C_word)C_i_cadr(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9109,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9312,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t3=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9338,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1389 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}
else{
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[9],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[13]);}}
else{
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[9],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[13]);}}}

/* k9336 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9338,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1390 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[177]))(4,*((C_word*)lf[177]+1),t3,t4,((C_word*)t0)[3]);}

/* k9339 in k9336 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1391 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9084(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9312 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9312,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9307,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9307 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9307,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9302,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9302 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9302,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9301,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(C_word)C_eqp(((C_word*)t0)[12],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1356 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t5,C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)((C_word*)t0)[11])[1]);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[13]);
t6=(C_word)C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9276,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1381 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t7,((C_word*)t0)[6],lf[188]);}
else{
/* optimizer.scm: 1384 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),((C_word*)t0)[7],lf[189]);}}}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9274 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1382 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k9277 in k9274 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1383 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9128,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_9137(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1359 quit */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t5,lf[184],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[2],tmp=(C_word)a,a+=10,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9252,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}
else{
/* optimizer.scm: 1379 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[174]))(4,*((C_word*)lf[174]+1),((C_word*)t0)[8],lf[187],((C_word*)t0)[11]);}}}

/* f_9252 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9252,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9251,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9183,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_i_length(t4);
t6=(C_word)C_eqp(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t3;
f_9183(2,t7,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1370 quit */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t3,lf[186],((C_word*)t0)[2]);}}

/* k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1373 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,((C_word*)t0)[5],lf[11]);}

/* k9184 in k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9189,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9220,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9228,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9229,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_9229 in k9184 in k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9229,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9226 in k9184 in k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(t1);
/* optimizer.scm: 1374 take */
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),((C_word*)t0)[2],t2,C_fix(1));}

/* k9218 in k9184 in k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1374 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9187 in k9184 in k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9192,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9203,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9212,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[183],t4,t5);}

/* f_9212 in k9187 in k9184 in k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9212,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k9201 in k9187 in k9184 in k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9203,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
/* optimizer.scm: 1375 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9190 in k9187 in k9184 in k9181 in k9249 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1378 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9084(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9135 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1362 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,((C_word*)t0)[3],lf[183]);}

/* k9138 in k9135 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1363 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[3],t3);}

/* k9141 in k9138 in k9135 in k9126 in k9299 in k9110 in k9107 in k9092 in k9089 in k9086 in rec in k9371 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1364 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8851,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9064,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9066,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1412 lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[181]))(5,*((C_word*)lf[181]+1),t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a9065 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9066(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9066,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k9062 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8994 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8995,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9056,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_9056 in a8994 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9056,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9000 in a8994 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9005,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_length(t3);
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t2;
f_9005(2,t6,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1402 quit */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t2,lf[180],((C_word*)t0)[2]);}}

/* k9003 in k9000 in a8994 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9005,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(C_word)C_i_cddr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9029,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t3,lf[178],t4,t7);}

/* f_9029 in k9003 in k9000 in a8994 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9029,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k9018 in k9003 in k9000 in a8994 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_9020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9020,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1405 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8851,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8986,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* f_8986 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8986,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8863,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1417 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[177]))(4,*((C_word*)lf[177]+1),t2,((C_word*)t0)[2],t1);}

/* k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8912,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1419 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8912,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8972,a[2]=t5,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8977,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* f_8977 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8977,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8972,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8940,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8964,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_8964 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8964,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8938 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8944,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8959,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8959 in k8938 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8959,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8942 in k8938 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8948,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8954,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8954 in k8942 in k8938 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8954,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8946 in k8942 in k8938 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8949,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8949 in k8946 in k8942 in k8938 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8949,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8934 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8936,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8928,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_8928 in k8934 in k8970 in a8911 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8928,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1428 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[177]))(4,*((C_word*)lf[177]+1),t2,t1,((C_word*)t0)[2]);}

/* k8867 in k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8874,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8873 in k8867 in k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8874,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8881,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8910,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1432 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t5);}

/* k8908 in a8873 in k8867 in k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8910,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1432 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8879 in a8873 in k8867 in k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8888,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8898,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8898 in k8879 in a8873 in k8867 in k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8898,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8886 in k8879 in a8873 in k8867 in k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8892,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8893,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_8893 in k8886 in k8879 in a8873 in k8867 in k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8893(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8893,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8890 in k8886 in k8879 in a8873 in k8867 in k8864 in k8861 in k8858 in k8849 in k8846 in k8843 in k8837 in k8834 in k8828 in k8822 in k8816 in k8812 in transform in ##compiler#transform-direct-lambdas! in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_car(((C_word*)t0)[2],t1));}

/* ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word ab[10],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5830,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5887,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6013,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);
case C_fix(2):
if(C_truep(C_retrieve(lf[136]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6038,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6136,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t4);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[136]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6169,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6190,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[136]))){
if(C_truep(C_retrieve(lf[140]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6218,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6263,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t4);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[136]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6286,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6357,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[140]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[136]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6391,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6442,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t4);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[140]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[136]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t11,t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6480,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6526,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t4);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[136]))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6553,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6560,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[136]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6579,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6725,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[136]))){
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[140]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6753,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6824,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t4);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[136]))){
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[140]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6852,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6904,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t4);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[136]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6923,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6992,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[136]))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7011,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7063,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[136]))){
t9=(C_word)C_i_cadr(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7088,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7143,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t4);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[136]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=C_retrieve(lf[140]);
t12=(C_truep(t11)?t11:(C_word)C_i_cadddr(t7));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7182,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7243,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t4);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[136]))){
t12=(C_word)C_i_not(t9);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,t9));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7287,a[2]=t10,a[3]=t11,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7349,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t4);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[136]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7377,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7423,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t4);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[136]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7456,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7477,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[136]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7496,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7641,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[140]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[136]))){
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t9,t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7678,a[2]=t8,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7740,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t4);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[136]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7763,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7924,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[136]))){
t12=(C_word)C_eqp(t10,t9);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7958,a[2]=t11,a[3]=t8,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8019,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t4);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[136]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8038,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8167,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1204 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t1,lf[175]);}}

/* f_8167 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8167,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8038,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8058,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8067,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1190 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8071,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a8078 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8079,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8087,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8093,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_8093(t9,t4,t3,t5);}

/* loop in a8078 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_8093(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8093,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8113,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 814  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5855,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_5855(t8,(C_word)C_eqp(lf[26],t7));}
else{
t7=t6;
f_5855(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8142,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1202 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k8140 in loop in a8078 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8142,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5853 in loop in a8078 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 815  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 816  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k8111 in loop in a8078 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8117,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1200 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8093(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k8115 in k8111 in loop in a8078 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8117,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8085 in a8078 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1193 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8072 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8073,2,t0,t1);}
/* optimizer.scm: 1192 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8069 in k8065 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1189 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[155]))(5,*((C_word*)lf[155]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8056 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8059,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_8059 in k8056 in k8036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8059(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8059,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_8019 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8019,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7956 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7958,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[140]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7983,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[145]),lf[150]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8002,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1171 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8010,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t4,lf[87],t7,((C_word*)t0)[3]);}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8010 in k7956 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8010,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8000 in k7956 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8002,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7994,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[138],t2,((C_word*)t0)[2]);}

/* f_7994 in k8000 in k7956 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7994,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7981 in k7956 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7983,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7975,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[173],t2);}

/* f_7975 in k7981 in k7956 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7975,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7924 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7924,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7763,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7769,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1131 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7769,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[140]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7778,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7885,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1135 remove */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t4,t5,((C_word*)t0)[2]);}

/* a7884 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7885,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7912,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7913,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7913 in a7884 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7913,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7910 in a7884 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7912,2,t0,t1);}
t2=(C_word)C_eqp(lf[26],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7904,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_7904 in k7910 in a7884 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7904,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7901 in k7910 in a7884 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7778,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1140 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7814,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[6],lf[15],lf[170],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7838,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1148 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[166]))(4,*((C_word*)lf[166]+1),t3,t4,t1);}}}

/* a7839 in k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7840,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[145]),lf[150]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7859,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[138],t5,t6);}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7875,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[87],t5,t6);}}

/* f_7875 in a7839 in k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7875,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7859 in a7839 in k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7859,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7836 in k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7838,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7830,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[171],t2);}

/* f_7830 in k7836 in k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7830,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7814 in k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7814,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7798 in k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7800,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7792,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[169],t2);}

/* f_7792 in k7798 in k7776 in k7767 in k7761 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7792,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7740 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7740,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7676 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7678,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7694,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7702,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7719,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7718 in k7676 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7719,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7731,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1119 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t4,t5);}

/* k7729 in a7718 in k7676 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1118 append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[12]+1)))(5,*((C_word*)lf[12]+1),((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7708 in k7676 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7709,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1117 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t1,((C_word*)t0)[2],t2);}

/* k7700 in k7676 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7703,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[138],((C_word*)t0)[2],t1);}

/* f_7703 in k7700 in k7676 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7703,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7692 in k7676 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7694,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7686,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[168],t2);}

/* f_7686 in k7692 in k7676 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7686,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7641 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7641,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7496,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[140]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7505,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7602,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1086 remove */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7601 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7602,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7629,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7630,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7630 in a7601 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7630,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7627 in a7601 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7629,2,t0,t1);}
t2=(C_word)C_eqp(lf[26],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7621,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_7621 in k7627 in a7601 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7621(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7621,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7618 in k7627 in a7601 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k7503 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7505,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7527,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1091 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7541,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],lf[15],lf[164],t4);}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[145]),lf[150]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7574,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1099 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[166]))(4,*((C_word*)lf[166]+1),t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a7575 in k7503 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7576,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7589,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[138],t4,t5);}

/* f_7589 in a7575 in k7503 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7589,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7572 in k7503 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7574,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7566,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[165],t2);}

/* f_7566 in k7572 in k7503 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7566,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7541 in k7503 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7541,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7525 in k7503 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7527,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7519,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[163],t2);}

/* f_7519 in k7525 in k7503 in k7494 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7519(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7519,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7477 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7477,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7454 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7456,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1073 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7470 in k7454 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7472,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7464,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[162],t2);}

/* f_7464 in k7470 in k7454 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7464,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7423 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7423,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7375 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7377,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7393,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7409,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[140]))){
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=t3;
f_7409(t5,(C_word)C_i_pairp(t4));}
else{
t4=t3;
f_7409(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7407 in k7375 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_7409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7409,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[4]):(C_word)C_i_cadr(((C_word*)t0)[4]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7398,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[138],t3,((C_word*)t0)[2]);}

/* f_7398 in k7407 in k7375 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7398,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7391 in k7375 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7393,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7385,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[161],t2);}

/* f_7385 in k7391 in k7375 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7385,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7349 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7349,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7285 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7287,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[140]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7312,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[7]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7329,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t7)){
t8=t6;
f_7329(t8,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=t6;
f_7329(t9,(C_word)C_fixnum_times(((C_word*)t0)[2],t8));}
else{
t8=t6;
f_7329(t8,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7327 in k7285 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_7329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7329,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7317,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[87],t2,((C_word*)t0)[2]);}

/* f_7317 in k7327 in k7285 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7317,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7310 in k7285 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7312,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7304,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[160],t2);}

/* f_7304 in k7310 in k7285 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7304,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7243 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7243,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7180 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7182,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[145]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7199,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1024 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[145]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7230,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[4],lf[15],lf[159],t6);}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7230 in k7180 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7230,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7206 in k7180 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1024 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[155]))(5,*((C_word*)lf[155]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7197 in k7180 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7200,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_7200 in k7197 in k7180 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7200,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7143 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7143,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7086 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7088,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[145]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[140]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(C_retrieve(lf[140]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7124,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,lf[138],t8,((C_word*)t0)[2]);}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7124 in k7086 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7124,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7117 in k7086 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7119,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7111,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[158],t2);}

/* f_7111 in k7117 in k7086 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7111(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7111,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7063 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7063,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k7009 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7011,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[140]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7030,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_7030(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_7030(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7028 in k7009 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_7030(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7030,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7034,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7048,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[157],t4,C_SCHEME_END_OF_LIST);}

/* f_7048 in k7028 in k7009 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7048,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7041 in k7028 in k7009 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 997  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[155]))(5,*((C_word*)lf[155]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7032 in k7028 in k7009 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7035,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_7035 in k7032 in k7028 in k7009 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7035,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6992 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6992,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6921 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6923,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[140]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6955,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],lf[15],lf[156],t7);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6970,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6979,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 987  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6977 in k6921 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 987  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[155]))(5,*((C_word*)lf[155]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6968 in k6921 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6971,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_6971 in k6968 in k6921 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6971,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6955 in k6921 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6955,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6904 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6904,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6850 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6864(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_6864(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6862 in k6850 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_6864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6864,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6875,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 972  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6882 in k6862 in k6850 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 972  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[155]))(5,*((C_word*)lf[155]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6873 in k6862 in k6850 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6876,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_6876 in k6873 in k6862 in k6850 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6876,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6824 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6824,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6751 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6753,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6782,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 954  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6780 in k6751 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6782,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 957  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,t4);}

/* k6788 in k6780 in k6751 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6794,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 959  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t2,t4);}
else{
t4=t2;
f_6794(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k6792 in k6788 in k6780 in k6751 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6794,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6774,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t2);}

/* f_6774 in k6792 in k6788 in k6780 in k6751 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6774,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6725 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6725,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6579,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 925  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[140]))){
t4=(C_word)C_eqp(C_retrieve(lf[145]),lf[154]);
t5=t3;
f_6607(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6607(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_6607(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6607,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6610(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[145]),lf[150]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_6610(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[145]),lf[153]);
t6=t2;
f_6610(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[3]):C_SCHEME_FALSE));}}}

/* k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_6610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6610,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6688,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6687 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6688,3,t0,t1,t2);}
/* optimizer.scm: 929  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t1);}

/* k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[48]),t1);}

/* k6614 in k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6621,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6642,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_retrieve(lf[145]),lf[150]);
t5=(C_truep(t4)?(C_word)C_i_car(((C_word*)t0)[3]):(C_word)C_i_cadr(((C_word*)t0)[3]));
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6658,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6660,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 941  fold-boolean */
((C_proc4)C_retrieve_symbol_proc(lf[152]))(4,*((C_word*)lf[152]+1),t7,t8,t1);}

/* a6659 in k6614 in k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6660,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6669,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[138],((C_word*)t0)[2],t4);}

/* f_6669 in a6659 in k6614 in k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6669,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6656 in k6614 in k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6658,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6647,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[151],t2);}

/* f_6647 in k6656 in k6614 in k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6647,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6640 in k6614 in k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 931  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[122]))(6,*((C_word*)lf[122]+1),((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6620 in k6614 in k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6621,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6634,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[11],t5,t6);}

/* f_6634 in a6620 in k6614 in k6611 in k6608 in k6605 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6634,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6599 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6601,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6593,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[149],t2);}

/* f_6593 in k6599 in k6577 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6593,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6560 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6560,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6551 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6526 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6526,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6478 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6480,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6496,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6504,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* optimizer.scm: 911  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t6,t7);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6515 in k6478 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6517,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 910  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6502 in k6478 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6505,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[138],((C_word*)t0)[2],t1);}

/* f_6505 in k6502 in k6478 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6505(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6505,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6494 in k6478 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6496,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6488,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[148],t2);}

/* f_6488 in k6494 in k6478 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6488,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6442 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6442,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6389 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6391,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6407,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6424,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6429,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[138],t7,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6429 in k6389 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6429,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6422 in k6389 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6424,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6416,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[138],((C_word*)t0)[2],t2);}

/* f_6416 in k6422 in k6389 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6416,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6405 in k6389 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6407,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6399,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[147],t2);}

/* f_6399 in k6405 in k6389 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6399,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6357 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6357,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6284 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6286,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[145])));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_car(((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(((C_word*)t0)[5]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6341,a[2]=t9,a[3]=t7,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 887  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t11,t12);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6339 in k6284 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6341,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6329,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[138],((C_word*)t0)[2],t2);}

/* f_6329 in k6339 in k6284 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6329,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6318 in k6284 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6312,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[146],t2);}

/* f_6312 in k6318 in k6284 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6312,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6263 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6263,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6216 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6218,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6238,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 869  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6236 in k6216 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6238,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 872  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,t4);}

/* k6244 in k6236 in k6216 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6246,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6230,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t3);}

/* f_6230 in k6244 in k6236 in k6216 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6230,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6190 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6190,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6167 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6169,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 860  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6183 in k6167 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6185,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6177,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[144],t2);}

/* f_6177 in k6183 in k6167 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6177,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6136 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6136,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6038,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[140]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6072,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6130,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6131,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}
else{
t8=t7;
f_6072(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6131 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6131,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6128 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6130,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6113,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6122,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_6072(t3,C_SCHEME_FALSE);}}

/* f_6122 in k6128 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6122,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6119 in k6128 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 851  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,lf[143]);}

/* k6111 in k6128 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6072(t2,(C_word)C_eqp(lf[142],t1));}

/* k6070 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_6072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6072,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6080,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[138],t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6092,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],lf[138],t3,((C_word*)t0)[3]);}}

/* f_6092 in k6070 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6092,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6080 in k6070 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6080,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6067 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6069,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6061,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[141],t2);}

/* f_6061 in k6067 in k6036 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6061,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6013 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6013,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5887,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5999,a[2]=t6,a[3]=t7,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6000,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t6=t2;
f_5890(2,t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6000 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6000,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5999,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5991,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[4];
f_5890(2,t3,C_SCHEME_FALSE);}}

/* f_5991 in k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5991,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5988 in k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5990,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5972,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5982,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_5890(2,t3,C_SCHEME_FALSE);}}

/* f_5982 in k5988 in k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5982,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5970 in k5988 in k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5977,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_5977 in k5970 in k5988 in k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5977,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5974 in k5970 in k5988 in k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5976,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[4],t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 830  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_5890(2,t2,C_SCHEME_FALSE);}}

/* k5966 in k5974 in k5970 in k5988 in k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5968,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5960,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[139],t2);}

/* f_5960 in k5966 in k5974 in k5970 in k5988 in k5997 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5960,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5888 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5890,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[136]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5912,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5917,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[138],t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* f_5917 in k5888 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5917,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5910 in k5888 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5912,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5904,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[137],t2);}

/* f_5904 in k5910 in k5888 in k5885 in ##compiler#simplify-named-call in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5904,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* ##compiler#rewrite in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5810r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5810r(t0,t1,t2,t3);}}

static void C_ccall f_5810r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5814,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 808  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t4,C_retrieve(lf[133]),t2);}

/* k5812 in ##compiler#rewrite in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5814,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 809  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,t2,t4);}

/* k5822 in k5812 in ##compiler#rewrite in k5806 in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 809  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[119]))(5,*((C_word*)lf[119]+1),((C_word*)t0)[3],C_retrieve(lf[133]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5450,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5454,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 720  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[131]+1)))(5,*((C_word*)lf[131]+1),t7,*((C_word*)lf[132]+1),t2,t3);}

/* k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5456,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5501,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 731  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5794 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5795,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5800,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 732  scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t5,t3,((C_word*)t0)[2]);}

/* k5802 in a5794 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 732  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5798 in a5794 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5501,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a5736 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5737,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5747,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5769,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 741  filter */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t3,t4,((C_word*)t0)[2]);}}

/* a5768 in a5736 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5769,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5782,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 742  find-path */
t5=((C_word*)t0)[2];
f_5456(t5,t4,((C_word*)t0)[3],t2);}}

/* k5780 in a5768 in a5736 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 742  find-path */
t2=((C_word*)t0)[5];
f_5456(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5745 in a5736 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5751,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5763,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 744  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t3);}

/* k5761 in k5745 in a5736 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5763,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 744  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k5749 in k5745 in a5736 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5751,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5755,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 745  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[12]+1)))(5,*((C_word*)lf[12]+1),t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k5753 in k5749 in k5745 in a5736 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5504,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5507,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a5677 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5678,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5685,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 754  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t4,t5,t6);}

/* a5720 in a5677 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5721,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5727,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 755  filter */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t1,t3,((C_word*)t0)[2]);}

/* a5726 in a5720 in a5677 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5727,3,t0,t1,t2);}
/* optimizer.scm: 755  find-path */
t3=((C_word*)t0)[3];
f_5456(t3,t1,((C_word*)t0)[2],t2);}

/* k5683 in a5677 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5689,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5693,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5695,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 760  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a5694 in k5683 in a5677 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5695,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5708,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 761  lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t4,*((C_word*)lf[35]+1),t5,((C_word*)t0)[2]);}}

/* k5706 in a5694 in k5683 in a5677 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k5691 in k5683 in a5677 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 758  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5687 in k5683 in a5677 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 767  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[124]))(4,*((C_word*)lf[124]+1),t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[35]+1));}

/* k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 772  fold */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t4,t5,((C_word*)t0)[2],t1);}

/* a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5530,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5543,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_5543(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_5543(t9,C_SCHEME_FALSE);}}

/* k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5543,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5555,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5572,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5602,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5604,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 786  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5603 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5604,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5650,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 789  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t4);}

/* k5648 in a5603 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5650,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5625,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t5=(C_word)C_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5634,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t3,lf[16],t4,t7);}

/* f_5634 in k5648 in a5603 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5634,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5623 in k5648 in a5603 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5617,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_5617 in k5623 in k5648 in a5603 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5617,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5600 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 781  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5571 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5572,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5593,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5594,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_5594 in a5571 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5594,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5591 in a5571 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5593,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5585,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_5585 in k5591 in a5571 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5585,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_5555 in k5541 in a5529 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5555,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5511 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5522,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 798  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[121],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 800  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k5520 in k5511 in k5508 in k5505 in k5502 in k5499 in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 799  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5456(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5456,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5462,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5462(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5462(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5462,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5486,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 728  any */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t1,t8,t5);}}}

/* a5485 in find in find-path in k5452 in ##compiler#reorganize-recursive-bindings in k5446 in k5443 in k5440 in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5486,3,t0,t1,t2);}
/* optimizer.scm: 728  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5462(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_5435r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5435r(t0,t1,t2,t3);}}

static void C_ccall f_5435r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 499  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[119]))(5,*((C_word*)lf[119]+1),t1,C_retrieve(lf[22]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5138,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5141,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5145,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5152,a[2]=t9,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 451  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t10,lf[20],lf[117]);}

/* k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5167,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5429,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[115]);}

/* f_5429 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5429,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5167,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5425,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 490  test */
t4=((C_word*)t0)[3];
f_5145(t4,t3,lf[115],lf[116]);}
else{
t2=((C_word*)t0)[2];
f_5155(2,t2,C_SCHEME_UNDEFINED);}}

/* k5423 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5172,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5417,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_5417 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5417,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cadr(t1);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5412,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* f_5412 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5412,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5185,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5403,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 460  test */
t5=((C_word*)t0)[2];
f_5145(t5,t4,t2,lf[75]);}

/* k5401 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5185(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 460  test */
t2=((C_word*)t0)[3];
f_5145(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[46]);}}

/* k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5188,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 461  test */
t3=((C_word*)t0)[3];
f_5145(t3,t2,((C_word*)t0)[2],lf[74]);}

/* k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[5]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5380,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5381,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}
else{
t7=t2;
f_5194(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5194(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5194(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5194(t3,C_SCHEME_FALSE);}}

/* f_5381 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5381,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5378 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5194(t2,(C_word)C_eqp(lf[54],t1));}

/* k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5194,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5354,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5354 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5354,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5353,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5344,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5345,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_5345 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5345,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5344,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5336,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_5336 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5336,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=t2;
f_5209(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_5209(t3,C_SCHEME_FALSE);}}

/* k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5209,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5215,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 472  test */
t4=((C_word*)t0)[2];
f_5145(t4,t3,t2,lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5316,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5317,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t2;
f_5221(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5221(t3,C_SCHEME_FALSE);}}

/* f_5317 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5317,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5314 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5221(t2,(C_word)C_eqp(lf[10],t1));}

/* k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5221,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5299,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5299 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5299,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5298,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5289,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5290,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_5290 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5290,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5287 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5289,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5281,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_5230(t3,C_SCHEME_FALSE);}}

/* f_5281 in k5287 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5281,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5278 in k5287 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
f_5230(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k5228 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5230,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 484  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t4,((C_word*)t0)[2],lf[114]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5235 in k5228 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5240,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 485  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),t2,((C_word*)t0)[2],t3);}

/* k5238 in k5235 in k5228 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5258,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 488  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t4,t5);}

/* k5256 in k5238 in k5235 in k5228 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5258,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 486  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5241 in k5238 in k5235 in k5228 in k5296 in k5219 in k5213 in k5207 in k5201 in k5342 in k5351 in k5192 in k5186 in k5183 in k5405 in k5177 in a5171 in k5165 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 489  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5141(((C_word*)t0)[2]));}

/* k5153 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 492  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[110],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5158(2,t4,C_SCHEME_UNDEFINED);}}

/* k5156 in k5153 in k5150 in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5145(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5145,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 449  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static C_word C_fcall f_5141(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[69],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3438,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3441,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3447,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3462,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3477,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3481,a[2]=t3,a[3]=t21,a[4]=t19,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3578,a[2]=t26,a[3]=t17,a[4]=t18,a[5]=t24,a[6]=t19,a[7]=t7,a[8]=t21,a[9]=t15,tmp=(C_word)a,a+=10,tmp));
t30=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3825,a[2]=t11,a[3]=t3,a[4]=t28,a[5]=t24,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t19,tmp=(C_word)a,a+=10,tmp));
t31=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5018,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5042,a[2]=t24,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 417  perform-pre-optimization! */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t32,t2,t3);}

/* k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5042,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 418  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5048,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 420  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[108]);}}

/* k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5048,2,t0,t1);}
t2=C_set_block_item(lf[23] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5052,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 422  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3578(3,t4,t3,((C_word*)t0)[2]);}

/* k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 423  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[107],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5055(2,t3,C_SCHEME_UNDEFINED);}}

/* k5053 in k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5091,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[23])))){
/* optimizer.scm: 424  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,lf[7],lf[106]);}
else{
t4=t3;
f_5091(2,t4,C_SCHEME_FALSE);}}

/* k5089 in k5053 in k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5091,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5096,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[23]));}
else{
t2=((C_word*)t0)[2];
f_5058(2,t2,C_SCHEME_UNDEFINED);}}

/* a5095 in k5089 in k5053 in k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5096,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5100,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 427  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[105]+1)))(4,*((C_word*)lf[105]+1),t3,C_make_character(9),t4);}

/* k5098 in a5095 in k5089 in k5053 in k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 429  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[103]+1)))(4,*((C_word*)lf[103]+1),((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 430  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[104]+1)))(2,*((C_word*)lf[104]+1),((C_word*)t0)[2]);}}

/* k5056 in k5053 in k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 432  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[102],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5061(2,t4,C_SCHEME_UNDEFINED);}}

/* k5059 in k5056 in k5053 in k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 433  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[101],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5064(2,t4,C_SCHEME_UNDEFINED);}}

/* k5062 in k5059 in k5056 in k5053 in k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 434  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[100],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5067(2,t4,C_SCHEME_UNDEFINED);}}

/* k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in k5046 in k5040 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 435  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_5018(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5018,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5022,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k5020 in walk-generic in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5028,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 413  every */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t2,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1);}

/* k5026 in k5020 in walk-generic in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5028,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5032,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_5032 in k5026 in k5020 in walk-generic in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5032,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3825(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3825,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3829,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5012,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_5012 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5012,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5007,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_5007 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5007,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5002,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_5002 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5002,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3835,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3850,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3850(t7,((C_word*)t0)[9],t3);}
else{
t3=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3931,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 238  test */
t6=((C_word*)t0)[11];
f_3441(t6,t5,t4,lf[50]);}
else{
t4=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3994,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[13]);
/* optimizer.scm: 248  test */
t8=((C_word*)t0)[11];
f_3441(t8,t6,t7,lf[63]);}
else{
t5=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[13],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4884,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t6=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[13]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[13],a[7]=t7,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 397  test */
t9=((C_word*)t0)[11];
f_3441(t9,t8,t7,lf[52]);}
else{
/* optimizer.scm: 409  walk-generic */
t7=((C_word*)((C_word*)t0)[5])[1];
f_5018(t7,((C_word*)t0)[9],((C_word*)t0)[4],t1,((C_word*)t0)[13],((C_word*)t0)[7]);}}}}}}

/* k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_4906(2,t3,t1);}
else{
/* optimizer.scm: 397  test */
t3=((C_word*)t0)[2];
f_3441(t3,t2,((C_word*)t0)[7],lf[50]);}}

/* k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4906,2,t0,t1);}
if(C_truep(t1)){
t2=f_3477(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4913,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 400  test */
t4=((C_word*)t0)[2];
f_3441(t4,t3,((C_word*)t0)[7],lf[99]);}}

/* k4993 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_4963(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4991,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 401  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[98]))(3,*((C_word*)lf[98]+1),t4,((C_word*)t0)[2]);}}

/* k4989 in k4993 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4963(t2,(C_word)C_i_not(t1));}

/* k4961 in k4993 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_4963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4963,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 402  test */
t3=((C_word*)t0)[3];
f_3441(t3,t2,((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[6];
f_4923(t2,C_SCHEME_FALSE);}}

/* k4982 in k4961 in k4993 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4984,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4923(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 403  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t2,t3,((C_word*)t0)[2]);}}

/* k4974 in k4982 in k4961 in k4993 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4923(t2,(C_word)C_i_not(t1));}

/* k4921 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_4923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4923,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3477(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 405  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t3,lf[7],lf[97],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4953,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 407  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3578(3,t4,t2,t3);}}

/* k4951 in k4921 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4953,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4945,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[16],((C_word*)t0)[2],t2);}

/* f_4945 in k4951 in k4921 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4945,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4927 in k4921 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4933,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_4933 in k4927 in k4921 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4933,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_4913 in k4904 in k4901 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4913,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_4884 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4884,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4841,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t3)){
if(C_truep((C_word)C_i_car(((C_word*)t0)[6]))){
/* optimizer.scm: 391  walk-generic */
t4=((C_word*)((C_word*)t0)[9])[1];
f_5018(t4,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[13]);}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4871,a[2]=t5,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[13]);}}
else{
/* optimizer.scm: 393  walk-generic */
t4=((C_word*)((C_word*)t0)[9])[1];
f_5018(t4,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[13]);}}}

/* k4869 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4872,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_4872 in k4869 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4872,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_4841 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4841,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 286  test */
t5=((C_word*)t0)[4];
f_3441(t5,t4,t2,lf[75]);}

/* k4834 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4184(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 287  test */
t3=((C_word*)t0)[3];
f_3441(t3,t2,((C_word*)t0)[2],lf[46]);}}

/* k4824 in k4834 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4184(2,t2,t1);}
else{
/* optimizer.scm: 288  test */
t2=((C_word*)t0)[3];
f_3441(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[96]);}}

/* k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t1,a[13]=t2,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word*)t0)[13],tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm: 290  test */
t4=((C_word*)t0)[4];
f_3441(t4,t3,((C_word*)t0)[10],lf[52]);}

/* k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4193,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4196,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4229,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[67])))){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4393,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t4=t3;
f_4245(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[12])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4815,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4816,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}
else{
t3=t2;
f_4403(t3,C_SCHEME_FALSE);}}}}

/* f_4816 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4816,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4813 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4403(t2,(C_word)C_eqp(lf[54],t1));}

/* k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_4403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4403,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4801,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 388  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_5018(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* f_4801 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4801,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t2,a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 317  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t2,t3);}

/* a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4414,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[89]))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[17],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 322  test */
t8=((C_word*)t0)[3];
f_3441(t8,t7,t5,lf[95]);}
else{
t7=t6;
f_4424(t7,C_SCHEME_FALSE);}}

/* k4765 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 323  test */
t3=((C_word*)t0)[2];
f_3441(t3,t2,((C_word*)t0)[3],lf[94]);}
else{
t2=((C_word*)t0)[5];
f_4424(t2,C_SCHEME_FALSE);}}

/* k4771 in k4765 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4796,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[93]);}
else{
t2=((C_word*)t0)[4];
f_4424(t2,C_SCHEME_FALSE);}}

/* f_4796 in k4771 in k4765 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4796,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,t3);}

/* k4774 in k4771 in k4765 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(t1,lf[90]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4424(t3,C_SCHEME_TRUE);}
else{
t3=(C_word)C_eqp(t1,lf[91]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4424(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[92]);
t6=((C_word*)t0)[3];
f_4424(t6,(C_word)C_fixnum_lessp(t4,t5));}}}

/* k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_4424(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4424,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4467,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],a[4]=t2,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4471,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4477,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[15],lf[80]);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[17],tmp=(C_word)a,a+=20,tmp);
/* optimizer.scm: 339  test */
t3=((C_word*)t0)[4];
f_3441(t3,t2,((C_word*)t0)[13],lf[63]);}}

/* k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 341  walk-generic */
t4=((C_word*)((C_word*)t0)[17])[1];
f_5018(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4501,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4501(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[4],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4754,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 363  test */
t4=((C_word*)t0)[6];
f_3441(t4,t3,((C_word*)t0)[2],lf[59]);}}

/* k4752 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_4659(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_4659(t2,C_SCHEME_FALSE);}}

/* k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_4659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4659,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[13]);
t3=(C_word)C_i_length(((C_word*)t0)[12]);
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* optimizer.scm: 367  walk-generic */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5018(t4,((C_word*)t0)[10],t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 369  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[6]))(6,*((C_word*)lf[6]+1),t4,lf[7],lf[88],((C_word*)t0)[3],t2);}}
else{
/* optimizer.scm: 387  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_5018(t2,((C_word*)t0)[10],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4684 in k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4685,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4689,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4718,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 380  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t7,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_length(t3);
t9=(C_word)C_fixnum_times(C_fix(3),t8);
t10=(C_word)C_a_i_list(&a,2,lf[86],t9);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4732,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,lf[87],t10,t3);}}

/* f_4732 in a4684 in k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4732,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4716 in a4684 in k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 376  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4708 in a4684 in k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4695 in a4684 in k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4698,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_4698 in k4695 in a4684 in k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4698,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4687 in a4684 in k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a4678 in k4672 in k4657 in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4679,2,t0,t1);}
/* optimizer.scm: 370  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_4501(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4501,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_3477(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 348  append-reverse */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 349  test */
t10=((C_word*)t0)[2];
f_3441(t10,t8,t9,lf[55]);}}

/* k4538 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4540,2,t0,t1);}
if(C_truep(t1)){
t2=f_3477(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 351  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[6]))(6,*((C_word*)lf[6]+1),t3,lf[7],lf[84],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 359  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_4501(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k4544 in k4538 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 352  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t2,t3,((C_word*)t0)[2]);}

/* k4550 in k4544 in k4538 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4552,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 355  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t2,lf[83]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 358  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4501(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k4594 in k4550 in k4544 in k4538 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 356  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3578(3,t5,t3,t4);}

/* k4570 in k4594 in k4550 in k4544 in k4538 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 357  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4501(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4574 in k4570 in k4594 in k4550 in k4544 in k4538 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4564,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_4564 in k4574 in k4570 in k4594 in k4550 in k4544 in k4538 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4564,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4532 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4534,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4519 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4522,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_4522 in k4519 in loop in k4485 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4522,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_4477 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4477,4,t0,t1,t2,t3);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,t3);}

/* k4469 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4472,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4472 in k4469 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4472,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[36]));}

/* k4465 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?lf[77]:lf[78]);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* optimizer.scm: 329  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[6]))(7,*((C_word*)lf[6]+1),((C_word*)t0)[4],lf[79],t2,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4425 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 335  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[66]))(5,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4428 in k4425 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 336  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[76],((C_word*)t0)[2]);}

/* k4431 in k4428 in k4425 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=f_3477(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4452,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_4452 in k4431 in k4428 in k4425 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4452,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k4449 in k4431 in k4428 in k4425 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 338  inline-lambda-bindings */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k4441 in k4431 in k4428 in k4425 in k4422 in a4413 in k4404 in k4401 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 338  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3578(3,t2,((C_word*)t0)[2],t1);}

/* f_4393 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4393,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4384,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
f_4245(2,t3,C_SCHEME_FALSE);}}

/* f_4384 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4384,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4379,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 301  test */
t5=((C_word*)t0)[2];
f_3441(t5,t4,t2,lf[75]);}
else{
t3=((C_word*)t0)[7];
f_4245(2,t3,C_SCHEME_FALSE);}}

/* k4377 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4266(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 301  test */
t2=((C_word*)t0)[3];
f_3441(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[46]);}}

/* k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4266,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4365,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[7];
f_4245(2,t2,C_SCHEME_FALSE);}}

/* f_4365 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4365,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4284,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 304  test */
t5=((C_word*)t0)[2];
f_3441(t5,t3,t4,lf[55]);}
else{
t3=((C_word*)t0)[7];
f_4245(2,t3,C_SCHEME_FALSE);}}

/* k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4287,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4287(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 305  test */
t5=((C_word*)t0)[2];
f_3441(t5,t3,t4,lf[74]);}}

/* k4350 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4287(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 306  test */
t4=((C_word*)t0)[2];
f_3441(t4,t2,t3,lf[73]);}}

/* k4342 in k4350 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4287(t2,(C_word)C_i_not(t1));}

/* k4285 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_4287(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4287,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4321,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 307  any */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_4245(2,t2,C_SCHEME_FALSE);}}

/* a4322 in k4285 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4323,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t1,t2,((C_word*)t0)[2]);}

/* k4319 in k4285 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4321,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4245(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 308  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[70],lf[71],((C_word*)t0)[2]);}}

/* k4294 in k4319 in k4285 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4313,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_4313 in k4294 in k4319 in k4285 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4313,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4310 in k4294 in k4319 in k4285 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4304,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[68],t2);}

/* f_4304 in k4310 in k4294 in k4319 in k4285 in k4282 in k4362 in k4264 in k4381 in k4390 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4304,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4243 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 312  walk-generic */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5018(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_4229 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4229,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4194 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4196,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 293  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[66]))(5,*((C_word*)lf[66]+1),t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k4200 in k4194 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4205,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 294  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[65],((C_word*)t0)[2]);}

/* k4203 in k4200 in k4194 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4205,2,t0,t1);}
t2=f_3477(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4224,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_4224 in k4203 in k4200 in k4194 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4224,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k4221 in k4203 in k4200 in k4194 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 296  inline-lambda-bindings */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4213 in k4203 in k4200 in k4194 in k4191 in k4182 in k4838 in k4170 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 296  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3578(3,t2,((C_word*)t0)[2],t1);}

/* k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 249  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 264  test */
t4=((C_word*)t0)[11];
f_3441(t4,t2,t3,lf[59]);}}

/* k4091 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4093,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4098,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 265  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
/* optimizer.scm: 277  walk-generic */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5018(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a4097 in k4091 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4098,5,t0,t1,t2,t3,t4);}
t5=f_3477(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4105,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 269  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t6,lf[7],lf[62],t4);}

/* k4103 in a4097 in k4091 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 274  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4139 in k4103 in a4097 in k4091 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4141,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4125,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 276  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3578(3,t6,t4,t5);}

/* k4123 in k4139 in k4103 in a4097 in k4091 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4125,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4117,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[54],((C_word*)t0)[2],t2);}

/* f_4117 in k4123 in k4139 in k4103 in a4097 in k4091 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4117,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3999,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4005,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4016 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4017,4,t0,t1,t2,t3);}
t4=f_3477(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 254  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t5,lf[7],lf[60],t2);}

/* k4022 in a4016 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 258  test */
t7=((C_word*)t0)[2];
f_3441(t7,t5,t6,lf[59]);}
else{
t6=t5;
f_4067(2,t6,C_SCHEME_FALSE);}}

/* k4065 in k4022 in a4016 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 259  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[58],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 261  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4068 in k4065 in k4022 in a4016 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 260  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4058 in k4022 in a4016 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4044,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 263  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3578(3,t6,t4,t5);}

/* k4042 in k4058 in k4022 in a4016 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4036,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[54],((C_word*)t0)[2],t2);}

/* f_4036 in k4042 in k4058 in k4022 in a4016 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4036,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a4004 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4011,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 252  partition */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t1,t2,((C_word*)t0)[2]);}

/* a4010 in a4004 in a3998 in k3992 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4011,3,t0,t1,t2);}
/* optimizer.scm: 252  test */
t3=((C_word*)t0)[2];
f_3441(t3,t1,t2,lf[55]);}

/* k3929 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_3934(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 239  test */
t4=((C_word*)t0)[3];
f_3441(t4,t3,((C_word*)t0)[2],lf[53]);}}

/* k3961 in k3929 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3934(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 240  test */
t3=((C_word*)t0)[3];
f_3441(t3,t2,((C_word*)t0)[2],lf[52]);}}

/* k3970 in k3961 in k3929 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 240  test */
t3=((C_word*)t0)[3];
f_3441(t3,t2,((C_word*)t0)[2],lf[51]);}
else{
t2=((C_word*)t0)[4];
f_3934(t2,C_SCHEME_FALSE);}}

/* k3977 in k3970 in k3961 in k3929 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3934(t2,(C_word)C_i_not(t1));}

/* k3932 in k3929 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3934(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3934,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3477(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 243  walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3578(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k3953 in k3932 in k3929 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3956,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t1);}

/* f_3956 in k3953 in k3932 in k3929 in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3956,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* replace in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3850,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 224  test */
t4=((C_word*)t0)[4];
f_3441(t4,t3,t2,lf[50]);}

/* k3852 in replace in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3854,2,t0,t1);}
if(C_truep(t1)){
/* replace318 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3850(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 225  test */
t3=((C_word*)t0)[5];
f_3441(t3,t2,((C_word*)t0)[4],lf[49]);}}

/* k3864 in k3852 in replace in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
if(C_truep(t1)){
t2=f_3477(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 227  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t3,lf[7],lf[47],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_3895(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_3477(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_3895(t8,t7);}}}

/* k3893 in k3864 in k3852 in replace in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 234  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3870 in k3864 in k3852 in replace in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3883,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3887,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 228  test */
t4=((C_word*)t0)[3];
f_3441(t4,t3,((C_word*)t0)[2],lf[46]);}

/* k3885 in k3870 in k3864 in k3852 in replace in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3888,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3888 in k3885 in k3870 in k3864 in k3852 in replace in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3888,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3881 in k3870 in k3864 in k3852 in replace in k3833 in k3830 in k3827 in walk1 in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 228  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2);}

/* walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3578,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[33])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[9])[1];
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 178  walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3825(t5,t4,t2);}}

/* k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3819,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f_3819 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3819(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3819,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3814,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_3814 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3814,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3601,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(t1,lf[10]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 183  constant-node? */
t6=((C_word*)t0)[4];
f_3447(3,t6,t4,t5);}
else{
t4=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3809,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t2;
f_3601(2,t5,((C_word*)t0)[5]);}}}

/* f_3809 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3809,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3804,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3796,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)t0)[9];
f_3601(2,t3,((C_word*)t0)[8]);}}

/* f_3796 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3796,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3791,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3769,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3783,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3783 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3783,3,t0,t1,t2);}
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t1,t2,lf[45]);}

/* k3767 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 195  foldable? */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3662(2,t2,C_SCHEME_FALSE);}}

/* k3773 in k3767 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 196  every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_3662(2,t2,C_SCHEME_FALSE);}}

/* k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[8];
f_3601(2,t2,((C_word*)t0)[7]);}}

/* a3749 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3750,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 197  node-value */
f_3462(t3,t2);}

/* k3760 in a3749 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3762,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[26],t2));}

/* k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3673,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,t4);}

/* a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3673,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3679,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3696,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t3,t4);}

/* a3695 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3702,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3733 in a3695 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3734r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3734r(t0,t1,t2);}}

static void C_ccall f_3734r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3740,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k271277 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3739 in a3733 in a3695 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3740,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3701 in a3695 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 204  eval */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}

/* k3704 in a3701 in a3695 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3709,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 205  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[39],((C_word*)t0)[2]);}

/* k3707 in k3704 in a3701 in a3695 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=f_3477(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3732,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 210  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t4,((C_word*)t0)[2]);}

/* k3730 in k3707 in k3704 in a3701 in a3695 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3732,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3720,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[37],t2);}

/* f_3720 in k3730 in k3707 in k3704 in a3701 in a3695 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3720,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a3678 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3679,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* k271277 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3684 in a3678 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3689(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_3689(t4,t3);}}

/* k3687 in a3684 in a3678 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3689,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 202  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[34]))(5,*((C_word*)lf[34]+1),t2,*((C_word*)lf[35]+1),C_retrieve(lf[33]),((C_word*)t0)[2]);}

/* k3691 in k3687 in a3684 in a3678 in a3672 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1 /* (set! broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k3669 in k3746 in k3660 in k3789 in k3802 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3608 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3610,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=f_3477(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 186  node-value */
f_3462(t5,t6);}
else{
t2=((C_word*)t0)[4];
f_3601(2,t2,((C_word*)t0)[2]);}}

/* k3625 in k3608 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_caddr(((C_word*)t0)[4]));
/* optimizer.scm: 186  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3578(3,t3,((C_word*)t0)[2],t2);}

/* k3599 in k3596 in k3593 in k3590 in walk in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 176  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3481(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3481(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3481,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3485,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3572,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3572 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3572,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3569 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 157  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),((C_word*)t0)[2],C_retrieve(lf[22]),t1);}

/* k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 158  any */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t2,t3,t1);}
else{
t3=t2;
f_3488(2,t3,C_SCHEME_FALSE);}}

/* a3495 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3496,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3506,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 160  match-node */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3504 in a3495 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3506,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3512,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3555,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3554 in k3504 in a3495 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3555,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k3551 in k3504 in a3495 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3510 in k3504 in a3495 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3518,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 163  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[28]+1)))(3,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3516 in k3510 in k3504 in a3495 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3518,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_3524(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3545,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 167  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k3543 in k3516 in k3510 in k3504 in a3495 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3524(t3,t2);}

/* k3522 in k3516 in k3510 in k3504 in a3495 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3477(((C_word*)t0)[5]);
/* optimizer.scm: 169  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3481(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3486 in k3483 in simplify in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static C_word C_fcall f_3477(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* node-value in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3462(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3462,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3470,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3471,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3471 in node-value in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3471,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3468 in node-value in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* constant-node? in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3447,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3455,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3456,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3456 in constant-node? in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3456,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3453 in constant-node? in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(lf[26],t1));}

/* test in ##compiler#perform-high-level-optimizations in k3433 in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3441(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3441,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 151  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3185,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3188,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3206,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 83   debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t8,lf[20],lf[21]);}

/* k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 84   call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t2,t3);}

/* a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3250,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3253,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3265,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 119  scan */
t9=((C_word*)t6)[1];
f_3265(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3265,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3269,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3424,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3424 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3424,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3419,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3419 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3419,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3414,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3414 in k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3414,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3273 in k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[8]))){
t5=t4;
f_3290(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_memq(t3,((C_word*)((C_word*)t0)[7])[1]);
t6=t4;
f_3290(t6,(C_word)C_i_not(t5));}}
else{
t3=(C_word)C_eqp(t1,lf[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t3)){
t5=t4;
f_3317(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[17]);
t6=t4;
f_3317(t6,(C_truep(t5)?t5:(C_word)C_eqp(t1,lf[18])));}}}

/* k3315 in k3273 in k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3317,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 101  scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3265(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 105  scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3265(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[13]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[14]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[15]);
if(C_truep(t5)){
/* optimizer.scm: 110  return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[16]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))){
t9=t8;
f_3381(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 114  mark */
t9=((C_word*)t0)[3];
f_3188(3,t9,t8,t7);}}
else{
/* optimizer.scm: 117  scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3253(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k3379 in k3315 in k3273 in k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 115  scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3265(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3334 in k3315 in k3273 in k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3336,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3347,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 106  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3345 in k3334 in k3315 in k3273 in k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 106  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3265(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3318 in k3315 in k3273 in k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 102  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3288 in k3273 in k3270 in k3267 in scan in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3290,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3253,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3259,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3258 in scan-each in a3249 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3259,3,t0,t1,t2);}
/* optimizer.scm: 88   scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3265(t3,t1,t2,((C_word*)t0)[2]);}

/* k3207 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 120  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[8],((C_word*)((C_word*)t0)[2])[1]);}

/* k3210 in k3207 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a3216 in k3210 in k3207 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3217,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[4]);}

/* f_3222 in a3216 in k3210 in k3207 in k3204 in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3222r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3222r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3226(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3226(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[3],t4);}}}

/* k3224 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* mark in ##compiler#scan-toplevel-assignments in k3181 in k3178 in k3175 in k3172 in k3169 in k3166 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3188,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[965] = {
{"toplevel:optimizer_scm",(void*)C_optimizer_toplevel},
{"f_3168:optimizer_scm",(void*)f_3168},
{"f_3171:optimizer_scm",(void*)f_3171},
{"f_3174:optimizer_scm",(void*)f_3174},
{"f_3177:optimizer_scm",(void*)f_3177},
{"f_3180:optimizer_scm",(void*)f_3180},
{"f_3183:optimizer_scm",(void*)f_3183},
{"f_3435:optimizer_scm",(void*)f_3435},
{"f_12713:optimizer_scm",(void*)f_12713},
{"f_12721:optimizer_scm",(void*)f_12721},
{"f_12726:optimizer_scm",(void*)f_12726},
{"f_12771:optimizer_scm",(void*)f_12771},
{"f_12775:optimizer_scm",(void*)f_12775},
{"f_12736:optimizer_scm",(void*)f_12736},
{"f_12760:optimizer_scm",(void*)f_12760},
{"f_12745:optimizer_scm",(void*)f_12745},
{"f_5442:optimizer_scm",(void*)f_5442},
{"f_11664:optimizer_scm",(void*)f_11664},
{"f_11710:optimizer_scm",(void*)f_11710},
{"f_11698:optimizer_scm",(void*)f_11698},
{"f_11693:optimizer_scm",(void*)f_11693},
{"f_11685:optimizer_scm",(void*)f_11685},
{"f_11812:optimizer_scm",(void*)f_11812},
{"f_11822:optimizer_scm",(void*)f_11822},
{"f_12121:optimizer_scm",(void*)f_12121},
{"f_11826:optimizer_scm",(void*)f_11826},
{"f_12116:optimizer_scm",(void*)f_12116},
{"f_11829:optimizer_scm",(void*)f_11829},
{"f_12111:optimizer_scm",(void*)f_12111},
{"f_11832:optimizer_scm",(void*)f_11832},
{"f_12102:optimizer_scm",(void*)f_12102},
{"f_11850:optimizer_scm",(void*)f_11850},
{"f_12097:optimizer_scm",(void*)f_12097},
{"f_11853:optimizer_scm",(void*)f_11853},
{"f_12092:optimizer_scm",(void*)f_12092},
{"f_11856:optimizer_scm",(void*)f_11856},
{"f_11886:optimizer_scm",(void*)f_11886},
{"f_11915:optimizer_scm",(void*)f_11915},
{"f_12075:optimizer_scm",(void*)f_12075},
{"f_11919:optimizer_scm",(void*)f_11919},
{"f_12070:optimizer_scm",(void*)f_12070},
{"f_11922:optimizer_scm",(void*)f_11922},
{"f_12065:optimizer_scm",(void*)f_12065},
{"f_11925:optimizer_scm",(void*)f_11925},
{"f_12056:optimizer_scm",(void*)f_12056},
{"f_12048:optimizer_scm",(void*)f_12048},
{"f_12043:optimizer_scm",(void*)f_12043},
{"f_12035:optimizer_scm",(void*)f_12035},
{"f_12030:optimizer_scm",(void*)f_12030},
{"f_11931:optimizer_scm",(void*)f_11931},
{"f_11984:optimizer_scm",(void*)f_11984},
{"f_11974:optimizer_scm",(void*)f_11974},
{"f_11982:optimizer_scm",(void*)f_11982},
{"f_11959:optimizer_scm",(void*)f_11959},
{"f_11954:optimizer_scm",(void*)f_11954},
{"f_12171:optimizer_scm",(void*)f_12171},
{"f_12184:optimizer_scm",(void*)f_12184},
{"f_12226:optimizer_scm",(void*)f_12226},
{"f_12210:optimizer_scm",(void*)f_12210},
{"f_12214:optimizer_scm",(void*)f_12214},
{"f_12201:optimizer_scm",(void*)f_12201},
{"f_12202:optimizer_scm",(void*)f_12202},
{"f_12392:optimizer_scm",(void*)f_12392},
{"f_12405:optimizer_scm",(void*)f_12405},
{"f_12411:optimizer_scm",(void*)f_12411},
{"f_12463:optimizer_scm",(void*)f_12463},
{"f_12455:optimizer_scm",(void*)f_12455},
{"f_12439:optimizer_scm",(void*)f_12439},
{"f_12443:optimizer_scm",(void*)f_12443},
{"f_12447:optimizer_scm",(void*)f_12447},
{"f_12431:optimizer_scm",(void*)f_12431},
{"f_5445:optimizer_scm",(void*)f_5445},
{"f_11305:optimizer_scm",(void*)f_11305},
{"f_11327:optimizer_scm",(void*)f_11327},
{"f_11407:optimizer_scm",(void*)f_11407},
{"f_11365:optimizer_scm",(void*)f_11365},
{"f_11399:optimizer_scm",(void*)f_11399},
{"f_11403:optimizer_scm",(void*)f_11403},
{"f_11391:optimizer_scm",(void*)f_11391},
{"f_11382:optimizer_scm",(void*)f_11382},
{"f_11386:optimizer_scm",(void*)f_11386},
{"f_11374:optimizer_scm",(void*)f_11374},
{"f_11363:optimizer_scm",(void*)f_11363},
{"f_11355:optimizer_scm",(void*)f_11355},
{"f_11350:optimizer_scm",(void*)f_11350},
{"f_11342:optimizer_scm",(void*)f_11342},
{"f_11501:optimizer_scm",(void*)f_11501},
{"f_11521:optimizer_scm",(void*)f_11521},
{"f_11530:optimizer_scm",(void*)f_11530},
{"f_11525:optimizer_scm",(void*)f_11525},
{"f_11513:optimizer_scm",(void*)f_11513},
{"f_5448:optimizer_scm",(void*)f_5448},
{"f_5808:optimizer_scm",(void*)f_5808},
{"f_9441:optimizer_scm",(void*)f_9441},
{"f_11184:optimizer_scm",(void*)f_11184},
{"f_11187:optimizer_scm",(void*)f_11187},
{"f_11190:optimizer_scm",(void*)f_11190},
{"f_11193:optimizer_scm",(void*)f_11193},
{"f_11196:optimizer_scm",(void*)f_11196},
{"f_11199:optimizer_scm",(void*)f_11199},
{"f_11276:optimizer_scm",(void*)f_11276},
{"f_11202:optimizer_scm",(void*)f_11202},
{"f_11205:optimizer_scm",(void*)f_11205},
{"f_11208:optimizer_scm",(void*)f_11208},
{"f_11270:optimizer_scm",(void*)f_11270},
{"f_11211:optimizer_scm",(void*)f_11211},
{"f_11214:optimizer_scm",(void*)f_11214},
{"f_11267:optimizer_scm",(void*)f_11267},
{"f_10096:optimizer_scm",(void*)f_10096},
{"f_10114:optimizer_scm",(void*)f_10114},
{"f_10120:optimizer_scm",(void*)f_10120},
{"f_10100:optimizer_scm",(void*)f_10100},
{"f_11217:optimizer_scm",(void*)f_11217},
{"f_11259:optimizer_scm",(void*)f_11259},
{"f_11257:optimizer_scm",(void*)f_11257},
{"f_11220:optimizer_scm",(void*)f_11220},
{"f_11223:optimizer_scm",(void*)f_11223},
{"f_11226:optimizer_scm",(void*)f_11226},
{"f_11250:optimizer_scm",(void*)f_11250},
{"f_11229:optimizer_scm",(void*)f_11229},
{"f_11232:optimizer_scm",(void*)f_11232},
{"f_11235:optimizer_scm",(void*)f_11235},
{"f_11238:optimizer_scm",(void*)f_11238},
{"f_11241:optimizer_scm",(void*)f_11241},
{"f_11244:optimizer_scm",(void*)f_11244},
{"f_11012:optimizer_scm",(void*)f_11012},
{"f_11018:optimizer_scm",(void*)f_11018},
{"f_11177:optimizer_scm",(void*)f_11177},
{"f_11022:optimizer_scm",(void*)f_11022},
{"f_11172:optimizer_scm",(void*)f_11172},
{"f_11025:optimizer_scm",(void*)f_11025},
{"f_11167:optimizer_scm",(void*)f_11167},
{"f_11028:optimizer_scm",(void*)f_11028},
{"f_11159:optimizer_scm",(void*)f_11159},
{"f_11158:optimizer_scm",(void*)f_11158},
{"f_11135:optimizer_scm",(void*)f_11135},
{"f_11144:optimizer_scm",(void*)f_11144},
{"f_11147:optimizer_scm",(void*)f_11147},
{"f_11122:optimizer_scm",(void*)f_11122},
{"f_11121:optimizer_scm",(void*)f_11121},
{"f_11037:optimizer_scm",(void*)f_11037},
{"f_11042:optimizer_scm",(void*)f_11042},
{"f_11083:optimizer_scm",(void*)f_11083},
{"f_11080:optimizer_scm",(void*)f_11080},
{"f_11065:optimizer_scm",(void*)f_11065},
{"f_11076:optimizer_scm",(void*)f_11076},
{"f_11072:optimizer_scm",(void*)f_11072},
{"f_10895:optimizer_scm",(void*)f_10895},
{"f_10901:optimizer_scm",(void*)f_10901},
{"f_11006:optimizer_scm",(void*)f_11006},
{"f_10905:optimizer_scm",(void*)f_10905},
{"f_11001:optimizer_scm",(void*)f_11001},
{"f_10908:optimizer_scm",(void*)f_10908},
{"f_10996:optimizer_scm",(void*)f_10996},
{"f_10911:optimizer_scm",(void*)f_10911},
{"f_10988:optimizer_scm",(void*)f_10988},
{"f_10987:optimizer_scm",(void*)f_10987},
{"f_10979:optimizer_scm",(void*)f_10979},
{"f_10978:optimizer_scm",(void*)f_10978},
{"f_10962:optimizer_scm",(void*)f_10962},
{"f_10958:optimizer_scm",(void*)f_10958},
{"f_10923:optimizer_scm",(void*)f_10923},
{"f_10931:optimizer_scm",(void*)f_10931},
{"f_10930:optimizer_scm",(void*)f_10930},
{"f_10590:optimizer_scm",(void*)f_10590},
{"f_10746:optimizer_scm",(void*)f_10746},
{"f_10745:optimizer_scm",(void*)f_10745},
{"f_10604:optimizer_scm",(void*)f_10604},
{"f_10611:optimizer_scm",(void*)f_10611},
{"f_10614:optimizer_scm",(void*)f_10614},
{"f_10733:optimizer_scm",(void*)f_10733},
{"f_10732:optimizer_scm",(void*)f_10732},
{"f_10623:optimizer_scm",(void*)f_10623},
{"f_10630:optimizer_scm",(void*)f_10630},
{"f_10633:optimizer_scm",(void*)f_10633},
{"f_10720:optimizer_scm",(void*)f_10720},
{"f_10719:optimizer_scm",(void*)f_10719},
{"f_10770:optimizer_scm",(void*)f_10770},
{"f_10889:optimizer_scm",(void*)f_10889},
{"f_10774:optimizer_scm",(void*)f_10774},
{"f_10884:optimizer_scm",(void*)f_10884},
{"f_10777:optimizer_scm",(void*)f_10777},
{"f_10879:optimizer_scm",(void*)f_10879},
{"f_10780:optimizer_scm",(void*)f_10780},
{"f_10856:optimizer_scm",(void*)f_10856},
{"f_10875:optimizer_scm",(void*)f_10875},
{"f_10871:optimizer_scm",(void*)f_10871},
{"f_10837:optimizer_scm",(void*)f_10837},
{"f_10826:optimizer_scm",(void*)f_10826},
{"f_10813:optimizer_scm",(void*)f_10813},
{"f_10796:optimizer_scm",(void*)f_10796},
{"f_10789:optimizer_scm",(void*)f_10789},
{"f_10755:optimizer_scm",(void*)f_10755},
{"f_10636:optimizer_scm",(void*)f_10636},
{"f_10711:optimizer_scm",(void*)f_10711},
{"f_10699:optimizer_scm",(void*)f_10699},
{"f_10695:optimizer_scm",(void*)f_10695},
{"f_10687:optimizer_scm",(void*)f_10687},
{"f_10681:optimizer_scm",(void*)f_10681},
{"f_10682:optimizer_scm",(void*)f_10682},
{"f_10673:optimizer_scm",(void*)f_10673},
{"f_10665:optimizer_scm",(void*)f_10665},
{"f_10656:optimizer_scm",(void*)f_10656},
{"f_10648:optimizer_scm",(void*)f_10648},
{"f_10602:optimizer_scm",(void*)f_10602},
{"f_10374:optimizer_scm",(void*)f_10374},
{"f_10576:optimizer_scm",(void*)f_10576},
{"f_10454:optimizer_scm",(void*)f_10454},
{"f_10531:optimizer_scm",(void*)f_10531},
{"f_10536:optimizer_scm",(void*)f_10536},
{"f_10574:optimizer_scm",(void*)f_10574},
{"f_10383:optimizer_scm",(void*)f_10383},
{"f_10447:optimizer_scm",(void*)f_10447},
{"f_10387:optimizer_scm",(void*)f_10387},
{"f_10442:optimizer_scm",(void*)f_10442},
{"f_10390:optimizer_scm",(void*)f_10390},
{"f_10437:optimizer_scm",(void*)f_10437},
{"f_10393:optimizer_scm",(void*)f_10393},
{"f_10421:optimizer_scm",(void*)f_10421},
{"f_10426:optimizer_scm",(void*)f_10426},
{"f_10403:optimizer_scm",(void*)f_10403},
{"f_10381:optimizer_scm",(void*)f_10381},
{"f_10566:optimizer_scm",(void*)f_10566},
{"f_10552:optimizer_scm",(void*)f_10552},
{"f_10550:optimizer_scm",(void*)f_10550},
{"f_10456:optimizer_scm",(void*)f_10456},
{"f_10524:optimizer_scm",(void*)f_10524},
{"f_10522:optimizer_scm",(void*)f_10522},
{"f_10510:optimizer_scm",(void*)f_10510},
{"f_10476:optimizer_scm",(void*)f_10476},
{"f_10500:optimizer_scm",(void*)f_10500},
{"f_10498:optimizer_scm",(void*)f_10498},
{"f_10494:optimizer_scm",(void*)f_10494},
{"f_10486:optimizer_scm",(void*)f_10486},
{"f_10130:optimizer_scm",(void*)f_10130},
{"f_10136:optimizer_scm",(void*)f_10136},
{"f_10368:optimizer_scm",(void*)f_10368},
{"f_10140:optimizer_scm",(void*)f_10140},
{"f_10363:optimizer_scm",(void*)f_10363},
{"f_10143:optimizer_scm",(void*)f_10143},
{"f_10358:optimizer_scm",(void*)f_10358},
{"f_10146:optimizer_scm",(void*)f_10146},
{"f_10155:optimizer_scm",(void*)f_10155},
{"f_10332:optimizer_scm",(void*)f_10332},
{"f_10252:optimizer_scm",(void*)f_10252},
{"f_10323:optimizer_scm",(void*)f_10323},
{"f_10322:optimizer_scm",(void*)f_10322},
{"f_10314:optimizer_scm",(void*)f_10314},
{"f_10313:optimizer_scm",(void*)f_10313},
{"f_10268:optimizer_scm",(void*)f_10268},
{"f_10298:optimizer_scm",(void*)f_10298},
{"f_10302:optimizer_scm",(void*)f_10302},
{"f_10288:optimizer_scm",(void*)f_10288},
{"f_10241:optimizer_scm",(void*)f_10241},
{"f_10246:optimizer_scm",(void*)f_10246},
{"f_10217:optimizer_scm",(void*)f_10217},
{"f_10229:optimizer_scm",(void*)f_10229},
{"f_10166:optimizer_scm",(void*)f_10166},
{"f_10187:optimizer_scm",(void*)f_10187},
{"f_10184:optimizer_scm",(void*)f_10184},
{"f_10134:optimizer_scm",(void*)f_10134},
{"f_9871:optimizer_scm",(void*)f_9871},
{"f_9877:optimizer_scm",(void*)f_9877},
{"f_10034:optimizer_scm",(void*)f_10034},
{"f_9881:optimizer_scm",(void*)f_9881},
{"f_10029:optimizer_scm",(void*)f_10029},
{"f_9884:optimizer_scm",(void*)f_9884},
{"f_10024:optimizer_scm",(void*)f_10024},
{"f_9887:optimizer_scm",(void*)f_9887},
{"f_9896:optimizer_scm",(void*)f_9896},
{"f_9998:optimizer_scm",(void*)f_9998},
{"f_9989:optimizer_scm",(void*)f_9989},
{"f_9955:optimizer_scm",(void*)f_9955},
{"f_9964:optimizer_scm",(void*)f_9964},
{"f_9976:optimizer_scm",(void*)f_9976},
{"f_9907:optimizer_scm",(void*)f_9907},
{"f_9928:optimizer_scm",(void*)f_9928},
{"f_9925:optimizer_scm",(void*)f_9925},
{"f_9875:optimizer_scm",(void*)f_9875},
{"f_9772:optimizer_scm",(void*)f_9772},
{"f_9778:optimizer_scm",(void*)f_9778},
{"f_9822:optimizer_scm",(void*)f_9822},
{"f_9827:optimizer_scm",(void*)f_9827},
{"f_9834:optimizer_scm",(void*)f_9834},
{"f_9861:optimizer_scm",(void*)f_9861},
{"f_9857:optimizer_scm",(void*)f_9857},
{"f_9849:optimizer_scm",(void*)f_9849},
{"f_9847:optimizer_scm",(void*)f_9847},
{"f_9812:optimizer_scm",(void*)f_9812},
{"f_9790:optimizer_scm",(void*)f_9790},
{"f_9797:optimizer_scm",(void*)f_9797},
{"f_9550:optimizer_scm",(void*)f_9550},
{"f_9719:optimizer_scm",(void*)f_9719},
{"f_9766:optimizer_scm",(void*)f_9766},
{"f_9765:optimizer_scm",(void*)f_9765},
{"f_9744:optimizer_scm",(void*)f_9744},
{"f_9757:optimizer_scm",(void*)f_9757},
{"f_9756:optimizer_scm",(void*)f_9756},
{"f_9734:optimizer_scm",(void*)f_9734},
{"f_9738:optimizer_scm",(void*)f_9738},
{"f_9717:optimizer_scm",(void*)f_9717},
{"f_9553:optimizer_scm",(void*)f_9553},
{"f_9710:optimizer_scm",(void*)f_9710},
{"f_9557:optimizer_scm",(void*)f_9557},
{"f_9705:optimizer_scm",(void*)f_9705},
{"f_9560:optimizer_scm",(void*)f_9560},
{"f_9700:optimizer_scm",(void*)f_9700},
{"f_9563:optimizer_scm",(void*)f_9563},
{"f_9692:optimizer_scm",(void*)f_9692},
{"f_9675:optimizer_scm",(void*)f_9675},
{"f_9687:optimizer_scm",(void*)f_9687},
{"f_9621:optimizer_scm",(void*)f_9621},
{"f_9645:optimizer_scm",(void*)f_9645},
{"f_9639:optimizer_scm",(void*)f_9639},
{"f_9603:optimizer_scm",(void*)f_9603},
{"f_9578:optimizer_scm",(void*)f_9578},
{"f_9581:optimizer_scm",(void*)f_9581},
{"f_9586:optimizer_scm",(void*)f_9586},
{"f_9444:optimizer_scm",(void*)f_9444},
{"f_9450:optimizer_scm",(void*)f_9450},
{"f_9536:optimizer_scm",(void*)f_9536},
{"f_9531:optimizer_scm",(void*)f_9531},
{"f_9481:optimizer_scm",(void*)f_9481},
{"f_9485:optimizer_scm",(void*)f_9485},
{"f_9489:optimizer_scm",(void*)f_9489},
{"f_9448:optimizer_scm",(void*)f_9448},
{"f_8176:optimizer_scm",(void*)f_8176},
{"f_9436:optimizer_scm",(void*)f_9436},
{"f_9439:optimizer_scm",(void*)f_9439},
{"f_8179:optimizer_scm",(void*)f_8179},
{"f_8350:optimizer_scm",(void*)f_8350},
{"f_8183:optimizer_scm",(void*)f_8183},
{"f_8345:optimizer_scm",(void*)f_8345},
{"f_8186:optimizer_scm",(void*)f_8186},
{"f_8340:optimizer_scm",(void*)f_8340},
{"f_8189:optimizer_scm",(void*)f_8189},
{"f_8335:optimizer_scm",(void*)f_8335},
{"f_8315:optimizer_scm",(void*)f_8315},
{"f_8289:optimizer_scm",(void*)f_8289},
{"f_8235:optimizer_scm",(void*)f_8235},
{"f_8241:optimizer_scm",(void*)f_8241},
{"f_8247:optimizer_scm",(void*)f_8247},
{"f_8204:optimizer_scm",(void*)f_8204},
{"f_8356:optimizer_scm",(void*)f_8356},
{"f_8801:optimizer_scm",(void*)f_8801},
{"f_8808:optimizer_scm",(void*)f_8808},
{"f_8359:optimizer_scm",(void*)f_8359},
{"f_8788:optimizer_scm",(void*)f_8788},
{"f_8363:optimizer_scm",(void*)f_8363},
{"f_8783:optimizer_scm",(void*)f_8783},
{"f_8366:optimizer_scm",(void*)f_8366},
{"f_8778:optimizer_scm",(void*)f_8778},
{"f_8369:optimizer_scm",(void*)f_8369},
{"f_8773:optimizer_scm",(void*)f_8773},
{"f_8749:optimizer_scm",(void*)f_8749},
{"f_8760:optimizer_scm",(void*)f_8760},
{"f_8716:optimizer_scm",(void*)f_8716},
{"f_8682:optimizer_scm",(void*)f_8682},
{"f_8681:optimizer_scm",(void*)f_8681},
{"f_8673:optimizer_scm",(void*)f_8673},
{"f_8672:optimizer_scm",(void*)f_8672},
{"f_8661:optimizer_scm",(void*)f_8661},
{"f_8660:optimizer_scm",(void*)f_8660},
{"f_8652:optimizer_scm",(void*)f_8652},
{"f_8651:optimizer_scm",(void*)f_8651},
{"f_8635:optimizer_scm",(void*)f_8635},
{"f_8607:optimizer_scm",(void*)f_8607},
{"f_8612:optimizer_scm",(void*)f_8612},
{"f_8554:optimizer_scm",(void*)f_8554},
{"f_8560:optimizer_scm",(void*)f_8560},
{"f_8565:optimizer_scm",(void*)f_8565},
{"f_8513:optimizer_scm",(void*)f_8513},
{"f_8519:optimizer_scm",(void*)f_8519},
{"f_8524:optimizer_scm",(void*)f_8524},
{"f_8497:optimizer_scm",(void*)f_8497},
{"f_8493:optimizer_scm",(void*)f_8493},
{"f_8463:optimizer_scm",(void*)f_8463},
{"f_8426:optimizer_scm",(void*)f_8426},
{"f_8442:optimizer_scm",(void*)f_8442},
{"f_8408:optimizer_scm",(void*)f_8408},
{"f_8810:optimizer_scm",(void*)f_8810},
{"f_9426:optimizer_scm",(void*)f_9426},
{"f_9424:optimizer_scm",(void*)f_9424},
{"f_8814:optimizer_scm",(void*)f_8814},
{"f_9410:optimizer_scm",(void*)f_9410},
{"f_8818:optimizer_scm",(void*)f_8818},
{"f_8824:optimizer_scm",(void*)f_8824},
{"f_8830:optimizer_scm",(void*)f_8830},
{"f_8836:optimizer_scm",(void*)f_8836},
{"f_8839:optimizer_scm",(void*)f_8839},
{"f_8845:optimizer_scm",(void*)f_8845},
{"f_9374:optimizer_scm",(void*)f_9374},
{"f_9373:optimizer_scm",(void*)f_9373},
{"f_9084:optimizer_scm",(void*)f_9084},
{"f_9365:optimizer_scm",(void*)f_9365},
{"f_9088:optimizer_scm",(void*)f_9088},
{"f_9360:optimizer_scm",(void*)f_9360},
{"f_9091:optimizer_scm",(void*)f_9091},
{"f_9355:optimizer_scm",(void*)f_9355},
{"f_9094:optimizer_scm",(void*)f_9094},
{"f_9338:optimizer_scm",(void*)f_9338},
{"f_9341:optimizer_scm",(void*)f_9341},
{"f_9312:optimizer_scm",(void*)f_9312},
{"f_9109:optimizer_scm",(void*)f_9109},
{"f_9307:optimizer_scm",(void*)f_9307},
{"f_9112:optimizer_scm",(void*)f_9112},
{"f_9302:optimizer_scm",(void*)f_9302},
{"f_9301:optimizer_scm",(void*)f_9301},
{"f_9276:optimizer_scm",(void*)f_9276},
{"f_9279:optimizer_scm",(void*)f_9279},
{"f_9128:optimizer_scm",(void*)f_9128},
{"f_9252:optimizer_scm",(void*)f_9252},
{"f_9251:optimizer_scm",(void*)f_9251},
{"f_9183:optimizer_scm",(void*)f_9183},
{"f_9186:optimizer_scm",(void*)f_9186},
{"f_9229:optimizer_scm",(void*)f_9229},
{"f_9228:optimizer_scm",(void*)f_9228},
{"f_9220:optimizer_scm",(void*)f_9220},
{"f_9189:optimizer_scm",(void*)f_9189},
{"f_9212:optimizer_scm",(void*)f_9212},
{"f_9203:optimizer_scm",(void*)f_9203},
{"f_9192:optimizer_scm",(void*)f_9192},
{"f_9137:optimizer_scm",(void*)f_9137},
{"f_9140:optimizer_scm",(void*)f_9140},
{"f_9143:optimizer_scm",(void*)f_9143},
{"f_8848:optimizer_scm",(void*)f_8848},
{"f_9066:optimizer_scm",(void*)f_9066},
{"f_9064:optimizer_scm",(void*)f_9064},
{"f_8995:optimizer_scm",(void*)f_8995},
{"f_9056:optimizer_scm",(void*)f_9056},
{"f_9002:optimizer_scm",(void*)f_9002},
{"f_9005:optimizer_scm",(void*)f_9005},
{"f_9029:optimizer_scm",(void*)f_9029},
{"f_9020:optimizer_scm",(void*)f_9020},
{"f_8851:optimizer_scm",(void*)f_8851},
{"f_8986:optimizer_scm",(void*)f_8986},
{"f_8860:optimizer_scm",(void*)f_8860},
{"f_8863:optimizer_scm",(void*)f_8863},
{"f_8912:optimizer_scm",(void*)f_8912},
{"f_8977:optimizer_scm",(void*)f_8977},
{"f_8972:optimizer_scm",(void*)f_8972},
{"f_8964:optimizer_scm",(void*)f_8964},
{"f_8940:optimizer_scm",(void*)f_8940},
{"f_8959:optimizer_scm",(void*)f_8959},
{"f_8944:optimizer_scm",(void*)f_8944},
{"f_8954:optimizer_scm",(void*)f_8954},
{"f_8948:optimizer_scm",(void*)f_8948},
{"f_8949:optimizer_scm",(void*)f_8949},
{"f_8936:optimizer_scm",(void*)f_8936},
{"f_8928:optimizer_scm",(void*)f_8928},
{"f_8866:optimizer_scm",(void*)f_8866},
{"f_8869:optimizer_scm",(void*)f_8869},
{"f_8874:optimizer_scm",(void*)f_8874},
{"f_8910:optimizer_scm",(void*)f_8910},
{"f_8881:optimizer_scm",(void*)f_8881},
{"f_8898:optimizer_scm",(void*)f_8898},
{"f_8888:optimizer_scm",(void*)f_8888},
{"f_8893:optimizer_scm",(void*)f_8893},
{"f_8892:optimizer_scm",(void*)f_8892},
{"f_5830:optimizer_scm",(void*)f_5830},
{"f_8167:optimizer_scm",(void*)f_8167},
{"f_8038:optimizer_scm",(void*)f_8038},
{"f_8067:optimizer_scm",(void*)f_8067},
{"f_8079:optimizer_scm",(void*)f_8079},
{"f_8093:optimizer_scm",(void*)f_8093},
{"f_8142:optimizer_scm",(void*)f_8142},
{"f_5855:optimizer_scm",(void*)f_5855},
{"f_8113:optimizer_scm",(void*)f_8113},
{"f_8117:optimizer_scm",(void*)f_8117},
{"f_8087:optimizer_scm",(void*)f_8087},
{"f_8073:optimizer_scm",(void*)f_8073},
{"f_8071:optimizer_scm",(void*)f_8071},
{"f_8058:optimizer_scm",(void*)f_8058},
{"f_8059:optimizer_scm",(void*)f_8059},
{"f_8019:optimizer_scm",(void*)f_8019},
{"f_7958:optimizer_scm",(void*)f_7958},
{"f_8010:optimizer_scm",(void*)f_8010},
{"f_8002:optimizer_scm",(void*)f_8002},
{"f_7994:optimizer_scm",(void*)f_7994},
{"f_7983:optimizer_scm",(void*)f_7983},
{"f_7975:optimizer_scm",(void*)f_7975},
{"f_7924:optimizer_scm",(void*)f_7924},
{"f_7763:optimizer_scm",(void*)f_7763},
{"f_7769:optimizer_scm",(void*)f_7769},
{"f_7885:optimizer_scm",(void*)f_7885},
{"f_7913:optimizer_scm",(void*)f_7913},
{"f_7912:optimizer_scm",(void*)f_7912},
{"f_7904:optimizer_scm",(void*)f_7904},
{"f_7903:optimizer_scm",(void*)f_7903},
{"f_7778:optimizer_scm",(void*)f_7778},
{"f_7840:optimizer_scm",(void*)f_7840},
{"f_7875:optimizer_scm",(void*)f_7875},
{"f_7859:optimizer_scm",(void*)f_7859},
{"f_7838:optimizer_scm",(void*)f_7838},
{"f_7830:optimizer_scm",(void*)f_7830},
{"f_7814:optimizer_scm",(void*)f_7814},
{"f_7800:optimizer_scm",(void*)f_7800},
{"f_7792:optimizer_scm",(void*)f_7792},
{"f_7740:optimizer_scm",(void*)f_7740},
{"f_7678:optimizer_scm",(void*)f_7678},
{"f_7719:optimizer_scm",(void*)f_7719},
{"f_7731:optimizer_scm",(void*)f_7731},
{"f_7709:optimizer_scm",(void*)f_7709},
{"f_7702:optimizer_scm",(void*)f_7702},
{"f_7703:optimizer_scm",(void*)f_7703},
{"f_7694:optimizer_scm",(void*)f_7694},
{"f_7686:optimizer_scm",(void*)f_7686},
{"f_7641:optimizer_scm",(void*)f_7641},
{"f_7496:optimizer_scm",(void*)f_7496},
{"f_7602:optimizer_scm",(void*)f_7602},
{"f_7630:optimizer_scm",(void*)f_7630},
{"f_7629:optimizer_scm",(void*)f_7629},
{"f_7621:optimizer_scm",(void*)f_7621},
{"f_7620:optimizer_scm",(void*)f_7620},
{"f_7505:optimizer_scm",(void*)f_7505},
{"f_7576:optimizer_scm",(void*)f_7576},
{"f_7589:optimizer_scm",(void*)f_7589},
{"f_7574:optimizer_scm",(void*)f_7574},
{"f_7566:optimizer_scm",(void*)f_7566},
{"f_7541:optimizer_scm",(void*)f_7541},
{"f_7527:optimizer_scm",(void*)f_7527},
{"f_7519:optimizer_scm",(void*)f_7519},
{"f_7477:optimizer_scm",(void*)f_7477},
{"f_7456:optimizer_scm",(void*)f_7456},
{"f_7472:optimizer_scm",(void*)f_7472},
{"f_7464:optimizer_scm",(void*)f_7464},
{"f_7423:optimizer_scm",(void*)f_7423},
{"f_7377:optimizer_scm",(void*)f_7377},
{"f_7409:optimizer_scm",(void*)f_7409},
{"f_7398:optimizer_scm",(void*)f_7398},
{"f_7393:optimizer_scm",(void*)f_7393},
{"f_7385:optimizer_scm",(void*)f_7385},
{"f_7349:optimizer_scm",(void*)f_7349},
{"f_7287:optimizer_scm",(void*)f_7287},
{"f_7329:optimizer_scm",(void*)f_7329},
{"f_7317:optimizer_scm",(void*)f_7317},
{"f_7312:optimizer_scm",(void*)f_7312},
{"f_7304:optimizer_scm",(void*)f_7304},
{"f_7243:optimizer_scm",(void*)f_7243},
{"f_7182:optimizer_scm",(void*)f_7182},
{"f_7230:optimizer_scm",(void*)f_7230},
{"f_7208:optimizer_scm",(void*)f_7208},
{"f_7199:optimizer_scm",(void*)f_7199},
{"f_7200:optimizer_scm",(void*)f_7200},
{"f_7143:optimizer_scm",(void*)f_7143},
{"f_7088:optimizer_scm",(void*)f_7088},
{"f_7124:optimizer_scm",(void*)f_7124},
{"f_7119:optimizer_scm",(void*)f_7119},
{"f_7111:optimizer_scm",(void*)f_7111},
{"f_7063:optimizer_scm",(void*)f_7063},
{"f_7011:optimizer_scm",(void*)f_7011},
{"f_7030:optimizer_scm",(void*)f_7030},
{"f_7048:optimizer_scm",(void*)f_7048},
{"f_7043:optimizer_scm",(void*)f_7043},
{"f_7034:optimizer_scm",(void*)f_7034},
{"f_7035:optimizer_scm",(void*)f_7035},
{"f_6992:optimizer_scm",(void*)f_6992},
{"f_6923:optimizer_scm",(void*)f_6923},
{"f_6979:optimizer_scm",(void*)f_6979},
{"f_6970:optimizer_scm",(void*)f_6970},
{"f_6971:optimizer_scm",(void*)f_6971},
{"f_6955:optimizer_scm",(void*)f_6955},
{"f_6904:optimizer_scm",(void*)f_6904},
{"f_6852:optimizer_scm",(void*)f_6852},
{"f_6864:optimizer_scm",(void*)f_6864},
{"f_6884:optimizer_scm",(void*)f_6884},
{"f_6875:optimizer_scm",(void*)f_6875},
{"f_6876:optimizer_scm",(void*)f_6876},
{"f_6824:optimizer_scm",(void*)f_6824},
{"f_6753:optimizer_scm",(void*)f_6753},
{"f_6782:optimizer_scm",(void*)f_6782},
{"f_6790:optimizer_scm",(void*)f_6790},
{"f_6794:optimizer_scm",(void*)f_6794},
{"f_6774:optimizer_scm",(void*)f_6774},
{"f_6725:optimizer_scm",(void*)f_6725},
{"f_6579:optimizer_scm",(void*)f_6579},
{"f_6607:optimizer_scm",(void*)f_6607},
{"f_6610:optimizer_scm",(void*)f_6610},
{"f_6688:optimizer_scm",(void*)f_6688},
{"f_6613:optimizer_scm",(void*)f_6613},
{"f_6616:optimizer_scm",(void*)f_6616},
{"f_6660:optimizer_scm",(void*)f_6660},
{"f_6669:optimizer_scm",(void*)f_6669},
{"f_6658:optimizer_scm",(void*)f_6658},
{"f_6647:optimizer_scm",(void*)f_6647},
{"f_6642:optimizer_scm",(void*)f_6642},
{"f_6621:optimizer_scm",(void*)f_6621},
{"f_6634:optimizer_scm",(void*)f_6634},
{"f_6601:optimizer_scm",(void*)f_6601},
{"f_6593:optimizer_scm",(void*)f_6593},
{"f_6560:optimizer_scm",(void*)f_6560},
{"f_6553:optimizer_scm",(void*)f_6553},
{"f_6526:optimizer_scm",(void*)f_6526},
{"f_6480:optimizer_scm",(void*)f_6480},
{"f_6517:optimizer_scm",(void*)f_6517},
{"f_6504:optimizer_scm",(void*)f_6504},
{"f_6505:optimizer_scm",(void*)f_6505},
{"f_6496:optimizer_scm",(void*)f_6496},
{"f_6488:optimizer_scm",(void*)f_6488},
{"f_6442:optimizer_scm",(void*)f_6442},
{"f_6391:optimizer_scm",(void*)f_6391},
{"f_6429:optimizer_scm",(void*)f_6429},
{"f_6424:optimizer_scm",(void*)f_6424},
{"f_6416:optimizer_scm",(void*)f_6416},
{"f_6407:optimizer_scm",(void*)f_6407},
{"f_6399:optimizer_scm",(void*)f_6399},
{"f_6357:optimizer_scm",(void*)f_6357},
{"f_6286:optimizer_scm",(void*)f_6286},
{"f_6341:optimizer_scm",(void*)f_6341},
{"f_6329:optimizer_scm",(void*)f_6329},
{"f_6320:optimizer_scm",(void*)f_6320},
{"f_6312:optimizer_scm",(void*)f_6312},
{"f_6263:optimizer_scm",(void*)f_6263},
{"f_6218:optimizer_scm",(void*)f_6218},
{"f_6238:optimizer_scm",(void*)f_6238},
{"f_6246:optimizer_scm",(void*)f_6246},
{"f_6230:optimizer_scm",(void*)f_6230},
{"f_6190:optimizer_scm",(void*)f_6190},
{"f_6169:optimizer_scm",(void*)f_6169},
{"f_6185:optimizer_scm",(void*)f_6185},
{"f_6177:optimizer_scm",(void*)f_6177},
{"f_6136:optimizer_scm",(void*)f_6136},
{"f_6038:optimizer_scm",(void*)f_6038},
{"f_6131:optimizer_scm",(void*)f_6131},
{"f_6130:optimizer_scm",(void*)f_6130},
{"f_6122:optimizer_scm",(void*)f_6122},
{"f_6121:optimizer_scm",(void*)f_6121},
{"f_6113:optimizer_scm",(void*)f_6113},
{"f_6072:optimizer_scm",(void*)f_6072},
{"f_6092:optimizer_scm",(void*)f_6092},
{"f_6080:optimizer_scm",(void*)f_6080},
{"f_6069:optimizer_scm",(void*)f_6069},
{"f_6061:optimizer_scm",(void*)f_6061},
{"f_6013:optimizer_scm",(void*)f_6013},
{"f_5887:optimizer_scm",(void*)f_5887},
{"f_6000:optimizer_scm",(void*)f_6000},
{"f_5999:optimizer_scm",(void*)f_5999},
{"f_5991:optimizer_scm",(void*)f_5991},
{"f_5990:optimizer_scm",(void*)f_5990},
{"f_5982:optimizer_scm",(void*)f_5982},
{"f_5972:optimizer_scm",(void*)f_5972},
{"f_5977:optimizer_scm",(void*)f_5977},
{"f_5976:optimizer_scm",(void*)f_5976},
{"f_5968:optimizer_scm",(void*)f_5968},
{"f_5960:optimizer_scm",(void*)f_5960},
{"f_5890:optimizer_scm",(void*)f_5890},
{"f_5917:optimizer_scm",(void*)f_5917},
{"f_5912:optimizer_scm",(void*)f_5912},
{"f_5904:optimizer_scm",(void*)f_5904},
{"f_5810:optimizer_scm",(void*)f_5810},
{"f_5814:optimizer_scm",(void*)f_5814},
{"f_5824:optimizer_scm",(void*)f_5824},
{"f_5450:optimizer_scm",(void*)f_5450},
{"f_5454:optimizer_scm",(void*)f_5454},
{"f_5795:optimizer_scm",(void*)f_5795},
{"f_5804:optimizer_scm",(void*)f_5804},
{"f_5800:optimizer_scm",(void*)f_5800},
{"f_5501:optimizer_scm",(void*)f_5501},
{"f_5737:optimizer_scm",(void*)f_5737},
{"f_5769:optimizer_scm",(void*)f_5769},
{"f_5782:optimizer_scm",(void*)f_5782},
{"f_5747:optimizer_scm",(void*)f_5747},
{"f_5763:optimizer_scm",(void*)f_5763},
{"f_5751:optimizer_scm",(void*)f_5751},
{"f_5755:optimizer_scm",(void*)f_5755},
{"f_5504:optimizer_scm",(void*)f_5504},
{"f_5678:optimizer_scm",(void*)f_5678},
{"f_5721:optimizer_scm",(void*)f_5721},
{"f_5727:optimizer_scm",(void*)f_5727},
{"f_5685:optimizer_scm",(void*)f_5685},
{"f_5695:optimizer_scm",(void*)f_5695},
{"f_5708:optimizer_scm",(void*)f_5708},
{"f_5693:optimizer_scm",(void*)f_5693},
{"f_5689:optimizer_scm",(void*)f_5689},
{"f_5507:optimizer_scm",(void*)f_5507},
{"f_5510:optimizer_scm",(void*)f_5510},
{"f_5530:optimizer_scm",(void*)f_5530},
{"f_5543:optimizer_scm",(void*)f_5543},
{"f_5604:optimizer_scm",(void*)f_5604},
{"f_5650:optimizer_scm",(void*)f_5650},
{"f_5634:optimizer_scm",(void*)f_5634},
{"f_5625:optimizer_scm",(void*)f_5625},
{"f_5617:optimizer_scm",(void*)f_5617},
{"f_5602:optimizer_scm",(void*)f_5602},
{"f_5572:optimizer_scm",(void*)f_5572},
{"f_5594:optimizer_scm",(void*)f_5594},
{"f_5593:optimizer_scm",(void*)f_5593},
{"f_5585:optimizer_scm",(void*)f_5585},
{"f_5555:optimizer_scm",(void*)f_5555},
{"f_5513:optimizer_scm",(void*)f_5513},
{"f_5522:optimizer_scm",(void*)f_5522},
{"f_5456:optimizer_scm",(void*)f_5456},
{"f_5462:optimizer_scm",(void*)f_5462},
{"f_5486:optimizer_scm",(void*)f_5486},
{"f_5435:optimizer_scm",(void*)f_5435},
{"f_5138:optimizer_scm",(void*)f_5138},
{"f_5152:optimizer_scm",(void*)f_5152},
{"f_5429:optimizer_scm",(void*)f_5429},
{"f_5167:optimizer_scm",(void*)f_5167},
{"f_5425:optimizer_scm",(void*)f_5425},
{"f_5172:optimizer_scm",(void*)f_5172},
{"f_5417:optimizer_scm",(void*)f_5417},
{"f_5179:optimizer_scm",(void*)f_5179},
{"f_5412:optimizer_scm",(void*)f_5412},
{"f_5407:optimizer_scm",(void*)f_5407},
{"f_5403:optimizer_scm",(void*)f_5403},
{"f_5185:optimizer_scm",(void*)f_5185},
{"f_5188:optimizer_scm",(void*)f_5188},
{"f_5381:optimizer_scm",(void*)f_5381},
{"f_5380:optimizer_scm",(void*)f_5380},
{"f_5194:optimizer_scm",(void*)f_5194},
{"f_5354:optimizer_scm",(void*)f_5354},
{"f_5353:optimizer_scm",(void*)f_5353},
{"f_5345:optimizer_scm",(void*)f_5345},
{"f_5344:optimizer_scm",(void*)f_5344},
{"f_5336:optimizer_scm",(void*)f_5336},
{"f_5203:optimizer_scm",(void*)f_5203},
{"f_5209:optimizer_scm",(void*)f_5209},
{"f_5215:optimizer_scm",(void*)f_5215},
{"f_5317:optimizer_scm",(void*)f_5317},
{"f_5316:optimizer_scm",(void*)f_5316},
{"f_5221:optimizer_scm",(void*)f_5221},
{"f_5299:optimizer_scm",(void*)f_5299},
{"f_5298:optimizer_scm",(void*)f_5298},
{"f_5290:optimizer_scm",(void*)f_5290},
{"f_5289:optimizer_scm",(void*)f_5289},
{"f_5281:optimizer_scm",(void*)f_5281},
{"f_5280:optimizer_scm",(void*)f_5280},
{"f_5230:optimizer_scm",(void*)f_5230},
{"f_5237:optimizer_scm",(void*)f_5237},
{"f_5240:optimizer_scm",(void*)f_5240},
{"f_5258:optimizer_scm",(void*)f_5258},
{"f_5243:optimizer_scm",(void*)f_5243},
{"f_5155:optimizer_scm",(void*)f_5155},
{"f_5158:optimizer_scm",(void*)f_5158},
{"f_5145:optimizer_scm",(void*)f_5145},
{"f_5141:optimizer_scm",(void*)f_5141},
{"f_3438:optimizer_scm",(void*)f_3438},
{"f_5042:optimizer_scm",(void*)f_5042},
{"f_5048:optimizer_scm",(void*)f_5048},
{"f_5052:optimizer_scm",(void*)f_5052},
{"f_5055:optimizer_scm",(void*)f_5055},
{"f_5091:optimizer_scm",(void*)f_5091},
{"f_5096:optimizer_scm",(void*)f_5096},
{"f_5100:optimizer_scm",(void*)f_5100},
{"f_5058:optimizer_scm",(void*)f_5058},
{"f_5061:optimizer_scm",(void*)f_5061},
{"f_5064:optimizer_scm",(void*)f_5064},
{"f_5067:optimizer_scm",(void*)f_5067},
{"f_5018:optimizer_scm",(void*)f_5018},
{"f_5022:optimizer_scm",(void*)f_5022},
{"f_5028:optimizer_scm",(void*)f_5028},
{"f_5032:optimizer_scm",(void*)f_5032},
{"f_3825:optimizer_scm",(void*)f_3825},
{"f_5012:optimizer_scm",(void*)f_5012},
{"f_3829:optimizer_scm",(void*)f_3829},
{"f_5007:optimizer_scm",(void*)f_5007},
{"f_3832:optimizer_scm",(void*)f_3832},
{"f_5002:optimizer_scm",(void*)f_5002},
{"f_3835:optimizer_scm",(void*)f_3835},
{"f_4903:optimizer_scm",(void*)f_4903},
{"f_4906:optimizer_scm",(void*)f_4906},
{"f_4995:optimizer_scm",(void*)f_4995},
{"f_4991:optimizer_scm",(void*)f_4991},
{"f_4963:optimizer_scm",(void*)f_4963},
{"f_4984:optimizer_scm",(void*)f_4984},
{"f_4976:optimizer_scm",(void*)f_4976},
{"f_4923:optimizer_scm",(void*)f_4923},
{"f_4953:optimizer_scm",(void*)f_4953},
{"f_4945:optimizer_scm",(void*)f_4945},
{"f_4929:optimizer_scm",(void*)f_4929},
{"f_4933:optimizer_scm",(void*)f_4933},
{"f_4913:optimizer_scm",(void*)f_4913},
{"f_4884:optimizer_scm",(void*)f_4884},
{"f_4172:optimizer_scm",(void*)f_4172},
{"f_4871:optimizer_scm",(void*)f_4871},
{"f_4872:optimizer_scm",(void*)f_4872},
{"f_4841:optimizer_scm",(void*)f_4841},
{"f_4840:optimizer_scm",(void*)f_4840},
{"f_4836:optimizer_scm",(void*)f_4836},
{"f_4826:optimizer_scm",(void*)f_4826},
{"f_4184:optimizer_scm",(void*)f_4184},
{"f_4193:optimizer_scm",(void*)f_4193},
{"f_4816:optimizer_scm",(void*)f_4816},
{"f_4815:optimizer_scm",(void*)f_4815},
{"f_4403:optimizer_scm",(void*)f_4403},
{"f_4801:optimizer_scm",(void*)f_4801},
{"f_4406:optimizer_scm",(void*)f_4406},
{"f_4414:optimizer_scm",(void*)f_4414},
{"f_4767:optimizer_scm",(void*)f_4767},
{"f_4773:optimizer_scm",(void*)f_4773},
{"f_4796:optimizer_scm",(void*)f_4796},
{"f_4776:optimizer_scm",(void*)f_4776},
{"f_4424:optimizer_scm",(void*)f_4424},
{"f_4487:optimizer_scm",(void*)f_4487},
{"f_4754:optimizer_scm",(void*)f_4754},
{"f_4659:optimizer_scm",(void*)f_4659},
{"f_4674:optimizer_scm",(void*)f_4674},
{"f_4685:optimizer_scm",(void*)f_4685},
{"f_4732:optimizer_scm",(void*)f_4732},
{"f_4718:optimizer_scm",(void*)f_4718},
{"f_4710:optimizer_scm",(void*)f_4710},
{"f_4697:optimizer_scm",(void*)f_4697},
{"f_4698:optimizer_scm",(void*)f_4698},
{"f_4689:optimizer_scm",(void*)f_4689},
{"f_4679:optimizer_scm",(void*)f_4679},
{"f_4501:optimizer_scm",(void*)f_4501},
{"f_4540:optimizer_scm",(void*)f_4540},
{"f_4546:optimizer_scm",(void*)f_4546},
{"f_4552:optimizer_scm",(void*)f_4552},
{"f_4596:optimizer_scm",(void*)f_4596},
{"f_4572:optimizer_scm",(void*)f_4572},
{"f_4576:optimizer_scm",(void*)f_4576},
{"f_4564:optimizer_scm",(void*)f_4564},
{"f_4534:optimizer_scm",(void*)f_4534},
{"f_4521:optimizer_scm",(void*)f_4521},
{"f_4522:optimizer_scm",(void*)f_4522},
{"f_4477:optimizer_scm",(void*)f_4477},
{"f_4471:optimizer_scm",(void*)f_4471},
{"f_4472:optimizer_scm",(void*)f_4472},
{"f_4467:optimizer_scm",(void*)f_4467},
{"f_4427:optimizer_scm",(void*)f_4427},
{"f_4430:optimizer_scm",(void*)f_4430},
{"f_4433:optimizer_scm",(void*)f_4433},
{"f_4452:optimizer_scm",(void*)f_4452},
{"f_4451:optimizer_scm",(void*)f_4451},
{"f_4443:optimizer_scm",(void*)f_4443},
{"f_4393:optimizer_scm",(void*)f_4393},
{"f_4392:optimizer_scm",(void*)f_4392},
{"f_4384:optimizer_scm",(void*)f_4384},
{"f_4383:optimizer_scm",(void*)f_4383},
{"f_4379:optimizer_scm",(void*)f_4379},
{"f_4266:optimizer_scm",(void*)f_4266},
{"f_4365:optimizer_scm",(void*)f_4365},
{"f_4364:optimizer_scm",(void*)f_4364},
{"f_4284:optimizer_scm",(void*)f_4284},
{"f_4352:optimizer_scm",(void*)f_4352},
{"f_4344:optimizer_scm",(void*)f_4344},
{"f_4287:optimizer_scm",(void*)f_4287},
{"f_4323:optimizer_scm",(void*)f_4323},
{"f_4321:optimizer_scm",(void*)f_4321},
{"f_4296:optimizer_scm",(void*)f_4296},
{"f_4313:optimizer_scm",(void*)f_4313},
{"f_4312:optimizer_scm",(void*)f_4312},
{"f_4304:optimizer_scm",(void*)f_4304},
{"f_4245:optimizer_scm",(void*)f_4245},
{"f_4229:optimizer_scm",(void*)f_4229},
{"f_4196:optimizer_scm",(void*)f_4196},
{"f_4202:optimizer_scm",(void*)f_4202},
{"f_4205:optimizer_scm",(void*)f_4205},
{"f_4224:optimizer_scm",(void*)f_4224},
{"f_4223:optimizer_scm",(void*)f_4223},
{"f_4215:optimizer_scm",(void*)f_4215},
{"f_3994:optimizer_scm",(void*)f_3994},
{"f_4093:optimizer_scm",(void*)f_4093},
{"f_4098:optimizer_scm",(void*)f_4098},
{"f_4105:optimizer_scm",(void*)f_4105},
{"f_4141:optimizer_scm",(void*)f_4141},
{"f_4125:optimizer_scm",(void*)f_4125},
{"f_4117:optimizer_scm",(void*)f_4117},
{"f_3999:optimizer_scm",(void*)f_3999},
{"f_4017:optimizer_scm",(void*)f_4017},
{"f_4024:optimizer_scm",(void*)f_4024},
{"f_4067:optimizer_scm",(void*)f_4067},
{"f_4070:optimizer_scm",(void*)f_4070},
{"f_4060:optimizer_scm",(void*)f_4060},
{"f_4044:optimizer_scm",(void*)f_4044},
{"f_4036:optimizer_scm",(void*)f_4036},
{"f_4005:optimizer_scm",(void*)f_4005},
{"f_4011:optimizer_scm",(void*)f_4011},
{"f_3931:optimizer_scm",(void*)f_3931},
{"f_3963:optimizer_scm",(void*)f_3963},
{"f_3972:optimizer_scm",(void*)f_3972},
{"f_3979:optimizer_scm",(void*)f_3979},
{"f_3934:optimizer_scm",(void*)f_3934},
{"f_3955:optimizer_scm",(void*)f_3955},
{"f_3956:optimizer_scm",(void*)f_3956},
{"f_3850:optimizer_scm",(void*)f_3850},
{"f_3854:optimizer_scm",(void*)f_3854},
{"f_3866:optimizer_scm",(void*)f_3866},
{"f_3895:optimizer_scm",(void*)f_3895},
{"f_3872:optimizer_scm",(void*)f_3872},
{"f_3887:optimizer_scm",(void*)f_3887},
{"f_3888:optimizer_scm",(void*)f_3888},
{"f_3883:optimizer_scm",(void*)f_3883},
{"f_3578:optimizer_scm",(void*)f_3578},
{"f_3592:optimizer_scm",(void*)f_3592},
{"f_3819:optimizer_scm",(void*)f_3819},
{"f_3595:optimizer_scm",(void*)f_3595},
{"f_3814:optimizer_scm",(void*)f_3814},
{"f_3598:optimizer_scm",(void*)f_3598},
{"f_3809:optimizer_scm",(void*)f_3809},
{"f_3804:optimizer_scm",(void*)f_3804},
{"f_3796:optimizer_scm",(void*)f_3796},
{"f_3791:optimizer_scm",(void*)f_3791},
{"f_3783:optimizer_scm",(void*)f_3783},
{"f_3769:optimizer_scm",(void*)f_3769},
{"f_3775:optimizer_scm",(void*)f_3775},
{"f_3662:optimizer_scm",(void*)f_3662},
{"f_3750:optimizer_scm",(void*)f_3750},
{"f_3762:optimizer_scm",(void*)f_3762},
{"f_3748:optimizer_scm",(void*)f_3748},
{"f_3673:optimizer_scm",(void*)f_3673},
{"f_3696:optimizer_scm",(void*)f_3696},
{"f_3734:optimizer_scm",(void*)f_3734},
{"f_3740:optimizer_scm",(void*)f_3740},
{"f_3702:optimizer_scm",(void*)f_3702},
{"f_3706:optimizer_scm",(void*)f_3706},
{"f_3709:optimizer_scm",(void*)f_3709},
{"f_3732:optimizer_scm",(void*)f_3732},
{"f_3720:optimizer_scm",(void*)f_3720},
{"f_3679:optimizer_scm",(void*)f_3679},
{"f_3685:optimizer_scm",(void*)f_3685},
{"f_3689:optimizer_scm",(void*)f_3689},
{"f_3693:optimizer_scm",(void*)f_3693},
{"f_3671:optimizer_scm",(void*)f_3671},
{"f_3610:optimizer_scm",(void*)f_3610},
{"f_3627:optimizer_scm",(void*)f_3627},
{"f_3601:optimizer_scm",(void*)f_3601},
{"f_3481:optimizer_scm",(void*)f_3481},
{"f_3572:optimizer_scm",(void*)f_3572},
{"f_3571:optimizer_scm",(void*)f_3571},
{"f_3485:optimizer_scm",(void*)f_3485},
{"f_3496:optimizer_scm",(void*)f_3496},
{"f_3506:optimizer_scm",(void*)f_3506},
{"f_3555:optimizer_scm",(void*)f_3555},
{"f_3553:optimizer_scm",(void*)f_3553},
{"f_3512:optimizer_scm",(void*)f_3512},
{"f_3518:optimizer_scm",(void*)f_3518},
{"f_3545:optimizer_scm",(void*)f_3545},
{"f_3524:optimizer_scm",(void*)f_3524},
{"f_3488:optimizer_scm",(void*)f_3488},
{"f_3477:optimizer_scm",(void*)f_3477},
{"f_3462:optimizer_scm",(void*)f_3462},
{"f_3471:optimizer_scm",(void*)f_3471},
{"f_3470:optimizer_scm",(void*)f_3470},
{"f_3447:optimizer_scm",(void*)f_3447},
{"f_3456:optimizer_scm",(void*)f_3456},
{"f_3455:optimizer_scm",(void*)f_3455},
{"f_3441:optimizer_scm",(void*)f_3441},
{"f_3185:optimizer_scm",(void*)f_3185},
{"f_3206:optimizer_scm",(void*)f_3206},
{"f_3250:optimizer_scm",(void*)f_3250},
{"f_3265:optimizer_scm",(void*)f_3265},
{"f_3424:optimizer_scm",(void*)f_3424},
{"f_3269:optimizer_scm",(void*)f_3269},
{"f_3419:optimizer_scm",(void*)f_3419},
{"f_3272:optimizer_scm",(void*)f_3272},
{"f_3414:optimizer_scm",(void*)f_3414},
{"f_3275:optimizer_scm",(void*)f_3275},
{"f_3317:optimizer_scm",(void*)f_3317},
{"f_3381:optimizer_scm",(void*)f_3381},
{"f_3336:optimizer_scm",(void*)f_3336},
{"f_3347:optimizer_scm",(void*)f_3347},
{"f_3320:optimizer_scm",(void*)f_3320},
{"f_3290:optimizer_scm",(void*)f_3290},
{"f_3253:optimizer_scm",(void*)f_3253},
{"f_3259:optimizer_scm",(void*)f_3259},
{"f_3209:optimizer_scm",(void*)f_3209},
{"f_3212:optimizer_scm",(void*)f_3212},
{"f_3217:optimizer_scm",(void*)f_3217},
{"f_3222:optimizer_scm",(void*)f_3222},
{"f_3226:optimizer_scm",(void*)f_3226},
{"f_3188:optimizer_scm",(void*)f_3188},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
