/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-05-13 09:19
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   SVN rev. 10674	compiled 2008-04-30 on debian (Linux)
   command line: optimizer.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[259];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9563)
static void C_ccall f_9563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9571)
static void C_ccall f_9571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9576)
static void C_fcall f_9576(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9621)
static void C_ccall f_9621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9625)
static void C_ccall f_9625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9586)
static void C_ccall f_9586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9610)
static void C_ccall f_9610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9595)
static void C_fcall f_9595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8934)
static void C_ccall f_8934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8968)
static void C_ccall f_8968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9010)
static void C_ccall f_9010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9020)
static void C_fcall f_9020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9084)
static void C_ccall f_9084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9113)
static void C_fcall f_9113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_fcall f_9129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9174)
static void C_ccall f_9174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9278)
static void C_ccall f_9278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_9291)
static void C_ccall f_9291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9326)
static void C_ccall f_9326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9310)
static void C_ccall f_9310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9314)
static void C_ccall f_9314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9303)
static void C_ccall f_9303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9400)
static void C_ccall f_9400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_9413)
static void C_ccall f_9413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_ccall f_9419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9465)
static void C_ccall f_9465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9445)
static void C_ccall f_9445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9449)
static void C_ccall f_9449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8752)
static void C_ccall f_8752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8774)
static void C_ccall f_8774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8829)
static void C_ccall f_8829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8799)
static void C_ccall f_8799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8821)
static void C_ccall f_8821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8825)
static void C_ccall f_8825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8797)
static void C_ccall f_8797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8863)
static void C_ccall f_8863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_8877)
static void C_ccall f_8877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8639)
static void C_ccall f_8639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8642)
static void C_ccall f_8642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8645)
static void C_ccall f_8645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8651)
static void C_ccall f_8651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_ccall f_8654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8731)
static void C_ccall f_8731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8657)
static void C_ccall f_8657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8660)
static void C_ccall f_8660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8663)
static void C_ccall f_8663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8725)
static void C_ccall f_8725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8666)
static void C_ccall f_8666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8722)
static void C_ccall f_8722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7701)
static void C_fcall f_7701(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7719)
static void C_ccall f_7719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8672)
static void C_ccall f_8672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8712)
static void C_ccall f_8712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8675)
static void C_ccall f_8675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8678)
static void C_ccall f_8678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8681)
static void C_ccall f_8681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8705)
static void C_ccall f_8705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8687)
static void C_ccall f_8687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8690)
static void C_ccall f_8690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8693)
static void C_ccall f_8693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8696)
static void C_ccall f_8696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8699)
static void C_ccall f_8699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8492)
static void C_fcall f_8492(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8498)
static void C_ccall f_8498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8610)
static void C_ccall f_8610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8619)
static void C_ccall f_8619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8622)
static void C_ccall f_8622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8517)
static void C_ccall f_8517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_fcall f_8522(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8563)
static void C_fcall f_8563(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8560)
static void C_ccall f_8560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8545)
static void C_ccall f_8545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8556)
static void C_ccall f_8556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8552)
static void C_ccall f_8552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8405)
static void C_fcall f_8405(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8467)
static void C_ccall f_8467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8463)
static void C_ccall f_8463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8155)
static void C_fcall f_8155(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8169)
static void C_ccall f_8169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8189)
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8196)
static void C_ccall f_8196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8199)
static void C_ccall f_8199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8400)
static void C_ccall f_8400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8396)
static void C_ccall f_8396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8362)
static void C_ccall f_8362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8351)
static void C_ccall f_8351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8338)
static void C_ccall f_8338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8314)
static void C_ccall f_8314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8280)
static void C_ccall f_8280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8251)
static void C_ccall f_8251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8239)
static void C_ccall f_8239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8235)
static void C_ccall f_8235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8167)
static void C_ccall f_8167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_fcall f_7954(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8141)
static void C_ccall f_8141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8019)
static void C_ccall f_8019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8096)
static void C_ccall f_8096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8139)
static void C_ccall f_8139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7963)
static void C_ccall f_7963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8001)
static void C_ccall f_8001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7961)
static void C_ccall f_7961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8117)
static void C_ccall f_8117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8115)
static void C_ccall f_8115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8021)
static void C_ccall f_8021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8089)
static void C_ccall f_8089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8087)
static void C_ccall f_8087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8075)
static void C_ccall f_8075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8065)
static void C_ccall f_8065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8063)
static void C_ccall f_8063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8059)
static void C_ccall f_8059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8051)
static void C_ccall f_8051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7735)
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7741)
static void C_fcall f_7741(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7760)
static void C_fcall f_7760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7857)
static void C_ccall f_7857(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7851)
static void C_ccall f_7851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7771)
static void C_fcall f_7771(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7792)
static void C_ccall f_7792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_fcall f_7491(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7497)
static void C_fcall f_7497(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7516)
static void C_fcall f_7516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7618)
static void C_ccall f_7618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7609)
static void C_ccall f_7609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_fcall f_7575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7527)
static void C_fcall f_7527(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7548)
static void C_ccall f_7548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7545)
static void C_ccall f_7545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7392)
static void C_fcall f_7392(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_fcall f_7447(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7469)
static void C_ccall f_7469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7467)
static void C_ccall f_7467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_fcall f_7195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7364)
static void C_ccall f_7364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_ccall f_7368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7198)
static void C_fcall f_7198(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7337)
static void C_ccall f_7337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7320)
static void C_ccall f_7320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7266)
static void C_fcall f_7266(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7284)
static void C_ccall f_7284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7248)
static void C_ccall f_7248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_fcall f_7223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_fcall f_7226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7231)
static void C_ccall f_7231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7095)
static void C_fcall f_7095(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7101)
static void C_ccall f_7101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7132)
static void C_fcall f_7132(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7090)
static void C_ccall f_7090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_fcall f_5960(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6116)
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6016)
static void C_ccall f_6016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6122)
static void C_fcall f_6122(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6532)
static void C_ccall f_6532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_fcall f_6125(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6519)
static void C_ccall f_6519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6506)
static void C_ccall f_6506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6462)
static void C_ccall f_6462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6401)
static void C_fcall f_6401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_fcall f_6373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6326)
static void C_fcall f_6326(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_fcall f_6285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_ccall f_6259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6208)
static void C_ccall f_6208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6541)
static void C_fcall f_6541(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7075)
static void C_ccall f_7075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6545)
static void C_ccall f_6545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_fcall f_6561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6570)
static void C_ccall f_6570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6576)
static void C_ccall f_6576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6752)
static void C_ccall f_6752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6977)
static void C_ccall f_6977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6851)
static void C_ccall f_6851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6854)
static void C_ccall f_6854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6881)
static void C_ccall f_6881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6857)
static void C_ccall f_6857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_ccall f_6860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_ccall f_6805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6808)
static void C_ccall f_6808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6811)
static void C_ccall f_6811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6734)
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6732)
static void C_ccall f_6732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6675)
static void C_ccall f_6675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6685)
static void C_ccall f_6685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6582)
static void C_ccall f_6582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6594)
static void C_ccall f_6594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6605)
static void C_ccall f_6605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5876)
static void C_fcall f_5876(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_fcall f_4002(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5856)
static void C_ccall f_5856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5843)
static void C_ccall f_5843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_fcall f_5784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5668)
static void C_ccall f_5668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_fcall f_5307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_fcall f_5238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_fcall f_4982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_fcall f_4838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4614)
static void C_fcall f_4614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_fcall f_4617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4504)
static void C_ccall f_4504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_ccall f_4507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_fcall f_4173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_fcall f_4170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_fcall f_4037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_fcall f_3980(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3898)
static void C_ccall f_3898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3722)
static void C_fcall f_3722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3635)
static void C_fcall f_3635(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3641)
static void C_fcall f_3641(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_fcall f_3429(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_fcall f_3444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_fcall f_3456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_fcall f_3465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_fcall f_3218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_fcall f_3230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_fcall f_3245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3156)
static C_word C_fcall f_3156(C_word t0);
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3038)
static void C_fcall f_3038(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_fcall f_2992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_ccall f_3013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_fcall f_2963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_fcall f_2539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2849)
static void C_ccall f_2849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_fcall f_2560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_fcall f_2756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_fcall f_2611(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2650)
static void C_ccall f_2650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2563)
static void C_ccall f_2563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_fcall f_2449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_fcall f_2407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2165)
static void C_ccall f_2165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_fcall f_2126(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_fcall f_2048(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_fcall f_2087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_fcall f_1918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_fcall f_1758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static C_word C_fcall f_1711(C_word t0);
C_noret_decl(f_1701)
static C_word C_fcall f_1701(C_word t0);
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1685)
static void C_fcall f_1685(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1524)
static void C_fcall f_1524(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1576)
static void C_fcall f_1576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_fcall f_1549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_fcall f_1512(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static C_word C_fcall f_1479(C_word *a,C_word t0,C_word t1);

C_noret_decl(trf_9576)
static void C_fcall trf_9576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9576(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9576(t0,t1,t2);}

C_noret_decl(trf_9595)
static void C_fcall trf_9595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9595(t0,t1);}

C_noret_decl(trf_9020)
static void C_fcall trf_9020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9020(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9020(t0,t1,t2,t3);}

C_noret_decl(trf_9113)
static void C_fcall trf_9113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9113(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9113(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9129)
static void C_fcall trf_9129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9129(t0,t1);}

C_noret_decl(trf_7701)
static void C_fcall trf_7701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7701(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7701(t0,t1,t2,t3);}

C_noret_decl(trf_8492)
static void C_fcall trf_8492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8492(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8492(t0,t1,t2);}

C_noret_decl(trf_8522)
static void C_fcall trf_8522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8522(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8522(t0,t1,t2,t3);}

C_noret_decl(trf_8563)
static void C_fcall trf_8563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8563(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8563(t0,t1);}

C_noret_decl(trf_8405)
static void C_fcall trf_8405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8405(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8405(t0,t1,t2);}

C_noret_decl(trf_8155)
static void C_fcall trf_8155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8155(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8155(t0,t1,t2,t3);}

C_noret_decl(trf_7954)
static void C_fcall trf_7954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7954(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7954(t0,t1,t2);}

C_noret_decl(trf_7735)
static void C_fcall trf_7735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7735(t0,t1,t2);}

C_noret_decl(trf_7741)
static void C_fcall trf_7741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7741(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7741(t0,t1,t2,t3);}

C_noret_decl(trf_7760)
static void C_fcall trf_7760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7760(t0,t1);}

C_noret_decl(trf_7771)
static void C_fcall trf_7771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7771(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7771(t0,t1,t2,t3);}

C_noret_decl(trf_7491)
static void C_fcall trf_7491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7491(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7491(t0,t1,t2);}

C_noret_decl(trf_7497)
static void C_fcall trf_7497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7497(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7497(t0,t1,t2,t3);}

C_noret_decl(trf_7516)
static void C_fcall trf_7516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7516(t0,t1);}

C_noret_decl(trf_7575)
static void C_fcall trf_7575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7575(t0,t1);}

C_noret_decl(trf_7527)
static void C_fcall trf_7527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7527(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7527(t0,t1,t2,t3);}

C_noret_decl(trf_7392)
static void C_fcall trf_7392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7392(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7392(t0,t1,t2,t3);}

C_noret_decl(trf_7447)
static void C_fcall trf_7447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7447(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7447(t0,t1,t2,t3);}

C_noret_decl(trf_7195)
static void C_fcall trf_7195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7195(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7195(t0,t1,t2);}

C_noret_decl(trf_7198)
static void C_fcall trf_7198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7198(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7198(t0,t1,t2,t3);}

C_noret_decl(trf_7266)
static void C_fcall trf_7266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7266(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7266(t0,t1,t2,t3);}

C_noret_decl(trf_7223)
static void C_fcall trf_7223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7223(t0,t1);}

C_noret_decl(trf_7226)
static void C_fcall trf_7226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7226(t0,t1);}

C_noret_decl(trf_7095)
static void C_fcall trf_7095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7095(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7095(t0,t1);}

C_noret_decl(trf_7132)
static void C_fcall trf_7132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7132(t0,t1);}

C_noret_decl(trf_5960)
static void C_fcall trf_5960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5960(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5960(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6122)
static void C_fcall trf_6122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6122(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6122(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6125)
static void C_fcall trf_6125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6125(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6125(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6401)
static void C_fcall trf_6401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6401(t0,t1);}

C_noret_decl(trf_6373)
static void C_fcall trf_6373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6373(t0,t1);}

C_noret_decl(trf_6326)
static void C_fcall trf_6326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6326(t0,t1);}

C_noret_decl(trf_6285)
static void C_fcall trf_6285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6285(t0,t1);}

C_noret_decl(trf_6541)
static void C_fcall trf_6541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6541(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6541(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6561)
static void C_fcall trf_6561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6561(t0,t1);}

C_noret_decl(trf_5876)
static void C_fcall trf_5876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5876(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5876(t0,t1,t2,t3);}

C_noret_decl(trf_4002)
static void C_fcall trf_4002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4002(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4002(t0,t1);}

C_noret_decl(trf_5784)
static void C_fcall trf_5784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5784(t0,t1);}

C_noret_decl(trf_5307)
static void C_fcall trf_5307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5307(t0,t1);}

C_noret_decl(trf_5238)
static void C_fcall trf_5238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5238(t0,t1);}

C_noret_decl(trf_4982)
static void C_fcall trf_4982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4982(t0,t1);}

C_noret_decl(trf_4838)
static void C_fcall trf_4838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4838(t0,t1);}

C_noret_decl(trf_4614)
static void C_fcall trf_4614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4614(t0,t1);}

C_noret_decl(trf_4617)
static void C_fcall trf_4617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4617(t0,t1);}

C_noret_decl(trf_4173)
static void C_fcall trf_4173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4173(t0,t1);}

C_noret_decl(trf_4170)
static void C_fcall trf_4170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4170(t0,t1);}

C_noret_decl(trf_4037)
static void C_fcall trf_4037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4037(t0,t1);}

C_noret_decl(trf_3980)
static void C_fcall trf_3980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3980(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3980(t0,t1,t2,t3);}

C_noret_decl(trf_3722)
static void C_fcall trf_3722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3722(t0,t1);}

C_noret_decl(trf_3635)
static void C_fcall trf_3635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3635(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3635(t0,t1,t2,t3);}

C_noret_decl(trf_3641)
static void C_fcall trf_3641(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3641(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3641(t0,t1,t2,t3);}

C_noret_decl(trf_3429)
static void C_fcall trf_3429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3429(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3429(t0,t1);}

C_noret_decl(trf_3444)
static void C_fcall trf_3444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3444(t0,t1);}

C_noret_decl(trf_3456)
static void C_fcall trf_3456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3456(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3456(t0,t1);}

C_noret_decl(trf_3465)
static void C_fcall trf_3465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3465(t0,t1);}

C_noret_decl(trf_3218)
static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3218(t0,t1);}

C_noret_decl(trf_3230)
static void C_fcall trf_3230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3230(t0,t1);}

C_noret_decl(trf_3245)
static void C_fcall trf_3245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3245(t0,t1);}

C_noret_decl(trf_3160)
static void C_fcall trf_3160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3160(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3160(t0,t1,t2,t3);}

C_noret_decl(trf_3038)
static void C_fcall trf_3038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3038(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3038(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2023)
static void C_fcall trf_2023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2023(t0,t1,t2);}

C_noret_decl(trf_2992)
static void C_fcall trf_2992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2992(t0,t1);}

C_noret_decl(trf_2963)
static void C_fcall trf_2963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2963(t0,t1);}

C_noret_decl(trf_2539)
static void C_fcall trf_2539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2539(t0,t1);}

C_noret_decl(trf_2560)
static void C_fcall trf_2560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2560(t0,t1);}

C_noret_decl(trf_2756)
static void C_fcall trf_2756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2756(t0,t1);}

C_noret_decl(trf_2611)
static void C_fcall trf_2611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2611(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2611(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2449)
static void C_fcall trf_2449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2449(t0,t1);}

C_noret_decl(trf_2407)
static void C_fcall trf_2407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2407(t0,t1);}

C_noret_decl(trf_2126)
static void C_fcall trf_2126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2126(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2126(t0,t1);}

C_noret_decl(trf_2048)
static void C_fcall trf_2048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2048(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2048(t0,t1,t2);}

C_noret_decl(trf_2087)
static void C_fcall trf_2087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2087(t0,t1);}

C_noret_decl(trf_1918)
static void C_fcall trf_1918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1918(t0,t1);}

C_noret_decl(trf_1715)
static void C_fcall trf_1715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1715(t0,t1,t2);}

C_noret_decl(trf_1758)
static void C_fcall trf_1758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1758(t0,t1);}

C_noret_decl(trf_1685)
static void C_fcall trf_1685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1685(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1685(t0,t1,t2,t3);}

C_noret_decl(trf_1524)
static void C_fcall trf_1524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1524(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1524(t0,t1,t2,t3);}

C_noret_decl(trf_1576)
static void C_fcall trf_1576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1576(t0,t1);}

C_noret_decl(trf_1549)
static void C_fcall trf_1549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1549(t0,t1);}

C_noret_decl(trf_1512)
static void C_fcall trf_1512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1512(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1512(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1914)){
C_save(t1);
C_rereclaim2(1914*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,259);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],34,"\010compilerscan-toplevel-assignments");
lf[2]=C_h_intern(&lf[2],12,"always-bound");
lf[3]=C_h_intern(&lf[3],6,"append");
lf[4]=C_h_intern(&lf[4],18,"\010compilerdebugging");
lf[5]=C_h_intern(&lf[5],1,"o");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[7]=C_h_intern(&lf[7],12,"\003sysfor-each");
lf[8]=C_h_intern(&lf[8],13,"\004corevariable");
lf[9]=C_h_intern(&lf[9],2,"if");
lf[10]=C_h_intern(&lf[10],3,"let");
lf[11]=C_h_intern(&lf[11],6,"lambda");
lf[12]=C_h_intern(&lf[12],13,"\004corecallunit");
lf[13]=C_h_intern(&lf[13],9,"\004corecall");
lf[14]=C_h_intern(&lf[14],4,"set!");
lf[15]=C_h_intern(&lf[15],9,"\004corecond");
lf[16]=C_h_intern(&lf[16],11,"\004coreswitch");
lf[17]=C_h_intern(&lf[17],30,"call-with-current-continuation");
lf[18]=C_h_intern(&lf[18],1,"p");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[20]=C_h_intern(&lf[20],24,"\010compilersimplifications");
lf[21]=C_h_intern(&lf[21],23,"\010compilersimplified-ops");
lf[22]=C_h_intern(&lf[22],41,"\010compilerperform-high-level-optimizations");
lf[23]=C_h_intern(&lf[23],12,"\010compilerget");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],10,"alist-cons");
lf[26]=C_h_intern(&lf[26],4,"caar");
lf[27]=C_h_intern(&lf[27],7,"\003sysmap");
lf[28]=C_h_intern(&lf[28],19,"\010compilermatch-node");
lf[29]=C_h_intern(&lf[29],3,"any");
lf[30]=C_h_intern(&lf[30],18,"\003syshash-table-ref");
lf[31]=C_h_intern(&lf[31],30,"\010compilerbroken-constant-nodes");
lf[32]=C_h_intern(&lf[32],11,"lset-adjoin");
lf[33]=C_h_intern(&lf[33],3,"eq\077");
lf[34]=C_h_intern(&lf[34],4,"node");
lf[35]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[36]=C_h_intern(&lf[36],14,"\010compilerqnode");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[38]=C_h_intern(&lf[38],4,"eval");
lf[39]=C_h_intern(&lf[39],22,"with-exception-handler");
lf[40]=C_h_intern(&lf[40],5,"every");
lf[41]=C_h_intern(&lf[41],8,"foldable");
lf[42]=C_h_intern(&lf[42],16,"extended-binding");
lf[43]=C_h_intern(&lf[43],16,"standard-binding");
lf[44]=C_h_intern(&lf[44],5,"value");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[46]=C_h_intern(&lf[46],16,"\010compilervarnode");
lf[47]=C_h_intern(&lf[47],11,"collapsable");
lf[48]=C_h_intern(&lf[48],10,"replacable");
lf[49]=C_h_intern(&lf[49],9,"replacing");
lf[50]=C_h_intern(&lf[50],12,"contractable");
lf[51]=C_h_intern(&lf[51],9,"removable");
lf[52]=C_h_intern(&lf[52],11,"\004corelambda");
lf[53]=C_h_intern(&lf[53],6,"unused");
lf[54]=C_h_intern(&lf[54],9,"partition");
lf[55]=C_h_intern(&lf[55],26,"\010compilerbuild-lambda-list");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[57]=C_h_intern(&lf[57],13,"explicit-rest");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[59]=C_h_intern(&lf[59],30,"\010compilerdecompose-lambda-list");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[61]=C_h_intern(&lf[61],21,"has-unused-parameters");
lf[62]=C_h_intern(&lf[62],31,"\010compilerinline-lambda-bindings");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[64]=C_h_intern(&lf[64],24,"\010compilercheck-signature");
lf[65]=C_h_intern(&lf[65],30,"\010compilerconstant-declarations");
lf[66]=C_h_intern(&lf[66],14,"\004coreundefined");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[68]=C_h_intern(&lf[68],1,"x");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[70]=C_h_intern(&lf[70],37,"\010compilerexpression-has-side-effects\077");
lf[71]=C_h_intern(&lf[71],8,"assigned");
lf[72]=C_h_intern(&lf[72],10,"references");
lf[73]=C_h_intern(&lf[73],7,"unknown");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[75]=C_h_intern(&lf[75],1,"i");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\023procedure inlinable");
lf[77]=C_h_intern(&lf[77],14,"append-reverse");
lf[78]=C_h_intern(&lf[78],6,"gensym");
lf[79]=C_h_intern(&lf[79],1,"t");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[81]=C_h_intern(&lf[81],8,"split-at");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[83]=C_h_intern(&lf[83],20,"\004coreinline_allocate");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[85]=C_h_intern(&lf[85],24,"\010compilernot-inline-list");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilerinline-max-size");
lf[88]=C_h_intern(&lf[88],9,"inlinable");
lf[89]=C_h_intern(&lf[89],6,"simple");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[91]=C_h_intern(&lf[91],26,"\010compilerblock-compilation");
lf[92]=C_h_intern(&lf[92],20,"\010compilerexport-list");
lf[93]=C_h_intern(&lf[93],6,"global");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[97]=C_h_intern(&lf[97],5,"print");
lf[98]=C_h_intern(&lf[98],7,"newline");
lf[99]=C_h_intern(&lf[99],6,"print*");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[103]=C_h_intern(&lf[103],34,"\010compilerperform-pre-optimization!");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[105]=C_h_intern(&lf[105],24,"node-subexpressions-set!");
lf[106]=C_h_intern(&lf[106],20,"node-parameters-set!");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\034removed call in test-context");
lf[109]=C_h_intern(&lf[109],10,"call-sites");
lf[110]=C_h_intern(&lf[110],67,"\010compilerside-effect-free-standard-bindings-that-never-return-false");
lf[111]=C_h_intern(&lf[111],7,"reverse");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[113]=C_h_intern(&lf[113],3,"not");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[115]=C_h_intern(&lf[115],24,"register-simplifications");
lf[116]=C_h_intern(&lf[116],19,"\003syshash-table-set!");
lf[117]=C_h_intern(&lf[117],38,"\010compilerreorganize-recursive-bindings");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[119]=C_h_intern(&lf[119],10,"fold-right");
lf[120]=C_h_intern(&lf[120],4,"fold");
lf[121]=C_h_intern(&lf[121],25,"\010compilertopological-sort");
lf[122]=C_h_intern(&lf[122],6,"lset<=");
lf[123]=C_h_intern(&lf[123],10,"filter-map");
lf[124]=C_h_intern(&lf[124],6,"filter");
lf[125]=C_h_intern(&lf[125],10,"append-map");
lf[126]=C_h_intern(&lf[126],28,"\010compilerscan-used-variables");
lf[127]=C_h_intern(&lf[127],8,"for-each");
lf[128]=C_h_intern(&lf[128],3,"map");
lf[129]=C_h_intern(&lf[129],4,"cons");
lf[130]=C_h_intern(&lf[130],27,"\010compilersubstitution-table");
lf[131]=C_h_intern(&lf[131],16,"\010compilerrewrite");
lf[132]=C_h_intern(&lf[132],28,"\010compilersimplify-named-call");
lf[133]=C_h_intern(&lf[133],37,"\010compilerinline-substitutions-enabled");
lf[134]=C_h_intern(&lf[134],11,"\004coreinline");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[137]=C_h_intern(&lf[137],6,"unsafe");
lf[138]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[139]=C_h_intern(&lf[139],6,"vector");
lf[140]=C_h_intern(&lf[140],14,"rest-parameter");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[142]=C_h_intern(&lf[142],11,"number-type");
lf[143]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[147]=C_h_intern(&lf[147],6,"fixnum");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[149]=C_h_intern(&lf[149],21,"\010compilerfold-boolean");
lf[150]=C_h_intern(&lf[150],6,"flonum");
lf[151]=C_h_intern(&lf[151],7,"generic");
lf[152]=C_h_intern(&lf[152],5,"cons*");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[154]=C_h_intern(&lf[154],9,"\004coreproc");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_h_intern(&lf[163],19,"\010compilerfold-inner");
lf[164]=C_h_intern(&lf[164],6,"remove");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[169]=C_h_intern(&lf[169],5,"fifth");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_h_intern(&lf[171],13,"\010compilerbomb");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[173]=C_h_intern(&lf[173],34,"\010compilertransform-direct-lambdas!");
lf[174]=C_h_intern(&lf[174],19,"\010compilercopy-node!");
lf[175]=C_h_intern(&lf[175],16,"\004coredirect_call");
lf[176]=C_h_intern(&lf[176],4,"quit");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[178]=C_h_intern(&lf[178],15,"lset-difference");
lf[179]=C_h_intern(&lf[179],15,"node-class-set!");
lf[180]=C_h_intern(&lf[180],12,"\004corerecurse");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[182]=C_h_intern(&lf[182],4,"take");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[185]=C_h_intern(&lf[185],11,"\004corereturn");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[187]=C_h_intern(&lf[187],18,"\004coredirect_lambda");
lf[188]=C_h_intern(&lf[188],6,"cdaddr");
lf[189]=C_h_intern(&lf[189],6,"caaddr");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[192]=C_h_intern(&lf[192],6,"unzip1");
lf[193]=C_h_intern(&lf[193],16,"\003sysmake-promise");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[195]=C_h_intern(&lf[195],5,"boxed");
lf[196]=C_h_intern(&lf[196],15,"\004coreinline_ref");
lf[197]=C_h_intern(&lf[197],37,"\010compilerestimate-foreign-result-size");
lf[198]=C_h_intern(&lf[198],19,"\004coreinline_loc_ref");
lf[199]=C_h_intern(&lf[199],5,"lset=");
lf[200]=C_h_intern(&lf[200],6,"delete");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[202]=C_h_intern(&lf[202],32,"\010compilerperform-lambda-lifting!");
lf[203]=C_h_intern(&lf[203],23,"\003syshash-table-for-each");
lf[204]=C_h_intern(&lf[204],1,"+");
lf[205]=C_h_intern(&lf[205],17,"delete-duplicates");
lf[206]=C_h_intern(&lf[206],14,"\004coreprimitive");
lf[207]=C_h_intern(&lf[207],7,"delete!");
lf[208]=C_h_intern(&lf[208],11,"concatenate");
lf[209]=C_h_intern(&lf[209],5,"count");
lf[210]=C_h_intern(&lf[210],22,"\010compilerblock-globals");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[214]=C_h_intern(&lf[214],12,"pretty-print");
lf[215]=C_h_intern(&lf[215],1,"l");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[226]=C_h_intern(&lf[226],11,"make-vector");
lf[227]=C_h_intern(&lf[227],3,"var");
lf[228]=C_h_intern(&lf[228],2,"d2");
lf[229]=C_h_intern(&lf[229],1,"y");
lf[230]=C_h_intern(&lf[230],2,"d3");
lf[231]=C_h_intern(&lf[231],1,"z");
lf[232]=C_h_intern(&lf[232],2,"d1");
lf[233]=C_h_intern(&lf[233],2,"op");
lf[234]=C_h_intern(&lf[234],5,"clist");
lf[235]=C_h_intern(&lf[235],34,"\010compilermembership-test-operators");
lf[236]=C_h_intern(&lf[236],32,"\010compilermembership-unfold-limit");
lf[237]=C_h_intern(&lf[237],4,"var1");
lf[238]=C_h_intern(&lf[238],4,"var0");
lf[239]=C_h_intern(&lf[239],6,"const1");
lf[240]=C_h_intern(&lf[240],4,"var2");
lf[241]=C_h_intern(&lf[241],6,"const2");
lf[242]=C_h_intern(&lf[242],5,"body2");
lf[243]=C_h_intern(&lf[243],4,"rest");
lf[244]=C_h_intern(&lf[244],5,"body1");
lf[245]=C_h_intern(&lf[245],27,"\010compilereq-inline-operator");
lf[246]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[247]=C_h_intern(&lf[247],19,"\010compilerimmediate\077");
lf[248]=C_h_intern(&lf[248],5,"const");
lf[249]=C_h_intern(&lf[249],1,"n");
lf[250]=C_h_intern(&lf[250],7,"clauses");
lf[251]=C_h_intern(&lf[251],1,"d");
lf[252]=C_h_intern(&lf[252],4,"body");
lf[253]=C_h_intern(&lf[253],4,"more");
lf[254]=C_h_intern(&lf[254],4,"args");
lf[255]=C_h_intern(&lf[255],1,"a");
lf[256]=C_h_intern(&lf[256],1,"b");
lf[257]=C_h_intern(&lf[257],1,"c");
lf[258]=C_h_intern(&lf[258],4,"cdar");
C_register_lf2(lf,259,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1459,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1457 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1460 in k1457 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1463 in k1460 in k1457 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_mutate((C_word*)lf[1]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1476,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 144  make-vector */
t5=*((C_word*)lf[226]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1679,2,t0,t1);}
t2=C_mutate((C_word*)lf[20]+1,t1);
t3=C_set_block_item(lf[21],0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1682,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3153,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3614,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,lf[255]);
t9=(C_word)C_a_i_list(&a,2,lf[8],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[256],lf[257]);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[251],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[13],t12);
t14=(C_word)C_a_i_list(&a,4,lf[255],lf[256],lf[257],lf[251]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9563,tmp=(C_word)a,a+=2,tmp);
t16=(C_word)C_a_i_list(&a,3,t13,t14,t15);
/* optimizer.scm: 536  register-simplifications */
t17=C_retrieve(lf[115]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t7,lf[13],t16);}

/* a9562 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_9563,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9571,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 542  ##sys#hash-table-ref */
t8=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,C_retrieve(lf[130]),t3);}

/* k9569 in a9562 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9571,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_9576(t6,((C_word*)t0)[2],t2);}

/* loop in k9569 in a9562 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_9576(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9576,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9586,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9621,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 544  caar */
t5=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k9619 in loop in k9569 in a9562 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9625,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 544  cdar */
t3=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9623 in k9619 in loop in k9569 in a9562 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 544  simplify-named-call */
t2=C_retrieve(lf[132]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9584 in loop in k9569 in a9562 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9586,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[21]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9595,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_9595(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9610,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 549  alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[21]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 551  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9576(t3,((C_word*)t0)[4],t2);}}

/* k9608 in k9584 in loop in k9569 in a9562 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[21]+1,t1);
t3=((C_word*)t0)[2];
f_9595(t3,t2);}

/* k9593 in k9584 in loop in k9569 in a9562 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_9595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[237]);
t4=(C_word)C_a_i_list(&a,1,lf[233]);
t5=(C_word)C_a_i_list(&a,1,lf[238]);
t6=(C_word)C_a_i_list(&a,2,lf[8],t5);
t7=(C_word)C_a_i_list(&a,1,lf[239]);
t8=(C_word)C_a_i_list(&a,2,lf[24],t7);
t9=(C_word)C_a_i_list(&a,4,lf[134],t4,t6,t8);
t10=(C_word)C_a_i_list(&a,1,lf[237]);
t11=(C_word)C_a_i_list(&a,2,lf[8],t10);
t12=(C_word)C_a_i_list(&a,1,lf[240]);
t13=(C_word)C_a_i_list(&a,1,lf[233]);
t14=(C_word)C_a_i_list(&a,1,lf[238]);
t15=(C_word)C_a_i_list(&a,2,lf[8],t14);
t16=(C_word)C_a_i_list(&a,1,lf[241]);
t17=(C_word)C_a_i_list(&a,2,lf[24],t16);
t18=(C_word)C_a_i_list(&a,4,lf[134],t13,t15,t17);
t19=(C_word)C_a_i_list(&a,1,lf[240]);
t20=(C_word)C_a_i_list(&a,2,lf[8],t19);
t21=(C_word)C_a_i_list(&a,5,lf[9],lf[228],t20,lf[242],lf[243]);
t22=(C_word)C_a_i_list(&a,4,lf[10],t12,t18,t21);
t23=(C_word)C_a_i_list(&a,5,lf[9],lf[232],t11,lf[244],t22);
t24=(C_word)C_a_i_list(&a,4,lf[10],t3,t9,t23);
t25=(C_word)C_a_i_list(&a,11,lf[238],lf[237],lf[240],lf[233],lf[239],lf[241],lf[244],lf[242],lf[232],lf[228],lf[243]);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9400,tmp=(C_word)a,a+=2,tmp);
t27=(C_word)C_a_i_list(&a,3,t24,t25,t26);
t28=(C_word)C_a_i_list(&a,1,lf[227]);
t29=(C_word)C_a_i_list(&a,1,lf[233]);
t30=(C_word)C_a_i_list(&a,1,lf[238]);
t31=(C_word)C_a_i_list(&a,2,lf[8],t30);
t32=(C_word)C_a_i_list(&a,1,lf[248]);
t33=(C_word)C_a_i_list(&a,2,lf[24],t32);
t34=(C_word)C_a_i_list(&a,4,lf[134],t29,t31,t33);
t35=(C_word)C_a_i_list(&a,1,lf[227]);
t36=(C_word)C_a_i_list(&a,2,lf[8],t35);
t37=(C_word)C_a_i_list(&a,1,lf[249]);
t38=(C_word)C_a_i_list(&a,1,lf[238]);
t39=(C_word)C_a_i_list(&a,2,lf[8],t38);
t40=(C_word)C_a_i_cons(&a,2,t39,lf[250]);
t41=(C_word)C_a_i_cons(&a,2,t37,t40);
t42=(C_word)C_a_i_cons(&a,2,lf[16],t41);
t43=(C_word)C_a_i_list(&a,5,lf[9],lf[251],t36,lf[252],t42);
t44=(C_word)C_a_i_list(&a,4,lf[10],t28,t34,t43);
t45=(C_word)C_a_i_list(&a,8,lf[227],lf[233],lf[238],lf[248],lf[251],lf[252],lf[249],lf[250]);
t46=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9278,tmp=(C_word)a,a+=2,tmp);
t47=(C_word)C_a_i_list(&a,3,t44,t45,t46);
t48=(C_word)C_a_i_list(&a,1,lf[237]);
t49=(C_word)C_a_i_list(&a,2,lf[66],C_SCHEME_END_OF_LIST);
t50=(C_word)C_a_i_list(&a,4,lf[10],t48,t49,lf[253]);
t51=(C_word)C_a_i_list(&a,2,lf[237],lf[253]);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9010,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_list(&a,3,t50,t51,t52);
t54=(C_word)C_a_i_list(&a,1,lf[227]);
t55=(C_word)C_a_i_list(&a,1,lf[233]);
t56=(C_word)C_a_i_cons(&a,2,t55,lf[254]);
t57=(C_word)C_a_i_cons(&a,2,lf[134],t56);
t58=(C_word)C_a_i_list(&a,1,lf[227]);
t59=(C_word)C_a_i_list(&a,2,lf[8],t58);
t60=(C_word)C_a_i_list(&a,5,lf[9],lf[251],t59,lf[68],lf[229]);
t61=(C_word)C_a_i_list(&a,4,lf[10],t54,t57,t60);
t62=(C_word)C_a_i_list(&a,6,lf[227],lf[233],lf[254],lf[251],lf[68],lf[229]);
t63=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8934,tmp=(C_word)a,a+=2,tmp);
t64=(C_word)C_a_i_list(&a,3,t61,t62,t63);
/* optimizer.scm: 554  register-simplifications */
t65=C_retrieve(lf[115]);
((C_proc7)C_retrieve_proc(t65))(7,t65,t2,lf[10],t27,t47,t53,t64);}

/* a8933 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8934,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[245])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8968,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 689  get */
t10=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,t2,t3,lf[72]);}}

/* k8966 in a8933 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8968,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[34],lf[9],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9010,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9020,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9020(t9,t1,t5,t4);}

/* loop1 in a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_9020(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9020,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_car(t9);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_slot(t12,C_fix(3));
t15=(C_word)C_slot(t12,C_fix(1));
t16=(C_word)C_eqp(t15,lf[66]);
if(C_truep(t16)){
t17=(C_word)C_i_car(t7);
t18=(C_word)C_a_i_cons(&a,2,t17,t2);
t19=(C_word)C_i_cadr(t9);
/* optimizer.scm: 635  loop1 */
t23=t1;
t24=t18;
t25=t19;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t17=(C_word)C_eqp(t15,lf[14]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9084,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t14,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 637  reverse */
t19=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t2);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k9082 in loop1 in a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9084,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_9113(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k9082 in loop1 in a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_9113(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9113,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9129,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[10]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9236,a[2]=t10,a[3]=t3,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t8);
/* optimizer.scm: 648  get */
t16=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t14,((C_word*)t0)[2],t15,lf[72]);}
else{
t14=t11;
f_9129(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_9129(t13,C_SCHEME_FALSE);}}

/* k9234 in loop2 in k9082 in loop1 in a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9129(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[14],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_9129(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_9129(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_9129(t2,C_SCHEME_FALSE);}}}

/* k9127 in loop2 in k9082 in loop1 in a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_9129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9129,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm: 652  loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_9113(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9166,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9176,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 656  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a9175 in k9127 in loop2 in k9082 in loop1 in a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9176,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a9165 in k9127 in loop2 in k9082 in loop1 in a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 657  reverse */
t3=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9172 in a9165 in k9127 in loop2 in k9082 in loop1 in a9009 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 657  reorganize-recursive-bindings */
t2=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a9277 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_9278,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[245])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9291,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 601  immediate? */
t12=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k9289 in a9277 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9291,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9326,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 602  get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9324 in k9289 in a9277 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9326,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9303,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 606  varnode */
t8=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9308 in k9324 in k9289 in a9277 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 607  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9312 in k9308 in k9324 in k9289 in a9277 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 606  cons* */
t2=C_retrieve(lf[152]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9301 in k9324 in k9289 in a9277 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9303,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[16],((C_word*)t0)[2],t1));}

/* a9399 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_9400,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[245])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9413,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 574  immediate? */
t15=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k9411 in a9399 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9413,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 575  immediate? */
t3=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9417 in k9411 in a9399 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9419,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 576  get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9463 in k9417 in k9411 in a9399 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9465,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 577  get */
t5=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[72]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9455 in k9463 in k9417 in k9411 in a9399 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9457,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9441,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 581  varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9439 in k9455 in k9463 in k9417 in k9411 in a9399 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 582  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9443 in k9439 in k9455 in k9463 in k9417 in k9411 in a9399 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9449,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 584  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9447 in k9443 in k9439 in k9455 in k9463 in k9417 in k9411 in a9399 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_9449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9449,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[16],lf[246],t2));}

/* k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[227]);
t4=(C_word)C_a_i_list(&a,2,lf[8],t3);
t5=(C_word)C_a_i_list(&a,4,lf[13],lf[228],t4,lf[229]);
t6=(C_word)C_a_i_list(&a,1,lf[227]);
t7=(C_word)C_a_i_list(&a,2,lf[8],t6);
t8=(C_word)C_a_i_list(&a,4,lf[13],lf[230],t7,lf[231]);
t9=(C_word)C_a_i_list(&a,5,lf[9],lf[232],lf[68],t5,t8);
t10=(C_word)C_a_i_list(&a,7,lf[232],lf[228],lf[230],lf[68],lf[229],lf[231],lf[227]);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8863,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_a_i_list(&a,3,t9,t10,t11);
t13=(C_word)C_a_i_list(&a,1,lf[233]);
t14=(C_word)C_a_i_list(&a,1,lf[234]);
t15=(C_word)C_a_i_list(&a,2,lf[24],t14);
t16=(C_word)C_a_i_list(&a,4,lf[134],t13,lf[68],t15);
t17=(C_word)C_a_i_list(&a,5,lf[9],lf[232],t16,lf[229],lf[231]);
t18=(C_word)C_a_i_list(&a,6,lf[232],lf[233],lf[68],lf[234],lf[229],lf[231]);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8752,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_list(&a,3,t17,t18,t19);
/* optimizer.scm: 696  register-simplifications */
t21=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t2,lf[9],t12,t20);}

/* a8751 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8752,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[235]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[236]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8774,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 727  gensym */
t13=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8772 in a8751 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8774,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8797,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8799,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8829,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 744  qnode */
t9=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_FALSE);}

/* k8827 in k8772 in a8751 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 736  fold-right */
t2=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a8798 in k8772 in a8751 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8799,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8821,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 741  varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k8819 in a8798 in k8772 in a8751 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 741  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8823 in k8819 in a8798 in k8772 in a8751 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8825,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 742  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k8815 in k8823 in k8819 in a8798 in k8772 in a8751 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8817,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[15],C_SCHEME_END_OF_LIST,t2));}

/* k8795 in k8772 in a8751 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8797,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[9],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t4));}

/* a8862 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_8863,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8877,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 712  varnode */
t11=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8875 in a8862 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8877,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[15],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t4));}

/* k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3629,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3955,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 839  make-vector */
t4=*((C_word*)lf[226]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1,t1);
t3=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3957,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3977,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5957,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7092,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7092,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7095,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7195,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7392,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7491,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7735,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7954,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8155,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8405,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8492,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8639,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1817 debugging */
t16=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[18],lf[225]);}

/* k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1818 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_7095(t3,t2);}

/* k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8645,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1819 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[224]);}

/* k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1820 build-call-graph */
t3=((C_word*)t0)[2];
f_7195(t3,t2,((C_word*)t0)[3]);}

/* k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8651,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1821 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[223]);}

/* k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8654,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1822 eliminate */
t3=((C_word*)t0)[4];
f_7392(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8657,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8731,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1823 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[222]);}

/* k8729 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1823 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8657(2,t2,C_SCHEME_UNDEFINED);}}

/* k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1824 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[221]);}

/* k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1825 collect-accessibles */
t3=((C_word*)t0)[2];
f_7491(t3,t2,((C_word*)t0)[3]);}

/* k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8725,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1826 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[220]);}

/* k8723 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1826 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8666(2,t2,C_SCHEME_UNDEFINED);}}

/* k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1827 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[219]);}

/* k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8672,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8722,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1828 eliminate4 */
t4=((C_word*)t0)[3];
f_7735(t4,t3,((C_word*)t0)[2]);}

/* k8720 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8722,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7701,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7701(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8720 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7701(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7701,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7705,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7719,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1622 filter */
t6=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,t2);}

/* a7718 in loop in k8720 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7719,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1622 every */
t5=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a7724 in a7718 in loop in k8720 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7725,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k7703 in loop in k8720 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1626 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7701(t5,((C_word*)t0)[3],t1,t2);}}

/* k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8712,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8714,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1829 ##sys#make-promise */
t5=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8713 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8714,2,t0,t1);}
/* optimizer.scm: 1829 unzip1 */
t2=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k8710 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1829 debugging */
t2=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[5],lf[218],t1);}

/* k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1830 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[217]);}

/* k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1831 compute-extra-variables */
t3=((C_word*)t0)[2];
f_7954(t3,t2,((C_word*)t0)[5]);}

/* k8679 in k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8705,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1832 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[216]);}

/* k8703 in k8679 in k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1832 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8684(2,t2,C_SCHEME_UNDEFINED);}}

/* k8682 in k8679 in k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1833 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[213]);}

/* k8685 in k8682 in k8679 in k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8690,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1834 extend-call-sites! */
t3=((C_word*)t0)[2];
f_8405(t3,t2,((C_word*)t0)[4]);}

/* k8688 in k8685 in k8682 in k8679 in k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1835 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[212]);}

/* k8691 in k8688 in k8685 in k8682 in k8679 in k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1836 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_8492(t3,t2,((C_word*)t0)[4]);}

/* k8694 in k8691 in k8688 in k8685 in k8682 in k8679 in k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1837 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[211]);}

/* k8697 in k8694 in k8691 in k8688 in k8685 in k8682 in k8679 in k8676 in k8673 in k8670 in k8667 in k8664 in k8661 in k8658 in k8655 in k8652 in k8649 in k8646 in k8643 in k8640 in k8637 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1838 reconstruct! */
t2=((C_word*)t0)[5];
f_8155(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_8492(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8492,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8498,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8498(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8498,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8517,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t10,((C_word*)((C_word*)t0)[2])[1],t12);}
else{
t10=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8610,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
/* for-each */
t14=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,((C_word*)((C_word*)t0)[2])[1],t13);}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* k8608 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8610,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1812 node-class-set! */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[66]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8617 in k8608 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1813 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8620 in k8617 in k8608 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1814 node-subexpressions-set! */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8515 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8517,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8522,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_8522(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do1385 in k8515 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_8522(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8522,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1802 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8545,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8560,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1804 reverse */
t6=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8563,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_8563(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_8563(t12,t11);}}}

/* k8561 in do1385 in k8515 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_8563(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_8522(t4,((C_word*)t0)[2],t2,t3);}

/* k8558 in do1385 in k8515 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1804 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8543 in do1385 in k8515 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8552,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8556,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1805 reverse */
t4=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k8554 in k8543 in do1385 in k8515 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1805 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8550 in k8543 in do1385 in k8515 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1805 node-subexpressions-set! */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_8405(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8405,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8411,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8411(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8411,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[13]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8433,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[8],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8463,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8467,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
/* map */
t21=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[46]),t20);}
else{
t17=t11;
f_8433(2,t17,C_SCHEME_UNDEFINED);}}
else{
t14=t11;
f_8433(2,t14,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t10=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}

/* k8465 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1784 append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k8461 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8463,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1782 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8431 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
/* for-each */
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_8155(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8155,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8167,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8169,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
/* optimizer.scm: 1718 fold-right */
t9=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,t2);}

/* a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8169,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8176,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1721 get */
t6=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t4,lf[44]);}

/* k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8176,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_retrieve(lf[210]));
t3=C_mutate((C_word*)lf[210]+1,t2);
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8189,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1723 decompose-lambda-list */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8189,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8196,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[78]),t6);}

/* k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8199,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1728 map */
t3=*((C_word*)lf[128]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[5],t1);}

/* k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8280,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8295,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_8295(3,t9,t2,t4);}

/* walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[28],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8295,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8314,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8321,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[8]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8338,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
/* optimizer.scm: 1757 rename */
t13=((C_word*)t0)[2];
f_8280(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8351,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8362,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 1759 rename */
t15=((C_word*)t0)[2];
f_8280(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1762 decompose-lambda-list */
t15=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,t13,t14);}
else{
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}}}

/* a8380 in walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8381(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8381,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8396,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8400,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k8398 in a8380 in walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1765 build-lambda-list */
t2=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8394 in a8380 in walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1766 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8295(3,t4,((C_word*)t0)[2],t3);}

/* k8360 in walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8362,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1759 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8349 in walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k8336 in walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8338,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1757 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8319 in walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1754 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8312 in walk in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8280,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k8200 in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1731 gensym */
t3=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[79]);}

/* k8249 in k8200 in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8251,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8235,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8239,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1737 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8237 in k8249 in k8200 in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1737 build-lambda-list */
t4=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8233 in k8249 in k8200 in k8197 in k8194 in a8188 in k8174 in a8168 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8235,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[11],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[34],lf[14],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t7));}

/* k8165 in reconstruct! in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8167,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1715 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7954(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7954,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8019,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8141,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a8140 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8141,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8019,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8021,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8096,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8101,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8101,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8139,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1704 get */
t5=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,lf[44]);}

/* k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8139,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7963,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7963(3,t8,t4,t1);}

/* walk in k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7963,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7983,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1680 append */
t11=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8001,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1683 decompose-lambda-list */
t13=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t13))(4,t13,t1,t11,t12);}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* a8000 in walk in k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8001,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8006,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1686 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k8004 in a8000 in walk in k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1687 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7963(3,t4,((C_word*)t0)[2],t3);}

/* k7981 in walk in k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7959 in k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7961,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8115,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8117,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8131,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1710 delete-duplicates */
t7=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,*((C_word*)lf[33]+1));}

/* k8129 in k7959 in k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1706 remove */
t2=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8116 in k7959 in k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8117,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k8113 in k7959 in k8137 in a8100 in k8094 in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8115,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8021,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8089,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1695 count */
t6=C_retrieve(lf[209]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a8088 in walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8089,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k8085 in walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8087,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8041,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a8074 in k8085 in walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8075,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1698 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8021(3,t4,t1,t3);}

/* k8039 in k8085 in walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8041,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8051,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8059,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8063,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8065,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a8064 in k8039 in k8085 in walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8065,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k8061 in k8039 in k8085 in walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1700 concatenate */
t2=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8057 in k8039 in k8085 in walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1700 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8049 in k8039 in k8085 in walk in k8017 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_8051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7735,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7739,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7741,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7741(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7741(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7741,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7760,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_7760(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t12)){
t13=t11;
f_7760(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t13)){
t14=t11;
f_7760(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[206]);
t15=t11;
f_7760(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[154])));}}}}

/* k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7760,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7771,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7771(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7822,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1645 decompose-lambda-list */
t6=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1651 call-with-current-continuation */
t8=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7927,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a7926 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7927,3,t0,t1,t2);}
/* optimizer.scm: 1666 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7741(t3,t1,t2,((C_word*)t0)[2]);}

/* a7856 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7857(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7857,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[8],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7873,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_7873(3,t12,t1,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a7856 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7873,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7893,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7903,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1660 lset<= */
t9=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[33]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k7901 in loop in a7856 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7903,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_7893(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7907,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1662 delete! */
t3=C_retrieve(lf[207]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[33]+1));}}

/* k7905 in k7901 in loop in a7856 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1663 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7891 in loop in a7856 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7844 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7850 in k7844 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7851,3,t0,t1,t2);}
/* optimizer.scm: 1665 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7741(t3,t1,t2,((C_word*)t0)[2]);}

/* a7821 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7822,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7834,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1648 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7832 in a7821 in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1648 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7741(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7771(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7771,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7789,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1640 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7792,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1642 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7741(t6,t4,t5,((C_word*)t0)[3]);}}

/* k7790 in loop in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1643 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7771(t4,((C_word*)t0)[2],t2,t3);}

/* k7787 in loop in k7758 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1640 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7741(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7737 in eliminate4 in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7491(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7491,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7495,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7497,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_7497(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7497(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7497,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_7516(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t12)){
t13=t11;
f_7516(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t13)){
t14=t11;
f_7516(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[206]);
t15=t11;
f_7516(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[154])));}}}}

/* k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7516,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7527,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7527(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7609,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1597 alist-cons */
t9=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_7575(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_7575(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7618,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a7617 in k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7618,3,t0,t1,t2);}
/* optimizer.scm: 1603 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7497(t3,t1,t2,((C_word*)t0)[2]);}

/* k7607 in k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7575(t3,t2);}

/* k7573 in k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7575,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1598 decompose-lambda-list */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a7583 in k7573 in k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7584,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7596,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1601 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7594 in a7583 in k7573 in k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1601 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7497(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7527(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7527,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7545,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1588 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7548,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1590 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7497(t6,t4,t5,((C_word*)t0)[3]);}}

/* k7546 in loop in k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1591 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7527(t4,((C_word*)t0)[2],t2,t3);}

/* k7543 in loop in k7514 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1588 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7497(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7493 in collect-accessibles in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7392(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7392,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7398,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1558 remove */
t5=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7398,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7432,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7442,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1568 unzip1 */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k7440 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7442,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7447,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7447(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k7440 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7447(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7447,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7454,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1571 lset-difference */
t7=C_retrieve(lf[178]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t5,*((C_word*)lf[33]+1),t6,t3,((C_word*)t0)[2]);}

/* k7452 in count in k7440 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7481,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1572 delete-duplicates */
t4=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,*((C_word*)lf[33]+1));}

/* k7479 in k7452 in count in k7440 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7481,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1573 append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7475 in k7479 in k7452 in count in k7440 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7477,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7467,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7469,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7468 in k7475 in k7479 in k7452 in count in k7440 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7469,3,t0,t1,t2);}
/* optimizer.scm: 1574 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7447(t3,t1,t2,((C_word*)t0)[2]);}

/* k7465 in k7475 in k7479 in k7452 in count in k7440 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1574 fold */
t2=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[204]+1),((C_word*)t0)[2],t1);}

/* k7430 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7432,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1561 any */
t5=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[5],t3,t4);}}

/* a7409 in k7430 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7410,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7417,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1562 get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],t2,lf[71]);}

/* k7415 in a7409 in k7430 in a7397 in eliminate in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7195,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7198,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7347,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7349,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t14=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a7348 in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7349,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7364,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7374,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1547 decompose-lambda-list */
t11=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t6,t10);}

/* a7373 in a7348 in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7374,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
/* optimizer.scm: 1550 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7198(t7,t1,t6,t2);}

/* k7362 in a7348 in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7368,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1551 alist-cons */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k7366 in k7362 in a7348 in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7345 in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7198(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7198,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[14]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7223,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7248,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_7248(2,t16,t14);}
else{
/* optimizer.scm: 1523 get */
t16=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t15,((C_word*)t0)[2],t12,lf[93]);}}
else{
t12=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7266,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_7266(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7320,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1535 decompose-lambda-list */
t16=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7337,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t9);}}}}

/* a7336 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7337,3,t0,t1,t2);}
/* optimizer.scm: 1538 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7198(t3,t1,t2,((C_word*)t0)[2]);}

/* a7319 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7320(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7320,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7332,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1537 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7330 in a7319 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1537 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7198(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7266(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7266,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7284,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1530 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7290,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1532 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_7198(t7,t5,t6,((C_word*)t0)[3]);}}

/* k7288 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1533 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7266(t4,((C_word*)t0)[2],t2,t3);}

/* k7282 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1530 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7198(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7246 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7248,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_7223(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_7223(t4,t3);}}

/* k7221 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7223,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_7226(t5,t4);}
else{
t3=t2;
f_7226(t3,C_SCHEME_UNDEFINED);}}

/* k7224 in k7221 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7226,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7231,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7230 in k7224 in k7221 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7231,3,t0,t1,t2);}
/* optimizer.scm: 1526 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7198(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7095(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7095,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7099,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7101,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1494 ##sys#hash-table-for-each */
t6=C_retrieve(lf[203]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7100 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7101(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7101,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[44],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[72],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[109],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7132,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[73],t3))){
t10=t9;
f_7132(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[11],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[93],t3))){
t13=t9;
f_7132(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_7132(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_7132(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k7130 in a7100 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_7132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7132,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1505 alist-cons */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7134 in k7130 in a7100 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7136,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7140,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1506 alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k7138 in k7134 in k7130 in a7100 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7097 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5957,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6541,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6122,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5960,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7087,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1473 debugging */
t18=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t17,lf[18],lf[201]);}

/* k7085 in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7090,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1474 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5960(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7088 in k7085 in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_5960(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(30);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5960,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[52]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5985,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6070,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1267 get */
t15=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[2],t2,lf[73]);}
else{
t14=t13;
f_5985(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_5985(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[14]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
/* optimizer.scm: 1277 walk */
t24=t1;
t25=t13;
t26=t14;
t27=C_SCHEME_FALSE;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[10]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6096,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
/* optimizer.scm: 1279 walk */
t24=t14;
t25=t15;
t26=t16;
t27=t3;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t15=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t8);}}}}

/* a6115 in walk in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6116,3,t0,t1,t2);}
/* optimizer.scm: 1281 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5960(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k6094 in walk in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1280 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5960(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k6068 in walk in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6070,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_5985(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1269 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[44]);}
else{
t2=((C_word*)t0)[9];
f_5985(2,t2,C_SCHEME_FALSE);}}}

/* k6014 in k6068 in walk in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6016,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1270 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[72]);}
else{
t2=((C_word*)t0)[4];
f_5985(2,t2,C_SCHEME_FALSE);}}

/* k6020 in k6014 in k6068 in walk in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6022,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6028,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1271 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[109]);}
else{
t2=((C_word*)t0)[4];
f_5985(2,t2,C_SCHEME_FALSE);}}

/* k6026 in k6020 in k6014 in k6068 in walk in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1274 scan */
t9=((C_word*)t0)[4];
f_6122(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_5985(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5985(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_5985(2,t2,C_SCHEME_FALSE);}}

/* k5983 in walk in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1275 transform */
t2=((C_word*)t0)[11];
f_6541(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1276 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5960(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_6122(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6122,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6125,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6532,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1360 rec */
t18=((C_word*)t12)[1];
f_6125(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k6530 in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6532,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1361 delete */
t3=C_retrieve(lf[200]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[33]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6537 in k6530 in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1361 lset= */
t2=C_retrieve(lf[199]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[33]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_6125(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(68);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6125,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[8]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1292 get */
t15=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[9],t13,lf[195]);}
else{
t13=(C_word)C_eqp(t11,lf[52]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6192,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1300 decompose-lambda-list */
t16=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[83]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6229,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1309 every */
t20=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t20))(4,t20,t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[187]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6263,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
/* optimizer.scm: 1312 scan-used-variables */
t18=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[196]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6279,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
/* optimizer.scm: 1317 estimate-foreign-result-size */
t19=C_retrieve(lf[197]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[198]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6320,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
/* optimizer.scm: 1325 estimate-foreign-result-size */
t20=C_retrieve(lf[197]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[13]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[8],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6373,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6401,a[2]=t24,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_slot(t27,C_fix(1));
t30=(C_word)C_eqp(lf[8],t29);
if(C_truep(t30)){
t31=(C_word)C_slot(t27,C_fix(2));
t32=(C_word)C_i_car(t31);
t33=(C_word)C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[3])[1]);
t34=C_mutate(((C_word *)((C_word*)t0)[3])+1,t33);
t35=t28;
f_6401(t35,t34);}
else{
t31=t28;
f_6401(t31,C_SCHEME_UNDEFINED);}}
else{
t27=t24;
f_6373(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_6373(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6462,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1351 every */
t26=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t26))(4,t26,t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[14]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
/* optimizer.scm: 1352 rec */
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[10]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6495,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
/* optimizer.scm: 1354 rec */
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6519,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1356 every */
t23=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t23))(4,t23,t1,t22,t9);}}}}}}}}}}}

/* a6518 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6519,3,t0,t1,t2);}
/* optimizer.scm: 1356 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6125(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6493 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6495,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6506,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1355 append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6504 in k6493 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1355 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6125(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a6461 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6462,3,t0,t1,t2);}
/* optimizer.scm: 1351 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6125(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6399 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_6401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_6373(t3,C_SCHEME_TRUE);}

/* k6371 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_6373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6373,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1344 every */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6377 in k6371 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6378,3,t0,t1,t2);}
/* optimizer.scm: 1344 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6125(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6318 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6326,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6326(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_6326(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_6326(t7,C_SCHEME_TRUE);}}}

/* k6324 in k6318 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_6326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6326,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6331,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1331 every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6330 in k6324 in k6318 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6331,3,t0,t1,t2);}
/* optimizer.scm: 1331 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6125(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6277 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6279,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6285(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_6285(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_6285(t7,C_SCHEME_TRUE);}}}

/* k6283 in k6277 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_6285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6285,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1323 every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6289 in k6283 in k6277 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6290,3,t0,t1,t2);}
/* optimizer.scm: 1323 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6125(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6261 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6263,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1314 alist-cons */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6257 in k6261 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a6228 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6229,3,t0,t1,t2);}
/* optimizer.scm: 1309 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6125(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a6191 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6192,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6208,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1304 append */
t9=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t2,((C_word*)t0)[2]);}

/* k6206 in a6191 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1304 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6125(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k6172 in rec in scan in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_6541(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6541,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6545,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7075,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7077,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1365 ##sys#make-promise */
t11=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1366 debugging */
t9=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,lf[5],lf[194],t3,t7);}}

/* a7076 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7077,2,t0,t1);}
/* optimizer.scm: 1365 unzip1 */
t2=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k7073 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1365 debugging */
t2=C_retrieve(lf[4]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[5],lf[191],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6545,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1371 get */
t10=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[109]);}

/* k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7049,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* cdaddr */
t9=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,((C_word*)t0)[11]);}
else{
t8=t4;
f_6561(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6561(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_6561(t6,C_SCHEME_FALSE);}}
else{
t5=t4;
f_6561(t5,C_SCHEME_FALSE);}}

/* k7047 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_listp(t1))){
t2=(C_word)C_i_cdddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cddddr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
f_6561(t4,(C_word)C_i_nullp(t3));}
else{
t3=((C_word*)t0)[2];
f_6561(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_6561(t2,C_SCHEME_FALSE);}}

/* k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_6561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6561,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* caaddr */
t4=*((C_word*)lf[189]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[13]);}
else{
/* ##compiler#bomb */
t2=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[10],lf[190],((C_word*)t0)[13]);}}

/* k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* cdaddr */
t3=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6570,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1378 node-class-set! */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[187]);}

/* k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6579,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6752,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6752(3,t9,t2,t5);}

/* rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6752,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[13]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[8],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1392 alist-cons */
t19=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t19))(5,t19,t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6927,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1417 node-class-set! */
t21=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t21))(4,t21,t20,t2,lf[185]);}
else{
/* optimizer.scm: 1420 bomb */
t20=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t1,lf[186]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6974,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1425 alist-cons */
t14=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}}

/* k6972 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6974,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1426 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* k6975 in k6972 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1427 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6752(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6925 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1418 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6928 in k6925 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1419 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6796,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_6805(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1395 quit */
t9=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[181],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6851,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_6851(2,t14,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1406 quit */
t14=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t10,lf[183],((C_word*)t0)[4]);}}
else{
/* optimizer.scm: 1415 bomb */
t7=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[8],lf[184],((C_word*)t0)[11]);}}}

/* k6849 in k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1409 node-class-set! */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[10]);}

/* k6852 in k6849 in k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6881,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
/* optimizer.scm: 1410 take */
t6=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t5,C_fix(1));}

/* k6879 in k6852 in k6849 in k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1410 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6855 in k6852 in k6849 in k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6860,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[180],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 1411 node-subexpressions-set! */
t7=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[2],t6);}

/* k6858 in k6855 in k6852 in k6849 in k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1414 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6752(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6803 in k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1398 node-class-set! */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[180]);}

/* k6806 in k6803 in k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1399 node-parameters-set! */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[3],t3);}

/* k6809 in k6806 in k6803 in k6794 in rec in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1400 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6582,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6675,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6732,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6734,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1448 lset-difference */
t6=C_retrieve(lf[178]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a6733 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6734,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k6730 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6674 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6675,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6685,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[3],t7);
if(C_truep(t8)){
t9=t5;
f_6685(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1438 quit */
t9=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[177],((C_word*)t0)[2]);}}

/* k6683 in a6674 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6685,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[175],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t2,t7);
/* optimizer.scm: 1441 node-subexpressions-set! */
t9=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k6580 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6582,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[34],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6594,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1453 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6592 in k6580 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6633,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1455 fold-right */
t4=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6632 in k6592 in k6580 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6633,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[34],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t5,t13));}

/* k6595 in k6592 in k6580 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1464 copy-node! */
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6598 in k6595 in k6592 in k6580 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6605,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6604 in k6598 in k6595 in k6592 in k6580 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6605,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6612,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6631,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1468 gensym */
t6=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6629 in a6604 in k6598 in k6595 in k6592 in k6580 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6631,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1468 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6610 in a6604 in k6598 in k6595 in k6592 in k6580 in k6577 in k6574 in k6568 in k6565 in k6559 in k6553 in k6543 in transform in ##compiler#transform-direct-lambdas! in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6612,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t2,t3));}

/* ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word ab[182],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_3977,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3980,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
switch(t6){
case C_fix(1):
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4034,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 857  test */
t11=t9;
f_3980(t11,t10,t4,lf[43]);
case C_fix(2):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4142,a[2]=t4,a[3]=t9,a[4]=t2,a[5]=t1,a[6]=t5,a[7]=t8,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 875  test */
t14=t9;
f_3980(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4246,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 893  test */
t11=t9;
f_3980(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep(C_retrieve(lf[137]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(2),t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4290,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 901  test */
t13=t9;
f_3980(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4346,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 913  test */
t11=t9;
f_3980(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(6):
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[133]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_eqp(C_fix(1),t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4439,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 929  test */
t15=t9;
f_3980(t15,t14,t4,lf[43]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(7):
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[133]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t12,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4504,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 941  test */
t16=t9;
f_3980(t16,t15,t4,lf[43]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4565,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t2,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 951  test */
t11=t9;
f_3980(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4592,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 959  test */
t11=t9;
f_3980(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4736,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 986  test */
t13=t9;
f_3980(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4823,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1003 test */
t13=t9;
f_3980(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4888,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1016 test */
t11=t9;
f_3980(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4964,a[2]=t4,a[3]=t9,a[4]=t3,a[5]=t8,a[6]=t5,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1029 test */
t11=t9;
f_3980(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_cadr(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5029,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1040 test */
t14=t9;
f_3980(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(1),t10);
if(C_truep(t11)){
t12=C_retrieve(lf[137]);
t13=(C_truep(t12)?t12:(C_word)C_i_cadddr(t7));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5112,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1058 test */
t15=t9;
f_3980(t15,t14,t4,lf[42]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(16):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_i_not(t10);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t11,t10));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5205,a[2]=t4,a[3]=t9,a[4]=t11,a[5]=t12,a[6]=t1,a[7]=t5,a[8]=t8,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1079 test */
t16=t9;
f_3980(t16,t15,t4,lf[42]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5284,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1096 test */
t14=t9;
f_3980(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5352,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1110 test */
t11=t9;
f_3980(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5387,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1120 test */
t11=t9;
f_3980(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(20):
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
t12=(C_truep(t11)?t11:C_retrieve(lf[137]));
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t10,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5535,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t10,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1149 test */
t16=t9;
f_3980(t16,t15,t4,lf[43]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5608,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1167 test */
t11=t9;
f_3980(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(22):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_eqp(t11,t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5762,a[2]=t4,a[3]=t9,a[4]=t12,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1201 test */
t15=t9;
f_3980(t15,t14,t4,lf[42]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5825,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=t1,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1222 test */
t11=t9;
f_3980(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1242 bomb */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t1,lf[172]);}}

/* k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5828(2,t3,t1);}
else{
/* optimizer.scm: 1222 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5843,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5850,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1228 varnode */
t10=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1230 ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a5861 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5862,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5870,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5876,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_5876(t9,t4,t3,t5);}

/* loop in a5861 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_5876(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5876,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5896,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 848  varnode */
t6=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4002,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_4002(t8,(C_word)C_eqp(lf[24],t7));}
else{
t7=t6;
f_4002(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5925,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1240 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k5923 in loop in a5861 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5925,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4000 in loop in a5861 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_4002(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 849  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 850  qnode */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k5894 in loop in a5861 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5900,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1238 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5876(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k5898 in k5894 in loop in a5861 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5900,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5868 in a5861 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1231 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5855 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5856,2,t0,t1);}
/* optimizer.scm: 1230 split-at */
t2=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5852 in k5848 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1227 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5841 in k5826 in k5823 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5843,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k5760 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5765,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5765(2,t3,t1);}
else{
/* optimizer.scm: 1201 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5763 in k5760 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5765,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5797,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1209 fifth */
t7=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
t9=t4;
f_5784(t9,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t7,t8));}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5795 in k5763 in k5760 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5797,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_5784(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t2,t3));}

/* k5782 in k5763 in k5760 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_5784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5784,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[170],t2));}

/* k5606 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5611,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5611(2,t3,t1);}
else{
/* optimizer.scm: 1167 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5609 in k5606 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1169 fifth */
t4=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5615 in k5609 in k5606 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5626,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5701,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1173 remove */
t6=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a5700 in k5615 in k5609 in k5606 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5701,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[24],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5624 in k5615 in k5609 in k5606 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5626,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1178 qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[167],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5668,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1186 fold-inner */
t5=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,t1);}}}

/* a5669 in k5624 in k5615 in k5609 in k5606 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5670,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t5,t6));}}

/* k5666 in k5624 in k5615 in k5609 in k5606 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5668,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[168],t2));}

/* k5640 in k5624 in k5615 in k5609 in k5606 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5642,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[166],t2));}

/* k5533 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5538(2,t3,t1);}
else{
/* optimizer.scm: 1149 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5536 in k5533 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1155 ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5565 in k5536 in k5533 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5566,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5578,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1157 qnode */
t6=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k5576 in a5565 in k5536 in k5533 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1156 append */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5555 in k5536 in k5533 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5556,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1155 split-at */
t3=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k5549 in k5536 in k5533 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5551,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[165],t3));}

/* k5385 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5390(2,t3,t1);}
else{
/* optimizer.scm: 1120 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5388 in k5385 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5399,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5471,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1124 remove */
t6=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5470 in k5388 in k5385 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5471,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[24],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5397 in k5388 in k5385 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5399,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5415,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1129 qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[161],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[142]),lf[147]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1137 fold-inner */
t7=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a5451 in k5397 in k5388 in k5385 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5452,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t4,t5));}

/* k5448 in k5397 in k5388 in k5385 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[162],t2));}

/* k5413 in k5397 in k5388 in k5385 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5415,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[160],t2));}

/* k5350 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_5355(2,t3,t1);}
else{
/* optimizer.scm: 1110 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5353 in k5350 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5365,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1111 qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5363 in k5353 in k5350 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5365,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[159],t2));}

/* k5282 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5287(2,t3,t1);}
else{
/* optimizer.scm: 1096 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5285 in k5282 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5287,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[137]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=t2;
f_5307(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_5307(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5305 in k5285 in k5282 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_5307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5307,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[158],t6));}

/* k5203 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_5208(2,t3,t1);}
else{
/* optimizer.scm: 1079 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5206 in k5203 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5208,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=t5;
f_5238(t7,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=t5;
f_5238(t8,(C_word)C_fixnum_times(((C_word*)t0)[2],t7));}
else{
t7=t5;
f_5238(t7,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5236 in k5206 in k5203 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_5238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5238,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[83],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[157],t5));}

/* k5110 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5115,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5115(2,t3,t1);}
else{
/* optimizer.scm: 1059 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5113 in k5110 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5115,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[142]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5127,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1062 varnode */
t9=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[142]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[156],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5132 in k5113 in k5110 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1062 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5125 in k5113 in k5110 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k5027 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5032(2,t3,t1);}
else{
/* optimizer.scm: 1041 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5030 in k5027 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5032,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[142]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[137]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[155],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4962 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4967(2,t3,t1);}
else{
/* optimizer.scm: 1029 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4965 in k4962 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_4982(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_4982(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4980 in k4965 in k4962 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_4982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4982,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4985,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[154],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 1033 cons* */
t5=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4983 in k4980 in k4965 in k4962 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4886 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4891,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4891(2,t3,t1);}
else{
/* optimizer.scm: 1016 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4889 in k4886 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4891,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[153],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4927,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 1023 varnode */
t12=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4932 in k4889 in k4886 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1023 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4925 in k4889 in k4886 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4821 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4826(2,t3,t1);}
else{
/* optimizer.scm: 1003 test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4824 in k4821 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_4838(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_4838(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4836 in k4824 in k4821 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_4838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4838,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4844,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1008 varnode */
t7=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4849 in k4836 in k4824 in k4821 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1008 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4842 in k4836 in k4824 in k4821 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4734 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 990  varnode */
t7=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4756 in k4734 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 993  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k4764 in k4756 in k4734 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4770,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 995  varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}
else{
t4=t2;
f_4770(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k4768 in k4764 in k4756 in k4734 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4770,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t2));}

/* k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 961  qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4614,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[137]))){
t4=(C_word)C_eqp(C_retrieve(lf[142]),lf[151]);
t5=t3;
f_4614(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4614(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4612 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_4614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4614,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4617(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_4617(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[142]),lf[150]);
t6=t2;
f_4617(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k4615 in k4612 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_4617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4617,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4676,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4675 in k4615 in k4612 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4676,3,t0,t1,t2);}
/* optimizer.scm: 965  gensym */
t3=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k4618 in k4615 in k4612 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4623,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[46]),t1);}

/* k4621 in k4618 in k4615 in k4612 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4628,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4654,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 977  fold-boolean */
t8=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,t1);}

/* a4653 in k4621 in k4618 in k4615 in k4612 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4654,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[2],t4));}

/* k4650 in k4621 in k4618 in k4615 in k4612 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4652,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[148],t2);
/* optimizer.scm: 967  fold-right */
t4=C_retrieve(lf[119]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4627 in k4621 in k4618 in k4615 in k4612 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4628,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t5,t6));}

/* k4606 in k4590 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[146],t2));}

/* k4563 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4568(2,t3,t1);}
else{
/* optimizer.scm: 952  test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4566 in k4563 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4502 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4507,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4507(2,t3,t1);}
else{
/* optimizer.scm: 941  test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4505 in k4502 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4507,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 946  qnode */
t7=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4529 in k4505 in k4502 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4531,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 945  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4518 in k4505 in k4502 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[145],t3));}

/* k4437 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[144],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4344 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4349(2,t3,t1);}
else{
/* optimizer.scm: 914  test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4347 in k4344 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[142])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 922  qnode */
t12=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4389 in k4347 in k4344 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[143],t4));}

/* k4288 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 903  varnode */
t6=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4301 in k4288 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 906  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k4309 in k4301 in k4288 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t3));}

/* k4244 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4249(2,t3,t1);}
else{
/* optimizer.scm: 893  test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4247 in k4244 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4249,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 894  varnode */
t4=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4257 in k4247 in k4244 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[141],t2));}

/* k4140 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4145(2,t3,t1);}
else{
/* optimizer.scm: 875  test */
t3=((C_word*)t0)[3];
f_3980(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4143 in k4140 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4173,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4202,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t4,C_fix(2));
t12=(C_word)C_i_car(t11);
/* optimizer.scm: 885  get */
t13=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t13))(5,t13,t10,((C_word*)t0)[2],t12,lf[140]);}
else{
t10=t7;
f_4173(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_4173(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4200 in k4143 in k4140 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4173(t2,(C_word)C_eqp(lf[139],t1));}

/* k4171 in k4143 in k4140 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_4173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4173,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
f_4170(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t2,t3));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
f_4170(t5,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4));}}

/* k4168 in k4143 in k4140 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_4170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4170,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[138],t2));}

/* k4032 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[8],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4097,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 864  qnode */
t15=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_4037(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_4037(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_4037(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_4037(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4095 in k4032 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4097,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_4037(t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[136],t2));}

/* k4035 in k4032 in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_4037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4037,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[133]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[135],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* test in ##compiler#simplify-named-call in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3980(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3980,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 846  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#rewrite in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3957r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3957r(t0,t1,t2,t3);}}

static void C_ccall f_3957r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3961,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 842  ##sys#hash-table-ref */
t5=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[130]),t2);}

/* k3959 in ##compiler#rewrite in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 843  append */
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,t4);}

/* k3969 in k3959 in ##compiler#rewrite in k3953 in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 843  ##sys#hash-table-set! */
t2=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[130]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3629,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3633,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 754  map */
t8=*((C_word*)lf[128]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,*((C_word*)lf[129]+1),t2,t3);}

/* k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3635,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3680,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 765  for-each */
t5=*((C_word*)lf[127]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3941 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3942,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3947,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 766  scan-used-variables */
t6=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}

/* k3949 in a3941 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 766  alist-cons */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3945 in a3941 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3680,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a3883 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3884,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3894,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 775  filter */
t5=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* a3915 in a3883 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3916,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 776  find-path */
t5=((C_word*)t0)[2];
f_3635(t5,t4,((C_word*)t0)[3],t2);}}

/* k3927 in a3915 in a3883 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 776  find-path */
t2=((C_word*)t0)[5];
f_3635(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3892 in a3883 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3898,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3910,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 778  gensym */
t4=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3908 in k3892 in a3883 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3910,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 778  alist-cons */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3896 in k3892 in a3883 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3898,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 779  append */
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k3900 in k3896 in k3892 in a3883 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3686,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a3824 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3825,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3832,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 788  append-map */
t7=C_retrieve(lf[125]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}

/* a3867 in a3824 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3868,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3874,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 789  filter */
t4=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a3873 in a3867 in a3824 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3874,3,t0,t1,t2);}
/* optimizer.scm: 789  find-path */
t3=((C_word*)t0)[3];
f_3635(t3,t1,((C_word*)t0)[2],t2);}

/* k3830 in a3824 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3842,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 794  filter-map */
t5=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a3841 in k3830 in a3824 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3842,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3855,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 795  lset<= */
t6=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,*((C_word*)lf[33]+1),t5,((C_word*)t0)[2]);}}

/* k3853 in a3841 in k3830 in a3824 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k3838 in k3830 in a3824 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 792  alist-cons */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3834 in k3830 in a3824 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 801  topological-sort */
t3=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[33]+1));}

/* k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 806  fold */
t6=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[2],t1);}

/* a3708 in k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3709,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3722,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_3722(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_3722(t9,C_SCHEME_FALSE);}}

/* k3720 in a3708 in k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3722,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3745,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3763,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 820  fold-right */
t5=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a3764 in k3720 in a3708 in k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3765,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3797,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 823  gensym */
t5=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3795 in a3764 in k3720 in a3708 in k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3797,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[14],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t2,t8));}

/* k3761 in k3720 in a3708 in k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 815  fold-right */
t2=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3744 in k3720 in a3708 in k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3745,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t4,t6));}

/* k3690 in k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3692,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3701,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 832  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[118],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 834  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k3699 in k3690 in k3687 in k3684 in k3681 in k3678 in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 833  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3635(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3635,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3641,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3641(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3641(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3641,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3665,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 762  any */
t9=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,t8,t5);}}}

/* a3664 in find in find-path in k3631 in ##compiler#reorganize-recursive-bindings in k3625 in k3622 in k3619 in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3665,3,t0,t1,t2);}
/* optimizer.scm: 762  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3641(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3614r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3614r(t0,t1,t2,t3);}}

static void C_ccall f_3614r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 533  ##sys#hash-table-set! */
t4=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[20]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3153,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3156,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3160,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3167,a[2]=t3,a[3]=t9,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 446  debugging */
t11=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,lf[18],lf[114]);}

/* k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3402,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 449  test */
t4=((C_word*)t0)[3];
f_3160(t4,t3,lf[113],lf[43]);}

/* k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3609,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 485  test */
t4=((C_word*)t0)[3];
f_3160(t4,t3,lf[113],lf[109]);}
else{
t2=((C_word*)t0)[2];
f_3170(2,t2,C_SCHEME_UNDEFINED);}}

/* k3607 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3407,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3420,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3598,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 455  test */
t10=((C_word*)t0)[2];
f_3160(t10,t9,t7,lf[73]);}

/* k3596 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3420(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 455  test */
t2=((C_word*)t0)[3];
f_3160(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 456  test */
t3=((C_word*)t0)[3];
f_3160(t3,t2,((C_word*)t0)[2],lf[72]);}

/* k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[4]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=t2;
f_3429(t8,(C_word)C_eqp(lf[52],t7));}
else{
t7=t2;
f_3429(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3429(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3429(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3429(t3,C_SCHEME_FALSE);}}

/* k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3429(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3429,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_3444(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_3444(t8,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3442 in k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3444,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3450,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 467  test */
t4=((C_word*)t0)[2];
f_3160(t4,t3,t2,lf[72]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3448 in k3442 in k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_3456(t6,(C_word)C_eqp(lf[9],t5));}
else{
t5=t2;
f_3456(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3456(t3,C_SCHEME_FALSE);}}

/* k3454 in k3448 in k3442 in k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3456,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[8],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_3465(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_3465(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3463 in k3454 in k3448 in k3442 in k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3465,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 479  node-parameters-set! */
t5=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[112]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3470 in k3463 in k3454 in k3448 in k3442 in k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 480  node-subexpressions-set! */
t4=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3473 in k3470 in k3463 in k3454 in k3448 in k3442 in k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 483  reverse */
t6=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k3491 in k3473 in k3470 in k3463 in k3454 in k3448 in k3442 in k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3493,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 481  node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3476 in k3473 in k3470 in k3463 in k3454 in k3448 in k3442 in k3427 in k3421 in k3418 in a3406 in k3400 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 484  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_3156(((C_word*)t0)[2]));}

/* k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3173,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[110]));}

/* a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3184,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3191,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 490  test */
t4=((C_word*)t0)[3];
f_3160(t4,t3,t2,lf[43]);}

/* k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3191,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3396,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 523  test */
t4=((C_word*)t0)[4];
f_3160(t4,t3,((C_word*)t0)[5],lf[109]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3394 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3196,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3209,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 496  test */
t9=((C_word*)t0)[3];
f_3160(t9,t8,t7,lf[72]);}

/* k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 497  test */
t4=((C_word*)t0)[4];
f_3160(t4,t3,((C_word*)t0)[2],lf[73]);}

/* k3383 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3212(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 497  test */
t2=((C_word*)t0)[3];
f_3160(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_eqp(lf[52],t3);
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* optimizer.scm: 502  any */
t10=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t7=t2;
f_3218(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3218(t5,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3218(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3218(t3,C_SCHEME_FALSE);}}

/* a3358 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3359,3,t0,t1,t2);}
/* optimizer.scm: 502  expression-has-side-effects? */
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k3355 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3218(t2,(C_word)C_i_not(t1));}

/* k3216 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t5,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t7=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_slot(t5,C_fix(1));
t9=t6;
f_3230(t9,(C_word)C_eqp(lf[9],t8));}
else{
t8=t6;
f_3230(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_3230(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3228 in k3216 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3230,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3236,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 510  test */
t4=((C_word*)t0)[2];
f_3160(t4,t3,t2,lf[72]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3234 in k3228 in k3216 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3236,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t5=(C_word)C_i_length(t1);
t6=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_word)C_eqp(lf[8],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(2));
t10=(C_word)C_i_car(t9);
t11=t4;
f_3245(t11,(C_word)C_eqp(((C_word*)t0)[2],t10));}
else{
t9=t4;
f_3245(t9,C_SCHEME_FALSE);}}
else{
t7=t4;
f_3245(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_3245(t5,C_SCHEME_FALSE);}}

/* k3243 in k3234 in k3228 in k3216 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3245,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 519  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[108],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3249 in k3243 in k3234 in k3228 in k3216 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 520  node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[107]);}

/* k3252 in k3249 in k3243 in k3234 in k3228 in k3216 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 521  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k3270 in k3252 in k3249 in k3243 in k3234 in k3228 in k3216 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 521  node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3255 in k3252 in k3249 in k3243 in k3234 in k3228 in k3216 in k3210 in k3207 in a3195 in k3189 in a3183 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 522  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_3156(((C_word*)t0)[2]));}

/* k3171 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 526  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[104],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3176(2,t4,C_SCHEME_UNDEFINED);}}

/* k3174 in k3171 in k3168 in k3165 in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3160,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 444  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static C_word C_fcall f_3156(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[70],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1682,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1685,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1691,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1701,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1715,a[2]=t3,a[3]=t21,a[4]=t19,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1807,a[2]=t26,a[3]=t16,a[4]=t17,a[5]=t24,a[6]=t18,a[7]=t19,a[8]=t7,a[9]=t21,a[10]=t15,tmp=(C_word)a,a+=11,tmp));
t30=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2023,a[2]=t11,a[3]=t3,a[4]=t28,a[5]=t24,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t19,tmp=(C_word)a,a+=10,tmp));
t31=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3038,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3057,a[2]=t24,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 412  perform-pre-optimization! */
t33=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t33))(4,t33,t32,t2,t3);}

/* k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 413  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 415  debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[102]);}}

/* k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
t2=C_set_block_item(lf[21],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3067,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 417  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1807(3,t4,t3,((C_word*)t0)[2]);}

/* k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 418  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[101],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_3070(2,t3,C_SCHEME_UNDEFINED);}}

/* k3068 in k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[21])))){
/* optimizer.scm: 419  debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[5],lf[100]);}
else{
t4=t3;
f_3106(2,t4,C_SCHEME_FALSE);}}

/* k3104 in k3068 in k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3111,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[21]));}
else{
t2=((C_word*)t0)[2];
f_3073(2,t2,C_SCHEME_UNDEFINED);}}

/* a3110 in k3104 in k3068 in k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3111,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3115,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 422  print* */
t5=*((C_word*)lf[99]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_make_character(9),t4);}

/* k3113 in a3110 in k3104 in k3068 in k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 424  print */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 425  newline */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,((C_word*)t0)[2]);}}

/* k3071 in k3068 in k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 427  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[96],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3076(2,t4,C_SCHEME_UNDEFINED);}}

/* k3074 in k3071 in k3068 in k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 428  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[95],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3079(2,t4,C_SCHEME_UNDEFINED);}}

/* k3077 in k3074 in k3071 in k3068 in k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 429  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[94],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3082(2,t4,C_SCHEME_UNDEFINED);}}

/* k3080 in k3077 in k3074 in k3071 in k3068 in k3065 in k3061 in k3055 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 430  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_3038(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3038,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3042,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k3040 in walk-generic in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3048,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 408  every */
t3=C_retrieve(lf[40]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k3046 in k3040 in walk-generic in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3048,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[68],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2023,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[8]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[7],a[3]=t6,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_2048(t14,t1,t10);}
else{
t10=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2123,a[2]=t11,a[3]=((C_word*)t0)[8],a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 243  test */
t13=((C_word*)t0)[8];
f_1685(t13,t12,t11,lf[48]);}
else{
t11=(C_word)C_eqp(t8,lf[52]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2180,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t6,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 253  test */
t15=((C_word*)t0)[8];
f_1685(t15,t13,t14,lf[61]);}
else{
t12=(C_word)C_eqp(t8,lf[13]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t4);
t14=(C_word)C_slot(t13,C_fix(1));
t15=(C_word)C_eqp(t14,lf[8]);
if(C_truep(t15)){
t16=(C_word)C_slot(t13,C_fix(2));
t17=(C_word)C_i_car(t16);
t18=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[2],a[3]=t13,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t8,a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=t17,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2898,a[2]=t17,a[3]=((C_word*)t0)[8],a[4]=t18,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 291  test */
t20=((C_word*)t0)[8];
f_1685(t20,t19,t17,lf[73]);}
else{
t16=(C_word)C_eqp(t14,lf[52]);
if(C_truep(t16)){
if(C_truep((C_word)C_i_car(t6))){
/* optimizer.scm: 385  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_3038(t17,t1,t2,t8,t6,t4);}
else{
t17=(C_word)C_i_cdr(t6);
t18=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2923,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t20=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
/* optimizer.scm: 387  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_3038(t17,t1,t2,t8,t6,t4);}}}
else{
t13=(C_word)C_eqp(t8,lf[14]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t6);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t14,a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 391  test */
t16=((C_word*)t0)[8];
f_1685(t16,t15,t14,lf[50]);}
else{
/* optimizer.scm: 404  walk-generic */
t14=((C_word*)((C_word*)t0)[4])[1];
f_3038(t14,t1,t2,t8,t6,t4);}}}}}}

/* k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_2951(2,t3,t1);}
else{
/* optimizer.scm: 391  test */
t3=((C_word*)t0)[2];
f_1685(t3,t2,((C_word*)t0)[7],lf[48]);}}

/* k2949 in k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
if(C_truep(t1)){
t2=f_1711(((C_word*)t0)[9]);
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 394  test */
t4=((C_word*)t0)[2];
f_1685(t4,t3,((C_word*)t0)[7],lf[93]);}}

/* k3028 in k2949 in k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2992(t4,t2);}
else{
t4=C_retrieve(lf[91]);
if(C_truep(t4)){
t5=t3;
f_2992(t5,t4);}
else{
if(C_truep(C_retrieve(lf[92]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[92]));
t6=t3;
f_2992(t6,(C_word)C_i_not(t5));}
else{
t5=t3;
f_2992(t5,C_SCHEME_FALSE);}}}}

/* k2990 in k3028 in k2949 in k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2992,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 397  test */
t3=((C_word*)t0)[3];
f_1685(t3,t2,((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[6];
f_2963(t2,C_SCHEME_FALSE);}}

/* k3011 in k2990 in k3028 in k2949 in k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3013,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2963(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 398  expression-has-side-effects? */
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* k3003 in k3011 in k2990 in k3028 in k2949 in k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2963(t2,(C_word)C_i_not(t1));}

/* k2961 in k2949 in k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2963,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_1711(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 400  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[90],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 402  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1807(3,t4,t2,t3);}}

/* k2980 in k2961 in k2949 in k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[14],((C_word*)t0)[2],t2));}

/* k2967 in k2961 in k2949 in k2946 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2969,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* k2921 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k2896 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2356(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 291  test */
t2=((C_word*)t0)[3];
f_1685(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2356,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=t1,tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm: 293  test */
t4=((C_word*)t0)[4];
f_1685(t4,t3,((C_word*)t0)[10],lf[50]);}

/* k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t3,a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 296  check-signature */
t5=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[11],((C_word*)t0)[12],t3);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[65])))){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(lf[8],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2428,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2525,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 304  test */
t10=((C_word*)t0)[4];
f_1685(t10,t9,t7,lf[73]);}
else{
t8=t3;
f_2407(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2407(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2407(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_word)C_slot(((C_word*)t0)[16],C_fix(1));
t4=t2;
f_2539(t4,(C_word)C_eqp(lf[52],t3));}
else{
t3=t2;
f_2539(t3,C_SCHEME_FALSE);}}}}

/* k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2539,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 319  decompose-lambda-list */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
/* optimizer.scm: 382  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_3038(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2550,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2560,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[17],a[4]=t6,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 323  test */
t8=((C_word*)t0)[3];
f_1685(t8,t7,t5,lf[89]);}

/* k2847 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2849,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 324  test */
t3=((C_word*)t0)[2];
f_1685(t3,t2,((C_word*)t0)[5],lf[88]);}
else{
t2=((C_word*)t0)[4];
f_2560(t2,C_SCHEME_FALSE);}}

/* k2853 in k2847 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[85])))){
t2=((C_word*)t0)[3];
f_2560(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[86]));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_2560(t3,t2);}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t4=C_retrieve(lf[87]);
t5=((C_word*)t0)[3];
f_2560(t5,(C_word)C_fixnum_lessp(t3,t4));}}}
else{
t2=((C_word*)t0)[3];
f_2560(t2,C_SCHEME_FALSE);}}

/* k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2560,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2563,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[14]);
/* optimizer.scm: 328  debugging */
t4=C_retrieve(lf[4]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,lf[75],lf[76],((C_word*)t0)[15],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2597,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* optimizer.scm: 333  test */
t3=((C_word*)t0)[4];
f_1685(t3,t2,((C_word*)t0)[13],lf[61]);}}

/* k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 335  walk-generic */
t4=((C_word*)((C_word*)t0)[17])[1];
f_3038(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_2611(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[4],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2839,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 357  test */
t4=((C_word*)t0)[6];
f_1685(t4,t3,((C_word*)t0)[2],lf[57]);}}

/* k2837 in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_2756(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2756(t2,C_SCHEME_FALSE);}}

/* k2754 in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2756,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[13]);
t3=(C_word)C_i_length(((C_word*)t0)[12]);
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* optimizer.scm: 361  walk-generic */
t4=((C_word*)((C_word*)t0)[11])[1];
f_3038(t4,((C_word*)t0)[10],t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 363  debugging */
t5=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[5],lf[84],((C_word*)t0)[3],t2);}}
else{
/* optimizer.scm: 381  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_3038(t2,((C_word*)t0)[10],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k2769 in k2754 in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 364  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2781 in k2769 in k2754 in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2782,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2801,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2809,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 374  qnode */
t7=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_i_length(t3);
t8=(C_word)C_fixnum_times(C_fix(3),t7);
t9=(C_word)C_a_i_list(&a,2,lf[82],t8);
t10=t6;
f_2809(2,t10,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t9,t3));}}

/* k2807 in a2781 in k2769 in k2754 in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 370  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2799 in a2781 in k2769 in k2754 in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k2784 in a2781 in k2769 in k2754 in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2786,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a2775 in k2769 in k2754 in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2776,2,t0,t1);}
/* optimizer.scm: 364  split-at */
t2=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2611(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2611,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_1711(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 342  append-reverse */
t11=C_retrieve(lf[77]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 343  test */
t10=((C_word*)t0)[2];
f_1685(t10,t8,t9,lf[53]);}}

/* k2642 in loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
if(C_truep(t1)){
t2=f_1711(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 345  debugging */
t5=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,lf[5],lf[80],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 353  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_2611(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k2648 in k2642 in loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 346  expression-has-side-effects? */
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k2654 in k2648 in k2642 in loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 349  gensym */
t3=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[79]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 352  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2611(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k2691 in k2654 in k2648 in k2642 in loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 350  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1807(3,t5,t3,t4);}

/* k2667 in k2691 in k2654 in k2648 in k2642 in loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 351  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2611(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k2671 in k2667 in k2691 in k2654 in k2648 in k2642 in loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t2));}

/* k2636 in loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k2625 in loop in k2595 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k2561 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 329  check-signature */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2564 in k2561 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 330  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[74],((C_word*)t0)[2]);}

/* k2567 in k2564 in k2561 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=f_1711(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 332  inline-lambda-bindings */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_TRUE);}

/* k2577 in k2567 in k2564 in k2561 in k2558 in a2549 in k2537 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 332  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1807(3,t2,((C_word*)t0)[2],t1);}

/* k2523 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2428(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 304  test */
t2=((C_word*)t0)[3];
f_1685(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k2426 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_caddr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 307  test */
t6=((C_word*)t0)[2];
f_1685(t6,t4,t5,lf[53]);}
else{
t4=((C_word*)t0)[7];
f_2407(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_2407(t2,C_SCHEME_FALSE);}}

/* k2444 in k2426 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_2449(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 308  test */
t5=((C_word*)t0)[2];
f_1685(t5,t3,t4,lf[72]);}}

/* k2501 in k2444 in k2426 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2503,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2449(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 309  test */
t4=((C_word*)t0)[2];
f_1685(t4,t2,t3,lf[71]);}}

/* k2493 in k2501 in k2444 in k2426 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2449(t2,(C_word)C_i_not(t1));}

/* k2447 in k2444 in k2426 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2449,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2472,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 310  any */
t5=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_2407(t2,C_SCHEME_FALSE);}}

/* a2473 in k2447 in k2444 in k2426 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2474,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2470 in k2447 in k2444 in k2426 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2472,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2407(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 311  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[68],lf[69],((C_word*)t0)[2]);}}

/* k2456 in k2470 in k2447 in k2444 in k2426 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_2407(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[67],t3));}

/* k2405 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 315  walk-generic */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3038(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2372 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 297  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[63],((C_word*)t0)[2]);}

/* k2375 in k2372 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=f_1711(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 299  inline-lambda-bindings */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k2385 in k2375 in k2372 in k2363 in k2354 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 299  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1807(3,t2,((C_word*)t0)[2],t1);}

/* k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 254  decompose-lambda-list */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 269  test */
t4=((C_word*)t0)[11];
f_1685(t4,t2,t3,lf[57]);}}

/* k2270 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2272,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 270  decompose-lambda-list */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
/* optimizer.scm: 282  walk-generic */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3038(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a2276 in k2270 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2277,5,t0,t1,t2,t3,t4);}
t5=f_1711(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2284,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 274  debugging */
t7=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[5],lf[60],t4);}

/* k2282 in a2276 in k2270 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 279  build-lambda-list */
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k2311 in k2282 in a2276 in k2270 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 281  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1807(3,t6,t4,t5);}

/* k2295 in k2311 in k2282 in a2276 in k2270 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2297,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[52],((C_word*)t0)[2],t2));}

/* a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2185,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2191,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2202 in a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2203,4,t0,t1,t2,t3);}
t4=f_1711(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 259  debugging */
t6=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[5],lf[58],t2);}

/* k2208 in a2202 in a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2210,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 263  test */
t7=((C_word*)t0)[2];
f_1685(t7,t5,t6,lf[57]);}
else{
t6=t5;
f_2246(2,t6,C_SCHEME_FALSE);}}

/* k2244 in k2208 in a2202 in a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 264  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[56],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 266  build-lambda-list */
t2=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2247 in k2244 in k2208 in a2202 in a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 265  build-lambda-list */
t3=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k2237 in k2208 in a2202 in a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 268  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1807(3,t6,t4,t5);}

/* k2221 in k2237 in k2208 in a2202 in a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2223,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[52],((C_word*)t0)[2],t2));}

/* a2190 in a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 257  partition */
t3=C_retrieve(lf[54]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2196 in a2190 in a2184 in k2178 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2197,3,t0,t1,t2);}
/* optimizer.scm: 257  test */
t3=((C_word*)t0)[2];
f_1685(t3,t1,t2,lf[53]);}

/* k2121 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_2126(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 244  test */
t4=((C_word*)t0)[3];
f_1685(t4,t3,((C_word*)t0)[2],lf[51]);}}

/* k2147 in k2121 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2149,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2126(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 245  test */
t3=((C_word*)t0)[3];
f_1685(t3,t2,((C_word*)t0)[2],lf[50]);}}

/* k2156 in k2147 in k2121 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2165,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 245  test */
t3=((C_word*)t0)[3];
f_1685(t3,t2,((C_word*)t0)[2],lf[49]);}
else{
t2=((C_word*)t0)[4];
f_2126(t2,C_SCHEME_FALSE);}}

/* k2163 in k2156 in k2147 in k2121 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2126(t2,(C_word)C_i_not(t1));}

/* k2124 in k2121 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2126,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_1711(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 248  walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1807(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k2141 in k2124 in k2121 in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2048(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2048,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 229  test */
t4=((C_word*)t0)[4];
f_1685(t4,t3,t2,lf[48]);}

/* k2050 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2052,2,t0,t1);}
if(C_truep(t1)){
/* replace119 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2048(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 230  test */
t3=((C_word*)t0)[5];
f_1685(t3,t2,((C_word*)t0)[4],lf[47]);}}

/* k2062 in k2050 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
if(C_truep(t1)){
t2=f_1711(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 232  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[45],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_2087(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_1711(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_2087(t8,t7);}}}

/* k2085 in k2062 in k2050 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_2087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 239  varnode */
t2=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2068 in k2062 in k2050 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 233  test */
t3=((C_word*)t0)[3];
f_1685(t3,t2,((C_word*)t0)[2],lf[44]);}

/* k2079 in k2068 in k2062 in k2050 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
/* optimizer.scm: 233  qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1807,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[31])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[10])[1];
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 182  walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2023(t5,t4,t2);}}

/* k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1830,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[9]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1839,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t2);
/* optimizer.scm: 187  constant-node? */
t8=((C_word*)t0)[5];
f_1691(3,t8,t6,t7);}
else{
t6=(C_word)C_eqp(t3,lf[13]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=t4,a[9]=t12,tmp=(C_word)a,a+=10,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1988,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t13,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 198  test */
t15=((C_word*)t0)[2];
f_1685(t15,t14,t12,lf[43]);}
else{
t10=t4;
f_1830(2,t10,t1);}}
else{
t7=t4;
f_1830(2,t7,t1);}}}

/* k1986 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1991(2,t3,t1);}
else{
/* optimizer.scm: 199  test */
t3=((C_word*)t0)[3];
f_1685(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k1989 in k1986 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 200  test */
t3=((C_word*)t0)[3];
f_1685(t3,t2,((C_word*)t0)[2],lf[41]);}
else{
t2=((C_word*)t0)[5];
f_1891(2,t2,C_SCHEME_FALSE);}}

/* k1995 in k1989 in k1986 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 201  every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_1891(2,t2,C_SCHEME_FALSE);}}

/* k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[8];
f_1830(2,t2,((C_word*)t0)[7]);}}

/* a1972 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1973,3,t0,t1,t2);}
t3=f_1701(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[24],t3));}

/* k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1971,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1902,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1902,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1908,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1925,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1924 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1956 in a1924 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1957r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1957r(t0,t1,t2);}}

static void C_ccall f_1957r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1963,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g9799 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1962 in a1956 in a1924 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1963,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1930 in a1924 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 209  eval */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1933 in a1930 in a1924 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1938,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 210  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[37],((C_word*)t0)[2]);}

/* k1936 in k1933 in a1930 in a1924 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=f_1711(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 215  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1953 in k1936 in k1933 in a1930 in a1924 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[35],t2));}

/* a1907 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1908,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* g9799 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1913 in a1907 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1918(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_1918(t4,t3);}}

/* k1916 in a1913 in a1907 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_1918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1918,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 207  lset-adjoin */
t3=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[33]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}

/* k1920 in k1916 in a1913 in a1907 in a1901 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k1898 in k1969 in k1889 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1837 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=f_1711(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=f_1701(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[6]):(C_word)C_i_caddr(((C_word*)t0)[6]));
/* optimizer.scm: 190  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_1807(3,t8,((C_word*)t0)[3],t7);}
else{
t2=((C_word*)t0)[3];
f_1830(2,t2,((C_word*)t0)[2]);}}

/* k1828 in k1819 in walk in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 180  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1715(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_1715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1715,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
/* optimizer.scm: 161  ##sys#hash-table-ref */
t6=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_retrieve(lf[20]),t5);}

/* k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 162  any */
t4=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}
else{
t3=t2;
f_1722(2,t3,C_SCHEME_FALSE);}}

/* a1729 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1730,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1740,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 164  match-node */
t6=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1738 in a1729 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1740,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1746,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1789,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1788 in k1738 in a1729 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1789,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1785 in k1738 in a1729 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1744 in k1738 in a1729 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1752,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 167  caar */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1750 in k1744 in k1738 in a1729 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1752,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_1758(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1779,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 171  alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k1777 in k1750 in k1744 in k1738 in a1729 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1758(t3,t2);}

/* k1756 in k1750 in k1744 in k1738 in a1729 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_1758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1711(((C_word*)t0)[5]);
/* optimizer.scm: 173  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1715(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1720 in k1717 in simplify in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static C_word C_fcall f_1711(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* node-value in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static C_word C_fcall f_1701(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(2));
return((C_word)C_i_car(t2));}

/* constant-node? in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1691,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[24],t3));}

/* test in ##compiler#perform-high-level-optimizations in k1677 in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_1685(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1685,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 155  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1476,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1479,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1497,a[2]=t2,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 87   debugging */
t9=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,lf[18],lf[19]);}

/* k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1500,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 88   call-with-current-continuation */
t4=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1509,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1512,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1524,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 123  scan */
t9=((C_word*)t6)[1];
f_1524(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_1524(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1524,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[8]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1549,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_1549(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_1549(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[9]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_1576(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[15]);
t14=t12;
f_1576(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[16])));}}}

/* k1574 in scan in a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_1576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1576,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 105  scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1524(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 109  scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1524(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[11]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[12]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[13]);
if(C_truep(t5)){
/* optimizer.scm: 114  return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[14]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))?C_SCHEME_UNDEFINED:f_1479(C_a_i(&a,3),((C_word*)t0)[3],t7));
t9=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 119  scan */
t10=((C_word*)((C_word*)t0)[7])[1];
f_1524(t10,((C_word*)t0)[9],t9,((C_word*)t0)[6]);}
else{
/* optimizer.scm: 121  scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1512(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k1593 in k1574 in scan in a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1606,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 110  append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1604 in k1593 in k1574 in scan in a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 110  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1524(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1577 in k1574 in scan in a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 106  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1547 in scan in a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_1549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1549,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_fcall f_1512(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1512,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1518,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1517 in scan-each in a1508 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1518,3,t0,t1,t2);}
/* optimizer.scm: 92   scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1524(t3,t1,t2,((C_word*)t0)[2]);}

/* k1498 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 124  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[6],((C_word*)((C_word*)t0)[2])[1]);}

/* k1501 in k1498 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 125  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],C_retrieve(lf[2]));}

/* k1505 in k1501 in k1498 in k1495 in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[2]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* mark in ##compiler#scan-toplevel-assignments in k1469 in k1466 in k1463 in k1460 in k1457 */
static C_word C_fcall f_1479(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_memq(t1,((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[616] = {
{"topleveloptimizer.scm",(void*)C_optimizer_toplevel},
{"f_1459optimizer.scm",(void*)f_1459},
{"f_1462optimizer.scm",(void*)f_1462},
{"f_1465optimizer.scm",(void*)f_1465},
{"f_1468optimizer.scm",(void*)f_1468},
{"f_1471optimizer.scm",(void*)f_1471},
{"f_1679optimizer.scm",(void*)f_1679},
{"f_9563optimizer.scm",(void*)f_9563},
{"f_9571optimizer.scm",(void*)f_9571},
{"f_9576optimizer.scm",(void*)f_9576},
{"f_9621optimizer.scm",(void*)f_9621},
{"f_9625optimizer.scm",(void*)f_9625},
{"f_9586optimizer.scm",(void*)f_9586},
{"f_9610optimizer.scm",(void*)f_9610},
{"f_9595optimizer.scm",(void*)f_9595},
{"f_3621optimizer.scm",(void*)f_3621},
{"f_8934optimizer.scm",(void*)f_8934},
{"f_8968optimizer.scm",(void*)f_8968},
{"f_9010optimizer.scm",(void*)f_9010},
{"f_9020optimizer.scm",(void*)f_9020},
{"f_9084optimizer.scm",(void*)f_9084},
{"f_9113optimizer.scm",(void*)f_9113},
{"f_9236optimizer.scm",(void*)f_9236},
{"f_9129optimizer.scm",(void*)f_9129},
{"f_9176optimizer.scm",(void*)f_9176},
{"f_9166optimizer.scm",(void*)f_9166},
{"f_9174optimizer.scm",(void*)f_9174},
{"f_9278optimizer.scm",(void*)f_9278},
{"f_9291optimizer.scm",(void*)f_9291},
{"f_9326optimizer.scm",(void*)f_9326},
{"f_9310optimizer.scm",(void*)f_9310},
{"f_9314optimizer.scm",(void*)f_9314},
{"f_9303optimizer.scm",(void*)f_9303},
{"f_9400optimizer.scm",(void*)f_9400},
{"f_9413optimizer.scm",(void*)f_9413},
{"f_9419optimizer.scm",(void*)f_9419},
{"f_9465optimizer.scm",(void*)f_9465},
{"f_9457optimizer.scm",(void*)f_9457},
{"f_9441optimizer.scm",(void*)f_9441},
{"f_9445optimizer.scm",(void*)f_9445},
{"f_9449optimizer.scm",(void*)f_9449},
{"f_3624optimizer.scm",(void*)f_3624},
{"f_8752optimizer.scm",(void*)f_8752},
{"f_8774optimizer.scm",(void*)f_8774},
{"f_8829optimizer.scm",(void*)f_8829},
{"f_8799optimizer.scm",(void*)f_8799},
{"f_8821optimizer.scm",(void*)f_8821},
{"f_8825optimizer.scm",(void*)f_8825},
{"f_8817optimizer.scm",(void*)f_8817},
{"f_8797optimizer.scm",(void*)f_8797},
{"f_8863optimizer.scm",(void*)f_8863},
{"f_8877optimizer.scm",(void*)f_8877},
{"f_3627optimizer.scm",(void*)f_3627},
{"f_3955optimizer.scm",(void*)f_3955},
{"f_7092optimizer.scm",(void*)f_7092},
{"f_8639optimizer.scm",(void*)f_8639},
{"f_8642optimizer.scm",(void*)f_8642},
{"f_8645optimizer.scm",(void*)f_8645},
{"f_8648optimizer.scm",(void*)f_8648},
{"f_8651optimizer.scm",(void*)f_8651},
{"f_8654optimizer.scm",(void*)f_8654},
{"f_8731optimizer.scm",(void*)f_8731},
{"f_8657optimizer.scm",(void*)f_8657},
{"f_8660optimizer.scm",(void*)f_8660},
{"f_8663optimizer.scm",(void*)f_8663},
{"f_8725optimizer.scm",(void*)f_8725},
{"f_8666optimizer.scm",(void*)f_8666},
{"f_8669optimizer.scm",(void*)f_8669},
{"f_8722optimizer.scm",(void*)f_8722},
{"f_7701optimizer.scm",(void*)f_7701},
{"f_7719optimizer.scm",(void*)f_7719},
{"f_7725optimizer.scm",(void*)f_7725},
{"f_7705optimizer.scm",(void*)f_7705},
{"f_8672optimizer.scm",(void*)f_8672},
{"f_8714optimizer.scm",(void*)f_8714},
{"f_8712optimizer.scm",(void*)f_8712},
{"f_8675optimizer.scm",(void*)f_8675},
{"f_8678optimizer.scm",(void*)f_8678},
{"f_8681optimizer.scm",(void*)f_8681},
{"f_8705optimizer.scm",(void*)f_8705},
{"f_8684optimizer.scm",(void*)f_8684},
{"f_8687optimizer.scm",(void*)f_8687},
{"f_8690optimizer.scm",(void*)f_8690},
{"f_8693optimizer.scm",(void*)f_8693},
{"f_8696optimizer.scm",(void*)f_8696},
{"f_8699optimizer.scm",(void*)f_8699},
{"f_8492optimizer.scm",(void*)f_8492},
{"f_8498optimizer.scm",(void*)f_8498},
{"f_8610optimizer.scm",(void*)f_8610},
{"f_8619optimizer.scm",(void*)f_8619},
{"f_8622optimizer.scm",(void*)f_8622},
{"f_8517optimizer.scm",(void*)f_8517},
{"f_8522optimizer.scm",(void*)f_8522},
{"f_8563optimizer.scm",(void*)f_8563},
{"f_8560optimizer.scm",(void*)f_8560},
{"f_8545optimizer.scm",(void*)f_8545},
{"f_8556optimizer.scm",(void*)f_8556},
{"f_8552optimizer.scm",(void*)f_8552},
{"f_8405optimizer.scm",(void*)f_8405},
{"f_8411optimizer.scm",(void*)f_8411},
{"f_8467optimizer.scm",(void*)f_8467},
{"f_8463optimizer.scm",(void*)f_8463},
{"f_8433optimizer.scm",(void*)f_8433},
{"f_8155optimizer.scm",(void*)f_8155},
{"f_8169optimizer.scm",(void*)f_8169},
{"f_8176optimizer.scm",(void*)f_8176},
{"f_8189optimizer.scm",(void*)f_8189},
{"f_8196optimizer.scm",(void*)f_8196},
{"f_8199optimizer.scm",(void*)f_8199},
{"f_8295optimizer.scm",(void*)f_8295},
{"f_8381optimizer.scm",(void*)f_8381},
{"f_8400optimizer.scm",(void*)f_8400},
{"f_8396optimizer.scm",(void*)f_8396},
{"f_8362optimizer.scm",(void*)f_8362},
{"f_8351optimizer.scm",(void*)f_8351},
{"f_8338optimizer.scm",(void*)f_8338},
{"f_8321optimizer.scm",(void*)f_8321},
{"f_8314optimizer.scm",(void*)f_8314},
{"f_8280optimizer.scm",(void*)f_8280},
{"f_8202optimizer.scm",(void*)f_8202},
{"f_8251optimizer.scm",(void*)f_8251},
{"f_8239optimizer.scm",(void*)f_8239},
{"f_8235optimizer.scm",(void*)f_8235},
{"f_8167optimizer.scm",(void*)f_8167},
{"f_7954optimizer.scm",(void*)f_7954},
{"f_8141optimizer.scm",(void*)f_8141},
{"f_8019optimizer.scm",(void*)f_8019},
{"f_8096optimizer.scm",(void*)f_8096},
{"f_8101optimizer.scm",(void*)f_8101},
{"f_8139optimizer.scm",(void*)f_8139},
{"f_7963optimizer.scm",(void*)f_7963},
{"f_8001optimizer.scm",(void*)f_8001},
{"f_8006optimizer.scm",(void*)f_8006},
{"f_7983optimizer.scm",(void*)f_7983},
{"f_7961optimizer.scm",(void*)f_7961},
{"f_8131optimizer.scm",(void*)f_8131},
{"f_8117optimizer.scm",(void*)f_8117},
{"f_8115optimizer.scm",(void*)f_8115},
{"f_8021optimizer.scm",(void*)f_8021},
{"f_8089optimizer.scm",(void*)f_8089},
{"f_8087optimizer.scm",(void*)f_8087},
{"f_8075optimizer.scm",(void*)f_8075},
{"f_8041optimizer.scm",(void*)f_8041},
{"f_8065optimizer.scm",(void*)f_8065},
{"f_8063optimizer.scm",(void*)f_8063},
{"f_8059optimizer.scm",(void*)f_8059},
{"f_8051optimizer.scm",(void*)f_8051},
{"f_7735optimizer.scm",(void*)f_7735},
{"f_7741optimizer.scm",(void*)f_7741},
{"f_7760optimizer.scm",(void*)f_7760},
{"f_7927optimizer.scm",(void*)f_7927},
{"f_7857optimizer.scm",(void*)f_7857},
{"f_7873optimizer.scm",(void*)f_7873},
{"f_7903optimizer.scm",(void*)f_7903},
{"f_7907optimizer.scm",(void*)f_7907},
{"f_7893optimizer.scm",(void*)f_7893},
{"f_7846optimizer.scm",(void*)f_7846},
{"f_7851optimizer.scm",(void*)f_7851},
{"f_7822optimizer.scm",(void*)f_7822},
{"f_7834optimizer.scm",(void*)f_7834},
{"f_7771optimizer.scm",(void*)f_7771},
{"f_7792optimizer.scm",(void*)f_7792},
{"f_7789optimizer.scm",(void*)f_7789},
{"f_7739optimizer.scm",(void*)f_7739},
{"f_7491optimizer.scm",(void*)f_7491},
{"f_7497optimizer.scm",(void*)f_7497},
{"f_7516optimizer.scm",(void*)f_7516},
{"f_7618optimizer.scm",(void*)f_7618},
{"f_7609optimizer.scm",(void*)f_7609},
{"f_7575optimizer.scm",(void*)f_7575},
{"f_7584optimizer.scm",(void*)f_7584},
{"f_7596optimizer.scm",(void*)f_7596},
{"f_7527optimizer.scm",(void*)f_7527},
{"f_7548optimizer.scm",(void*)f_7548},
{"f_7545optimizer.scm",(void*)f_7545},
{"f_7495optimizer.scm",(void*)f_7495},
{"f_7392optimizer.scm",(void*)f_7392},
{"f_7398optimizer.scm",(void*)f_7398},
{"f_7442optimizer.scm",(void*)f_7442},
{"f_7447optimizer.scm",(void*)f_7447},
{"f_7454optimizer.scm",(void*)f_7454},
{"f_7481optimizer.scm",(void*)f_7481},
{"f_7477optimizer.scm",(void*)f_7477},
{"f_7469optimizer.scm",(void*)f_7469},
{"f_7467optimizer.scm",(void*)f_7467},
{"f_7432optimizer.scm",(void*)f_7432},
{"f_7410optimizer.scm",(void*)f_7410},
{"f_7417optimizer.scm",(void*)f_7417},
{"f_7195optimizer.scm",(void*)f_7195},
{"f_7349optimizer.scm",(void*)f_7349},
{"f_7374optimizer.scm",(void*)f_7374},
{"f_7364optimizer.scm",(void*)f_7364},
{"f_7368optimizer.scm",(void*)f_7368},
{"f_7347optimizer.scm",(void*)f_7347},
{"f_7198optimizer.scm",(void*)f_7198},
{"f_7337optimizer.scm",(void*)f_7337},
{"f_7320optimizer.scm",(void*)f_7320},
{"f_7332optimizer.scm",(void*)f_7332},
{"f_7266optimizer.scm",(void*)f_7266},
{"f_7290optimizer.scm",(void*)f_7290},
{"f_7284optimizer.scm",(void*)f_7284},
{"f_7248optimizer.scm",(void*)f_7248},
{"f_7223optimizer.scm",(void*)f_7223},
{"f_7226optimizer.scm",(void*)f_7226},
{"f_7231optimizer.scm",(void*)f_7231},
{"f_7095optimizer.scm",(void*)f_7095},
{"f_7101optimizer.scm",(void*)f_7101},
{"f_7132optimizer.scm",(void*)f_7132},
{"f_7136optimizer.scm",(void*)f_7136},
{"f_7140optimizer.scm",(void*)f_7140},
{"f_7099optimizer.scm",(void*)f_7099},
{"f_5957optimizer.scm",(void*)f_5957},
{"f_7087optimizer.scm",(void*)f_7087},
{"f_7090optimizer.scm",(void*)f_7090},
{"f_5960optimizer.scm",(void*)f_5960},
{"f_6116optimizer.scm",(void*)f_6116},
{"f_6096optimizer.scm",(void*)f_6096},
{"f_6070optimizer.scm",(void*)f_6070},
{"f_6016optimizer.scm",(void*)f_6016},
{"f_6022optimizer.scm",(void*)f_6022},
{"f_6028optimizer.scm",(void*)f_6028},
{"f_5985optimizer.scm",(void*)f_5985},
{"f_6122optimizer.scm",(void*)f_6122},
{"f_6532optimizer.scm",(void*)f_6532},
{"f_6539optimizer.scm",(void*)f_6539},
{"f_6125optimizer.scm",(void*)f_6125},
{"f_6519optimizer.scm",(void*)f_6519},
{"f_6495optimizer.scm",(void*)f_6495},
{"f_6506optimizer.scm",(void*)f_6506},
{"f_6462optimizer.scm",(void*)f_6462},
{"f_6401optimizer.scm",(void*)f_6401},
{"f_6373optimizer.scm",(void*)f_6373},
{"f_6378optimizer.scm",(void*)f_6378},
{"f_6320optimizer.scm",(void*)f_6320},
{"f_6326optimizer.scm",(void*)f_6326},
{"f_6331optimizer.scm",(void*)f_6331},
{"f_6279optimizer.scm",(void*)f_6279},
{"f_6285optimizer.scm",(void*)f_6285},
{"f_6290optimizer.scm",(void*)f_6290},
{"f_6263optimizer.scm",(void*)f_6263},
{"f_6259optimizer.scm",(void*)f_6259},
{"f_6229optimizer.scm",(void*)f_6229},
{"f_6192optimizer.scm",(void*)f_6192},
{"f_6208optimizer.scm",(void*)f_6208},
{"f_6174optimizer.scm",(void*)f_6174},
{"f_6541optimizer.scm",(void*)f_6541},
{"f_7077optimizer.scm",(void*)f_7077},
{"f_7075optimizer.scm",(void*)f_7075},
{"f_6545optimizer.scm",(void*)f_6545},
{"f_6555optimizer.scm",(void*)f_6555},
{"f_7049optimizer.scm",(void*)f_7049},
{"f_6561optimizer.scm",(void*)f_6561},
{"f_6567optimizer.scm",(void*)f_6567},
{"f_6570optimizer.scm",(void*)f_6570},
{"f_6576optimizer.scm",(void*)f_6576},
{"f_6752optimizer.scm",(void*)f_6752},
{"f_6974optimizer.scm",(void*)f_6974},
{"f_6977optimizer.scm",(void*)f_6977},
{"f_6927optimizer.scm",(void*)f_6927},
{"f_6930optimizer.scm",(void*)f_6930},
{"f_6796optimizer.scm",(void*)f_6796},
{"f_6851optimizer.scm",(void*)f_6851},
{"f_6854optimizer.scm",(void*)f_6854},
{"f_6881optimizer.scm",(void*)f_6881},
{"f_6857optimizer.scm",(void*)f_6857},
{"f_6860optimizer.scm",(void*)f_6860},
{"f_6805optimizer.scm",(void*)f_6805},
{"f_6808optimizer.scm",(void*)f_6808},
{"f_6811optimizer.scm",(void*)f_6811},
{"f_6579optimizer.scm",(void*)f_6579},
{"f_6734optimizer.scm",(void*)f_6734},
{"f_6732optimizer.scm",(void*)f_6732},
{"f_6675optimizer.scm",(void*)f_6675},
{"f_6685optimizer.scm",(void*)f_6685},
{"f_6582optimizer.scm",(void*)f_6582},
{"f_6594optimizer.scm",(void*)f_6594},
{"f_6633optimizer.scm",(void*)f_6633},
{"f_6597optimizer.scm",(void*)f_6597},
{"f_6600optimizer.scm",(void*)f_6600},
{"f_6605optimizer.scm",(void*)f_6605},
{"f_6631optimizer.scm",(void*)f_6631},
{"f_6612optimizer.scm",(void*)f_6612},
{"f_3977optimizer.scm",(void*)f_3977},
{"f_5825optimizer.scm",(void*)f_5825},
{"f_5828optimizer.scm",(void*)f_5828},
{"f_5850optimizer.scm",(void*)f_5850},
{"f_5862optimizer.scm",(void*)f_5862},
{"f_5876optimizer.scm",(void*)f_5876},
{"f_5925optimizer.scm",(void*)f_5925},
{"f_4002optimizer.scm",(void*)f_4002},
{"f_5896optimizer.scm",(void*)f_5896},
{"f_5900optimizer.scm",(void*)f_5900},
{"f_5870optimizer.scm",(void*)f_5870},
{"f_5856optimizer.scm",(void*)f_5856},
{"f_5854optimizer.scm",(void*)f_5854},
{"f_5843optimizer.scm",(void*)f_5843},
{"f_5762optimizer.scm",(void*)f_5762},
{"f_5765optimizer.scm",(void*)f_5765},
{"f_5797optimizer.scm",(void*)f_5797},
{"f_5784optimizer.scm",(void*)f_5784},
{"f_5608optimizer.scm",(void*)f_5608},
{"f_5611optimizer.scm",(void*)f_5611},
{"f_5617optimizer.scm",(void*)f_5617},
{"f_5701optimizer.scm",(void*)f_5701},
{"f_5626optimizer.scm",(void*)f_5626},
{"f_5670optimizer.scm",(void*)f_5670},
{"f_5668optimizer.scm",(void*)f_5668},
{"f_5642optimizer.scm",(void*)f_5642},
{"f_5535optimizer.scm",(void*)f_5535},
{"f_5538optimizer.scm",(void*)f_5538},
{"f_5566optimizer.scm",(void*)f_5566},
{"f_5578optimizer.scm",(void*)f_5578},
{"f_5556optimizer.scm",(void*)f_5556},
{"f_5551optimizer.scm",(void*)f_5551},
{"f_5387optimizer.scm",(void*)f_5387},
{"f_5390optimizer.scm",(void*)f_5390},
{"f_5471optimizer.scm",(void*)f_5471},
{"f_5399optimizer.scm",(void*)f_5399},
{"f_5452optimizer.scm",(void*)f_5452},
{"f_5450optimizer.scm",(void*)f_5450},
{"f_5415optimizer.scm",(void*)f_5415},
{"f_5352optimizer.scm",(void*)f_5352},
{"f_5355optimizer.scm",(void*)f_5355},
{"f_5365optimizer.scm",(void*)f_5365},
{"f_5284optimizer.scm",(void*)f_5284},
{"f_5287optimizer.scm",(void*)f_5287},
{"f_5307optimizer.scm",(void*)f_5307},
{"f_5205optimizer.scm",(void*)f_5205},
{"f_5208optimizer.scm",(void*)f_5208},
{"f_5238optimizer.scm",(void*)f_5238},
{"f_5112optimizer.scm",(void*)f_5112},
{"f_5115optimizer.scm",(void*)f_5115},
{"f_5134optimizer.scm",(void*)f_5134},
{"f_5127optimizer.scm",(void*)f_5127},
{"f_5029optimizer.scm",(void*)f_5029},
{"f_5032optimizer.scm",(void*)f_5032},
{"f_4964optimizer.scm",(void*)f_4964},
{"f_4967optimizer.scm",(void*)f_4967},
{"f_4982optimizer.scm",(void*)f_4982},
{"f_4985optimizer.scm",(void*)f_4985},
{"f_4888optimizer.scm",(void*)f_4888},
{"f_4891optimizer.scm",(void*)f_4891},
{"f_4934optimizer.scm",(void*)f_4934},
{"f_4927optimizer.scm",(void*)f_4927},
{"f_4823optimizer.scm",(void*)f_4823},
{"f_4826optimizer.scm",(void*)f_4826},
{"f_4838optimizer.scm",(void*)f_4838},
{"f_4851optimizer.scm",(void*)f_4851},
{"f_4844optimizer.scm",(void*)f_4844},
{"f_4736optimizer.scm",(void*)f_4736},
{"f_4758optimizer.scm",(void*)f_4758},
{"f_4766optimizer.scm",(void*)f_4766},
{"f_4770optimizer.scm",(void*)f_4770},
{"f_4592optimizer.scm",(void*)f_4592},
{"f_4614optimizer.scm",(void*)f_4614},
{"f_4617optimizer.scm",(void*)f_4617},
{"f_4676optimizer.scm",(void*)f_4676},
{"f_4620optimizer.scm",(void*)f_4620},
{"f_4623optimizer.scm",(void*)f_4623},
{"f_4654optimizer.scm",(void*)f_4654},
{"f_4652optimizer.scm",(void*)f_4652},
{"f_4628optimizer.scm",(void*)f_4628},
{"f_4608optimizer.scm",(void*)f_4608},
{"f_4565optimizer.scm",(void*)f_4565},
{"f_4568optimizer.scm",(void*)f_4568},
{"f_4504optimizer.scm",(void*)f_4504},
{"f_4507optimizer.scm",(void*)f_4507},
{"f_4531optimizer.scm",(void*)f_4531},
{"f_4520optimizer.scm",(void*)f_4520},
{"f_4439optimizer.scm",(void*)f_4439},
{"f_4346optimizer.scm",(void*)f_4346},
{"f_4349optimizer.scm",(void*)f_4349},
{"f_4391optimizer.scm",(void*)f_4391},
{"f_4290optimizer.scm",(void*)f_4290},
{"f_4303optimizer.scm",(void*)f_4303},
{"f_4311optimizer.scm",(void*)f_4311},
{"f_4246optimizer.scm",(void*)f_4246},
{"f_4249optimizer.scm",(void*)f_4249},
{"f_4259optimizer.scm",(void*)f_4259},
{"f_4142optimizer.scm",(void*)f_4142},
{"f_4145optimizer.scm",(void*)f_4145},
{"f_4202optimizer.scm",(void*)f_4202},
{"f_4173optimizer.scm",(void*)f_4173},
{"f_4170optimizer.scm",(void*)f_4170},
{"f_4034optimizer.scm",(void*)f_4034},
{"f_4097optimizer.scm",(void*)f_4097},
{"f_4037optimizer.scm",(void*)f_4037},
{"f_3980optimizer.scm",(void*)f_3980},
{"f_3957optimizer.scm",(void*)f_3957},
{"f_3961optimizer.scm",(void*)f_3961},
{"f_3971optimizer.scm",(void*)f_3971},
{"f_3629optimizer.scm",(void*)f_3629},
{"f_3633optimizer.scm",(void*)f_3633},
{"f_3942optimizer.scm",(void*)f_3942},
{"f_3951optimizer.scm",(void*)f_3951},
{"f_3947optimizer.scm",(void*)f_3947},
{"f_3680optimizer.scm",(void*)f_3680},
{"f_3884optimizer.scm",(void*)f_3884},
{"f_3916optimizer.scm",(void*)f_3916},
{"f_3929optimizer.scm",(void*)f_3929},
{"f_3894optimizer.scm",(void*)f_3894},
{"f_3910optimizer.scm",(void*)f_3910},
{"f_3898optimizer.scm",(void*)f_3898},
{"f_3902optimizer.scm",(void*)f_3902},
{"f_3683optimizer.scm",(void*)f_3683},
{"f_3825optimizer.scm",(void*)f_3825},
{"f_3868optimizer.scm",(void*)f_3868},
{"f_3874optimizer.scm",(void*)f_3874},
{"f_3832optimizer.scm",(void*)f_3832},
{"f_3842optimizer.scm",(void*)f_3842},
{"f_3855optimizer.scm",(void*)f_3855},
{"f_3840optimizer.scm",(void*)f_3840},
{"f_3836optimizer.scm",(void*)f_3836},
{"f_3686optimizer.scm",(void*)f_3686},
{"f_3689optimizer.scm",(void*)f_3689},
{"f_3709optimizer.scm",(void*)f_3709},
{"f_3722optimizer.scm",(void*)f_3722},
{"f_3765optimizer.scm",(void*)f_3765},
{"f_3797optimizer.scm",(void*)f_3797},
{"f_3763optimizer.scm",(void*)f_3763},
{"f_3745optimizer.scm",(void*)f_3745},
{"f_3692optimizer.scm",(void*)f_3692},
{"f_3701optimizer.scm",(void*)f_3701},
{"f_3635optimizer.scm",(void*)f_3635},
{"f_3641optimizer.scm",(void*)f_3641},
{"f_3665optimizer.scm",(void*)f_3665},
{"f_3614optimizer.scm",(void*)f_3614},
{"f_3153optimizer.scm",(void*)f_3153},
{"f_3167optimizer.scm",(void*)f_3167},
{"f_3402optimizer.scm",(void*)f_3402},
{"f_3609optimizer.scm",(void*)f_3609},
{"f_3407optimizer.scm",(void*)f_3407},
{"f_3598optimizer.scm",(void*)f_3598},
{"f_3420optimizer.scm",(void*)f_3420},
{"f_3423optimizer.scm",(void*)f_3423},
{"f_3429optimizer.scm",(void*)f_3429},
{"f_3444optimizer.scm",(void*)f_3444},
{"f_3450optimizer.scm",(void*)f_3450},
{"f_3456optimizer.scm",(void*)f_3456},
{"f_3465optimizer.scm",(void*)f_3465},
{"f_3472optimizer.scm",(void*)f_3472},
{"f_3475optimizer.scm",(void*)f_3475},
{"f_3493optimizer.scm",(void*)f_3493},
{"f_3478optimizer.scm",(void*)f_3478},
{"f_3170optimizer.scm",(void*)f_3170},
{"f_3184optimizer.scm",(void*)f_3184},
{"f_3191optimizer.scm",(void*)f_3191},
{"f_3396optimizer.scm",(void*)f_3396},
{"f_3196optimizer.scm",(void*)f_3196},
{"f_3209optimizer.scm",(void*)f_3209},
{"f_3385optimizer.scm",(void*)f_3385},
{"f_3212optimizer.scm",(void*)f_3212},
{"f_3359optimizer.scm",(void*)f_3359},
{"f_3357optimizer.scm",(void*)f_3357},
{"f_3218optimizer.scm",(void*)f_3218},
{"f_3230optimizer.scm",(void*)f_3230},
{"f_3236optimizer.scm",(void*)f_3236},
{"f_3245optimizer.scm",(void*)f_3245},
{"f_3251optimizer.scm",(void*)f_3251},
{"f_3254optimizer.scm",(void*)f_3254},
{"f_3272optimizer.scm",(void*)f_3272},
{"f_3257optimizer.scm",(void*)f_3257},
{"f_3173optimizer.scm",(void*)f_3173},
{"f_3176optimizer.scm",(void*)f_3176},
{"f_3160optimizer.scm",(void*)f_3160},
{"f_3156optimizer.scm",(void*)f_3156},
{"f_1682optimizer.scm",(void*)f_1682},
{"f_3057optimizer.scm",(void*)f_3057},
{"f_3063optimizer.scm",(void*)f_3063},
{"f_3067optimizer.scm",(void*)f_3067},
{"f_3070optimizer.scm",(void*)f_3070},
{"f_3106optimizer.scm",(void*)f_3106},
{"f_3111optimizer.scm",(void*)f_3111},
{"f_3115optimizer.scm",(void*)f_3115},
{"f_3073optimizer.scm",(void*)f_3073},
{"f_3076optimizer.scm",(void*)f_3076},
{"f_3079optimizer.scm",(void*)f_3079},
{"f_3082optimizer.scm",(void*)f_3082},
{"f_3038optimizer.scm",(void*)f_3038},
{"f_3042optimizer.scm",(void*)f_3042},
{"f_3048optimizer.scm",(void*)f_3048},
{"f_2023optimizer.scm",(void*)f_2023},
{"f_2948optimizer.scm",(void*)f_2948},
{"f_2951optimizer.scm",(void*)f_2951},
{"f_3030optimizer.scm",(void*)f_3030},
{"f_2992optimizer.scm",(void*)f_2992},
{"f_3013optimizer.scm",(void*)f_3013},
{"f_3005optimizer.scm",(void*)f_3005},
{"f_2963optimizer.scm",(void*)f_2963},
{"f_2982optimizer.scm",(void*)f_2982},
{"f_2969optimizer.scm",(void*)f_2969},
{"f_2923optimizer.scm",(void*)f_2923},
{"f_2898optimizer.scm",(void*)f_2898},
{"f_2356optimizer.scm",(void*)f_2356},
{"f_2365optimizer.scm",(void*)f_2365},
{"f_2539optimizer.scm",(void*)f_2539},
{"f_2550optimizer.scm",(void*)f_2550},
{"f_2849optimizer.scm",(void*)f_2849},
{"f_2855optimizer.scm",(void*)f_2855},
{"f_2560optimizer.scm",(void*)f_2560},
{"f_2597optimizer.scm",(void*)f_2597},
{"f_2839optimizer.scm",(void*)f_2839},
{"f_2756optimizer.scm",(void*)f_2756},
{"f_2771optimizer.scm",(void*)f_2771},
{"f_2782optimizer.scm",(void*)f_2782},
{"f_2809optimizer.scm",(void*)f_2809},
{"f_2801optimizer.scm",(void*)f_2801},
{"f_2786optimizer.scm",(void*)f_2786},
{"f_2776optimizer.scm",(void*)f_2776},
{"f_2611optimizer.scm",(void*)f_2611},
{"f_2644optimizer.scm",(void*)f_2644},
{"f_2650optimizer.scm",(void*)f_2650},
{"f_2656optimizer.scm",(void*)f_2656},
{"f_2693optimizer.scm",(void*)f_2693},
{"f_2669optimizer.scm",(void*)f_2669},
{"f_2673optimizer.scm",(void*)f_2673},
{"f_2638optimizer.scm",(void*)f_2638},
{"f_2627optimizer.scm",(void*)f_2627},
{"f_2563optimizer.scm",(void*)f_2563},
{"f_2566optimizer.scm",(void*)f_2566},
{"f_2569optimizer.scm",(void*)f_2569},
{"f_2579optimizer.scm",(void*)f_2579},
{"f_2525optimizer.scm",(void*)f_2525},
{"f_2428optimizer.scm",(void*)f_2428},
{"f_2446optimizer.scm",(void*)f_2446},
{"f_2503optimizer.scm",(void*)f_2503},
{"f_2495optimizer.scm",(void*)f_2495},
{"f_2449optimizer.scm",(void*)f_2449},
{"f_2474optimizer.scm",(void*)f_2474},
{"f_2472optimizer.scm",(void*)f_2472},
{"f_2458optimizer.scm",(void*)f_2458},
{"f_2407optimizer.scm",(void*)f_2407},
{"f_2374optimizer.scm",(void*)f_2374},
{"f_2377optimizer.scm",(void*)f_2377},
{"f_2387optimizer.scm",(void*)f_2387},
{"f_2180optimizer.scm",(void*)f_2180},
{"f_2272optimizer.scm",(void*)f_2272},
{"f_2277optimizer.scm",(void*)f_2277},
{"f_2284optimizer.scm",(void*)f_2284},
{"f_2313optimizer.scm",(void*)f_2313},
{"f_2297optimizer.scm",(void*)f_2297},
{"f_2185optimizer.scm",(void*)f_2185},
{"f_2203optimizer.scm",(void*)f_2203},
{"f_2210optimizer.scm",(void*)f_2210},
{"f_2246optimizer.scm",(void*)f_2246},
{"f_2249optimizer.scm",(void*)f_2249},
{"f_2239optimizer.scm",(void*)f_2239},
{"f_2223optimizer.scm",(void*)f_2223},
{"f_2191optimizer.scm",(void*)f_2191},
{"f_2197optimizer.scm",(void*)f_2197},
{"f_2123optimizer.scm",(void*)f_2123},
{"f_2149optimizer.scm",(void*)f_2149},
{"f_2158optimizer.scm",(void*)f_2158},
{"f_2165optimizer.scm",(void*)f_2165},
{"f_2126optimizer.scm",(void*)f_2126},
{"f_2143optimizer.scm",(void*)f_2143},
{"f_2048optimizer.scm",(void*)f_2048},
{"f_2052optimizer.scm",(void*)f_2052},
{"f_2064optimizer.scm",(void*)f_2064},
{"f_2087optimizer.scm",(void*)f_2087},
{"f_2070optimizer.scm",(void*)f_2070},
{"f_2081optimizer.scm",(void*)f_2081},
{"f_1807optimizer.scm",(void*)f_1807},
{"f_1821optimizer.scm",(void*)f_1821},
{"f_1988optimizer.scm",(void*)f_1988},
{"f_1991optimizer.scm",(void*)f_1991},
{"f_1997optimizer.scm",(void*)f_1997},
{"f_1891optimizer.scm",(void*)f_1891},
{"f_1973optimizer.scm",(void*)f_1973},
{"f_1971optimizer.scm",(void*)f_1971},
{"f_1902optimizer.scm",(void*)f_1902},
{"f_1925optimizer.scm",(void*)f_1925},
{"f_1957optimizer.scm",(void*)f_1957},
{"f_1963optimizer.scm",(void*)f_1963},
{"f_1931optimizer.scm",(void*)f_1931},
{"f_1935optimizer.scm",(void*)f_1935},
{"f_1938optimizer.scm",(void*)f_1938},
{"f_1955optimizer.scm",(void*)f_1955},
{"f_1908optimizer.scm",(void*)f_1908},
{"f_1914optimizer.scm",(void*)f_1914},
{"f_1918optimizer.scm",(void*)f_1918},
{"f_1922optimizer.scm",(void*)f_1922},
{"f_1900optimizer.scm",(void*)f_1900},
{"f_1839optimizer.scm",(void*)f_1839},
{"f_1830optimizer.scm",(void*)f_1830},
{"f_1715optimizer.scm",(void*)f_1715},
{"f_1719optimizer.scm",(void*)f_1719},
{"f_1730optimizer.scm",(void*)f_1730},
{"f_1740optimizer.scm",(void*)f_1740},
{"f_1789optimizer.scm",(void*)f_1789},
{"f_1787optimizer.scm",(void*)f_1787},
{"f_1746optimizer.scm",(void*)f_1746},
{"f_1752optimizer.scm",(void*)f_1752},
{"f_1779optimizer.scm",(void*)f_1779},
{"f_1758optimizer.scm",(void*)f_1758},
{"f_1722optimizer.scm",(void*)f_1722},
{"f_1711optimizer.scm",(void*)f_1711},
{"f_1701optimizer.scm",(void*)f_1701},
{"f_1691optimizer.scm",(void*)f_1691},
{"f_1685optimizer.scm",(void*)f_1685},
{"f_1476optimizer.scm",(void*)f_1476},
{"f_1497optimizer.scm",(void*)f_1497},
{"f_1509optimizer.scm",(void*)f_1509},
{"f_1524optimizer.scm",(void*)f_1524},
{"f_1576optimizer.scm",(void*)f_1576},
{"f_1595optimizer.scm",(void*)f_1595},
{"f_1606optimizer.scm",(void*)f_1606},
{"f_1579optimizer.scm",(void*)f_1579},
{"f_1549optimizer.scm",(void*)f_1549},
{"f_1512optimizer.scm",(void*)f_1512},
{"f_1518optimizer.scm",(void*)f_1518},
{"f_1500optimizer.scm",(void*)f_1500},
{"f_1503optimizer.scm",(void*)f_1503},
{"f_1507optimizer.scm",(void*)f_1507},
{"f_1479optimizer.scm",(void*)f_1479},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
