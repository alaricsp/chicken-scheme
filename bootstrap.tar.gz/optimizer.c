/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-17 11:10
   Version 4.0.0x - linux-unix-gnu-x86	[ dload ptables applyhook lockts ]
   SVN rev. 11775	compiled 2008-08-28 on dill (Linux)
   command line: optimizer.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[265];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13075)
static void C_ccall f_13075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_13083)
static void C_ccall f_13083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13088)
static void C_fcall f_13088(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13133)
static void C_ccall f_13133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13137)
static void C_ccall f_13137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13098)
static void C_ccall f_13098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13122)
static void C_ccall f_13122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13107)
static void C_fcall f_13107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12026)
static void C_ccall f_12026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_12072)
static void C_ccall f_12072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12060)
static void C_ccall f_12060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12055)
static void C_ccall f_12055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12047)
static void C_ccall f_12047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12174)
static void C_ccall f_12174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12184)
static void C_fcall f_12184(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12483)
static void C_ccall f_12483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12188)
static void C_ccall f_12188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12478)
static void C_ccall f_12478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12191)
static void C_ccall f_12191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12473)
static void C_ccall f_12473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12194)
static void C_ccall f_12194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12464)
static void C_ccall f_12464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12212)
static void C_ccall f_12212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12459)
static void C_ccall f_12459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12215)
static void C_ccall f_12215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12454)
static void C_ccall f_12454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12218)
static void C_ccall f_12218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12248)
static void C_ccall f_12248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12277)
static void C_fcall f_12277(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12437)
static void C_ccall f_12437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12281)
static void C_ccall f_12281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12432)
static void C_ccall f_12432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12284)
static void C_ccall f_12284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12427)
static void C_ccall f_12427(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12287)
static void C_ccall f_12287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12418)
static void C_ccall f_12418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12410)
static void C_ccall f_12410(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12405)
static void C_ccall f_12405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12397)
static void C_ccall f_12397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12392)
static void C_ccall f_12392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12293)
static void C_fcall f_12293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12346)
static void C_ccall f_12346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12336)
static void C_ccall f_12336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12344)
static void C_ccall f_12344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12321)
static void C_ccall f_12321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12316)
static void C_ccall f_12316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12533)
static void C_ccall f_12533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_12546)
static void C_ccall f_12546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12588)
static void C_ccall f_12588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12572)
static void C_ccall f_12572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12576)
static void C_ccall f_12576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12563)
static void C_ccall f_12563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12564)
static void C_ccall f_12564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12754)
static void C_ccall f_12754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_12767)
static void C_ccall f_12767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12773)
static void C_ccall f_12773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12825)
static void C_ccall f_12825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12817)
static void C_ccall f_12817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12801)
static void C_ccall f_12801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12805)
static void C_ccall f_12805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12809)
static void C_ccall f_12809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12793)
static void C_ccall f_12793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11667)
static void C_ccall f_11667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_11689)
static void C_ccall f_11689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11769)
static void C_ccall f_11769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11727)
static void C_ccall f_11727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11761)
static void C_ccall f_11761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11765)
static void C_ccall f_11765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11753)
static void C_ccall f_11753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11744)
static void C_ccall f_11744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11748)
static void C_ccall f_11748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11736)
static void C_ccall f_11736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11725)
static void C_ccall f_11725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11717)
static void C_ccall f_11717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11712)
static void C_ccall f_11712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11704)
static void C_ccall f_11704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11863)
static void C_ccall f_11863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_11883)
static void C_ccall f_11883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11892)
static void C_ccall f_11892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11887)
static void C_ccall f_11887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11875)
static void C_ccall f_11875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5810)
static void C_ccall f_5810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9803)
static void C_ccall f_9803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11546)
static void C_ccall f_11546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11549)
static void C_ccall f_11549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11552)
static void C_ccall f_11552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11555)
static void C_ccall f_11555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11558)
static void C_ccall f_11558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11561)
static void C_ccall f_11561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11638)
static void C_ccall f_11638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11564)
static void C_ccall f_11564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11567)
static void C_ccall f_11567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11570)
static void C_ccall f_11570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11632)
static void C_ccall f_11632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11573)
static void C_ccall f_11573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11576)
static void C_ccall f_11576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11629)
static void C_ccall f_11629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10458)
static void C_fcall f_10458(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10476)
static void C_ccall f_10476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10482)
static void C_ccall f_10482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10462)
static void C_ccall f_10462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11579)
static void C_ccall f_11579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11621)
static void C_ccall f_11621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11619)
static void C_ccall f_11619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11582)
static void C_ccall f_11582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11585)
static void C_ccall f_11585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11588)
static void C_ccall f_11588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11612)
static void C_ccall f_11612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11591)
static void C_ccall f_11591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11594)
static void C_ccall f_11594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11597)
static void C_ccall f_11597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11600)
static void C_ccall f_11600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11603)
static void C_ccall f_11603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11606)
static void C_ccall f_11606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11374)
static void C_fcall f_11374(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11380)
static void C_ccall f_11380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11539)
static void C_ccall f_11539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11384)
static void C_ccall f_11384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11534)
static void C_ccall f_11534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11387)
static void C_ccall f_11387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11529)
static void C_ccall f_11529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11390)
static void C_ccall f_11390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11521)
static void C_ccall f_11521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11520)
static void C_ccall f_11520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11497)
static void C_ccall f_11497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11506)
static void C_ccall f_11506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11509)
static void C_ccall f_11509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11484)
static void C_ccall f_11484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11483)
static void C_ccall f_11483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11399)
static void C_ccall f_11399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11404)
static void C_fcall f_11404(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11445)
static void C_fcall f_11445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11442)
static void C_ccall f_11442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11427)
static void C_ccall f_11427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11438)
static void C_ccall f_11438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11434)
static void C_ccall f_11434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11257)
static void C_fcall f_11257(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11263)
static void C_ccall f_11263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11368)
static void C_ccall f_11368(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11267)
static void C_ccall f_11267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11363)
static void C_ccall f_11363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11270)
static void C_ccall f_11270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11358)
static void C_ccall f_11358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11273)
static void C_ccall f_11273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11350)
static void C_ccall f_11350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11349)
static void C_ccall f_11349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11341)
static void C_ccall f_11341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11340)
static void C_ccall f_11340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11324)
static void C_ccall f_11324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11320)
static void C_ccall f_11320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11285)
static void C_ccall f_11285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11293)
static void C_ccall f_11293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11292)
static void C_ccall f_11292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10952)
static void C_fcall f_10952(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11108)
static void C_ccall f_11108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11107)
static void C_ccall f_11107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10966)
static void C_ccall f_10966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10973)
static void C_ccall f_10973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10976)
static void C_ccall f_10976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11095)
static void C_ccall f_11095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11094)
static void C_ccall f_11094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10985)
static void C_ccall f_10985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10992)
static void C_ccall f_10992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10995)
static void C_ccall f_10995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11082)
static void C_ccall f_11082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11081)
static void C_ccall f_11081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11132)
static void C_ccall f_11132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11251)
static void C_ccall f_11251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11136)
static void C_ccall f_11136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11246)
static void C_ccall f_11246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11241)
static void C_ccall f_11241(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11142)
static void C_ccall f_11142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11218)
static void C_ccall f_11218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11237)
static void C_ccall f_11237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11233)
static void C_ccall f_11233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11199)
static void C_ccall f_11199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11188)
static void C_ccall f_11188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11175)
static void C_ccall f_11175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11151)
static void C_ccall f_11151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11117)
static void C_ccall f_11117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10998)
static void C_ccall f_10998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11073)
static void C_ccall f_11073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11061)
static void C_ccall f_11061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11057)
static void C_ccall f_11057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11049)
static void C_ccall f_11049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11043)
static void C_ccall f_11043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11044)
static void C_ccall f_11044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11035)
static void C_ccall f_11035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11027)
static void C_ccall f_11027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11018)
static void C_ccall f_11018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11010)
static void C_ccall f_11010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10964)
static void C_ccall f_10964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10736)
static void C_fcall f_10736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10938)
static void C_ccall f_10938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10816)
static void C_ccall f_10816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10893)
static void C_ccall f_10893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10898)
static void C_ccall f_10898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10936)
static void C_ccall f_10936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10745)
static void C_ccall f_10745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10809)
static void C_ccall f_10809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10749)
static void C_ccall f_10749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10804)
static void C_ccall f_10804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10752)
static void C_ccall f_10752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10755)
static void C_ccall f_10755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10783)
static void C_ccall f_10783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10788)
static void C_ccall f_10788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10765)
static void C_ccall f_10765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10743)
static void C_ccall f_10743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10928)
static void C_ccall f_10928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10914)
static void C_ccall f_10914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10912)
static void C_ccall f_10912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10818)
static void C_ccall f_10818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10886)
static void C_ccall f_10886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10884)
static void C_ccall f_10884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10872)
static void C_ccall f_10872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10838)
static void C_ccall f_10838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10862)
static void C_ccall f_10862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10860)
static void C_ccall f_10860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10856)
static void C_ccall f_10856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10848)
static void C_ccall f_10848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10492)
static void C_fcall f_10492(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10498)
static void C_fcall f_10498(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10730)
static void C_ccall f_10730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10502)
static void C_ccall f_10502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10725)
static void C_ccall f_10725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10505)
static void C_ccall f_10505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10720)
static void C_ccall f_10720(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10508)
static void C_ccall f_10508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10517)
static void C_fcall f_10517(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10694)
static void C_ccall f_10694(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10614)
static void C_ccall f_10614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10684)
static void C_ccall f_10684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10676)
static void C_ccall f_10676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10675)
static void C_ccall f_10675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10630)
static void C_ccall f_10630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10660)
static void C_ccall f_10660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10664)
static void C_ccall f_10664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10650)
static void C_ccall f_10650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10603)
static void C_ccall f_10603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10608)
static void C_ccall f_10608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10579)
static void C_ccall f_10579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10591)
static void C_ccall f_10591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10528)
static void C_fcall f_10528(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10549)
static void C_ccall f_10549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10546)
static void C_ccall f_10546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10496)
static void C_ccall f_10496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10233)
static void C_fcall f_10233(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10239)
static void C_fcall f_10239(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10396)
static void C_ccall f_10396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10243)
static void C_ccall f_10243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10391)
static void C_ccall f_10391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10246)
static void C_ccall f_10246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10386)
static void C_ccall f_10386(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10249)
static void C_ccall f_10249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10258)
static void C_fcall f_10258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10360)
static void C_ccall f_10360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10351)
static void C_ccall f_10351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10317)
static void C_fcall f_10317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10326)
static void C_ccall f_10326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10338)
static void C_ccall f_10338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10269)
static void C_fcall f_10269(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10290)
static void C_ccall f_10290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10287)
static void C_ccall f_10287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10237)
static void C_ccall f_10237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10134)
static void C_fcall f_10134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10140)
static void C_ccall f_10140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10189)
static void C_fcall f_10189(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10196)
static void C_ccall f_10196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10223)
static void C_ccall f_10223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10219)
static void C_ccall f_10219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10211)
static void C_ccall f_10211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10209)
static void C_ccall f_10209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10174)
static void C_ccall f_10174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10152)
static void C_ccall f_10152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10159)
static void C_ccall f_10159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9912)
static void C_fcall f_9912(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10081)
static void C_ccall f_10081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10128)
static void C_ccall f_10128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10127)
static void C_ccall f_10127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10106)
static void C_ccall f_10106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10119)
static void C_ccall f_10119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10118)
static void C_ccall f_10118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10096)
static void C_ccall f_10096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10100)
static void C_ccall f_10100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10079)
static void C_ccall f_10079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9915)
static void C_fcall f_9915(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10072)
static void C_ccall f_10072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10067)
static void C_ccall f_10067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9922)
static void C_ccall f_9922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10062)
static void C_ccall f_10062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9925)
static void C_ccall f_9925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10054)
static void C_ccall f_10054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10037)
static void C_ccall f_10037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10049)
static void C_ccall f_10049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9983)
static void C_fcall f_9983(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10007)
static void C_ccall f_10007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10001)
static void C_ccall f_10001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9965)
static void C_ccall f_9965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9940)
static void C_fcall f_9940(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9943)
static void C_fcall f_9943(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9948)
static void C_ccall f_9948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9806)
static void C_fcall f_9806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9812)
static void C_ccall f_9812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9898)
static void C_ccall f_9898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9843)
static void C_fcall f_9843(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9847)
static void C_ccall f_9847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9851)
static void C_ccall f_9851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8538)
static void C_ccall f_8538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9798)
static void C_ccall f_9798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9801)
static void C_ccall f_9801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8541)
static void C_fcall f_8541(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8712)
static void C_ccall f_8712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8545)
static void C_ccall f_8545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8702)
static void C_ccall f_8702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8551)
static void C_ccall f_8551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8697)
static void C_ccall f_8697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8677)
static void C_ccall f_8677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8651)
static void C_ccall f_8651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8597)
static void C_ccall f_8597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8603)
static void C_ccall f_8603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8609)
static void C_ccall f_8609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8566)
static void C_ccall f_8566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8718)
static void C_fcall f_8718(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9163)
static void C_ccall f_9163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8721)
static void C_fcall f_8721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9150)
static void C_ccall f_9150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8725)
static void C_ccall f_8725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9145)
static void C_ccall f_9145(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8728)
static void C_ccall f_8728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8731)
static void C_ccall f_8731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9135)
static void C_ccall f_9135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9111)
static void C_ccall f_9111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9044)
static void C_ccall f_9044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9043)
static void C_ccall f_9043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9035)
static void C_ccall f_9035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9022)
static void C_ccall f_9022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9014)
static void C_ccall f_9014(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8997)
static void C_fcall f_8997(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8969)
static void C_fcall f_8969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8916)
static void C_ccall f_8916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8922)
static void C_fcall f_8922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8927)
static void C_ccall f_8927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8875)
static void C_ccall f_8875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static void C_fcall f_8881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8859)
static void C_ccall f_8859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8825)
static void C_ccall f_8825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8788)
static void C_ccall f_8788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8804)
static void C_ccall f_8804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8770)
static void C_ccall f_8770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_fcall f_9172(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_9788)
static void C_ccall f_9788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9176)
static void C_ccall f_9176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9772)
static void C_ccall f_9772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9180)
static void C_ccall f_9180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9186)
static void C_ccall f_9186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9192)
static void C_fcall f_9192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9198)
static void C_ccall f_9198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9201)
static void C_ccall f_9201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9207)
static void C_ccall f_9207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9736)
static void C_ccall f_9736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9735)
static void C_ccall f_9735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9446)
static void C_ccall f_9446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9727)
static void C_ccall f_9727(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9453)
static void C_ccall f_9453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9717)
static void C_ccall f_9717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9456)
static void C_ccall f_9456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9700)
static void C_ccall f_9700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9703)
static void C_ccall f_9703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9674)
static void C_ccall f_9674(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9471)
static void C_ccall f_9471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9669)
static void C_ccall f_9669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9474)
static void C_ccall f_9474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9664)
static void C_ccall f_9664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9663)
static void C_ccall f_9663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9638)
static void C_ccall f_9638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9641)
static void C_ccall f_9641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9490)
static void C_ccall f_9490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9614)
static void C_ccall f_9614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9613)
static void C_ccall f_9613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9545)
static void C_ccall f_9545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9548)
static void C_ccall f_9548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9591)
static void C_ccall f_9591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9590)
static void C_ccall f_9590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9582)
static void C_ccall f_9582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9551)
static void C_ccall f_9551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9574)
static void C_ccall f_9574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9565)
static void C_ccall f_9565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9554)
static void C_ccall f_9554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9499)
static void C_ccall f_9499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9502)
static void C_ccall f_9502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9505)
static void C_ccall f_9505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9428)
static void C_ccall f_9428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9426)
static void C_ccall f_9426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9357)
static void C_ccall f_9357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9418)
static void C_ccall f_9418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9364)
static void C_ccall f_9364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9367)
static void C_ccall f_9367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9391)
static void C_ccall f_9391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9382)
static void C_ccall f_9382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9213)
static void C_ccall f_9213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9348)
static void C_ccall f_9348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9222)
static void C_ccall f_9222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9225)
static void C_ccall f_9225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9274)
static void C_ccall f_9274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9339)
static void C_ccall f_9339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9334)
static void C_ccall f_9334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9326)
static void C_ccall f_9326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9302)
static void C_ccall f_9302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9321)
static void C_ccall f_9321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9306)
static void C_ccall f_9306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9316)
static void C_ccall f_9316(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9310)
static void C_ccall f_9310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9311)
static void C_ccall f_9311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9298)
static void C_ccall f_9298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9231)
static void C_ccall f_9231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9236)
static void C_ccall f_9236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9272)
static void C_ccall f_9272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9243)
static void C_ccall f_9243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9260)
static void C_ccall f_9260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9250)
static void C_ccall f_9250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9255)
static void C_ccall f_9255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9254)
static void C_ccall f_9254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8400)
static void C_ccall f_8400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8429)
static void C_ccall f_8429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8441)
static void C_ccall f_8441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8455)
static void C_fcall f_8455(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8504)
static void C_ccall f_8504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6217)
static void C_fcall f_6217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8479)
static void C_ccall f_8479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8449)
static void C_ccall f_8449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8435)
static void C_ccall f_8435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8420)
static void C_ccall f_8420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8421)
static void C_ccall f_8421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8381)
static void C_ccall f_8381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8356)
static void C_ccall f_8356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8345)
static void C_ccall f_8345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8286)
static void C_ccall f_8286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8275)
static void C_ccall f_8275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8266)
static void C_ccall f_8266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8237)
static void C_ccall f_8237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8221)
static void C_ccall f_8221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8200)
static void C_ccall f_8200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8192)
static void C_ccall f_8192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8162)
static void C_ccall f_8162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8102)
static void C_ccall f_8102(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8040)
static void C_ccall f_8040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8071)
static void C_ccall f_8071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8064)
static void C_ccall f_8064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8065)
static void C_ccall f_8065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8056)
static void C_ccall f_8056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8048)
static void C_ccall f_8048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8003)
static void C_ccall f_8003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7964)
static void C_ccall f_7964(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7991)
static void C_ccall f_7991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7982)
static void C_ccall f_7982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7867)
static void C_ccall f_7867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7951)
static void C_ccall f_7951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7936)
static void C_ccall f_7936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7785)
static void C_ccall f_7785(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7771)
static void C_fcall f_7771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7755)
static void C_ccall f_7755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7649)
static void C_ccall f_7649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_fcall f_7691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7679)
static void C_ccall f_7679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7674)
static void C_ccall f_7674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7666)
static void C_ccall f_7666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7605)
static void C_ccall f_7605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7544)
static void C_ccall f_7544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_ccall f_7561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7562)
static void C_ccall f_7562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7486)
static void C_ccall f_7486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7392)
static void C_fcall f_7392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7405)
static void C_ccall f_7405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7396)
static void C_ccall f_7396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7397)
static void C_ccall f_7397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7354)
static void C_ccall f_7354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7285)
static void C_ccall f_7285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7332)
static void C_ccall f_7332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7266)
static void C_ccall f_7266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7214)
static void C_ccall f_7214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_fcall f_7226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7246)
static void C_ccall f_7246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7237)
static void C_ccall f_7237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7186)
static void C_ccall f_7186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7144)
static void C_ccall f_7144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7152)
static void C_ccall f_7152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7156)
static void C_ccall f_7156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6941)
static void C_ccall f_6941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6969)
static void C_fcall f_6969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6972)
static void C_fcall f_6972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6975)
static void C_ccall f_6975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7020)
static void C_ccall f_7020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7009)
static void C_ccall f_7009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6983)
static void C_ccall f_6983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6955)
static void C_ccall f_6955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_ccall f_6888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6879)
static void C_ccall f_6879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6866)
static void C_ccall f_6866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6804)
static void C_ccall f_6804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6786)
static void C_ccall f_6786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6778)
static void C_ccall f_6778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6769)
static void C_ccall f_6769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6719)
static void C_ccall f_6719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6682)
static void C_ccall f_6682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6674)
static void C_ccall f_6674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6580)
static void C_ccall f_6580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6600)
static void C_ccall f_6600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6400)
static void C_ccall f_6400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_fcall f_6434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6431)
static void C_ccall f_6431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6423)
static void C_ccall f_6423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6249)
static void C_ccall f_6249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6352)
static void C_ccall f_6352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6344)
static void C_ccall f_6344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6279)
static void C_ccall f_6279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6172)
static void C_ccall f_6172r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6186)
static void C_ccall f_6186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6144)
static void C_ccall f_6144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5905)
static void C_fcall f_5905(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5966)
static void C_ccall f_5966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5934)
static void C_ccall f_5934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5956)
static void C_ccall f_5956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5818)
static void C_fcall f_5818(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5824)
static void C_fcall f_5824(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5797)
static void C_ccall f_5797r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_ccall f_5765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_fcall f_5556(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_fcall f_5571(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_fcall f_5583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5651)
static void C_ccall f_5651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5642)
static void C_ccall f_5642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_fcall f_5592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5274)
static void C_ccall f_5274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5280)
static void C_ccall f_5280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5482)
static void C_ccall f_5482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_fcall f_5289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_fcall f_5301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5316)
static void C_fcall f_5316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5231)
static void C_fcall f_5231(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5227)
static C_word C_fcall f_5227(C_word t0);
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_ccall f_5144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5150)
static void C_ccall f_5150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_fcall f_5104(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3911)
static void C_fcall f_3911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_fcall f_5049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_fcall f_5009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5031)
static void C_ccall f_5031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4957)
static void C_ccall f_4957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_fcall f_4489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_fcall f_4510(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_fcall f_4745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_fcall f_4587(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4438)
static void C_ccall f_4438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_fcall f_4373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_ccall f_4291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_fcall f_4020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3936)
static void C_fcall f_3936(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_fcall f_3981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3664)
static void C_ccall f_3664(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_ccall f_3895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_fcall f_3775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_fcall f_3567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3610)
static void C_fcall f_3610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static C_word C_fcall f_3563(C_word t0);
C_noret_decl(f_3548)
static void C_fcall f_3548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_fcall f_3527(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3351)
static void C_fcall f_3351(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_fcall f_3403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_fcall f_3376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_fcall f_3339(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_13088)
static void C_fcall trf_13088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13088(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13088(t0,t1,t2);}

C_noret_decl(trf_13107)
static void C_fcall trf_13107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13107(t0,t1);}

C_noret_decl(trf_12184)
static void C_fcall trf_12184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12184(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12184(t0,t1,t2,t3);}

C_noret_decl(trf_12277)
static void C_fcall trf_12277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12277(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_12277(t0,t1,t2,t3,t4);}

C_noret_decl(trf_12293)
static void C_fcall trf_12293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12293(t0,t1);}

C_noret_decl(trf_10458)
static void C_fcall trf_10458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10458(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10458(t0,t1,t2,t3);}

C_noret_decl(trf_11374)
static void C_fcall trf_11374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11374(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11374(t0,t1,t2);}

C_noret_decl(trf_11404)
static void C_fcall trf_11404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11404(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11404(t0,t1,t2,t3);}

C_noret_decl(trf_11445)
static void C_fcall trf_11445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11445(t0,t1);}

C_noret_decl(trf_11257)
static void C_fcall trf_11257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11257(t0,t1,t2);}

C_noret_decl(trf_10952)
static void C_fcall trf_10952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10952(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10952(t0,t1,t2,t3);}

C_noret_decl(trf_10736)
static void C_fcall trf_10736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10736(t0,t1,t2);}

C_noret_decl(trf_10492)
static void C_fcall trf_10492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10492(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10492(t0,t1,t2);}

C_noret_decl(trf_10498)
static void C_fcall trf_10498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10498(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10498(t0,t1,t2,t3);}

C_noret_decl(trf_10517)
static void C_fcall trf_10517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10517(t0,t1);}

C_noret_decl(trf_10528)
static void C_fcall trf_10528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10528(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10528(t0,t1,t2,t3);}

C_noret_decl(trf_10233)
static void C_fcall trf_10233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10233(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10233(t0,t1,t2);}

C_noret_decl(trf_10239)
static void C_fcall trf_10239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10239(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10239(t0,t1,t2,t3);}

C_noret_decl(trf_10258)
static void C_fcall trf_10258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10258(t0,t1);}

C_noret_decl(trf_10317)
static void C_fcall trf_10317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10317(t0,t1);}

C_noret_decl(trf_10269)
static void C_fcall trf_10269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10269(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10269(t0,t1,t2,t3);}

C_noret_decl(trf_10134)
static void C_fcall trf_10134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10134(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10134(t0,t1,t2,t3);}

C_noret_decl(trf_10189)
static void C_fcall trf_10189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10189(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10189(t0,t1,t2,t3);}

C_noret_decl(trf_9912)
static void C_fcall trf_9912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9912(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9912(t0,t1,t2);}

C_noret_decl(trf_9915)
static void C_fcall trf_9915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9915(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9915(t0,t1,t2,t3);}

C_noret_decl(trf_9983)
static void C_fcall trf_9983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9983(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9983(t0,t1,t2,t3);}

C_noret_decl(trf_9940)
static void C_fcall trf_9940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9940(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9940(t0,t1);}

C_noret_decl(trf_9943)
static void C_fcall trf_9943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9943(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9943(t0,t1);}

C_noret_decl(trf_9806)
static void C_fcall trf_9806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9806(t0,t1);}

C_noret_decl(trf_9843)
static void C_fcall trf_9843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9843(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9843(t0,t1);}

C_noret_decl(trf_8541)
static void C_fcall trf_8541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8541(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8541(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8718)
static void C_fcall trf_8718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8718(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8718(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8721)
static void C_fcall trf_8721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8721(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8721(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8997)
static void C_fcall trf_8997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8997(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8997(t0,t1);}

C_noret_decl(trf_8969)
static void C_fcall trf_8969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8969(t0,t1);}

C_noret_decl(trf_8922)
static void C_fcall trf_8922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8922(t0,t1);}

C_noret_decl(trf_8881)
static void C_fcall trf_8881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8881(t0,t1);}

C_noret_decl(trf_9172)
static void C_fcall trf_9172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9172(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_9172(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_9192)
static void C_fcall trf_9192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9192(t0,t1);}

C_noret_decl(trf_8455)
static void C_fcall trf_8455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8455(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8455(t0,t1,t2,t3);}

C_noret_decl(trf_6217)
static void C_fcall trf_6217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6217(t0,t1);}

C_noret_decl(trf_7771)
static void C_fcall trf_7771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7771(t0,t1);}

C_noret_decl(trf_7691)
static void C_fcall trf_7691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7691(t0,t1);}

C_noret_decl(trf_7392)
static void C_fcall trf_7392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7392(t0,t1);}

C_noret_decl(trf_7226)
static void C_fcall trf_7226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7226(t0,t1);}

C_noret_decl(trf_6969)
static void C_fcall trf_6969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6969(t0,t1);}

C_noret_decl(trf_6972)
static void C_fcall trf_6972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6972(t0,t1);}

C_noret_decl(trf_6434)
static void C_fcall trf_6434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6434(t0,t1);}

C_noret_decl(trf_5905)
static void C_fcall trf_5905(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5905(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5905(t0,t1);}

C_noret_decl(trf_5818)
static void C_fcall trf_5818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5818(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5818(t0,t1,t2,t3);}

C_noret_decl(trf_5824)
static void C_fcall trf_5824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5824(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5824(t0,t1,t2,t3);}

C_noret_decl(trf_5556)
static void C_fcall trf_5556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5556(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5556(t0,t1);}

C_noret_decl(trf_5571)
static void C_fcall trf_5571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5571(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5571(t0,t1);}

C_noret_decl(trf_5583)
static void C_fcall trf_5583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5583(t0,t1);}

C_noret_decl(trf_5592)
static void C_fcall trf_5592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5592(t0,t1);}

C_noret_decl(trf_5289)
static void C_fcall trf_5289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5289(t0,t1);}

C_noret_decl(trf_5301)
static void C_fcall trf_5301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5301(t0,t1);}

C_noret_decl(trf_5316)
static void C_fcall trf_5316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5316(t0,t1);}

C_noret_decl(trf_5231)
static void C_fcall trf_5231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5231(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5231(t0,t1,t2,t3);}

C_noret_decl(trf_5104)
static void C_fcall trf_5104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5104(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5104(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3911)
static void C_fcall trf_3911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3911(t0,t1,t2);}

C_noret_decl(trf_5049)
static void C_fcall trf_5049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5049(t0,t1);}

C_noret_decl(trf_5009)
static void C_fcall trf_5009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5009(t0,t1);}

C_noret_decl(trf_4489)
static void C_fcall trf_4489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4489(t0,t1);}

C_noret_decl(trf_4510)
static void C_fcall trf_4510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4510(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4510(t0,t1);}

C_noret_decl(trf_4745)
static void C_fcall trf_4745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4745(t0,t1);}

C_noret_decl(trf_4587)
static void C_fcall trf_4587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4587(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4587(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4373)
static void C_fcall trf_4373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4373(t0,t1);}

C_noret_decl(trf_4020)
static void C_fcall trf_4020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4020(t0,t1);}

C_noret_decl(trf_3936)
static void C_fcall trf_3936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3936(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3936(t0,t1,t2);}

C_noret_decl(trf_3981)
static void C_fcall trf_3981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3981(t0,t1);}

C_noret_decl(trf_3775)
static void C_fcall trf_3775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3775(t0,t1);}

C_noret_decl(trf_3567)
static void C_fcall trf_3567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3567(t0,t1,t2);}

C_noret_decl(trf_3610)
static void C_fcall trf_3610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3610(t0,t1);}

C_noret_decl(trf_3548)
static void C_fcall trf_3548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3548(t0,t1);}

C_noret_decl(trf_3527)
static void C_fcall trf_3527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3527(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3527(t0,t1,t2,t3);}

C_noret_decl(trf_3351)
static void C_fcall trf_3351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3351(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3351(t0,t1,t2,t3);}

C_noret_decl(trf_3403)
static void C_fcall trf_3403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3403(t0,t1);}

C_noret_decl(trf_3376)
static void C_fcall trf_3376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3376(t0,t1);}

C_noret_decl(trf_3339)
static void C_fcall trf_3339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3339(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3339(t0,t1,t2,t3);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1954)){
C_save(t1);
C_rereclaim2(1954*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,265);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],8,"\003sysput!");
lf[2]=C_h_intern(&lf[2],9,"\003syserror");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],21,"\010compileralways-bound");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],18,"\010compilerdebugging");
lf[7]=C_h_intern(&lf[7],1,"o");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[9]=C_h_intern(&lf[9],13,"\004corevariable");
lf[10]=C_h_intern(&lf[10],2,"if");
lf[11]=C_h_intern(&lf[11],3,"let");
lf[12]=C_h_intern(&lf[12],6,"append");
lf[13]=C_h_intern(&lf[13],6,"lambda");
lf[14]=C_h_intern(&lf[14],13,"\004corecallunit");
lf[15]=C_h_intern(&lf[15],9,"\004corecall");
lf[16]=C_h_intern(&lf[16],4,"set!");
lf[17]=C_h_intern(&lf[17],9,"\004corecond");
lf[18]=C_h_intern(&lf[18],11,"\004coreswitch");
lf[19]=C_h_intern(&lf[19],30,"call-with-current-continuation");
lf[20]=C_h_intern(&lf[20],1,"p");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[22]=C_h_intern(&lf[22],24,"\010compilersimplifications");
lf[23]=C_h_intern(&lf[23],23,"\010compilersimplified-ops");
lf[24]=C_h_intern(&lf[24],41,"\010compilerperform-high-level-optimizations");
lf[25]=C_h_intern(&lf[25],12,"\010compilerget");
lf[26]=C_h_intern(&lf[26],5,"quote");
lf[27]=C_h_intern(&lf[27],10,"alist-cons");
lf[28]=C_h_intern(&lf[28],4,"caar");
lf[29]=C_h_intern(&lf[29],7,"\003sysmap");
lf[30]=C_h_intern(&lf[30],19,"\010compilermatch-node");
lf[31]=C_h_intern(&lf[31],3,"any");
lf[32]=C_h_intern(&lf[32],18,"\003syshash-table-ref");
lf[33]=C_h_intern(&lf[33],30,"\010compilerbroken-constant-nodes");
lf[34]=C_h_intern(&lf[34],11,"lset-adjoin");
lf[35]=C_h_intern(&lf[35],3,"eq\077");
lf[36]=C_h_intern(&lf[36],4,"node");
lf[37]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[38]=C_h_intern(&lf[38],14,"\010compilerqnode");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[40]=C_h_intern(&lf[40],4,"eval");
lf[41]=C_h_intern(&lf[41],22,"with-exception-handler");
lf[42]=C_h_intern(&lf[42],5,"every");
lf[43]=C_h_intern(&lf[43],8,"foldable");
lf[44]=C_h_intern(&lf[44],7,"\003sysget");
lf[45]=C_h_intern(&lf[45],18,"\010compilerintrinsic");
lf[46]=C_h_intern(&lf[46],5,"value");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[48]=C_h_intern(&lf[48],16,"\010compilervarnode");
lf[49]=C_h_intern(&lf[49],11,"collapsable");
lf[50]=C_h_intern(&lf[50],10,"replacable");
lf[51]=C_h_intern(&lf[51],9,"replacing");
lf[52]=C_h_intern(&lf[52],12,"contractable");
lf[53]=C_h_intern(&lf[53],9,"removable");
lf[54]=C_h_intern(&lf[54],11,"\004corelambda");
lf[55]=C_h_intern(&lf[55],6,"unused");
lf[56]=C_h_intern(&lf[56],9,"partition");
lf[57]=C_h_intern(&lf[57],26,"\010compilerbuild-lambda-list");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[59]=C_h_intern(&lf[59],13,"explicit-rest");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[61]=C_h_intern(&lf[61],30,"\010compilerdecompose-lambda-list");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[63]=C_h_intern(&lf[63],21,"has-unused-parameters");
lf[64]=C_h_intern(&lf[64],31,"\010compilerinline-lambda-bindings");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[66]=C_h_intern(&lf[66],24,"\010compilercheck-signature");
lf[67]=C_h_intern(&lf[67],30,"\010compilerconstant-declarations");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[69]=C_h_intern(&lf[69],14,"\004coreundefined");
lf[70]=C_h_intern(&lf[70],1,"x");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[72]=C_h_intern(&lf[72],37,"\010compilerexpression-has-side-effects\077");
lf[73]=C_h_intern(&lf[73],8,"assigned");
lf[74]=C_h_intern(&lf[74],10,"references");
lf[75]=C_h_intern(&lf[75],7,"unknown");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000#procedure can be inlined (globally)");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure can be inlined");
lf[79]=C_h_intern(&lf[79],1,"i");
lf[80]=C_h_intern(&lf[80],22,"\010compilerinline-global");
lf[81]=C_h_intern(&lf[81],14,"append-reverse");
lf[82]=C_h_intern(&lf[82],6,"gensym");
lf[83]=C_h_intern(&lf[83],1,"t");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[85]=C_h_intern(&lf[85],8,"split-at");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[87]=C_h_intern(&lf[87],20,"\004coreinline_allocate");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[89]=C_h_intern(&lf[89],23,"\010compilerinline-locally");
lf[90]=C_h_intern(&lf[90],3,"yes");
lf[91]=C_h_intern(&lf[91],2,"no");
lf[92]=C_h_intern(&lf[92],24,"\010compilerinline-max-size");
lf[93]=C_h_intern(&lf[93],15,"\010compilerinline");
lf[94]=C_h_intern(&lf[94],9,"inlinable");
lf[95]=C_h_intern(&lf[95],6,"simple");
lf[96]=C_h_intern(&lf[96],11,"local-value");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[98]=C_h_intern(&lf[98],26,"\010compilervariable-visible\077");
lf[99]=C_h_intern(&lf[99],6,"global");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[103]=C_h_intern(&lf[103],5,"print");
lf[104]=C_h_intern(&lf[104],7,"newline");
lf[105]=C_h_intern(&lf[105],6,"print*");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[109]=C_h_intern(&lf[109],34,"\010compilerperform-pre-optimization!");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[111]=C_h_intern(&lf[111],24,"node-subexpressions-set!");
lf[112]=C_h_intern(&lf[112],20,"node-parameters-set!");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\034removed call in test-context");
lf[115]=C_h_intern(&lf[115],10,"call-sites");
lf[116]=C_h_intern(&lf[116],67,"\010compilerside-effect-free-standard-bindings-that-never-return-false");
lf[117]=C_h_intern(&lf[117],7,"reverse");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[119]=C_h_intern(&lf[119],3,"not");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[121]=C_h_intern(&lf[121],24,"register-simplifications");
lf[122]=C_h_intern(&lf[122],19,"\003syshash-table-set!");
lf[123]=C_h_intern(&lf[123],38,"\010compilerreorganize-recursive-bindings");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[125]=C_h_intern(&lf[125],10,"fold-right");
lf[126]=C_h_intern(&lf[126],4,"fold");
lf[127]=C_h_intern(&lf[127],25,"\010compilertopological-sort");
lf[128]=C_h_intern(&lf[128],6,"lset<=");
lf[129]=C_h_intern(&lf[129],10,"filter-map");
lf[130]=C_h_intern(&lf[130],6,"filter");
lf[131]=C_h_intern(&lf[131],10,"append-map");
lf[132]=C_h_intern(&lf[132],28,"\010compilerscan-used-variables");
lf[133]=C_h_intern(&lf[133],8,"for-each");
lf[134]=C_h_intern(&lf[134],3,"map");
lf[135]=C_h_intern(&lf[135],4,"cons");
lf[136]=C_h_intern(&lf[136],27,"\010compilersubstitution-table");
lf[137]=C_h_intern(&lf[137],16,"\010compilerrewrite");
lf[138]=C_h_intern(&lf[138],28,"\010compilersimplify-named-call");
lf[139]=C_h_intern(&lf[139],37,"\010compilerinline-substitutions-enabled");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[141]=C_h_intern(&lf[141],11,"\004coreinline");
lf[142]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[143]=C_h_intern(&lf[143],6,"unsafe");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[145]=C_h_intern(&lf[145],6,"vector");
lf[146]=C_h_intern(&lf[146],14,"rest-parameter");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[148]=C_h_intern(&lf[148],11,"number-type");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[153]=C_h_intern(&lf[153],6,"fixnum");
lf[154]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[155]=C_h_intern(&lf[155],21,"\010compilerfold-boolean");
lf[156]=C_h_intern(&lf[156],6,"flonum");
lf[157]=C_h_intern(&lf[157],7,"generic");
lf[158]=C_h_intern(&lf[158],5,"cons*");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_h_intern(&lf[160],9,"\004coreproc");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[169]=C_h_intern(&lf[169],19,"\010compilerfold-inner");
lf[170]=C_h_intern(&lf[170],6,"remove");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[175]=C_h_intern(&lf[175],5,"fifth");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[177]=C_h_intern(&lf[177],13,"\010compilerbomb");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[179]=C_h_intern(&lf[179],34,"\010compilertransform-direct-lambdas!");
lf[180]=C_h_intern(&lf[180],19,"\010compilercopy-node!");
lf[181]=C_h_intern(&lf[181],16,"\004coredirect_call");
lf[182]=C_h_intern(&lf[182],4,"quit");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[184]=C_h_intern(&lf[184],15,"lset-difference");
lf[185]=C_h_intern(&lf[185],15,"node-class-set!");
lf[186]=C_h_intern(&lf[186],12,"\004corerecurse");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[188]=C_h_intern(&lf[188],4,"take");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[191]=C_h_intern(&lf[191],11,"\004corereturn");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[193]=C_h_intern(&lf[193],18,"\004coredirect_lambda");
lf[194]=C_h_intern(&lf[194],6,"cdaddr");
lf[195]=C_h_intern(&lf[195],6,"caaddr");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[198]=C_h_intern(&lf[198],6,"unzip1");
lf[199]=C_h_intern(&lf[199],16,"\003sysmake-promise");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[201]=C_h_intern(&lf[201],5,"boxed");
lf[202]=C_h_intern(&lf[202],15,"\004coreinline_ref");
lf[203]=C_h_intern(&lf[203],37,"\010compilerestimate-foreign-result-size");
lf[204]=C_h_intern(&lf[204],19,"\004coreinline_loc_ref");
lf[205]=C_h_intern(&lf[205],5,"lset=");
lf[206]=C_h_intern(&lf[206],6,"delete");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[208]=C_h_intern(&lf[208],32,"\010compilerperform-lambda-lifting!");
lf[209]=C_h_intern(&lf[209],23,"\003syshash-table-for-each");
lf[210]=C_h_intern(&lf[210],1,"+");
lf[211]=C_h_intern(&lf[211],17,"delete-duplicates");
lf[212]=C_h_intern(&lf[212],14,"\004coreprimitive");
lf[213]=C_h_intern(&lf[213],7,"delete!");
lf[214]=C_h_intern(&lf[214],11,"concatenate");
lf[215]=C_h_intern(&lf[215],5,"count");
lf[216]=C_h_intern(&lf[216],22,"\010compilerhide-variable");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[220]=C_h_intern(&lf[220],12,"pretty-print");
lf[221]=C_h_intern(&lf[221],1,"l");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[232]=C_h_intern(&lf[232],11,"make-vector");
lf[233]=C_h_intern(&lf[233],3,"var");
lf[234]=C_h_intern(&lf[234],1,"y");
lf[235]=C_h_intern(&lf[235],2,"d2");
lf[236]=C_h_intern(&lf[236],1,"z");
lf[237]=C_h_intern(&lf[237],2,"d3");
lf[238]=C_h_intern(&lf[238],2,"d1");
lf[239]=C_h_intern(&lf[239],2,"op");
lf[240]=C_h_intern(&lf[240],5,"clist");
lf[241]=C_h_intern(&lf[241],34,"\010compilermembership-test-operators");
lf[242]=C_h_intern(&lf[242],32,"\010compilermembership-unfold-limit");
lf[243]=C_h_intern(&lf[243],4,"var1");
lf[244]=C_h_intern(&lf[244],4,"var0");
lf[245]=C_h_intern(&lf[245],6,"const1");
lf[246]=C_h_intern(&lf[246],4,"var2");
lf[247]=C_h_intern(&lf[247],6,"const2");
lf[248]=C_h_intern(&lf[248],4,"rest");
lf[249]=C_h_intern(&lf[249],5,"body2");
lf[250]=C_h_intern(&lf[250],5,"body1");
lf[251]=C_h_intern(&lf[251],27,"\010compilereq-inline-operator");
lf[252]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[253]=C_h_intern(&lf[253],19,"\010compilerimmediate\077");
lf[254]=C_h_intern(&lf[254],5,"const");
lf[255]=C_h_intern(&lf[255],1,"n");
lf[256]=C_h_intern(&lf[256],7,"clauses");
lf[257]=C_h_intern(&lf[257],4,"body");
lf[258]=C_h_intern(&lf[258],1,"d");
lf[259]=C_h_intern(&lf[259],4,"more");
lf[260]=C_h_intern(&lf[260],4,"args");
lf[261]=C_h_intern(&lf[261],1,"a");
lf[262]=C_h_intern(&lf[262],1,"b");
lf[263]=C_h_intern(&lf[263],1,"c");
lf[264]=C_h_intern(&lf[264],4,"cdar");
C_register_lf2(lf,265,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3254,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3252 */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3257,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3255 in k3252 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3258 in k3255 in k3252 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3266,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3271,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3521,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 141  make-vector */
t4=*((C_word*)lf[232]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3521,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! simplifications ...) */,t1);
t3=C_set_block_item(lf[23] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[24]+1 /* (set! perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3524,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[109]+1 /* (set! perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5224,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[121]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5797,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[261],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[9],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[262],lf[263]);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[258],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[15],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[258],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[263],t15);
t17=(C_word)C_a_i_cons(&a,2,lf[262],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[261],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13075,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t18,t20);
t22=(C_word)C_a_i_cons(&a,2,t14,t21);
/* optimizer.scm: 542  register-simplifications */
t23=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t23))(4,t23,t7,lf[15],t22);}

/* a13074 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_13075(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_13075,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13083,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 548  ##sys#hash-table-ref */
t8=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,C_retrieve(lf[136]),t3);}

/* k13081 in a13074 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_13083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13083,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_13088(t6,((C_word*)t0)[2],t2);}

/* loop in k13081 in a13074 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_13088(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13088,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13098,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13133,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 550  caar */
t5=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k13131 in loop in k13081 in a13074 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_13133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13137,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 550  cdar */
t3=*((C_word*)lf[264]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k13135 in k13131 in loop in k13081 in a13074 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_13137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 550  simplify-named-call */
t2=C_retrieve(lf[138]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k13096 in loop in k13081 in a13074 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_13098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13098,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[23]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13107,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_13107(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13122,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 555  alist-cons */
t5=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[23]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 557  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_13088(t3,((C_word*)t0)[4],t2);}}

/* k13120 in k13096 in loop in k13081 in a13074 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_13122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[23]+1 /* (set! simplified-ops ...) */,t1);
t3=((C_word*)t0)[2];
f_13107(t3,t2);}

/* k13105 in k13096 in loop in k13081 in a13074 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_13107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[9],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[245],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[26],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,t4,t12);
t14=(C_word)C_a_i_cons(&a,2,lf[141],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[9],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[9],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[26],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t22,t26);
t28=(C_word)C_a_i_cons(&a,2,t19,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[141],t28);
t30=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[9],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[248],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[249],t33);
t35=(C_word)C_a_i_cons(&a,2,t32,t34);
t36=(C_word)C_a_i_cons(&a,2,lf[235],t35);
t37=(C_word)C_a_i_cons(&a,2,lf[10],t36);
t38=(C_word)C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t29,t38);
t40=(C_word)C_a_i_cons(&a,2,t18,t39);
t41=(C_word)C_a_i_cons(&a,2,lf[11],t40);
t42=(C_word)C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=(C_word)C_a_i_cons(&a,2,lf[250],t42);
t44=(C_word)C_a_i_cons(&a,2,t17,t43);
t45=(C_word)C_a_i_cons(&a,2,lf[238],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[10],t45);
t47=(C_word)C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=(C_word)C_a_i_cons(&a,2,t14,t47);
t49=(C_word)C_a_i_cons(&a,2,t3,t48);
t50=(C_word)C_a_i_cons(&a,2,lf[11],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[248],C_SCHEME_END_OF_LIST);
t52=(C_word)C_a_i_cons(&a,2,lf[235],t51);
t53=(C_word)C_a_i_cons(&a,2,lf[238],t52);
t54=(C_word)C_a_i_cons(&a,2,lf[249],t53);
t55=(C_word)C_a_i_cons(&a,2,lf[250],t54);
t56=(C_word)C_a_i_cons(&a,2,lf[247],t55);
t57=(C_word)C_a_i_cons(&a,2,lf[245],t56);
t58=(C_word)C_a_i_cons(&a,2,lf[239],t57);
t59=(C_word)C_a_i_cons(&a,2,lf[246],t58);
t60=(C_word)C_a_i_cons(&a,2,lf[243],t59);
t61=(C_word)C_a_i_cons(&a,2,lf[244],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12754,tmp=(C_word)a,a+=2,tmp);
t63=(C_word)C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=(C_word)C_a_i_cons(&a,2,t61,t63);
t65=(C_word)C_a_i_cons(&a,2,t50,t64);
t66=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t67=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t68=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t69=(C_word)C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=(C_word)C_a_i_cons(&a,2,lf[9],t69);
t71=(C_word)C_a_i_cons(&a,2,lf[254],C_SCHEME_END_OF_LIST);
t72=(C_word)C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=(C_word)C_a_i_cons(&a,2,lf[26],t72);
t74=(C_word)C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=(C_word)C_a_i_cons(&a,2,t70,t74);
t76=(C_word)C_a_i_cons(&a,2,t67,t75);
t77=(C_word)C_a_i_cons(&a,2,lf[141],t76);
t78=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t79=(C_word)C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=(C_word)C_a_i_cons(&a,2,lf[9],t79);
t81=(C_word)C_a_i_cons(&a,2,lf[255],C_SCHEME_END_OF_LIST);
t82=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t83=(C_word)C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=(C_word)C_a_i_cons(&a,2,lf[9],t83);
t85=(C_word)C_a_i_cons(&a,2,t84,lf[256]);
t86=(C_word)C_a_i_cons(&a,2,t81,t85);
t87=(C_word)C_a_i_cons(&a,2,lf[18],t86);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[257],t88);
t90=(C_word)C_a_i_cons(&a,2,t80,t89);
t91=(C_word)C_a_i_cons(&a,2,lf[258],t90);
t92=(C_word)C_a_i_cons(&a,2,lf[10],t91);
t93=(C_word)C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=(C_word)C_a_i_cons(&a,2,t77,t93);
t95=(C_word)C_a_i_cons(&a,2,t66,t94);
t96=(C_word)C_a_i_cons(&a,2,lf[11],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[256],C_SCHEME_END_OF_LIST);
t98=(C_word)C_a_i_cons(&a,2,lf[255],t97);
t99=(C_word)C_a_i_cons(&a,2,lf[257],t98);
t100=(C_word)C_a_i_cons(&a,2,lf[258],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[254],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[244],t101);
t103=(C_word)C_a_i_cons(&a,2,lf[239],t102);
t104=(C_word)C_a_i_cons(&a,2,lf[233],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12533,tmp=(C_word)a,a+=2,tmp);
t106=(C_word)C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=(C_word)C_a_i_cons(&a,2,t104,t106);
t108=(C_word)C_a_i_cons(&a,2,t96,t107);
t109=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=(C_word)C_a_i_cons(&a,2,lf[69],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t113=(C_word)C_a_i_cons(&a,2,t111,t112);
t114=(C_word)C_a_i_cons(&a,2,t109,t113);
t115=(C_word)C_a_i_cons(&a,2,lf[11],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t117=(C_word)C_a_i_cons(&a,2,lf[243],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12174,tmp=(C_word)a,a+=2,tmp);
t119=(C_word)C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,t117,t119);
t121=(C_word)C_a_i_cons(&a,2,t115,t120);
t122=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t123=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,t123,lf[260]);
t125=(C_word)C_a_i_cons(&a,2,lf[141],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t127=(C_word)C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=(C_word)C_a_i_cons(&a,2,lf[9],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,lf[70],t129);
t131=(C_word)C_a_i_cons(&a,2,t128,t130);
t132=(C_word)C_a_i_cons(&a,2,lf[258],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[10],t132);
t134=(C_word)C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=(C_word)C_a_i_cons(&a,2,t125,t134);
t136=(C_word)C_a_i_cons(&a,2,t122,t135);
t137=(C_word)C_a_i_cons(&a,2,lf[11],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t139=(C_word)C_a_i_cons(&a,2,lf[70],t138);
t140=(C_word)C_a_i_cons(&a,2,lf[258],t139);
t141=(C_word)C_a_i_cons(&a,2,lf[260],t140);
t142=(C_word)C_a_i_cons(&a,2,lf[239],t141);
t143=(C_word)C_a_i_cons(&a,2,lf[233],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12026,tmp=(C_word)a,a+=2,tmp);
t145=(C_word)C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=(C_word)C_a_i_cons(&a,2,t143,t145);
t147=(C_word)C_a_i_cons(&a,2,t137,t146);
/* optimizer.scm: 560  register-simplifications */
t148=C_retrieve(lf[121]);
((C_proc7)C_retrieve_proc(t148))(7,t148,t2,lf[11],t65,t108,t121,t147);}

/* a12025 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12026(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_12026,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[251])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12072,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t1,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 695  get */
t10=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,t2,t3,lf[74]);}}

/* k12070 in a12025 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12072,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12055,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12060,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[141],t5,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_12060 in k12070 in a12025 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12060,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k12053 in k12070 in a12025 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12055,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12047,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[10],((C_word*)t0)[2],t2);}

/* f_12047 in k12053 in k12070 in a12025 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12047(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12047,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12174,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12184,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_12184(t9,t1,t5,t4);}

/* loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_12184(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12184,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12188,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12483,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_12483 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12483,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12478,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12478 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12478,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12473,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12473 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12473,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12194,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t1);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12212,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12464,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_12464 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12464,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12459,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12459 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12459,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12218,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12454,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_12454 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12454,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12218,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[69]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_cadr(((C_word*)t0)[7]);
/* optimizer.scm: 641  loop1 */
t6=((C_word*)((C_word*)t0)[6])[1];
f_12184(t6,((C_word*)t0)[5],t4,t5);}
else{
t3=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12248,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 643  reverse */
t5=*((C_word*)lf[117]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12248,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12277,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_12277(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_12277(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12277,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12281,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12437,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* f_12437 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12284,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12432,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_12432 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12432,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12287,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12427,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_12427 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12427(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12427,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12293,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12418,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 654  get */
t7=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,((C_word*)t0)[2],t6,lf[74]);}
else{
t5=t2;
f_12293(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_12293(t4,C_SCHEME_FALSE);}}

/* k12416 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12418,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_12293(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12410,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
f_12293(t2,C_SCHEME_FALSE);}}}

/* f_12410 in k12416 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12410(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12410,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k12403 in k12416 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12405,2,t0,t1);}
t2=(C_word)C_eqp(lf[16],t1);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12392,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12397,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)t0)[3];
f_12293(t3,C_SCHEME_FALSE);}}

/* f_12397 in k12403 in k12416 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12397,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k12390 in k12403 in k12416 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
f_12293(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k12291 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_12293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12293,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12316,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12321,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12336,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12346,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a12345 in k12291 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12346,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a12335 in k12291 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12344,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 663  reverse */
t3=*((C_word*)lf[117]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k12342 in a12335 in k12291 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 663  reorganize-recursive-bindings */
t2=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f_12321 in k12291 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12321,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k12314 in k12291 in k12285 in k12282 in k12279 in loop2 in k12246 in k12216 in k12213 in k12210 in k12192 in k12189 in k12186 in loop1 in a12173 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12316,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 658  loop2 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_12277(t6,((C_word*)t0)[2],t3,t4,t5);}

/* a12532 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_12533,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[251])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12546,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 607  immediate? */
t12=C_retrieve(lf[253]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k12544 in a12532 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12546,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 608  get */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12586 in k12544 in a12532 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12588,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12563,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 612  varnode */
t8=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12570 in k12586 in k12544 in a12532 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 613  qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k12574 in k12570 in k12586 in k12544 in a12532 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 612  cons* */
t2=C_retrieve(lf[158]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12561 in k12586 in k12544 in a12532 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12564,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[18],((C_word*)t0)[2],t1);}

/* f_12564 in k12561 in k12586 in k12544 in a12532 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12564(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12564,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12754(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_12754,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[251])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12767,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 580  immediate? */
t15=C_retrieve(lf[253]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k12765 in a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12767,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 581  immediate? */
t3=C_retrieve(lf[253]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12771 in k12765 in a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12773,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 582  get */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12823 in k12771 in k12765 in a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12825,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12817,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 583  get */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[74]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12815 in k12823 in k12771 in k12765 in a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12817,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 587  varnode */
t5=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12799 in k12815 in k12823 in k12771 in k12765 in a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 588  qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k12803 in k12799 in k12815 in k12823 in k12771 in k12765 in a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 590  qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k12807 in k12803 in k12799 in k12815 in k12823 in k12771 in k12765 in a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12809,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12793,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[18],lf[252],t2);}

/* f_12793 in k12807 in k12803 in k12799 in k12815 in k12823 in k12771 in k12765 in a12753 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_12793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12793,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5810,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[9],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[235],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[15],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[9],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t12,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[237],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[15],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t9,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[70],t18);
t20=(C_word)C_a_i_cons(&a,2,lf[238],t19);
t21=(C_word)C_a_i_cons(&a,2,lf[10],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[233],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[236],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[234],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[70],t24);
t26=(C_word)C_a_i_cons(&a,2,lf[237],t25);
t27=(C_word)C_a_i_cons(&a,2,lf[235],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[238],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11863,tmp=(C_word)a,a+=2,tmp);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t28,t30);
t32=(C_word)C_a_i_cons(&a,2,t21,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[239],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,lf[26],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[70],t37);
t39=(C_word)C_a_i_cons(&a,2,t33,t38);
t40=(C_word)C_a_i_cons(&a,2,lf[141],t39);
t41=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t42=(C_word)C_a_i_cons(&a,2,lf[234],t41);
t43=(C_word)C_a_i_cons(&a,2,t40,t42);
t44=(C_word)C_a_i_cons(&a,2,lf[238],t43);
t45=(C_word)C_a_i_cons(&a,2,lf[10],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t47=(C_word)C_a_i_cons(&a,2,lf[234],t46);
t48=(C_word)C_a_i_cons(&a,2,lf[240],t47);
t49=(C_word)C_a_i_cons(&a,2,lf[70],t48);
t50=(C_word)C_a_i_cons(&a,2,lf[239],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[238],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11667,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t45,t54);
/* optimizer.scm: 702  register-simplifications */
t56=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t56))(5,t56,t2,lf[10],t32,t55);}

/* a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_11667,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[241]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[242]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11689,a[2]=t6,a[3]=t3,a[4]=t8,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 733  gensym */
t13=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11689,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11712,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11725,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11727,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11769,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 750  qnode */
t9=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_FALSE);}

/* k11767 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 742  fold-right */
t2=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a11726 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11727,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11744,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11761,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 747  varnode */
t6=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k11759 in a11726 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 747  qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k11763 in k11759 in a11726 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11765,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11753,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[141],((C_word*)t0)[2],t2);}

/* f_11753 in k11763 in k11759 in a11726 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11753(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11753,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11742 in a11726 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 748  qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k11746 in k11742 in a11726 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11748,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11736,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[17],C_SCHEME_END_OF_LIST,t2);}

/* f_11736 in k11746 in k11742 in a11726 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11736,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11723 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11725,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11717,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[10],((C_word*)t0)[2],t2);}

/* f_11717 in k11723 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11717(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11717,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11710 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11712,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11704,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_11704 in k11710 in k11687 in a11666 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11704,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a11862 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_11863,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[139]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11883,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 718  varnode */
t11=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11881 in a11862 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11887,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11892,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[17],C_SCHEME_END_OF_LIST,t3);}

/* f_11892 in k11881 in a11862 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11892,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11885 in k11881 in a11862 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11887,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11875,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t2);}

/* f_11875 in k11885 in k11881 in a11862 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11875,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5810,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1 /* (set! reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5812,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6170,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 845  make-vector */
t4=*((C_word*)lf[232]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6170,2,t0,t1);}
t2=C_mutate((C_word*)lf[136]+1 /* (set! substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[137]+1 /* (set! rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6172,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[138]+1 /* (set! simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6192,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[179]+1 /* (set! transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8538,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[208]+1 /* (set! perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9803,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9803,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9806,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9912,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10134,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10233,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10492,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10736,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10952,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11257,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11374,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11546,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1821 debugging */
t16=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[20],lf[231]);}

/* k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1822 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_9806(t3,t2);}

/* k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11552,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1823 debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[230]);}

/* k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1824 build-call-graph */
t3=((C_word*)t0)[2];
f_9912(t3,t2,((C_word*)t0)[3]);}

/* k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11558,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1825 debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[229]);}

/* k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11561,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1826 eliminate */
t3=((C_word*)t0)[4];
f_10134(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11564,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11638,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1827 debugging */
t4=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[221],lf[228]);}

/* k11636 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1827 pretty-print */
t2=C_retrieve(lf[220]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11564(2,t2,C_SCHEME_UNDEFINED);}}

/* k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1828 debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[227]);}

/* k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1829 collect-accessibles */
t3=((C_word*)t0)[2];
f_10233(t3,t2,((C_word*)t0)[3]);}

/* k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11632,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1830 debugging */
t4=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[221],lf[226]);}

/* k11630 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1830 pretty-print */
t2=C_retrieve(lf[220]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11573(2,t2,C_SCHEME_UNDEFINED);}}

/* k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1831 debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[225]);}

/* k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11579,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11629,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1832 eliminate4 */
t4=((C_word*)t0)[3];
f_10492(t4,t3,((C_word*)t0)[2]);}

/* k11627 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11629,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10458,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10458(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k11627 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10458(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10458,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10462,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1626 filter */
t6=C_retrieve(lf[130]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,t2);}

/* a10475 in loop in k11627 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10476,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10482,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1626 every */
t5=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a10481 in a10475 in loop in k11627 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10482,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k10460 in loop in k11627 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1630 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_10458(t5,((C_word*)t0)[3],t1,t2);}}

/* k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11619,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11621,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t5=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a11620 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11621,2,t0,t1);}
/* optimizer.scm: 1833 unzip1 */
t2=C_retrieve(lf[198]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k11617 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1833 debugging */
t2=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[7],lf[224],t1);}

/* k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1834 debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[223]);}

/* k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1835 compute-extra-variables */
t3=((C_word*)t0)[2];
f_10736(t3,t2,((C_word*)t0)[5]);}

/* k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11612,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1836 debugging */
t4=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[221],lf[222]);}

/* k11610 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1836 pretty-print */
t2=C_retrieve(lf[220]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_11591(2,t2,C_SCHEME_UNDEFINED);}}

/* k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1837 debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[219]);}

/* k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1838 extend-call-sites! */
t3=((C_word*)t0)[2];
f_11257(t3,t2,((C_word*)t0)[4]);}

/* k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1839 debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[218]);}

/* k11598 in k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1840 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_11374(t3,t2,((C_word*)t0)[4]);}

/* k11601 in k11598 in k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1841 debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[217]);}

/* k11604 in k11601 in k11598 in k11595 in k11592 in k11589 in k11586 in k11583 in k11580 in k11577 in k11574 in k11571 in k11568 in k11565 in k11562 in k11559 in k11556 in k11553 in k11550 in k11547 in k11544 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1842 reconstruct! */
t2=((C_word*)t0)[5];
f_10952(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_11374(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11374,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11380,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11380(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11380,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11384,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11539,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_11539 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11539,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11534,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11534 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11534,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11390,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11529,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_11529 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11529,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11390,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11399,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11483,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11484,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[16]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11497,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11520,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11521,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1],t1);}}}

/* f_11521 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11521,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11518 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k11495 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11497,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1816 node-class-set! */
t4=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[69]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k11504 in k11495 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1817 node-parameters-set! */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k11507 in k11504 in k11495 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1818 node-subexpressions-set! */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* f_11484 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11484,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11481 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k11397 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11399,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11404,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_11404(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop3144 in k11397 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_11404(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11404,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1806 copy-node! */
t5=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11427,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11442,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1808 reverse */
t6=*((C_word*)lf[117]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11445,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_11445(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_11445(t12,t11);}}}

/* k11443 in doloop3144 in k11397 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_11445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_11404(t4,((C_word*)t0)[2],t2,t3);}

/* k11440 in doloop3144 in k11397 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1808 node-parameters-set! */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11425 in doloop3144 in k11397 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11434,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11438,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1809 reverse */
t4=*((C_word*)lf[117]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k11436 in k11425 in doloop3144 in k11397 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1809 append */
t2=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11432 in k11425 in doloop3144 in k11397 in k11388 in k11385 in k11382 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1809 node-subexpressions-set! */
t2=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_11257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11257,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11263,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11263(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11263,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11267,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11368,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_11368 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11368(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11368,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11363,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11363 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11363,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11273,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11358,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11358 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11358,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11273,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[15]);
if(C_truep(t2)){
t3=(C_word)C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11349,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11350,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],t1);}}

/* f_11350 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11350,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11347 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11349,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11341,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[4];
f_11285(2,t3,C_SCHEME_UNDEFINED);}}

/* f_11341 in k11347 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11341,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11338 in k11347 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11340,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_assq(t2,((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(C_word)C_i_set_car(((C_word*)t0)[6],C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11324,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t3);
/* map */
t8=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,C_retrieve(lf[48]),t7);}
else{
t4=((C_word*)t0)[4];
f_11285(2,t4,C_SCHEME_UNDEFINED);}}

/* k11322 in k11338 in k11347 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1788 append */
t3=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k11318 in k11338 in k11347 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11320,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1786 node-subexpressions-set! */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11283 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11293,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_11293 in k11283 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11293,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11290 in k11283 in k11271 in k11268 in k11265 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10952(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10952,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10964,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10966,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11107,a[2]=t2,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11108,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[3]);}

/* f_11108 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11108,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11105 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 1722 fold-right */
t3=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10966,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10973,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1725 get */
t6=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t4,lf[46]);}

/* k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10976,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1726 hide-variable */
t3=C_retrieve(lf[216]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}

/* k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11095,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11095 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11095,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11094,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1727 decompose-lambda-list */
t4=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10985(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10985,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10992,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[82]),t6);}

/* k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10995,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1732 map */
t3=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[135]+1),((C_word*)t0)[5],t1);}

/* k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11081,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11082,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* f_11082 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11082,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11081,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11117,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11132,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11132(3,t8,((C_word*)t0)[2],t2);}

/* walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11132,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11136,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11251,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_11251 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11251,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11246,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11246 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11246,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11142,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11241,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_11241 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11241(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11241,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11142,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11151,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11158,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[9]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11175,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1761 rename */
t6=((C_word*)t0)[3];
f_11117(3,t6,t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[16]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11188,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11199,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1763 rename */
t8=((C_word*)t0)[3];
f_11117(3,t8,t6,t7);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1766 decompose-lambda-list */
t8=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],t6,t7);}
else{
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],t1);}}}}}

/* a11217 in k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11218,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11233,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11237,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k11235 in a11217 in k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1769 build-lambda-list */
t2=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11231 in a11217 in k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1770 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11132(3,t4,((C_word*)t0)[2],t3);}

/* k11197 in k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11199,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1763 node-parameters-set! */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11186 in k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k11173 in k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11175,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1761 node-parameters-set! */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k11156 in k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1758 node-parameters-set! */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11149 in k11140 in k11137 in k11134 in walk in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k11079 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11117,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1735 gensym */
t3=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[83]);}

/* k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11073,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11018,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11035,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11057,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11061,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1741 append */
t8=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11059 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1741 build-lambda-list */
t4=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k11055 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11057,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11043,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11049,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_11049 in k11055 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11049,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k11041 in k11055 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11044,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],((C_word*)t0)[2],t1);}

/* f_11044 in k11041 in k11055 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11044(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11044,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11033 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11035,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11027,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[16],((C_word*)t0)[2],t2);}

/* f_11027 in k11033 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11027,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k11016 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11018,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11010,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_11010 in k11016 in k11071 in k10996 in k10993 in k10990 in a10984 in k11092 in k10974 in k10971 in a10965 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_11010(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11010,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k10962 in reconstruct! in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10964,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1719 node-subexpressions-set! */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10736,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10816,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10938,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a10937 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10938,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10816,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10818,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10893,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10898,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10936,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1708 get */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,lf[46]);}

/* k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10936,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10745,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10745(3,t8,t4,t1);}

/* walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10745,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10749,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10809,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_10809 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10809,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10747 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10804,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10804 in k10747 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10804,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10750 in k10747 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10755,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10799,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10799 in k10750 in k10747 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10799,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10753 in k10750 in k10747 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10755,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10765,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1684 append */
t4=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10783,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1687 decompose-lambda-list */
t6=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[4],t4,t5);}
else{
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);}}}

/* a10782 in k10753 in k10750 in k10747 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10783,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10788,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1690 append */
t6=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k10786 in a10782 in k10753 in k10750 in k10747 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1691 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10745(3,t4,((C_word*)t0)[2],t3);}

/* k10763 in k10753 in k10750 in k10747 in walk in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10741 in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10743,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10912,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10914,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10928,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1714 delete-duplicates */
t7=C_retrieve(lf[211]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,*((C_word*)lf[35]+1));}

/* k10926 in k10741 in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1710 remove */
t2=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10913 in k10741 in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10914,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k10910 in k10741 in k10934 in a10897 in k10891 in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10912,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10818,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10886,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1699 count */
t6=C_retrieve(lf[215]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a10885 in walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10886,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k10882 in walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10884,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10838,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a10871 in k10882 in walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10872,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1702 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10818(3,t4,t1,t3);}

/* k10836 in k10882 in walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10838,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10848,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10856,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10860,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10862,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a10861 in k10836 in k10882 in walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10862,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k10858 in k10836 in k10882 in walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1704 concatenate */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10854 in k10836 in k10882 in walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1704 append */
t2=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10846 in k10836 in k10882 in walk in k10814 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10492(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10492,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10496,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10498,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10498(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10498(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10498,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10502,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10730,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10730 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10730,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10725,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10725 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10725,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10720,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10720 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10720(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10720,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10508,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10517,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_10517(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[26]);
if(C_truep(t4)){
t5=t3;
f_10517(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[7],lf[69]);
if(C_truep(t5)){
t6=t3;
f_10517(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[7],lf[212]);
t7=t3;
f_10517(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[7],lf[160])));}}}}

/* k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10517,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10528,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_10528(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10579,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1649 decompose-lambda-list */
t6=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[15]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10614,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1655 call-with-current-continuation */
t8=*((C_word*)lf[19]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10694,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a10693 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10694(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10694,3,t0,t1,t2);}
/* optimizer.scm: 1670 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10498(t3,t1,t2,((C_word*)t0)[2]);}

/* a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10614,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10684,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10685,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_10685 in a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10685,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10682 in a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10684,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10675,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10676,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* f_10676 in k10682 in a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10676,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10673 in k10682 in a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10675,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_10630(3,t6,((C_word*)t0)[2],t2);}

/* loop in k10673 in k10682 in a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10630,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10650,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10660,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1664 lset<= */
t9=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[35]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k10658 in loop in k10673 in k10682 in a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10660,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10650(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10664,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1666 delete! */
t3=C_retrieve(lf[213]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[35]+1));}}

/* k10662 in k10658 in loop in k10673 in k10682 in a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1667 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k10648 in loop in k10673 in k10682 in a10613 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k10601 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10608,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10607 in k10601 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10608,3,t0,t1,t2);}
/* optimizer.scm: 1669 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10498(t3,t1,t2,((C_word*)t0)[2]);}

/* a10578 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10579,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10591,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1652 append */
t7=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10589 in a10578 in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1652 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10498(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10528(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10528,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10546,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1644 append */
t6=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10549,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1646 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_10498(t6,t4,t5,((C_word*)t0)[3]);}}

/* k10547 in loop in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1647 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10528(t4,((C_word*)t0)[2],t2,t3);}

/* k10544 in loop in k10515 in k10506 in k10503 in k10500 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1644 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10498(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10494 in eliminate4 in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10233(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10233,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10237,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10239,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_10239(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10239(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10239,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10396,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10396 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10396,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10391,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_10391 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10391,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10386,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_10386 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10386(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10386,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10249,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
t4=t3;
f_10258(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[10],lf[26]);
if(C_truep(t4)){
t5=t3;
f_10258(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[69]);
if(C_truep(t5)){
t6=t3;
f_10258(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[10],lf[212]);
t7=t3;
f_10258(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[10],lf[160])));}}}}

/* k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10258,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[11]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10269,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_10269(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10317,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10351,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1601 alist-cons */
t9=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_10317(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_10317(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10360,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a10359 in k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10360,3,t0,t1,t2);}
/* optimizer.scm: 1607 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10239(t3,t1,t2,((C_word*)t0)[2]);}

/* k10349 in k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10317(t3,t2);}

/* k10315 in k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10317,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1602 decompose-lambda-list */
t4=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a10325 in k10315 in k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10326,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10338,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1605 append */
t7=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10336 in a10325 in k10315 in k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1605 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10239(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10269(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10269,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10287,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1592 append */
t6=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10290,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1594 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_10239(t6,t4,t5,((C_word*)t0)[3]);}}

/* k10288 in loop in k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1595 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10269(t4,((C_word*)t0)[2],t2,t3);}

/* k10285 in loop in k10256 in k10247 in k10244 in k10241 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1592 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10239(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10235 in collect-accessibles in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10134(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10134,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10140,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1562 remove */
t5=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10140,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10174,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10184,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1572 unzip1 */
t7=C_retrieve(lf[198]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k10182 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10184,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10189,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10189(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k10182 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_10189(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10189,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10196,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1575 lset-difference */
t7=C_retrieve(lf[184]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t5,*((C_word*)lf[35]+1),t6,t3,((C_word*)t0)[2]);}

/* k10194 in count in k10182 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10223,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1576 delete-duplicates */
t4=C_retrieve(lf[211]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,*((C_word*)lf[35]+1));}

/* k10221 in k10194 in count in k10182 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10223,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1577 append */
t4=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10217 in k10221 in k10194 in count in k10182 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10219,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10209,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10211,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a10210 in k10217 in k10221 in k10194 in count in k10182 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10211,3,t0,t1,t2);}
/* optimizer.scm: 1578 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10189(t3,t1,t2,((C_word*)t0)[2]);}

/* k10207 in k10217 in k10221 in k10194 in count in k10182 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1578 fold */
t2=C_retrieve(lf[126]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[210]+1),((C_word*)t0)[2],t1);}

/* k10172 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10174,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10152,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1565 any */
t5=C_retrieve(lf[31]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[5],t3,t4);}}

/* a10151 in k10172 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10152,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10159,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1566 get */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],t2,lf[73]);}

/* k10157 in a10151 in k10172 in a10139 in eliminate in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9912(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9912,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9915,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10079,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10081,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t14=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a10080 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10081,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10127,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10128,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* f_10128 in a10080 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10128,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k10125 in a10080 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10127,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_set_block_item(((C_word*)t0)[8],0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10096,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1551 decompose-lambda-list */
t7=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t2,t6);}

/* a10105 in k10125 in a10080 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10106(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10106,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10118,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10119,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* f_10119 in a10105 in k10125 in a10080 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10119,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k10116 in a10105 in k10125 in a10080 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 1554 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9915(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k10094 in k10125 in a10080 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10100,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1555 alist-cons */
t4=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k10098 in k10094 in k10125 in a10080 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10077 in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9915(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9915,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9919,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10072,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10072 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10072,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10067,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10067 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10067,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10062,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_10062 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10062,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9925,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[9]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[10],lf[16]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9940,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_i_memq(t4,((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9965,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_9965(2,t8,t6);}
else{
/* optimizer.scm: 1527 get */
t8=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[2],t4,lf[99]);}}
else{
t4=(C_word)C_eqp(((C_word*)t0)[10],lf[11]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9983,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_9983(t8,((C_word*)t0)[6],((C_word*)t0)[9],t1);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[10],lf[13]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10037,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1539 decompose-lambda-list */
t8=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10054,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],t6,t1);}}}}

/* a10053 in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10054,3,t0,t1,t2);}
/* optimizer.scm: 1542 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9915(t3,t1,t2,((C_word*)t0)[2]);}

/* a10036 in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10037,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10049,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1541 append */
t7=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10047 in a10036 in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1541 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9915(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9983(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9983,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10001,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1534 append */
t6=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10007,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1536 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_9915(t7,t5,t6,((C_word*)t0)[3]);}}

/* k10005 in loop in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1537 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9983(t4,((C_word*)t0)[2],t2,t3);}

/* k9999 in loop in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_10001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1534 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9915(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9963 in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9965,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9940(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_9940(t4,t3);}}

/* k9938 in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9940(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9940,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9943,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_9943(t5,t4);}
else{
t3=t2;
f_9943(t3,C_SCHEME_UNDEFINED);}}

/* k9941 in k9938 in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9943(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9943,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9948,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9947 in k9941 in k9938 in k9923 in k9920 in k9917 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9948,3,t0,t1,t2);}
/* optimizer.scm: 1530 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9915(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9806,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9810,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9812,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1498 ##sys#hash-table-for-each */
t6=C_retrieve(lf[209]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9811 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9812,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[46],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[74],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[115],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9843,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[75],t3))){
t10=t9;
f_9843(t10,C_SCHEME_FALSE);}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9893,a[2]=t8,a[3]=t6,a[4]=t9,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(t4);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9898,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* f_9898 in a9811 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9898,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9891 in a9811 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(lf[13],t1);
if(C_truep(t2)){
if(C_truep((C_word)C_i_assq(lf[99],((C_word*)t0)[5]))){
t3=((C_word*)t0)[4];
f_9843(t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_length(t3);
t5=((C_word*)t0)[4];
f_9843(t5,(C_word)C_eqp(((C_word*)t0)[2],t4));}}
else{
t3=((C_word*)t0)[4];
f_9843(t3,C_SCHEME_FALSE);}}

/* k9841 in a9811 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9843(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9843,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1509 alist-cons */
t4=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9845 in k9841 in a9811 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9847,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9851,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1510 alist-cons */
t5=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k9849 in k9845 in k9841 in a9811 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9808 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8538,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9172,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8718,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8541,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9798,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1477 debugging */
t18=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t17,lf[20],lf[207]);}

/* k9796 in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9801,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1478 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8541(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9799 in k9796 in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_8541(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8541,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=t3,a[11]=t1,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8712,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* f_8712 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8712,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8707,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_8707 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8707,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8702,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_8702 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8702,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8549 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8551,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t2)){
t3=(C_word)C_i_caddr(((C_word*)t0)[14]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8566,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[10])){
if(C_truep((C_word)C_i_cadr(((C_word*)t0)[14]))){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=t3,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1269 get */
t6=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[10],lf[75]);}
else{
t5=t4;
f_8566(2,t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8566(2,t5,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[14]);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 1279 walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8541(t6,((C_word*)t0)[12],t4,t5,C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8677,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[14]);
t7=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 1281 walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_8541(t8,t5,t6,t7,((C_word*)t0)[11]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8697,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[12],t5,((C_word*)t0)[5]);}}}}

/* a8696 in k8549 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8697,3,t0,t1,t2);}
/* optimizer.scm: 1283 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8541(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8675 in k8549 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1282 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8541(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8649 in k8549 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8651,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_8566(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1271 get */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[46]);}
else{
t2=((C_word*)t0)[9];
f_8566(2,t2,C_SCHEME_FALSE);}}}

/* k8595 in k8649 in k8549 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8597,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1272 get */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[74]);}
else{
t2=((C_word*)t0)[4];
f_8566(2,t2,C_SCHEME_FALSE);}}

/* k8601 in k8595 in k8649 in k8549 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8603,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1273 get */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[115]);}
else{
t2=((C_word*)t0)[4];
f_8566(2,t2,C_SCHEME_FALSE);}}

/* k8607 in k8601 in k8595 in k8649 in k8549 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8609,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1276 scan */
t9=((C_word*)t0)[4];
f_8718(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_8566(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_8566(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_8566(2,t2,C_SCHEME_FALSE);}}

/* k8564 in k8549 in k8546 in k8543 in walk in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1277 transform */
t2=((C_word*)t0)[11];
f_9172(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1278 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8541(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_8718(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8718,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8721,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9163,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1362 rec */
t18=((C_word*)t12)[1];
f_8721(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k9161 in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9163,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9170,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1363 delete */
t3=C_retrieve(lf[206]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[35]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9168 in k9161 in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1363 lset= */
t2=C_retrieve(lf[205]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_8721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8721,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_8725,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t4,a[9]=t5,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=t3,a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9150,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* f_9150 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9150,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_8728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=t1,tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9145,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9145 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9145(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9145,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_8731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9140,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9140 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9140,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8731,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8770,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=t3,a[6]=((C_word*)t0)[18],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1294 get */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[14],t3,lf[201]);}
else{
t3=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t3)){
if(C_truep(((C_word*)t0)[13])){
t4=(C_word)C_i_caddr(((C_word*)t0)[19]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8788,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1302 decompose-lambda-list */
t6=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[18],t4,t5);}
else{
t4=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_eqp(t1,lf[87]);
if(C_truep(t4)){
t5=((C_word*)((C_word*)t0)[16])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[19]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[15])[1],t6);
t8=C_mutate(((C_word *)((C_word*)t0)[15])+1,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8825,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1311 every */
t10=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[18],t9,((C_word*)t0)[11]);}}
else{
t5=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t5)){
if(C_truep(((C_word*)t0)[8])){
if(C_truep(((C_word*)t0)[7])){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8859,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[11]);
/* optimizer.scm: 1314 scan-used-variables */
t8=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,((C_word*)t0)[9]);}
else{
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_eqp(t1,lf[202]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8875,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cadr(((C_word*)t0)[19]);
/* optimizer.scm: 1319 estimate-foreign-result-size */
t9=C_retrieve(lf[203]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t7=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8916,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t9=(C_word)C_i_car(((C_word*)t0)[19]);
/* optimizer.scm: 1327 estimate-foreign-result-size */
t10=C_retrieve(lf[203]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t8,t9);}
else{
t8=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t8)){
t9=(C_word)C_i_car(((C_word*)t0)[11]);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9043,a[2]=t9,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[18],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9044,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t9)){
t10=(C_word)C_i_cadddr(((C_word*)t0)[19]);
t11=(C_word)C_eqp(t10,C_fix(0));
if(C_truep(t11)){
t12=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t12=((C_word*)((C_word*)t0)[16])[1];
if(C_truep(t12)){
t13=((C_word*)t0)[18];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[15])[1],t10);
t14=C_mutate(((C_word *)((C_word*)t0)[15])+1,t13);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9078,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1353 every */
t16=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t16))(4,t16,((C_word*)t0)[18],t15,((C_word*)t0)[11]);}}}
else{
t10=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t10)){
t11=(C_word)C_i_car(((C_word*)t0)[11]);
t12=(C_word)C_i_car(((C_word*)t0)[19]);
/* optimizer.scm: 1354 rec */
t13=((C_word*)((C_word*)t0)[10])[1];
f_8721(t13,((C_word*)t0)[18],t11,t12,C_SCHEME_FALSE,((C_word*)t0)[9]);}
else{
t11=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9111,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_i_car(((C_word*)t0)[11]);
t14=(C_word)C_i_car(((C_word*)t0)[19]);
/* optimizer.scm: 1356 rec */
t15=((C_word*)((C_word*)t0)[10])[1];
f_8721(t15,t12,t13,t14,((C_word*)t0)[2],((C_word*)t0)[9]);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9135,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1358 every */
t13=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t13))(4,t13,((C_word*)t0)[18],t12,((C_word*)t0)[11]);}}}}}}}}}}}

/* a9134 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9135,3,t0,t1,t2);}
/* optimizer.scm: 1358 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8721(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9109 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9111,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9122,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1357 append */
t4=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9120 in k9109 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1357 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8721(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a9077 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9078,3,t0,t1,t2);}
/* optimizer.scm: 1353 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8721(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* f_9044 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9044,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9043,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9035,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_9035 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9035,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9032 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9034,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8969,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)((C_word*)t0)[5])[1],C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8997,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9022,a[2]=t6,a[3]=t7,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9023,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t6=t3;
f_8969(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_8969(t5,(C_word)C_eqp(t2,((C_word*)t0)[2]));}}

/* f_9023 in k9032 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9023,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9020 in k9032 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9022,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9014,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_8997(t3,C_SCHEME_UNDEFINED);}}

/* f_9014 in k9020 in k9032 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9014(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9014,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9011 in k9020 in k9032 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9013,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_8997(t5,t4);}

/* k8995 in k9032 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_8997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_8969(t3,C_SCHEME_TRUE);}

/* k8967 in k9032 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_8969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8969,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1346 every */
t4=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8973 in k8967 in k9032 in k9041 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8974,3,t0,t1,t2);}
/* optimizer.scm: 1346 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8721(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8914 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8916,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8922,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8922(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8922(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8922(t7,C_SCHEME_TRUE);}}}

/* k8920 in k8914 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_8922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8922,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8927,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1333 every */
t3=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8926 in k8920 in k8914 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8927,3,t0,t1,t2);}
/* optimizer.scm: 1333 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8721(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8873 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8875,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8881,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8881(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8881(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8881(t7,C_SCHEME_TRUE);}}}

/* k8879 in k8873 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_8881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8881,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8886,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1325 every */
t3=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8885 in k8879 in k8873 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8886,3,t0,t1,t2);}
/* optimizer.scm: 1325 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8721(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8857 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8859,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1316 alist-cons */
t3=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8853 in k8857 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a8824 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8825,3,t0,t1,t2);}
/* optimizer.scm: 1311 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8721(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a8787 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8788,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8804,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1306 append */
t9=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t2,((C_word*)t0)[2]);}

/* k8802 in a8787 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1306 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8721(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k8768 in k8729 in k8726 in k8723 in rec in scan in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9172(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9172,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9176,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t7,a[7]=t1,a[8]=t5,a[9]=t6,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9786,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9788,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t11=*((C_word*)lf[199]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1368 debugging */
t9=C_retrieve(lf[6]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,lf[7],lf[200],t3,t7);}}

/* a9787 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9788,2,t0,t1);}
/* optimizer.scm: 1367 unzip1 */
t2=C_retrieve(lf[198]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k9784 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1367 debugging */
t2=C_retrieve(lf[6]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[7],lf[197],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9176,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9772,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* f_9772 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9772,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9180,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(C_word)C_i_length(t2);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1373 get */
t7=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[2],((C_word*)t0)[5],lf[115]);}

/* k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9186,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t5=(C_word)C_i_length(((C_word*)t0)[11]);
t6=(C_word)C_eqp(t5,C_fix(4));
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
t8=t4;
f_9192(t8,(C_word)C_i_listp(t7));}
else{
t7=t4;
f_9192(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9192(t5,C_SCHEME_FALSE);}}

/* k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_9192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9192,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1377 caaddr */
t4=*((C_word*)lf[195]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 1475 bomb */
t2=C_retrieve(lf[177]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[10],lf[196],((C_word*)t0)[13]);}}

/* k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1378 cdaddr */
t3=*((C_word*)lf[194]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9201,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1382 node-class-set! */
t5=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[193]);}

/* k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9210,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9735,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9736,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_9736 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9736,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9735,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9446,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_9446(3,t6,((C_word*)t0)[2],t2);}

/* rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9446,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9727,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_9727 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9727(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9727,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9453,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9722,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* f_9722 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9722,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9717,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}

/* f_9717 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9717,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9456,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(C_word)C_i_cadr(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9471,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9674,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t3=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_i_car(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9700,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1429 alist-cons */
t7=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}
else{
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[9],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[13]);}}
else{
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[9],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[13]);}}}

/* k9698 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9700,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1430 copy-node! */
t5=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* k9701 in k9698 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1431 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9446(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_9674 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9674(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9674,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9669,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9669 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9669,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9664,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9664 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9664,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9663,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=(C_word)C_eqp(((C_word*)t0)[12],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1396 alist-cons */
t6=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)((C_word*)t0)[11])[1]);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[13]);
t6=(C_word)C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9638,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1421 node-class-set! */
t8=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,((C_word*)t0)[6],lf[191]);}
else{
/* optimizer.scm: 1424 bomb */
t7=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[7],lf[192]);}}}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9636 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1422 node-parameters-set! */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k9639 in k9636 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1423 node-subexpressions-set! */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9490,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9499,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_9499(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1399 quit */
t9=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[187],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9613,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[2],tmp=(C_word)a,a+=10,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9614,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}
else{
/* optimizer.scm: 1419 bomb */
t7=C_retrieve(lf[177]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[8],lf[190],((C_word*)t0)[11]);}}}

/* f_9614 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9614,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9613,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9545,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_i_length(t4);
t6=(C_word)C_eqp(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t3;
f_9545(2,t7,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1410 quit */
t7=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,lf[189],((C_word*)t0)[2]);}}

/* k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1413 node-class-set! */
t3=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],lf[11]);}

/* k9546 in k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9582,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9590,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9591,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_9591 in k9546 in k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9591,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9588 in k9546 in k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_caddr(t1);
/* optimizer.scm: 1414 take */
t3=C_retrieve(lf[188]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_fix(1));}

/* k9580 in k9546 in k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1414 node-parameters-set! */
t2=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9549 in k9546 in k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9554,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9565,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9574,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[186],t4,t5);}

/* f_9574 in k9549 in k9546 in k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9574,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k9563 in k9549 in k9546 in k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9565,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
/* optimizer.scm: 1415 node-subexpressions-set! */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9552 in k9549 in k9546 in k9543 in k9611 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1418 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9446(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9497 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1402 node-class-set! */
t3=C_retrieve(lf[185]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[186]);}

/* k9500 in k9497 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1403 node-parameters-set! */
t4=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[3],t3);}

/* k9503 in k9500 in k9497 in k9488 in k9661 in k9472 in k9469 in k9454 in k9451 in k9448 in rec in k9733 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1404 node-subexpressions-set! */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9213,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9357,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9426,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9428,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1452 lset-difference */
t6=C_retrieve(lf[184]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a9427 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9428,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k9424 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9356 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9357,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9418,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_9418 in a9356 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9418,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9362 in a9356 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9367,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(t1);
t4=(C_word)C_i_length(t3);
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t2;
f_9367(2,t6,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1442 quit */
t6=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,lf[183],((C_word*)t0)[2]);}}

/* k9365 in k9362 in a9356 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9367,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2]);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=(C_word)C_i_cddr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9391,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t3,lf[181],t4,t7);}

/* f_9391 in k9365 in k9362 in a9356 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9391,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k9380 in k9365 in k9362 in a9356 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9382,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1445 node-subexpressions-set! */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9213,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9222,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9348,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* f_9348 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9348(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9348,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9225,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1457 copy-node! */
t3=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9274,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1459 fold-right */
t4=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9274,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9334,a[2]=t5,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t2);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9339,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* f_9339 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9339,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9334,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9302,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9326,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_9326 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9326,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k9300 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9306,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9321,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9321 in k9300 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9321,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k9304 in k9300 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9310,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9316,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9316 in k9304 in k9300 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9316(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9316,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9308 in k9304 in k9300 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9311,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9311 in k9308 in k9304 in k9300 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9311,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k9296 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9298,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9290,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_9290 in k9296 in k9332 in a9273 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9290,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9231,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1468 copy-node! */
t3=C_retrieve(lf[180]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k9229 in k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9236,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9235 in k9229 in k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9236,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9243,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9272,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1472 gensym */
t6=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k9270 in a9235 in k9229 in k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9272,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1472 node-parameters-set! */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9241 in a9235 in k9229 in k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9250,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9260,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_9260 in k9241 in a9235 in k9229 in k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9260,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k9248 in k9241 in a9235 in k9229 in k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9254,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9255,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_9255 in k9248 in k9241 in a9235 in k9229 in k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9255,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k9252 in k9248 in k9241 in a9235 in k9229 in k9226 in k9223 in k9220 in k9211 in k9208 in k9205 in k9199 in k9196 in k9190 in k9184 in k9178 in k9174 in transform in ##compiler#transform-direct-lambdas! in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_9254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_car(((C_word*)t0)[2],t1));}

/* ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word ab[189],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6192,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6249,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6375,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);
case C_fix(2):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6400,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6498,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t4);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6531,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6552,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep(C_retrieve(lf[143]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6580,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6625,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t4);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[139]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6648,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6719,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[139]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6753,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6804,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t4);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[139]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t11,t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6842,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6888,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t4);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[139]))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6915,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6922,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[139]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6941,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7087,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7115,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7186,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t4);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[143]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7214,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7266,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t4);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[139]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7285,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7354,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[139]))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7373,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7425,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_cadr(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7450,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7505,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t4);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=C_retrieve(lf[143]);
t12=(C_truep(t11)?t11:(C_word)C_i_cadddr(t7));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7544,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7605,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t4);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_i_not(t9);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,t9));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7649,a[2]=t10,a[3]=t11,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7711,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t4);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[139]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7739,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7785,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t4);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[139]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7818,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7839,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[139]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7858,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8003,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[143]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t9,t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8040,a[2]=t8,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8102,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t4);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[139]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8125,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8286,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[139]))){
t12=(C_word)C_eqp(t10,t9);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8320,a[2]=t11,a[3]=t8,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8381,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t4);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[139]))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8400,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8529,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1244 bomb */
t9=C_retrieve(lf[177]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t1,lf[178]);}}

/* f_8529 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8529,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8400,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8420,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8429,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1230 varnode */
t10=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8433,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a8440 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8441,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8449,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8455,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_8455(t9,t4,t3,t5);}

/* loop in a8440 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_8455(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8455,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 854  varnode */
t6=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6217,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_6217(t8,(C_word)C_eqp(lf[26],t7));}
else{
t7=t6;
f_6217(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8504,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1242 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k8502 in loop in a8440 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8504,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6215 in loop in a8440 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_6217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 855  qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 856  qnode */
t2=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k8473 in loop in a8440 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8479,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1240 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8455(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k8477 in k8473 in loop in a8440 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8479,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8447 in a8440 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1233 append */
t2=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8434 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8435,2,t0,t1);}
/* optimizer.scm: 1232 split-at */
t2=C_retrieve(lf[85]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8431 in k8427 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1229 cons* */
t2=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8418 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8421,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_8421 in k8418 in k8398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8421,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_8381 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8381,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k8318 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8320,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8345,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[148]),lf[153]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8364,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1211 fifth */
t7=C_retrieve(lf[175]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8372,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t4,lf[87],t7,((C_word*)t0)[3]);}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_8372 in k8318 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8372,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8362 in k8318 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8364,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8356,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[141],t2,((C_word*)t0)[2]);}

/* f_8356 in k8362 in k8318 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8356,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8343 in k8318 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8345,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8337,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[176],t2);}

/* f_8337 in k8343 in k8318 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8337,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_8286 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8286,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8125,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8131,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1171 fifth */
t4=C_retrieve(lf[175]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8131,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8140,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1175 remove */
t6=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a8246 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8247,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8274,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8275,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_8275 in a8246 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8275,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k8272 in a8246 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8274,2,t0,t1);}
t2=(C_word)C_eqp(lf[26],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8266,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_8266 in k8272 in a8246 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8266,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k8263 in k8272 in a8246 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8140,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8162,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1180 qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8176,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[6],lf[15],lf[173],t4);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8200,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1188 fold-inner */
t5=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,t1);}}}

/* a8201 in k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8202,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[148]),lf[153]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8221,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[141],t5,t6);}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8237,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[87],t5,t6);}}

/* f_8237 in a8201 in k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8237,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_8221 in a8201 in k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8221(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8221,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8198 in k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8200,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8192,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[174],t2);}

/* f_8192 in k8198 in k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8192(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8192,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_8176 in k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8176,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8160 in k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8162,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8154,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[172],t2);}

/* f_8154 in k8160 in k8138 in k8129 in k8123 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8154,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_8102 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8102(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8102,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k8038 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8040,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8056,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8064,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8081,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t5,t6,t7);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8080 in k8038 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8081,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8093,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1159 qnode */
t6=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k8091 in a8080 in k8038 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8093,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1158 append */
t3=*((C_word*)lf[12]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8070 in k8038 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8071,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1157 split-at */
t3=C_retrieve(lf[85]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k8062 in k8038 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8065,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[141],((C_word*)t0)[2],t1);}

/* f_8065 in k8062 in k8038 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8065,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k8054 in k8038 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8056,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8048,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[171],t2);}

/* f_8048 in k8054 in k8038 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8048,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_8003 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_8003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8003,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7858,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7867,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7964,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1126 remove */
t6=C_retrieve(lf[170]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7963 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7964(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7964,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7991,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7992,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_7992 in a7963 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7992,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k7989 in a7963 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7991,2,t0,t1);}
t2=(C_word)C_eqp(lf[26],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7982,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7983,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_7983 in k7989 in a7963 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7983,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k7980 in k7989 in a7963 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k7865 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7867,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7889,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1131 qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7903,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],lf[15],lf[167],t4);}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[148]),lf[153]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7936,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7938,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1139 fold-inner */
t7=C_retrieve(lf[169]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a7937 in k7865 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7938,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7951,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[141],t4,t5);}

/* f_7951 in a7937 in k7865 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7951,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7934 in k7865 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7936,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7928,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[168],t2);}

/* f_7928 in k7934 in k7865 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7928,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7903 in k7865 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7903,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7887 in k7865 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7889,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7881,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[166],t2);}

/* f_7881 in k7887 in k7865 in k7856 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7881,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7839 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7839,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7816 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7818,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1113 qnode */
t4=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7832 in k7816 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7834,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7826,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[165],t2);}

/* f_7826 in k7832 in k7816 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7826,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7785 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7785(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7785,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7737 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7739,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7755,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7771,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[143]))){
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=t3;
f_7771(t5,(C_word)C_i_pairp(t4));}
else{
t4=t3;
f_7771(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7769 in k7737 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_7771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7771,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[4]):(C_word)C_i_cadr(((C_word*)t0)[4]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7760,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[141],t3,((C_word*)t0)[2]);}

/* f_7760 in k7769 in k7737 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7760,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7753 in k7737 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7755,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7747,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[164],t2);}

/* f_7747 in k7753 in k7737 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7747,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7711 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7711,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7647 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7649,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7674,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[7]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7691,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t7)){
t8=t6;
f_7691(t8,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=t6;
f_7691(t9,(C_word)C_fixnum_times(((C_word*)t0)[2],t8));}
else{
t8=t6;
f_7691(t8,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7689 in k7647 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_7691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7691,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7679,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[87],t2,((C_word*)t0)[2]);}

/* f_7679 in k7689 in k7647 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7679,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7672 in k7647 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7674,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7666,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[163],t2);}

/* f_7666 in k7672 in k7647 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7666,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7605 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7605,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7542 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7544,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[148]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7561,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1064 varnode */
t9=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[148]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7592,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[4],lf[15],lf[162],t6);}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7592 in k7542 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7592,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7568 in k7542 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1064 cons* */
t2=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7559 in k7542 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7562,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_7562 in k7559 in k7542 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7562,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7505 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7505,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7448 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7450,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[148]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[143]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(C_retrieve(lf[143]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7486,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t6,lf[141],t8,((C_word*)t0)[2]);}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7486 in k7448 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7486,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7479 in k7448 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7481,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7473,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[161],t2);}

/* f_7473 in k7479 in k7448 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7473,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7425 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7425,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7371 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7373,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7392,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_7392(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_7392(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7390 in k7371 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_7392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7392,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7396,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7410,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,lf[160],t4,C_SCHEME_END_OF_LIST);}

/* f_7410 in k7390 in k7371 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7410,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7403 in k7390 in k7371 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1037 cons* */
t2=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7394 in k7390 in k7371 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7397,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_7397 in k7394 in k7390 in k7371 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7397,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7354 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7354,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7283 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7285,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7317,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],lf[15],lf[159],t7);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7332,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 1027 varnode */
t12=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7339 in k7283 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1027 cons* */
t2=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7330 in k7283 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7333,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_7333 in k7330 in k7283 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7333,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7317 in k7283 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7317,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7266 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7266,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7212 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7214,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7226(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_7226(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7224 in k7212 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_7226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7226,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7237,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1012 varnode */
t7=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7244 in k7224 in k7212 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1012 cons* */
t2=C_retrieve(lf[158]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7235 in k7224 in k7212 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7238,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_7238 in k7235 in k7224 in k7212 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7238,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7186 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7186,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k7113 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7115,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7144,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 994  varnode */
t7=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7142 in k7113 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7144,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7152,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 997  qnode */
t5=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k7150 in k7142 in k7113 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7156,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 999  varnode */
t5=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}
else{
t4=t2;
f_7156(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k7154 in k7150 in k7142 in k7113 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7156,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7136,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t2);}

/* f_7136 in k7154 in k7150 in k7142 in k7113 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7136,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_7087 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7087,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6941,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 965  qnode */
t4=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6969,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[143]))){
t4=(C_word)C_eqp(C_retrieve(lf[148]),lf[157]);
t5=t3;
f_6969(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6969(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_6969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6969,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6972(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[148]),lf[153]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_6972(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[148]),lf[156]);
t6=t2;
f_6972(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[3]):C_SCHEME_FALSE));}}}

/* k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_6972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6972,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7050,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7049 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7050,3,t0,t1,t2);}
/* optimizer.scm: 969  gensym */
t3=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[48]),t1);}

/* k6976 in k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6983,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7004,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_retrieve(lf[148]),lf[153]);
t5=(C_truep(t4)?(C_word)C_i_car(((C_word*)t0)[3]):(C_word)C_i_cadr(((C_word*)t0)[3]));
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7020,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7022,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 981  fold-boolean */
t9=C_retrieve(lf[155]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,t8,t1);}

/* a7021 in k6976 in k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7022,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7031,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[141],((C_word*)t0)[2],t4);}

/* f_7031 in a7021 in k6976 in k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7031,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7018 in k6976 in k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7020,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7009,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[154],t2);}

/* f_7009 in k7018 in k6976 in k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7009,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k7002 in k6976 in k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 971  fold-right */
t2=C_retrieve(lf[125]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6982 in k6976 in k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6983,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6996,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[11],t5,t6);}

/* f_6996 in a6982 in k6976 in k6973 in k6970 in k6967 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6996,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6961 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6963,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6955,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[152],t2);}

/* f_6955 in k6961 in k6939 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6955(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6955,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6922 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6922,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6913 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6888 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6888,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6840 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6866,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6879,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* optimizer.scm: 951  qnode */
t8=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6877 in k6840 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6879,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 950  append */
t3=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6864 in k6840 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6867,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[141],((C_word*)t0)[2],t1);}

/* f_6867 in k6864 in k6840 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6867,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6856 in k6840 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6858,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6850,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[151],t2);}

/* f_6850 in k6856 in k6840 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6850,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6804 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6804,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6751 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6753,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6769,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6786,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6791,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[141],t7,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6791 in k6751 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6791,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6784 in k6751 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6786,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6778,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[141],((C_word*)t0)[2],t2);}

/* f_6778 in k6784 in k6751 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6778,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6767 in k6751 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6769,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6761,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[150],t2);}

/* f_6761 in k6767 in k6751 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6761,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6719 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6719,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6646 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6648,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[148])));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_car(((C_word*)t0)[4]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_i_car(((C_word*)t0)[5]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6703,a[2]=t9,a[3]=t7,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 927  qnode */
t13=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t11,t12);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6701 in k6646 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6691,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[141],((C_word*)t0)[2],t2);}

/* f_6691 in k6701 in k6646 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6691,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6680 in k6646 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6682,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6674,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[149],t2);}

/* f_6674 in k6680 in k6646 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6674,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6625 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6625,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6578 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6580,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6600,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 909  varnode */
t6=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6598 in k6578 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6600,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 912  qnode */
t5=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k6606 in k6598 in k6578 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6608,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6592,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t3);}

/* f_6592 in k6606 in k6598 in k6578 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6592,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6552 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6552,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6529 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6531,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 900  varnode */
t4=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6545 in k6529 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6547,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6539,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[147],t2);}

/* f_6539 in k6545 in k6529 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6539,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6498 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6498,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6400,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[143]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6492,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6493,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}
else{
t8=t7;
f_6434(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6493 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6493,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6490 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6492,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6475,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6483,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6484,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_6434(t3,C_SCHEME_FALSE);}}

/* f_6484 in k6490 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6484,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6481 in k6490 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 891  get */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,lf[146]);}

/* k6473 in k6490 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6434(t2,(C_word)C_eqp(lf[145],t1));}

/* k6432 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_6434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6434,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6442,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[141],t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6454,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],lf[141],t3,((C_word*)t0)[3]);}}

/* f_6454 in k6432 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6454,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6442 in k6432 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6442,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6429 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6431,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6423,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[144],t2);}

/* f_6423 in k6429 in k6398 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6423,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_6375 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6375,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6249,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6361,a[2]=t6,a[3]=t7,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6362,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t6=t2;
f_6252(2,t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_6362 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6362,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6353,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[4];
f_6252(2,t3,C_SCHEME_FALSE);}}

/* f_6353 in k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6353,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k6350 in k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6352,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6344,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_6252(2,t3,C_SCHEME_FALSE);}}

/* f_6344 in k6350 in k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6344,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6332 in k6350 in k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6339,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_6339 in k6332 in k6350 in k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6339,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k6336 in k6332 in k6350 in k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6338,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(((C_word*)t0)[4],t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 870  qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6252(2,t2,C_SCHEME_FALSE);}}

/* k6328 in k6336 in k6332 in k6350 in k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6330,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6322,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[142],t2);}

/* f_6322 in k6328 in k6336 in k6332 in k6350 in k6359 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6322,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6250 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6252,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[139]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6274,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6279,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[141],t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* f_6279 in k6250 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6279,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k6272 in k6250 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6274,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6266,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[140],t2);}

/* f_6266 in k6272 in k6250 in k6247 in ##compiler#simplify-named-call in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6266,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* ##compiler#rewrite in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6172(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6172r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6172r(t0,t1,t2,t3);}}

static void C_ccall f_6172r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6176,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 848  ##sys#hash-table-ref */
t5=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[136]),t2);}

/* k6174 in ##compiler#rewrite in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6176,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 849  append */
t5=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,t4);}

/* k6184 in k6174 in ##compiler#rewrite in k6168 in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 849  ##sys#hash-table-set! */
t2=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[136]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5812,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5816,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 760  map */
t8=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,*((C_word*)lf[135]+1),t2,t3);}

/* k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5818,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 771  for-each */
t5=*((C_word*)lf[133]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6156 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6157,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6162,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 772  scan-used-variables */
t6=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}

/* k6164 in a6156 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 772  alist-cons */
t2=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6160 in a6156 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a6098 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6099,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6109,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 781  filter */
t5=C_retrieve(lf[130]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* a6130 in a6098 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6131,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 782  find-path */
t5=((C_word*)t0)[2];
f_5818(t5,t4,((C_word*)t0)[3],t2);}}

/* k6142 in a6130 in a6098 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 782  find-path */
t2=((C_word*)t0)[5];
f_5818(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6107 in a6098 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6113,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 784  gensym */
t4=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6123 in k6107 in a6098 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6125,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 784  alist-cons */
t3=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k6111 in k6107 in a6098 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6113,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6117,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 785  append */
t5=*((C_word*)lf[12]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k6115 in k6111 in k6107 in a6098 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5869,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a6039 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6040,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 794  append-map */
t7=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}

/* a6082 in a6039 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6083,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6089,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 795  filter */
t4=C_retrieve(lf[130]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a6088 in a6082 in a6039 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6089,3,t0,t1,t2);}
/* optimizer.scm: 795  find-path */
t3=((C_word*)t0)[3];
f_5818(t3,t1,((C_word*)t0)[2],t2);}

/* k6045 in a6039 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6051,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6055,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6057,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 800  filter-map */
t5=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a6056 in k6045 in a6039 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6057,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6070,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 801  lset<= */
t6=C_retrieve(lf[128]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,*((C_word*)lf[35]+1),t5,((C_word*)t0)[2]);}}

/* k6068 in a6056 in k6045 in a6039 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k6053 in k6045 in a6039 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 798  alist-cons */
t2=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6049 in k6045 in a6039 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 807  topological-sort */
t3=C_retrieve(lf[127]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[35]+1));}

/* k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5872,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 812  fold */
t6=C_retrieve(lf[126]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[2],t1);}

/* a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5892,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5905,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_5905(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_5905(t9,C_SCHEME_FALSE);}}

/* k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5905(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5905,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5917,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t6);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5934,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5964,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5966,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 826  fold-right */
t5=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5965 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5966,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 829  gensym */
t5=C_retrieve(lf[82]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6010 in a5965 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6012,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5987,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
t5=(C_word)C_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5996,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t3,lf[16],t4,t7);}

/* f_5996 in k6010 in a5965 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5996,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5985 in k6010 in a5965 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5987,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5979,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_5979 in k5985 in k6010 in a5965 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5979,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5962 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 821  fold-right */
t2=C_retrieve(lf[125]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5933 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5934,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5955,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5956,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_5956 in a5933 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5956,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5953 in a5933 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5955,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5947,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_5947 in k5953 in a5933 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5947,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_5917 in k5903 in a5891 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5917,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5873 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5875,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5884,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 838  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[7],lf[124],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 840  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k5882 in k5873 in k5870 in k5867 in k5864 in k5861 in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 839  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5818(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5818,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5824,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5824(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5824(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5824,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5848,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 768  any */
t9=C_retrieve(lf[31]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,t8,t5);}}}

/* a5847 in find in find-path in k5814 in ##compiler#reorganize-recursive-bindings in k5808 in k5805 in k5802 in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5848,3,t0,t1,t2);}
/* optimizer.scm: 768  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5824(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5797(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_5797r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5797r(t0,t1,t2,t3);}}

static void C_ccall f_5797r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 539  ##sys#hash-table-set! */
t4=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,*((C_word*)lf[22]+1),t2,t3);}

/* ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5224,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5227,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5231,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5238,a[2]=t3,a[3]=t9,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 452  debugging */
t11=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,lf[20],lf[120]);}

/* k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5529,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5791,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[119]);}

/* f_5791 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5791,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5534,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5787,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 491  test */
t4=((C_word*)t0)[3];
f_5231(t4,t3,lf[119],lf[115]);}
else{
t2=((C_word*)t0)[2];
f_5241(2,t2,C_SCHEME_UNDEFINED);}}

/* k5785 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5534,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5541,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5779,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_5779 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5779,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cadr(t1);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5774,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* f_5774 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5774,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5769,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5547,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5765,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 461  test */
t5=((C_word*)t0)[2];
f_5231(t5,t4,t2,lf[75]);}

/* k5763 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5547(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 461  test */
t2=((C_word*)t0)[3];
f_5231(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[46]);}}

/* k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5550,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 462  test */
t3=((C_word*)t0)[3];
f_5231(t3,t2,((C_word*)t0)[2],lf[74]);}

/* k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[5]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5742,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5743,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}
else{
t7=t2;
f_5556(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5556(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5556(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5556(t3,C_SCHEME_FALSE);}}

/* f_5743 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5743,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5740 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5556(t2,(C_word)C_eqp(lf[54],t1));}

/* k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5556(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5556,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5716,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5716 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5716,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5715,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5707,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_5707 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5707,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5706,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5698,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_5698 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5698,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[9]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=t2;
f_5571(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_5571(t3,C_SCHEME_FALSE);}}

/* k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5571(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5571,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5577,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 473  test */
t4=((C_word*)t0)[2];
f_5231(t4,t3,t2,lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5678,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5679,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[5]);}
else{
t5=t2;
f_5583(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5583(t3,C_SCHEME_FALSE);}}

/* f_5679 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5679,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5676 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5583(t2,(C_word)C_eqp(lf[10],t1));}

/* k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5583,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5661,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5661 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5661,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5660,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5651,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5652,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_5652 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5652,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5649 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5651,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5643,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_5592(t3,C_SCHEME_FALSE);}}

/* f_5643 in k5649 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5643,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5640 in k5649 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
f_5592(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k5590 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5592,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 485  node-parameters-set! */
t5=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[118]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5597 in k5590 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5602,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 486  node-subexpressions-set! */
t4=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k5600 in k5597 in k5590 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 489  reverse */
t6=*((C_word*)lf[117]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k5618 in k5600 in k5597 in k5590 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 487  node-subexpressions-set! */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5603 in k5600 in k5597 in k5590 in k5658 in k5581 in k5575 in k5569 in k5563 in k5704 in k5713 in k5554 in k5548 in k5545 in k5767 in k5539 in a5533 in k5527 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 490  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5227(((C_word*)t0)[2]));}

/* k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[116]));}

/* a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5255,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5262,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5522,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_5522 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5522,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5262,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5518,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 529  test */
t4=((C_word*)t0)[4];
f_5231(t4,t3,((C_word*)t0)[5],lf[115]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5516 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5267,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5510,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* f_5510 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5510,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cadr(t1);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5505,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* f_5505 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5505,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5280,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 502  test */
t4=((C_word*)t0)[3];
f_5231(t4,t3,t2,lf[74]);}

/* k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5283,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 503  test */
t4=((C_word*)t0)[4];
f_5231(t4,t3,((C_word*)t0)[2],lf[75]);}

/* k5494 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5283(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 503  test */
t2=((C_word*)t0)[3];
f_5231(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[46]);}}

/* k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5289,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5482,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}
else{
t3=t2;
f_5289(t3,C_SCHEME_FALSE);}}

/* f_5482 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5482,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5479 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5481,2,t0,t1);}
t2=(C_word)C_eqp(lf[54],t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
t3=(C_word)C_i_length(((C_word*)t0)[5]);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5463,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5465,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* optimizer.scm: 508  any */
t8=C_retrieve(lf[31]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}
else{
t5=((C_word*)t0)[4];
f_5289(t5,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[4];
f_5289(t3,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[4];
f_5289(t3,C_SCHEME_FALSE);}}

/* a5464 in k5479 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5465,3,t0,t1,t2);}
/* optimizer.scm: 508  expression-has-side-effects? */
t3=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k5461 in k5479 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5289(t2,(C_word)C_i_not(t1));}

/* k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5289,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5437,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5437 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5437,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5428,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_5428 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5428,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5414,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5415,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=t3;
f_5301(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_5301(t4,C_SCHEME_FALSE);}}

/* f_5415 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5415,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5412 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5301(t2,(C_word)C_eqp(lf[10],t1));}

/* k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5301,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5307,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 516  test */
t4=((C_word*)t0)[2];
f_5231(t4,t3,t2,lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5394,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_5394 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5394,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5393,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5316,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_i_length(((C_word*)t0)[3]);
t5=(C_word)C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5380,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5381,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
t6=t3;
f_5316(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_5316(t4,C_SCHEME_FALSE);}}

/* f_5381 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5381,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k5378 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5380,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5372,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
f_5316(t3,C_SCHEME_FALSE);}}

/* f_5372 in k5378 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5372,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k5369 in k5378 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=((C_word*)t0)[3];
f_5316(t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k5314 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5316,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5344,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* f_5344 in k5314 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5344,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k5317 in k5314 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 525  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[7],lf[114],((C_word*)t0)[2]);}

/* k5320 in k5317 in k5314 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 526  node-parameters-set! */
t3=C_retrieve(lf[112]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[113]);}

/* k5323 in k5320 in k5317 in k5314 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5328,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5343,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 527  qnode */
t5=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k5341 in k5323 in k5320 in k5317 in k5314 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5343,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 527  node-subexpressions-set! */
t3=C_retrieve(lf[111]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5326 in k5323 in k5320 in k5317 in k5314 in k5391 in k5305 in k5299 in k5425 in k5434 in k5287 in k5281 in k5278 in k5498 in k5272 in a5266 in k5260 in a5254 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 528  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5227(((C_word*)t0)[2]));}

/* k5242 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 532  debugging */
t4=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[7],lf[110],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5247(2,t4,C_SCHEME_UNDEFINED);}}

/* k5245 in k5242 in k5239 in k5236 in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5231(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5231,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 450  get */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static C_word C_fcall f_5227(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[70],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3524,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3527,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3533,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3548,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3563,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3567,a[2]=t3,a[3]=t21,a[4]=t19,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3664,a[2]=t26,a[3]=t16,a[4]=t17,a[5]=t18,a[6]=t24,a[7]=t19,a[8]=t7,a[9]=t21,a[10]=t15,tmp=(C_word)a,a+=11,tmp));
t30=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3911,a[2]=t11,a[3]=t3,a[4]=t28,a[5]=t24,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t19,tmp=(C_word)a,a+=10,tmp));
t31=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5104,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5128,a[2]=t24,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 418  perform-pre-optimization! */
t33=C_retrieve(lf[109]);
((C_proc4)C_retrieve_proc(t33))(4,t33,t32,t2,t3);}

/* k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5128,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 419  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 421  debugging */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[20],lf[108]);}}

/* k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5134,2,t0,t1);}
t2=C_set_block_item(lf[23] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5138,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 423  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3664(3,t4,t3,((C_word*)t0)[2]);}

/* k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 424  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[7],lf[107],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5141(2,t3,C_SCHEME_UNDEFINED);}}

/* k5139 in k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5177,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[23])))){
/* optimizer.scm: 425  debugging */
t4=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[7],lf[106]);}
else{
t4=t3;
f_5177(2,t4,C_SCHEME_FALSE);}}

/* k5175 in k5139 in k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5177,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5182,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[23]));}
else{
t2=((C_word*)t0)[2];
f_5144(2,t2,C_SCHEME_UNDEFINED);}}

/* a5181 in k5175 in k5139 in k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5182,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5186,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 428  print* */
t5=*((C_word*)lf[105]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_make_character(9),t4);}

/* k5184 in a5181 in k5175 in k5139 in k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 430  print */
t4=*((C_word*)lf[103]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 431  newline */
t3=*((C_word*)lf[104]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,((C_word*)t0)[2]);}}

/* k5142 in k5139 in k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 433  debugging */
t4=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[7],lf[102],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5147(2,t4,C_SCHEME_UNDEFINED);}}

/* k5145 in k5142 in k5139 in k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 434  debugging */
t4=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[7],lf[101],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5150(2,t4,C_SCHEME_UNDEFINED);}}

/* k5148 in k5145 in k5142 in k5139 in k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 435  debugging */
t4=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[7],lf[100],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5153(2,t4,C_SCHEME_UNDEFINED);}}

/* k5151 in k5148 in k5145 in k5142 in k5139 in k5136 in k5132 in k5126 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 436  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5104(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5104,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5108,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k5106 in walk-generic in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5114,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 414  every */
t3=C_retrieve(lf[42]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1);}

/* k5112 in k5106 in walk-generic in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5114,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5118,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[6],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_5118 in k5112 in k5106 in walk-generic in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5118,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3911,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5098,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_5098 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5098,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5093,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_5093 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5093,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5088,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_5088 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5088,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3936(t7,((C_word*)t0)[9],t3);}
else{
t3=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4017,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 239  test */
t6=((C_word*)t0)[11];
f_3527(t6,t5,t4,lf[50]);}
else{
t4=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4080,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[13]);
/* optimizer.scm: 249  test */
t8=((C_word*)t0)[11];
f_3527(t8,t6,t7,lf[63]);}
else{
t5=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4258,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[13],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[7],tmp=(C_word)a,a+=14,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4970,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t6=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[13]);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[13],a[7]=t7,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 398  test */
t9=((C_word*)t0)[11];
f_3527(t9,t8,t7,lf[52]);}
else{
/* optimizer.scm: 410  walk-generic */
t7=((C_word*)((C_word*)t0)[5])[1];
f_5104(t7,((C_word*)t0)[9],((C_word*)t0)[4],t1,((C_word*)t0)[13],((C_word*)t0)[7]);}}}}}}

/* k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_4992(2,t3,t1);}
else{
/* optimizer.scm: 398  test */
t3=((C_word*)t0)[2];
f_3527(t3,t2,((C_word*)t0)[7],lf[50]);}}

/* k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
if(C_truep(t1)){
t2=f_3563(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4999,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 401  test */
t4=((C_word*)t0)[2];
f_3527(t4,t3,((C_word*)t0)[7],lf[99]);}}

/* k5079 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5081,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5049(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5077,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 402  variable-visible? */
t5=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5075 in k5079 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5049(t2,(C_word)C_i_not(t1));}

/* k5047 in k5079 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5049,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 403  test */
t3=((C_word*)t0)[3];
f_3527(t3,t2,((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[6];
f_5009(t2,C_SCHEME_FALSE);}}

/* k5068 in k5047 in k5079 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5009(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 404  expression-has-side-effects? */
t4=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* k5060 in k5068 in k5047 in k5079 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5009(t2,(C_word)C_i_not(t1));}

/* k5007 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_5009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5009,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3563(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 406  debugging */
t4=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[7],lf[97],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 408  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3664(3,t4,t2,t3);}}

/* k5037 in k5007 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5031,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[16],((C_word*)t0)[2],t2);}

/* f_5031 in k5037 in k5007 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5031,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k5013 in k5007 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5019,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_5019 in k5013 in k5007 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5019,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_4999 in k4990 in k4987 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4999,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_4970 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4970,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4258,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4927,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t3)){
if(C_truep((C_word)C_i_car(((C_word*)t0)[6]))){
/* optimizer.scm: 392  walk-generic */
t4=((C_word*)((C_word*)t0)[9])[1];
f_5104(t4,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[13]);}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4957,a[2]=t5,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[11])[1],((C_word*)t0)[13]);}}
else{
/* optimizer.scm: 394  walk-generic */
t4=((C_word*)((C_word*)t0)[9])[1];
f_5104(t4,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[13]);}}}

/* k4955 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4958,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_4958 in k4955 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4958,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_4927 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4927,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4926,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4922,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 287  test */
t5=((C_word*)t0)[4];
f_3527(t5,t4,t2,lf[75]);}

/* k4920 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4270(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 288  test */
t3=((C_word*)t0)[3];
f_3527(t3,t2,((C_word*)t0)[2],lf[46]);}}

/* k4910 in k4920 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4270(2,t2,t1);}
else{
/* optimizer.scm: 289  test */
t2=((C_word*)t0)[3];
f_3527(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[96]);}}

/* k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t1,a[13]=t2,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=((C_word*)t0)[13],tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm: 291  test */
t4=((C_word*)t0)[4];
f_3527(t4,t3,((C_word*)t0)[10],lf[52]);}

/* k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4279,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4282,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4315,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[67])))){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4479,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t4=t3;
f_4331(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4489,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[12])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4901,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4902,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[12]);}
else{
t3=t2;
f_4489(t3,C_SCHEME_FALSE);}}}}

/* f_4902 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4902,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4899 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4489(t2,(C_word)C_eqp(lf[54],t1));}

/* k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_4489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4489,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4887,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 389  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_5104(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* f_4887 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4887,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4492,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t2,a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 318  decompose-lambda-list */
t4=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4500,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_4510,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[89]))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[17],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 323  test */
t8=((C_word*)t0)[3];
f_3527(t8,t7,t5,lf[95]);}
else{
t7=t6;
f_4510(t7,C_SCHEME_FALSE);}}

/* k4851 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 324  test */
t3=((C_word*)t0)[2];
f_3527(t3,t2,((C_word*)t0)[3],lf[94]);}
else{
t2=((C_word*)t0)[5];
f_4510(t2,C_SCHEME_FALSE);}}

/* k4857 in k4851 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4859,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4882,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[93]);}
else{
t2=((C_word*)t0)[4];
f_4510(t2,C_SCHEME_FALSE);}}

/* f_4882 in k4857 in k4851 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4882,4,t0,t1,t2,t3);}
/* ##sys#get */
t4=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* k4860 in k4857 in k4851 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(t1,lf[90]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4510(t3,C_SCHEME_TRUE);}
else{
t3=(C_word)C_eqp(t1,lf[91]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4510(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[92]);
t6=((C_word*)t0)[3];
f_4510(t6,(C_word)C_fixnum_lessp(t4,t5));}}}

/* k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_4510(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4510,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],a[4]=t2,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4557,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4563,tmp=(C_word)a,a+=2,tmp);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[15],lf[80]);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[18],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[17],tmp=(C_word)a,a+=20,tmp);
/* optimizer.scm: 340  test */
t3=((C_word*)t0)[4];
f_3527(t3,t2,((C_word*)t0)[13],lf[63]);}}

/* k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 342  walk-generic */
t4=((C_word*)((C_word*)t0)[17])[1];
f_5104(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4587(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[4],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4840,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 364  test */
t4=((C_word*)t0)[6];
f_3527(t4,t3,((C_word*)t0)[2],lf[59]);}}

/* k4838 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_4745(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_4745(t2,C_SCHEME_FALSE);}}

/* k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_4745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4745,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[13]);
t3=(C_word)C_i_length(((C_word*)t0)[12]);
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* optimizer.scm: 368  walk-generic */
t4=((C_word*)((C_word*)t0)[11])[1];
f_5104(t4,((C_word*)t0)[10],t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 370  debugging */
t5=C_retrieve(lf[6]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[7],lf[88],((C_word*)t0)[3],t2);}}
else{
/* optimizer.scm: 388  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_5104(t2,((C_word*)t0)[10],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4770 in k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4771,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4804,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 381  qnode */
t8=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_i_length(t3);
t9=(C_word)C_fixnum_times(C_fix(3),t8);
t10=(C_word)C_a_i_list(&a,2,lf[86],t9);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4818,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,lf[87],t10,t3);}}

/* f_4818 in a4770 in k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4818,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4802 in a4770 in k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4804,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 377  append */
t3=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4794 in a4770 in k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4796,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4781 in a4770 in k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4784,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_4784 in k4781 in a4770 in k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4784,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4773 in a4770 in k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a4764 in k4758 in k4743 in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4765,2,t0,t1);}
/* optimizer.scm: 371  split-at */
t2=C_retrieve(lf[85]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_4587(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4587,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_3563(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 349  append-reverse */
t11=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 350  test */
t10=((C_word*)t0)[2];
f_3527(t10,t8,t9,lf[55]);}}

/* k4624 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
if(C_truep(t1)){
t2=f_3563(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 352  debugging */
t5=C_retrieve(lf[6]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,lf[7],lf[84],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 360  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_4587(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k4630 in k4624 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 353  expression-has-side-effects? */
t4=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k4636 in k4630 in k4624 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 356  gensym */
t3=C_retrieve(lf[82]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[83]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 359  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4587(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k4680 in k4636 in k4630 in k4624 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4682,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 357  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3664(3,t5,t3,t4);}

/* k4656 in k4680 in k4636 in k4630 in k4624 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 358  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4587(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4660 in k4656 in k4680 in k4636 in k4630 in k4624 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4650,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t2);}

/* f_4650 in k4660 in k4656 in k4680 in k4636 in k4630 in k4624 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4650,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4618 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4605 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4608,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[15],((C_word*)t0)[2],t1);}

/* f_4608 in k4605 in loop in k4571 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4608,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* f_4563 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4563,4,t0,t1,t2,t3);}
/* ##sys#get */
t4=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,t3);}

/* k4555 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4558,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4558 in k4555 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4558,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[36]));}

/* k4551 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?lf[77]:lf[78]);
t3=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* optimizer.scm: 330  debugging */
t4=C_retrieve(lf[6]);
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[4],lf[79],t2,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4511 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 336  check-signature */
t3=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4514 in k4511 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 337  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[7],lf[76],((C_word*)t0)[2]);}

/* k4517 in k4514 in k4511 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=f_3563(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4538,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_4538 in k4517 in k4514 in k4511 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4538,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k4535 in k4517 in k4514 in k4511 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 339  inline-lambda-bindings */
t3=C_retrieve(lf[64]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k4527 in k4517 in k4514 in k4511 in k4508 in a4499 in k4490 in k4487 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 339  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3664(3,t2,((C_word*)t0)[2],t1);}

/* f_4479 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4479,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4478,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4470,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
f_4331(2,t3,C_SCHEME_FALSE);}}

/* f_4470 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4470,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4469,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4465,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 302  test */
t5=((C_word*)t0)[2];
f_3527(t5,t4,t2,lf[75]);}
else{
t3=((C_word*)t0)[7];
f_4331(2,t3,C_SCHEME_FALSE);}}

/* k4463 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4352(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 302  test */
t2=((C_word*)t0)[3];
f_3527(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[46]);}}

/* k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4451,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
t2=((C_word*)t0)[7];
f_4331(2,t2,C_SCHEME_FALSE);}}

/* f_4451 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4451,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4450,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 305  test */
t5=((C_word*)t0)[2];
f_3527(t5,t3,t4,lf[55]);}
else{
t3=((C_word*)t0)[7];
f_4331(2,t3,C_SCHEME_FALSE);}}

/* k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4373(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 306  test */
t5=((C_word*)t0)[2];
f_3527(t5,t3,t4,lf[74]);}}

/* k4436 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4373(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 307  test */
t4=((C_word*)t0)[2];
f_3527(t4,t2,t3,lf[73]);}}

/* k4428 in k4436 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4373(t2,(C_word)C_i_not(t1));}

/* k4371 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_4373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4373,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4407,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 308  any */
t5=C_retrieve(lf[31]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_4331(2,t2,C_SCHEME_FALSE);}}

/* a4408 in k4371 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4409,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
t3=C_retrieve(lf[72]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k4405 in k4371 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4407,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4331(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 309  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[70],lf[71],((C_word*)t0)[2]);}}

/* k4380 in k4405 in k4371 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4399,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* f_4399 in k4380 in k4405 in k4371 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4399,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4396 in k4380 in k4405 in k4371 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4390,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[68],t2);}

/* f_4390 in k4396 in k4380 in k4405 in k4371 in k4368 in k4448 in k4350 in k4467 in k4476 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4390,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* k4329 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 313  walk-generic */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5104(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* f_4315 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4315,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k4280 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
t2=(C_word)C_i_caddr(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 294  check-signature */
t4=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k4286 in k4280 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 295  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[7],lf[65],((C_word*)t0)[2]);}

/* k4289 in k4286 in k4280 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4291,2,t0,t1);}
t2=f_3563(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4310,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* f_4310 in k4289 in k4286 in k4280 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4310,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k4307 in k4289 in k4286 in k4280 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 297  inline-lambda-bindings */
t3=C_retrieve(lf[64]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4299 in k4289 in k4286 in k4280 in k4277 in k4268 in k4924 in k4256 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 297  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3664(3,t2,((C_word*)t0)[2],t1);}

/* k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 250  decompose-lambda-list */
t3=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 265  test */
t4=((C_word*)t0)[11];
f_3527(t4,t2,t3,lf[59]);}}

/* k4177 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4184,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 266  decompose-lambda-list */
t3=C_retrieve(lf[61]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
/* optimizer.scm: 278  walk-generic */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5104(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a4183 in k4177 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4184,5,t0,t1,t2,t3,t4);}
t5=f_3563(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4191,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 270  debugging */
t7=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[7],lf[62],t4);}

/* k4189 in a4183 in k4177 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4227,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 275  build-lambda-list */
t6=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4225 in k4189 in a4183 in k4177 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4227,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4211,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 277  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3664(3,t6,t4,t5);}

/* k4209 in k4225 in k4189 in a4183 in k4177 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4211,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4203,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[54],((C_word*)t0)[2],t2);}

/* f_4203 in k4209 in k4225 in k4189 in a4183 in k4177 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4203,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4085,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4091,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4103,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4102 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4103,4,t0,t1,t2,t3);}
t4=f_3563(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 255  debugging */
t6=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[7],lf[60],t2);}

/* k4108 in a4102 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4146,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 259  test */
t7=((C_word*)t0)[2];
f_3527(t7,t5,t6,lf[59]);}
else{
t6=t5;
f_4153(2,t6,C_SCHEME_FALSE);}}

/* k4151 in k4108 in a4102 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 260  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[7],lf[58],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 262  build-lambda-list */
t2=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4154 in k4151 in k4108 in a4102 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 261  build-lambda-list */
t3=C_retrieve(lf[57]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4144 in k4108 in a4102 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4146,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4130,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 264  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3664(3,t6,t4,t5);}

/* k4128 in k4144 in k4108 in a4102 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4130,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4122,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[54],((C_word*)t0)[2],t2);}

/* f_4122 in k4128 in k4144 in k4108 in a4102 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4122,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a4090 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 253  partition */
t3=C_retrieve(lf[56]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a4096 in a4090 in a4084 in k4078 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4097,3,t0,t1,t2);}
/* optimizer.scm: 253  test */
t3=((C_word*)t0)[2];
f_3527(t3,t1,t2,lf[55]);}

/* k4015 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_4020(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 240  test */
t4=((C_word*)t0)[3];
f_3527(t4,t3,((C_word*)t0)[2],lf[53]);}}

/* k4047 in k4015 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4020(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 241  test */
t3=((C_word*)t0)[3];
f_3527(t3,t2,((C_word*)t0)[2],lf[52]);}}

/* k4056 in k4047 in k4015 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4065,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 241  test */
t3=((C_word*)t0)[3];
f_3527(t3,t2,((C_word*)t0)[2],lf[51]);}
else{
t2=((C_word*)t0)[4];
f_4020(t2,C_SCHEME_FALSE);}}

/* k4063 in k4056 in k4047 in k4015 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4020(t2,(C_word)C_i_not(t1));}

/* k4018 in k4015 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_4020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4020,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3563(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 244  walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3664(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k4039 in k4018 in k4015 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4042,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[11],((C_word*)t0)[2],t1);}

/* f_4042 in k4039 in k4018 in k4015 in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4042,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* replace in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3936(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3936,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 225  test */
t4=((C_word*)t0)[4];
f_3527(t4,t3,t2,lf[50]);}

/* k3938 in replace in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
if(C_truep(t1)){
/* replace318 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3936(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 226  test */
t3=((C_word*)t0)[5];
f_3527(t3,t2,((C_word*)t0)[4],lf[49]);}}

/* k3950 in k3938 in replace in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
if(C_truep(t1)){
t2=f_3563(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 228  debugging */
t4=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[7],lf[47],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_3981(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_3563(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_3981(t8,t7);}}}

/* k3979 in k3950 in k3938 in replace in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 235  varnode */
t2=C_retrieve(lf[48]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3956 in k3950 in k3938 in replace in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3973,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 229  test */
t4=((C_word*)t0)[3];
f_3527(t4,t3,((C_word*)t0)[2],lf[46]);}

/* k3971 in k3956 in k3950 in k3938 in replace in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3974,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_3974 in k3971 in k3956 in k3950 in k3938 in replace in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3974,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3967 in k3956 in k3950 in k3938 in replace in k3919 in k3916 in k3913 in walk1 in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(t1);
/* optimizer.scm: 229  qnode */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3664(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3664,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[33])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[10])[1];
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 179  walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3911(t5,t4,t2);}}

/* k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3905,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f_3905 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3905,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3900,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* f_3900 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3900,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3687,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(t1,lf[10]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 184  constant-node? */
t6=((C_word*)t0)[5];
f_3533(3,t6,t4,t5);}
else{
t4=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[6],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3895,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t2;
f_3687(2,t5,((C_word*)t0)[6]);}}}

/* f_3895 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3895,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=(C_word)C_eqp(lf[9],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3882,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)t0)[10];
f_3687(2,t3,((C_word*)t0)[9]);}}

/* f_3882 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3882,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3877,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3855,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3869,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3869 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3869,3,t0,t1,t2);}
/* ##sys#get */
t3=C_retrieve(lf[44]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[45]);}

/* k3853 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 196  test */
t3=((C_word*)t0)[3];
f_3527(t3,t2,((C_word*)t0)[2],lf[43]);}
else{
t2=((C_word*)t0)[5];
f_3748(2,t2,C_SCHEME_FALSE);}}

/* k3859 in k3853 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 197  every */
t3=C_retrieve(lf[42]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_3748(2,t2,C_SCHEME_FALSE);}}

/* k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[8];
f_3687(2,t2,((C_word*)t0)[7]);}}

/* a3835 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3836,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3848,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 198  node-value */
f_3548(t3,t2);}

/* k3846 in a3835 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[26],t2));}

/* k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3834,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3759,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[19]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3759,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3765,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3782,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[41]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a3781 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3819 in a3781 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3820r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3820r(t0,t1,t2);}}

static void C_ccall f_3820r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3826,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k271277 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3825 in a3819 in a3781 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3826,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3787 in a3781 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 205  eval */
t3=C_retrieve(lf[40]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3790 in a3787 in a3781 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3795,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 206  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[7],lf[39],((C_word*)t0)[2]);}

/* k3793 in k3790 in a3787 in a3781 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3795,2,t0,t1);}
t2=f_3563(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 211  qnode */
t5=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3816 in k3793 in k3790 in a3787 in a3781 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3806,tmp=(C_word)a,a+=2,tmp);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[15],lf[37],t2);}

/* f_3806 in k3816 in k3793 in k3790 in a3787 in a3781 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3806,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,t4));}

/* a3764 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3765,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* k271277 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3770 in a3764 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3775(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_3775(t4,t3);}}

/* k3773 in a3770 in a3764 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3775,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 203  lset-adjoin */
t3=C_retrieve(lf[34]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[35]+1),C_retrieve(lf[33]),((C_word*)t0)[2]);}

/* k3777 in k3773 in a3770 in a3764 in a3758 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1 /* (set! broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k3755 in k3832 in k3746 in k3875 in k3888 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3694 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=f_3563(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3713,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 187  node-value */
f_3548(t5,t6);}
else{
t2=((C_word*)t0)[4];
f_3687(2,t2,((C_word*)t0)[2]);}}

/* k3711 in k3694 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[4]):(C_word)C_i_caddr(((C_word*)t0)[4]));
/* optimizer.scm: 187  walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3664(3,t3,((C_word*)t0)[2],t2);}

/* k3685 in k3682 in k3679 in k3676 in walk in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 177  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3567(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3567,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3657,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3658,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3658 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3658,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3655 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 158  ##sys#hash-table-ref */
t2=C_retrieve(lf[32]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],*((C_word*)lf[22]+1),t1);}

/* k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3582,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 159  any */
t4=C_retrieve(lf[31]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}
else{
t3=t2;
f_3574(2,t3,C_SCHEME_FALSE);}}

/* a3581 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3582,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3592,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 161  match-node */
t6=C_retrieve(lf[30]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3590 in a3581 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3639,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3641,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3640 in k3590 in a3581 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3641,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k3637 in k3590 in a3581 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3596 in k3590 in a3581 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3598,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3604,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 164  caar */
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3602 in k3596 in k3590 in a3581 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3604,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_3610(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3631,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 168  alist-cons */
t5=C_retrieve(lf[27]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k3629 in k3602 in k3596 in k3590 in a3581 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3610(t3,t2);}

/* k3608 in k3602 in k3596 in k3590 in a3581 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3563(((C_word*)t0)[5]);
/* optimizer.scm: 170  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3567(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3572 in k3569 in simplify in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static C_word C_fcall f_3563(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* node-value in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3548(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3548,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3557,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3557 in node-value in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3557,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3554 in node-value in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* constant-node? in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3533,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3541,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3542,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_3542 in constant-node? in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3542,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3539 in constant-node? in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(lf[26],t1));}

/* test in ##compiler#perform-high-level-optimizations in k3519 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3527(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3527,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 152  get */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3271,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3274,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3292,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 84   debugging */
t9=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,lf[20],lf[21]);}

/* k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 85   call-with-current-continuation */
t4=*((C_word*)lf[19]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3336,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3339,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3351,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 120  scan */
t9=((C_word*)t6)[1];
f_3351(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3351(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3351,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3355,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3510,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3510 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3510,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3505,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3505 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3505,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3500,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3500 in k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3500,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3359 in k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[8]))){
t5=t4;
f_3376(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_memq(t3,((C_word*)((C_word*)t0)[7])[1]);
t6=t4;
f_3376(t6,(C_word)C_i_not(t5));}}
else{
t3=(C_word)C_eqp(t1,lf[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t3)){
t5=t4;
f_3403(t5,t3);}
else{
t5=(C_word)C_eqp(t1,lf[17]);
t6=t4;
f_3403(t6,(C_truep(t5)?t5:(C_word)C_eqp(t1,lf[18])));}}}

/* k3401 in k3359 in k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3403,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 102  scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3351(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3422,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 106  scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3351(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[13]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[14]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[15]);
if(C_truep(t5)){
/* optimizer.scm: 111  return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[16]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))){
t9=t8;
f_3467(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 115  mark */
t9=((C_word*)t0)[3];
f_3274(3,t9,t8,t7);}}
else{
/* optimizer.scm: 118  scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3339(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k3465 in k3401 in k3359 in k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 116  scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3351(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3420 in k3401 in k3359 in k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3422,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3433,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 107  append */
t4=*((C_word*)lf[12]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3431 in k3420 in k3401 in k3359 in k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 107  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3351(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3404 in k3401 in k3359 in k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 103  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3374 in k3359 in k3356 in k3353 in scan in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_fcall f_3339(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3339,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3345,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3344 in scan-each in a3335 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3345,3,t0,t1,t2);}
/* optimizer.scm: 89   scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3351(t3,t1,t2,((C_word*)t0)[2]);}

/* k3293 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 121  debugging */
t3=C_retrieve(lf[6]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[7],lf[8],((C_word*)((C_word*)t0)[2])[1]);}

/* k3296 in k3293 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3303,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a3302 in k3296 in k3293 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3303,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[4]);}

/* f_3308 in a3302 in k3296 in k3293 in k3290 in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3308r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3308r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3308r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3312(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3312(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[3],t4);}}}

/* k3310 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
t2=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* mark in ##compiler#scan-toplevel-assignments in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3274,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[1004] = {
{"topleveloptimizer.scm",(void*)C_optimizer_toplevel},
{"f_3254optimizer.scm",(void*)f_3254},
{"f_3257optimizer.scm",(void*)f_3257},
{"f_3260optimizer.scm",(void*)f_3260},
{"f_3263optimizer.scm",(void*)f_3263},
{"f_3266optimizer.scm",(void*)f_3266},
{"f_3269optimizer.scm",(void*)f_3269},
{"f_3521optimizer.scm",(void*)f_3521},
{"f_13075optimizer.scm",(void*)f_13075},
{"f_13083optimizer.scm",(void*)f_13083},
{"f_13088optimizer.scm",(void*)f_13088},
{"f_13133optimizer.scm",(void*)f_13133},
{"f_13137optimizer.scm",(void*)f_13137},
{"f_13098optimizer.scm",(void*)f_13098},
{"f_13122optimizer.scm",(void*)f_13122},
{"f_13107optimizer.scm",(void*)f_13107},
{"f_5804optimizer.scm",(void*)f_5804},
{"f_12026optimizer.scm",(void*)f_12026},
{"f_12072optimizer.scm",(void*)f_12072},
{"f_12060optimizer.scm",(void*)f_12060},
{"f_12055optimizer.scm",(void*)f_12055},
{"f_12047optimizer.scm",(void*)f_12047},
{"f_12174optimizer.scm",(void*)f_12174},
{"f_12184optimizer.scm",(void*)f_12184},
{"f_12483optimizer.scm",(void*)f_12483},
{"f_12188optimizer.scm",(void*)f_12188},
{"f_12478optimizer.scm",(void*)f_12478},
{"f_12191optimizer.scm",(void*)f_12191},
{"f_12473optimizer.scm",(void*)f_12473},
{"f_12194optimizer.scm",(void*)f_12194},
{"f_12464optimizer.scm",(void*)f_12464},
{"f_12212optimizer.scm",(void*)f_12212},
{"f_12459optimizer.scm",(void*)f_12459},
{"f_12215optimizer.scm",(void*)f_12215},
{"f_12454optimizer.scm",(void*)f_12454},
{"f_12218optimizer.scm",(void*)f_12218},
{"f_12248optimizer.scm",(void*)f_12248},
{"f_12277optimizer.scm",(void*)f_12277},
{"f_12437optimizer.scm",(void*)f_12437},
{"f_12281optimizer.scm",(void*)f_12281},
{"f_12432optimizer.scm",(void*)f_12432},
{"f_12284optimizer.scm",(void*)f_12284},
{"f_12427optimizer.scm",(void*)f_12427},
{"f_12287optimizer.scm",(void*)f_12287},
{"f_12418optimizer.scm",(void*)f_12418},
{"f_12410optimizer.scm",(void*)f_12410},
{"f_12405optimizer.scm",(void*)f_12405},
{"f_12397optimizer.scm",(void*)f_12397},
{"f_12392optimizer.scm",(void*)f_12392},
{"f_12293optimizer.scm",(void*)f_12293},
{"f_12346optimizer.scm",(void*)f_12346},
{"f_12336optimizer.scm",(void*)f_12336},
{"f_12344optimizer.scm",(void*)f_12344},
{"f_12321optimizer.scm",(void*)f_12321},
{"f_12316optimizer.scm",(void*)f_12316},
{"f_12533optimizer.scm",(void*)f_12533},
{"f_12546optimizer.scm",(void*)f_12546},
{"f_12588optimizer.scm",(void*)f_12588},
{"f_12572optimizer.scm",(void*)f_12572},
{"f_12576optimizer.scm",(void*)f_12576},
{"f_12563optimizer.scm",(void*)f_12563},
{"f_12564optimizer.scm",(void*)f_12564},
{"f_12754optimizer.scm",(void*)f_12754},
{"f_12767optimizer.scm",(void*)f_12767},
{"f_12773optimizer.scm",(void*)f_12773},
{"f_12825optimizer.scm",(void*)f_12825},
{"f_12817optimizer.scm",(void*)f_12817},
{"f_12801optimizer.scm",(void*)f_12801},
{"f_12805optimizer.scm",(void*)f_12805},
{"f_12809optimizer.scm",(void*)f_12809},
{"f_12793optimizer.scm",(void*)f_12793},
{"f_5807optimizer.scm",(void*)f_5807},
{"f_11667optimizer.scm",(void*)f_11667},
{"f_11689optimizer.scm",(void*)f_11689},
{"f_11769optimizer.scm",(void*)f_11769},
{"f_11727optimizer.scm",(void*)f_11727},
{"f_11761optimizer.scm",(void*)f_11761},
{"f_11765optimizer.scm",(void*)f_11765},
{"f_11753optimizer.scm",(void*)f_11753},
{"f_11744optimizer.scm",(void*)f_11744},
{"f_11748optimizer.scm",(void*)f_11748},
{"f_11736optimizer.scm",(void*)f_11736},
{"f_11725optimizer.scm",(void*)f_11725},
{"f_11717optimizer.scm",(void*)f_11717},
{"f_11712optimizer.scm",(void*)f_11712},
{"f_11704optimizer.scm",(void*)f_11704},
{"f_11863optimizer.scm",(void*)f_11863},
{"f_11883optimizer.scm",(void*)f_11883},
{"f_11892optimizer.scm",(void*)f_11892},
{"f_11887optimizer.scm",(void*)f_11887},
{"f_11875optimizer.scm",(void*)f_11875},
{"f_5810optimizer.scm",(void*)f_5810},
{"f_6170optimizer.scm",(void*)f_6170},
{"f_9803optimizer.scm",(void*)f_9803},
{"f_11546optimizer.scm",(void*)f_11546},
{"f_11549optimizer.scm",(void*)f_11549},
{"f_11552optimizer.scm",(void*)f_11552},
{"f_11555optimizer.scm",(void*)f_11555},
{"f_11558optimizer.scm",(void*)f_11558},
{"f_11561optimizer.scm",(void*)f_11561},
{"f_11638optimizer.scm",(void*)f_11638},
{"f_11564optimizer.scm",(void*)f_11564},
{"f_11567optimizer.scm",(void*)f_11567},
{"f_11570optimizer.scm",(void*)f_11570},
{"f_11632optimizer.scm",(void*)f_11632},
{"f_11573optimizer.scm",(void*)f_11573},
{"f_11576optimizer.scm",(void*)f_11576},
{"f_11629optimizer.scm",(void*)f_11629},
{"f_10458optimizer.scm",(void*)f_10458},
{"f_10476optimizer.scm",(void*)f_10476},
{"f_10482optimizer.scm",(void*)f_10482},
{"f_10462optimizer.scm",(void*)f_10462},
{"f_11579optimizer.scm",(void*)f_11579},
{"f_11621optimizer.scm",(void*)f_11621},
{"f_11619optimizer.scm",(void*)f_11619},
{"f_11582optimizer.scm",(void*)f_11582},
{"f_11585optimizer.scm",(void*)f_11585},
{"f_11588optimizer.scm",(void*)f_11588},
{"f_11612optimizer.scm",(void*)f_11612},
{"f_11591optimizer.scm",(void*)f_11591},
{"f_11594optimizer.scm",(void*)f_11594},
{"f_11597optimizer.scm",(void*)f_11597},
{"f_11600optimizer.scm",(void*)f_11600},
{"f_11603optimizer.scm",(void*)f_11603},
{"f_11606optimizer.scm",(void*)f_11606},
{"f_11374optimizer.scm",(void*)f_11374},
{"f_11380optimizer.scm",(void*)f_11380},
{"f_11539optimizer.scm",(void*)f_11539},
{"f_11384optimizer.scm",(void*)f_11384},
{"f_11534optimizer.scm",(void*)f_11534},
{"f_11387optimizer.scm",(void*)f_11387},
{"f_11529optimizer.scm",(void*)f_11529},
{"f_11390optimizer.scm",(void*)f_11390},
{"f_11521optimizer.scm",(void*)f_11521},
{"f_11520optimizer.scm",(void*)f_11520},
{"f_11497optimizer.scm",(void*)f_11497},
{"f_11506optimizer.scm",(void*)f_11506},
{"f_11509optimizer.scm",(void*)f_11509},
{"f_11484optimizer.scm",(void*)f_11484},
{"f_11483optimizer.scm",(void*)f_11483},
{"f_11399optimizer.scm",(void*)f_11399},
{"f_11404optimizer.scm",(void*)f_11404},
{"f_11445optimizer.scm",(void*)f_11445},
{"f_11442optimizer.scm",(void*)f_11442},
{"f_11427optimizer.scm",(void*)f_11427},
{"f_11438optimizer.scm",(void*)f_11438},
{"f_11434optimizer.scm",(void*)f_11434},
{"f_11257optimizer.scm",(void*)f_11257},
{"f_11263optimizer.scm",(void*)f_11263},
{"f_11368optimizer.scm",(void*)f_11368},
{"f_11267optimizer.scm",(void*)f_11267},
{"f_11363optimizer.scm",(void*)f_11363},
{"f_11270optimizer.scm",(void*)f_11270},
{"f_11358optimizer.scm",(void*)f_11358},
{"f_11273optimizer.scm",(void*)f_11273},
{"f_11350optimizer.scm",(void*)f_11350},
{"f_11349optimizer.scm",(void*)f_11349},
{"f_11341optimizer.scm",(void*)f_11341},
{"f_11340optimizer.scm",(void*)f_11340},
{"f_11324optimizer.scm",(void*)f_11324},
{"f_11320optimizer.scm",(void*)f_11320},
{"f_11285optimizer.scm",(void*)f_11285},
{"f_11293optimizer.scm",(void*)f_11293},
{"f_11292optimizer.scm",(void*)f_11292},
{"f_10952optimizer.scm",(void*)f_10952},
{"f_11108optimizer.scm",(void*)f_11108},
{"f_11107optimizer.scm",(void*)f_11107},
{"f_10966optimizer.scm",(void*)f_10966},
{"f_10973optimizer.scm",(void*)f_10973},
{"f_10976optimizer.scm",(void*)f_10976},
{"f_11095optimizer.scm",(void*)f_11095},
{"f_11094optimizer.scm",(void*)f_11094},
{"f_10985optimizer.scm",(void*)f_10985},
{"f_10992optimizer.scm",(void*)f_10992},
{"f_10995optimizer.scm",(void*)f_10995},
{"f_11082optimizer.scm",(void*)f_11082},
{"f_11081optimizer.scm",(void*)f_11081},
{"f_11132optimizer.scm",(void*)f_11132},
{"f_11251optimizer.scm",(void*)f_11251},
{"f_11136optimizer.scm",(void*)f_11136},
{"f_11246optimizer.scm",(void*)f_11246},
{"f_11139optimizer.scm",(void*)f_11139},
{"f_11241optimizer.scm",(void*)f_11241},
{"f_11142optimizer.scm",(void*)f_11142},
{"f_11218optimizer.scm",(void*)f_11218},
{"f_11237optimizer.scm",(void*)f_11237},
{"f_11233optimizer.scm",(void*)f_11233},
{"f_11199optimizer.scm",(void*)f_11199},
{"f_11188optimizer.scm",(void*)f_11188},
{"f_11175optimizer.scm",(void*)f_11175},
{"f_11158optimizer.scm",(void*)f_11158},
{"f_11151optimizer.scm",(void*)f_11151},
{"f_11117optimizer.scm",(void*)f_11117},
{"f_10998optimizer.scm",(void*)f_10998},
{"f_11073optimizer.scm",(void*)f_11073},
{"f_11061optimizer.scm",(void*)f_11061},
{"f_11057optimizer.scm",(void*)f_11057},
{"f_11049optimizer.scm",(void*)f_11049},
{"f_11043optimizer.scm",(void*)f_11043},
{"f_11044optimizer.scm",(void*)f_11044},
{"f_11035optimizer.scm",(void*)f_11035},
{"f_11027optimizer.scm",(void*)f_11027},
{"f_11018optimizer.scm",(void*)f_11018},
{"f_11010optimizer.scm",(void*)f_11010},
{"f_10964optimizer.scm",(void*)f_10964},
{"f_10736optimizer.scm",(void*)f_10736},
{"f_10938optimizer.scm",(void*)f_10938},
{"f_10816optimizer.scm",(void*)f_10816},
{"f_10893optimizer.scm",(void*)f_10893},
{"f_10898optimizer.scm",(void*)f_10898},
{"f_10936optimizer.scm",(void*)f_10936},
{"f_10745optimizer.scm",(void*)f_10745},
{"f_10809optimizer.scm",(void*)f_10809},
{"f_10749optimizer.scm",(void*)f_10749},
{"f_10804optimizer.scm",(void*)f_10804},
{"f_10752optimizer.scm",(void*)f_10752},
{"f_10799optimizer.scm",(void*)f_10799},
{"f_10755optimizer.scm",(void*)f_10755},
{"f_10783optimizer.scm",(void*)f_10783},
{"f_10788optimizer.scm",(void*)f_10788},
{"f_10765optimizer.scm",(void*)f_10765},
{"f_10743optimizer.scm",(void*)f_10743},
{"f_10928optimizer.scm",(void*)f_10928},
{"f_10914optimizer.scm",(void*)f_10914},
{"f_10912optimizer.scm",(void*)f_10912},
{"f_10818optimizer.scm",(void*)f_10818},
{"f_10886optimizer.scm",(void*)f_10886},
{"f_10884optimizer.scm",(void*)f_10884},
{"f_10872optimizer.scm",(void*)f_10872},
{"f_10838optimizer.scm",(void*)f_10838},
{"f_10862optimizer.scm",(void*)f_10862},
{"f_10860optimizer.scm",(void*)f_10860},
{"f_10856optimizer.scm",(void*)f_10856},
{"f_10848optimizer.scm",(void*)f_10848},
{"f_10492optimizer.scm",(void*)f_10492},
{"f_10498optimizer.scm",(void*)f_10498},
{"f_10730optimizer.scm",(void*)f_10730},
{"f_10502optimizer.scm",(void*)f_10502},
{"f_10725optimizer.scm",(void*)f_10725},
{"f_10505optimizer.scm",(void*)f_10505},
{"f_10720optimizer.scm",(void*)f_10720},
{"f_10508optimizer.scm",(void*)f_10508},
{"f_10517optimizer.scm",(void*)f_10517},
{"f_10694optimizer.scm",(void*)f_10694},
{"f_10614optimizer.scm",(void*)f_10614},
{"f_10685optimizer.scm",(void*)f_10685},
{"f_10684optimizer.scm",(void*)f_10684},
{"f_10676optimizer.scm",(void*)f_10676},
{"f_10675optimizer.scm",(void*)f_10675},
{"f_10630optimizer.scm",(void*)f_10630},
{"f_10660optimizer.scm",(void*)f_10660},
{"f_10664optimizer.scm",(void*)f_10664},
{"f_10650optimizer.scm",(void*)f_10650},
{"f_10603optimizer.scm",(void*)f_10603},
{"f_10608optimizer.scm",(void*)f_10608},
{"f_10579optimizer.scm",(void*)f_10579},
{"f_10591optimizer.scm",(void*)f_10591},
{"f_10528optimizer.scm",(void*)f_10528},
{"f_10549optimizer.scm",(void*)f_10549},
{"f_10546optimizer.scm",(void*)f_10546},
{"f_10496optimizer.scm",(void*)f_10496},
{"f_10233optimizer.scm",(void*)f_10233},
{"f_10239optimizer.scm",(void*)f_10239},
{"f_10396optimizer.scm",(void*)f_10396},
{"f_10243optimizer.scm",(void*)f_10243},
{"f_10391optimizer.scm",(void*)f_10391},
{"f_10246optimizer.scm",(void*)f_10246},
{"f_10386optimizer.scm",(void*)f_10386},
{"f_10249optimizer.scm",(void*)f_10249},
{"f_10258optimizer.scm",(void*)f_10258},
{"f_10360optimizer.scm",(void*)f_10360},
{"f_10351optimizer.scm",(void*)f_10351},
{"f_10317optimizer.scm",(void*)f_10317},
{"f_10326optimizer.scm",(void*)f_10326},
{"f_10338optimizer.scm",(void*)f_10338},
{"f_10269optimizer.scm",(void*)f_10269},
{"f_10290optimizer.scm",(void*)f_10290},
{"f_10287optimizer.scm",(void*)f_10287},
{"f_10237optimizer.scm",(void*)f_10237},
{"f_10134optimizer.scm",(void*)f_10134},
{"f_10140optimizer.scm",(void*)f_10140},
{"f_10184optimizer.scm",(void*)f_10184},
{"f_10189optimizer.scm",(void*)f_10189},
{"f_10196optimizer.scm",(void*)f_10196},
{"f_10223optimizer.scm",(void*)f_10223},
{"f_10219optimizer.scm",(void*)f_10219},
{"f_10211optimizer.scm",(void*)f_10211},
{"f_10209optimizer.scm",(void*)f_10209},
{"f_10174optimizer.scm",(void*)f_10174},
{"f_10152optimizer.scm",(void*)f_10152},
{"f_10159optimizer.scm",(void*)f_10159},
{"f_9912optimizer.scm",(void*)f_9912},
{"f_10081optimizer.scm",(void*)f_10081},
{"f_10128optimizer.scm",(void*)f_10128},
{"f_10127optimizer.scm",(void*)f_10127},
{"f_10106optimizer.scm",(void*)f_10106},
{"f_10119optimizer.scm",(void*)f_10119},
{"f_10118optimizer.scm",(void*)f_10118},
{"f_10096optimizer.scm",(void*)f_10096},
{"f_10100optimizer.scm",(void*)f_10100},
{"f_10079optimizer.scm",(void*)f_10079},
{"f_9915optimizer.scm",(void*)f_9915},
{"f_10072optimizer.scm",(void*)f_10072},
{"f_9919optimizer.scm",(void*)f_9919},
{"f_10067optimizer.scm",(void*)f_10067},
{"f_9922optimizer.scm",(void*)f_9922},
{"f_10062optimizer.scm",(void*)f_10062},
{"f_9925optimizer.scm",(void*)f_9925},
{"f_10054optimizer.scm",(void*)f_10054},
{"f_10037optimizer.scm",(void*)f_10037},
{"f_10049optimizer.scm",(void*)f_10049},
{"f_9983optimizer.scm",(void*)f_9983},
{"f_10007optimizer.scm",(void*)f_10007},
{"f_10001optimizer.scm",(void*)f_10001},
{"f_9965optimizer.scm",(void*)f_9965},
{"f_9940optimizer.scm",(void*)f_9940},
{"f_9943optimizer.scm",(void*)f_9943},
{"f_9948optimizer.scm",(void*)f_9948},
{"f_9806optimizer.scm",(void*)f_9806},
{"f_9812optimizer.scm",(void*)f_9812},
{"f_9898optimizer.scm",(void*)f_9898},
{"f_9893optimizer.scm",(void*)f_9893},
{"f_9843optimizer.scm",(void*)f_9843},
{"f_9847optimizer.scm",(void*)f_9847},
{"f_9851optimizer.scm",(void*)f_9851},
{"f_9810optimizer.scm",(void*)f_9810},
{"f_8538optimizer.scm",(void*)f_8538},
{"f_9798optimizer.scm",(void*)f_9798},
{"f_9801optimizer.scm",(void*)f_9801},
{"f_8541optimizer.scm",(void*)f_8541},
{"f_8712optimizer.scm",(void*)f_8712},
{"f_8545optimizer.scm",(void*)f_8545},
{"f_8707optimizer.scm",(void*)f_8707},
{"f_8548optimizer.scm",(void*)f_8548},
{"f_8702optimizer.scm",(void*)f_8702},
{"f_8551optimizer.scm",(void*)f_8551},
{"f_8697optimizer.scm",(void*)f_8697},
{"f_8677optimizer.scm",(void*)f_8677},
{"f_8651optimizer.scm",(void*)f_8651},
{"f_8597optimizer.scm",(void*)f_8597},
{"f_8603optimizer.scm",(void*)f_8603},
{"f_8609optimizer.scm",(void*)f_8609},
{"f_8566optimizer.scm",(void*)f_8566},
{"f_8718optimizer.scm",(void*)f_8718},
{"f_9163optimizer.scm",(void*)f_9163},
{"f_9170optimizer.scm",(void*)f_9170},
{"f_8721optimizer.scm",(void*)f_8721},
{"f_9150optimizer.scm",(void*)f_9150},
{"f_8725optimizer.scm",(void*)f_8725},
{"f_9145optimizer.scm",(void*)f_9145},
{"f_8728optimizer.scm",(void*)f_8728},
{"f_9140optimizer.scm",(void*)f_9140},
{"f_8731optimizer.scm",(void*)f_8731},
{"f_9135optimizer.scm",(void*)f_9135},
{"f_9111optimizer.scm",(void*)f_9111},
{"f_9122optimizer.scm",(void*)f_9122},
{"f_9078optimizer.scm",(void*)f_9078},
{"f_9044optimizer.scm",(void*)f_9044},
{"f_9043optimizer.scm",(void*)f_9043},
{"f_9035optimizer.scm",(void*)f_9035},
{"f_9034optimizer.scm",(void*)f_9034},
{"f_9023optimizer.scm",(void*)f_9023},
{"f_9022optimizer.scm",(void*)f_9022},
{"f_9014optimizer.scm",(void*)f_9014},
{"f_9013optimizer.scm",(void*)f_9013},
{"f_8997optimizer.scm",(void*)f_8997},
{"f_8969optimizer.scm",(void*)f_8969},
{"f_8974optimizer.scm",(void*)f_8974},
{"f_8916optimizer.scm",(void*)f_8916},
{"f_8922optimizer.scm",(void*)f_8922},
{"f_8927optimizer.scm",(void*)f_8927},
{"f_8875optimizer.scm",(void*)f_8875},
{"f_8881optimizer.scm",(void*)f_8881},
{"f_8886optimizer.scm",(void*)f_8886},
{"f_8859optimizer.scm",(void*)f_8859},
{"f_8855optimizer.scm",(void*)f_8855},
{"f_8825optimizer.scm",(void*)f_8825},
{"f_8788optimizer.scm",(void*)f_8788},
{"f_8804optimizer.scm",(void*)f_8804},
{"f_8770optimizer.scm",(void*)f_8770},
{"f_9172optimizer.scm",(void*)f_9172},
{"f_9788optimizer.scm",(void*)f_9788},
{"f_9786optimizer.scm",(void*)f_9786},
{"f_9176optimizer.scm",(void*)f_9176},
{"f_9772optimizer.scm",(void*)f_9772},
{"f_9180optimizer.scm",(void*)f_9180},
{"f_9186optimizer.scm",(void*)f_9186},
{"f_9192optimizer.scm",(void*)f_9192},
{"f_9198optimizer.scm",(void*)f_9198},
{"f_9201optimizer.scm",(void*)f_9201},
{"f_9207optimizer.scm",(void*)f_9207},
{"f_9736optimizer.scm",(void*)f_9736},
{"f_9735optimizer.scm",(void*)f_9735},
{"f_9446optimizer.scm",(void*)f_9446},
{"f_9727optimizer.scm",(void*)f_9727},
{"f_9450optimizer.scm",(void*)f_9450},
{"f_9722optimizer.scm",(void*)f_9722},
{"f_9453optimizer.scm",(void*)f_9453},
{"f_9717optimizer.scm",(void*)f_9717},
{"f_9456optimizer.scm",(void*)f_9456},
{"f_9700optimizer.scm",(void*)f_9700},
{"f_9703optimizer.scm",(void*)f_9703},
{"f_9674optimizer.scm",(void*)f_9674},
{"f_9471optimizer.scm",(void*)f_9471},
{"f_9669optimizer.scm",(void*)f_9669},
{"f_9474optimizer.scm",(void*)f_9474},
{"f_9664optimizer.scm",(void*)f_9664},
{"f_9663optimizer.scm",(void*)f_9663},
{"f_9638optimizer.scm",(void*)f_9638},
{"f_9641optimizer.scm",(void*)f_9641},
{"f_9490optimizer.scm",(void*)f_9490},
{"f_9614optimizer.scm",(void*)f_9614},
{"f_9613optimizer.scm",(void*)f_9613},
{"f_9545optimizer.scm",(void*)f_9545},
{"f_9548optimizer.scm",(void*)f_9548},
{"f_9591optimizer.scm",(void*)f_9591},
{"f_9590optimizer.scm",(void*)f_9590},
{"f_9582optimizer.scm",(void*)f_9582},
{"f_9551optimizer.scm",(void*)f_9551},
{"f_9574optimizer.scm",(void*)f_9574},
{"f_9565optimizer.scm",(void*)f_9565},
{"f_9554optimizer.scm",(void*)f_9554},
{"f_9499optimizer.scm",(void*)f_9499},
{"f_9502optimizer.scm",(void*)f_9502},
{"f_9505optimizer.scm",(void*)f_9505},
{"f_9210optimizer.scm",(void*)f_9210},
{"f_9428optimizer.scm",(void*)f_9428},
{"f_9426optimizer.scm",(void*)f_9426},
{"f_9357optimizer.scm",(void*)f_9357},
{"f_9418optimizer.scm",(void*)f_9418},
{"f_9364optimizer.scm",(void*)f_9364},
{"f_9367optimizer.scm",(void*)f_9367},
{"f_9391optimizer.scm",(void*)f_9391},
{"f_9382optimizer.scm",(void*)f_9382},
{"f_9213optimizer.scm",(void*)f_9213},
{"f_9348optimizer.scm",(void*)f_9348},
{"f_9222optimizer.scm",(void*)f_9222},
{"f_9225optimizer.scm",(void*)f_9225},
{"f_9274optimizer.scm",(void*)f_9274},
{"f_9339optimizer.scm",(void*)f_9339},
{"f_9334optimizer.scm",(void*)f_9334},
{"f_9326optimizer.scm",(void*)f_9326},
{"f_9302optimizer.scm",(void*)f_9302},
{"f_9321optimizer.scm",(void*)f_9321},
{"f_9306optimizer.scm",(void*)f_9306},
{"f_9316optimizer.scm",(void*)f_9316},
{"f_9310optimizer.scm",(void*)f_9310},
{"f_9311optimizer.scm",(void*)f_9311},
{"f_9298optimizer.scm",(void*)f_9298},
{"f_9290optimizer.scm",(void*)f_9290},
{"f_9228optimizer.scm",(void*)f_9228},
{"f_9231optimizer.scm",(void*)f_9231},
{"f_9236optimizer.scm",(void*)f_9236},
{"f_9272optimizer.scm",(void*)f_9272},
{"f_9243optimizer.scm",(void*)f_9243},
{"f_9260optimizer.scm",(void*)f_9260},
{"f_9250optimizer.scm",(void*)f_9250},
{"f_9255optimizer.scm",(void*)f_9255},
{"f_9254optimizer.scm",(void*)f_9254},
{"f_6192optimizer.scm",(void*)f_6192},
{"f_8529optimizer.scm",(void*)f_8529},
{"f_8400optimizer.scm",(void*)f_8400},
{"f_8429optimizer.scm",(void*)f_8429},
{"f_8441optimizer.scm",(void*)f_8441},
{"f_8455optimizer.scm",(void*)f_8455},
{"f_8504optimizer.scm",(void*)f_8504},
{"f_6217optimizer.scm",(void*)f_6217},
{"f_8475optimizer.scm",(void*)f_8475},
{"f_8479optimizer.scm",(void*)f_8479},
{"f_8449optimizer.scm",(void*)f_8449},
{"f_8435optimizer.scm",(void*)f_8435},
{"f_8433optimizer.scm",(void*)f_8433},
{"f_8420optimizer.scm",(void*)f_8420},
{"f_8421optimizer.scm",(void*)f_8421},
{"f_8381optimizer.scm",(void*)f_8381},
{"f_8320optimizer.scm",(void*)f_8320},
{"f_8372optimizer.scm",(void*)f_8372},
{"f_8364optimizer.scm",(void*)f_8364},
{"f_8356optimizer.scm",(void*)f_8356},
{"f_8345optimizer.scm",(void*)f_8345},
{"f_8337optimizer.scm",(void*)f_8337},
{"f_8286optimizer.scm",(void*)f_8286},
{"f_8125optimizer.scm",(void*)f_8125},
{"f_8131optimizer.scm",(void*)f_8131},
{"f_8247optimizer.scm",(void*)f_8247},
{"f_8275optimizer.scm",(void*)f_8275},
{"f_8274optimizer.scm",(void*)f_8274},
{"f_8266optimizer.scm",(void*)f_8266},
{"f_8265optimizer.scm",(void*)f_8265},
{"f_8140optimizer.scm",(void*)f_8140},
{"f_8202optimizer.scm",(void*)f_8202},
{"f_8237optimizer.scm",(void*)f_8237},
{"f_8221optimizer.scm",(void*)f_8221},
{"f_8200optimizer.scm",(void*)f_8200},
{"f_8192optimizer.scm",(void*)f_8192},
{"f_8176optimizer.scm",(void*)f_8176},
{"f_8162optimizer.scm",(void*)f_8162},
{"f_8154optimizer.scm",(void*)f_8154},
{"f_8102optimizer.scm",(void*)f_8102},
{"f_8040optimizer.scm",(void*)f_8040},
{"f_8081optimizer.scm",(void*)f_8081},
{"f_8093optimizer.scm",(void*)f_8093},
{"f_8071optimizer.scm",(void*)f_8071},
{"f_8064optimizer.scm",(void*)f_8064},
{"f_8065optimizer.scm",(void*)f_8065},
{"f_8056optimizer.scm",(void*)f_8056},
{"f_8048optimizer.scm",(void*)f_8048},
{"f_8003optimizer.scm",(void*)f_8003},
{"f_7858optimizer.scm",(void*)f_7858},
{"f_7964optimizer.scm",(void*)f_7964},
{"f_7992optimizer.scm",(void*)f_7992},
{"f_7991optimizer.scm",(void*)f_7991},
{"f_7983optimizer.scm",(void*)f_7983},
{"f_7982optimizer.scm",(void*)f_7982},
{"f_7867optimizer.scm",(void*)f_7867},
{"f_7938optimizer.scm",(void*)f_7938},
{"f_7951optimizer.scm",(void*)f_7951},
{"f_7936optimizer.scm",(void*)f_7936},
{"f_7928optimizer.scm",(void*)f_7928},
{"f_7903optimizer.scm",(void*)f_7903},
{"f_7889optimizer.scm",(void*)f_7889},
{"f_7881optimizer.scm",(void*)f_7881},
{"f_7839optimizer.scm",(void*)f_7839},
{"f_7818optimizer.scm",(void*)f_7818},
{"f_7834optimizer.scm",(void*)f_7834},
{"f_7826optimizer.scm",(void*)f_7826},
{"f_7785optimizer.scm",(void*)f_7785},
{"f_7739optimizer.scm",(void*)f_7739},
{"f_7771optimizer.scm",(void*)f_7771},
{"f_7760optimizer.scm",(void*)f_7760},
{"f_7755optimizer.scm",(void*)f_7755},
{"f_7747optimizer.scm",(void*)f_7747},
{"f_7711optimizer.scm",(void*)f_7711},
{"f_7649optimizer.scm",(void*)f_7649},
{"f_7691optimizer.scm",(void*)f_7691},
{"f_7679optimizer.scm",(void*)f_7679},
{"f_7674optimizer.scm",(void*)f_7674},
{"f_7666optimizer.scm",(void*)f_7666},
{"f_7605optimizer.scm",(void*)f_7605},
{"f_7544optimizer.scm",(void*)f_7544},
{"f_7592optimizer.scm",(void*)f_7592},
{"f_7570optimizer.scm",(void*)f_7570},
{"f_7561optimizer.scm",(void*)f_7561},
{"f_7562optimizer.scm",(void*)f_7562},
{"f_7505optimizer.scm",(void*)f_7505},
{"f_7450optimizer.scm",(void*)f_7450},
{"f_7486optimizer.scm",(void*)f_7486},
{"f_7481optimizer.scm",(void*)f_7481},
{"f_7473optimizer.scm",(void*)f_7473},
{"f_7425optimizer.scm",(void*)f_7425},
{"f_7373optimizer.scm",(void*)f_7373},
{"f_7392optimizer.scm",(void*)f_7392},
{"f_7410optimizer.scm",(void*)f_7410},
{"f_7405optimizer.scm",(void*)f_7405},
{"f_7396optimizer.scm",(void*)f_7396},
{"f_7397optimizer.scm",(void*)f_7397},
{"f_7354optimizer.scm",(void*)f_7354},
{"f_7285optimizer.scm",(void*)f_7285},
{"f_7341optimizer.scm",(void*)f_7341},
{"f_7332optimizer.scm",(void*)f_7332},
{"f_7333optimizer.scm",(void*)f_7333},
{"f_7317optimizer.scm",(void*)f_7317},
{"f_7266optimizer.scm",(void*)f_7266},
{"f_7214optimizer.scm",(void*)f_7214},
{"f_7226optimizer.scm",(void*)f_7226},
{"f_7246optimizer.scm",(void*)f_7246},
{"f_7237optimizer.scm",(void*)f_7237},
{"f_7238optimizer.scm",(void*)f_7238},
{"f_7186optimizer.scm",(void*)f_7186},
{"f_7115optimizer.scm",(void*)f_7115},
{"f_7144optimizer.scm",(void*)f_7144},
{"f_7152optimizer.scm",(void*)f_7152},
{"f_7156optimizer.scm",(void*)f_7156},
{"f_7136optimizer.scm",(void*)f_7136},
{"f_7087optimizer.scm",(void*)f_7087},
{"f_6941optimizer.scm",(void*)f_6941},
{"f_6969optimizer.scm",(void*)f_6969},
{"f_6972optimizer.scm",(void*)f_6972},
{"f_7050optimizer.scm",(void*)f_7050},
{"f_6975optimizer.scm",(void*)f_6975},
{"f_6978optimizer.scm",(void*)f_6978},
{"f_7022optimizer.scm",(void*)f_7022},
{"f_7031optimizer.scm",(void*)f_7031},
{"f_7020optimizer.scm",(void*)f_7020},
{"f_7009optimizer.scm",(void*)f_7009},
{"f_7004optimizer.scm",(void*)f_7004},
{"f_6983optimizer.scm",(void*)f_6983},
{"f_6996optimizer.scm",(void*)f_6996},
{"f_6963optimizer.scm",(void*)f_6963},
{"f_6955optimizer.scm",(void*)f_6955},
{"f_6922optimizer.scm",(void*)f_6922},
{"f_6915optimizer.scm",(void*)f_6915},
{"f_6888optimizer.scm",(void*)f_6888},
{"f_6842optimizer.scm",(void*)f_6842},
{"f_6879optimizer.scm",(void*)f_6879},
{"f_6866optimizer.scm",(void*)f_6866},
{"f_6867optimizer.scm",(void*)f_6867},
{"f_6858optimizer.scm",(void*)f_6858},
{"f_6850optimizer.scm",(void*)f_6850},
{"f_6804optimizer.scm",(void*)f_6804},
{"f_6753optimizer.scm",(void*)f_6753},
{"f_6791optimizer.scm",(void*)f_6791},
{"f_6786optimizer.scm",(void*)f_6786},
{"f_6778optimizer.scm",(void*)f_6778},
{"f_6769optimizer.scm",(void*)f_6769},
{"f_6761optimizer.scm",(void*)f_6761},
{"f_6719optimizer.scm",(void*)f_6719},
{"f_6648optimizer.scm",(void*)f_6648},
{"f_6703optimizer.scm",(void*)f_6703},
{"f_6691optimizer.scm",(void*)f_6691},
{"f_6682optimizer.scm",(void*)f_6682},
{"f_6674optimizer.scm",(void*)f_6674},
{"f_6625optimizer.scm",(void*)f_6625},
{"f_6580optimizer.scm",(void*)f_6580},
{"f_6600optimizer.scm",(void*)f_6600},
{"f_6608optimizer.scm",(void*)f_6608},
{"f_6592optimizer.scm",(void*)f_6592},
{"f_6552optimizer.scm",(void*)f_6552},
{"f_6531optimizer.scm",(void*)f_6531},
{"f_6547optimizer.scm",(void*)f_6547},
{"f_6539optimizer.scm",(void*)f_6539},
{"f_6498optimizer.scm",(void*)f_6498},
{"f_6400optimizer.scm",(void*)f_6400},
{"f_6493optimizer.scm",(void*)f_6493},
{"f_6492optimizer.scm",(void*)f_6492},
{"f_6484optimizer.scm",(void*)f_6484},
{"f_6483optimizer.scm",(void*)f_6483},
{"f_6475optimizer.scm",(void*)f_6475},
{"f_6434optimizer.scm",(void*)f_6434},
{"f_6454optimizer.scm",(void*)f_6454},
{"f_6442optimizer.scm",(void*)f_6442},
{"f_6431optimizer.scm",(void*)f_6431},
{"f_6423optimizer.scm",(void*)f_6423},
{"f_6375optimizer.scm",(void*)f_6375},
{"f_6249optimizer.scm",(void*)f_6249},
{"f_6362optimizer.scm",(void*)f_6362},
{"f_6361optimizer.scm",(void*)f_6361},
{"f_6353optimizer.scm",(void*)f_6353},
{"f_6352optimizer.scm",(void*)f_6352},
{"f_6344optimizer.scm",(void*)f_6344},
{"f_6334optimizer.scm",(void*)f_6334},
{"f_6339optimizer.scm",(void*)f_6339},
{"f_6338optimizer.scm",(void*)f_6338},
{"f_6330optimizer.scm",(void*)f_6330},
{"f_6322optimizer.scm",(void*)f_6322},
{"f_6252optimizer.scm",(void*)f_6252},
{"f_6279optimizer.scm",(void*)f_6279},
{"f_6274optimizer.scm",(void*)f_6274},
{"f_6266optimizer.scm",(void*)f_6266},
{"f_6172optimizer.scm",(void*)f_6172},
{"f_6176optimizer.scm",(void*)f_6176},
{"f_6186optimizer.scm",(void*)f_6186},
{"f_5812optimizer.scm",(void*)f_5812},
{"f_5816optimizer.scm",(void*)f_5816},
{"f_6157optimizer.scm",(void*)f_6157},
{"f_6166optimizer.scm",(void*)f_6166},
{"f_6162optimizer.scm",(void*)f_6162},
{"f_5863optimizer.scm",(void*)f_5863},
{"f_6099optimizer.scm",(void*)f_6099},
{"f_6131optimizer.scm",(void*)f_6131},
{"f_6144optimizer.scm",(void*)f_6144},
{"f_6109optimizer.scm",(void*)f_6109},
{"f_6125optimizer.scm",(void*)f_6125},
{"f_6113optimizer.scm",(void*)f_6113},
{"f_6117optimizer.scm",(void*)f_6117},
{"f_5866optimizer.scm",(void*)f_5866},
{"f_6040optimizer.scm",(void*)f_6040},
{"f_6083optimizer.scm",(void*)f_6083},
{"f_6089optimizer.scm",(void*)f_6089},
{"f_6047optimizer.scm",(void*)f_6047},
{"f_6057optimizer.scm",(void*)f_6057},
{"f_6070optimizer.scm",(void*)f_6070},
{"f_6055optimizer.scm",(void*)f_6055},
{"f_6051optimizer.scm",(void*)f_6051},
{"f_5869optimizer.scm",(void*)f_5869},
{"f_5872optimizer.scm",(void*)f_5872},
{"f_5892optimizer.scm",(void*)f_5892},
{"f_5905optimizer.scm",(void*)f_5905},
{"f_5966optimizer.scm",(void*)f_5966},
{"f_6012optimizer.scm",(void*)f_6012},
{"f_5996optimizer.scm",(void*)f_5996},
{"f_5987optimizer.scm",(void*)f_5987},
{"f_5979optimizer.scm",(void*)f_5979},
{"f_5964optimizer.scm",(void*)f_5964},
{"f_5934optimizer.scm",(void*)f_5934},
{"f_5956optimizer.scm",(void*)f_5956},
{"f_5955optimizer.scm",(void*)f_5955},
{"f_5947optimizer.scm",(void*)f_5947},
{"f_5917optimizer.scm",(void*)f_5917},
{"f_5875optimizer.scm",(void*)f_5875},
{"f_5884optimizer.scm",(void*)f_5884},
{"f_5818optimizer.scm",(void*)f_5818},
{"f_5824optimizer.scm",(void*)f_5824},
{"f_5848optimizer.scm",(void*)f_5848},
{"f_5797optimizer.scm",(void*)f_5797},
{"f_5224optimizer.scm",(void*)f_5224},
{"f_5238optimizer.scm",(void*)f_5238},
{"f_5791optimizer.scm",(void*)f_5791},
{"f_5529optimizer.scm",(void*)f_5529},
{"f_5787optimizer.scm",(void*)f_5787},
{"f_5534optimizer.scm",(void*)f_5534},
{"f_5779optimizer.scm",(void*)f_5779},
{"f_5541optimizer.scm",(void*)f_5541},
{"f_5774optimizer.scm",(void*)f_5774},
{"f_5769optimizer.scm",(void*)f_5769},
{"f_5765optimizer.scm",(void*)f_5765},
{"f_5547optimizer.scm",(void*)f_5547},
{"f_5550optimizer.scm",(void*)f_5550},
{"f_5743optimizer.scm",(void*)f_5743},
{"f_5742optimizer.scm",(void*)f_5742},
{"f_5556optimizer.scm",(void*)f_5556},
{"f_5716optimizer.scm",(void*)f_5716},
{"f_5715optimizer.scm",(void*)f_5715},
{"f_5707optimizer.scm",(void*)f_5707},
{"f_5706optimizer.scm",(void*)f_5706},
{"f_5698optimizer.scm",(void*)f_5698},
{"f_5565optimizer.scm",(void*)f_5565},
{"f_5571optimizer.scm",(void*)f_5571},
{"f_5577optimizer.scm",(void*)f_5577},
{"f_5679optimizer.scm",(void*)f_5679},
{"f_5678optimizer.scm",(void*)f_5678},
{"f_5583optimizer.scm",(void*)f_5583},
{"f_5661optimizer.scm",(void*)f_5661},
{"f_5660optimizer.scm",(void*)f_5660},
{"f_5652optimizer.scm",(void*)f_5652},
{"f_5651optimizer.scm",(void*)f_5651},
{"f_5643optimizer.scm",(void*)f_5643},
{"f_5642optimizer.scm",(void*)f_5642},
{"f_5592optimizer.scm",(void*)f_5592},
{"f_5599optimizer.scm",(void*)f_5599},
{"f_5602optimizer.scm",(void*)f_5602},
{"f_5620optimizer.scm",(void*)f_5620},
{"f_5605optimizer.scm",(void*)f_5605},
{"f_5241optimizer.scm",(void*)f_5241},
{"f_5255optimizer.scm",(void*)f_5255},
{"f_5522optimizer.scm",(void*)f_5522},
{"f_5262optimizer.scm",(void*)f_5262},
{"f_5518optimizer.scm",(void*)f_5518},
{"f_5267optimizer.scm",(void*)f_5267},
{"f_5510optimizer.scm",(void*)f_5510},
{"f_5274optimizer.scm",(void*)f_5274},
{"f_5505optimizer.scm",(void*)f_5505},
{"f_5500optimizer.scm",(void*)f_5500},
{"f_5280optimizer.scm",(void*)f_5280},
{"f_5496optimizer.scm",(void*)f_5496},
{"f_5283optimizer.scm",(void*)f_5283},
{"f_5482optimizer.scm",(void*)f_5482},
{"f_5481optimizer.scm",(void*)f_5481},
{"f_5465optimizer.scm",(void*)f_5465},
{"f_5463optimizer.scm",(void*)f_5463},
{"f_5289optimizer.scm",(void*)f_5289},
{"f_5437optimizer.scm",(void*)f_5437},
{"f_5436optimizer.scm",(void*)f_5436},
{"f_5428optimizer.scm",(void*)f_5428},
{"f_5427optimizer.scm",(void*)f_5427},
{"f_5415optimizer.scm",(void*)f_5415},
{"f_5414optimizer.scm",(void*)f_5414},
{"f_5301optimizer.scm",(void*)f_5301},
{"f_5307optimizer.scm",(void*)f_5307},
{"f_5394optimizer.scm",(void*)f_5394},
{"f_5393optimizer.scm",(void*)f_5393},
{"f_5381optimizer.scm",(void*)f_5381},
{"f_5380optimizer.scm",(void*)f_5380},
{"f_5372optimizer.scm",(void*)f_5372},
{"f_5371optimizer.scm",(void*)f_5371},
{"f_5316optimizer.scm",(void*)f_5316},
{"f_5344optimizer.scm",(void*)f_5344},
{"f_5319optimizer.scm",(void*)f_5319},
{"f_5322optimizer.scm",(void*)f_5322},
{"f_5325optimizer.scm",(void*)f_5325},
{"f_5343optimizer.scm",(void*)f_5343},
{"f_5328optimizer.scm",(void*)f_5328},
{"f_5244optimizer.scm",(void*)f_5244},
{"f_5247optimizer.scm",(void*)f_5247},
{"f_5231optimizer.scm",(void*)f_5231},
{"f_5227optimizer.scm",(void*)f_5227},
{"f_3524optimizer.scm",(void*)f_3524},
{"f_5128optimizer.scm",(void*)f_5128},
{"f_5134optimizer.scm",(void*)f_5134},
{"f_5138optimizer.scm",(void*)f_5138},
{"f_5141optimizer.scm",(void*)f_5141},
{"f_5177optimizer.scm",(void*)f_5177},
{"f_5182optimizer.scm",(void*)f_5182},
{"f_5186optimizer.scm",(void*)f_5186},
{"f_5144optimizer.scm",(void*)f_5144},
{"f_5147optimizer.scm",(void*)f_5147},
{"f_5150optimizer.scm",(void*)f_5150},
{"f_5153optimizer.scm",(void*)f_5153},
{"f_5104optimizer.scm",(void*)f_5104},
{"f_5108optimizer.scm",(void*)f_5108},
{"f_5114optimizer.scm",(void*)f_5114},
{"f_5118optimizer.scm",(void*)f_5118},
{"f_3911optimizer.scm",(void*)f_3911},
{"f_5098optimizer.scm",(void*)f_5098},
{"f_3915optimizer.scm",(void*)f_3915},
{"f_5093optimizer.scm",(void*)f_5093},
{"f_3918optimizer.scm",(void*)f_3918},
{"f_5088optimizer.scm",(void*)f_5088},
{"f_3921optimizer.scm",(void*)f_3921},
{"f_4989optimizer.scm",(void*)f_4989},
{"f_4992optimizer.scm",(void*)f_4992},
{"f_5081optimizer.scm",(void*)f_5081},
{"f_5077optimizer.scm",(void*)f_5077},
{"f_5049optimizer.scm",(void*)f_5049},
{"f_5070optimizer.scm",(void*)f_5070},
{"f_5062optimizer.scm",(void*)f_5062},
{"f_5009optimizer.scm",(void*)f_5009},
{"f_5039optimizer.scm",(void*)f_5039},
{"f_5031optimizer.scm",(void*)f_5031},
{"f_5015optimizer.scm",(void*)f_5015},
{"f_5019optimizer.scm",(void*)f_5019},
{"f_4999optimizer.scm",(void*)f_4999},
{"f_4970optimizer.scm",(void*)f_4970},
{"f_4258optimizer.scm",(void*)f_4258},
{"f_4957optimizer.scm",(void*)f_4957},
{"f_4958optimizer.scm",(void*)f_4958},
{"f_4927optimizer.scm",(void*)f_4927},
{"f_4926optimizer.scm",(void*)f_4926},
{"f_4922optimizer.scm",(void*)f_4922},
{"f_4912optimizer.scm",(void*)f_4912},
{"f_4270optimizer.scm",(void*)f_4270},
{"f_4279optimizer.scm",(void*)f_4279},
{"f_4902optimizer.scm",(void*)f_4902},
{"f_4901optimizer.scm",(void*)f_4901},
{"f_4489optimizer.scm",(void*)f_4489},
{"f_4887optimizer.scm",(void*)f_4887},
{"f_4492optimizer.scm",(void*)f_4492},
{"f_4500optimizer.scm",(void*)f_4500},
{"f_4853optimizer.scm",(void*)f_4853},
{"f_4859optimizer.scm",(void*)f_4859},
{"f_4882optimizer.scm",(void*)f_4882},
{"f_4862optimizer.scm",(void*)f_4862},
{"f_4510optimizer.scm",(void*)f_4510},
{"f_4573optimizer.scm",(void*)f_4573},
{"f_4840optimizer.scm",(void*)f_4840},
{"f_4745optimizer.scm",(void*)f_4745},
{"f_4760optimizer.scm",(void*)f_4760},
{"f_4771optimizer.scm",(void*)f_4771},
{"f_4818optimizer.scm",(void*)f_4818},
{"f_4804optimizer.scm",(void*)f_4804},
{"f_4796optimizer.scm",(void*)f_4796},
{"f_4783optimizer.scm",(void*)f_4783},
{"f_4784optimizer.scm",(void*)f_4784},
{"f_4775optimizer.scm",(void*)f_4775},
{"f_4765optimizer.scm",(void*)f_4765},
{"f_4587optimizer.scm",(void*)f_4587},
{"f_4626optimizer.scm",(void*)f_4626},
{"f_4632optimizer.scm",(void*)f_4632},
{"f_4638optimizer.scm",(void*)f_4638},
{"f_4682optimizer.scm",(void*)f_4682},
{"f_4658optimizer.scm",(void*)f_4658},
{"f_4662optimizer.scm",(void*)f_4662},
{"f_4650optimizer.scm",(void*)f_4650},
{"f_4620optimizer.scm",(void*)f_4620},
{"f_4607optimizer.scm",(void*)f_4607},
{"f_4608optimizer.scm",(void*)f_4608},
{"f_4563optimizer.scm",(void*)f_4563},
{"f_4557optimizer.scm",(void*)f_4557},
{"f_4558optimizer.scm",(void*)f_4558},
{"f_4553optimizer.scm",(void*)f_4553},
{"f_4513optimizer.scm",(void*)f_4513},
{"f_4516optimizer.scm",(void*)f_4516},
{"f_4519optimizer.scm",(void*)f_4519},
{"f_4538optimizer.scm",(void*)f_4538},
{"f_4537optimizer.scm",(void*)f_4537},
{"f_4529optimizer.scm",(void*)f_4529},
{"f_4479optimizer.scm",(void*)f_4479},
{"f_4478optimizer.scm",(void*)f_4478},
{"f_4470optimizer.scm",(void*)f_4470},
{"f_4469optimizer.scm",(void*)f_4469},
{"f_4465optimizer.scm",(void*)f_4465},
{"f_4352optimizer.scm",(void*)f_4352},
{"f_4451optimizer.scm",(void*)f_4451},
{"f_4450optimizer.scm",(void*)f_4450},
{"f_4370optimizer.scm",(void*)f_4370},
{"f_4438optimizer.scm",(void*)f_4438},
{"f_4430optimizer.scm",(void*)f_4430},
{"f_4373optimizer.scm",(void*)f_4373},
{"f_4409optimizer.scm",(void*)f_4409},
{"f_4407optimizer.scm",(void*)f_4407},
{"f_4382optimizer.scm",(void*)f_4382},
{"f_4399optimizer.scm",(void*)f_4399},
{"f_4398optimizer.scm",(void*)f_4398},
{"f_4390optimizer.scm",(void*)f_4390},
{"f_4331optimizer.scm",(void*)f_4331},
{"f_4315optimizer.scm",(void*)f_4315},
{"f_4282optimizer.scm",(void*)f_4282},
{"f_4288optimizer.scm",(void*)f_4288},
{"f_4291optimizer.scm",(void*)f_4291},
{"f_4310optimizer.scm",(void*)f_4310},
{"f_4309optimizer.scm",(void*)f_4309},
{"f_4301optimizer.scm",(void*)f_4301},
{"f_4080optimizer.scm",(void*)f_4080},
{"f_4179optimizer.scm",(void*)f_4179},
{"f_4184optimizer.scm",(void*)f_4184},
{"f_4191optimizer.scm",(void*)f_4191},
{"f_4227optimizer.scm",(void*)f_4227},
{"f_4211optimizer.scm",(void*)f_4211},
{"f_4203optimizer.scm",(void*)f_4203},
{"f_4085optimizer.scm",(void*)f_4085},
{"f_4103optimizer.scm",(void*)f_4103},
{"f_4110optimizer.scm",(void*)f_4110},
{"f_4153optimizer.scm",(void*)f_4153},
{"f_4156optimizer.scm",(void*)f_4156},
{"f_4146optimizer.scm",(void*)f_4146},
{"f_4130optimizer.scm",(void*)f_4130},
{"f_4122optimizer.scm",(void*)f_4122},
{"f_4091optimizer.scm",(void*)f_4091},
{"f_4097optimizer.scm",(void*)f_4097},
{"f_4017optimizer.scm",(void*)f_4017},
{"f_4049optimizer.scm",(void*)f_4049},
{"f_4058optimizer.scm",(void*)f_4058},
{"f_4065optimizer.scm",(void*)f_4065},
{"f_4020optimizer.scm",(void*)f_4020},
{"f_4041optimizer.scm",(void*)f_4041},
{"f_4042optimizer.scm",(void*)f_4042},
{"f_3936optimizer.scm",(void*)f_3936},
{"f_3940optimizer.scm",(void*)f_3940},
{"f_3952optimizer.scm",(void*)f_3952},
{"f_3981optimizer.scm",(void*)f_3981},
{"f_3958optimizer.scm",(void*)f_3958},
{"f_3973optimizer.scm",(void*)f_3973},
{"f_3974optimizer.scm",(void*)f_3974},
{"f_3969optimizer.scm",(void*)f_3969},
{"f_3664optimizer.scm",(void*)f_3664},
{"f_3678optimizer.scm",(void*)f_3678},
{"f_3905optimizer.scm",(void*)f_3905},
{"f_3681optimizer.scm",(void*)f_3681},
{"f_3900optimizer.scm",(void*)f_3900},
{"f_3684optimizer.scm",(void*)f_3684},
{"f_3895optimizer.scm",(void*)f_3895},
{"f_3890optimizer.scm",(void*)f_3890},
{"f_3882optimizer.scm",(void*)f_3882},
{"f_3877optimizer.scm",(void*)f_3877},
{"f_3869optimizer.scm",(void*)f_3869},
{"f_3855optimizer.scm",(void*)f_3855},
{"f_3861optimizer.scm",(void*)f_3861},
{"f_3748optimizer.scm",(void*)f_3748},
{"f_3836optimizer.scm",(void*)f_3836},
{"f_3848optimizer.scm",(void*)f_3848},
{"f_3834optimizer.scm",(void*)f_3834},
{"f_3759optimizer.scm",(void*)f_3759},
{"f_3782optimizer.scm",(void*)f_3782},
{"f_3820optimizer.scm",(void*)f_3820},
{"f_3826optimizer.scm",(void*)f_3826},
{"f_3788optimizer.scm",(void*)f_3788},
{"f_3792optimizer.scm",(void*)f_3792},
{"f_3795optimizer.scm",(void*)f_3795},
{"f_3818optimizer.scm",(void*)f_3818},
{"f_3806optimizer.scm",(void*)f_3806},
{"f_3765optimizer.scm",(void*)f_3765},
{"f_3771optimizer.scm",(void*)f_3771},
{"f_3775optimizer.scm",(void*)f_3775},
{"f_3779optimizer.scm",(void*)f_3779},
{"f_3757optimizer.scm",(void*)f_3757},
{"f_3696optimizer.scm",(void*)f_3696},
{"f_3713optimizer.scm",(void*)f_3713},
{"f_3687optimizer.scm",(void*)f_3687},
{"f_3567optimizer.scm",(void*)f_3567},
{"f_3658optimizer.scm",(void*)f_3658},
{"f_3657optimizer.scm",(void*)f_3657},
{"f_3571optimizer.scm",(void*)f_3571},
{"f_3582optimizer.scm",(void*)f_3582},
{"f_3592optimizer.scm",(void*)f_3592},
{"f_3641optimizer.scm",(void*)f_3641},
{"f_3639optimizer.scm",(void*)f_3639},
{"f_3598optimizer.scm",(void*)f_3598},
{"f_3604optimizer.scm",(void*)f_3604},
{"f_3631optimizer.scm",(void*)f_3631},
{"f_3610optimizer.scm",(void*)f_3610},
{"f_3574optimizer.scm",(void*)f_3574},
{"f_3563optimizer.scm",(void*)f_3563},
{"f_3548optimizer.scm",(void*)f_3548},
{"f_3557optimizer.scm",(void*)f_3557},
{"f_3556optimizer.scm",(void*)f_3556},
{"f_3533optimizer.scm",(void*)f_3533},
{"f_3542optimizer.scm",(void*)f_3542},
{"f_3541optimizer.scm",(void*)f_3541},
{"f_3527optimizer.scm",(void*)f_3527},
{"f_3271optimizer.scm",(void*)f_3271},
{"f_3292optimizer.scm",(void*)f_3292},
{"f_3336optimizer.scm",(void*)f_3336},
{"f_3351optimizer.scm",(void*)f_3351},
{"f_3510optimizer.scm",(void*)f_3510},
{"f_3355optimizer.scm",(void*)f_3355},
{"f_3505optimizer.scm",(void*)f_3505},
{"f_3358optimizer.scm",(void*)f_3358},
{"f_3500optimizer.scm",(void*)f_3500},
{"f_3361optimizer.scm",(void*)f_3361},
{"f_3403optimizer.scm",(void*)f_3403},
{"f_3467optimizer.scm",(void*)f_3467},
{"f_3422optimizer.scm",(void*)f_3422},
{"f_3433optimizer.scm",(void*)f_3433},
{"f_3406optimizer.scm",(void*)f_3406},
{"f_3376optimizer.scm",(void*)f_3376},
{"f_3339optimizer.scm",(void*)f_3339},
{"f_3345optimizer.scm",(void*)f_3345},
{"f_3295optimizer.scm",(void*)f_3295},
{"f_3298optimizer.scm",(void*)f_3298},
{"f_3303optimizer.scm",(void*)f_3303},
{"f_3308optimizer.scm",(void*)f_3308},
{"f_3312optimizer.scm",(void*)f_3312},
{"f_3274optimizer.scm",(void*)f_3274},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
