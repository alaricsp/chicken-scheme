/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-06-19 09:27
   Version 4.0.7 - SVN rev. 14630
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-05-14 on lenovo-1 (MINGW32_NT-6.0)
   command line: optimizer.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[263];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11666)
static void C_ccall f_11666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_11674)
static void C_ccall f_11674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11679)
static void C_fcall f_11679(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11724)
static void C_ccall f_11724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11728)
static void C_ccall f_11728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11689)
static void C_ccall f_11689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11713)
static void C_ccall f_11713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11698)
static void C_fcall f_11698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_10739)
static void C_ccall f_10739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10841)
static void C_ccall f_10841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10851)
static void C_fcall f_10851(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10915)
static void C_ccall f_10915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10944)
static void C_fcall f_10944(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11067)
static void C_ccall f_11067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10960)
static void C_fcall f_10960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11007)
static void C_ccall f_11007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10997)
static void C_ccall f_10997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11005)
static void C_ccall f_11005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11137)
static void C_ccall f_11137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_11150)
static void C_ccall f_11150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11185)
static void C_ccall f_11185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11169)
static void C_ccall f_11169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11173)
static void C_ccall f_11173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11162)
static void C_ccall f_11162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11351)
static void C_ccall f_11351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_11364)
static void C_ccall f_11364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11370)
static void C_ccall f_11370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11416)
static void C_ccall f_11416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11408)
static void C_ccall f_11408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11392)
static void C_ccall f_11392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11396)
static void C_ccall f_11396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11400)
static void C_ccall f_11400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10383)
static void C_ccall f_10383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_10405)
static void C_ccall f_10405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10460)
static void C_ccall f_10460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10430)
static void C_ccall f_10430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10452)
static void C_ccall f_10452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10456)
static void C_ccall f_10456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10448)
static void C_ccall f_10448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10428)
static void C_ccall f_10428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10554)
static void C_ccall f_10554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_10568)
static void C_ccall f_10568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8716)
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10262)
static void C_ccall f_10262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10265)
static void C_ccall f_10265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10268)
static void C_ccall f_10268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10271)
static void C_ccall f_10271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10274)
static void C_ccall f_10274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10277)
static void C_ccall f_10277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10354)
static void C_ccall f_10354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10283)
static void C_ccall f_10283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10286)
static void C_ccall f_10286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10348)
static void C_ccall f_10348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10289)
static void C_ccall f_10289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10292)
static void C_ccall f_10292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10345)
static void C_ccall f_10345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_fcall f_9325(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9343)
static void C_ccall f_9343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9349)
static void C_ccall f_9349(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9329)
static void C_ccall f_9329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10295)
static void C_ccall f_10295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10337)
static void C_ccall f_10337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10335)
static void C_ccall f_10335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10298)
static void C_ccall f_10298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10301)
static void C_ccall f_10301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10304)
static void C_ccall f_10304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10328)
static void C_ccall f_10328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10307)
static void C_ccall f_10307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10310)
static void C_ccall f_10310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10316)
static void C_ccall f_10316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10319)
static void C_ccall f_10319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10322)
static void C_ccall f_10322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10115)
static void C_fcall f_10115(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10121)
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10233)
static void C_ccall f_10233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10242)
static void C_ccall f_10242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10245)
static void C_ccall f_10245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10140)
static void C_ccall f_10140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10145)
static void C_fcall f_10145(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10186)
static void C_fcall f_10186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10183)
static void C_ccall f_10183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10168)
static void C_ccall f_10168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10179)
static void C_ccall f_10179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10175)
static void C_ccall f_10175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10028)
static void C_fcall f_10028(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10034)
static void C_ccall f_10034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10090)
static void C_ccall f_10090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10086)
static void C_ccall f_10086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10056)
static void C_ccall f_10056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9779)
static void C_fcall f_9779(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9793)
static void C_ccall f_9793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9803)
static void C_ccall f_9803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9812)
static void C_ccall f_9812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9819)
static void C_ccall f_9819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9918)
static void C_ccall f_9918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10004)
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10023)
static void C_ccall f_10023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10019)
static void C_ccall f_10019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9985)
static void C_ccall f_9985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9974)
static void C_ccall f_9974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9961)
static void C_ccall f_9961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9944)
static void C_ccall f_9944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9937)
static void C_ccall f_9937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9903)
static void C_ccall f_9903(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9825)
static void C_ccall f_9825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9874)
static void C_ccall f_9874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9862)
static void C_ccall f_9862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9858)
static void C_ccall f_9858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9791)
static void C_ccall f_9791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9578)
static void C_fcall f_9578(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9643)
static void C_ccall f_9643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9720)
static void C_ccall f_9720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9763)
static void C_ccall f_9763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9587)
static void C_ccall f_9587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9625)
static void C_ccall f_9625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9607)
static void C_ccall f_9607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9585)
static void C_ccall f_9585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9741)
static void C_ccall f_9741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9739)
static void C_ccall f_9739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9645)
static void C_ccall f_9645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9711)
static void C_ccall f_9711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9699)
static void C_ccall f_9699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9689)
static void C_ccall f_9689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9687)
static void C_ccall f_9687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9683)
static void C_ccall f_9683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9675)
static void C_ccall f_9675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9359)
static void C_fcall f_9359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9365)
static void C_fcall f_9365(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9384)
static void C_fcall f_9384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9551)
static void C_ccall f_9551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9481)
static void C_ccall f_9481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9497)
static void C_ccall f_9497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9527)
static void C_ccall f_9527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9531)
static void C_ccall f_9531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9517)
static void C_ccall f_9517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9470)
static void C_ccall f_9470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9475)
static void C_ccall f_9475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9446)
static void C_ccall f_9446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9458)
static void C_ccall f_9458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9395)
static void C_fcall f_9395(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9416)
static void C_ccall f_9416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9413)
static void C_ccall f_9413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9115)
static void C_fcall f_9115(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9121)
static void C_fcall f_9121(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9140)
static void C_fcall f_9140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9233)
static void C_ccall f_9233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9199)
static void C_fcall f_9199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9208)
static void C_ccall f_9208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_fcall f_9151(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_ccall f_9169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9119)
static void C_ccall f_9119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_fcall f_9016(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9022)
static void C_ccall f_9022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9066)
static void C_ccall f_9066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9071)
static void C_fcall f_9071(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9078)
static void C_ccall f_9078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9105)
static void C_ccall f_9105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_ccall f_9101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9093)
static void C_ccall f_9093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9091)
static void C_ccall f_9091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9041)
static void C_ccall f_9041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8819)
static void C_fcall f_8819(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8973)
static void C_ccall f_8973(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8998)
static void C_ccall f_8998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8988)
static void C_ccall f_8988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8992)
static void C_ccall f_8992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8971)
static void C_ccall f_8971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8822)
static void C_fcall f_8822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8961)
static void C_ccall f_8961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8944)
static void C_ccall f_8944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8956)
static void C_ccall f_8956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8890)
static void C_fcall f_8890(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8914)
static void C_ccall f_8914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8908)
static void C_ccall f_8908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8872)
static void C_ccall f_8872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8847)
static void C_fcall f_8847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8850)
static void C_fcall f_8850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8719)
static void C_fcall f_8719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8725)
static void C_ccall f_8725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8756)
static void C_fcall f_8756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8760)
static void C_ccall f_8760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_ccall f_8764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7621)
static void C_ccall f_7621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8711)
static void C_ccall f_8711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7624)
static void C_fcall f_7624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7680)
static void C_ccall f_7680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7686)
static void C_ccall f_7686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7692)
static void C_ccall f_7692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7649)
static void C_ccall f_7649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_fcall f_7786(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8196)
static void C_ccall f_8196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_fcall f_7789(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8183)
static void C_ccall f_8183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8159)
static void C_ccall f_8159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8170)
static void C_ccall f_8170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8065)
static void C_fcall f_8065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8037)
static void C_fcall f_8037(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8042)
static void C_ccall f_8042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7990)
static void C_fcall f_7990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7995)
static void C_ccall f_7995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_fcall f_7949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7923)
static void C_ccall f_7923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7893)
static void C_ccall f_7893(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_fcall f_8205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8701)
static void C_ccall f_8701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8699)
static void C_ccall f_8699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8219)
static void C_ccall f_8219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8225)
static void C_fcall f_8225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8234)
static void C_ccall f_8234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8416)
static void C_ccall f_8416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8638)
static void C_ccall f_8638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8591)
static void C_ccall f_8591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8460)
static void C_ccall f_8460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8515)
static void C_ccall f_8515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8518)
static void C_ccall f_8518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8545)
static void C_ccall f_8545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8521)
static void C_ccall f_8521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8524)
static void C_ccall f_8524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8469)
static void C_ccall f_8469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8472)
static void C_ccall f_8472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8396)
static void C_ccall f_8396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8339)
static void C_ccall f_8339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8246)
static void C_ccall f_8246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8258)
static void C_ccall f_8258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8261)
static void C_ccall f_8261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8264)
static void C_ccall f_8264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8276)
static void C_ccall f_8276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7529)
static void C_ccall f_7529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7543)
static void C_fcall f_7543(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7592)
static void C_ccall f_7592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5774)
static void C_fcall f_5774(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_ccall f_7567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_ccall f_7521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7510)
static void C_ccall f_7510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7438)
static void C_ccall f_7438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_fcall f_7457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7380)
static void C_ccall f_7380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7305)
static void C_ccall f_7305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7349)
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7321)
static void C_ccall f_7321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7263)
static void C_ccall f_7263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7241)
static void C_ccall f_7241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7162)
static void C_ccall f_7162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7090)
static void C_ccall f_7090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7143)
static void C_ccall f_7143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7141)
static void C_ccall f_7141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_fcall f_7010(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6917)
static void C_ccall f_6917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6947)
static void C_fcall f_6947(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6830)
static void C_ccall f_6830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6842)
static void C_ccall f_6842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6753)
static void C_ccall f_6753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6709)
static void C_fcall f_6709(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_ccall f_6624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6660)
static void C_ccall f_6660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_fcall f_6577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6590)
static void C_ccall f_6590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6500)
static void C_ccall f_6500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6512)
static void C_ccall f_6512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static void C_ccall f_6334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_fcall f_6356(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_fcall f_6359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6394)
static void C_ccall f_6394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_ccall f_6050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5942)
static void C_fcall f_5942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_fcall f_5939(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_fcall f_5809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5729)
static void C_ccall f_5729r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5714)
static void C_ccall f_5714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5723)
static void C_ccall f_5723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5688)
static void C_ccall f_5688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5682)
static void C_ccall f_5682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5455)
static void C_ccall f_5455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5481)
static void C_ccall f_5481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5494)
static void C_fcall f_5494(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_fcall f_5407(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5413)
static void C_fcall f_5413(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_fcall f_5201(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5216)
static void C_fcall f_5216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_fcall f_5228(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_fcall f_5237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5152)
static void C_fcall f_5152(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5148)
static C_word C_fcall f_5148(C_word t0);
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_fcall f_5030(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_fcall f_3996(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4990)
static void C_fcall f_4990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_fcall f_4961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_fcall f_4519(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4851)
static void C_ccall f_4851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_fcall f_4540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_fcall f_4746(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_fcall f_4601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_fcall f_4425(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_ccall f_4450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_fcall f_4380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_fcall f_4099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_fcall f_4021(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_fcall f_4060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_fcall f_3893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_fcall f_3690(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_fcall f_3733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static C_word C_fcall f_3686(C_word t0);
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3660)
static void C_fcall f_3660(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3499)
static void C_fcall f_3499(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3551)
static void C_fcall f_3551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_ccall f_3581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_fcall f_3524(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_fcall f_3487(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_ccall f_3422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_11679)
static void C_fcall trf_11679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11679(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11679(t0,t1,t2);}

C_noret_decl(trf_11698)
static void C_fcall trf_11698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11698(t0,t1);}

C_noret_decl(trf_10851)
static void C_fcall trf_10851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10851(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10851(t0,t1,t2,t3);}

C_noret_decl(trf_10944)
static void C_fcall trf_10944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10944(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10944(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10960)
static void C_fcall trf_10960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10960(t0,t1);}

C_noret_decl(trf_9325)
static void C_fcall trf_9325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9325(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9325(t0,t1,t2,t3);}

C_noret_decl(trf_10115)
static void C_fcall trf_10115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10115(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10115(t0,t1,t2);}

C_noret_decl(trf_10145)
static void C_fcall trf_10145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10145(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10145(t0,t1,t2,t3);}

C_noret_decl(trf_10186)
static void C_fcall trf_10186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10186(t0,t1);}

C_noret_decl(trf_10028)
static void C_fcall trf_10028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10028(t0,t1,t2);}

C_noret_decl(trf_9779)
static void C_fcall trf_9779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9779(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9779(t0,t1,t2,t3);}

C_noret_decl(trf_9578)
static void C_fcall trf_9578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9578(t0,t1,t2);}

C_noret_decl(trf_9359)
static void C_fcall trf_9359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9359(t0,t1,t2);}

C_noret_decl(trf_9365)
static void C_fcall trf_9365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9365(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9365(t0,t1,t2,t3);}

C_noret_decl(trf_9384)
static void C_fcall trf_9384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9384(t0,t1);}

C_noret_decl(trf_9395)
static void C_fcall trf_9395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9395(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9395(t0,t1,t2,t3);}

C_noret_decl(trf_9115)
static void C_fcall trf_9115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9115(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9115(t0,t1,t2);}

C_noret_decl(trf_9121)
static void C_fcall trf_9121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9121(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9121(t0,t1,t2,t3);}

C_noret_decl(trf_9140)
static void C_fcall trf_9140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9140(t0,t1);}

C_noret_decl(trf_9199)
static void C_fcall trf_9199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9199(t0,t1);}

C_noret_decl(trf_9151)
static void C_fcall trf_9151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9151(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9151(t0,t1,t2,t3);}

C_noret_decl(trf_9016)
static void C_fcall trf_9016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9016(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9016(t0,t1,t2,t3);}

C_noret_decl(trf_9071)
static void C_fcall trf_9071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9071(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9071(t0,t1,t2,t3);}

C_noret_decl(trf_8819)
static void C_fcall trf_8819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8819(t0,t1,t2);}

C_noret_decl(trf_8822)
static void C_fcall trf_8822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8822(t0,t1,t2,t3);}

C_noret_decl(trf_8890)
static void C_fcall trf_8890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8890(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8890(t0,t1,t2,t3);}

C_noret_decl(trf_8847)
static void C_fcall trf_8847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8847(t0,t1);}

C_noret_decl(trf_8850)
static void C_fcall trf_8850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8850(t0,t1);}

C_noret_decl(trf_8719)
static void C_fcall trf_8719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8719(t0,t1);}

C_noret_decl(trf_8756)
static void C_fcall trf_8756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8756(t0,t1);}

C_noret_decl(trf_7624)
static void C_fcall trf_7624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7624(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7624(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7786)
static void C_fcall trf_7786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7786(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_7786(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7789)
static void C_fcall trf_7789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7789(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_7789(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8065)
static void C_fcall trf_8065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8065(t0,t1);}

C_noret_decl(trf_8037)
static void C_fcall trf_8037(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8037(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8037(t0,t1);}

C_noret_decl(trf_7990)
static void C_fcall trf_7990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7990(t0,t1);}

C_noret_decl(trf_7949)
static void C_fcall trf_7949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7949(t0,t1);}

C_noret_decl(trf_8205)
static void C_fcall trf_8205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8205(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8205(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8225)
static void C_fcall trf_8225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8225(t0,t1);}

C_noret_decl(trf_7543)
static void C_fcall trf_7543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7543(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7543(t0,t1,t2,t3);}

C_noret_decl(trf_5774)
static void C_fcall trf_5774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5774(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5774(t0,t1);}

C_noret_decl(trf_7457)
static void C_fcall trf_7457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7457(t0,t1);}

C_noret_decl(trf_7010)
static void C_fcall trf_7010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7010(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7010(t0,t1);}

C_noret_decl(trf_6947)
static void C_fcall trf_6947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6947(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6947(t0,t1);}

C_noret_decl(trf_6709)
static void C_fcall trf_6709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6709(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6709(t0,t1);}

C_noret_decl(trf_6577)
static void C_fcall trf_6577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6577(t0,t1);}

C_noret_decl(trf_6356)
static void C_fcall trf_6356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6356(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6356(t0,t1);}

C_noret_decl(trf_6359)
static void C_fcall trf_6359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6359(t0,t1);}

C_noret_decl(trf_5942)
static void C_fcall trf_5942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5942(t0,t1);}

C_noret_decl(trf_5939)
static void C_fcall trf_5939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5939(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5939(t0,t1);}

C_noret_decl(trf_5809)
static void C_fcall trf_5809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5809(t0,t1);}

C_noret_decl(trf_5494)
static void C_fcall trf_5494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5494(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5494(t0,t1);}

C_noret_decl(trf_5407)
static void C_fcall trf_5407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5407(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5407(t0,t1,t2,t3);}

C_noret_decl(trf_5413)
static void C_fcall trf_5413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5413(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5413(t0,t1,t2,t3);}

C_noret_decl(trf_5201)
static void C_fcall trf_5201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5201(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5201(t0,t1);}

C_noret_decl(trf_5216)
static void C_fcall trf_5216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5216(t0,t1);}

C_noret_decl(trf_5228)
static void C_fcall trf_5228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5228(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5228(t0,t1);}

C_noret_decl(trf_5237)
static void C_fcall trf_5237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5237(t0,t1);}

C_noret_decl(trf_5152)
static void C_fcall trf_5152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5152(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5152(t0,t1,t2,t3);}

C_noret_decl(trf_5030)
static void C_fcall trf_5030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5030(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5030(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3996)
static void C_fcall trf_3996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3996(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3996(t0,t1,t2);}

C_noret_decl(trf_4990)
static void C_fcall trf_4990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4990(t0,t1);}

C_noret_decl(trf_4961)
static void C_fcall trf_4961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4961(t0,t1);}

C_noret_decl(trf_4519)
static void C_fcall trf_4519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4519(t0,t1);}

C_noret_decl(trf_4540)
static void C_fcall trf_4540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4540(t0,t1);}

C_noret_decl(trf_4746)
static void C_fcall trf_4746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4746(t0,t1);}

C_noret_decl(trf_4601)
static void C_fcall trf_4601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4601(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4601(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4425)
static void C_fcall trf_4425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4425(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4425(t0,t1);}

C_noret_decl(trf_4380)
static void C_fcall trf_4380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4380(t0,t1);}

C_noret_decl(trf_4099)
static void C_fcall trf_4099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4099(t0,t1);}

C_noret_decl(trf_4021)
static void C_fcall trf_4021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4021(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4021(t0,t1,t2);}

C_noret_decl(trf_4060)
static void C_fcall trf_4060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4060(t0,t1);}

C_noret_decl(trf_3893)
static void C_fcall trf_3893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3893(t0,t1);}

C_noret_decl(trf_3690)
static void C_fcall trf_3690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3690(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3690(t0,t1,t2);}

C_noret_decl(trf_3733)
static void C_fcall trf_3733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3733(t0,t1);}

C_noret_decl(trf_3660)
static void C_fcall trf_3660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3660(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3660(t0,t1,t2,t3);}

C_noret_decl(trf_3499)
static void C_fcall trf_3499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3499(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3499(t0,t1,t2,t3);}

C_noret_decl(trf_3551)
static void C_fcall trf_3551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3551(t0,t1);}

C_noret_decl(trf_3524)
static void C_fcall trf_3524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3524(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3524(t0,t1);}

C_noret_decl(trf_3487)
static void C_fcall trf_3487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3487(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3487(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1951)){
C_save(t1);
C_rereclaim2(1951*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,263);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],8,"\003sysput!");
lf[2]=C_h_intern(&lf[2],9,"\003syserror");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],21,"\010compileralways-bound");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],18,"\010compilerdebugging");
lf[7]=C_h_intern(&lf[7],1,"o");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[9]=C_h_intern(&lf[9],13,"\004corevariable");
lf[10]=C_h_intern(&lf[10],2,"if");
lf[11]=C_h_intern(&lf[11],3,"let");
lf[12]=C_h_intern(&lf[12],6,"append");
lf[13]=C_h_intern(&lf[13],6,"lambda");
lf[14]=C_h_intern(&lf[14],13,"\004corecallunit");
lf[15]=C_h_intern(&lf[15],9,"\004corecall");
lf[16]=C_h_intern(&lf[16],4,"set!");
lf[17]=C_h_intern(&lf[17],9,"\004corecond");
lf[18]=C_h_intern(&lf[18],11,"\004coreswitch");
lf[19]=C_h_intern(&lf[19],30,"call-with-current-continuation");
lf[20]=C_h_intern(&lf[20],1,"p");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[22]=C_h_intern(&lf[22],24,"\010compilersimplifications");
lf[23]=C_h_intern(&lf[23],23,"\010compilersimplified-ops");
lf[24]=C_h_intern(&lf[24],41,"\010compilerperform-high-level-optimizations");
lf[25]=C_h_intern(&lf[25],12,"\010compilerget");
lf[26]=C_h_intern(&lf[26],5,"quote");
lf[27]=C_h_intern(&lf[27],10,"alist-cons");
lf[28]=C_h_intern(&lf[28],4,"caar");
lf[29]=C_h_intern(&lf[29],7,"\003sysmap");
lf[30]=C_h_intern(&lf[30],19,"\010compilermatch-node");
lf[31]=C_h_intern(&lf[31],3,"any");
lf[32]=C_h_intern(&lf[32],18,"\003syshash-table-ref");
lf[33]=C_h_intern(&lf[33],30,"\010compilerbroken-constant-nodes");
lf[34]=C_h_intern(&lf[34],11,"lset-adjoin");
lf[35]=C_h_intern(&lf[35],3,"eq\077");
lf[36]=C_h_intern(&lf[36],4,"node");
lf[37]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[38]=C_h_intern(&lf[38],14,"\010compilerqnode");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[40]=C_h_intern(&lf[40],4,"eval");
lf[41]=C_h_intern(&lf[41],22,"with-exception-handler");
lf[42]=C_h_intern(&lf[42],5,"every");
lf[43]=C_h_intern(&lf[43],9,"foldable\077");
lf[44]=C_h_intern(&lf[44],7,"\003sysget");
lf[45]=C_h_intern(&lf[45],18,"\010compilerintrinsic");
lf[46]=C_h_intern(&lf[46],5,"value");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[48]=C_h_intern(&lf[48],16,"\010compilervarnode");
lf[49]=C_h_intern(&lf[49],11,"collapsable");
lf[50]=C_h_intern(&lf[50],10,"replacable");
lf[51]=C_h_intern(&lf[51],9,"replacing");
lf[52]=C_h_intern(&lf[52],12,"contractable");
lf[53]=C_h_intern(&lf[53],9,"removable");
lf[54]=C_h_intern(&lf[54],11,"\004corelambda");
lf[55]=C_h_intern(&lf[55],6,"unused");
lf[56]=C_h_intern(&lf[56],9,"partition");
lf[57]=C_h_intern(&lf[57],26,"\010compilerbuild-lambda-list");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[59]=C_h_intern(&lf[59],13,"explicit-rest");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[61]=C_h_intern(&lf[61],30,"\010compilerdecompose-lambda-list");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[63]=C_h_intern(&lf[63],21,"has-unused-parameters");
lf[64]=C_h_intern(&lf[64],31,"\010compilerinline-lambda-bindings");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[66]=C_h_intern(&lf[66],24,"\010compilercheck-signature");
lf[67]=C_h_intern(&lf[67],30,"\010compilerconstant-declarations");
lf[68]=C_h_intern(&lf[68],14,"\004coreundefined");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[70]=C_h_intern(&lf[70],1,"x");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[72]=C_h_intern(&lf[72],37,"\010compilerexpression-has-side-effects\077");
lf[73]=C_h_intern(&lf[73],8,"assigned");
lf[74]=C_h_intern(&lf[74],10,"references");
lf[75]=C_h_intern(&lf[75],7,"unknown");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000#procedure can be inlined (globally)");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure can be inlined");
lf[79]=C_h_intern(&lf[79],1,"i");
lf[80]=C_h_intern(&lf[80],22,"\010compilerinline-global");
lf[81]=C_h_intern(&lf[81],14,"append-reverse");
lf[82]=C_h_intern(&lf[82],6,"gensym");
lf[83]=C_h_intern(&lf[83],1,"t");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[85]=C_h_intern(&lf[85],8,"split-at");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[87]=C_h_intern(&lf[87],20,"\004coreinline_allocate");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[89]=C_h_intern(&lf[89],21,"\010compilerllist-length");
lf[90]=C_h_intern(&lf[90],23,"\010compilerinline-locally");
lf[91]=C_h_intern(&lf[91],3,"yes");
lf[92]=C_h_intern(&lf[92],2,"no");
lf[93]=C_h_intern(&lf[93],24,"\010compilerinline-max-size");
lf[94]=C_h_intern(&lf[94],15,"\010compilerinline");
lf[95]=C_h_intern(&lf[95],9,"inlinable");
lf[96]=C_h_intern(&lf[96],6,"simple");
lf[97]=C_h_intern(&lf[97],11,"local-value");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[99]=C_h_intern(&lf[99],26,"\010compilervariable-visible\077");
lf[100]=C_h_intern(&lf[100],6,"global");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[104]=C_h_intern(&lf[104],5,"print");
lf[105]=C_h_intern(&lf[105],7,"newline");
lf[106]=C_h_intern(&lf[106],6,"print*");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[110]=C_h_intern(&lf[110],34,"\010compilerperform-pre-optimization!");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[112]=C_h_intern(&lf[112],24,"node-subexpressions-set!");
lf[113]=C_h_intern(&lf[113],7,"reverse");
lf[114]=C_h_intern(&lf[114],20,"node-parameters-set!");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[116]=C_h_intern(&lf[116],3,"not");
lf[117]=C_h_intern(&lf[117],10,"call-sites");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[119]=C_h_intern(&lf[119],24,"register-simplifications");
lf[120]=C_h_intern(&lf[120],19,"\003syshash-table-set!");
lf[121]=C_h_intern(&lf[121],38,"\010compilerreorganize-recursive-bindings");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[123]=C_h_intern(&lf[123],10,"fold-right");
lf[124]=C_h_intern(&lf[124],4,"fold");
lf[125]=C_h_intern(&lf[125],25,"\010compilertopological-sort");
lf[126]=C_h_intern(&lf[126],6,"lset<=");
lf[127]=C_h_intern(&lf[127],10,"filter-map");
lf[128]=C_h_intern(&lf[128],6,"filter");
lf[129]=C_h_intern(&lf[129],10,"append-map");
lf[130]=C_h_intern(&lf[130],28,"\010compilerscan-used-variables");
lf[131]=C_h_intern(&lf[131],8,"for-each");
lf[132]=C_h_intern(&lf[132],3,"map");
lf[133]=C_h_intern(&lf[133],4,"cons");
lf[134]=C_h_intern(&lf[134],27,"\010compilersubstitution-table");
lf[135]=C_h_intern(&lf[135],16,"\010compilerrewrite");
lf[136]=C_h_intern(&lf[136],28,"\010compilersimplify-named-call");
lf[137]=C_h_intern(&lf[137],37,"\010compilerinline-substitutions-enabled");
lf[138]=C_h_intern(&lf[138],11,"\004coreinline");
lf[139]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[141]=C_h_intern(&lf[141],6,"unsafe");
lf[142]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[143]=C_h_intern(&lf[143],6,"vector");
lf[144]=C_h_intern(&lf[144],14,"rest-parameter");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[146]=C_h_intern(&lf[146],11,"number-type");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[151]=C_h_intern(&lf[151],6,"fixnum");
lf[152]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[153]=C_h_intern(&lf[153],21,"\010compilerfold-boolean");
lf[154]=C_h_intern(&lf[154],6,"flonum");
lf[155]=C_h_intern(&lf[155],7,"generic");
lf[156]=C_h_intern(&lf[156],5,"cons*");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[158]=C_h_intern(&lf[158],9,"\004coreproc");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_h_intern(&lf[167],19,"\010compilerfold-inner");
lf[168]=C_h_intern(&lf[168],6,"remove");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[173]=C_h_intern(&lf[173],5,"fifth");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[175]=C_h_intern(&lf[175],13,"\010compilerbomb");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[177]=C_h_intern(&lf[177],34,"\010compilertransform-direct-lambdas!");
lf[178]=C_h_intern(&lf[178],19,"\010compilercopy-node!");
lf[179]=C_h_intern(&lf[179],16,"\004coredirect_call");
lf[180]=C_h_intern(&lf[180],4,"quit");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[182]=C_h_intern(&lf[182],15,"lset-difference");
lf[183]=C_h_intern(&lf[183],15,"node-class-set!");
lf[184]=C_h_intern(&lf[184],12,"\004corerecurse");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[186]=C_h_intern(&lf[186],4,"take");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[189]=C_h_intern(&lf[189],11,"\004corereturn");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[191]=C_h_intern(&lf[191],18,"\004coredirect_lambda");
lf[192]=C_h_intern(&lf[192],6,"cdaddr");
lf[193]=C_h_intern(&lf[193],6,"caaddr");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[196]=C_h_intern(&lf[196],6,"unzip1");
lf[197]=C_h_intern(&lf[197],16,"\003sysmake-promise");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[199]=C_h_intern(&lf[199],5,"boxed");
lf[200]=C_h_intern(&lf[200],15,"\004coreinline_ref");
lf[201]=C_h_intern(&lf[201],37,"\010compilerestimate-foreign-result-size");
lf[202]=C_h_intern(&lf[202],19,"\004coreinline_loc_ref");
lf[203]=C_h_intern(&lf[203],5,"lset=");
lf[204]=C_h_intern(&lf[204],6,"delete");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[206]=C_h_intern(&lf[206],32,"\010compilerperform-lambda-lifting!");
lf[207]=C_h_intern(&lf[207],23,"\003syshash-table-for-each");
lf[208]=C_h_intern(&lf[208],1,"+");
lf[209]=C_h_intern(&lf[209],17,"delete-duplicates");
lf[210]=C_h_intern(&lf[210],14,"\004coreprimitive");
lf[211]=C_h_intern(&lf[211],7,"delete!");
lf[212]=C_h_intern(&lf[212],11,"concatenate");
lf[213]=C_h_intern(&lf[213],5,"count");
lf[214]=C_h_intern(&lf[214],22,"\010compilerhide-variable");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[218]=C_h_intern(&lf[218],12,"pretty-print");
lf[219]=C_h_intern(&lf[219],1,"l");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[230]=C_h_intern(&lf[230],11,"make-vector");
lf[231]=C_h_intern(&lf[231],3,"var");
lf[232]=C_h_intern(&lf[232],1,"y");
lf[233]=C_h_intern(&lf[233],2,"d2");
lf[234]=C_h_intern(&lf[234],1,"z");
lf[235]=C_h_intern(&lf[235],2,"d3");
lf[236]=C_h_intern(&lf[236],2,"d1");
lf[237]=C_h_intern(&lf[237],2,"op");
lf[238]=C_h_intern(&lf[238],5,"clist");
lf[239]=C_h_intern(&lf[239],34,"\010compilermembership-test-operators");
lf[240]=C_h_intern(&lf[240],32,"\010compilermembership-unfold-limit");
lf[241]=C_h_intern(&lf[241],4,"var1");
lf[242]=C_h_intern(&lf[242],4,"var0");
lf[243]=C_h_intern(&lf[243],6,"const1");
lf[244]=C_h_intern(&lf[244],4,"var2");
lf[245]=C_h_intern(&lf[245],6,"const2");
lf[246]=C_h_intern(&lf[246],4,"rest");
lf[247]=C_h_intern(&lf[247],5,"body2");
lf[248]=C_h_intern(&lf[248],5,"body1");
lf[249]=C_h_intern(&lf[249],27,"\010compilereq-inline-operator");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[251]=C_h_intern(&lf[251],19,"\010compilerimmediate\077");
lf[252]=C_h_intern(&lf[252],5,"const");
lf[253]=C_h_intern(&lf[253],1,"n");
lf[254]=C_h_intern(&lf[254],7,"clauses");
lf[255]=C_h_intern(&lf[255],4,"body");
lf[256]=C_h_intern(&lf[256],1,"d");
lf[257]=C_h_intern(&lf[257],4,"more");
lf[258]=C_h_intern(&lf[258],4,"args");
lf[259]=C_h_intern(&lf[259],1,"a");
lf[260]=C_h_intern(&lf[260],1,"b");
lf[261]=C_h_intern(&lf[261],1,"c");
lf[262]=C_h_intern(&lf[262],4,"cdar");
C_register_lf2(lf,263,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3402,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3400 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3403 in k3400 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3406 in k3403 in k3400 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3417,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3419,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 140  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[230]+1)))(4,*((C_word*)lf[230]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3654,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! simplifications ...) */,t1);
t3=C_set_block_item(lf[23] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[24]+1 /* (set! perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3657,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[110]+1 /* (set! perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5145,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[119]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5386,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[9],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[260],lf[261]);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[256],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[15],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[256],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[261],t15);
t17=(C_word)C_a_i_cons(&a,2,lf[260],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[259],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11666,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t18,t20);
t22=(C_word)C_a_i_cons(&a,2,t14,t21);
/* optimizer.scm: 504  register-simplifications */
((C_proc4)C_retrieve_symbol_proc(lf[119]))(4,*((C_word*)lf[119]+1),t7,lf[15],t22);}

/* a11665 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_11666,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11674,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 510  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t7,C_retrieve(lf[134]),t3);}

/* k11672 in a11665 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11674,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_11679(t6,((C_word*)t0)[2],t2);}

/* loop in k11672 in a11665 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_11679(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11679,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11689,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11724,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 512  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[28]+1)))(3,*((C_word*)lf[28]+1),t4,t2);}}

/* k11722 in loop in k11672 in a11665 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11728,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 512  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[262]+1)))(3,*((C_word*)lf[262]+1),t2,((C_word*)t0)[2]);}

/* k11726 in k11722 in loop in k11672 in a11665 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 512  simplify-named-call */
((C_proc9)C_retrieve_symbol_proc(lf[136]))(9,*((C_word*)lf[136]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11687 in loop in k11672 in a11665 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11689,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[23]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11698,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_11698(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 517  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[23]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 519  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11679(t3,((C_word*)t0)[4],t2);}}

/* k11711 in k11687 in loop in k11672 in a11665 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[23]+1 /* (set! simplified-ops ...) */,t1);
t3=((C_word*)t0)[2];
f_11698(t3,t2);}

/* k11696 in k11687 in loop in k11672 in a11665 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_11698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[9],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[26],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,t4,t12);
t14=(C_word)C_a_i_cons(&a,2,lf[138],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[9],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[9],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[245],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[26],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t22,t26);
t28=(C_word)C_a_i_cons(&a,2,t19,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[138],t28);
t30=(C_word)C_a_i_cons(&a,2,lf[244],C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[9],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[247],t33);
t35=(C_word)C_a_i_cons(&a,2,t32,t34);
t36=(C_word)C_a_i_cons(&a,2,lf[233],t35);
t37=(C_word)C_a_i_cons(&a,2,lf[10],t36);
t38=(C_word)C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t29,t38);
t40=(C_word)C_a_i_cons(&a,2,t18,t39);
t41=(C_word)C_a_i_cons(&a,2,lf[11],t40);
t42=(C_word)C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=(C_word)C_a_i_cons(&a,2,lf[248],t42);
t44=(C_word)C_a_i_cons(&a,2,t17,t43);
t45=(C_word)C_a_i_cons(&a,2,lf[236],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[10],t45);
t47=(C_word)C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=(C_word)C_a_i_cons(&a,2,t14,t47);
t49=(C_word)C_a_i_cons(&a,2,t3,t48);
t50=(C_word)C_a_i_cons(&a,2,lf[11],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t52=(C_word)C_a_i_cons(&a,2,lf[233],t51);
t53=(C_word)C_a_i_cons(&a,2,lf[236],t52);
t54=(C_word)C_a_i_cons(&a,2,lf[247],t53);
t55=(C_word)C_a_i_cons(&a,2,lf[248],t54);
t56=(C_word)C_a_i_cons(&a,2,lf[245],t55);
t57=(C_word)C_a_i_cons(&a,2,lf[243],t56);
t58=(C_word)C_a_i_cons(&a,2,lf[237],t57);
t59=(C_word)C_a_i_cons(&a,2,lf[244],t58);
t60=(C_word)C_a_i_cons(&a,2,lf[241],t59);
t61=(C_word)C_a_i_cons(&a,2,lf[242],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11351,tmp=(C_word)a,a+=2,tmp);
t63=(C_word)C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=(C_word)C_a_i_cons(&a,2,t61,t63);
t65=(C_word)C_a_i_cons(&a,2,t50,t64);
t66=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t67=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t68=(C_word)C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t69=(C_word)C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=(C_word)C_a_i_cons(&a,2,lf[9],t69);
t71=(C_word)C_a_i_cons(&a,2,lf[252],C_SCHEME_END_OF_LIST);
t72=(C_word)C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=(C_word)C_a_i_cons(&a,2,lf[26],t72);
t74=(C_word)C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=(C_word)C_a_i_cons(&a,2,t70,t74);
t76=(C_word)C_a_i_cons(&a,2,t67,t75);
t77=(C_word)C_a_i_cons(&a,2,lf[138],t76);
t78=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t79=(C_word)C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=(C_word)C_a_i_cons(&a,2,lf[9],t79);
t81=(C_word)C_a_i_cons(&a,2,lf[253],C_SCHEME_END_OF_LIST);
t82=(C_word)C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t83=(C_word)C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=(C_word)C_a_i_cons(&a,2,lf[9],t83);
t85=(C_word)C_a_i_cons(&a,2,t84,lf[254]);
t86=(C_word)C_a_i_cons(&a,2,t81,t85);
t87=(C_word)C_a_i_cons(&a,2,lf[18],t86);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[255],t88);
t90=(C_word)C_a_i_cons(&a,2,t80,t89);
t91=(C_word)C_a_i_cons(&a,2,lf[256],t90);
t92=(C_word)C_a_i_cons(&a,2,lf[10],t91);
t93=(C_word)C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=(C_word)C_a_i_cons(&a,2,t77,t93);
t95=(C_word)C_a_i_cons(&a,2,t66,t94);
t96=(C_word)C_a_i_cons(&a,2,lf[11],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[254],C_SCHEME_END_OF_LIST);
t98=(C_word)C_a_i_cons(&a,2,lf[253],t97);
t99=(C_word)C_a_i_cons(&a,2,lf[255],t98);
t100=(C_word)C_a_i_cons(&a,2,lf[256],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[252],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[242],t101);
t103=(C_word)C_a_i_cons(&a,2,lf[237],t102);
t104=(C_word)C_a_i_cons(&a,2,lf[231],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11137,tmp=(C_word)a,a+=2,tmp);
t106=(C_word)C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=(C_word)C_a_i_cons(&a,2,t104,t106);
t108=(C_word)C_a_i_cons(&a,2,t96,t107);
t109=(C_word)C_a_i_cons(&a,2,lf[241],C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=(C_word)C_a_i_cons(&a,2,lf[68],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[257],C_SCHEME_END_OF_LIST);
t113=(C_word)C_a_i_cons(&a,2,t111,t112);
t114=(C_word)C_a_i_cons(&a,2,t109,t113);
t115=(C_word)C_a_i_cons(&a,2,lf[11],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[257],C_SCHEME_END_OF_LIST);
t117=(C_word)C_a_i_cons(&a,2,lf[241],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10841,tmp=(C_word)a,a+=2,tmp);
t119=(C_word)C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,t117,t119);
t121=(C_word)C_a_i_cons(&a,2,t115,t120);
t122=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t123=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,t123,lf[258]);
t125=(C_word)C_a_i_cons(&a,2,lf[138],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t127=(C_word)C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=(C_word)C_a_i_cons(&a,2,lf[9],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,lf[70],t129);
t131=(C_word)C_a_i_cons(&a,2,t128,t130);
t132=(C_word)C_a_i_cons(&a,2,lf[256],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[10],t132);
t134=(C_word)C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=(C_word)C_a_i_cons(&a,2,t125,t134);
t136=(C_word)C_a_i_cons(&a,2,t122,t135);
t137=(C_word)C_a_i_cons(&a,2,lf[11],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t139=(C_word)C_a_i_cons(&a,2,lf[70],t138);
t140=(C_word)C_a_i_cons(&a,2,lf[256],t139);
t141=(C_word)C_a_i_cons(&a,2,lf[258],t140);
t142=(C_word)C_a_i_cons(&a,2,lf[237],t141);
t143=(C_word)C_a_i_cons(&a,2,lf[231],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10705,tmp=(C_word)a,a+=2,tmp);
t145=(C_word)C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=(C_word)C_a_i_cons(&a,2,t143,t145);
t147=(C_word)C_a_i_cons(&a,2,t137,t146);
/* optimizer.scm: 522  register-simplifications */
((C_proc7)C_retrieve_symbol_proc(lf[119]))(7,*((C_word*)lf[119]+1),t2,lf[11],t65,t108,t121,t147);}

/* a10704 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_10705,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[249])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10739,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 657  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t9,t2,t3,lf[74]);}}

/* k10737 in a10704 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10739,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[36],lf[138],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[36],lf[10],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10841,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10851,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10851(t9,t1,t5,t4);}

/* loop1 in a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_10851(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10851,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_car(t9);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_slot(t12,C_fix(3));
t15=(C_word)C_slot(t12,C_fix(1));
t16=(C_word)C_eqp(t15,lf[68]);
if(C_truep(t16)){
t17=(C_word)C_i_car(t7);
t18=(C_word)C_a_i_cons(&a,2,t17,t2);
t19=(C_word)C_i_cadr(t9);
/* optimizer.scm: 603  loop1 */
t23=t1;
t24=t18;
t25=t19;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t17=(C_word)C_eqp(t15,lf[16]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10915,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t14,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 605  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),t18,t2);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k10913 in loop1 in a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10915,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10944,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_10944(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k10913 in loop1 in a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_10944(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10944,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10960,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[11]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11067,a[2]=t10,a[3]=t3,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t8);
/* optimizer.scm: 616  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t14,((C_word*)t0)[2],t15,lf[74]);}
else{
t14=t11;
f_10960(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_10960(t13,C_SCHEME_FALSE);}}

/* k11065 in loop2 in k10913 in loop1 in a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10960(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[16],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_10960(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_10960(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_10960(t2,C_SCHEME_FALSE);}}}

/* k10958 in loop2 in k10913 in loop1 in a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_10960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10960,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm: 620  loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_10944(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10997,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11007,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a11006 in k10958 in loop2 in k10913 in loop1 in a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11007(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11007,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a10996 in k10958 in loop2 in k10913 in loop1 in a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 625  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2]);}

/* k11003 in a10996 in k10958 in loop2 in k10913 in loop1 in a10840 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 625  reorganize-recursive-bindings */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a11136 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11137(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_11137,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[249])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11150,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 569  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k11148 in a11136 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11150,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11185,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 570  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11183 in k11148 in a11136 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11185,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11162,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 574  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11167 in k11183 in k11148 in a11136 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 575  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k11171 in k11167 in k11183 in k11148 in a11136 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 574  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[156]))(6,*((C_word*)lf[156]+1),((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11160 in k11183 in k11148 in a11136 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11162,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[18],((C_word*)t0)[2],t1));}

/* a11350 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_11351,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[249])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11364,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 542  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k11362 in a11350 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11364,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_11370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 543  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11368 in k11362 in a11350 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11370,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 544  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11414 in k11368 in k11362 in a11350 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11416,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11408,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 545  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[74]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11406 in k11414 in k11368 in k11362 in a11350 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11408,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 549  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11390 in k11406 in k11414 in k11368 in k11362 in a11350 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 550  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k11394 in k11390 in k11406 in k11414 in k11368 in k11362 in a11350 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11400,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 552  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k11398 in k11394 in k11390 in k11406 in k11414 in k11368 in k11362 in a11350 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_11400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11400,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[18],lf[250],t2));}

/* k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[9],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[232],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[233],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[15],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[9],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t12,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[235],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[15],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t9,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[70],t18);
t20=(C_word)C_a_i_cons(&a,2,lf[236],t19);
t21=(C_word)C_a_i_cons(&a,2,lf[10],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[231],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[234],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[232],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[70],t24);
t26=(C_word)C_a_i_cons(&a,2,lf[235],t25);
t27=(C_word)C_a_i_cons(&a,2,lf[233],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[236],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10554,tmp=(C_word)a,a+=2,tmp);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t28,t30);
t32=(C_word)C_a_i_cons(&a,2,t21,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[237],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,lf[26],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[70],t37);
t39=(C_word)C_a_i_cons(&a,2,t33,t38);
t40=(C_word)C_a_i_cons(&a,2,lf[138],t39);
t41=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t42=(C_word)C_a_i_cons(&a,2,lf[232],t41);
t43=(C_word)C_a_i_cons(&a,2,t40,t42);
t44=(C_word)C_a_i_cons(&a,2,lf[236],t43);
t45=(C_word)C_a_i_cons(&a,2,lf[10],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[234],C_SCHEME_END_OF_LIST);
t47=(C_word)C_a_i_cons(&a,2,lf[232],t46);
t48=(C_word)C_a_i_cons(&a,2,lf[238],t47);
t49=(C_word)C_a_i_cons(&a,2,lf[70],t48);
t50=(C_word)C_a_i_cons(&a,2,lf[237],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[236],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10383,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t45,t54);
/* optimizer.scm: 664  register-simplifications */
((C_proc5)C_retrieve_symbol_proc(lf[119]))(5,*((C_word*)lf[119]+1),t2,lf[10],t32,t55);}

/* a10382 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_10383,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[239]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[240]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10405,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 695  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k10403 in a10382 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10405,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10428,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10430,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10460,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 712  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t8,C_SCHEME_FALSE);}

/* k10458 in k10403 in a10382 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 704  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a10429 in k10403 in a10382 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10430(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10430,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10452,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 709  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t4,((C_word*)t0)[2]);}

/* k10450 in a10429 in k10403 in a10382 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 709  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}

/* k10454 in k10450 in a10429 in k10403 in a10382 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10456,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[36],lf[138],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 710  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t4,C_SCHEME_TRUE);}

/* k10446 in k10454 in k10450 in a10429 in k10403 in a10382 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10448,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[17],C_SCHEME_END_OF_LIST,t2));}

/* k10426 in k10403 in a10382 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10428,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[36],lf[10],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],lf[11],((C_word*)t0)[2],t4));}

/* a10553 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_10554,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[137]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10568,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 680  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k10566 in a10553 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10568,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[36],lf[17],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t4));}

/* k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5399,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1 /* (set! reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5401,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5727,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 807  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[230]+1)))(4,*((C_word*)lf[230]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5727,2,t0,t1);}
t2=C_mutate((C_word*)lf[134]+1 /* (set! substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[135]+1 /* (set! rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5729,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[136]+1 /* (set! simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5749,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[177]+1 /* (set! transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7621,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[206]+1 /* (set! perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8716,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8716,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8719,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8819,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9016,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9115,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9359,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9578,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9779,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10028,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10115,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10262,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1783 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t15,lf[20],lf[229]);}

/* k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1784 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_8719(t3,t2);}

/* k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10268,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1785 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[228]);}

/* k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1786 build-call-graph */
t3=((C_word*)t0)[2];
f_8819(t3,t2,((C_word*)t0)[3]);}

/* k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10274,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1787 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[227]);}

/* k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10277,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1788 eliminate */
t3=((C_word*)t0)[4];
f_9016(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10280,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10354,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1789 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,lf[219],lf[226]);}

/* k10352 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1789 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[218]))(3,*((C_word*)lf[218]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10280(2,t2,C_SCHEME_UNDEFINED);}}

/* k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1790 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[225]);}

/* k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10286,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1791 collect-accessibles */
t3=((C_word*)t0)[2];
f_9115(t3,t2,((C_word*)t0)[3]);}

/* k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10348,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1792 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,lf[219],lf[224]);}

/* k10346 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1792 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[218]))(3,*((C_word*)lf[218]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10289(2,t2,C_SCHEME_UNDEFINED);}}

/* k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1793 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[223]);}

/* k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10295,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10345,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1794 eliminate4 */
t4=((C_word*)t0)[3];
f_9359(t4,t3,((C_word*)t0)[2]);}

/* k10343 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10345,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9325,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_9325(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k10343 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9325(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9325,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9329,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9343,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1588 filter */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t4,t5,t2);}

/* a9342 in loop in k10343 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9343,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1588 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t1,t3,t4);}

/* a9348 in a9342 in loop in k10343 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9349(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9349,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k9327 in loop in k10343 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1592 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9325(t5,((C_word*)t0)[3],t1,t2);}}

/* k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10335,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10337,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t5=*((C_word*)lf[197]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a10336 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10337,2,t0,t1);}
/* optimizer.scm: 1795 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[196]))(3,*((C_word*)lf[196]+1),t1,((C_word*)t0)[2]);}

/* k10333 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1795 debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],lf[7],lf[222],t1);}

/* k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1796 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[221]);}

/* k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10304,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1797 compute-extra-variables */
t3=((C_word*)t0)[2];
f_9578(t3,t2,((C_word*)t0)[5]);}

/* k10302 in k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10328,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1798 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,lf[219],lf[220]);}

/* k10326 in k10302 in k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1798 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[218]))(3,*((C_word*)lf[218]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10307(2,t2,C_SCHEME_UNDEFINED);}}

/* k10305 in k10302 in k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1799 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[217]);}

/* k10308 in k10305 in k10302 in k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1800 extend-call-sites! */
t3=((C_word*)t0)[2];
f_10028(t3,t2,((C_word*)t0)[4]);}

/* k10311 in k10308 in k10305 in k10302 in k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1801 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[216]);}

/* k10314 in k10311 in k10308 in k10305 in k10302 in k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10319,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1802 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_10115(t3,t2,((C_word*)t0)[4]);}

/* k10317 in k10314 in k10311 in k10308 in k10305 in k10302 in k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1803 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[215]);}

/* k10320 in k10317 in k10314 in k10311 in k10308 in k10305 in k10302 in k10299 in k10296 in k10293 in k10290 in k10287 in k10284 in k10281 in k10278 in k10275 in k10272 in k10269 in k10266 in k10263 in k10260 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1804 reconstruct! */
t2=((C_word*)t0)[5];
f_9779(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_10115(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10115,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10121,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10121(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10121,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10140,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
/* for-each */
t13=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t10,((C_word*)((C_word*)t0)[2])[1],t12);}
else{
t10=(C_word)C_eqp(t4,lf[16]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10233,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
/* for-each */
t14=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,((C_word*)((C_word*)t0)[2])[1],t13);}
else{
/* for-each */
t11=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* k10231 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10233,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1778 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t3,((C_word*)t0)[2],lf[68]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10240 in k10231 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1779 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10243 in k10240 in k10231 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1780 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10138 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10140,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10145,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_10145(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop3291 in k10138 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_10145(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10145,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1768 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10168,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10183,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1770 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10186,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_10186(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_10186(t12,t11);}}}

/* k10184 in doloop3291 in k10138 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_10186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_10145(t4,((C_word*)t0)[2],t2,t3);}

/* k10181 in doloop3291 in k10138 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1770 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10166 in doloop3291 in k10138 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10175,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10179,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1771 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k10177 in k10166 in doloop3291 in k10138 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1771 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10173 in k10166 in doloop3291 in k10138 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1771 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_10028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10028,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10034,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10034(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10034,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[15]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10056,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[9],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10086,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10090,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
/* map */
t21=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[48]),t20);}
else{
t17=t11;
f_10056(2,t17,C_SCHEME_UNDEFINED);}}
else{
t14=t11;
f_10056(2,t14,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t10=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}

/* k10088 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1750 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[2],t1,t2);}

/* k10084 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10086,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1748 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10054 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9779(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9779,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9791,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9793,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
/* optimizer.scm: 1684 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t4,t5,t8,t2);}

/* a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9793,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9800,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1687 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t5,((C_word*)t0)[2],t4,lf[46]);}

/* k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1688 hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[214]))(3,*((C_word*)lf[214]+1),t2,((C_word*)t0)[5]);}

/* k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9803,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1689 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t3,t4);}

/* a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9812,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9819,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[82]),t6);}

/* k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9822,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1694 map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[132]+1)))(5,*((C_word*)lf[132]+1),t2,*((C_word*)lf[133]+1),((C_word*)t0)[5],t1);}

/* k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9903,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9918,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9918(3,t9,t2,t4);}

/* walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9918,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9937,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9944,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[9]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9961,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
/* optimizer.scm: 1723 rename */
t13=((C_word*)t0)[2];
f_9903(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[16]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9974,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9985,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 1725 rename */
t15=((C_word*)t0)[2];
f_9903(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[13]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1728 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t1,t13,t14);}
else{
/* for-each */
t13=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}}}

/* a10003 in walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10004,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10019,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10023,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k10021 in a10003 in walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1731 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10017 in a10003 in walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_10019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1732 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9918(3,t4,((C_word*)t0)[2],t3);}

/* k9983 in walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9985,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1725 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9972 in walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k9959 in walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9961,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1723 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9942 in walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1720 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9935 in walk in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9903(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9903,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k9823 in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1697 gensym */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t2,lf[83]);}

/* k9872 in k9823 in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9874,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9858,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9862,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1703 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9860 in k9872 in k9823 in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1703 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k9856 in k9872 in k9823 in k9820 in k9817 in a9811 in k9801 in k9798 in a9792 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9858,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[36],lf[13],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[36],lf[16],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[36],lf[11],((C_word*)t0)[2],t7));}

/* k9789 in reconstruct! in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9791,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1681 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9578,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9643,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9765,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a9764 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9765,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9643,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9645,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9720,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9725,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9725,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9763,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1670 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t4,((C_word*)t0)[2],t3,lf[46]);}

/* k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9763,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9587,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9587(3,t8,t4,t1);}

/* walk in k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9587,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9607,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1646 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[13]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9625,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1649 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t1,t11,t12);}
else{
/* for-each */
t11=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* a9624 in walk in k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9625,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9630,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1652 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k9628 in a9624 in walk in k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1653 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9587(3,t4,((C_word*)t0)[2],t3);}

/* k9605 in walk in k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k9583 in k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9585,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9739,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9741,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9755,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1676 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t5,t6,*((C_word*)lf[35]+1));}

/* k9753 in k9583 in k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1672 remove */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9740 in k9583 in k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9741,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k9737 in k9583 in k9761 in a9724 in k9718 in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9739,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9645,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9713,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1661 count */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a9712 in walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9713,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k9709 in walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9711,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9665,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a9698 in k9709 in walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9699,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1664 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9645(3,t4,t1,t3);}

/* k9663 in k9709 in walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9665,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9675,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9683,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9687,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9689,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a9688 in k9663 in k9709 in walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9689,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k9685 in k9663 in k9709 in walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1666 concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),((C_word*)t0)[2],t1);}

/* k9681 in k9663 in k9709 in walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1666 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9673 in k9663 in k9709 in walk in k9641 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9359,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9363,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9365,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9365(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9365(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9365,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[9]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9384,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9384(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[26]);
if(C_truep(t12)){
t13=t11;
f_9384(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[68]);
if(C_truep(t13)){
t14=t11;
f_9384(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[210]);
t15=t11;
f_9384(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[158])));}}}}

/* k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9384,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9395,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9395(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9446,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1611 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[15]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9481,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1617 call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a9550 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9551,3,t0,t1,t2);}
/* optimizer.scm: 1632 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9365(t3,t1,t2,((C_word*)t0)[2]);}

/* a9480 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9481,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[9],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9497,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9497(3,t12,t1,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9480 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9497,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9517,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9527,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1626 lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[126]))(5,*((C_word*)lf[126]+1),t7,*((C_word*)lf[35]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k9525 in loop in a9480 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9527,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_9517(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9531,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1628 delete! */
((C_proc5)C_retrieve_symbol_proc(lf[211]))(5,*((C_word*)lf[211]+1),t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[35]+1));}}

/* k9529 in k9525 in loop in a9480 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1629 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9515 in loop in a9480 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k9468 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9474 in k9468 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9475,3,t0,t1,t2);}
/* optimizer.scm: 1631 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9365(t3,t1,t2,((C_word*)t0)[2]);}

/* a9445 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9446(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9446,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9458,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1614 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t6,t2,((C_word*)t0)[2]);}

/* k9456 in a9445 in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1614 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9365(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9395(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9395,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9413,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1606 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9416,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1608 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9365(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9414 in loop in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1609 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9395(t4,((C_word*)t0)[2],t2,t3);}

/* k9411 in loop in k9382 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1606 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9365(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9361 in eliminate4 in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9115(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9115,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9119,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9121,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_9121(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9121(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9121,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[9]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_9140(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[26]);
if(C_truep(t12)){
t13=t11;
f_9140(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[68]);
if(C_truep(t13)){
t14=t11;
f_9140(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[210]);
t15=t11;
f_9140(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[158])));}}}}

/* k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9140,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[11]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9151,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9151(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[13]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9199,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9233,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1563 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_9199(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_9199(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9242,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a9241 in k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9242,3,t0,t1,t2);}
/* optimizer.scm: 1569 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9121(t3,t1,t2,((C_word*)t0)[2]);}

/* k9231 in k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9199(t3,t2);}

/* k9197 in k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9199,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9208,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1564 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t2,t3);}

/* a9207 in k9197 in k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9208,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9220,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1567 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t6,t2,((C_word*)t0)[2]);}

/* k9218 in a9207 in k9197 in k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1567 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9121(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9151(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9151,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9169,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1554 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9172,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1556 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9121(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9170 in loop in k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1557 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9151(t4,((C_word*)t0)[2],t2,t3);}

/* k9167 in loop in k9138 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1554 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9121(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9117 in collect-accessibles in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9016(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9016,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9022,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1524 remove */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t1,t4,t3);}

/* a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9022,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9056,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9066,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1534 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[196]))(3,*((C_word*)lf[196]+1),t6,t5);}

/* k9064 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9066,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9071,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9071(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k9064 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_9071(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9071,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9078,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1537 lset-difference */
((C_proc6)C_retrieve_symbol_proc(lf[182]))(6,*((C_word*)lf[182]+1),t5,*((C_word*)lf[35]+1),t6,t3,((C_word*)t0)[2]);}

/* k9076 in count in k9064 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9105,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1538 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[209]))(4,*((C_word*)lf[209]+1),t2,t3,*((C_word*)lf[35]+1));}

/* k9103 in k9076 in count in k9064 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9105,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1539 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9099 in k9103 in k9076 in count in k9064 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9101,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9091,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9093,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a9092 in k9099 in k9103 in k9076 in count in k9064 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9093,3,t0,t1,t2);}
/* optimizer.scm: 1540 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9071(t3,t1,t2,((C_word*)t0)[2]);}

/* k9089 in k9099 in k9103 in k9076 in count in k9064 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1540 fold */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[3],*((C_word*)lf[208]+1),((C_word*)t0)[2],t1);}

/* k9054 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9056,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1527 any */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),((C_word*)t0)[5],t3,t4);}}

/* a9033 in k9054 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9034,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9041,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1528 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t3,((C_word*)t0)[2],t2,lf[73]);}

/* k9039 in a9033 in k9054 in a9021 in eliminate in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_9041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8819(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8819,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8822,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8971,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8973,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t14=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a8972 in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8973(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8973,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8988,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8998,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1513 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t9,t6,t10);}

/* a8997 in a8972 in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8998,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
/* optimizer.scm: 1516 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8822(t7,t1,t6,t2);}

/* k8986 in a8972 in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8992,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1517 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k8990 in k8986 in a8972 in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8969 in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8822,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[9]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[16]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8847,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8872,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_8872(2,t16,t14);}
else{
/* optimizer.scm: 1489 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t15,((C_word*)t0)[2],t12,lf[100]);}}
else{
t12=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8890,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8890(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[13]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8944,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1501 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8961,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t9);}}}}

/* a8960 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8961,3,t0,t1,t2);}
/* optimizer.scm: 1504 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8822(t3,t1,t2,((C_word*)t0)[2]);}

/* a8943 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8944,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8956,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1503 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t6,t2,((C_word*)t0)[2]);}

/* k8954 in a8943 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1503 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8822(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8890(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8890,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8908,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1496 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8914,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1498 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_8822(t7,t5,t6,((C_word*)t0)[3]);}}

/* k8912 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1499 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8890(t4,((C_word*)t0)[2],t2,t3);}

/* k8906 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1496 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8822(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8870 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8872,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_8847(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_8847(t4,t3);}}

/* k8845 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8847,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8850,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_8850(t5,t4);}
else{
t3=t2;
f_8850(t3,C_SCHEME_UNDEFINED);}}

/* k8848 in k8845 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8850,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8855,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8854 in k8848 in k8845 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8855,3,t0,t1,t2);}
/* optimizer.scm: 1492 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8822(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8719,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8723,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8725,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1460 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[207]))(4,*((C_word*)lf[207]+1),t4,t5,((C_word*)t0)[2]);}

/* a8724 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8725,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[46],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[74],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[117],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8756,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[75],t3))){
t10=t9;
f_8756(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[13],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[100],t3))){
t13=t9;
f_8756(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_8756(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_8756(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k8754 in a8724 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8756,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1471 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8758 in k8754 in a8724 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8760,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1472 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k8762 in k8758 in k8754 in a8724 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8721 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7621,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8205,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7786,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7624,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8711,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1439 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t17,lf[20],lf[205]);}

/* k8709 in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8714,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1440 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7624(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8712 in k8709 in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_7624(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7624,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[54]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7649,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7734,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1231 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t14,((C_word*)t0)[2],t2,lf[75]);}
else{
t14=t13;
f_7649(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_7649(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[16]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
/* optimizer.scm: 1241 walk */
t24=t1;
t25=t13;
t26=t14;
t27=C_SCHEME_FALSE;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[11]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7760,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
/* optimizer.scm: 1243 walk */
t24=t14;
t25=t15;
t26=t16;
t27=t3;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t15=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t8);}}}}

/* a7779 in walk in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7780,3,t0,t1,t2);}
/* optimizer.scm: 1245 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7624(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k7758 in walk in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1244 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7624(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k7732 in walk in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7734,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_7649(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1233 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[46]);}
else{
t2=((C_word*)t0)[9];
f_7649(2,t2,C_SCHEME_FALSE);}}}

/* k7678 in k7732 in walk in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7680,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1234 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[74]);}
else{
t2=((C_word*)t0)[4];
f_7649(2,t2,C_SCHEME_FALSE);}}

/* k7684 in k7678 in k7732 in walk in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7686,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1235 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[117]);}
else{
t2=((C_word*)t0)[4];
f_7649(2,t2,C_SCHEME_FALSE);}}

/* k7690 in k7684 in k7678 in k7732 in walk in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7692,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1238 scan */
t9=((C_word*)t0)[4];
f_7786(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_7649(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_7649(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_7649(2,t2,C_SCHEME_FALSE);}}

/* k7647 in walk in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1239 transform */
t2=((C_word*)t0)[11];
f_8205(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1240 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7624(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_7786(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7786,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_7789,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8196,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1324 rec */
t18=((C_word*)t12)[1];
f_7789(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k8194 in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8196,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8203,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1325 delete */
((C_proc5)C_retrieve_symbol_proc(lf[204]))(5,*((C_word*)lf[204]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[35]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8201 in k8194 in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1325 lset= */
((C_proc5)C_retrieve_symbol_proc(lf[203]))(5,*((C_word*)lf[203]+1),((C_word*)t0)[3],*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_7789(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7789,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[9]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7838,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1256 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t14,((C_word*)t0)[9],t13,lf[199]);}
else{
t13=(C_word)C_eqp(t11,lf[54]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7856,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1264 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[87]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7893,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1273 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[191]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7927,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
/* optimizer.scm: 1276 scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[200]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7943,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
/* optimizer.scm: 1281 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[201]))(3,*((C_word*)lf[201]+1),t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[202]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
/* optimizer.scm: 1289 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[201]))(3,*((C_word*)lf[201]+1),t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[9],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8037,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8065,a[2]=t24,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_slot(t27,C_fix(1));
t30=(C_word)C_eqp(lf[9],t29);
if(C_truep(t30)){
t31=(C_word)C_slot(t27,C_fix(2));
t32=(C_word)C_i_car(t31);
t33=(C_word)C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[3])[1]);
t34=C_mutate(((C_word *)((C_word*)t0)[3])+1,t33);
t35=t28;
f_8065(t35,t34);}
else{
t31=t28;
f_8065(t31,C_SCHEME_UNDEFINED);}}
else{
t27=t24;
f_8037(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_8037(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[179]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8126,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1315 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[16]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
/* optimizer.scm: 1316 rec */
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[11]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8159,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
/* optimizer.scm: 1318 rec */
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8183,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1320 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t1,t22,t9);}}}}}}}}}}}

/* a8182 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8183,3,t0,t1,t2);}
/* optimizer.scm: 1320 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7789(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8157 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8159,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8170,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1319 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8168 in k8157 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1319 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7789(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a8125 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8126,3,t0,t1,t2);}
/* optimizer.scm: 1315 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7789(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8063 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_8037(t3,C_SCHEME_TRUE);}

/* k8035 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8037,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8042,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1308 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8041 in k8035 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8042,3,t0,t1,t2);}
/* optimizer.scm: 1308 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7789(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7982 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7984,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7990,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7990(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_7990(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_7990(t7,C_SCHEME_TRUE);}}}

/* k7988 in k7982 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_7990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7990,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7995,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1295 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7994 in k7988 in k7982 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7995,3,t0,t1,t2);}
/* optimizer.scm: 1295 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7789(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7941 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7943,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7949,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7949(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_7949(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_7949(t7,C_SCHEME_TRUE);}}}

/* k7947 in k7941 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_7949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7949,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7954,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1287 every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7953 in k7947 in k7941 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7954,3,t0,t1,t2);}
/* optimizer.scm: 1287 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7789(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k7925 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7927,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1278 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7921 in k7925 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a7892 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7893(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7893,3,t0,t1,t2);}
/* optimizer.scm: 1273 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7789(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a7855 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7856,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7872,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1268 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t8,t2,((C_word*)t0)[2]);}

/* k7870 in a7855 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1268 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7789(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k7836 in rec in scan in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8205(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8205,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8699,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8701,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t11=*((C_word*)lf[197]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1330 debugging */
((C_proc6)C_retrieve_symbol_proc(lf[6]))(6,*((C_word*)lf[6]+1),t8,lf[7],lf[198],t3,t7);}}

/* a8700 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8701,2,t0,t1);}
/* optimizer.scm: 1329 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[196]))(3,*((C_word*)lf[196]+1),t1,((C_word*)t0)[2]);}

/* k8697 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1329 debugging */
((C_proc7)C_retrieve_symbol_proc(lf[6]))(7,*((C_word*)lf[6]+1),((C_word*)t0)[4],lf[7],lf[195],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8209,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8219,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1335 get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[117]);}

/* k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8219,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t5=(C_word)C_i_length(((C_word*)t0)[11]);
t6=(C_word)C_eqp(t5,C_fix(4));
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
t8=t4;
f_8225(t8,(C_word)C_i_listp(t7));}
else{
t7=t4;
f_8225(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8225(t5,C_SCHEME_FALSE);}}

/* k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_8225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8225,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1339 caaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[193]+1)))(3,*((C_word*)lf[193]+1),t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 1437 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),((C_word*)t0)[10],lf[194],((C_word*)t0)[13]);}}

/* k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1340 cdaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[192]+1)))(3,*((C_word*)lf[192]+1),t2,((C_word*)t0)[14]);}

/* k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8234,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1344 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t4,((C_word*)t0)[5],lf[191]);}

/* k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8243,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8416,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_8416(3,t9,t2,t5);}

/* rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8416,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[15]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[9],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1358 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8591,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1383 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t20,t2,lf[189]);}
else{
/* optimizer.scm: 1386 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t1,lf[190]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[11]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8638,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1391 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
/* for-each */
t13=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}
else{
/* for-each */
t11=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}}

/* k8636 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8638,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1392 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t3,t4,((C_word*)t0)[3]);}

/* k8639 in k8636 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1393 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8416(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8589 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1384 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8592 in k8589 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1385 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8460,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8469,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_8469(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1361 quit */
((C_proc4)C_retrieve_symbol_proc(lf[180]))(4,*((C_word*)lf[180]+1),t5,lf[185],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8515,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_8515(2,t14,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1372 quit */
((C_proc4)C_retrieve_symbol_proc(lf[180]))(4,*((C_word*)lf[180]+1),t10,lf[187],((C_word*)t0)[4]);}}
else{
/* optimizer.scm: 1381 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),((C_word*)t0)[8],lf[188],((C_word*)t0)[11]);}}}

/* k8513 in k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1375 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t2,((C_word*)t0)[3],lf[11]);}

/* k8516 in k8513 in k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8545,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
/* optimizer.scm: 1376 take */
((C_proc4)C_retrieve_symbol_proc(lf[186]))(4,*((C_word*)lf[186]+1),t3,t5,C_fix(1));}

/* k8543 in k8516 in k8513 in k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1376 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8519 in k8516 in k8513 in k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8524,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[36],lf[184],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 1377 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2],t6);}

/* k8522 in k8519 in k8516 in k8513 in k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1380 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8416(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8467 in k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1364 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[183]))(4,*((C_word*)lf[183]+1),t2,((C_word*)t0)[3],lf[184]);}

/* k8470 in k8467 in k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1365 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),t2,((C_word*)t0)[3],t3);}

/* k8473 in k8470 in k8467 in k8458 in rec in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1366 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8246,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8339,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8396,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8398,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1414 lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[182]))(5,*((C_word*)lf[182]+1),t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a8397 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8398,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k8394 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8338 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8339,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8349,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[3],t7);
if(C_truep(t8)){
t9=t5;
f_8349(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1404 quit */
((C_proc4)C_retrieve_symbol_proc(lf[180]))(4,*((C_word*)lf[180]+1),t5,lf[181],((C_word*)t0)[2]);}}

/* k8347 in a8338 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_record(&a,4,lf[36],lf[179],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t2,t7);
/* optimizer.scm: 1407 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k8244 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8246,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[36],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8258,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1419 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8256 in k8244 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8297,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1421 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8296 in k8256 in k8244 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8297,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[36],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[36],lf[11],t5,t13));}

/* k8259 in k8256 in k8244 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8264,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1430 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t2,t1,((C_word*)t0)[2]);}

/* k8262 in k8259 in k8256 in k8244 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8269,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8268 in k8262 in k8259 in k8256 in k8244 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8269,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8276,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8295,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1434 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t5);}

/* k8293 in a8268 in k8262 in k8259 in k8256 in k8244 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8295,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1434 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8274 in a8268 in k8262 in k8259 in k8256 in k8244 in k8241 in k8238 in k8232 in k8229 in k8223 in k8217 in k8207 in transform in ##compiler#transform-direct-lambdas! in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_8276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8276,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[36],lf[68],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t2,t3));}

/* ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5749,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5806,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);
case C_fix(2):
if(C_truep(C_retrieve(lf[137]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5914,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t13,t12,lf[45]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[137]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6012,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[137]))){
if(C_truep(C_retrieve(lf[141]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6050,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t12,t11,lf[45]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[137]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6106,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[141]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[137]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6193,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t14,t13,lf[45]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[141]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[137]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t11,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6258,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t15,t14,lf[45]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[137]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6313,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[137]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6334,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[137]))){
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[141]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6478,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t12,t11,lf[45]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[137]))){
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[141]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6565,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t12,t11,lf[45]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[137]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6624,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[137]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6694,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[137]))){
t9=(C_word)C_i_cadr(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6753,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t13,t12,lf[45]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[137]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=C_retrieve(lf[141]);
t12=(C_truep(t11)?t11:(C_word)C_i_cadddr(t7));
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6830,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t14,t13,lf[45]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[137]))){
t12=(C_word)C_i_not(t9);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,t9));
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6917,a[2]=t10,a[3]=t11,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t15,t14,lf[45]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[137]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6990,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t13,t12,lf[45]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[137]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7052,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[137]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7081,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[141]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[137]))){
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t9,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7223,a[2]=t8,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t15,t14,lf[45]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[137]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7290,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[137]))){
t12=(C_word)C_eqp(t10,t9);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7438,a[2]=t11,a[3]=t8,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t14,t13,lf[45]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[137]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7495,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t10,t9,lf[45]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1206 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t1,lf[176]);}}

/* k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7495,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7510,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7517,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1192 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7521,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a7528 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7529,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7537,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7543,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_7543(t9,t4,t3,t5);}

/* loop in a7528 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_7543(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7543,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7563,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 816  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5774,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_5774(t8,(C_word)C_eqp(lf[26],t7));}
else{
t7=t6;
f_5774(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7592,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1204 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k7590 in loop in a7528 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7592,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5772 in loop in a7528 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5774(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 817  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 818  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k7561 in loop in a7528 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7567,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1202 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7543(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k7565 in k7561 in loop in a7528 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7567,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7535 in a7528 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1195 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7522 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7523,2,t0,t1);}
/* optimizer.scm: 1194 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7519 in k7515 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1191 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[156]))(5,*((C_word*)lf[156]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7508 in k7493 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7510,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t1));}

/* k7436 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7438,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[141]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[146]),lf[151]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7470,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1173 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
t9=t4;
f_7457(t9,(C_word)C_a_i_record(&a,4,lf[36],lf[87],t7,t8));}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7468 in k7436 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7470,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_7457(t4,(C_word)C_a_i_record(&a,4,lf[36],lf[138],t2,t3));}

/* k7455 in k7436 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_7457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7457,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[174],t2));}

/* k7288 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7290,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7296,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1133 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7294 in k7288 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7296,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[141]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7305,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7380,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1137 remove */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t4,t5,((C_word*)t0)[2]);}

/* a7379 in k7294 in k7288 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7380,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[26],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7303 in k7294 in k7288 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7305,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7321,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1142 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[171],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7347,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1150 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t3,t4,t1);}}}

/* a7348 in k7303 in k7294 in k7288 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7349,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[146]),lf[151]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[36],lf[138],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[36],lf[87],t5,t6));}}

/* k7345 in k7303 in k7294 in k7288 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7347,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[172],t2));}

/* k7319 in k7303 in k7294 in k7288 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7321,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[170],t2));}

/* k7221 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7223,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7236,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7251,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7250 in k7221 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7251,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7263,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1121 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t4,t5);}

/* k7261 in a7250 in k7221 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7263,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1120 append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[12]+1)))(5,*((C_word*)lf[12]+1),((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7240 in k7221 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7241,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1119 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t1,((C_word*)t0)[2],t2);}

/* k7234 in k7221 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7236,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[36],lf[138],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[169],t3));}

/* k7079 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7081,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[141]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7090,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7162,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1088 remove */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7161 in k7079 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7162,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[26],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7088 in k7079 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7090,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7106,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1093 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[165],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[146]),lf[151]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7141,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7143,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1101 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a7142 in k7088 in k7079 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7143(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7143,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[36],lf[138],t4,t5));}

/* k7139 in k7088 in k7079 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7141,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[166],t2));}

/* k7104 in k7088 in k7079 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[164],t2));}

/* k7050 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7052,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1075 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7060 in k7050 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7062,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[163],t2));}

/* k6988 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6990,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[141]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=t2;
f_7010(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_7010(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7008 in k6988 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_7010(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7010,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,4,lf[36],lf[138],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[162],t6));}

/* k6915 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6917,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[141]));
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6947,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=t5;
f_6947(t7,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=t5;
f_6947(t8,(C_word)C_fixnum_times(((C_word*)t0)[2],t7));}
else{
t7=t5;
f_6947(t7,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6945 in k6915 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_6947(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6947,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[36],lf[87],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[161],t5));}

/* k6828 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6830,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[146]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6842,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1026 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[146]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[160],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6847 in k6828 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1026 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[156]))(5,*((C_word*)lf[156]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6840 in k6828 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t1));}

/* k6751 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6753,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[146]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[141]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[141]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[36],lf[138],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[159],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6692 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6694,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[141]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_6709(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_6709(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6707 in k6692 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_6709(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6709,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6712,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[36],lf[158],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 999  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[156]))(5,*((C_word*)lf[156]+1),t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6710 in k6707 in k6692 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6712,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t1));}

/* k6622 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6624,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[141]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[157],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6660,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6667,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 989  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6665 in k6622 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 989  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[156]))(5,*((C_word*)lf[156]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6658 in k6622 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6660,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t1));}

/* k6563 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6577(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_6577(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6575 in k6563 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_6577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6577,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6583,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 974  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6588 in k6575 in k6563 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 974  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[156]))(5,*((C_word*)lf[156]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6581 in k6575 in k6563 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6583,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t1));}

/* k6476 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6478,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6500,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 956  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6498 in k6476 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6500,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 959  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,t4);}

/* k6506 in k6498 in k6476 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6512,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 961  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t2,t4);}
else{
t4=t2;
f_6512(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k6510 in k6506 in k6498 in k6476 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6512,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t2));}

/* k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 927  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6356,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[141]))){
t4=(C_word)C_eqp(C_retrieve(lf[146]),lf[155]);
t5=t3;
f_6356(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6356(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6354 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_6356(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6356,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6359(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[146]),lf[151]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_6359(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[146]),lf[154]);
t6=t2;
f_6359(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k6357 in k6354 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_6359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6359,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6418,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6417 in k6357 in k6354 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6418,3,t0,t1,t2);}
/* optimizer.scm: 931  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t1);}

/* k6360 in k6357 in k6354 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6365,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[48]),t1);}

/* k6363 in k6360 in k6357 in k6354 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6370,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[146]),lf[151]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 943  fold-boolean */
((C_proc4)C_retrieve_symbol_proc(lf[153]))(4,*((C_word*)lf[153]+1),t6,t7,t1);}

/* a6395 in k6363 in k6360 in k6357 in k6354 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6396,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],lf[138],((C_word*)t0)[2],t4));}

/* k6392 in k6363 in k6360 in k6357 in k6354 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6394,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[152],t2);
/* optimizer.scm: 933  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[123]))(6,*((C_word*)lf[123]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6369 in k6363 in k6360 in k6357 in k6354 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6370,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[36],lf[11],t5,t6));}

/* k6348 in k6332 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6350,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[150],t2));}

/* k6311 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6256 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 913  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6280 in k6256 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6282,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 912  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6269 in k6256 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6271,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[36],lf[138],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[149],t3));}

/* k6191 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[36],lf[138],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[36],lf[138],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[148],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6104 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[146])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 889  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6146 in k6104 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6148,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[36],lf[138],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[147],t4));}

/* k6048 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6050,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6063,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 871  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6061 in k6048 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6063,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 874  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,t4);}

/* k6069 in k6061 in k6048 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6071,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t3));}

/* k6010 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6012,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 862  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6020 in k6010 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6022,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[145],t2));}

/* k5912 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5914,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[141]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5942,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(lf[9],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5971,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t4,C_fix(2));
t12=(C_word)C_i_car(t11);
/* optimizer.scm: 853  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t10,((C_word*)t0)[2],t12,lf[144]);}
else{
t10=t7;
f_5942(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_5942(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5969 in k5912 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5942(t2,(C_word)C_eqp(lf[143],t1));}

/* k5940 in k5912 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5942,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
f_5939(t4,(C_word)C_a_i_record(&a,4,lf[36],lf[138],t2,t3));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
f_5939(t5,(C_word)C_a_i_record(&a,4,lf[36],lf[138],t3,t4));}}

/* k5937 in k5912 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5939(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5939,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[142],t2));}

/* k5804 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5806,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[9],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[9],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5869,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 832  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_5809(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_5809(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_5809(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_5809(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5867 in k5804 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5869,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5809(t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[140],t2));}

/* k5807 in k5804 in ##compiler#simplify-named-call in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[137]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[36],lf[138],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[139],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##compiler#rewrite in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5729(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5729r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5729r(t0,t1,t2,t3);}}

static void C_ccall f_5729r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5733,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 810  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t4,C_retrieve(lf[134]),t2);}

/* k5731 in ##compiler#rewrite in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5733,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5743,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 811  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,t2,t4);}

/* k5741 in k5731 in ##compiler#rewrite in k5725 in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 811  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),((C_word*)t0)[3],C_retrieve(lf[134]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5401,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5405,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 722  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[132]+1)))(5,*((C_word*)lf[132]+1),t7,*((C_word*)lf[133]+1),t2,t3);}

/* k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5407,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 733  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[131]+1)))(5,*((C_word*)lf[131]+1),t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5713 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5714,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5719,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5723,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 734  scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t5,t3,((C_word*)t0)[2]);}

/* k5721 in a5713 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 734  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5717 in a5713 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a5655 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5656,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5666,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5688,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 743  filter */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t3,t4,((C_word*)t0)[2]);}}

/* a5687 in a5655 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5688,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5701,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 744  find-path */
t5=((C_word*)t0)[2];
f_5407(t5,t4,((C_word*)t0)[3],t2);}}

/* k5699 in a5687 in a5655 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 744  find-path */
t2=((C_word*)t0)[5];
f_5407(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5664 in a5655 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5670,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5682,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 746  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t3);}

/* k5680 in k5664 in a5655 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5682,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 746  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k5668 in k5664 in a5655 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5670,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5674,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 747  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[12]+1)))(5,*((C_word*)lf[12]+1),t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k5672 in k5668 in k5664 in a5655 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5455,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5458,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a5596 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5597,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5604,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 756  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t4,t5,t6);}

/* a5639 in a5596 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5640,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5646,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 757  filter */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t1,t3,((C_word*)t0)[2]);}

/* a5645 in a5639 in a5596 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5646,3,t0,t1,t2);}
/* optimizer.scm: 757  find-path */
t3=((C_word*)t0)[3];
f_5407(t3,t1,((C_word*)t0)[2],t2);}

/* k5602 in a5596 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5608,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5612,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5614,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 762  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[127]))(4,*((C_word*)lf[127]+1),t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a5613 in k5602 in a5596 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5614,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5627,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 763  lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[126]))(5,*((C_word*)lf[126]+1),t4,*((C_word*)lf[35]+1),t5,((C_word*)t0)[2]);}}

/* k5625 in a5613 in k5602 in a5596 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k5610 in k5602 in a5596 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 760  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5606 in k5602 in a5596 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5461,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 769  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[125]))(4,*((C_word*)lf[125]+1),t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[35]+1));}

/* k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5464,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 774  fold */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t4,t5,((C_word*)t0)[2],t1);}

/* a5480 in k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5481,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5494,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_5494(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_5494(t9,C_SCHEME_FALSE);}}

/* k5492 in a5480 in k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5494(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5494,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[36],lf[11],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5517,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5537,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 788  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5536 in k5492 in a5480 in k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5537,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5569,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 791  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[82]))(2,*((C_word*)lf[82]+1),t4);}

/* k5567 in a5536 in k5492 in a5480 in k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5569,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[36],lf[16],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[36],lf[11],t2,t8));}

/* k5533 in k5492 in a5480 in k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 783  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[123]))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5516 in k5492 in a5480 in k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5517,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[36],lf[68],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[36],lf[11],t4,t6));}

/* k5462 in k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5464,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5473,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 800  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[122],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 802  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k5471 in k5462 in k5459 in k5456 in k5453 in k5450 in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 801  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5407(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5407,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5413,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5413(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5413(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5413,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5437,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 730  any */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t1,t8,t5);}}}

/* a5436 in find in find-path in k5403 in ##compiler#reorganize-recursive-bindings in k5397 in k5394 in k5391 in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5437,3,t0,t1,t2);}
/* optimizer.scm: 730  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5413(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_5386r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5386r(t0,t1,t2,t3);}}

static void C_ccall f_5386r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 501  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t1,C_retrieve(lf[22]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5145,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5148,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5152,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5159,a[2]=t9,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 453  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t10,lf[20],lf[118]);}

/* k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5162,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5174,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t3,lf[116],lf[45]);}

/* k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5174,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5381,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 492  test */
t4=((C_word*)t0)[3];
f_5152(t4,t3,lf[116],lf[117]);}
else{
t2=((C_word*)t0)[2];
f_5162(2,t2,C_SCHEME_UNDEFINED);}}

/* k5379 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5179,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5192,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5370,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 462  test */
t10=((C_word*)t0)[2];
f_5152(t10,t9,t7,lf[75]);}

/* k5368 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5192(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 462  test */
t2=((C_word*)t0)[3];
f_5152(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[46]);}}

/* k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 463  test */
t3=((C_word*)t0)[3];
f_5152(t3,t2,((C_word*)t0)[2],lf[74]);}

/* k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[4]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=t2;
f_5201(t8,(C_word)C_eqp(lf[54],t7));}
else{
t7=t2;
f_5201(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5201(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5201(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5201(t3,C_SCHEME_FALSE);}}

/* k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5201(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5201,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_5216(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_5216(t8,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5214 in k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5216,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5222,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 474  test */
t4=((C_word*)t0)[2];
f_5152(t4,t3,t2,lf[74]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5220 in k5214 in k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_5228(t6,(C_word)C_eqp(lf[10],t5));}
else{
t5=t2;
f_5228(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5228(t3,C_SCHEME_FALSE);}}

/* k5226 in k5220 in k5214 in k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5228,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[9],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_5237(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_5237(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5235 in k5226 in k5220 in k5214 in k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5237,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 486  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[114]))(4,*((C_word*)lf[114]+1),t4,((C_word*)t0)[2],lf[115]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5242 in k5235 in k5226 in k5220 in k5214 in k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 487  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2],t3);}

/* k5245 in k5242 in k5235 in k5226 in k5220 in k5214 in k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 490  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),t4,t5);}

/* k5263 in k5245 in k5242 in k5235 in k5226 in k5220 in k5214 in k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 488  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5248 in k5245 in k5242 in k5235 in k5226 in k5220 in k5214 in k5199 in k5193 in k5190 in a5178 in k5172 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 491  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5148(((C_word*)t0)[2]));}

/* k5160 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 494  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[111],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5165(2,t4,C_SCHEME_UNDEFINED);}}

/* k5163 in k5160 in k5157 in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5152(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5152,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 451  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static C_word C_fcall f_5148(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[66],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3657,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3660,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3666,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3686,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3690,a[2]=t3,a[3]=t20,a[4]=t18,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3782,a[2]=t25,a[3]=t17,a[4]=t23,a[5]=t18,a[6]=t7,a[7]=t20,a[8]=t15,tmp=(C_word)a,a+=9,tmp));
t29=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3996,a[2]=t11,a[3]=t3,a[4]=t27,a[5]=t23,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t18,tmp=(C_word)a,a+=10,tmp));
t30=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5030,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5049,a[2]=t23,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 419  perform-pre-optimization! */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t31,t2,t3);}

/* k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 420  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 422  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,lf[20],lf[109]);}}

/* k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=C_set_block_item(lf[23] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 424  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3782(3,t4,t3,((C_word*)t0)[2]);}

/* k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 425  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[108],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5062(2,t3,C_SCHEME_UNDEFINED);}}

/* k5060 in k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5098,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[23])))){
/* optimizer.scm: 426  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,lf[7],lf[107]);}
else{
t4=t3;
f_5098(2,t4,C_SCHEME_FALSE);}}

/* k5096 in k5060 in k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5098,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5103,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[23]));}
else{
t2=((C_word*)t0)[2];
f_5065(2,t2,C_SCHEME_UNDEFINED);}}

/* a5102 in k5096 in k5060 in k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5107,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 429  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[106]+1)))(4,*((C_word*)lf[106]+1),t3,C_make_character(9),t4);}

/* k5105 in a5102 in k5096 in k5060 in k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 431  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[104]+1)))(4,*((C_word*)lf[104]+1),((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 432  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[105]+1)))(2,*((C_word*)lf[105]+1),((C_word*)t0)[2]);}}

/* k5063 in k5060 in k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 434  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[103],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5068(2,t4,C_SCHEME_UNDEFINED);}}

/* k5066 in k5063 in k5060 in k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 435  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[102],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5071(2,t4,C_SCHEME_UNDEFINED);}}

/* k5069 in k5066 in k5063 in k5060 in k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 436  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[101],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5074(2,t4,C_SCHEME_UNDEFINED);}}

/* k5072 in k5069 in k5066 in k5063 in k5060 in k5057 in k5053 in k5047 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 437  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_5030(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5030,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5034,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k5032 in walk-generic in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5040,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 415  every */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),t2,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1);}

/* k5038 in k5032 in walk-generic in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5040,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[36],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3996,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[9]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[7],a[3]=t6,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_4021(t14,t1,t10);}
else{
t10=(C_word)C_eqp(t8,lf[11]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4096,a[2]=t11,a[3]=((C_word*)t0)[8],a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 238  test */
t13=((C_word*)t0)[8];
f_3660(t13,t12,t11,lf[50]);}
else{
t11=(C_word)C_eqp(t8,lf[54]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4153,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t6,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 248  test */
t15=((C_word*)t0)[8];
f_3660(t15,t13,t14,lf[63]);}
else{
t12=(C_word)C_eqp(t8,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t4);
t14=(C_word)C_slot(t13,C_fix(1));
t15=(C_word)C_eqp(t14,lf[9]);
if(C_truep(t15)){
t16=(C_word)C_slot(t13,C_fix(2));
t17=(C_word)C_i_car(t16);
t18=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[2],a[3]=t13,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t8,a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=t17,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4896,a[2]=t17,a[3]=((C_word*)t0)[8],a[4]=t18,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 286  test */
t20=((C_word*)t0)[8];
f_3660(t20,t19,t17,lf[75]);}
else{
t16=(C_word)C_eqp(t14,lf[54]);
if(C_truep(t16)){
if(C_truep((C_word)C_i_car(t6))){
/* optimizer.scm: 393  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_5030(t17,t1,t2,t8,t6,t4);}
else{
t17=(C_word)C_i_cdr(t6);
t18=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4921,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t20=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
/* optimizer.scm: 395  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_5030(t17,t1,t2,t8,t6,t4);}}}
else{
t13=(C_word)C_eqp(t8,lf[16]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t6);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t14,a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 399  test */
t16=((C_word*)t0)[8];
f_3660(t16,t15,t14,lf[52]);}
else{
/* optimizer.scm: 411  walk-generic */
t14=((C_word*)((C_word*)t0)[4])[1];
f_5030(t14,t1,t2,t8,t6,t4);}}}}}}

/* k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_4949(2,t3,t1);}
else{
/* optimizer.scm: 399  test */
t3=((C_word*)t0)[2];
f_3660(t3,t2,((C_word*)t0)[7],lf[50]);}}

/* k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4949,2,t0,t1);}
if(C_truep(t1)){
t2=f_3686(((C_word*)t0)[9]);
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[68],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 402  test */
t4=((C_word*)t0)[2];
f_3660(t4,t3,((C_word*)t0)[7],lf[100]);}}

/* k5020 in k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_4990(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5018,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 403  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[99]))(3,*((C_word*)lf[99]+1),t4,((C_word*)t0)[2]);}}

/* k5016 in k5020 in k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4990(t2,(C_word)C_i_not(t1));}

/* k4988 in k5020 in k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4990,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5011,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 404  test */
t3=((C_word*)t0)[3];
f_3660(t3,t2,((C_word*)t0)[2],lf[74]);}
else{
t2=((C_word*)t0)[6];
f_4961(t2,C_SCHEME_FALSE);}}

/* k5009 in k4988 in k5020 in k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4961(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 405  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t2,t3,((C_word*)t0)[2]);}}

/* k5001 in k5009 in k4988 in k5020 in k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4961(t2,(C_word)C_i_not(t1));}

/* k4959 in k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4961,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3686(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 407  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t3,lf[7],lf[98],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 409  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3782(3,t4,t2,t3);}}

/* k4978 in k4959 in k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4980,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[16],((C_word*)t0)[2],t2));}

/* k4965 in k4959 in k4947 in k4944 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[68],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* k4919 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4921,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t1));}

/* k4894 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4329(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 287  test */
t3=((C_word*)t0)[3];
f_3660(t3,t2,((C_word*)t0)[2],lf[46]);}}

/* k4884 in k4894 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4329(2,t2,t1);}
else{
/* optimizer.scm: 288  test */
t2=((C_word*)t0)[3];
f_3660(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[97]);}}

/* k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=t1,tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm: 290  test */
t4=((C_word*)t0)[4];
f_3660(t4,t3,((C_word*)t0)[10],lf[52]);}

/* k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t3,a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 293  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[66]))(5,*((C_word*)lf[66]+1),t4,((C_word*)t0)[11],((C_word*)t0)[12],t3);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[67])))){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4380,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(lf[9],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 301  test */
t10=((C_word*)t0)[4];
f_3660(t10,t9,t7,lf[75]);}
else{
t8=t3;
f_4380(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_4380(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4380(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_word)C_slot(((C_word*)t0)[16],C_fix(1));
t4=t2;
f_4519(t4,(C_word)C_eqp(lf[54],t3));}
else{
t3=t2;
f_4519(t3,C_SCHEME_FALSE);}}}}

/* k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4519,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 317  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t3,t4);}
else{
/* optimizer.scm: 390  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_5030(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4530,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[90]))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[17],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 322  test */
t8=((C_word*)t0)[3];
f_3660(t8,t7,t5,lf[96]);}
else{
t7=t6;
f_4540(t7,C_SCHEME_FALSE);}}

/* k4840 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 323  test */
t3=((C_word*)t0)[2];
f_3660(t3,t2,((C_word*)t0)[3],lf[95]);}
else{
t2=((C_word*)t0)[5];
f_4540(t2,C_SCHEME_FALSE);}}

/* k4846 in k4840 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t2,((C_word*)t0)[2],lf[94]);}
else{
t2=((C_word*)t0)[4];
f_4540(t2,C_SCHEME_FALSE);}}

/* k4849 in k4846 in k4840 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(t1,lf[91]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4540(t3,C_SCHEME_TRUE);}
else{
t3=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4540(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[93]);
t6=((C_word*)t0)[3];
f_4540(t6,(C_word)C_fixnum_lessp(t4,t5));}}}

/* k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4540,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],a[4]=t2,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t3,((C_word*)t0)[15],lf[80]);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* optimizer.scm: 339  test */
t3=((C_word*)t0)[4];
f_3660(t3,t2,((C_word*)t0)[13],lf[63]);}}

/* k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4587,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 341  walk-generic */
t4=((C_word*)((C_word*)t0)[17])[1];
f_5030(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4601(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4746,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[19],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4829,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 365  test */
t4=((C_word*)t0)[6];
f_3660(t4,t3,((C_word*)t0)[2],lf[59]);}}

/* k4827 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_4746(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_4746(t2,C_SCHEME_FALSE);}}

/* k4744 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4746(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4746,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4749,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 367  llist-length */
((C_proc3)C_retrieve_symbol_proc(lf[89]))(3,*((C_word*)lf[89]+1),t2,((C_word*)t0)[3]);}
else{
/* optimizer.scm: 389  walk-generic */
t2=((C_word*)((C_word*)t0)[12])[1];
f_5030(t2,((C_word*)t0)[11],((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k4747 in k4744 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4749,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[11]);
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 369  walk-generic */
t4=((C_word*)((C_word*)t0)[10])[1];
f_5030(t4,((C_word*)t0)[9],t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 371  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[6]))(6,*((C_word*)lf[6]+1),t4,lf[7],lf[88],((C_word*)t0)[2],t1);}}

/* k4759 in k4747 in k4744 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4771 in k4759 in k4747 in k4744 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4772,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4776,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4791,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4799,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 382  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t6,C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_i_length(t3);
t8=(C_word)C_fixnum_times(C_fix(3),t7);
t9=(C_word)C_a_i_list(&a,2,lf[86],t8);
t10=t6;
f_4799(2,t10,(C_word)C_a_i_record(&a,4,lf[36],lf[87],t9,t3));}}

/* k4797 in a4771 in k4759 in k4747 in k4744 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4799,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 378  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4789 in a4771 in k4759 in k4747 in k4744 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4774 in a4771 in k4759 in k4747 in k4744 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a4765 in k4759 in k4747 in k4744 in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
/* optimizer.scm: 372  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[85]))(4,*((C_word*)lf[85]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4601(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4601,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_3686(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4617,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 348  append-reverse */
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 349  test */
t10=((C_word*)t0)[2];
f_3660(t10,t8,t9,lf[55]);}}

/* k4632 in loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4634,2,t0,t1);}
if(C_truep(t1)){
t2=f_3686(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 351  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[6]))(6,*((C_word*)lf[6]+1),t3,lf[7],lf[84],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 361  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_4601(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k4638 in k4632 in loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 354  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t2,t3,((C_word*)t0)[2]);}

/* k4644 in k4638 in k4632 in loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 357  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),t2,lf[83]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 360  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4601(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k4681 in k4644 in k4638 in k4632 in loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 358  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3782(3,t5,t3,t4);}

/* k4657 in k4681 in k4644 in k4638 in k4632 in loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 359  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4601(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4661 in k4657 in k4681 in k4644 in k4638 in k4632 in loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[11],((C_word*)t0)[2],t2));}

/* k4626 in loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4628,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4615 in loop in k4585 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4617,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[15],((C_word*)t0)[2],t1));}

/* k4576 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_structurep(t1,lf[36]);
t3=(C_truep(t2)?lf[77]:lf[78]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* optimizer.scm: 329  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[6]))(7,*((C_word*)lf[6]+1),((C_word*)t0)[4],lf[79],t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4541 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 335  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[66]))(5,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k4544 in k4541 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 336  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[76],((C_word*)t0)[2]);}

/* k4547 in k4544 in k4541 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4549,2,t0,t1);}
t2=f_3686(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 338  inline-lambda-bindings */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_TRUE);}

/* k4557 in k4547 in k4544 in k4541 in k4538 in a4529 in k4517 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 338  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3782(3,t2,((C_word*)t0)[2],t1);}

/* k4503 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4401(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 301  test */
t2=((C_word*)t0)[3];
f_3660(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[46]);}}

/* k4399 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4401,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(lf[54],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_caddr(t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t5);
/* optimizer.scm: 304  test */
t8=((C_word*)t0)[2];
f_3660(t8,t6,t7,lf[55]);}
else{
t6=((C_word*)t0)[7];
f_4380(t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[7];
f_4380(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_4380(t2,C_SCHEME_FALSE);}}

/* k4420 in k4399 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4425(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 305  test */
t5=((C_word*)t0)[2];
f_3660(t5,t3,t4,lf[74]);}}

/* k4477 in k4420 in k4399 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4479,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4425(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 306  test */
t4=((C_word*)t0)[2];
f_3660(t4,t2,t3,lf[73]);}}

/* k4469 in k4477 in k4420 in k4399 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4425(t2,(C_word)C_i_not(t1));}

/* k4423 in k4420 in k4399 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4425(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4425,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 307  any */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_4380(t2,C_SCHEME_FALSE);}}

/* a4449 in k4423 in k4420 in k4399 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4450,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[72]))(4,*((C_word*)lf[72]+1),t1,t2,((C_word*)t0)[2]);}

/* k4446 in k4423 in k4420 in k4399 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4380(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 308  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[70],lf[71],((C_word*)t0)[2]);}}

/* k4432 in k4446 in k4423 in k4420 in k4399 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4434,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[36],lf[68],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4380(t4,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[69],t3));}

/* k4378 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 312  walk-generic */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5030(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4345 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 294  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[65],((C_word*)t0)[2]);}

/* k4348 in k4345 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
t2=f_3686(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 296  inline-lambda-bindings */
((C_proc6)C_retrieve_symbol_proc(lf[64]))(6,*((C_word*)lf[64]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4358 in k4348 in k4345 in k4336 in k4327 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 296  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3782(3,t2,((C_word*)t0)[2],t1);}

/* k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 249  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 264  test */
t4=((C_word*)t0)[11];
f_3660(t4,t2,t3,lf[59]);}}

/* k4243 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 265  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
/* optimizer.scm: 277  walk-generic */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5030(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a4249 in k4243 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4250,5,t0,t1,t2,t3,t4);}
t5=f_3686(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4257,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 269  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t6,lf[7],lf[62],t4);}

/* k4255 in a4249 in k4243 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 274  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4284 in k4255 in a4249 in k4243 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4270,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 276  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3782(3,t6,t4,t5);}

/* k4268 in k4284 in k4255 in a4249 in k4243 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[54],((C_word*)t0)[2],t2));}

/* a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4158,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4164,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4175 in a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4176,4,t0,t1,t2,t3);}
t4=f_3686(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 254  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t5,lf[7],lf[60],t2);}

/* k4181 in a4175 in a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 258  test */
t7=((C_word*)t0)[2];
f_3660(t7,t5,t6,lf[59]);}
else{
t6=t5;
f_4219(2,t6,C_SCHEME_FALSE);}}

/* k4217 in k4181 in a4175 in a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4219,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 259  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[58],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 261  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4220 in k4217 in k4181 in a4175 in a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 260  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[57]))(5,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4210 in k4181 in a4175 in a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4196,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 263  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3782(3,t6,t4,t5);}

/* k4194 in k4210 in k4181 in a4175 in a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4196,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[54],((C_word*)t0)[2],t2));}

/* a4163 in a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 252  partition */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t1,t2,((C_word*)t0)[2]);}

/* a4169 in a4163 in a4157 in k4151 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4170,3,t0,t1,t2);}
/* optimizer.scm: 252  test */
t3=((C_word*)t0)[2];
f_3660(t3,t1,t2,lf[55]);}

/* k4094 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_4099(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 239  test */
t4=((C_word*)t0)[3];
f_3660(t4,t3,((C_word*)t0)[2],lf[53]);}}

/* k4120 in k4094 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4099(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 240  test */
t3=((C_word*)t0)[3];
f_3660(t3,t2,((C_word*)t0)[2],lf[52]);}}

/* k4129 in k4120 in k4094 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4131,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4138,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 240  test */
t3=((C_word*)t0)[3];
f_3660(t3,t2,((C_word*)t0)[2],lf[51]);}
else{
t2=((C_word*)t0)[4];
f_4099(t2,C_SCHEME_FALSE);}}

/* k4136 in k4129 in k4120 in k4094 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4099(t2,(C_word)C_i_not(t1));}

/* k4097 in k4094 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4099,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3686(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 243  walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3782(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k4114 in k4097 in k4094 in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4116,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[36],lf[11],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4021(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4021,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 224  test */
t4=((C_word*)t0)[4];
f_3660(t4,t3,t2,lf[50]);}

/* k4023 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
if(C_truep(t1)){
/* replace333 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4021(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 225  test */
t3=((C_word*)t0)[5];
f_3660(t3,t2,((C_word*)t0)[4],lf[49]);}}

/* k4035 in k4023 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
if(C_truep(t1)){
t2=f_3686(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 227  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t3,lf[7],lf[47],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_4060(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_3686(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_4060(t8,t7);}}}

/* k4058 in k4035 in k4023 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_4060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 234  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4041 in k4035 in k4023 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 228  test */
t3=((C_word*)t0)[3];
f_3660(t3,t2,((C_word*)t0)[2],lf[46]);}

/* k4052 in k4041 in k4035 in k4023 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
/* optimizer.scm: 228  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3782,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[33])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[8])[1];
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3796,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 178  walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3996(t5,t4,t2);}}

/* k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3796,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[10]);
if(C_truep(t5)){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[26],t7);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t10=C_mutate(((C_word *)((C_word*)t0)[7])+1,t9);
t11=f_3686(((C_word*)t0)[6]);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
/* optimizer.scm: 186  walk */
t16=((C_word*)((C_word*)t0)[5])[1];
f_3782(3,t16,t4,t15);}
else{
t9=t4;
f_3805(2,t9,t1);}}
else{
t6=(C_word)C_eqp(t3,lf[15]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[9],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3866,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=t12,tmp=(C_word)a,a+=9,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3967,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=t13,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),t14,t12,lf[45]);}
else{
t10=t4;
f_3805(2,t10,t1);}}
else{
t7=t4;
f_3805(2,t7,t1);}}}

/* k3965 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 195  foldable? */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3866(2,t2,C_SCHEME_FALSE);}}

/* k3971 in k3965 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 196  every */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_3866(2,t2,C_SCHEME_FALSE);}}

/* k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3948,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[7];
f_3805(2,t2,((C_word*)t0)[6]);}}

/* a3947 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3948,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[26],t5));}

/* k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3877,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,t4);}

/* a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3877,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3883,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3900,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[41]))(4,*((C_word*)lf[41]+1),t1,t3,t4);}

/* a3899 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3931 in a3899 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3932r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3932r(t0,t1,t2);}}

static void C_ccall f_3932r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3938,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k282288 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3937 in a3931 in a3899 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3905 in a3899 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3910,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 204  eval */
((C_proc3)C_retrieve_symbol_proc(lf[40]))(3,*((C_word*)lf[40]+1),t2,((C_word*)t0)[2]);}

/* k3908 in a3905 in a3899 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3913,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 205  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[39],((C_word*)t0)[2]);}

/* k3911 in k3908 in a3905 in a3899 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3913,2,t0,t1);}
t2=f_3686(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 210  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t4,((C_word*)t0)[2]);}

/* k3928 in k3911 in k3908 in a3905 in a3899 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[36],lf[15],lf[37],t2));}

/* a3882 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3883,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* k282288 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3888 in a3882 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3893(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_3893(t4,t3);}}

/* k3891 in a3888 in a3882 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3893,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 202  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[34]))(5,*((C_word*)lf[34]+1),t2,*((C_word*)lf[35]+1),C_retrieve(lf[33]),((C_word*)t0)[2]);}

/* k3895 in k3891 in a3888 in a3882 in a3876 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[33]+1 /* (set! broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k3873 in k3944 in k3864 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3803 in k3794 in walk in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 176  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3690(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3690(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3690,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
/* optimizer.scm: 157  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t3,C_retrieve(lf[22]),t5);}

/* k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 158  any */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t2,t3,t1);}
else{
t3=t2;
f_3697(2,t3,C_SCHEME_FALSE);}}

/* a3704 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3705,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3715,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 160  match-node */
((C_proc5)C_retrieve_symbol_proc(lf[30]))(5,*((C_word*)lf[30]+1),t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3713 in a3704 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3764,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3763 in k3713 in a3704 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3764,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k3760 in k3713 in a3704 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3719 in k3713 in a3704 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3727,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 163  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[28]+1)))(3,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3725 in k3719 in k3713 in a3704 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_3733(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3754,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 167  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[27]))(5,*((C_word*)lf[27]+1),t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k3752 in k3725 in k3719 in k3713 in a3704 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3733(t3,t2);}

/* k3731 in k3725 in k3719 in k3713 in a3704 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3686(((C_word*)t0)[5]);
/* optimizer.scm: 169  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3690(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3695 in k3692 in simplify in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static C_word C_fcall f_3686(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* constant-node? in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3666,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[26],t3));}

/* test in ##compiler#perform-high-level-optimizations in k3652 in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3660(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3660,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 151  get */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3419,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3422,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3440,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 83   debugging */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t8,lf[20],lf[21]);}

/* k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 84   call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t2,t3);}

/* a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3484,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3487,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3499,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 119  scan */
t9=((C_word*)t6)[1];
f_3499(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3499(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3499,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[9]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3524,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_3524(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_3524(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[10]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_3551(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[17]);
t14=t12;
f_3551(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[18])));}}}

/* k3549 in scan in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3554,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 101  scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3499(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[11]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 105  scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3499(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[13]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[14]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[15]);
if(C_truep(t5)){
/* optimizer.scm: 110  return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[16]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))){
t9=t8;
f_3615(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 114  mark */
t9=((C_word*)t0)[3];
f_3422(3,t9,t8,t7);}}
else{
/* optimizer.scm: 117  scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3487(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k3613 in k3549 in scan in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 115  scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3499(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3568 in k3549 in scan in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3570,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3581,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 106  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3579 in k3568 in k3549 in scan in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 106  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3499(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3552 in k3549 in scan in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 102  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3522 in scan in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3524(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3524,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_fcall f_3487(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3487,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3493,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3492 in scan-each in a3483 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3493,3,t0,t1,t2);}
/* optimizer.scm: 88   scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3499(t3,t1,t2,((C_word*)t0)[2]);}

/* k3441 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 120  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),t2,lf[7],lf[8],((C_word*)((C_word*)t0)[2])[1]);}

/* k3444 in k3441 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a3450 in k3444 in k3441 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3451,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[4]);}

/* f_3456 in a3450 in k3444 in k3441 in k3438 in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3456r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3456r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3456r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3460(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3460(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[3],t4);}}}

/* k3458 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* mark in ##compiler#scan-toplevel-assignments in k3415 in k3412 in k3409 in k3406 in k3403 in k3400 */
static void C_ccall f_3422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3422,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[585] = {
{"toplevel:optimizer_scm",(void*)C_optimizer_toplevel},
{"f_3402:optimizer_scm",(void*)f_3402},
{"f_3405:optimizer_scm",(void*)f_3405},
{"f_3408:optimizer_scm",(void*)f_3408},
{"f_3411:optimizer_scm",(void*)f_3411},
{"f_3414:optimizer_scm",(void*)f_3414},
{"f_3417:optimizer_scm",(void*)f_3417},
{"f_3654:optimizer_scm",(void*)f_3654},
{"f_11666:optimizer_scm",(void*)f_11666},
{"f_11674:optimizer_scm",(void*)f_11674},
{"f_11679:optimizer_scm",(void*)f_11679},
{"f_11724:optimizer_scm",(void*)f_11724},
{"f_11728:optimizer_scm",(void*)f_11728},
{"f_11689:optimizer_scm",(void*)f_11689},
{"f_11713:optimizer_scm",(void*)f_11713},
{"f_11698:optimizer_scm",(void*)f_11698},
{"f_5393:optimizer_scm",(void*)f_5393},
{"f_10705:optimizer_scm",(void*)f_10705},
{"f_10739:optimizer_scm",(void*)f_10739},
{"f_10841:optimizer_scm",(void*)f_10841},
{"f_10851:optimizer_scm",(void*)f_10851},
{"f_10915:optimizer_scm",(void*)f_10915},
{"f_10944:optimizer_scm",(void*)f_10944},
{"f_11067:optimizer_scm",(void*)f_11067},
{"f_10960:optimizer_scm",(void*)f_10960},
{"f_11007:optimizer_scm",(void*)f_11007},
{"f_10997:optimizer_scm",(void*)f_10997},
{"f_11005:optimizer_scm",(void*)f_11005},
{"f_11137:optimizer_scm",(void*)f_11137},
{"f_11150:optimizer_scm",(void*)f_11150},
{"f_11185:optimizer_scm",(void*)f_11185},
{"f_11169:optimizer_scm",(void*)f_11169},
{"f_11173:optimizer_scm",(void*)f_11173},
{"f_11162:optimizer_scm",(void*)f_11162},
{"f_11351:optimizer_scm",(void*)f_11351},
{"f_11364:optimizer_scm",(void*)f_11364},
{"f_11370:optimizer_scm",(void*)f_11370},
{"f_11416:optimizer_scm",(void*)f_11416},
{"f_11408:optimizer_scm",(void*)f_11408},
{"f_11392:optimizer_scm",(void*)f_11392},
{"f_11396:optimizer_scm",(void*)f_11396},
{"f_11400:optimizer_scm",(void*)f_11400},
{"f_5396:optimizer_scm",(void*)f_5396},
{"f_10383:optimizer_scm",(void*)f_10383},
{"f_10405:optimizer_scm",(void*)f_10405},
{"f_10460:optimizer_scm",(void*)f_10460},
{"f_10430:optimizer_scm",(void*)f_10430},
{"f_10452:optimizer_scm",(void*)f_10452},
{"f_10456:optimizer_scm",(void*)f_10456},
{"f_10448:optimizer_scm",(void*)f_10448},
{"f_10428:optimizer_scm",(void*)f_10428},
{"f_10554:optimizer_scm",(void*)f_10554},
{"f_10568:optimizer_scm",(void*)f_10568},
{"f_5399:optimizer_scm",(void*)f_5399},
{"f_5727:optimizer_scm",(void*)f_5727},
{"f_8716:optimizer_scm",(void*)f_8716},
{"f_10262:optimizer_scm",(void*)f_10262},
{"f_10265:optimizer_scm",(void*)f_10265},
{"f_10268:optimizer_scm",(void*)f_10268},
{"f_10271:optimizer_scm",(void*)f_10271},
{"f_10274:optimizer_scm",(void*)f_10274},
{"f_10277:optimizer_scm",(void*)f_10277},
{"f_10354:optimizer_scm",(void*)f_10354},
{"f_10280:optimizer_scm",(void*)f_10280},
{"f_10283:optimizer_scm",(void*)f_10283},
{"f_10286:optimizer_scm",(void*)f_10286},
{"f_10348:optimizer_scm",(void*)f_10348},
{"f_10289:optimizer_scm",(void*)f_10289},
{"f_10292:optimizer_scm",(void*)f_10292},
{"f_10345:optimizer_scm",(void*)f_10345},
{"f_9325:optimizer_scm",(void*)f_9325},
{"f_9343:optimizer_scm",(void*)f_9343},
{"f_9349:optimizer_scm",(void*)f_9349},
{"f_9329:optimizer_scm",(void*)f_9329},
{"f_10295:optimizer_scm",(void*)f_10295},
{"f_10337:optimizer_scm",(void*)f_10337},
{"f_10335:optimizer_scm",(void*)f_10335},
{"f_10298:optimizer_scm",(void*)f_10298},
{"f_10301:optimizer_scm",(void*)f_10301},
{"f_10304:optimizer_scm",(void*)f_10304},
{"f_10328:optimizer_scm",(void*)f_10328},
{"f_10307:optimizer_scm",(void*)f_10307},
{"f_10310:optimizer_scm",(void*)f_10310},
{"f_10313:optimizer_scm",(void*)f_10313},
{"f_10316:optimizer_scm",(void*)f_10316},
{"f_10319:optimizer_scm",(void*)f_10319},
{"f_10322:optimizer_scm",(void*)f_10322},
{"f_10115:optimizer_scm",(void*)f_10115},
{"f_10121:optimizer_scm",(void*)f_10121},
{"f_10233:optimizer_scm",(void*)f_10233},
{"f_10242:optimizer_scm",(void*)f_10242},
{"f_10245:optimizer_scm",(void*)f_10245},
{"f_10140:optimizer_scm",(void*)f_10140},
{"f_10145:optimizer_scm",(void*)f_10145},
{"f_10186:optimizer_scm",(void*)f_10186},
{"f_10183:optimizer_scm",(void*)f_10183},
{"f_10168:optimizer_scm",(void*)f_10168},
{"f_10179:optimizer_scm",(void*)f_10179},
{"f_10175:optimizer_scm",(void*)f_10175},
{"f_10028:optimizer_scm",(void*)f_10028},
{"f_10034:optimizer_scm",(void*)f_10034},
{"f_10090:optimizer_scm",(void*)f_10090},
{"f_10086:optimizer_scm",(void*)f_10086},
{"f_10056:optimizer_scm",(void*)f_10056},
{"f_9779:optimizer_scm",(void*)f_9779},
{"f_9793:optimizer_scm",(void*)f_9793},
{"f_9800:optimizer_scm",(void*)f_9800},
{"f_9803:optimizer_scm",(void*)f_9803},
{"f_9812:optimizer_scm",(void*)f_9812},
{"f_9819:optimizer_scm",(void*)f_9819},
{"f_9822:optimizer_scm",(void*)f_9822},
{"f_9918:optimizer_scm",(void*)f_9918},
{"f_10004:optimizer_scm",(void*)f_10004},
{"f_10023:optimizer_scm",(void*)f_10023},
{"f_10019:optimizer_scm",(void*)f_10019},
{"f_9985:optimizer_scm",(void*)f_9985},
{"f_9974:optimizer_scm",(void*)f_9974},
{"f_9961:optimizer_scm",(void*)f_9961},
{"f_9944:optimizer_scm",(void*)f_9944},
{"f_9937:optimizer_scm",(void*)f_9937},
{"f_9903:optimizer_scm",(void*)f_9903},
{"f_9825:optimizer_scm",(void*)f_9825},
{"f_9874:optimizer_scm",(void*)f_9874},
{"f_9862:optimizer_scm",(void*)f_9862},
{"f_9858:optimizer_scm",(void*)f_9858},
{"f_9791:optimizer_scm",(void*)f_9791},
{"f_9578:optimizer_scm",(void*)f_9578},
{"f_9765:optimizer_scm",(void*)f_9765},
{"f_9643:optimizer_scm",(void*)f_9643},
{"f_9720:optimizer_scm",(void*)f_9720},
{"f_9725:optimizer_scm",(void*)f_9725},
{"f_9763:optimizer_scm",(void*)f_9763},
{"f_9587:optimizer_scm",(void*)f_9587},
{"f_9625:optimizer_scm",(void*)f_9625},
{"f_9630:optimizer_scm",(void*)f_9630},
{"f_9607:optimizer_scm",(void*)f_9607},
{"f_9585:optimizer_scm",(void*)f_9585},
{"f_9755:optimizer_scm",(void*)f_9755},
{"f_9741:optimizer_scm",(void*)f_9741},
{"f_9739:optimizer_scm",(void*)f_9739},
{"f_9645:optimizer_scm",(void*)f_9645},
{"f_9713:optimizer_scm",(void*)f_9713},
{"f_9711:optimizer_scm",(void*)f_9711},
{"f_9699:optimizer_scm",(void*)f_9699},
{"f_9665:optimizer_scm",(void*)f_9665},
{"f_9689:optimizer_scm",(void*)f_9689},
{"f_9687:optimizer_scm",(void*)f_9687},
{"f_9683:optimizer_scm",(void*)f_9683},
{"f_9675:optimizer_scm",(void*)f_9675},
{"f_9359:optimizer_scm",(void*)f_9359},
{"f_9365:optimizer_scm",(void*)f_9365},
{"f_9384:optimizer_scm",(void*)f_9384},
{"f_9551:optimizer_scm",(void*)f_9551},
{"f_9481:optimizer_scm",(void*)f_9481},
{"f_9497:optimizer_scm",(void*)f_9497},
{"f_9527:optimizer_scm",(void*)f_9527},
{"f_9531:optimizer_scm",(void*)f_9531},
{"f_9517:optimizer_scm",(void*)f_9517},
{"f_9470:optimizer_scm",(void*)f_9470},
{"f_9475:optimizer_scm",(void*)f_9475},
{"f_9446:optimizer_scm",(void*)f_9446},
{"f_9458:optimizer_scm",(void*)f_9458},
{"f_9395:optimizer_scm",(void*)f_9395},
{"f_9416:optimizer_scm",(void*)f_9416},
{"f_9413:optimizer_scm",(void*)f_9413},
{"f_9363:optimizer_scm",(void*)f_9363},
{"f_9115:optimizer_scm",(void*)f_9115},
{"f_9121:optimizer_scm",(void*)f_9121},
{"f_9140:optimizer_scm",(void*)f_9140},
{"f_9242:optimizer_scm",(void*)f_9242},
{"f_9233:optimizer_scm",(void*)f_9233},
{"f_9199:optimizer_scm",(void*)f_9199},
{"f_9208:optimizer_scm",(void*)f_9208},
{"f_9220:optimizer_scm",(void*)f_9220},
{"f_9151:optimizer_scm",(void*)f_9151},
{"f_9172:optimizer_scm",(void*)f_9172},
{"f_9169:optimizer_scm",(void*)f_9169},
{"f_9119:optimizer_scm",(void*)f_9119},
{"f_9016:optimizer_scm",(void*)f_9016},
{"f_9022:optimizer_scm",(void*)f_9022},
{"f_9066:optimizer_scm",(void*)f_9066},
{"f_9071:optimizer_scm",(void*)f_9071},
{"f_9078:optimizer_scm",(void*)f_9078},
{"f_9105:optimizer_scm",(void*)f_9105},
{"f_9101:optimizer_scm",(void*)f_9101},
{"f_9093:optimizer_scm",(void*)f_9093},
{"f_9091:optimizer_scm",(void*)f_9091},
{"f_9056:optimizer_scm",(void*)f_9056},
{"f_9034:optimizer_scm",(void*)f_9034},
{"f_9041:optimizer_scm",(void*)f_9041},
{"f_8819:optimizer_scm",(void*)f_8819},
{"f_8973:optimizer_scm",(void*)f_8973},
{"f_8998:optimizer_scm",(void*)f_8998},
{"f_8988:optimizer_scm",(void*)f_8988},
{"f_8992:optimizer_scm",(void*)f_8992},
{"f_8971:optimizer_scm",(void*)f_8971},
{"f_8822:optimizer_scm",(void*)f_8822},
{"f_8961:optimizer_scm",(void*)f_8961},
{"f_8944:optimizer_scm",(void*)f_8944},
{"f_8956:optimizer_scm",(void*)f_8956},
{"f_8890:optimizer_scm",(void*)f_8890},
{"f_8914:optimizer_scm",(void*)f_8914},
{"f_8908:optimizer_scm",(void*)f_8908},
{"f_8872:optimizer_scm",(void*)f_8872},
{"f_8847:optimizer_scm",(void*)f_8847},
{"f_8850:optimizer_scm",(void*)f_8850},
{"f_8855:optimizer_scm",(void*)f_8855},
{"f_8719:optimizer_scm",(void*)f_8719},
{"f_8725:optimizer_scm",(void*)f_8725},
{"f_8756:optimizer_scm",(void*)f_8756},
{"f_8760:optimizer_scm",(void*)f_8760},
{"f_8764:optimizer_scm",(void*)f_8764},
{"f_8723:optimizer_scm",(void*)f_8723},
{"f_7621:optimizer_scm",(void*)f_7621},
{"f_8711:optimizer_scm",(void*)f_8711},
{"f_8714:optimizer_scm",(void*)f_8714},
{"f_7624:optimizer_scm",(void*)f_7624},
{"f_7780:optimizer_scm",(void*)f_7780},
{"f_7760:optimizer_scm",(void*)f_7760},
{"f_7734:optimizer_scm",(void*)f_7734},
{"f_7680:optimizer_scm",(void*)f_7680},
{"f_7686:optimizer_scm",(void*)f_7686},
{"f_7692:optimizer_scm",(void*)f_7692},
{"f_7649:optimizer_scm",(void*)f_7649},
{"f_7786:optimizer_scm",(void*)f_7786},
{"f_8196:optimizer_scm",(void*)f_8196},
{"f_8203:optimizer_scm",(void*)f_8203},
{"f_7789:optimizer_scm",(void*)f_7789},
{"f_8183:optimizer_scm",(void*)f_8183},
{"f_8159:optimizer_scm",(void*)f_8159},
{"f_8170:optimizer_scm",(void*)f_8170},
{"f_8126:optimizer_scm",(void*)f_8126},
{"f_8065:optimizer_scm",(void*)f_8065},
{"f_8037:optimizer_scm",(void*)f_8037},
{"f_8042:optimizer_scm",(void*)f_8042},
{"f_7984:optimizer_scm",(void*)f_7984},
{"f_7990:optimizer_scm",(void*)f_7990},
{"f_7995:optimizer_scm",(void*)f_7995},
{"f_7943:optimizer_scm",(void*)f_7943},
{"f_7949:optimizer_scm",(void*)f_7949},
{"f_7954:optimizer_scm",(void*)f_7954},
{"f_7927:optimizer_scm",(void*)f_7927},
{"f_7923:optimizer_scm",(void*)f_7923},
{"f_7893:optimizer_scm",(void*)f_7893},
{"f_7856:optimizer_scm",(void*)f_7856},
{"f_7872:optimizer_scm",(void*)f_7872},
{"f_7838:optimizer_scm",(void*)f_7838},
{"f_8205:optimizer_scm",(void*)f_8205},
{"f_8701:optimizer_scm",(void*)f_8701},
{"f_8699:optimizer_scm",(void*)f_8699},
{"f_8209:optimizer_scm",(void*)f_8209},
{"f_8219:optimizer_scm",(void*)f_8219},
{"f_8225:optimizer_scm",(void*)f_8225},
{"f_8231:optimizer_scm",(void*)f_8231},
{"f_8234:optimizer_scm",(void*)f_8234},
{"f_8240:optimizer_scm",(void*)f_8240},
{"f_8416:optimizer_scm",(void*)f_8416},
{"f_8638:optimizer_scm",(void*)f_8638},
{"f_8641:optimizer_scm",(void*)f_8641},
{"f_8591:optimizer_scm",(void*)f_8591},
{"f_8594:optimizer_scm",(void*)f_8594},
{"f_8460:optimizer_scm",(void*)f_8460},
{"f_8515:optimizer_scm",(void*)f_8515},
{"f_8518:optimizer_scm",(void*)f_8518},
{"f_8545:optimizer_scm",(void*)f_8545},
{"f_8521:optimizer_scm",(void*)f_8521},
{"f_8524:optimizer_scm",(void*)f_8524},
{"f_8469:optimizer_scm",(void*)f_8469},
{"f_8472:optimizer_scm",(void*)f_8472},
{"f_8475:optimizer_scm",(void*)f_8475},
{"f_8243:optimizer_scm",(void*)f_8243},
{"f_8398:optimizer_scm",(void*)f_8398},
{"f_8396:optimizer_scm",(void*)f_8396},
{"f_8339:optimizer_scm",(void*)f_8339},
{"f_8349:optimizer_scm",(void*)f_8349},
{"f_8246:optimizer_scm",(void*)f_8246},
{"f_8258:optimizer_scm",(void*)f_8258},
{"f_8297:optimizer_scm",(void*)f_8297},
{"f_8261:optimizer_scm",(void*)f_8261},
{"f_8264:optimizer_scm",(void*)f_8264},
{"f_8269:optimizer_scm",(void*)f_8269},
{"f_8295:optimizer_scm",(void*)f_8295},
{"f_8276:optimizer_scm",(void*)f_8276},
{"f_5749:optimizer_scm",(void*)f_5749},
{"f_7495:optimizer_scm",(void*)f_7495},
{"f_7517:optimizer_scm",(void*)f_7517},
{"f_7529:optimizer_scm",(void*)f_7529},
{"f_7543:optimizer_scm",(void*)f_7543},
{"f_7592:optimizer_scm",(void*)f_7592},
{"f_5774:optimizer_scm",(void*)f_5774},
{"f_7563:optimizer_scm",(void*)f_7563},
{"f_7567:optimizer_scm",(void*)f_7567},
{"f_7537:optimizer_scm",(void*)f_7537},
{"f_7523:optimizer_scm",(void*)f_7523},
{"f_7521:optimizer_scm",(void*)f_7521},
{"f_7510:optimizer_scm",(void*)f_7510},
{"f_7438:optimizer_scm",(void*)f_7438},
{"f_7470:optimizer_scm",(void*)f_7470},
{"f_7457:optimizer_scm",(void*)f_7457},
{"f_7290:optimizer_scm",(void*)f_7290},
{"f_7296:optimizer_scm",(void*)f_7296},
{"f_7380:optimizer_scm",(void*)f_7380},
{"f_7305:optimizer_scm",(void*)f_7305},
{"f_7349:optimizer_scm",(void*)f_7349},
{"f_7347:optimizer_scm",(void*)f_7347},
{"f_7321:optimizer_scm",(void*)f_7321},
{"f_7223:optimizer_scm",(void*)f_7223},
{"f_7251:optimizer_scm",(void*)f_7251},
{"f_7263:optimizer_scm",(void*)f_7263},
{"f_7241:optimizer_scm",(void*)f_7241},
{"f_7236:optimizer_scm",(void*)f_7236},
{"f_7081:optimizer_scm",(void*)f_7081},
{"f_7162:optimizer_scm",(void*)f_7162},
{"f_7090:optimizer_scm",(void*)f_7090},
{"f_7143:optimizer_scm",(void*)f_7143},
{"f_7141:optimizer_scm",(void*)f_7141},
{"f_7106:optimizer_scm",(void*)f_7106},
{"f_7052:optimizer_scm",(void*)f_7052},
{"f_7062:optimizer_scm",(void*)f_7062},
{"f_6990:optimizer_scm",(void*)f_6990},
{"f_7010:optimizer_scm",(void*)f_7010},
{"f_6917:optimizer_scm",(void*)f_6917},
{"f_6947:optimizer_scm",(void*)f_6947},
{"f_6830:optimizer_scm",(void*)f_6830},
{"f_6849:optimizer_scm",(void*)f_6849},
{"f_6842:optimizer_scm",(void*)f_6842},
{"f_6753:optimizer_scm",(void*)f_6753},
{"f_6694:optimizer_scm",(void*)f_6694},
{"f_6709:optimizer_scm",(void*)f_6709},
{"f_6712:optimizer_scm",(void*)f_6712},
{"f_6624:optimizer_scm",(void*)f_6624},
{"f_6667:optimizer_scm",(void*)f_6667},
{"f_6660:optimizer_scm",(void*)f_6660},
{"f_6565:optimizer_scm",(void*)f_6565},
{"f_6577:optimizer_scm",(void*)f_6577},
{"f_6590:optimizer_scm",(void*)f_6590},
{"f_6583:optimizer_scm",(void*)f_6583},
{"f_6478:optimizer_scm",(void*)f_6478},
{"f_6500:optimizer_scm",(void*)f_6500},
{"f_6508:optimizer_scm",(void*)f_6508},
{"f_6512:optimizer_scm",(void*)f_6512},
{"f_6334:optimizer_scm",(void*)f_6334},
{"f_6356:optimizer_scm",(void*)f_6356},
{"f_6359:optimizer_scm",(void*)f_6359},
{"f_6418:optimizer_scm",(void*)f_6418},
{"f_6362:optimizer_scm",(void*)f_6362},
{"f_6365:optimizer_scm",(void*)f_6365},
{"f_6396:optimizer_scm",(void*)f_6396},
{"f_6394:optimizer_scm",(void*)f_6394},
{"f_6370:optimizer_scm",(void*)f_6370},
{"f_6350:optimizer_scm",(void*)f_6350},
{"f_6313:optimizer_scm",(void*)f_6313},
{"f_6258:optimizer_scm",(void*)f_6258},
{"f_6282:optimizer_scm",(void*)f_6282},
{"f_6271:optimizer_scm",(void*)f_6271},
{"f_6193:optimizer_scm",(void*)f_6193},
{"f_6106:optimizer_scm",(void*)f_6106},
{"f_6148:optimizer_scm",(void*)f_6148},
{"f_6050:optimizer_scm",(void*)f_6050},
{"f_6063:optimizer_scm",(void*)f_6063},
{"f_6071:optimizer_scm",(void*)f_6071},
{"f_6012:optimizer_scm",(void*)f_6012},
{"f_6022:optimizer_scm",(void*)f_6022},
{"f_5914:optimizer_scm",(void*)f_5914},
{"f_5971:optimizer_scm",(void*)f_5971},
{"f_5942:optimizer_scm",(void*)f_5942},
{"f_5939:optimizer_scm",(void*)f_5939},
{"f_5806:optimizer_scm",(void*)f_5806},
{"f_5869:optimizer_scm",(void*)f_5869},
{"f_5809:optimizer_scm",(void*)f_5809},
{"f_5729:optimizer_scm",(void*)f_5729},
{"f_5733:optimizer_scm",(void*)f_5733},
{"f_5743:optimizer_scm",(void*)f_5743},
{"f_5401:optimizer_scm",(void*)f_5401},
{"f_5405:optimizer_scm",(void*)f_5405},
{"f_5714:optimizer_scm",(void*)f_5714},
{"f_5723:optimizer_scm",(void*)f_5723},
{"f_5719:optimizer_scm",(void*)f_5719},
{"f_5452:optimizer_scm",(void*)f_5452},
{"f_5656:optimizer_scm",(void*)f_5656},
{"f_5688:optimizer_scm",(void*)f_5688},
{"f_5701:optimizer_scm",(void*)f_5701},
{"f_5666:optimizer_scm",(void*)f_5666},
{"f_5682:optimizer_scm",(void*)f_5682},
{"f_5670:optimizer_scm",(void*)f_5670},
{"f_5674:optimizer_scm",(void*)f_5674},
{"f_5455:optimizer_scm",(void*)f_5455},
{"f_5597:optimizer_scm",(void*)f_5597},
{"f_5640:optimizer_scm",(void*)f_5640},
{"f_5646:optimizer_scm",(void*)f_5646},
{"f_5604:optimizer_scm",(void*)f_5604},
{"f_5614:optimizer_scm",(void*)f_5614},
{"f_5627:optimizer_scm",(void*)f_5627},
{"f_5612:optimizer_scm",(void*)f_5612},
{"f_5608:optimizer_scm",(void*)f_5608},
{"f_5458:optimizer_scm",(void*)f_5458},
{"f_5461:optimizer_scm",(void*)f_5461},
{"f_5481:optimizer_scm",(void*)f_5481},
{"f_5494:optimizer_scm",(void*)f_5494},
{"f_5537:optimizer_scm",(void*)f_5537},
{"f_5569:optimizer_scm",(void*)f_5569},
{"f_5535:optimizer_scm",(void*)f_5535},
{"f_5517:optimizer_scm",(void*)f_5517},
{"f_5464:optimizer_scm",(void*)f_5464},
{"f_5473:optimizer_scm",(void*)f_5473},
{"f_5407:optimizer_scm",(void*)f_5407},
{"f_5413:optimizer_scm",(void*)f_5413},
{"f_5437:optimizer_scm",(void*)f_5437},
{"f_5386:optimizer_scm",(void*)f_5386},
{"f_5145:optimizer_scm",(void*)f_5145},
{"f_5159:optimizer_scm",(void*)f_5159},
{"f_5174:optimizer_scm",(void*)f_5174},
{"f_5381:optimizer_scm",(void*)f_5381},
{"f_5179:optimizer_scm",(void*)f_5179},
{"f_5370:optimizer_scm",(void*)f_5370},
{"f_5192:optimizer_scm",(void*)f_5192},
{"f_5195:optimizer_scm",(void*)f_5195},
{"f_5201:optimizer_scm",(void*)f_5201},
{"f_5216:optimizer_scm",(void*)f_5216},
{"f_5222:optimizer_scm",(void*)f_5222},
{"f_5228:optimizer_scm",(void*)f_5228},
{"f_5237:optimizer_scm",(void*)f_5237},
{"f_5244:optimizer_scm",(void*)f_5244},
{"f_5247:optimizer_scm",(void*)f_5247},
{"f_5265:optimizer_scm",(void*)f_5265},
{"f_5250:optimizer_scm",(void*)f_5250},
{"f_5162:optimizer_scm",(void*)f_5162},
{"f_5165:optimizer_scm",(void*)f_5165},
{"f_5152:optimizer_scm",(void*)f_5152},
{"f_5148:optimizer_scm",(void*)f_5148},
{"f_3657:optimizer_scm",(void*)f_3657},
{"f_5049:optimizer_scm",(void*)f_5049},
{"f_5055:optimizer_scm",(void*)f_5055},
{"f_5059:optimizer_scm",(void*)f_5059},
{"f_5062:optimizer_scm",(void*)f_5062},
{"f_5098:optimizer_scm",(void*)f_5098},
{"f_5103:optimizer_scm",(void*)f_5103},
{"f_5107:optimizer_scm",(void*)f_5107},
{"f_5065:optimizer_scm",(void*)f_5065},
{"f_5068:optimizer_scm",(void*)f_5068},
{"f_5071:optimizer_scm",(void*)f_5071},
{"f_5074:optimizer_scm",(void*)f_5074},
{"f_5030:optimizer_scm",(void*)f_5030},
{"f_5034:optimizer_scm",(void*)f_5034},
{"f_5040:optimizer_scm",(void*)f_5040},
{"f_3996:optimizer_scm",(void*)f_3996},
{"f_4946:optimizer_scm",(void*)f_4946},
{"f_4949:optimizer_scm",(void*)f_4949},
{"f_5022:optimizer_scm",(void*)f_5022},
{"f_5018:optimizer_scm",(void*)f_5018},
{"f_4990:optimizer_scm",(void*)f_4990},
{"f_5011:optimizer_scm",(void*)f_5011},
{"f_5003:optimizer_scm",(void*)f_5003},
{"f_4961:optimizer_scm",(void*)f_4961},
{"f_4980:optimizer_scm",(void*)f_4980},
{"f_4967:optimizer_scm",(void*)f_4967},
{"f_4921:optimizer_scm",(void*)f_4921},
{"f_4896:optimizer_scm",(void*)f_4896},
{"f_4886:optimizer_scm",(void*)f_4886},
{"f_4329:optimizer_scm",(void*)f_4329},
{"f_4338:optimizer_scm",(void*)f_4338},
{"f_4519:optimizer_scm",(void*)f_4519},
{"f_4530:optimizer_scm",(void*)f_4530},
{"f_4842:optimizer_scm",(void*)f_4842},
{"f_4848:optimizer_scm",(void*)f_4848},
{"f_4851:optimizer_scm",(void*)f_4851},
{"f_4540:optimizer_scm",(void*)f_4540},
{"f_4587:optimizer_scm",(void*)f_4587},
{"f_4829:optimizer_scm",(void*)f_4829},
{"f_4746:optimizer_scm",(void*)f_4746},
{"f_4749:optimizer_scm",(void*)f_4749},
{"f_4761:optimizer_scm",(void*)f_4761},
{"f_4772:optimizer_scm",(void*)f_4772},
{"f_4799:optimizer_scm",(void*)f_4799},
{"f_4791:optimizer_scm",(void*)f_4791},
{"f_4776:optimizer_scm",(void*)f_4776},
{"f_4766:optimizer_scm",(void*)f_4766},
{"f_4601:optimizer_scm",(void*)f_4601},
{"f_4634:optimizer_scm",(void*)f_4634},
{"f_4640:optimizer_scm",(void*)f_4640},
{"f_4646:optimizer_scm",(void*)f_4646},
{"f_4683:optimizer_scm",(void*)f_4683},
{"f_4659:optimizer_scm",(void*)f_4659},
{"f_4663:optimizer_scm",(void*)f_4663},
{"f_4628:optimizer_scm",(void*)f_4628},
{"f_4617:optimizer_scm",(void*)f_4617},
{"f_4578:optimizer_scm",(void*)f_4578},
{"f_4543:optimizer_scm",(void*)f_4543},
{"f_4546:optimizer_scm",(void*)f_4546},
{"f_4549:optimizer_scm",(void*)f_4549},
{"f_4559:optimizer_scm",(void*)f_4559},
{"f_4505:optimizer_scm",(void*)f_4505},
{"f_4401:optimizer_scm",(void*)f_4401},
{"f_4422:optimizer_scm",(void*)f_4422},
{"f_4479:optimizer_scm",(void*)f_4479},
{"f_4471:optimizer_scm",(void*)f_4471},
{"f_4425:optimizer_scm",(void*)f_4425},
{"f_4450:optimizer_scm",(void*)f_4450},
{"f_4448:optimizer_scm",(void*)f_4448},
{"f_4434:optimizer_scm",(void*)f_4434},
{"f_4380:optimizer_scm",(void*)f_4380},
{"f_4347:optimizer_scm",(void*)f_4347},
{"f_4350:optimizer_scm",(void*)f_4350},
{"f_4360:optimizer_scm",(void*)f_4360},
{"f_4153:optimizer_scm",(void*)f_4153},
{"f_4245:optimizer_scm",(void*)f_4245},
{"f_4250:optimizer_scm",(void*)f_4250},
{"f_4257:optimizer_scm",(void*)f_4257},
{"f_4286:optimizer_scm",(void*)f_4286},
{"f_4270:optimizer_scm",(void*)f_4270},
{"f_4158:optimizer_scm",(void*)f_4158},
{"f_4176:optimizer_scm",(void*)f_4176},
{"f_4183:optimizer_scm",(void*)f_4183},
{"f_4219:optimizer_scm",(void*)f_4219},
{"f_4222:optimizer_scm",(void*)f_4222},
{"f_4212:optimizer_scm",(void*)f_4212},
{"f_4196:optimizer_scm",(void*)f_4196},
{"f_4164:optimizer_scm",(void*)f_4164},
{"f_4170:optimizer_scm",(void*)f_4170},
{"f_4096:optimizer_scm",(void*)f_4096},
{"f_4122:optimizer_scm",(void*)f_4122},
{"f_4131:optimizer_scm",(void*)f_4131},
{"f_4138:optimizer_scm",(void*)f_4138},
{"f_4099:optimizer_scm",(void*)f_4099},
{"f_4116:optimizer_scm",(void*)f_4116},
{"f_4021:optimizer_scm",(void*)f_4021},
{"f_4025:optimizer_scm",(void*)f_4025},
{"f_4037:optimizer_scm",(void*)f_4037},
{"f_4060:optimizer_scm",(void*)f_4060},
{"f_4043:optimizer_scm",(void*)f_4043},
{"f_4054:optimizer_scm",(void*)f_4054},
{"f_3782:optimizer_scm",(void*)f_3782},
{"f_3796:optimizer_scm",(void*)f_3796},
{"f_3967:optimizer_scm",(void*)f_3967},
{"f_3973:optimizer_scm",(void*)f_3973},
{"f_3866:optimizer_scm",(void*)f_3866},
{"f_3948:optimizer_scm",(void*)f_3948},
{"f_3946:optimizer_scm",(void*)f_3946},
{"f_3877:optimizer_scm",(void*)f_3877},
{"f_3900:optimizer_scm",(void*)f_3900},
{"f_3932:optimizer_scm",(void*)f_3932},
{"f_3938:optimizer_scm",(void*)f_3938},
{"f_3906:optimizer_scm",(void*)f_3906},
{"f_3910:optimizer_scm",(void*)f_3910},
{"f_3913:optimizer_scm",(void*)f_3913},
{"f_3930:optimizer_scm",(void*)f_3930},
{"f_3883:optimizer_scm",(void*)f_3883},
{"f_3889:optimizer_scm",(void*)f_3889},
{"f_3893:optimizer_scm",(void*)f_3893},
{"f_3897:optimizer_scm",(void*)f_3897},
{"f_3875:optimizer_scm",(void*)f_3875},
{"f_3805:optimizer_scm",(void*)f_3805},
{"f_3690:optimizer_scm",(void*)f_3690},
{"f_3694:optimizer_scm",(void*)f_3694},
{"f_3705:optimizer_scm",(void*)f_3705},
{"f_3715:optimizer_scm",(void*)f_3715},
{"f_3764:optimizer_scm",(void*)f_3764},
{"f_3762:optimizer_scm",(void*)f_3762},
{"f_3721:optimizer_scm",(void*)f_3721},
{"f_3727:optimizer_scm",(void*)f_3727},
{"f_3754:optimizer_scm",(void*)f_3754},
{"f_3733:optimizer_scm",(void*)f_3733},
{"f_3697:optimizer_scm",(void*)f_3697},
{"f_3686:optimizer_scm",(void*)f_3686},
{"f_3666:optimizer_scm",(void*)f_3666},
{"f_3660:optimizer_scm",(void*)f_3660},
{"f_3419:optimizer_scm",(void*)f_3419},
{"f_3440:optimizer_scm",(void*)f_3440},
{"f_3484:optimizer_scm",(void*)f_3484},
{"f_3499:optimizer_scm",(void*)f_3499},
{"f_3551:optimizer_scm",(void*)f_3551},
{"f_3615:optimizer_scm",(void*)f_3615},
{"f_3570:optimizer_scm",(void*)f_3570},
{"f_3581:optimizer_scm",(void*)f_3581},
{"f_3554:optimizer_scm",(void*)f_3554},
{"f_3524:optimizer_scm",(void*)f_3524},
{"f_3487:optimizer_scm",(void*)f_3487},
{"f_3493:optimizer_scm",(void*)f_3493},
{"f_3443:optimizer_scm",(void*)f_3443},
{"f_3446:optimizer_scm",(void*)f_3446},
{"f_3451:optimizer_scm",(void*)f_3451},
{"f_3456:optimizer_scm",(void*)f_3456},
{"f_3460:optimizer_scm",(void*)f_3460},
{"f_3422:optimizer_scm",(void*)f_3422},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
