/* Generated from match.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-01-18 12:10
   Version 3.0.0rc1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-17 on dill (Linux)
   command line: match.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file match.c
   unit: match
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[153];
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,16),40,101,118,101,114,121,32,102,110,48,32,108,115,116,49,41};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,34),40,35,35,109,97,116,99,104,35,115,121,110,116,97,120,45,101,114,114,32,111,98,106,49,54,55,32,109,115,103,49,54,56,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,35,35,109,97,116,99,104,35,115,101,116,45,101,114,114,111,114,32,118,49,54,57,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,35,35,109,97,116,99,104,35,115,101,116,45,101,114,114,111,114,45,99,111,110,116,114,111,108,32,118,49,55,48,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,97,55,51,56,54,32,120,54,51,56,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,20),40,115,121,109,98,111,108,45,97,112,112,101,110,100,32,108,54,51,55,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,18),40,103,101,116,116,101,114,32,101,54,51,50,32,112,54,51,51,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,16),40,109,107,45,115,101,116,116,101,114,32,115,54,50,56,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,18),40,115,101,116,116,101,114,32,101,54,50,53,32,112,54,50,54,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,12),40,97,100,100,45,100,32,97,54,50,51,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,97,100,100,45,97,32,97,54,50,49,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,11),40,100,105,115,106,111,105,110,116,63,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,101,113,117,97,108,45,116,101,115,116,63,32,116,115,116,54,49,56,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,10),40,109,101,109,32,108,53,57,55,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,10),40,109,101,109,32,108,54,48,55,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,10),40,109,101,109,32,108,54,49,51,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,14),40,105,110,32,101,53,56,54,32,108,53,56,55,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,99,111,100,101,53,55,56,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,103,117,97,114,97,110,116,101,101,115,32,99,111,100,101,53,55,51,32,120,53,55,52,41};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,23),40,97,115,115,109,32,116,115,116,53,54,53,32,102,53,54,54,32,115,53,54,55,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,31),40,101,109,105,116,32,116,115,116,53,53,51,32,115,102,53,53,52,32,107,102,53,53,53,32,107,115,53,53,54,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,17),40,100,111,116,45,100,111,116,45,107,63,32,115,50,53,54,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,10),40,118,97,108,32,120,52,54,51,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,102,97,105,108,32,115,102,52,54,53,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,15),40,115,117,99,99,101,115,115,32,115,102,52,54,55,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,13),40,97,52,49,54,53,32,115,102,52,56,52,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,112,52,56,50,32,115,102,52,56,51,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,13),40,97,52,50,48,56,32,115,102,52,57,48,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,112,52,56,56,32,115,102,52,56,57,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,14),40,102,95,52,50,53,57,32,115,102,52,57,57,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,12),40,114,108,111,111,112,32,110,52,57,56,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,13),40,97,52,52,54,48,32,115,102,53,48,57,41};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,13),40,97,52,52,54,51,32,115,102,53,49,48,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,12),40,97,52,53,50,50,32,120,53,50,48,41};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,12),40,97,52,53,52,48,32,120,53,49,57,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,97,52,53,55,50,32,98,53,49,55,32,102,53,49,56,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,13),40,97,52,53,53,52,32,115,102,53,49,54,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,10),40,107,115,32,115,102,53,48,54,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,13),40,97,52,51,53,54,32,115,102,53,48,51,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,13),40,97,52,54,54,56,32,115,102,53,50,53,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,13),40,97,52,54,53,52,32,115,102,53,50,52,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,12),40,97,52,56,49,48,32,120,53,52,49,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,17),40,97,52,56,53,56,32,98,53,51,57,32,102,53,52,48,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,13),40,97,52,56,52,48,32,115,102,53,51,56,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,14),40,102,95,52,55,51,49,32,115,102,53,51,51,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,118,108,111,111,112,32,110,53,51,50,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,13),40,97,52,55,48,55,32,115,102,53,51,48,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,14),40,102,95,52,57,52,49,32,115,102,53,52,56,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,12),40,118,108,111,111,112,32,110,53,52,55,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,13),40,97,52,57,50,52,32,115,102,53,52,53,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,34),40,110,101,120,116,32,112,52,55,52,32,101,52,55,53,32,115,102,52,55,54,32,107,102,52,55,55,32,107,115,52,55,56,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,54),40,103,101,110,32,120,52,53,53,32,115,102,52,53,54,32,112,108,105,115,116,52,53,55,32,101,114,114,97,99,116,52,53,56,32,108,101,110,103,116,104,62,61,52,53,57,32,101,116,97,52,54,48,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,8),40,99,111,110,115,116,63,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,8),40,105,115,118,97,108,63,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,8),40,115,109,97,108,108,63,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,101,52,50,48,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,101,52,49,52,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,98,52,52,50,32,110,101,119,45,98,52,52,51,32,101,52,52,52,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,23),40,105,110,108,105,110,101,45,108,101,116,32,108,101,116,45,101,120,112,52,48,53,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,13),40,97,51,52,51,56,32,120,49,51,57,54,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,25),40,112,101,114,109,117,116,97,116,105,111,110,32,112,49,51,57,52,32,112,50,51,57,53,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,23),40,102,105,110,100,45,112,114,101,102,105,120,32,98,51,57,50,32,97,51,57,51,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,18),40,97,50,55,53,54,32,112,50,51,52,53,32,97,51,52,54,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,97,50,55,57,56,32,112,51,52,55,32,97,51,52,56,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,16),40,97,50,56,51,49,32,112,108,105,115,116,51,53,57,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,16),40,97,50,56,55,55,32,99,100,114,45,112,51,53,54,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,97,50,56,54,52,32,99,97,114,45,112,51,53,52,32,99,97,114,45,97,51,53,53,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,19),40,111,114,42,32,112,108,105,115,116,51,53,50,32,107,51,53,51,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,29),40,97,50,56,50,49,32,102,105,114,115,116,45,112,51,52,57,32,102,105,114,115,116,45,97,51,53,48,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,19),40,97,50,57,51,49,32,112,50,51,54,48,32,97,50,51,54,49,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,12),40,97,51,48,48,52,32,95,51,54,54,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,17),40,97,50,57,55,53,32,113,51,54,51,32,98,51,54,52,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,18),40,97,51,48,50,51,32,112,49,51,54,55,32,97,51,54,56,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,21),40,97,51,49,50,52,32,99,100,114,45,112,51,55,49,32,97,51,55,50,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,21),40,97,51,49,49,52,32,99,97,114,45,112,51,54,57,32,97,51,55,48,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,97,51,49,52,55,32,112,108,51,55,51,32,97,51,55,52,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,22),40,98,111,117,110,100,32,112,51,51,51,32,97,51,51,52,32,107,51,51,53,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,6),40,103,49,49,53,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,97,51,51,49,55,32,99,100,114,45,112,51,56,51,32,97,51,56,52,41};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,21),40,97,51,51,49,49,32,99,97,114,45,112,51,56,49,32,97,51,56,50,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,27),40,98,111,117,110,100,118,32,112,108,105,115,116,51,55,53,32,97,51,55,54,32,107,51,55,55,41};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,21),40,97,51,51,57,50,32,99,100,114,45,112,51,57,48,32,97,51,57,49,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,21),40,97,51,51,56,50,32,99,97,114,45,112,51,56,56,32,97,51,56,57,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,27),40,98,111,117,110,100,42,32,112,108,105,115,116,51,56,53,32,97,51,56,54,32,107,51,56,55,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,17),40,97,51,52,53,53,32,112,51,57,55,32,97,51,57,56,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,18),40,98,111,117,110,100,32,112,97,116,116,101,114,110,51,50,54,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,112,97,116,116,101,114,110,45,118,97,114,63,32,120,50,53,53,41};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,9),40,115,105,109,112,108,101,63,41};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,103,56,56,32,120,50,56,52,32,121,50,56,53,41};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,111,114,100,105,110,97,114,121,32,112,50,56,50,41};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,16),40,103,49,48,57,32,120,51,48,56,32,121,51,48,57,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,12),40,113,117,97,115,105,32,112,51,48,54,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,14),40,111,114,100,108,105,115,116,32,112,51,50,49,41};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,29),40,118,97,108,105,100,97,116,101,45,112,97,116,116,101,114,110,32,112,97,116,116,101,114,110,50,54,56,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,12),40,97,49,52,56,48,32,120,50,54,55,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,36),40,117,110,114,101,97,99,104,97,98,108,101,32,112,108,105,115,116,50,54,53,32,109,97,116,99,104,45,101,120,112,114,50,54,54,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,12),40,97,49,52,48,56,32,120,50,54,48,41};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,12),40,97,49,52,50,48,32,120,50,54,49,41};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,12),40,97,49,52,52,53,32,120,50,54,52,41};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,27),40,101,114,114,111,114,45,109,97,107,101,114,32,109,97,116,99,104,45,101,120,112,114,50,53,57,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,11),40,97,56,50,54,32,99,50,48,52,41};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,40),40,103,101,110,109,97,116,99,104,32,120,49,57,55,32,99,108,97,117,115,101,115,49,57,56,32,109,97,116,99,104,45,101,120,112,114,49,57,57,41};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,17),40,97,49,48,54,56,32,118,50,51,51,32,103,50,51,52,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,12),40,97,49,48,55,52,32,118,50,51,50,41};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,12),40,97,49,49,48,52,32,95,50,51,49,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,47),40,103,101,110,108,101,116,114,101,99,32,112,97,116,50,49,54,32,101,120,112,50,49,55,32,98,111,100,121,50,49,56,32,109,97,116,99,104,45,101,120,112,114,50,49,57,41};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,17),40,97,49,50,52,52,32,118,50,53,50,32,103,50,53,51,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,12),40,97,49,50,55,52,32,118,50,53,49,41};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,12),40,97,49,50,56,48,32,95,50,53,48,41};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,39),40,103,101,110,100,101,102,105,110,101,32,112,97,116,50,51,54,32,101,120,112,50,51,55,32,109,97,116,99,104,45,101,120,112,114,50,51,56,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,5),40,114,97,99,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,10),40,114,100,99,32,108,54,52,48,41};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,30),40,109,97,116,99,104,45,101,114,114,111,114,45,99,111,110,116,114,111,108,32,46,32,97,114,103,54,54,55,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,33),40,109,97,116,99,104,45,101,114,114,111,114,45,112,114,111,99,101,100,117,114,101,32,46,32,112,114,111,99,54,54,56,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,6),40,103,50,48,57,41};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,15),40,97,55,52,57,54,32,97,114,103,115,49,54,50,41};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,32),40,103,49,57,57,32,101,49,49,48,54,32,112,50,49,48,55,32,101,50,49,48,56,32,98,111,100,121,49,48,57,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,6),40,103,49,57,53,41};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,28),40,103,49,57,52,32,112,97,116,49,49,48,32,101,120,112,49,49,49,32,98,111,100,121,49,49,50,41};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,28),40,103,49,56,54,32,112,97,116,49,49,51,32,101,120,112,49,49,52,32,98,111,100,121,49,49,53,41};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,49,56,32,103,49,56,56,49,49,57,32,103,49,56,55,49,50,48,41};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,50,51,32,103,49,56,56,49,50,52,32,103,49,56,55,49,50,53,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,50,56,32,103,49,56,56,49,50,57,32,103,49,56,55,49,51,48,41};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,51,51,32,103,49,56,56,49,51,52,32,103,49,56,55,49,51,53,41};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,51,56,32,103,49,56,56,49,51,57,32,103,49,56,55,49,52,48,41};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,15),40,97,56,51,54,48,32,103,50,48,54,49,49,54,41};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,52,51,32,103,49,56,56,49,52,52,32,103,49,56,55,49,52,53,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,52,56,32,103,49,56,56,49,52,57,32,103,49,56,55,49,53,48,41};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,53,51,32,103,49,56,56,49,53,52,32,103,49,56,55,49,53,53,41};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,30),40,103,49,56,57,32,103,49,57,48,49,53,56,32,103,49,56,56,49,53,57,32,103,49,56,55,49,54,48,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,14),40,97,55,53,57,57,32,97,114,103,115,57,57,41};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,6),40,103,49,55,54,41};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,14),40,97,56,57,54,54,32,97,114,103,115,57,50,41};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,19),40,103,49,53,56,32,101,120,112,50,50,32,98,111,100,121,50,51,41};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,11),40,97,57,49,57,51,32,120,50,57,41};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,25),40,103,49,53,52,32,112,97,116,50,52,32,101,120,112,50,53,32,98,111,100,121,50,54,41};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,6),40,103,49,52,54,41};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,33),40,103,49,52,53,32,112,49,51,48,32,101,49,51,49,32,112,50,51,50,32,101,50,51,51,32,98,111,100,121,51,52,41};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,27),40,103,49,54,49,32,103,49,54,50,51,56,32,103,49,54,48,51,57,32,103,49,53,57,52,48,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,52,56,32,103,49,52,56,52,57,32,103,49,52,55,53,48,41};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,53,51,32,103,49,52,56,53,52,32,103,49,52,55,53,53,41};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,53,56,32,103,49,52,56,53,57,32,103,49,52,55,54,48,41};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,54,51,32,103,49,52,56,54,52,32,103,49,52,55,54,53,41};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,54,56,32,103,49,52,56,54,57,32,103,49,52,55,55,48,41};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,15),40,97,49,48,48,57,52,32,103,49,54,55,52,54,41};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,55,51,32,103,49,52,56,55,52,32,103,49,52,55,55,53,41};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,55,56,32,103,49,52,56,55,57,32,103,49,52,55,56,48,41};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,56,51,32,103,49,52,56,56,52,32,103,49,52,55,56,53,41};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,27),40,103,49,52,57,32,103,49,53,48,56,56,32,103,49,52,56,56,57,32,103,49,52,55,57,48,41};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,14),40,97,57,49,53,52,32,97,114,103,115,49,53,41};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,52,48,32,103,49,51,52,49,51,41};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,15),40,97,49,48,55,48,52,32,97,114,103,115,49,50,41};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,15),40,97,49,48,56,48,54,32,103,49,50,54,49,48,41};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,14),40,97,49,48,55,54,54,32,97,114,103,115,57,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,11),40,97,49,48,57,49,51,32,121,53,41};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,14),40,97,49,48,56,51,50,32,97,114,103,115,52,41};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41};


C_noret_decl(C_match_toplevel)
C_externexport void C_ccall C_match_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10833)
static void C_ccall f_10833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10914)
static void C_ccall f_10914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10840)
static void C_ccall f_10840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10849)
static void C_ccall f_10849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10876)
static void C_ccall f_10876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10767)
static void C_ccall f_10767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10807)
static void C_ccall f_10807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10814)
static void C_fcall f_10814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10774)
static void C_ccall f_10774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10777)
static void C_ccall f_10777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10741)
static void C_ccall f_10741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10748)
static void C_fcall f_10748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10712)
static void C_ccall f_10712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10715)
static void C_ccall f_10715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_725)
static void C_ccall f_725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9155)
static void C_ccall f_9155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10685)
static void C_ccall f_10685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10681)
static void C_ccall f_10681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10677)
static void C_ccall f_10677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10145)
static void C_fcall f_10145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10560)
static void C_fcall f_10560(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10657)
static void C_ccall f_10657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10653)
static void C_ccall f_10653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10611)
static void C_fcall f_10611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10634)
static void C_ccall f_10634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10630)
static void C_ccall f_10630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10573)
static void C_fcall f_10573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10580)
static void C_ccall f_10580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10584)
static void C_ccall f_10584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10551)
static void C_ccall f_10551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10547)
static void C_ccall f_10547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10543)
static void C_ccall f_10543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10539)
static void C_ccall f_10539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10535)
static void C_ccall f_10535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10527)
static void C_ccall f_10527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10267)
static void C_fcall f_10267(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10398)
static void C_fcall f_10398(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10495)
static void C_ccall f_10495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10491)
static void C_ccall f_10491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10449)
static void C_fcall f_10449(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10472)
static void C_ccall f_10472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10468)
static void C_ccall f_10468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10411)
static void C_fcall f_10411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10418)
static void C_ccall f_10418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10422)
static void C_ccall f_10422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10273)
static void C_fcall f_10273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10309)
static void C_fcall f_10309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10371)
static void C_ccall f_10371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10367)
static void C_ccall f_10367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10325)
static void C_fcall f_10325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10348)
static void C_ccall f_10348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10344)
static void C_ccall f_10344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10280)
static void C_ccall f_10280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10284)
static void C_ccall f_10284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10288)
static void C_ccall f_10288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10300)
static void C_ccall f_10300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10157)
static void C_fcall f_10157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10181)
static void C_fcall f_10181(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10243)
static void C_ccall f_10243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10239)
static void C_ccall f_10239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10197)
static void C_fcall f_10197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10220)
static void C_ccall f_10220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10216)
static void C_ccall f_10216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10164)
static void C_ccall f_10164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10168)
static void C_ccall f_10168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10095)
static void C_ccall f_10095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10118)
static void C_ccall f_10118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10102)
static void C_fcall f_10102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9439)
static void C_ccall f_9439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10089)
static void C_ccall f_10089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10085)
static void C_ccall f_10085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10081)
static void C_ccall f_10081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_fcall f_9543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9958)
static void C_fcall f_9958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10055)
static void C_ccall f_10055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10051)
static void C_ccall f_10051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10009)
static void C_fcall f_10009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10032)
static void C_ccall f_10032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10028)
static void C_ccall f_10028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9971)
static void C_fcall f_9971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9978)
static void C_ccall f_9978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9982)
static void C_ccall f_9982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9949)
static void C_ccall f_9949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9945)
static void C_ccall f_9945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9941)
static void C_ccall f_9941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9937)
static void C_ccall f_9937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9925)
static void C_ccall f_9925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9665)
static void C_fcall f_9665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9796)
static void C_fcall f_9796(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9889)
static void C_ccall f_9889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9847)
static void C_fcall f_9847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9870)
static void C_ccall f_9870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9866)
static void C_ccall f_9866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9809)
static void C_fcall f_9809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9816)
static void C_ccall f_9816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9820)
static void C_ccall f_9820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9671)
static void C_fcall f_9671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9707)
static void C_fcall f_9707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9769)
static void C_ccall f_9769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9765)
static void C_ccall f_9765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9723)
static void C_fcall f_9723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9746)
static void C_ccall f_9746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9742)
static void C_ccall f_9742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9678)
static void C_ccall f_9678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9682)
static void C_ccall f_9682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9686)
static void C_ccall f_9686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9698)
static void C_ccall f_9698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9555)
static void C_fcall f_9555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9579)
static void C_fcall f_9579(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9641)
static void C_ccall f_9641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9637)
static void C_ccall f_9637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9595)
static void C_fcall f_9595(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9618)
static void C_ccall f_9618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9614)
static void C_ccall f_9614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9562)
static void C_ccall f_9562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9566)
static void C_ccall f_9566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9445)
static void C_fcall f_9445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_fcall f_9457(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9519)
static void C_ccall f_9519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9515)
static void C_ccall f_9515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9473)
static void C_fcall f_9473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9496)
static void C_ccall f_9496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9267)
static void C_fcall f_9267(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9276)
static void C_fcall f_9276(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9406)
static void C_ccall f_9406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9402)
static void C_ccall f_9402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9360)
static void C_fcall f_9360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9383)
static void C_ccall f_9383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9289)
static void C_fcall f_9289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9295)
static void C_ccall f_9295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9298)
static void C_ccall f_9298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9307)
static void C_ccall f_9307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9208)
static void C_fcall f_9208(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9212)
static void C_ccall f_9212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9215)
static void C_ccall f_9215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9199)
static void C_fcall f_9199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9166)
static void C_fcall f_9166(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9173)
static void C_ccall f_9173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9180)
static void C_ccall f_9180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9157)
static C_word C_fcall f_9157(C_word *a,C_word t0,C_word t1,C_word t2);
C_noret_decl(f_728)
static void C_ccall f_728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8967)
static void C_ccall f_8967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9142)
static void C_ccall f_9142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9134)
static void C_ccall f_9134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9130)
static void C_ccall f_9130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9024)
static void C_fcall f_9024(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9027)
static void C_ccall f_9027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9030)
static void C_ccall f_9030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9033)
static void C_ccall f_9033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9042)
static void C_ccall f_9042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_fcall f_8995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8969)
static void C_fcall f_8969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8951)
static void C_ccall f_8951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8947)
static void C_ccall f_8947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8943)
static void C_ccall f_8943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_fcall f_8411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8826)
static void C_fcall f_8826(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8923)
static void C_ccall f_8923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8919)
static void C_ccall f_8919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8877)
static void C_fcall f_8877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8900)
static void C_ccall f_8900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8896)
static void C_ccall f_8896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8839)
static void C_fcall f_8839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8846)
static void C_ccall f_8846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8850)
static void C_ccall f_8850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8813)
static void C_ccall f_8813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8809)
static void C_ccall f_8809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8805)
static void C_ccall f_8805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8801)
static void C_ccall f_8801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8793)
static void C_ccall f_8793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8533)
static void C_fcall f_8533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_fcall f_8664(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8761)
static void C_ccall f_8761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8715)
static void C_fcall f_8715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8738)
static void C_ccall f_8738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8734)
static void C_ccall f_8734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8677)
static void C_fcall f_8677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8539)
static void C_fcall f_8539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8575)
static void C_fcall f_8575(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8637)
static void C_ccall f_8637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8633)
static void C_ccall f_8633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8591)
static void C_fcall f_8591(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8614)
static void C_ccall f_8614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8610)
static void C_ccall f_8610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_ccall f_8546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8550)
static void C_ccall f_8550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8554)
static void C_ccall f_8554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8566)
static void C_ccall f_8566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8423)
static void C_fcall f_8423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8447)
static void C_fcall f_8447(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8463)
static void C_fcall f_8463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8486)
static void C_ccall f_8486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8482)
static void C_ccall f_8482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_ccall f_8430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8434)
static void C_ccall f_8434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8361)
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8384)
static void C_ccall f_8384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8368)
static void C_fcall f_8368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7705)
static void C_ccall f_7705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8355)
static void C_ccall f_8355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8351)
static void C_ccall f_8351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8347)
static void C_ccall f_8347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7809)
static void C_fcall f_7809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8224)
static void C_fcall f_8224(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8317)
static void C_ccall f_8317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8275)
static void C_fcall f_8275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8298)
static void C_ccall f_8298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8294)
static void C_ccall f_8294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8237)
static void C_fcall f_8237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8244)
static void C_ccall f_8244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8248)
static void C_ccall f_8248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8215)
static void C_ccall f_8215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8211)
static void C_ccall f_8211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8207)
static void C_ccall f_8207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_ccall f_8203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8199)
static void C_ccall f_8199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7931)
static void C_fcall f_7931(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8062)
static void C_fcall f_8062(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8159)
static void C_ccall f_8159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8155)
static void C_ccall f_8155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8113)
static void C_fcall f_8113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8136)
static void C_ccall f_8136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8132)
static void C_ccall f_8132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8075)
static void C_fcall f_8075(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8082)
static void C_ccall f_8082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8086)
static void C_ccall f_8086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7937)
static void C_fcall f_7937(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7973)
static void C_fcall f_7973(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8035)
static void C_ccall f_8035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8031)
static void C_ccall f_8031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7989)
static void C_fcall f_7989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8012)
static void C_ccall f_8012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8008)
static void C_ccall f_8008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_ccall f_7944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_ccall f_7948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_ccall f_7952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7964)
static void C_ccall f_7964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7821)
static void C_fcall f_7821(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7845)
static void C_fcall f_7845(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7907)
static void C_ccall f_7907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7861)
static void C_fcall f_7861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7884)
static void C_ccall f_7884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7832)
static void C_ccall f_7832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7711)
static void C_fcall f_7711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7723)
static void C_fcall f_7723(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7785)
static void C_ccall f_7785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7739)
static void C_fcall f_7739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_ccall f_7762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7758)
static void C_ccall f_7758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7664)
static void C_fcall f_7664(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7639)
static void C_fcall f_7639(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7659)
static void C_ccall f_7659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7630)
static void C_fcall f_7630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7605)
static C_word C_fcall f_7605(C_word *a,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4);
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7497)
static void C_ccall f_7497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7522)
static void C_ccall f_7522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_fcall f_7558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7528)
static void C_fcall f_7528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_fcall f_7502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_737)
static void C_ccall f_737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_ccall f_7495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7478)
static void C_ccall f_7478r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7462)
static void C_ccall f_7462r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7431)
static void C_fcall f_7431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static C_word C_fcall f_7408(C_word t0);
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1231)
static void C_ccall f_1231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1005)
static void C_ccall f_1005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1023)
static void C_ccall f_1023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_766)
static void C_ccall f_766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_949)
static void C_ccall f_949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_778)
static void C_ccall f_778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_fcall f_1397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1475)
static void C_fcall f_1475(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1505)
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2530)
static void C_fcall f_2530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_fcall f_2352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_fcall f_2391(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_fcall f_2315(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_fcall f_2270(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_fcall f_2109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_fcall f_2034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_fcall f_1987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_fcall f_1923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_fcall f_1876(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_fcall f_1829(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_fcall f_1782(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_fcall f_1722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_fcall f_1668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_fcall f_1631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_fcall f_1588(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_fcall f_1540(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static C_word C_fcall f_1508(C_word t0);
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_fcall f_2570(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_fcall f_3364(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3271)
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_fcall f_3289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3273)
static void C_fcall f_3273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_fcall f_2574(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2612)
static void C_fcall f_2612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_fcall f_2621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2713)
static void C_fcall f_2713(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2790)
static void C_fcall f_2790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_fcall f_2813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_fcall f_2902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_fcall f_3015(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_fcall f_3046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_fcall f_3076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2846)
static void C_fcall f_2846(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2865)
static void C_ccall f_2865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2832)
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2722)
static void C_fcall f_2722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_fcall f_2659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_fcall f_3403(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_fcall f_3427(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3466)
static void C_fcall f_3466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_fcall f_3726(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_fcall f_3475(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_fcall f_3780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_fcall f_3515(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3533)
static void C_ccall f_3533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static C_word C_fcall f_3653(C_word t0,C_word t1);
C_noret_decl(f_3631)
static C_word C_fcall f_3631(C_word t0,C_word t1);
C_noret_decl(f_3549)
static C_word C_fcall f_3549(C_word t0);
C_noret_decl(f_3850)
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_fcall f_3977(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_4088)
static void C_fcall f_4088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_fcall f_4101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_fcall f_4117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_fcall f_4138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_fcall f_4180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_fcall f_4223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_fcall f_4236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_fcall f_4298(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_fcall f_4323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4939)
static void C_fcall f_4939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_fcall f_4729(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4753)
static void C_ccall f_4753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4867)
static void C_ccall f_4867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4831)
static void C_ccall f_4831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_ccall f_4782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4362)
static void C_ccall f_4362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4471)
static void C_fcall f_4471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4521)
static void C_ccall f_4521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_fcall f_4405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_fcall f_4387(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4402)
static void C_ccall f_4402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_fcall f_4257(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_fcall f_4189(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4147)
static void C_fcall f_4147(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3861)
static void C_ccall f_3861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1329)
static void C_fcall f_1329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5123)
static void C_fcall f_5123(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_fcall f_5261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_fcall f_5148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_fcall f_5154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_fcall f_5330(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6125)
static void C_ccall f_6125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_ccall f_6117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6105)
static void C_ccall f_6105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6089)
static void C_ccall f_6089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_ccall f_6081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6061)
static void C_ccall f_6061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_ccall f_6053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6033)
static void C_ccall f_6033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6029)
static void C_ccall f_6029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6025)
static void C_ccall f_6025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5985)
static void C_ccall f_5985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_ccall f_5969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5965)
static void C_ccall f_5965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5905)
static void C_ccall f_5905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5901)
static void C_ccall f_5901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_ccall f_5897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_fcall f_5388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_ccall f_5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6199)
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6211)
static void C_fcall f_6211(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6278)
static void C_fcall f_6278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6242)
static void C_ccall f_6242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_fcall f_6330(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6340)
static void C_fcall f_6340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_fcall f_6547(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6560)
static void C_fcall f_6560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6481)
static void C_fcall f_6481(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6494)
static void C_fcall f_6494(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6376)
static void C_fcall f_6376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6407)
static void C_ccall f_6407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6388)
static void C_fcall f_6388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_fcall f_6640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6680)
static void C_fcall f_6680(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static C_word C_fcall f_6726(C_word t0);
C_noret_decl(f_6736)
static void C_fcall f_6736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6740)
static void C_fcall f_6740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6769)
static void C_fcall f_6769(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6773)
static void C_fcall f_6773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_fcall f_6803(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6997)
static void C_fcall f_6997(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_ccall f_7023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6805)
static void C_fcall f_6805(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7108)
static void C_fcall f_7108(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7277)
static void C_fcall f_7277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_fcall f_7373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7381)
static void C_ccall f_7381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_692)
static void C_fcall f_692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_705)
static void C_ccall f_705(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_10814)
static void C_fcall trf_10814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10814(t0,t1);}

C_noret_decl(trf_10748)
static void C_fcall trf_10748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10748(t0,t1);}

C_noret_decl(trf_10145)
static void C_fcall trf_10145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10145(t0,t1);}

C_noret_decl(trf_10560)
static void C_fcall trf_10560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10560(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10560(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10611)
static void C_fcall trf_10611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10611(t0,t1);}

C_noret_decl(trf_10573)
static void C_fcall trf_10573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10573(t0,t1);}

C_noret_decl(trf_10267)
static void C_fcall trf_10267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10267(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10267(t0,t1);}

C_noret_decl(trf_10398)
static void C_fcall trf_10398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10398(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10398(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10449)
static void C_fcall trf_10449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10449(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10449(t0,t1);}

C_noret_decl(trf_10411)
static void C_fcall trf_10411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10411(t0,t1);}

C_noret_decl(trf_10273)
static void C_fcall trf_10273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10273(t0,t1);}

C_noret_decl(trf_10309)
static void C_fcall trf_10309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10309(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10309(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10325)
static void C_fcall trf_10325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10325(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10325(t0,t1);}

C_noret_decl(trf_10157)
static void C_fcall trf_10157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10157(t0,t1);}

C_noret_decl(trf_10181)
static void C_fcall trf_10181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10181(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10181(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10197)
static void C_fcall trf_10197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10197(t0,t1);}

C_noret_decl(trf_10102)
static void C_fcall trf_10102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10102(t0,t1);}

C_noret_decl(trf_9543)
static void C_fcall trf_9543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9543(t0,t1);}

C_noret_decl(trf_9958)
static void C_fcall trf_9958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9958(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9958(t0,t1,t2,t3,t4);}

C_noret_decl(trf_10009)
static void C_fcall trf_10009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10009(t0,t1);}

C_noret_decl(trf_9971)
static void C_fcall trf_9971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9971(t0,t1);}

C_noret_decl(trf_9665)
static void C_fcall trf_9665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9665(t0,t1);}

C_noret_decl(trf_9796)
static void C_fcall trf_9796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9796(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9796(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9847)
static void C_fcall trf_9847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9847(t0,t1);}

C_noret_decl(trf_9809)
static void C_fcall trf_9809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9809(t0,t1);}

C_noret_decl(trf_9671)
static void C_fcall trf_9671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9671(t0,t1);}

C_noret_decl(trf_9707)
static void C_fcall trf_9707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9707(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9707(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9723)
static void C_fcall trf_9723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9723(t0,t1);}

C_noret_decl(trf_9555)
static void C_fcall trf_9555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9555(t0,t1);}

C_noret_decl(trf_9579)
static void C_fcall trf_9579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9579(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9579(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9595)
static void C_fcall trf_9595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9595(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9595(t0,t1);}

C_noret_decl(trf_9445)
static void C_fcall trf_9445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9445(t0,t1);}

C_noret_decl(trf_9457)
static void C_fcall trf_9457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9457(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9457(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9473)
static void C_fcall trf_9473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9473(t0,t1);}

C_noret_decl(trf_9267)
static void C_fcall trf_9267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9267(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9267(t0,t1);}

C_noret_decl(trf_9276)
static void C_fcall trf_9276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9276(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9276(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9360)
static void C_fcall trf_9360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9360(t0,t1);}

C_noret_decl(trf_9289)
static void C_fcall trf_9289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9289(t0,t1);}

C_noret_decl(trf_9208)
static void C_fcall trf_9208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9208(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_9208(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_9199)
static void C_fcall trf_9199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9199(t0,t1);}

C_noret_decl(trf_9166)
static void C_fcall trf_9166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9166(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9166(t0,t1,t2,t3);}

C_noret_decl(trf_9024)
static void C_fcall trf_9024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9024(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9024(t0,t1);}

C_noret_decl(trf_8995)
static void C_fcall trf_8995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8995(t0,t1);}

C_noret_decl(trf_8969)
static void C_fcall trf_8969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8969(t0,t1);}

C_noret_decl(trf_8411)
static void C_fcall trf_8411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8411(t0,t1);}

C_noret_decl(trf_8826)
static void C_fcall trf_8826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8826(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8826(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8877)
static void C_fcall trf_8877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8877(t0,t1);}

C_noret_decl(trf_8839)
static void C_fcall trf_8839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8839(t0,t1);}

C_noret_decl(trf_8533)
static void C_fcall trf_8533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8533(t0,t1);}

C_noret_decl(trf_8664)
static void C_fcall trf_8664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8664(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8664(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8715)
static void C_fcall trf_8715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8715(t0,t1);}

C_noret_decl(trf_8677)
static void C_fcall trf_8677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8677(t0,t1);}

C_noret_decl(trf_8539)
static void C_fcall trf_8539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8539(t0,t1);}

C_noret_decl(trf_8575)
static void C_fcall trf_8575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8575(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8575(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8591)
static void C_fcall trf_8591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8591(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8591(t0,t1);}

C_noret_decl(trf_8423)
static void C_fcall trf_8423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8423(t0,t1);}

C_noret_decl(trf_8447)
static void C_fcall trf_8447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8447(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8447(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8463)
static void C_fcall trf_8463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8463(t0,t1);}

C_noret_decl(trf_8368)
static void C_fcall trf_8368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8368(t0,t1);}

C_noret_decl(trf_7809)
static void C_fcall trf_7809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7809(t0,t1);}

C_noret_decl(trf_8224)
static void C_fcall trf_8224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8224(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8224(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8275)
static void C_fcall trf_8275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8275(t0,t1);}

C_noret_decl(trf_8237)
static void C_fcall trf_8237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8237(t0,t1);}

C_noret_decl(trf_7931)
static void C_fcall trf_7931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7931(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7931(t0,t1);}

C_noret_decl(trf_8062)
static void C_fcall trf_8062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8062(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8062(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8113)
static void C_fcall trf_8113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8113(t0,t1);}

C_noret_decl(trf_8075)
static void C_fcall trf_8075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8075(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8075(t0,t1);}

C_noret_decl(trf_7937)
static void C_fcall trf_7937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7937(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7937(t0,t1);}

C_noret_decl(trf_7973)
static void C_fcall trf_7973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7973(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7973(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7989)
static void C_fcall trf_7989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7989(t0,t1);}

C_noret_decl(trf_7821)
static void C_fcall trf_7821(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7821(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7821(t0,t1);}

C_noret_decl(trf_7845)
static void C_fcall trf_7845(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7845(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7845(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7861)
static void C_fcall trf_7861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7861(t0,t1);}

C_noret_decl(trf_7711)
static void C_fcall trf_7711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7711(t0,t1);}

C_noret_decl(trf_7723)
static void C_fcall trf_7723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7723(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7723(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7739)
static void C_fcall trf_7739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7739(t0,t1);}

C_noret_decl(trf_7664)
static void C_fcall trf_7664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7664(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7664(t0,t1,t2,t3);}

C_noret_decl(trf_7639)
static void C_fcall trf_7639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7639(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7639(t0,t1,t2,t3);}

C_noret_decl(trf_7630)
static void C_fcall trf_7630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7630(t0,t1);}

C_noret_decl(trf_7558)
static void C_fcall trf_7558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7558(t0,t1);}

C_noret_decl(trf_7528)
static void C_fcall trf_7528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7528(t0,t1);}

C_noret_decl(trf_7502)
static void C_fcall trf_7502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7502(t0,t1);}

C_noret_decl(trf_7431)
static void C_fcall trf_7431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7431(t0,t1,t2);}

C_noret_decl(trf_1397)
static void C_fcall trf_1397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1397(t0,t1);}

C_noret_decl(trf_1475)
static void C_fcall trf_1475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1475(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1475(t0,t1,t2);}

C_noret_decl(trf_1505)
static void C_fcall trf_1505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1505(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1505(t0,t1,t2);}

C_noret_decl(trf_2530)
static void C_fcall trf_2530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2530(t0,t1,t2);}

C_noret_decl(trf_2352)
static void C_fcall trf_2352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2352(t0,t1);}

C_noret_decl(trf_2391)
static void C_fcall trf_2391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2391(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2391(t0,t1);}

C_noret_decl(trf_2315)
static void C_fcall trf_2315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2315(t0,t1);}

C_noret_decl(trf_2270)
static void C_fcall trf_2270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2270(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2270(t0,t1,t2,t3);}

C_noret_decl(trf_2109)
static void C_fcall trf_2109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2109(t0,t1);}

C_noret_decl(trf_2034)
static void C_fcall trf_2034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2034(t0,t1);}

C_noret_decl(trf_1987)
static void C_fcall trf_1987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1987(t0,t1);}

C_noret_decl(trf_1923)
static void C_fcall trf_1923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1923(t0,t1);}

C_noret_decl(trf_1876)
static void C_fcall trf_1876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1876(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1876(t0,t1);}

C_noret_decl(trf_1829)
static void C_fcall trf_1829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1829(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1829(t0,t1);}

C_noret_decl(trf_1782)
static void C_fcall trf_1782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1782(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1782(t0,t1);}

C_noret_decl(trf_1722)
static void C_fcall trf_1722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1722(t0,t1);}

C_noret_decl(trf_1668)
static void C_fcall trf_1668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1668(t0,t1);}

C_noret_decl(trf_1631)
static void C_fcall trf_1631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1631(t0,t1);}

C_noret_decl(trf_1588)
static void C_fcall trf_1588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1588(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1588(t0,t1);}

C_noret_decl(trf_1540)
static void C_fcall trf_1540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1540(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1540(t0,t1,t2,t3);}

C_noret_decl(trf_2570)
static void C_fcall trf_2570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2570(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2570(t0,t1,t2);}

C_noret_decl(trf_3364)
static void C_fcall trf_3364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3364(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3364(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3271)
static void C_fcall trf_3271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3271(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3271(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3289)
static void C_fcall trf_3289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3289(t0,t1);}

C_noret_decl(trf_3273)
static void C_fcall trf_3273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3273(t0,t1);}

C_noret_decl(trf_2574)
static void C_fcall trf_2574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2574(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2574(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2612)
static void C_fcall trf_2612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2612(t0,t1);}

C_noret_decl(trf_2621)
static void C_fcall trf_2621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2621(t0,t1);}

C_noret_decl(trf_2713)
static void C_fcall trf_2713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2713(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2713(t0,t1);}

C_noret_decl(trf_2790)
static void C_fcall trf_2790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2790(t0,t1);}

C_noret_decl(trf_2813)
static void C_fcall trf_2813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2813(t0,t1);}

C_noret_decl(trf_2902)
static void C_fcall trf_2902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2902(t0,t1);}

C_noret_decl(trf_3015)
static void C_fcall trf_3015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3015(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3015(t0,t1);}

C_noret_decl(trf_3046)
static void C_fcall trf_3046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3046(t0,t1);}

C_noret_decl(trf_3076)
static void C_fcall trf_3076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3076(t0,t1);}

C_noret_decl(trf_2846)
static void C_fcall trf_2846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2846(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2846(t0,t1,t2,t3);}

C_noret_decl(trf_2722)
static void C_fcall trf_2722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2722(t0,t1);}

C_noret_decl(trf_2659)
static void C_fcall trf_2659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2659(t0,t1);}

C_noret_decl(trf_3403)
static void C_fcall trf_3403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3403(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3403(t0,t1,t2,t3);}

C_noret_decl(trf_3427)
static void C_fcall trf_3427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3427(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3427(t0,t1,t2);}

C_noret_decl(trf_3466)
static void C_fcall trf_3466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3466(t0,t1);}

C_noret_decl(trf_3726)
static void C_fcall trf_3726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3726(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3726(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3475)
static void C_fcall trf_3475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3475(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3475(t0,t1,t2);}

C_noret_decl(trf_3780)
static void C_fcall trf_3780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3780(t0,t1);}

C_noret_decl(trf_3515)
static void C_fcall trf_3515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3515(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3515(t0,t1,t2);}

C_noret_decl(trf_3850)
static void C_fcall trf_3850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3850(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3850(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_3977)
static void C_fcall trf_3977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3977(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3977(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4088)
static void C_fcall trf_4088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4088(t0,t1);}

C_noret_decl(trf_4101)
static void C_fcall trf_4101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4101(t0,t1);}

C_noret_decl(trf_4117)
static void C_fcall trf_4117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4117(t0,t1);}

C_noret_decl(trf_4138)
static void C_fcall trf_4138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4138(t0,t1);}

C_noret_decl(trf_4180)
static void C_fcall trf_4180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4180(t0,t1);}

C_noret_decl(trf_4223)
static void C_fcall trf_4223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4223(t0,t1);}

C_noret_decl(trf_4236)
static void C_fcall trf_4236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4236(t0,t1);}

C_noret_decl(trf_4298)
static void C_fcall trf_4298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4298(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4298(t0,t1);}

C_noret_decl(trf_4323)
static void C_fcall trf_4323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4323(t0,t1);}

C_noret_decl(trf_4939)
static void C_fcall trf_4939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4939(t0,t1,t2);}

C_noret_decl(trf_4729)
static void C_fcall trf_4729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4729(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4729(t0,t1,t2);}

C_noret_decl(trf_4471)
static void C_fcall trf_4471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4471(t0,t1);}

C_noret_decl(trf_4405)
static void C_fcall trf_4405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4405(t0,t1);}

C_noret_decl(trf_4387)
static void C_fcall trf_4387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4387(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4387(t0,t1);}

C_noret_decl(trf_4257)
static void C_fcall trf_4257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4257(t0,t1,t2);}

C_noret_decl(trf_4189)
static void C_fcall trf_4189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4189(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4189(t0,t1,t2,t3);}

C_noret_decl(trf_4147)
static void C_fcall trf_4147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4147(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4147(t0,t1,t2,t3);}

C_noret_decl(trf_1329)
static void C_fcall trf_1329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1329(t0,t1);}

C_noret_decl(trf_5123)
static void C_fcall trf_5123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5123(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5123(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5261)
static void C_fcall trf_5261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5261(t0,t1);}

C_noret_decl(trf_5148)
static void C_fcall trf_5148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5148(t0,t1);}

C_noret_decl(trf_5154)
static void C_fcall trf_5154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5154(t0,t1);}

C_noret_decl(trf_5305)
static void C_fcall trf_5305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5305(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5305(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5330)
static void C_fcall trf_5330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5330(t0,t1);}

C_noret_decl(trf_5388)
static void C_fcall trf_5388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5388(t0,t1);}

C_noret_decl(trf_6199)
static void C_fcall trf_6199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6199(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6199(t0,t1,t2,t3);}

C_noret_decl(trf_6211)
static void C_fcall trf_6211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6211(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6211(t0,t1,t2);}

C_noret_decl(trf_6278)
static void C_fcall trf_6278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6278(t0,t1);}

C_noret_decl(trf_6330)
static void C_fcall trf_6330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6330(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6330(t0,t1,t2,t3);}

C_noret_decl(trf_6340)
static void C_fcall trf_6340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6340(t0,t1);}

C_noret_decl(trf_6547)
static void C_fcall trf_6547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6547(t0,t1,t2);}

C_noret_decl(trf_6560)
static void C_fcall trf_6560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6560(t0,t1);}

C_noret_decl(trf_6481)
static void C_fcall trf_6481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6481(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6481(t0,t1,t2);}

C_noret_decl(trf_6494)
static void C_fcall trf_6494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6494(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6494(t0,t1);}

C_noret_decl(trf_6363)
static void C_fcall trf_6363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6363(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6363(t0,t1,t2);}

C_noret_decl(trf_6376)
static void C_fcall trf_6376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6376(t0,t1);}

C_noret_decl(trf_6388)
static void C_fcall trf_6388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6388(t0,t1);}

C_noret_decl(trf_6640)
static void C_fcall trf_6640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6640(t0,t1);}

C_noret_decl(trf_6680)
static void C_fcall trf_6680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6680(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6680(t0,t1);}

C_noret_decl(trf_6736)
static void C_fcall trf_6736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6736(t0,t1,t2);}

C_noret_decl(trf_6740)
static void C_fcall trf_6740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6740(t0,t1);}

C_noret_decl(trf_6769)
static void C_fcall trf_6769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6769(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6769(t0,t1,t2);}

C_noret_decl(trf_6773)
static void C_fcall trf_6773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6773(t0,t1);}

C_noret_decl(trf_6803)
static void C_fcall trf_6803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6803(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6803(t0,t1,t2,t3);}

C_noret_decl(trf_6997)
static void C_fcall trf_6997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6997(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6997(t0,t1);}

C_noret_decl(trf_6805)
static void C_fcall trf_6805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6805(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6805(t0,t1,t2);}

C_noret_decl(trf_7108)
static void C_fcall trf_7108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7108(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7108(t0,t1,t2,t3);}

C_noret_decl(trf_7277)
static void C_fcall trf_7277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7277(t0,t1);}

C_noret_decl(trf_7373)
static void C_fcall trf_7373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7373(t0,t1);}

C_noret_decl(trf_692)
static void C_fcall trf_692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_692(t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_match_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_match_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("match_toplevel"));
C_check_nursery_minimum(9);
if(!C_demand(9)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3339)){
C_save(t1);
C_rereclaim2(3339*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(9);
C_initialize_lf(lf,153);
lf[0]=C_h_intern(&lf[0],13,"\005matchversion");
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000*Version 1.18, July 17, 1995 (Chicken port)");
lf[3]=C_h_intern(&lf[3],16,"\005matchsyntax-err");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_h_intern(&lf[5],13,"\000syntax-error");
lf[6]=C_h_intern(&lf[6],15,"\005matchset-error");
lf[7]=C_h_intern(&lf[7],15,"\003sysmatch-error");
lf[8]=C_h_intern(&lf[8],19,"\005matcherror-control");
lf[9]=C_h_intern(&lf[9],6,"\000error");
lf[10]=C_h_intern(&lf[10],23,"\005matchset-error-control");
lf[11]=C_h_intern(&lf[11],4,"null");
lf[12]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\007number\077\376\003\000\000\002\376\001\000\000\007str"
"ing\077\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000\002\376\001\000\000\012procedure\077\376\003\000\000\002\376\001\000\000\007vector\077\376\377\016");
lf[13]=C_h_intern(&lf[13],25,"\005matchdisjoint-predicates");
lf[14]=C_h_intern(&lf[14],14,"string->symbol");
lf[15]=C_h_intern(&lf[15],13,"string-append");
lf[16]=C_h_intern(&lf[16],14,"symbol->string");
lf[17]=C_h_intern(&lf[17],7,"\003sysmap");
lf[18]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\003car\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cadr\376\003\000\000\002\376\001\000\000\003cdr\376\001\000\000\003car"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\003car\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\003cdr\376\001\000\000\003cdr"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\004caar\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\004cadr\376\001\000\000"
"\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\004cdar\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005caddr\376\003\000\000\002\376\001\000\000\004cddr"
"\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\004caar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\004"
"cadr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\004cdar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376"
"\001\000\000\004cddr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006caaaar\376\003\000\000\002\376\001\000\000\005caaar\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006caaad"
"r\376\003\000\000\002\376\001\000\000\005caadr\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\005cadar\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\006caaddr\376\003\000\000\002\376\001\000\000\005caddr\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\005cdaar\376\001\000\000\003car\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\006cadadr\376\003\000\000\002\376\001\000\000\005cdadr\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006caddar\376\003\000\000\002\376\001\000\000\005cddar\376\001\000\000"
"\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\005cdddr\376\001\000\000\003car\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\005c"
"aaar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\005caadr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000"
"\000\002\376\001\000\000\005cadar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cdaddr\376\003\000\000\002\376\001\000\000\005caddr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006c"
"ddaar\376\003\000\000\002\376\001\000\000\005cdaar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\005cdadr\376\001\000\000\003cdr\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\005cddar\376\001\000\000\003cdr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\005cdddr\376\001\000\000\003cdr"
"\376\377\016");
lf[19]=C_h_intern(&lf[19],10,"vector-ref");
lf[20]=C_h_intern(&lf[20],1,"x");
lf[21]=C_h_intern(&lf[21],6,"lambda");
lf[22]=C_h_intern(&lf[22],3,"let");
lf[23]=C_h_intern(&lf[23],5,"unbox");
lf[24]=C_h_intern(&lf[24],3,"car");
lf[25]=C_h_intern(&lf[25],3,"cdr");
lf[26]=C_h_intern(&lf[26],13,"\003sysblock-ref");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\025unnested get! pattern");
lf[28]=C_h_intern(&lf[28],4,"set-");
lf[29]=C_h_intern(&lf[29],1,"!");
lf[30]=C_h_intern(&lf[30],1,"y");
lf[31]=C_h_intern(&lf[31],11,"vector-set!");
lf[32]=C_h_intern(&lf[32],8,"set-box!");
lf[33]=C_h_intern(&lf[33],8,"set-car!");
lf[34]=C_h_intern(&lf[34],8,"set-cdr!");
lf[35]=C_h_intern(&lf[35],14,"\003sysblock-set!");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\025unnested set! pattern");
lf[37]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\004caar\376\001\000\000\004cdar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004cadr\376\001\000\000\004cd"
"dr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\005caaar\376\001\000\000\005cdaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cadr\376\003\000\000\002\376\001\000\000\005caadr"
"\376\001\000\000\005cdadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\005cadar\376\001\000\000\005cddar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001"
"\000\000\005caddr\376\001\000\000\005cdddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\006caaaar\376\001\000\000\006cdaaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005"
"caadr\376\003\000\000\002\376\001\000\000\006caaadr\376\001\000\000\006cdaadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\006caadar\376\001\000\000\006cdadar\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\005caddr\376\003\000\000\002\376\001\000\000\006caaddr\376\001\000\000\006cdaddr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\006cada"
"ar\376\001\000\000\006cddaar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\006cadadr\376\001\000\000\006cddadr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cddar"
"\376\003\000\000\002\376\001\000\000\006caddar\376\001\000\000\006cdddar\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006cadddr\376\001\000\000\006cddddr\376\377\016");
lf[38]=C_h_intern(&lf[38],6,"equal\077");
lf[39]=C_h_intern(&lf[39],7,"string\077");
lf[40]=C_h_intern(&lf[40],8,"boolean\077");
lf[41]=C_h_intern(&lf[41],5,"char\077");
lf[42]=C_h_intern(&lf[42],7,"number\077");
lf[43]=C_h_intern(&lf[43],7,"symbol\077");
lf[44]=C_h_intern(&lf[44],5,"quote");
lf[45]=C_h_intern(&lf[45],3,"not");
lf[46]=C_h_intern(&lf[46],5,"list\077");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\005null\077\376\377\016");
lf[48]=C_h_intern(&lf[48],5,"null\077");
lf[49]=C_h_intern(&lf[49],5,"pair\077");
lf[50]=C_h_intern(&lf[50],4,"cond");
lf[51]=C_h_intern(&lf[51],2,"if");
lf[52]=C_h_intern(&lf[52],3,"and");
lf[53]=C_h_intern(&lf[53],30,"call-with-current-continuation");
lf[54]=C_h_intern(&lf[54],6,"caddar");
lf[55]=C_h_intern(&lf[55],6,"cddadr");
lf[56]=C_h_intern(&lf[56],6,"caadar");
lf[57]=C_h_intern(&lf[57],6,"cadadr");
lf[58]=C_h_intern(&lf[58],5,"cadar");
lf[59]=C_h_intern(&lf[59],6,"cdddar");
lf[60]=C_h_intern(&lf[60],5,"cddar");
lf[61]=C_h_intern(&lf[61],6,"cdadar");
lf[62]=C_h_intern(&lf[62],4,"cdar");
lf[63]=C_h_intern(&lf[63],5,"cdadr");
lf[64]=C_h_intern(&lf[64],5,"caadr");
lf[65]=C_h_intern(&lf[65],4,"caar");
lf[66]=C_h_intern(&lf[66],12,"\000unspecified");
lf[67]=C_h_intern(&lf[67],5,"\000fail");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_h_intern(&lf[69],3,"...");
lf[70]=C_h_intern(&lf[70],3,"___");
lf[71]=C_h_intern(&lf[71],9,"substring");
lf[72]=C_h_intern(&lf[72],13,"char-numeric\077");
lf[73]=C_h_intern(&lf[73],16,"\003sysstring->list");
lf[74]=C_h_intern(&lf[74],1,"_");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016");
lf[76]=C_h_intern(&lf[76],1,"\077");
lf[77]=C_h_intern(&lf[77],5,"every");
lf[78]=C_h_intern(&lf[78],3,"map");
lf[79]=C_h_intern(&lf[79],4,"cons");
lf[80]=C_h_intern(&lf[80],7,"reverse");
lf[81]=C_h_intern(&lf[81],7,"vector\077");
lf[82]=C_h_intern(&lf[82],13,"vector-length");
lf[83]=C_h_intern(&lf[83],2,">=");
lf[84]=C_h_intern(&lf[84],1,"-");
lf[85]=C_h_intern(&lf[85],1,">");
lf[86]=C_h_intern(&lf[86],9,"\003syserror");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\022THIS NEVER HAPPENS");
lf[88]=C_h_intern(&lf[88],7,"newline");
lf[89]=C_h_intern(&lf[89],7,"display");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\036FATAL ERROR IN PATTERN MATCHER");
lf[91]=C_h_intern(&lf[91],4,"get!");
lf[92]=C_h_intern(&lf[92],4,"set!");
lf[93]=C_h_intern(&lf[93],1,"$");
lf[94]=C_h_intern(&lf[94],2,"or");
lf[95]=C_h_intern(&lf[95],1,"=");
lf[96]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006lambda\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\014match-lambda\376\003\000\000\002\376\001\000\000\015match-lambda*\376\377\016");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\035duplicate variable in pattern");
lf[98]=C_h_intern(&lf[98],6,"gensym");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000!variables of or-pattern differ in");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\027no variables allowed in");
lf[101]=C_h_intern(&lf[101],12,"list->vector");
lf[102]=C_h_intern(&lf[102],12,"vector->list");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012quasiquote\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\007unquote\376\003\000\000\002\376\001\000\000\020unquote-splicing\376\003"
"\000\000\002\376\001\000\000\001\077\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001$\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\003and\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\003not"
"\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\004get!\376\003\000\000\002\376\001\000\000\003...\376\003\000\000\002\376\001\000\000\003___\376\377\016");
lf[104]=C_h_intern(&lf[104],10,"quasiquote");
lf[105]=C_h_intern(&lf[105],7,"unquote");
lf[106]=C_h_intern(&lf[106],16,"unquote-splicing");
lf[107]=C_h_intern(&lf[107],6,"vector");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\027syntax error in pattern");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\027syntax error in pattern");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000*invalid use of unquote-splicing in pattern");
lf[111]=C_h_intern(&lf[111],8,"\003syswarn");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\035Warning: unreachable pattern ");
lf[113]=C_h_intern(&lf[113],2,"in");
lf[114]=C_h_intern(&lf[114],12,"\003sysfor-each");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[116]=C_h_intern(&lf[116],6,"\000match");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\013unspecified\376\003\000\000\002\376\001\000\000\005error\376\003\000\000\002\376\001\000\000\004fail\376\003\000\000\002\376\001\000\000\005match\376\377\016");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\0009invalid value for ##match#error-control, legal values are");
lf[119]=C_h_intern(&lf[119],1,"n");
lf[120]=C_h_intern(&lf[120],1,"l");
lf[121]=C_h_intern(&lf[121],6,"length");
lf[122]=C_h_intern(&lf[122],2,"=>");
lf[123]=C_h_intern(&lf[123],6,"letrec");
lf[124]=C_h_intern(&lf[124],10,"\003sysappend");
lf[125]=C_h_intern(&lf[125],5,"begin");
lf[126]=C_h_intern(&lf[126],8,"\003sysvoid");
lf[127]=C_h_intern(&lf[127],6,"define");
lf[128]=C_h_intern(&lf[128],15,"\005matchexpanders");
lf[129]=C_h_intern(&lf[129],19,"match-error-control");
lf[130]=C_h_intern(&lf[130],21,"match-error-procedure");
lf[131]=C_h_intern(&lf[131],17,"register-feature!");
lf[132]=C_h_intern(&lf[132],5,"match");
lf[133]=C_h_intern(&lf[133],12,"match-define");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[135]=C_h_intern(&lf[135],20,"\003sysregister-macro-2");
lf[136]=C_h_intern(&lf[136],12,"match-letrec");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[138]=C_h_intern(&lf[138],6,"cadaar");
lf[139]=C_h_intern(&lf[139],5,"caaar");
lf[140]=C_h_intern(&lf[140],6,"cddaar");
lf[141]=C_h_intern(&lf[141],5,"cdaar");
lf[142]=C_h_intern(&lf[142],10,"match-let*");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[144]=C_h_intern(&lf[144],4,"let*");
lf[145]=C_h_intern(&lf[145],4,"list");
lf[146]=C_h_intern(&lf[146],9,"match-let");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[148]=C_h_intern(&lf[148],13,"match-lambda*");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[150]=C_h_intern(&lf[150],12,"match-lambda");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\017syntax error in");
C_register_lf2(lf,153,create_ptable());
t2=C_mutate((C_word*)lf[0]+1,lf[1]);
t3=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_692,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_719,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10833,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 143  ##sys#register-macro-2 */
t6=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[132],t5);}

/* a10832 */
static void C_ccall f_10833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10833,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10840,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
if(C_truep((C_word)C_i_less_or_equalp(C_fix(1),t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10914,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* match.scm: 148  every */
f_692(t3,t5,t6);}
else{
t5=t3;
f_10840(2,t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_10840(2,t4,C_SCHEME_FALSE);}}

/* a10913 in a10832 */
static void C_ccall f_10914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10914,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_length(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_less_or_equalp(C_fix(2),t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k10838 in a10832 */
static void C_ccall f_10840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10840,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10849,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=t4;
f_10849(2,t5,t2);}
else{
/* match.scm: 152  gensym */
t5=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}
else{
t2=(C_word)C_a_i_cons(&a,2,lf[132],((C_word*)t0)[3]);
/* match.scm: 163  ##match#syntax-err */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[152]);}}

/* k10847 in k10838 in a10832 */
static void C_ccall f_10849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10849,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,lf[132],((C_word*)t0)[4]);
t3=(C_word)C_i_car(*((C_word*)lf[128]+1));
t4=t3;
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}
else{
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10876,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[132],((C_word*)t0)[4]);
t6=(C_word)C_i_car(*((C_word*)lf[128]+1));
t7=t6;
((C_proc5)C_retrieve_proc(t7))(5,t7,t4,t1,((C_word*)t0)[2],t5);}}

/* k10874 in k10847 in k10838 in a10832 */
static void C_ccall f_10876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10876,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[22],((C_word*)t0)[2],t1));}

/* k717 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10767,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 164  ##sys#register-macro-2 */
t4=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[150],t3);}

/* a10766 in k717 */
static void C_ccall f_10767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10767,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10774,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10807,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 167  every */
f_692(t3,t4,t2);}
else{
t4=t3;
f_10774(2,t4,C_SCHEME_FALSE);}}

/* a10806 in a10766 in k717 */
static void C_ccall f_10807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10807,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10814,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_10814(t5,(C_word)C_i_listp(t4));}
else{
t4=t3;
f_10814(t4,C_SCHEME_FALSE);}}

/* k10812 in a10806 in a10766 in k717 */
static void C_fcall f_10814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10772 in a10766 in k717 */
static void C_ccall f_10774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10774,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 174  gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,lf[150],((C_word*)t0)[3]);
/* match.scm: 176  ##match#syntax-err */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[151]);}}

/* k10775 in k10772 in a10766 in k717 */
static void C_ccall f_10777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10777,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t4=(C_word)C_a_i_cons(&a,2,lf[132],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[21],t2,t4));}

/* k720 in k717 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10705,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 179  ##sys#register-macro-2 */
t4=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[148],t3);}

/* a10704 in k720 in k717 */
static void C_ccall f_10705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10705,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10712,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10741,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 182  every */
f_692(t3,t4,t2);}
else{
t4=t3;
f_10712(2,t4,C_SCHEME_FALSE);}}

/* a10740 in a10704 in k720 in k717 */
static void C_ccall f_10741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10741,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10748,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_cdr(t2);
t5=t3;
f_10748(t5,(C_word)C_i_listp(t4));}
else{
t4=t3;
f_10748(t4,C_SCHEME_FALSE);}}

/* k10746 in a10740 in a10704 in k720 in k717 */
static void C_fcall f_10748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10710 in a10704 in k720 in k717 */
static void C_ccall f_10712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10712,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 189  gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_a_i_cons(&a,2,lf[148],((C_word*)t0)[3]);
/* match.scm: 191  ##match#syntax-err */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,lf[149]);}}

/* k10713 in k10710 in a10704 in k720 in k717 */
static void C_ccall f_10715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10715,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[132],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[21],t1,t3));}

/* k723 in k720 in k717 */
static void C_ccall f_725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9155,a[2]=((C_word)li149),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 194  ##sys#register-macro-2 */
t4=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[146],t3);}

/* a9154 in k723 in k720 in k717 */
static void C_ccall f_9155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[42],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9155,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9157,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9166,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9199,a[2]=t2,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9208,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cadddr(*((C_word*)lf[128]+1));
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_symbolp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9267,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t2);
t12=t9;
f_9267(t12,(C_word)C_i_listp(t11));}
else{
t11=t9;
f_9267(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t9))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9439,a[2]=t4,a[3]=t6,a[4]=t3,a[5]=t5,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10095,a[2]=t7,a[3]=((C_word)li144),tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t2);
/* match.scm: 238  every */
f_692(t10,t11,t12);}
else{
t10=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10145,a[2]=t4,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10685,a[2]=t2,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 338  caar */
t13=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t2);}
else{
/* match.scm: 416  g146 */
t11=t5;
f_9199(t11,t1);}}}}
else{
/* match.scm: 417  g146 */
t8=t5;
f_9199(t8,t1);}}

/* k10683 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10685,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 339  cdaar */
t3=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10145(t2,C_SCHEME_FALSE);}}

/* k10679 in k10683 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10681,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10677,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 340  cddaar */
t3=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10145(t2,C_SCHEME_FALSE);}}

/* k10675 in k10679 in k10683 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10145(t2,(C_word)C_i_nullp(t1));}

/* k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10145,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 341  cdar */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10560,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word)li148),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_10560(t6,((C_word*)t0)[6],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10560(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10560,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10573,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_10573(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_10573(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10611,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10657,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 410  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10611(t7,C_SCHEME_FALSE);}}}

/* k10655 in g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10657,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10653,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 411  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10611(t2,C_SCHEME_FALSE);}}

/* k10651 in k10655 in g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10611(t2,(C_word)C_i_nullp(t1));}

/* k10609 in g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10611,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10634,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 413  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 415  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k10632 in k10609 in g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10634,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10630,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 414  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10628 in k10632 in k10609 in g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10630,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 412  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10560(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10571 in g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10573,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10580,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 405  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 408  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[5]);}}

/* k10578 in k10571 in g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10584,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 406  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10582 in k10578 in k10571 in g149 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 405  g154 */
f_9166(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10551,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10157,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=t2;
f_10157(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_10157(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10547,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 358  cdar */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k10545 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10547,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 359  cadar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10267(t2,C_SCHEME_FALSE);}}

/* k10541 in k10545 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10543,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 360  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10267(t2,C_SCHEME_FALSE);}}

/* k10537 in k10541 in k10545 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10539,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 361  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10267(t2,C_SCHEME_FALSE);}}

/* k10533 in k10537 in k10541 in k10545 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10535,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10527,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 362  cddar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_10267(t3,C_SCHEME_FALSE);}}

/* k10525 in k10533 in k10537 in k10541 in k10545 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10267(t2,(C_word)C_i_nullp(t1));}

/* k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10267(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10267,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10273,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_10273(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_10273(t4,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10398,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word)li147),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_10398(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10398(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10398,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10411,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_10411(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_10411(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10449,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10495,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 395  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10449(t7,C_SCHEME_FALSE);}}}

/* k10493 in g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10495,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10491,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 396  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10449(t2,C_SCHEME_FALSE);}}

/* k10489 in k10493 in g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10449(t2,(C_word)C_i_nullp(t1));}

/* k10447 in g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10449(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10449,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10472,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 398  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 400  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k10470 in k10447 in g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10472,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10468,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 399  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10466 in k10470 in k10447 in g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10468,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 397  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10398(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10409 in g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10411,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10418,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 390  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 393  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[5]);}}

/* k10416 in k10409 in g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10422,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 391  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10420 in k10416 in k10409 in g149 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 390  g154 */
f_9166(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10273,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 365  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10309,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li146),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10309(t6,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10309,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 374  g146 */
t5=((C_word*)t0)[3];
f_9199(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10325,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10371,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 376  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10325(t7,C_SCHEME_FALSE);}}}

/* k10369 in g149 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10371,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10367,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 377  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10325(t2,C_SCHEME_FALSE);}}

/* k10365 in k10369 in g149 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10325(t2,(C_word)C_i_nullp(t1));}

/* k10323 in g149 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10325(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10325,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10348,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 379  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 383  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k10346 in k10323 in g149 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10348,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10344,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 381  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10342 in k10346 in k10323 in g149 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10344,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 378  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10309(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10278 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10284,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 366  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k10282 in k10278 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10288,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 367  caadar */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k10286 in k10282 in k10278 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10300,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 368  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k10298 in k10286 in k10282 in k10278 in k10271 in k10265 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 365  g145 */
f_9208(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10157,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10164,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 343  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10181,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li145),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10181(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10181(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10181,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 350  g146 */
t5=((C_word*)t0)[3];
f_9199(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10197,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10243,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 352  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10197(t7,C_SCHEME_FALSE);}}}

/* k10241 in g149 in k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10243,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10239,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 353  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10197(t2,C_SCHEME_FALSE);}}

/* k10237 in k10241 in g149 in k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10197(t2,(C_word)C_i_nullp(t1));}

/* k10195 in g149 in k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10197,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10220,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 355  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 357  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k10218 in k10195 in g149 in k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10220,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10216,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 356  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10214 in k10218 in k10195 in g149 in k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10216,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 354  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_10181(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10162 in k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10168,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 344  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k10166 in k10162 in k10155 in k10549 in k10143 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10168,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 343  g158 */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,f_9157(C_a_i(&a,12),((C_word*)t0)[2],t1,t2));}

/* a10094 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10095,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10102,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10118,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* match.scm: 241  g136 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t3;
f_10102(t4,C_SCHEME_FALSE);}}

/* k10116 in a10094 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_10102(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_10102(t2,C_SCHEME_FALSE);}}

/* k10100 in a10094 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9439,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9445,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_9445(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_9445(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10089,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 259  caar */
t5=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_9543(t4,C_SCHEME_FALSE);}}}

/* k10087 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10089,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 260  cdaar */
t3=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9543(t2,C_SCHEME_FALSE);}}

/* k10083 in k10087 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10085,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10081,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 261  cddaar */
t3=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9543(t2,C_SCHEME_FALSE);}}

/* k10079 in k10083 in k10087 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9543(t2,(C_word)C_i_nullp(t1));}

/* k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9543,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 262  cdar */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9958,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word)li143),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_9958(t6,((C_word*)t0)[6],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9958,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9971,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_9971(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_9971(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10009,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10055,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 331  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_10009(t7,C_SCHEME_FALSE);}}}

/* k10053 in g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10055,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10051,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 332  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10009(t2,C_SCHEME_FALSE);}}

/* k10049 in k10053 in g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10009(t2,(C_word)C_i_nullp(t1));}

/* k10007 in g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_10009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10009,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10032,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 334  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 336  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k10030 in k10007 in g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10032,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10028,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 335  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k10026 in k10030 in k10007 in g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_10028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10028,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 333  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9958(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9969 in g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9971,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9978,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 326  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 329  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[5]);}}

/* k9976 in k9969 in g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9982,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 327  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9980 in k9976 in k9969 in g149 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 326  g154 */
f_9166(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9949,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9555,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=t2;
f_9555(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_9555(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9945,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 279  cdar */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k9943 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9945,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 280  cadar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9665(t2,C_SCHEME_FALSE);}}

/* k9939 in k9943 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9941,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 281  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9665(t2,C_SCHEME_FALSE);}}

/* k9935 in k9939 in k9943 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9937,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 282  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9665(t2,C_SCHEME_FALSE);}}

/* k9931 in k9935 in k9939 in k9943 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9933,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9925,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 283  cddar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_9665(t3,C_SCHEME_FALSE);}}

/* k9923 in k9931 in k9935 in k9939 in k9943 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9665(t2,(C_word)C_i_nullp(t1));}

/* k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9665,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9671,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_9671(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_9671(t4,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9796,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word)li142),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_9796(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9796(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9796,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9809,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_9809(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_9809(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9847,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9893,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 316  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9847(t7,C_SCHEME_FALSE);}}}

/* k9891 in g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9893,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9889,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 317  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9847(t2,C_SCHEME_FALSE);}}

/* k9887 in k9891 in g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9847(t2,(C_word)C_i_nullp(t1));}

/* k9845 in g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9847,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9870,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 319  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 321  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k9868 in k9845 in g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9870,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9866,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 320  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9864 in k9868 in k9845 in g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9866,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 318  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9796(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9807 in g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9816,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 311  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 314  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[5]);}}

/* k9814 in k9807 in g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9820,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 312  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9818 in k9814 in k9807 in g149 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 311  g154 */
f_9166(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9671,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9678,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 286  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9707,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li141),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_9707(t6,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9707,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 295  g146 */
t5=((C_word*)t0)[3];
f_9199(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9723,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9769,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 297  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9723(t7,C_SCHEME_FALSE);}}}

/* k9767 in g149 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9769,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9765,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 298  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9723(t2,C_SCHEME_FALSE);}}

/* k9763 in k9767 in g149 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9723(t2,(C_word)C_i_nullp(t1));}

/* k9721 in g149 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9723,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9746,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 300  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 304  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k9744 in k9721 in g149 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9746,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9742,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 302  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9740 in k9744 in k9721 in g149 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9742,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 299  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9707(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9676 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9682,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 287  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9680 in k9676 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9686,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 288  caadar */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k9684 in k9680 in k9676 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9698,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 289  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k9696 in k9684 in k9680 in k9676 in k9669 in k9663 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 286  g145 */
f_9208(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9555,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 264  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9579,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li140),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_9579(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9579(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9579,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 271  g146 */
t5=((C_word*)t0)[3];
f_9199(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9595,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9641,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 273  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9595(t7,C_SCHEME_FALSE);}}}

/* k9639 in g149 in k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9641,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9637,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 274  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9595(t2,C_SCHEME_FALSE);}}

/* k9635 in k9639 in g149 in k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9595(t2,(C_word)C_i_nullp(t1));}

/* k9593 in g149 in k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9595(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9595,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9618,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 276  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 278  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k9616 in k9593 in g149 in k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9618,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9614,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 277  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9612 in k9616 in k9593 in g149 in k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9614,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 275  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9579(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9560 in k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9566,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 265  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9564 in k9560 in k9553 in k9947 in k9541 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9566,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 264  g158 */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,f_9157(C_a_i(&a,12),((C_word*)t0)[2],t1,t2));}

/* k9443 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9445,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[22],((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9457,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li139),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_9457(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g149 in k9443 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9457(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9457,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 250  g146 */
t5=((C_word*)t0)[3];
f_9199(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9473,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9519,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 252  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9473(t7,C_SCHEME_FALSE);}}}

/* k9517 in g149 in k9443 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9519,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9515,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 253  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9473(t2,C_SCHEME_FALSE);}}

/* k9513 in k9517 in g149 in k9443 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9473(t2,(C_word)C_i_nullp(t1));}

/* k9471 in g149 in k9443 in k9437 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9473,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9496,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 255  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 257  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k9494 in k9471 in g149 in k9443 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9496,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9492,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 256  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9490 in k9494 in k9471 in g149 in k9443 in k9437 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9492,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 254  g149 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9457(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9265 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9267(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9267,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9276,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li138),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9276(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* match.scm: 236  g146 */
t2=((C_word*)t0)[3];
f_9199(t2,((C_word*)t0)[2]);}}

/* g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9276(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9276,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9289,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[4]);
t8=t5;
f_9289(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_9289(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9360,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9406,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 230  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9360(t7,C_SCHEME_FALSE);}}}

/* k9404 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9406,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9402,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 231  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_9360(t2,C_SCHEME_FALSE);}}

/* k9400 in k9404 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_9360(t2,(C_word)C_i_nullp(t1));}

/* k9358 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9360,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9383,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 233  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 235  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[3]);}}

/* k9381 in k9358 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9383,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9379,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 234  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9377 in k9381 in k9358 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9379,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 232  g161 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_9276(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9287 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9289,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9295,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 225  reverse */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
/* match.scm: 228  g146 */
t2=((C_word*)t0)[2];
f_9199(t2,((C_word*)t0)[5]);}}

/* k9293 in k9287 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9298,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 226  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9296 in k9293 in k9287 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9298,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9307,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadddr(*((C_word*)lf[128]+1));
/* match.scm: 217  every */
f_692(t3,t4,((C_word*)t0)[3]);}

/* k9305 in k9296 in k9293 in k9287 in g161 in k9265 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9307,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[22],((C_word*)t0)[6]));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,lf[148],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,3,lf[123],t5,t6));}}

/* g145 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9208(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9208,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9212,a[2]=t1,a[3]=t6,a[4]=t4,a[5]=t2,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* match.scm: 206  gensym */
t8=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}

/* k9210 in g145 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* match.scm: 206  gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9213 in k9210 in g145 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9215,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=(C_word)C_a_i_list(&a,3,lf[79],((C_word*)t0)[8],t1);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=(C_word)C_a_i_list(&a,3,lf[132],t5,t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,3,lf[22],t4,t8));}

/* g146 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9199,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[146],((C_word*)t0)[2]);
/* match.scm: 204  ##match#syntax-err */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[147]);}

/* g154 in a9154 in k723 in k720 in k717 */
static void C_fcall f_9166(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9166,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9170,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9194,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a9193 in g154 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9194,3,t0,t1,t2);}
/* match.scm: 199  gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k9168 in g154 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match.scm: 200  list->vector */
t3=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9171 in k9168 in g154 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 201  map */
t3=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[145]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k9178 in k9171 in k9168 in g154 in a9154 in k723 in k720 in k717 */
static void C_ccall f_9180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9180,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[107],((C_word*)t0)[5]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_a_i_list(&a,3,lf[132],t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[22],t1,t4));}

/* g158 in a9154 in k723 in k720 in k717 */
static C_word C_fcall f_9157(C_word *a,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_stack_check;
t4=(C_word)C_a_i_cons(&a,2,t1,t3);
return((C_word)C_a_i_list(&a,3,lf[132],t2,t4));}

/* k726 in k723 in k720 in k717 */
static void C_ccall f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_731,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8967,a[2]=((C_word)li132),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 418  ##sys#register-macro-2 */
t4=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[142],t3);}

/* a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_8967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8967,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8969,a[2]=t2,a[3]=((C_word)li131),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8995,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(t2);
t8=t5;
f_8995(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8995(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9024,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9142,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 428  caar */
t8=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_9024(t7,C_SCHEME_FALSE);}}}
else{
/* match.scm: 443  g176 */
t4=t3;
f_8969(t4,t1);}}

/* k9140 in a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_9142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9142,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 429  cdaar */
t3=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_9024(t2,C_SCHEME_FALSE);}}

/* k9136 in k9140 in a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_9138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9138,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 430  cddaar */
t3=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_9024(t2,C_SCHEME_FALSE);}}

/* k9132 in k9136 in k9140 in a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_9134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9134,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 431  cdar */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_9024(t2,C_SCHEME_FALSE);}}

/* k9128 in k9132 in k9136 in k9140 in a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_9130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_listp(t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_listp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
f_9024(t4,(C_word)C_i_pairp(t3));}
else{
t3=((C_word*)t0)[2];
f_9024(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_9024(t2,C_SCHEME_FALSE);}}

/* k9022 in a8966 in k726 in k723 in k720 in k717 */
static void C_fcall f_9024(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9024,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 438  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
/* match.scm: 442  g176 */
t2=((C_word*)t0)[2];
f_8969(t2,((C_word*)t0)[3]);}}

/* k9025 in k9022 in a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_9027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9030,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 439  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k9028 in k9025 in k9022 in a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_9030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9033,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 440  cdar */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9031 in k9028 in k9025 in k9022 in a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_9033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9033,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9042,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_cadddr(*((C_word*)lf[128]+1));
t5=t4;
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,((C_word*)t0)[4]);}

/* k9040 in k9031 in k9028 in k9025 in k9022 in a8966 in k726 in k723 in k720 in k717 */
static void C_ccall f_9042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[45],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9042,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,lf[142],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,3,lf[22],t3,t5));}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,lf[142],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[132],((C_word*)t0)[5],t4));}}

/* k8993 in a8966 in k726 in k723 in k720 in k717 */
static void C_fcall f_8995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8995,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[144],((C_word*)t0)[4]));}
else{
/* match.scm: 426  g176 */
t2=((C_word*)t0)[2];
f_8969(t2,((C_word*)t0)[3]);}}

/* g176 in a8966 in k726 in k723 in k720 in k717 */
static void C_fcall f_8969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8969,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[142],((C_word*)t0)[2]);
/* match.scm: 421  ##match#syntax-err */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[143]);}

/* k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7600,a[2]=((C_word)li130),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 444  ##sys#register-macro-2 */
t4=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[136],t3);}

/* a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[37],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7600,3,t0,t1,t2);}
t3=(C_word)C_i_cadddr(*((C_word*)lf[128]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7605,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7630,a[2]=t2,a[3]=((C_word)li117),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7639,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7664,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t8=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_listp(t8))){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7705,a[2]=t6,a[3]=t4,a[4]=t7,a[5]=t5,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8361,a[2]=t3,a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_car(t2);
/* match.scm: 465  every */
f_692(t9,t10,t11);}
else{
t9=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8411,a[2]=t6,a[3]=t4,a[4]=t5,a[5]=t1,a[6]=t7,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8951,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 559  caar */
t12=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}
else{
/* match.scm: 631  g195 */
t10=t5;
f_7630(t10,t1);}}}
else{
/* match.scm: 632  g195 */
t8=t5;
f_7630(t8,t1);}}

/* k8949 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8951,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 560  cdaar */
t3=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8411(t2,C_SCHEME_FALSE);}}

/* k8945 in k8949 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8947,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8943,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 561  cddaar */
t3=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8411(t2,C_SCHEME_FALSE);}}

/* k8941 in k8945 in k8949 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8411(t2,(C_word)C_i_nullp(t1));}

/* k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8411,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 562  cdar */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8826,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word)li129),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_8826(t6,((C_word*)t0)[5],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8826(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8826,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8839,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_8839(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8839(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8877,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8923,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 625  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8877(t7,C_SCHEME_FALSE);}}}

/* k8921 in g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8923,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8919,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 626  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8877(t2,C_SCHEME_FALSE);}}

/* k8917 in k8921 in g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8877(t2,(C_word)C_i_nullp(t1));}

/* k8875 in g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8877,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8900,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 628  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 630  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k8898 in k8875 in g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8900,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8896,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 629  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8894 in k8898 in k8875 in g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8896,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 627  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8826(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8837 in g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8839,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8846,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 620  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 623  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[5]);}}

/* k8844 in k8837 in g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8850,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 621  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8848 in k8844 in k8837 in g189 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 620  g194 */
f_7639(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8817,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8423,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=t2;
f_8423(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_8423(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8813,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 577  cdar */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k8811 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8813,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 578  cadar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8533(t2,C_SCHEME_FALSE);}}

/* k8807 in k8811 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8809,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 579  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8533(t2,C_SCHEME_FALSE);}}

/* k8803 in k8807 in k8811 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8805,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 580  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8533(t2,C_SCHEME_FALSE);}}

/* k8799 in k8803 in k8807 in k8811 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8801,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8793,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 581  cddar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_8533(t3,C_SCHEME_FALSE);}}

/* k8791 in k8799 in k8803 in k8807 in k8811 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8533(t2,(C_word)C_i_nullp(t1));}

/* k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8533,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_8539(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_8539(t4,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8664,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word)li128),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_8664(t6,((C_word*)t0)[5],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8664(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8664,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8677,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_8677(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8677(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8715,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8761,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 611  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8715(t7,C_SCHEME_FALSE);}}}

/* k8759 in g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8761,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8757,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 612  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8715(t2,C_SCHEME_FALSE);}}

/* k8755 in k8759 in g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8715(t2,(C_word)C_i_nullp(t1));}

/* k8713 in g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8715,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8738,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 614  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 616  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k8736 in k8713 in g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8738,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8734,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 615  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8732 in k8736 in k8713 in g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8734,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 613  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8664(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8675 in g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8677,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8684,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 606  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 609  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[5]);}}

/* k8682 in k8675 in g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8688,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 607  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8686 in k8682 in k8675 in g189 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 606  g194 */
f_7639(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8539,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 583  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8575,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li127),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8575(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8575(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8575,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 592  g195 */
t5=((C_word*)t0)[3];
f_7630(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8591,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8637,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 594  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8591(t7,C_SCHEME_FALSE);}}}

/* k8635 in g189 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8637,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8633,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 595  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8591(t2,C_SCHEME_FALSE);}}

/* k8631 in k8635 in g189 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8591(t2,(C_word)C_i_nullp(t1));}

/* k8589 in g189 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8591(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8591,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8614,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 597  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 599  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k8612 in k8589 in g189 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8614,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8610,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 598  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8608 in k8612 in k8589 in g189 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8610,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 596  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8575(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8544 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8550,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 584  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k8548 in k8544 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8554,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 585  caadar */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k8552 in k8548 in k8544 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8566,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 586  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k8564 in k8552 in k8548 in k8544 in k8537 in k8531 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8566,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 583  g199 */
t4=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7605(C_a_i(&a,27),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3));}

/* k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8423,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 564  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8447,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li126),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8447(t6,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8447(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8447,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 569  g195 */
t5=((C_word*)t0)[3];
f_7630(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8463,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8509,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 571  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8463(t7,C_SCHEME_FALSE);}}}

/* k8507 in g189 in k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8509,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8505,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 572  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8463(t2,C_SCHEME_FALSE);}}

/* k8503 in k8507 in g189 in k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8463(t2,(C_word)C_i_nullp(t1));}

/* k8461 in g189 in k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8463,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8486,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 574  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 576  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k8484 in k8461 in g189 in k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8486,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8482,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 575  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8480 in k8484 in k8461 in g189 in k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8482,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 573  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8447(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8428 in k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8434,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 564  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k8432 in k8428 in k8421 in k8815 in k8409 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 564  g186 */
f_7664(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* a8360 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8361,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8368,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8384,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* match.scm: 468  g200 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t4=t3;
f_8368(t4,C_SCHEME_FALSE);}}

/* k8382 in a8360 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_8368(t3,(C_word)C_i_pairp(t2));}
else{
t2=((C_word*)t0)[2];
f_8368(t2,C_SCHEME_FALSE);}}

/* k8366 in a8360 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7705,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7711,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_7711(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_7711(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8355,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 486  caar */
t5=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t4=t2;
f_7809(t4,C_SCHEME_FALSE);}}}

/* k8353 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8355,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 487  cdaar */
t3=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7809(t2,C_SCHEME_FALSE);}}

/* k8349 in k8353 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8351,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8347,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 488  cddaar */
t3=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7809(t2,C_SCHEME_FALSE);}}

/* k8345 in k8349 in k8353 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7809(t2,(C_word)C_i_nullp(t1));}

/* k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7809,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 489  cdar */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8224,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word)li124),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_8224(t6,((C_word*)t0)[5],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8224(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8224,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8237,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_8237(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8237(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8275,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8321,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 552  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8275(t7,C_SCHEME_FALSE);}}}

/* k8319 in g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8321,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8317,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 553  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8275(t2,C_SCHEME_FALSE);}}

/* k8315 in k8319 in g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8275(t2,(C_word)C_i_nullp(t1));}

/* k8273 in g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8275,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8298,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 555  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 557  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k8296 in k8273 in g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8298,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8294,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 556  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8292 in k8296 in k8273 in g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8294,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 554  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8224(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8235 in g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8237,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8244,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 547  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 550  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[5]);}}

/* k8242 in k8235 in g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8248,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 548  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8246 in k8242 in k8235 in g189 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 547  g194 */
f_7639(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8215,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7821,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=t2;
f_7821(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_7821(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8211,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 504  cdar */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k8209 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8211,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 505  cadar */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7931(t2,C_SCHEME_FALSE);}}

/* k8205 in k8209 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8207,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 506  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7931(t2,C_SCHEME_FALSE);}}

/* k8201 in k8205 in k8209 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8203,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 507  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7931(t2,C_SCHEME_FALSE);}}

/* k8197 in k8201 in k8205 in k8209 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8199,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8191,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 508  cddar */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_7931(t3,C_SCHEME_FALSE);}}

/* k8189 in k8197 in k8201 in k8205 in k8209 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7931(t2,(C_word)C_i_nullp(t1));}

/* k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7931(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7931,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=t2;
f_7937(t5,(C_word)C_i_pairp(t4));}
else{
t4=t2;
f_7937(t4,C_SCHEME_FALSE);}}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8062,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word)li123),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_8062(t6,((C_word*)t0)[5],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8062(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8062,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8075,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_listp(t6))){
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=t5;
f_8075(t8,(C_word)C_i_pairp(t7));}
else{
t7=t5;
f_8075(t7,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8113,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8159,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 538  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_8113(t7,C_SCHEME_FALSE);}}}

/* k8157 in g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8159,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8155,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 539  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8113(t2,C_SCHEME_FALSE);}}

/* k8153 in k8157 in g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8113(t2,(C_word)C_i_nullp(t1));}

/* k8111 in g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8113,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8136,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 541  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 543  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k8134 in k8111 in g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8136,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8132,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 542  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8130 in k8134 in k8111 in g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8132,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 540  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_8062(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8073 in g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_8075(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8075,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8082,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 533  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* match.scm: 536  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[5]);}}

/* k8080 in k8073 in g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8086,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 534  reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8084 in k8080 in k8073 in g189 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 533  g194 */
f_7639(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7937(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7937,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 510  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7973,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li122),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7973(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7973(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7973,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 519  g195 */
t5=((C_word*)t0)[3];
f_7630(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7989,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8035,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 521  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_7989(t7,C_SCHEME_FALSE);}}}

/* k8033 in g189 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8035,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8031,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 522  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7989(t2,C_SCHEME_FALSE);}}

/* k8029 in k8033 in g189 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7989(t2,(C_word)C_i_nullp(t1));}

/* k7987 in g189 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7989,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8012,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 524  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 526  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k8010 in k7987 in g189 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8012,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8008,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 525  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8006 in k8010 in k7987 in g189 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_8008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8008,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 523  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7973(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7942 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7948,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 511  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k7946 in k7942 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7952,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 512  caadar */
t3=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k7950 in k7946 in k7942 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7964,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 513  cdadar */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k7962 in k7950 in k7946 in k7942 in k7935 in k7929 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7964,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 510  g199 */
t4=((C_word*)t0)[6];
((C_proc2)C_retrieve_proc(t4))(2,t4,f_7605(C_a_i(&a,27),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3));}

/* k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7821(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7821,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 491  caaar */
t3=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7845,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li121),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7845(t6,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7845(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7845,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 496  g195 */
t5=((C_word*)t0)[3];
f_7630(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7861,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7907,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 498  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_7861(t7,C_SCHEME_FALSE);}}}

/* k7905 in g189 in k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7907,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7903,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 499  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7861(t2,C_SCHEME_FALSE);}}

/* k7901 in k7905 in g189 in k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7861(t2,(C_word)C_i_nullp(t1));}

/* k7859 in g189 in k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7861,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7884,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 501  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 503  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k7882 in k7859 in g189 in k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7884,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7880,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 502  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7878 in k7882 in k7859 in g189 in k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7880,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 500  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7845(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7826 in k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7832,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 491  cadaar */
t3=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k7830 in k7826 in k7819 in k8213 in k7807 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 491  g186 */
f_7664(((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k7709 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7711,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[123],((C_word*)t0)[3]));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7723,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li120),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7723(t6,((C_word*)t0)[4],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* g189 in k7709 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7723(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7723,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 477  g195 */
t5=((C_word*)t0)[3];
f_7630(t5,t1);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7739,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7785,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 479  cdar */
t8=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=t5;
f_7739(t7,C_SCHEME_FALSE);}}}

/* k7783 in g189 in k7709 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7785,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7781,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 480  cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7739(t2,C_SCHEME_FALSE);}}

/* k7779 in k7783 in g189 in k7709 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7739(t2,(C_word)C_i_nullp(t1));}

/* k7737 in g189 in k7709 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7739,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7762,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 482  cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
/* match.scm: 484  g195 */
t2=((C_word*)t0)[2];
f_7630(t2,((C_word*)t0)[3]);}}

/* k7760 in k7737 in g189 in k7709 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7762,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7758,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 483  caar */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7756 in k7760 in k7737 in g189 in k7709 in k7703 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7758,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* match.scm: 481  g189 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_7723(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* g186 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7664(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7664,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,t4);
t8=(C_word)C_a_i_cons(&a,2,lf[136],t7);
t9=(C_word)C_i_cadr(*((C_word*)lf[128]+1));
t10=t9;
((C_proc6)C_retrieve_proc(t10))(6,t10,t1,t2,t3,t4,t8);}

/* g194 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7639(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7639,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7659,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 455  list->vector */
t6=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7657 in g194 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7659,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[107],((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[136],t5));}

/* g195 in a7599 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7630,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[136],((C_word*)t0)[2]);
/* match.scm: 450  ##match#syntax-err */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[137]);}

/* g199 in a7599 in k729 in k726 in k723 in k720 in k717 */
static C_word C_fcall f_7605(C_word *a,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_stack_check;
t6=(C_word)C_a_i_cons(&a,2,t1,t3);
t7=(C_word)C_a_i_list(&a,3,lf[79],t2,t4);
t8=(C_word)C_a_i_list(&a,2,t6,t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_a_i_cons(&a,2,t9,t5);
return((C_word)C_a_i_cons(&a,2,lf[136],t10));}

/* k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7497,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 633  ##sys#register-macro-2 */
t4=*((C_word*)lf[135]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[133],t3);}

/* a7496 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7497,3,t0,t1,t2);}
t3=(C_word)C_i_cadddr(*((C_word*)lf[128]+1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7502,a[2]=t2,a[3]=((C_word)li114),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7522,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t2);
/* match.scm: 641  g210 */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
/* match.scm: 654  g209 */
t5=t4;
f_7502(t5,t1);}}

/* k7520 in a7496 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7522,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=t2;
f_7528(t5,(C_word)C_i_nullp(t4));}
else{
t4=t2;
f_7528(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=t2;
f_7558(t5,(C_word)C_i_nullp(t4));}
else{
t4=t2;
f_7558(t4,C_SCHEME_FALSE);}}}

/* k7556 in k7520 in a7496 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7558,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,lf[133],((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(*((C_word*)lf[128]+1));
t6=t5;
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[3],t2,t3,t4);}
else{
/* match.scm: 653  g209 */
t2=((C_word*)t0)[2];
f_7502(t2,((C_word*)t0)[3]);}}

/* k7526 in k7520 in a7496 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7528(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7528,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,lf[127],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[125],t2));}
else{
/* match.scm: 644  g209 */
t2=((C_word*)t0)[2];
f_7502(t2,((C_word*)t0)[3]);}}

/* g209 in a7496 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7502,NULL,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[133],((C_word*)t0)[2]);
/* match.scm: 637  ##match#syntax-err */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[134]);}

/* k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word ab[155],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_737,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_739,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1,lf[9]);
t5=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_750,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=(C_word)C_a_i_cons(&a,2,lf[11],lf[12]);
t7=C_mutate((C_word*)lf[13]+1,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7373,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
t9=lf[18];
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7108,a[2]=t9,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6803,a[2]=t9,a[3]=t8,a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t12=lf[37];
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6769,a[2]=t12,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6736,a[2]=t12,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6726,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6640,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6330,a[2]=t15,a[3]=t16,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6199,a[2]=t14,a[3]=t13,a[4]=((C_word)li18),tmp=(C_word)a,a+=5,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5305,a[2]=t18,a[3]=t20,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp));
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5123,a[2]=t17,a[3]=t20,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp);
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3850,a[2]=t14,a[3]=t13,a[4]=t23,a[5]=t20,a[6]=t10,a[7]=t11,a[8]=t8,a[9]=t22,a[10]=t25,a[11]=((C_word)li51),tmp=(C_word)a,a+=12,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2570,a[2]=t23,a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=t23,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1505,a[2]=t23,a[3]=t29,a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1475,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
t33=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_759,a[2]=t32,a[3]=t30,a[4]=t28,a[5]=t25,a[6]=t31,a[7]=t27,a[8]=((C_word)li101),tmp=(C_word)a,a+=9,tmp);
t34=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_971,a[2]=t32,a[3]=t30,a[4]=t28,a[5]=t25,a[6]=t31,a[7]=((C_word)li105),tmp=(C_word)a,a+=8,tmp);
t35=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1127,a[2]=t32,a[3]=t30,a[4]=t28,a[5]=t25,a[6]=t31,a[7]=t27,a[8]=((C_word)li109),tmp=(C_word)a,a+=9,tmp);
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7408,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_set_block_item(t38,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7431,a[2]=t38,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp));
t40=(C_word)C_a_i_list(&a,4,t33,t34,t35,t29);
t41=C_mutate((C_word*)lf[128]+1,t40);
t42=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7462,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7478,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t44=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7495,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 2217 register-feature! */
t45=*((C_word*)lf[131]+1);
((C_proc3)C_retrieve_proc(t45))(3,t45,t44,lf[132]);}

/* k7493 in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* match-error-procedure in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7478(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7478r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7478r(t0,t1,t2);}}

static void C_ccall f_7478r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
/* match.scm: 2214 ##match#set-error */
t4=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[7]+1));}}

/* match-error-control in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7462(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7462r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7462r(t0,t1,t2);}}

static void C_ccall f_7462r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
if(C_truep((C_word)C_notvemptyp(t2))){
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
/* match.scm: 2209 ##match#set-error-control */
t4=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[8]+1));}}

/* rdc in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7431,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7449,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* match.scm: 2204 rdc */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}

/* k7447 in rdc in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7449,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* rac in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static C_word C_fcall f_7408(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
return((C_word)C_i_car(t1));}
else{
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}}

/* gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1127,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* match.scm: 769  gensym */
t6=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* match.scm: 770  error-maker */
f_1397(t2,((C_word*)t0)[7]);}

/* k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1137,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1301,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 771  validate-pattern */
t4=((C_word*)t0)[3];
f_1505(t4,t3,((C_word*)t0)[2]);}

/* k1299 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 771  bound */
t2=((C_word*)t0)[3];
f_2570(t2,((C_word*)t0)[2],t1);}

/* k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1137,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* match.scm: 775  gensym */
t6=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1149,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[12],t1,((C_word*)t0)[11],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* match.scm: 777  gensym */
t5=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[12],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 783  gensym */
t5=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1291 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 778  gen */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3850(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1281,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* a1280 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1281,3,t0,t1,t2);}
/* match.scm: 784  gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1164,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t1,a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* match.scm: 785  unreachable */
f_1475(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1275,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1274 in k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1275,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[127],t2,C_SCHEME_FALSE));}

/* k1173 in k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[72],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1183,a[2]=t1,a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[119]);
t4=(C_word)C_a_i_list(&a,1,lf[120]);
t5=(C_word)C_a_i_list(&a,2,lf[121],lf[120]);
t6=(C_word)C_a_i_list(&a,3,lf[83],t5,lf[119]);
t7=(C_word)C_a_i_list(&a,3,lf[21],t4,t6);
t8=(C_word)C_a_i_list(&a,3,lf[21],t3,t7);
t9=(C_word)C_a_i_list(&a,2,((C_word*)t0)[11],t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1231,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t9,a[8]=t10,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1235,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1245,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 794  map */
t14=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t12,t13,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* a1244 in k1173 in k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1245,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[92],t2,t3));}

/* k1233 in k1173 in k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[126]);
t3=(C_word)C_a_i_list(&a,1,t2);
/* match.scm: 675  ##sys#append */
t4=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k1229 in k1173 in k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1231,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[21],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1215,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* match.scm: 675  ##sys#append */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k1213 in k1229 in k1173 in k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1215,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,3,lf[22],t4,((C_word*)t0)[4]);
/* match.scm: 787  inline-let */
f_3466(((C_word*)t0)[2],t5);}

/* k1181 in k1173 in k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1183,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* match.scm: 675  ##sys#append */
t3=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1169 in k1162 in k1159 in k1156 in k1153 in k1147 in k1135 in k1132 in k1129 in gendefine in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1171,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[125],t1));}

/* genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_971,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t4,a[10]=t3,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* match.scm: 737  gensym */
t7=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* match.scm: 738  error-maker */
f_1397(t2,((C_word*)t0)[7]);}

/* k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_981,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1125,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 739  validate-pattern */
t4=((C_word*)t0)[3];
f_1505(t4,t3,((C_word*)t0)[2]);}

/* k1123 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 739  bound */
t2=((C_word*)t0)[3];
f_2570(t2,((C_word*)t0)[2],t1);}

/* k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_981,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* match.scm: 743  gensym */
t6=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[12],t1,((C_word*)t0)[11],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* match.scm: 745  gensym */
t5=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[13],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 751  gensym */
t5=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k1115 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 746  gen */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3850(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1105,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* a1104 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1105,3,t0,t1,t2);}
/* match.scm: 752  gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* match.scm: 753  unreachable */
f_1475(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1006 in k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[64],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[119]);
t3=(C_word)C_a_i_list(&a,1,lf[120]);
t4=(C_word)C_a_i_list(&a,2,lf[121],lf[120]);
t5=(C_word)C_a_i_list(&a,3,lf[83],t4,lf[119]);
t6=(C_word)C_a_i_list(&a,3,lf[21],t3,t5);
t7=(C_word)C_a_i_list(&a,3,lf[21],t2,t6);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[12],t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1023,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t9,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp);
/* map */
t12=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a1074 in k1006 in k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1075,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,C_SCHEME_FALSE));}

/* k1025 in k1006 in k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1069,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 760  map */
t6=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* a1068 in k1025 in k1006 in k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1069,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[92],t2,t3));}

/* k1065 in k1025 in k1006 in k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 675  ##sys#append */
t2=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1061 in k1025 in k1006 in k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1063,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[21],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* match.scm: 675  ##sys#append */
t7=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}

/* k1045 in k1061 in k1025 in k1006 in k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1047,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
/* match.scm: 675  ##sys#append */
t4=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1021 in k1006 in k1003 in k1000 in k997 in k991 in k979 in k976 in k973 in genletrec in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1023,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[123],t2,((C_word*)t0)[2]));}

/* genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_759,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_763,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
/* match.scm: 677  gensym */
t6=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
/* match.scm: 678  error-maker */
f_1397(t2,((C_word*)t0)[8]);}

/* k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_766,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_772,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t4,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp);
/* map */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[2]);}

/* a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_827,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_831,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_965,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* match.scm: 682  validate-pattern */
t6=((C_word*)t0)[2];
f_1505(t6,t4,t5);}

/* k963 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 681  bound */
t2=((C_word*)t0)[3];
f_2570(t2,((C_word*)t0)[2],t1);}

/* k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_843,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* match.scm: 687  gensym */
t6=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k841 in k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_953,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 692  caadr */
t6=*((C_word*)lf[64]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t5=t2;
f_846(2,t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_846(2,t4,C_SCHEME_FALSE);}}

/* k951 in k841 in k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_953,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[122]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 696  cadadr */
t4=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_846(2,t3,C_SCHEME_FALSE);}}

/* k947 in k951 in k841 in k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_949,2,t0,t1);}
if(C_truep((C_word)C_i_symbolp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 698  cdadr */
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_846(2,t2,C_SCHEME_FALSE);}}

/* k943 in k947 in k951 in k841 in k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 700  cddadr */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_846(2,t2,C_SCHEME_FALSE);}}

/* k939 in k943 in k947 in k951 in k841 in k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* match.scm: 703  cadadr */
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
f_846(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_846(2,t2,C_SCHEME_FALSE);}}

/* k844 in k841 in k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]):((C_word*)t0)[8]);
t3=(C_truep(t1)?(C_word)C_i_cddr(((C_word*)t0)[7]):(C_word)C_i_cdr(((C_word*)t0)[7]));
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[21],t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t5);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_874,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* match.scm: 714  append */
t8=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k872 in k844 in k841 in k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_874,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* match.scm: 720  gensym */
t5=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t5=t4;
f_863(2,t5,C_SCHEME_FALSE);}}

/* k861 in k872 in k844 in k841 in k829 in a826 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_863,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k770 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_775,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_825,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 728  gensym */
t5=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k823 in k770 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 723  gen */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3850(t2,((C_word*)t0)[6],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k773 in k770 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_778,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 729  unreachable */
f_1475(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k776 in k773 in k770 in k764 in k761 in genmatch in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_778,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,lf[119]);
t3=(C_word)C_a_i_list(&a,1,lf[120]);
t4=(C_word)C_a_i_list(&a,2,lf[121],lf[120]);
t5=(C_word)C_a_i_list(&a,3,lf[83],t4,lf[119]);
t6=(C_word)C_a_i_list(&a,3,lf[21],t3,t5);
t7=(C_word)C_a_i_list(&a,3,lf[21],t2,t6);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[5])[1]);
t10=(C_word)C_a_i_list(&a,3,lf[22],t9,((C_word*)t0)[4]);
/* match.scm: 730  inline-let */
f_3466(((C_word*)t0)[2],t10);}

/* error-maker in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1397(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1397,NULL,2,t1,t2);}
t3=(C_word)C_eqp(*((C_word*)lf[8]+1),lf[66]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1409,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4));}
else{
t4=*((C_word*)lf[8]+1);
if(C_truep((C_truep((C_word)C_eqp(t4,lf[9]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,lf[67]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5));}
else{
t5=(C_word)C_eqp(*((C_word*)lf[8]+1),lf[116]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1434,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 845  gensym */
t7=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
/* match.scm: 855  ##match#syntax-err */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,lf[117],lf[118]);}}}}

/* k1432 in error-maker in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 846  gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1435 in k1432 in error-maker in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,2,lf[44],((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,3,lf[7],t1,t3);
t5=(C_word)C_a_i_list(&a,3,lf[21],t2,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=(C_word)C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[3],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,t7,t8));}

/* a1445 in k1435 in k1432 in error-maker in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1446,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t2));}

/* a1420 in error-maker in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1421,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[7],t2));}

/* a1408 in error-maker in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1409,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[115]);}

/* unreachable in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1475(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1475,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1481,a[2]=t3,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1480 in unreachable in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1481,3,t0,t1,t2);}
t3=(C_word)C_i_cddddr(t2);
if(C_truep((C_word)C_i_car(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(t2);
/* match.scm: 862  ##sys#warn */
t5=*((C_word*)lf[111]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,lf[112],t4,lf[113],((C_word*)t0)[2]);}}

/* validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1505(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1505,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1538,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=t3,a[7]=t5,a[8]=((C_word)li89),tmp=(C_word)a,a+=9,tmp));
t11=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2268,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t5,a[6]=t3,a[7]=t7,a[8]=((C_word)li91),tmp=(C_word)a,a+=9,tmp));
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2530,a[2]=t2,a[3]=t5,a[4]=t9,a[5]=((C_word)li92),tmp=(C_word)a,a+=6,tmp));
/* match.scm: 1186 ordinary */
t13=((C_word*)t5)[1];
f_1538(3,t13,t1,t2);}

/* ordlist in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2530(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2530,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* match.scm: 1179 ordinary */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1538(3,t5,t3,t4);}
else{
/* match.scm: 1183 ##match#syntax-err */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],lf[110]);}}}

/* k2548 in ordlist in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2554,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1181 ordlist */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2530(t4,t2,t3);}

/* k2552 in k2548 in ordlist in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[35],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2268,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[7],a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp);
t4=f_1508(t2);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,lf[44],t5));}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[105]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2315,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(t2);
t10=t7;
f_2315(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_2315(t9,C_SCHEME_FALSE);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t8=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2469,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1115 caar */
t10=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
t9=t7;
f_2352(t9,C_SCHEME_FALSE);}}}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t5=t2;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1157 vector->list */
t7=*((C_word*)lf[102]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
/* match.scm: 1173 ##match#syntax-err */
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,((C_word*)t0)[2],lf[109]);}}}}}

/* k2484 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1159 reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2487 in k2484 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2499,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t1);
/* match.scm: 1163 dot-dot-k? */
f_1329(t3,t4);}

/* k2497 in k2487 in k2484 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2499,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* map */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[4])[1],t4);}
else{
/* map */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k2512 in k2497 in k2487 in k2484 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* match.scm: 1165 reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k2494 in k2487 in k2484 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[107]+1),t1);}

/* k2467 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2469,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[106]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1118 cdar */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_2352(t3,C_SCHEME_FALSE);}}

/* k2463 in k2467 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2465,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1120 cddar */
t3=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2352(t2,C_SCHEME_FALSE);}}

/* k2459 in k2463 in k2467 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2352(t2,(C_word)C_i_nullp(t1));}

/* k2350 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2352,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2361,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1127 cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1136 cadar */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2424,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* match.scm: 1141 dot-dot-k? */
f_1329(t4,t5);}
else{
t4=t2;
f_2391(t4,C_SCHEME_FALSE);}}}

/* k2422 in k2350 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2391(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_2391(t2,C_SCHEME_FALSE);}}

/* k2389 in k2350 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2391(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2391,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1147 quasi */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2268(3,t5,t4,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 1152 g109 */
t4=((C_word*)t0)[2];
f_2270(t4,((C_word*)t0)[4],t2,t3);}}

/* k2402 in k2389 in k2350 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k2365 in k2350 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2367,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2377,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1132 ordlist */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2530(t4,t3,t1);}

/* k2375 in k2365 in k2350 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2381,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1134 quasi */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2268(3,t3,t2,((C_word*)t0)[2]);}

/* k2379 in k2375 in k2365 in k2350 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1131 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2359 in k2350 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1125 ordinary */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1538(3,t2,((C_word*)t0)[2],t1);}

/* k2313 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2315(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* match.scm: 1107 ordinary */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1538(3,t3,((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 1110 g109 */
t4=((C_word*)t0)[2];
f_2270(t4,((C_word*)t0)[3],t2,t3);}}

/* g109 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2270(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2270,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2278,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1088 quasi */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2268(3,t5,t4,t2);}

/* k2276 in g109 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2282,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1090 quasi */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2268(3,t3,t2,((C_word*)t0)[2]);}

/* k2280 in k2276 in g109 in quasi in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1538,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[7],a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
t4=f_1508(t2);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(C_word)C_eqp(t2,lf[74]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[74]);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* match.scm: 884  pattern-var? */
t7=((C_word*)t0)[4];
f_1303(3,t7,t6,t2);}}}

/* k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[80],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_eqp(t2,lf[104]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(((C_word*)t0)[9]);
t7=t4;
f_1588(t7,(C_word)C_i_nullp(t6));}
else{
t6=t4;
f_1588(t6,C_SCHEME_FALSE);}}
else{
t4=(C_word)C_i_car(((C_word*)t0)[9]);
t5=(C_word)C_eqp(t4,lf[44]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(((C_word*)t0)[9]);
t9=t6;
f_1631(t9,(C_word)C_i_nullp(t8));}
else{
t8=t6;
f_1631(t8,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(((C_word*)t0)[9]);
t7=(C_word)C_eqp(t6,lf[76]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cddr(((C_word*)t0)[9]);
t11=t8;
f_1668(t11,(C_word)C_i_listp(t10));}
else{
t10=t8;
f_1668(t10,C_SCHEME_FALSE);}}
else{
t8=(C_word)C_i_car(((C_word*)t0)[9]);
t9=(C_word)C_eqp(t8,lf[95]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t11))){
t12=(C_word)C_i_cddr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cdddr(((C_word*)t0)[9]);
t14=t10;
f_1722(t14,(C_word)C_i_nullp(t13));}
else{
t13=t10;
f_1722(t13,C_SCHEME_FALSE);}}
else{
t12=t10;
f_1722(t12,C_SCHEME_FALSE);}}
else{
t10=(C_word)C_i_car(((C_word*)t0)[9]);
t11=(C_word)C_eqp(t10,lf[52]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t13))){
t14=(C_word)C_i_cdr(((C_word*)t0)[9]);
t15=t12;
f_1782(t15,(C_word)C_i_pairp(t14));}
else{
t14=t12;
f_1782(t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_i_car(((C_word*)t0)[9]);
t13=(C_word)C_eqp(t12,lf[94]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t15))){
t16=(C_word)C_i_cdr(((C_word*)t0)[9]);
t17=t14;
f_1829(t17,(C_word)C_i_pairp(t16));}
else{
t16=t14;
f_1829(t16,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_i_car(((C_word*)t0)[9]);
t15=(C_word)C_eqp(t14,lf[45]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_listp(t17))){
t18=(C_word)C_i_cdr(((C_word*)t0)[9]);
t19=t16;
f_1876(t19,(C_word)C_i_pairp(t18));}
else{
t18=t16;
f_1876(t18,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_i_car(((C_word*)t0)[9]);
t17=(C_word)C_eqp(t16,lf[93]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t19=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cadr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_symbolp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[9]);
t22=t18;
f_1923(t22,(C_word)C_i_listp(t21));}
else{
t21=t18;
f_1923(t21,C_SCHEME_FALSE);}}
else{
t20=t18;
f_1923(t20,C_SCHEME_FALSE);}}
else{
t18=(C_word)C_i_car(((C_word*)t0)[9]);
t19=(C_word)C_eqp(t18,lf[92]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t21=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t21))){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t20,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_i_cadr(((C_word*)t0)[9]);
/* match.scm: 1014 pattern-var? */
t24=((C_word*)t0)[4];
f_1303(3,t24,t22,t23);}
else{
t22=t20;
f_1987(t22,C_SCHEME_FALSE);}}
else{
t20=(C_word)C_i_car(((C_word*)t0)[9]);
t21=(C_word)C_eqp(t20,lf[91]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2054,a[2]=t22,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t25=(C_word)C_i_cadr(((C_word*)t0)[9]);
/* match.scm: 1028 pattern-var? */
t26=((C_word*)t0)[4];
f_1303(3,t26,t24,t25);}
else{
t24=t22;
f_2034(t24,C_SCHEME_FALSE);}}
else{
t22=(C_word)C_i_car(((C_word*)t0)[9]);
t23=(C_word)C_eqp(t22,lf[105]);
if(C_truep(t23)){
t24=(C_word)C_i_car(((C_word*)t0)[9]);
t25=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* match.scm: 1040 g88 */
t26=((C_word*)t0)[6];
f_1540(t26,((C_word*)t0)[8],t24,t25);}
else{
t24=(C_word)C_i_car(((C_word*)t0)[9]);
t25=(C_word)C_eqp(t24,lf[106]);
if(C_truep(t25)){
t26=(C_word)C_i_car(((C_word*)t0)[9]);
t27=(C_word)C_i_cdr(((C_word*)t0)[9]);
/* match.scm: 1045 g88 */
t28=((C_word*)t0)[6];
f_1540(t28,((C_word*)t0)[8],t26,t27);}
else{
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t27=(C_word)C_i_cdr(((C_word*)t0)[9]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=t26,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_i_cadr(((C_word*)t0)[9]);
/* match.scm: 1049 dot-dot-k? */
f_1329(t28,t29);}
else{
t28=t26;
f_2109(t28,C_SCHEME_FALSE);}}}}}}}}}}}}}}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[9]))){
t2=((C_word*)t0)[9];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1065 vector->list */
t4=*((C_word*)lf[102]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
/* match.scm: 1083 ##match#syntax-err */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[8],((C_word*)t0)[2],lf[108]);}}}}

/* k2212 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1067 reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2215 in k2212 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t4=t3;
f_2227(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_car(t1);
/* match.scm: 1073 dot-dot-k? */
f_1329(t3,t4);}}

/* k2225 in k2215 in k2212 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* map */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[3])[1],t4);}
else{
/* map */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k2240 in k2225 in k2215 in k2212 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2242,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* match.scm: 1075 reverse */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k2222 in k2215 in k2212 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[107]+1),t1);}

/* k2140 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2109(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_2109(t2,C_SCHEME_FALSE);}}

/* k2107 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2109,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2122,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1055 ordinary */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1538(3,t5,t4,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 1060 g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[4],t2,t3);}}

/* k2120 in k2107 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k2052 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2034(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_2034(t2,C_SCHEME_FALSE);}}

/* k2032 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* match.scm: 1035 g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[3],t2,t3);}}

/* k2005 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_1987(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_1987(t2,C_SCHEME_FALSE);}}

/* k1985 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* match.scm: 1021 g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[3],t2,t3);}}

/* k1921 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1923(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1923,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 1007 g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[4],t2,t3);}}

/* k1938 in k1921 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[93],t2));}

/* k1874 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1876(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1876,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 989  g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[4],t2,t3);}}

/* k1884 in k1874 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[45],t1));}

/* k1827 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1829(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1829,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 976  g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[4],t2,t3);}}

/* k1837 in k1827 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[94],t1));}

/* k1780 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1782,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[3])[1],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 963  g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[4],t2,t3);}}

/* k1790 in k1780 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,lf[52],t1));}

/* k1720 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1722,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1735,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 945  ordinary */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1538(3,t5,t4,t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 950  g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[4],t2,t3);}}

/* k1733 in k1720 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1735,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[95],((C_word*)t0)[2],t1));}

/* k1666 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1668,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],t3);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 930  g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[4],t2,t3);}}

/* k1683 in k1666 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[76],t2));}

/* k1629 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* match.scm: 914  g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[3],t2,t3);}}

/* k1586 in k1568 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1588(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* match.scm: 899  quasi */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2268(3,t3,((C_word*)t0)[3],t2);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* match.scm: 902  g88 */
t4=((C_word*)t0)[2];
f_1540(t4,((C_word*)t0)[3],t2,t3);}}

/* g88 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1540(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1540,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1548,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 874  ordinary */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1538(3,t5,t4,t2);}

/* k1546 in g88 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1552,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* match.scm: 876  ordinary */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1538(3,t3,t2,((C_word*)t0)[2]);}

/* k1550 in k1546 in g88 in ordinary in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* simple? in validate-pattern in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static C_word C_fcall f_1508(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t2=(C_word)C_i_stringp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_booleanp(t1);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_charp(t1);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_i_numberp(t1);
return((C_truep(t5)?t5:(C_word)C_i_nullp(t1)));}}}}

/* pattern-var? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1303,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1327,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 805  dot-dot-k? */
f_1329(t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1325 in pattern-var? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[2],lf[103]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}}

/* bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2570(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2570,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3427,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3403,a[2]=t7,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=t7,a[5]=t5,a[6]=t14,a[7]=t10,a[8]=t4,a[9]=t2,a[10]=((C_word)li76),tmp=(C_word)a,a+=11,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=t10,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t17=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3364,a[2]=t10,a[3]=t14,a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp));
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=t4,a[3]=((C_word)li84),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1411 bound */
t19=((C_word*)t10)[1];
f_2574(t19,t1,t2,C_SCHEME_END_OF_LIST,t18);}

/* a3455 in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3456,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1414 reverse */
t5=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3462 in a3455 in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3464,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]));}

/* bound* in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3364(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3364,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1386 k */
t5=t4;
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1387 bound */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2574(t7,t1,t5,t3,t6);}}

/* a3382 in bound* in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3383,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1391 bound* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3364(t6,t1,t4,t3,t5);}

/* a3392 in a3382 in bound* in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3393,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* match.scm: 1395 k */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* boundv in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3271(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3271,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3273,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=((C_word)li77),tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3289,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3335,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_cadr(t2);
/* match.scm: 1359 dot-dot-k? */
f_1329(t8,t9);}
else{
t8=t6;
f_3289(t8,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1382 g115 */
t6=t5;
f_3273(t6,t1);}
else{
/* match.scm: 1383 ##sys#match-error */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}}}

/* k3333 in boundv in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3289(t3,(C_word)C_i_nullp(t2));}
else{
t2=((C_word*)t0)[2];
f_3289(t2,C_SCHEME_FALSE);}}

/* k3287 in boundv in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3289,NULL,2,t0,t1);}
if(C_truep(t1)){
/* match.scm: 1363 bound */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2574(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
/* match.scm: 1365 g115 */
t2=((C_word*)t0)[3];
f_3273(t2,((C_word*)t0)[7]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3312,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1367 bound */
t5=((C_word*)((C_word*)t0)[8])[1];
f_2574(t5,((C_word*)t0)[7],t2,((C_word*)t0)[5],t4);}}}

/* a3311 in k3287 in boundv in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3312,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1371 boundv */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3271(t5,t1,((C_word*)t0)[2],t3,t4);}

/* a3317 in a3311 in k3287 in boundv in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3318,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* match.scm: 1376 k */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* g115 in boundv in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3273,NULL,2,t0,t1);}
/* match.scm: 1356 k */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2574(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2574,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(lf[74],t2);
if(C_truep(t5)){
/* match.scm: 1191 k */
t6=t4;
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2593,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t2,t3))){
/* match.scm: 1193 ##match#syntax-err */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],lf[97]);}
else{
t7=t6;
f_2593(2,t7,C_SCHEME_UNDEFINED);}}
else{
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t3,a[11]=t2,a[12]=t1,a[13]=t4,tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_2612(t8,(C_word)C_eqp(lf[44],t7));}
else{
t7=t6;
f_2612(t7,C_SCHEME_FALSE);}}}}

/* k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2612,NULL,2,t0,t1);}
if(C_truep(t1)){
/* match.scm: 1198 k */
t2=((C_word*)t0)[13];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=t2;
f_2621(t4,(C_word)C_eqp(lf[76],t3));}
else{
t3=t2;
f_2621(t3,C_SCHEME_FALSE);}}}

/* k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2621,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[13]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cadr(((C_word*)t0)[13]);
t4=(C_word)C_i_symbolp(t3);
t5=(C_word)C_i_not(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_2659(t7,t5);}
else{
t7=(C_word)C_i_cadr(((C_word*)t0)[13]);
t8=t6;
f_2659(t8,(C_word)C_i_memq(t7,((C_word*)t0)[9]));}}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[13]);
t4=(C_word)C_a_i_list(&a,2,lf[76],t3);
t5=(C_word)C_i_cddr(((C_word*)t0)[13]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[52],t6);
/* match.scm: 1201 bound */
t8=((C_word*)((C_word*)t0)[8])[1];
f_2574(t8,((C_word*)t0)[10],t7,((C_word*)t0)[9],((C_word*)t0)[11]);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[13]))){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=t2;
f_2713(t4,(C_word)C_eqp(lf[95],t3));}
else{
t3=t2;
f_2713(t3,C_SCHEME_FALSE);}}}

/* k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2713(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2713,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[13]);
t3=(C_word)C_i_symbolp(t2);
t4=(C_word)C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_2722(t6,t4);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[13]);
t7=t5;
f_2722(t7,(C_word)C_i_memq(t6,((C_word*)t0)[9]));}}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[13]))){
t3=(C_word)C_i_car(((C_word*)t0)[13]);
t4=t2;
f_2790(t4,(C_word)C_eqp(lf[52],t3));}
else{
t3=t2;
f_2790(t3,C_SCHEME_FALSE);}}}

/* k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2790,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[11],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1240 bound* */
t4=((C_word*)((C_word*)t0)[10])[1];
f_3364(t4,((C_word*)t0)[9],t2,((C_word*)t0)[8],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t3=(C_word)C_i_car(((C_word*)t0)[12]);
t4=t2;
f_2813(t4,(C_word)C_eqp(lf[94],t3));}
else{
t3=t2;
f_2813(t3,C_SCHEME_FALSE);}}}

/* k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2813,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word)li68),tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1247 bound */
t4=((C_word*)((C_word*)t0)[8])[1];
f_2574(t4,((C_word*)t0)[6],t2,((C_word*)t0)[7],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t3=(C_word)C_i_car(((C_word*)t0)[12]);
t4=t2;
f_2902(t4,(C_word)C_eqp(lf[45],t3));}
else{
t3=t2;
f_2902(t3,C_SCHEME_FALSE);}}}

/* k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2902,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cadr(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1281 bound */
t5=((C_word*)((C_word*)t0)[7])[1];
f_2574(t5,((C_word*)t0)[6],t3,((C_word*)t0)[9],t4);}
else{
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
t4=(C_word)C_a_i_cons(&a,2,lf[94],t3);
t5=(C_word)C_a_i_list(&a,2,lf[45],t4);
/* match.scm: 1277 bound */
t6=((C_word*)((C_word*)t0)[7])[1];
f_2574(t6,((C_word*)t0)[6],t5,((C_word*)t0)[9],((C_word*)t0)[10]);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[11]);
/* match.scm: 1296 dot-dot-k? */
f_1329(t2,t4);}
else{
t4=t2;
f_2967(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2967(2,t3,C_SCHEME_FALSE);}}}

/* k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1296 bound */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2574(t4,((C_word*)t0)[4],t2,((C_word*)t0)[6],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[9]))){
t3=(C_word)C_i_car(((C_word*)t0)[9]);
t4=t2;
f_3015(t4,(C_word)C_eqp(lf[93],t3));}
else{
t3=t2;
f_3015(t3,C_SCHEME_FALSE);}}}

/* k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3015(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3015,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3024,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1312 bound* */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3364(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=t2;
f_3046(t4,(C_word)C_eqp(lf[92],t3));}
else{
t3=t2;
f_3046(t3,C_SCHEME_FALSE);}}}

/* k3044 in k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3046,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[6]))){
/* match.scm: 1323 k */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
/* match.scm: 1325 k */
t5=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],((C_word*)t0)[7],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_3076(t4,(C_word)C_eqp(lf[91],t3));}
else{
t3=t2;
f_3076(t3,C_SCHEME_FALSE);}}}

/* k3074 in k3044 in k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3076,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_memq(t2,((C_word*)t0)[6]))){
/* match.scm: 1331 k */
t3=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[6]);
/* match.scm: 1333 k */
t5=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],((C_word*)t0)[7],t4);}}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1336 bound */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2574(t4,((C_word*)t0)[4],t2,((C_word*)t0)[6],t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3146,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1348 vector->list */
t3=*((C_word*)lf[102]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
/* match.scm: 1354 k */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[7],((C_word*)t0)[6]);}}}}

/* k3144 in k3074 in k3044 in k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3148,a[2]=((C_word*)t0)[5],a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1347 boundv */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3271(t3,((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* a3147 in k3144 in k3074 in k3044 in k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3148,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3156,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1351 list->vector */
t5=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3154 in a3147 in k3144 in k3074 in k3044 in k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1351 k */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3114 in k3074 in k3044 in k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3115,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1340 bound */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2574(t6,t1,t4,t3,t5);}

/* a3124 in a3114 in k3074 in k3044 in k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3125,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* match.scm: 1344 k */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a3023 in k3013 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3024,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
t6=(C_word)C_a_i_cons(&a,2,lf[93],t5);
/* match.scm: 1317 k */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,t6,t3);}

/* a2975 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2976,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2980,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1301 find-prefix */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3403(t5,t4,t3,((C_word*)t0)[2]);}

/* k2978 in a2975 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1306 gensym */
t4=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2993 in k2978 in a2975 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1307 gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2997 in k2993 in k2978 in a2975 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}

/* a3004 in k2997 in k2993 in k2978 in a2975 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3005,3,t0,t1,t2);}
/* match.scm: 1309 gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k3001 in k2997 in k2993 in k2978 in a2975 in k2965 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
/* match.scm: 1304 k */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2931 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2932,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1286 permutation */
f_3427(t5,((C_word*)t0)[4],t3);}

/* k2951 in a2931 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2936(2,t2,C_SCHEME_UNDEFINED);}
else{
/* match.scm: 1289 ##match#syntax-err */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[100]);}}

/* k2934 in a2931 in k2900 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[45],((C_word*)t0)[5]);
/* match.scm: 1292 k */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2821 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2822,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cddr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2832,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t7,a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_2846(t9,t1,t4,t5);}

/* or* in a2821 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2846(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2846,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1259 k */
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t3,a[7]=t2,a[8]=((C_word)li66),tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1260 bound */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2574(t6,t1,t4,((C_word*)t0)[2],t5);}}

/* a2864 in or* in a2821 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2865,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2869,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1265 permutation */
f_3427(t5,t3,((C_word*)t0)[2]);}

/* k2894 in a2864 in or* in a2821 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2869(2,t2,C_SCHEME_UNDEFINED);}
else{
/* match.scm: 1268 ##match#syntax-err */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[99]);}}

/* k2867 in a2864 in or* in a2821 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1271 or* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2846(t4,((C_word*)t0)[2],t2,t3);}

/* a2877 in k2867 in a2864 in or* in a2821 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2878,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
/* match.scm: 1273 k */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2831 in a2821 in k2811 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2832,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_cons(&a,2,lf[94],t3);
/* match.scm: 1254 k */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,((C_word*)t0)[2]);}

/* a2798 in k2788 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2799,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[52],t2);
/* match.scm: 1245 k */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* k2720 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2722,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1221 gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1231 bound */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2574(t4,((C_word*)t0)[4],t2,((C_word*)t0)[3],t3);}}

/* a2756 in k2720 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2757,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_list(&a,3,lf[95],t4,t2);
/* match.scm: 1237 k */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t3);}

/* k2723 in k2720 in k2711 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=(C_word)C_i_caddr(((C_word*)t0)[7]);
t7=(C_word)C_a_i_list(&a,3,lf[95],t1,t6);
/* match.scm: 1225 bound */
t8=((C_word*)((C_word*)t0)[5])[1];
f_2574(t8,((C_word*)t0)[4],t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2657 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_2659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2659,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1209 gensym */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
/* match.scm: 1215 k */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k2660 in k2657 in k2619 in k2610 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[5])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,t4);
t6=(C_word)C_a_i_list(&a,2,lf[76],t1);
/* match.scm: 1213 k */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k2591 in bound in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* match.scm: 1196 k */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* find-prefix in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3403(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3403,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* match.scm: 1401 find-prefix */
t9=t6;
t10=t7;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k3419 in find-prefix in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* permutation in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3427(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3427,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=(C_word)C_i_length(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3439,a[2]=t3,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1407 every */
f_692(t1,t6,t2);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* a3438 in permutation in bound in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3439,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(t2,((C_word*)t0)[2]));}

/* inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3466(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3466,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3631,a[2]=t3,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3653,a[2]=t3,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_caddr(t2);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3726,a[2]=t5,a[3]=t9,a[4]=t4,a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3726(t11,t1,t6,C_SCHEME_END_OF_LIST,t7);}

/* loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3726(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3726,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3746,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1466 reverse */
t6=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cadr(t5);
t7=f_3631(((C_word*)t0)[4],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1467 caar */
t9=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
/* match.scm: 1485 loop */
t14=t1;
t15=t8;
t16=t10;
t17=t4;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}}}

/* k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=t1;
t4=((C_word*)t0)[3];
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3475,a[2]=t3,a[3]=t6,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3475(t8,t2,t4);}

/* loop in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3475(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3475,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* match.scm: 1419 loop */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_fix(1):C_fix(0)));}}

/* k3487 in loop in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3493,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1420 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3475(t4,t2,t3);}

/* k3491 in k3487 in loop in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3493,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* k3756 in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3758,2,t0,t1);}
if(C_truep((C_word)C_i_nequalp(C_fix(0),t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* match.scm: 1470 loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3726(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_nequalp(C_fix(1),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3780,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3780(t4,t2);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[8]);
t5=(C_word)C_i_cadr(t4);
/* match.scm: 1474 small? */
t6=t3;
f_3780(t6,f_3653(((C_word*)t0)[2],t5));}}}

/* k3778 in k3756 in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3780,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_cadr(t4);
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3515,a[2]=t5,a[3]=t7,a[4]=t9,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3515(t11,t3,t6);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* match.scm: 1481 loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3726(t5,((C_word*)t0)[5],t2,t4,((C_word*)t0)[3]);}}

/* loop in k3778 in k3756 in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3515(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3515,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3529,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* match.scm: 1426 loop */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?((C_word*)t0)[2]:t2));}}

/* k3527 in loop in k3778 in k3756 in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3533,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1427 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3515(t4,t2,t3);}

/* k3531 in k3527 in loop in k3778 in k3756 in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3533,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3789 in k3778 in k3756 in k3753 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1475 loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3726(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3744 in loop in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3746,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[22],t1,((C_word*)t0)[2]));}

/* small? in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static C_word C_fcall f_3653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=f_3549(t1);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t3,lf[21]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(t1);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_caddr(t1);
t8=f_3549(t7);
if(C_truep(t8)){
t9=(C_word)C_i_cdddr(t1);
return((C_word)C_i_nullp(t9));}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}

/* isval? in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static C_word C_fcall f_3631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=f_3549(t1);
if(C_truep(t2)){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
return((C_word)C_i_memq(t3,lf[96]));}
else{
return(C_SCHEME_FALSE);}}}

/* const? in inline-let in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static C_word C_fcall f_3549(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_stack_check;
t2=(C_word)C_i_symbolp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_booleanp(t1);
if(C_truep(t3)){
return(t3);}
else{
t4=(C_word)C_i_stringp(t1);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_charp(t1);
if(C_truep(t5)){
return(t5);}
else{
t6=(C_word)C_i_numberp(t1);
if(C_truep(t6)){
return(t6);}
else{
t7=(C_word)C_i_nullp(t1);
if(C_truep(t7)){
return(t7);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t8=(C_word)C_i_car(t1);
t9=(C_word)C_eqp(t8,lf[44]);
if(C_truep(t9)){
t10=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t1);
if(C_truep((C_word)C_i_symbolp(t11))){
t12=(C_word)C_i_cddr(t1);
return((C_word)C_i_nullp(t12));}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}}}}}}}

/* gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3850,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
if(C_truep((C_word)C_i_nullp(t4))){
/* match.scm: 1488 erract */
t8=t5;
((C_proc3)C_retrieve_proc(t8))(3,t8,t1,t2);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3861,a[2]=t9,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3870,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t2,a[6]=((C_word*)t0)[10],a[7]=t4,a[8]=((C_word)li23),tmp=(C_word)a,a+=9,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3879,a[2]=t10,a[3]=t11,a[4]=t4,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3975,a[2]=t12,a[3]=t11,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=t6,a[11]=t10,a[12]=t7,a[13]=((C_word*)t0)[5],a[14]=((C_word*)t0)[6],a[15]=((C_word*)t0)[7],a[16]=((C_word*)t0)[8],a[17]=((C_word*)t0)[9],a[18]=t9,tmp=(C_word)a,a+=19,tmp);
/* match.scm: 1515 caar */
t14=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,t4);}}

/* k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[16],a[12]=t3,a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word)li50),tmp=(C_word)a,a+=16,tmp));
t5=((C_word*)t3)[1];
f_3977(t5,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_3977(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[75],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3977,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_eqp(lf[74],t2);
if(C_truep(t7)){
/* match.scm: 1521 ks */
t8=t6;
((C_proc3)C_retrieve_proc(t8))(3,t8,t1,t4);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t8=(C_word)C_a_i_cons(&a,2,t2,t3);
t9=(C_word)C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[14])[1]);
t10=C_mutate(((C_word *)((C_word*)t0)[14])+1,t9);
/* match.scm: 1523 ks */
t11=t6;
((C_proc3)C_retrieve_proc(t11))(3,t11,t1,t4);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t8=(C_word)C_a_i_list(&a,2,lf[48],t3);
/* match.scm: 1524 emit */
t9=((C_word*)t0)[13];
f_5123(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_equalp(t2,lf[75]))){
t8=(C_word)C_a_i_list(&a,2,lf[48],t3);
/* match.scm: 1525 emit */
t9=((C_word*)t0)[13];
f_5123(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[38],t3,t2);
/* match.scm: 1526 emit */
t9=((C_word*)t0)[13];
f_5123(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_booleanp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[38],t3,t2);
/* match.scm: 1527 emit */
t9=((C_word*)t0)[13];
f_5123(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_charp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[38],t3,t2);
/* match.scm: 1528 emit */
t9=((C_word*)t0)[13];
f_5123(t9,t1,t8,t4,t5,t6);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t8=(C_word)C_a_i_list(&a,3,lf[38],t3,t2);
/* match.scm: 1529 emit */
t9=((C_word*)t0)[13];
f_5123(t9,t1,t8,t4,t5,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t5,a[16]=t4,a[17]=t1,a[18]=((C_word*)t0)[13],a[19]=t2,a[20]=t3,tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_car(t2);
t10=t8;
f_4088(t10,(C_word)C_eqp(lf[44],t9));}
else{
t9=t8;
f_4088(t9,C_SCHEME_FALSE);}}}}}}}}}}

/* k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4088,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,3,lf[38],((C_word*)t0)[20],((C_word*)t0)[19]);
/* match.scm: 1530 emit */
t3=((C_word*)t0)[18];
f_5123(t3,((C_word*)t0)[17],t2,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_4101(t4,(C_word)C_eqp(lf[76],t3));}
else{
t3=t2;
f_4101(t3,C_SCHEME_FALSE);}}}

/* k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4101,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
t3=(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[19]);
/* match.scm: 1538 emit */
t4=((C_word*)t0)[18];
f_5123(t4,((C_word*)t0)[17],t3,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4117(t4,(C_word)C_eqp(lf[95],t3));}
else{
t3=t2;
f_4117(t3,C_SCHEME_FALSE);}}}

/* k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4117,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[20]);
t3=(C_word)C_i_cadr(((C_word*)t0)[20]);
t4=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[19]);
/* match.scm: 1542 next */
t5=((C_word*)((C_word*)t0)[18])[1];
f_3977(t5,((C_word*)t0)[17],t2,t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[14],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4138(t4,(C_word)C_eqp(lf[52],t3));}
else{
t3=t2;
f_4138(t3,C_SCHEME_FALSE);}}}

/* k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4138,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[20]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4147,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[18],a[5]=t4,a[6]=((C_word*)t0)[19],a[7]=((C_word)li26),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4147(t6,((C_word*)t0)[15],t2,((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[13],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4180(t4,(C_word)C_eqp(lf[94],t3));}
else{
t3=t2;
f_4180(t3,C_SCHEME_FALSE);}}}

/* k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4180,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)((C_word*)t0)[20])[1];
t3=(C_word)C_i_cdr(((C_word*)t0)[19]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4189,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=t5,a[6]=t2,a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[18],a[9]=((C_word)li28),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4189(t7,((C_word*)t0)[14],t3,((C_word*)t0)[13]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[20],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[13],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_4223(t4,(C_word)C_eqp(lf[45],t3));}
else{
t3=t2;
f_4223(t3,C_SCHEME_FALSE);}}}

/* k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4223,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
/* match.scm: 1576 next */
t3=((C_word*)((C_word*)t0)[19])[1];
f_3977(t3,((C_word*)t0)[18],t2,((C_word*)t0)[17],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[13],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[20],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4236(t4,(C_word)C_eqp(lf[93],t3));}
else{
t3=t2;
f_4236(t3,C_SCHEME_FALSE);}}}

/* k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4236,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[20]);
t3=(C_word)C_i_cdr(((C_word*)t0)[20]);
t4=(C_word)C_i_length(t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[13],a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=t4,a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[18],a[10]=((C_word*)t0)[19],tmp=(C_word)a,a+=11,tmp);
/* match.scm: 1585 symbol-append */
f_7373(t5,(C_word)C_a_i_list(&a,2,t2,lf[76]));}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[18],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[11],a[19]=((C_word*)t0)[20],tmp=(C_word)a,a+=20,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[20]))){
t3=(C_word)C_i_car(((C_word*)t0)[20]);
t4=t2;
f_4298(t4,(C_word)C_eqp(lf[92],t3));}
else{
t3=t2;
f_4298(t3,C_SCHEME_FALSE);}}}

/* k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4298(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4298,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[19]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1608 setter */
t4=((C_word*)t0)[14];
f_6803(t4,t3,((C_word*)t0)[13],((C_word*)t0)[19]);}
else{
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[19]))){
t3=(C_word)C_i_car(((C_word*)t0)[19]);
t4=t2;
f_4323(t4,(C_word)C_eqp(lf[91],t3));}
else{
t3=t2;
f_4323(t3,C_SCHEME_FALSE);}}}

/* k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4323,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[18]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[17],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1615 getter */
t4=((C_word*)t0)[13];
f_7108(t4,t3,((C_word*)t0)[12],((C_word*)t0)[18]);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[17],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[12],tmp=(C_word)a,a+=18,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[18]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[18]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadr(((C_word*)t0)[18]);
/* match.scm: 1622 dot-dot-k? */
f_1329(t2,t4);}
else{
t4=t2;
f_4348(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4348(2,t3,C_SCHEME_FALSE);}}}

/* k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,lf[46],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4357,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word)li38),tmp=(C_word)a,a+=15,tmp);
/* match.scm: 1622 emit */
t4=((C_word*)t0)[8];
f_5123(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[13],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[16]))){
t2=(C_word)C_a_i_list(&a,2,lf[49],((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4655,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[16],a[9]=((C_word)li40),tmp=(C_word)a,a+=10,tmp);
/* match.scm: 1723 emit */
t4=((C_word*)t0)[8];
f_5123(t4,((C_word*)t0)[5],t2,((C_word*)t0)[4],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4687,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[15],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[16],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[16]))){
t3=(C_word)C_i_vector_length(((C_word*)t0)[16]);
if(C_truep((C_word)C_i_greater_or_equalp(t3,C_fix(6)))){
t4=(C_word)C_i_vector_length(((C_word*)t0)[16]);
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(5));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[16],t5);
/* match.scm: 1739 dot-dot-k? */
f_1329(t2,t6);}
else{
t4=t2;
f_4687(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4687(2,t3,C_SCHEME_FALSE);}}}}

/* k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4687,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_length(((C_word*)t0)[13]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t5=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[13],t5);
/* match.scm: 1745 dot-dot-k? */
f_1329(t4,t6);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[13]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[13]);
t3=(C_word)C_a_i_list(&a,2,lf[81],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[12],a[9]=((C_word)li49),tmp=(C_word)a,a+=10,tmp);
/* match.scm: 1833 emit */
t5=((C_word*)t0)[5];
f_5123(t5,((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[6],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1858 display */
t3=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[90]);}}}

/* k4975 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1860 newline */
t3=*((C_word*)lf[88]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4978 in k4975 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1861 ##sys#error */
t2=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,lf[87]);}

/* a4924 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[34],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4925,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[8]);
t4=(C_word)C_a_i_list(&a,3,lf[38],t3,((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4939,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[7],a[9]=((C_word)li48),tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_4939(t9,t5,C_fix(0));}

/* vloop in a4924 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4939,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li47),tmp=(C_word)a,a+=11,tmp));}

/* f_4941 in vloop in a4924 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4941,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[9],((C_word*)t0)[8]))){
/* match.scm: 1846 ks */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(C_word)C_i_vector_ref(((C_word*)t0)[6],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[19],((C_word*)t0)[5],((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[9]);
/* match.scm: 1855 vloop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4939(t7,t5,t6);}}

/* k4964 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1847 next */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3977(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4935 in a4924 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1837 emit */
t2=((C_word*)t0)[6];
f_5123(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4691 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[13],t1);
t3=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[13],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[12],t3);
t5=(C_word)C_a_i_list(&a,2,lf[81],((C_word*)t0)[11]);
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t4,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[10],a[11]=t2,a[12]=((C_word*)t0)[11],a[13]=((C_word)li46),tmp=(C_word)a,a+=14,tmp);
/* match.scm: 1756 emit */
t7=((C_word*)t0)[4];
f_5123(t7,((C_word*)t0)[3],t5,((C_word*)t0)[2],((C_word*)t0)[5],t6);}

/* a4707 in k4691 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[31],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4708,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[12]);
t4=(C_word)C_a_i_list(&a,3,lf[83],t3,((C_word*)t0)[11]);
t5=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t2,a[13]=t4,a[14]=t1,a[15]=((C_word*)t0)[10],tmp=(C_word)a,a+=16,tmp);
/* match.scm: 1764 kf */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k4718 in a4707 in k4691 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4724,a[2]=t1,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[12],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4729,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word)li45),tmp=(C_word)a,a+=14,tmp));
t7=((C_word*)t5)[1];
f_4729(t7,t3,C_fix(0));}

/* vloop in k4718 in a4707 in k4691 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4729(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4729,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,a[14]=((C_word)li44),tmp=(C_word)a,a+=15,tmp));}

/* f_4731 in vloop in k4718 in a4707 in k4691 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[62],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4731,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[13],((C_word*)t0)[12]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[12]);
t4=(C_word)C_eqp(t3,lf[74]);
if(C_truep(t4)){
/* match.scm: 1783 ks */
t5=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t2);}
else{
t5=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(3));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[11],t5);
t7=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(4));
t8=(C_word)C_i_vector_ref(((C_word*)t0)[11],t7);
t9=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[12],C_fix(5));
t10=(C_word)C_i_vector_ref(((C_word*)t0)[11],t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t2,a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t8,a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t12=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[12]);
t13=(C_word)C_a_i_list(&a,3,lf[19],((C_word*)t0)[8],t8);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4841,a[2]=t10,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=t8,a[7]=((C_word)li43),tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1796 next */
t15=((C_word*)((C_word*)t0)[4])[1];
f_3977(t15,t11,t12,t13,t2,((C_word*)t0)[3],t14);}}
else{
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],((C_word*)t0)[13]);
t4=(C_word)C_a_i_list(&a,3,lf[19],((C_word*)t0)[8],((C_word*)t0)[13]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4753,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[13]);
/* match.scm: 1777 vloop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4729(t7,t5,t6);}}

/* k4751 */
static void C_ccall f_4753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1769 next */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3977(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4840 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4841,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[84],((C_word*)t0)[6],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[4],a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1808 map */
t6=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4858 in a4840 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4859,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4867,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1810 val */
t5=((C_word*)t0)[2];
f_3861(3,t5,t4,t2);}

/* k4865 in a4858 in a4840 */
static void C_ccall f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4867,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],t1,((C_word*)t0)[2]));}

/* k4855 in a4840 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4857,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4776 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4831,a[2]=((C_word*)t0)[11],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1816 map */
t4=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[79]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4829 in k4776 */
static void C_ccall f_4831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1815 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4780 in k4776 */
static void C_ccall f_4782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4782,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[11])+1,t1);
t3=(C_word)C_a_i_list(&a,2,lf[82],((C_word*)t0)[10]);
t4=(C_word)C_a_i_list(&a,3,lf[84],t3,C_fix(1));
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4811,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a4810 in k4780 in k4776 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4811,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[44],C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k4807 in k4780 in k4776 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_list(&a,3,lf[85],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4801,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1829 ks */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4799 in k4807 in k4780 in k4776 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[51],((C_word*)t0)[6],t1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[22],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* k4725 in k4718 in a4707 in k4691 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4722 in k4718 in a4707 in k4691 in k4685 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1761 assm */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5305(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4654 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4655,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4667,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* match.scm: 1728 add-a */
t5=((C_word*)t0)[2];
f_6736(t5,t4,((C_word*)t0)[3]);}

/* k4665 in a4654 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word)li39),tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1727 next */
t3=((C_word*)((C_word*)t0)[9])[1];
f_3977(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],((C_word*)t0)[8],t2);}

/* a4668 in k4665 in a4654 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4669,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1733 add-d */
t5=((C_word*)t0)[3];
f_6769(t5,t4,((C_word*)t0)[2]);}

/* k4679 in a4668 in k4665 in a4654 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1732 next */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3977(t2,((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4357,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* match.scm: 1626 dot-dot-k? */
f_1329(t3,t4);}

/* k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word)li37),tmp=(C_word)a,a+=12,tmp);
switch(t1){
case C_fix(0):
/* match.scm: 1711 ks */
t3=t2;
f_4362(3,t3,((C_word*)t0)[5],((C_word*)t0)[4]);
case C_fix(1):
t3=(C_word)C_a_i_list(&a,2,lf[49],((C_word*)t0)[12]);
/* match.scm: 1712 emit */
t4=((C_word*)t0)[3];
f_5123(t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[10],t2);
default:
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t4=(C_word)C_a_i_list(&a,2,t3,((C_word*)t0)[12]);
/* match.scm: 1717 emit */
t5=((C_word*)t0)[3];
f_5123(t5,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[10],t2);}}

/* ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[30],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4362,3,t0,t1,t2);}
t3=(C_word)C_i_list_ref(((C_word*)t0)[10],C_fix(2));
t4=(C_word)C_i_car(((C_word*)t0)[10]);
t5=(C_word)C_eqp(t4,lf[74]);
if(C_truep(t5)){
/* match.scm: 1634 ks */
t6=((C_word*)t0)[9];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,t2);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[9],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[10]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4461,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1636 next */
t10=((C_word*)((C_word*)t0)[4])[1];
f_3977(t10,t6,t7,((C_word*)t0)[5],t2,t8,t9);}
else{
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_symbolp(t7))){
t8=(C_word)C_i_car(((C_word*)t0)[10]);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=t6;
f_4471(t10,(C_word)C_i_equalp(t9,t3));}
else{
t8=t6;
f_4471(t8,C_SCHEME_FALSE);}}}}

/* k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4471,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[11]);
/* match.scm: 1665 next */
t3=((C_word*)((C_word*)t0)[10])[1];
f_3977(t3,((C_word*)t0)[9],t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(3));
t3=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(4));
t4=(C_word)C_i_list_ref(((C_word*)t0)[11],C_fix(5));
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[11]);
t7=(C_word)C_a_i_list(&a,2,lf[24],t3);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4555,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t3,a[7]=((C_word)li36),tmp=(C_word)a,a+=8,tmp);
/* match.scm: 1679 next */
t9=((C_word*)((C_word*)t0)[10])[1];
f_3977(t9,t5,t6,t7,((C_word*)t0)[7],((C_word*)t0)[6],t8);}}

/* a4554 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4555,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[25],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[4],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1686 map */
t6=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4572 in a4554 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4573,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4581,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* match.scm: 1688 val */
t5=((C_word*)t0)[2];
f_3861(3,t5,t4,t2);}

/* k4579 in a4572 in a4554 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4581,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[79],t1,((C_word*)t0)[2]));}

/* k4569 in a4554 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4571,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k4488 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4541,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[3]);}

/* a4540 in k4488 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4541,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[80],t2));}

/* k4537 in k4488 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1694 map */
t2=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[79]+1),((C_word*)t0)[2],t1);}

/* k4533 in k4488 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1693 append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4492 in k4488 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4494,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[10])+1,t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4523,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a4522 in k4492 in k4488 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4523,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[44],C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k4519 in k4492 in k4488 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4521,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_list(&a,2,lf[48],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4513,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1708 ks */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4511 in k4519 in k4492 in k4488 in k4469 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[51],((C_word*)t0)[6],t1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,4,lf[22],((C_word*)t0)[3],((C_word*)t0)[2],t2));}

/* a4463 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4464,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a4460 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4461,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k4382 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4405,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t4=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cadr(t1);
t7=(C_word)C_eqp(((C_word*)t0)[2],t6);
if(C_truep(t7)){
t8=(C_word)C_i_cddr(t1);
t9=t3;
f_4405(t9,(C_word)C_i_nullp(t8));}
else{
t8=t3;
f_4405(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_4405(t6,C_SCHEME_FALSE);}}
else{
t5=t3;
f_4405(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4405(t4,C_SCHEME_FALSE);}}

/* k4403 in k4382 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4405,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4387(t2,(C_word)C_i_car(((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4387(t3,(C_word)C_a_i_list(&a,3,lf[21],t2,((C_word*)t0)[3]));}}

/* k4385 in k4382 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4387(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4387,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[77],t1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1659 kf */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4396 in k4385 in k4382 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4402,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1660 ks */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4400 in k4396 in k4385 in k4382 in ks in k4359 in a4356 in k4346 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1656 assm */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5305(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4340 in k4321 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
/* match.scm: 1619 ks */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4315 in k4296 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
/* match.scm: 1612 ks */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4290 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4292,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4255,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4257,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word)li30),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4257(t7,t3,C_fix(1));}

/* rloop in k4290 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4257,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word)li29),tmp=(C_word)a,a+=11,tmp));}

/* f_4259 in rloop in k4290 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4259,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nequalp(((C_word*)t0)[9],((C_word*)t0)[8]))){
/* match.scm: 1596 ks */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}
else{
t3=(C_word)C_i_list_ref(((C_word*)t0)[6],((C_word*)t0)[9]);
t4=(C_word)C_a_i_list(&a,3,lf[26],((C_word*)t0)[5],((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4284,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1),((C_word*)t0)[9]);
/* match.scm: 1603 rloop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_4257(t7,t5,t6);}}

/* k4282 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1597 next */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3977(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4253 in k4290 in k4234 in k4221 in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1589 emit */
t2=((C_word*)t0)[6];
f_5123(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4189(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4189,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1566 kf */
t4=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4209,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1569 next */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3977(t7,t1,t5,((C_word*)t0)[3],t3,t6,((C_word*)t0)[2]);}}

/* a4208 in loop in k4178 in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4209,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1573 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4189(t4,t1,t3,t2);}

/* loop in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_4147(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4147,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* match.scm: 1553 ks */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1554 next */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3977(t6,t1,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],t5);}}

/* a4165 in loop in k4136 in k4115 in k4099 in k4086 in next in k3973 in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4166,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 1559 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4147(t4,t1,t3,t2);}

/* success in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3879,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_i_cddddr(t3);
t5=(C_word)C_i_set_car(t4,C_SCHEME_TRUE);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(C_word)C_i_cadr(t6);
t8=(C_word)C_i_car(((C_word*)t0)[4]);
t9=(C_word)C_i_caddr(t8);
t10=(C_word)C_i_car(((C_word*)t0)[4]);
t11=(C_word)C_i_cadddr(t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3941,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t7,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
/* map */
t13=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)t0)[2],t9);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3948,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t13=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,((C_word*)t0)[2],t9);}}

/* k3946 in success in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3939 in success in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1512 fail */
t6=((C_word*)t0)[3];
f_3870(3,t6,t5,((C_word*)t0)[2]);}

/* k3931 in k3939 in success in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[48],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_list(&a,3,lf[22],t5,((C_word*)t0)[4]);
t7=(C_word)C_a_i_list(&a,3,lf[21],((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,2,lf[53],t7));}

/* fail in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3870,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* match.scm: 1492 gen */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3850(t4,t1,((C_word*)t0)[5],t2,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* val in gen in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_3861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3861,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* dot-dot-k? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_1329(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1329,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t2;
if(C_truep((C_truep((C_word)C_eqp(t3,lf[69]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[70]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 826  symbol->string */
t5=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1343 in dot-dot-k? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_less_or_equalp(C_fix(3),t2))){
t3=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(95)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=(C_word)C_i_string_ref(t1,C_fix(1));
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(95)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1372,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1383,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1387,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 834  substring */
t8=*((C_word*)lf[71]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t1,C_fix(2),t2);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1385 in k1343 in dot-dot-k? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1381 in k1343 in dot-dot-k? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 831  every */
f_692(((C_word*)t0)[2],*((C_word*)lf[72]+1),t1);}

/* k1370 in k1343 in dot-dot-k? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1379,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* match.scm: 836  substring */
t3=*((C_word*)lf[71]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1377 in k1370 in k1343 in dot-dot-k? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 835  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_5123(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5123,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,a[6]=t3,a[7]=t1,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* match.scm: 1864 in */
t7=((C_word*)t0)[2];
f_6330(t7,t6,t2,t3);}

/* k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5130,2,t0,t1);}
if(C_truep(t1)){
/* match.scm: 1864 ks */
t2=((C_word*)t0)[8];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5139,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[45],((C_word*)t0)[4]);
/* match.scm: 1865 in */
t4=((C_word*)t0)[2];
f_6330(t4,t2,t3,((C_word*)t0)[6]);}}

/* k5137 in k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[58],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5139,2,t0,t1);}
if(C_truep(t1)){
/* match.scm: 1865 kf */
t2=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5148,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t4,lf[38]);
if(C_truep(t5)){
t6=(C_word)C_i_caddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_stringp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[39],t2);
t8=t3;
f_5148(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_booleanp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[40],t2);
t8=t3;
f_5148(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_charp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[41],t2);
t8=t3;
f_5148(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
if(C_truep((C_word)C_i_numberp(t6))){
t7=(C_word)C_a_i_list(&a,2,lf[42],t2);
t8=t3;
f_5148(t8,(C_word)C_a_i_list(&a,1,t7));}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5261,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t6))){
t8=(C_word)C_i_car(t6);
t9=t7;
f_5261(t9,(C_word)C_eqp(lf[44],t8));}
else{
t8=t7;
f_5261(t8,C_SCHEME_FALSE);}}}}}}
else{
t6=(C_word)C_i_car(((C_word*)t0)[4]);
t7=(C_word)C_eqp(t6,lf[48]);
if(C_truep(t7)){
t8=(C_word)C_a_i_list(&a,2,lf[46],t2);
t9=t3;
f_5148(t9,(C_word)C_a_i_list(&a,1,t8));}
else{
t8=t3;
f_5148(t8,C_SCHEME_END_OF_LIST);}}}}

/* k5259 in k5137 in k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_5261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5261,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,2,lf[43],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5148(t3,(C_word)C_a_i_list(&a,1,t2));}
else{
t2=((C_word*)t0)[2];
f_5148(t2,C_SCHEME_END_OF_LIST);}}

/* k5146 in k5137 in k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_5148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5148,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5154,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_eqp(t2,lf[46]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,lf[48],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,lf[45],t5);
t7=t3;
f_5154(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t5=t3;
f_5154(t5,C_SCHEME_END_OF_LIST);}}

/* k5152 in k5146 in k5137 in k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_5154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5154,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5157,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5183,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1895 append */
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k5181 in k5152 in k5146 in k5137 in k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5183,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* match.scm: 1895 ks */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5155 in k5152 in k5146 in k5137 in k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5160,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_a_i_list(&a,2,lf[45],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5175,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1897 append */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5173 in k5155 in k5152 in k5146 in k5137 in k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* match.scm: 1896 kf */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k5158 in k5155 in k5152 in k5146 in k5137 in k5128 in emit in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1898 assm */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5305(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_5305(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5305,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_equalp(t4,t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(t4,C_SCHEME_TRUE);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[49]);
if(C_truep(t9)){
t10=*((C_word*)lf[8]+1);
if(C_truep((C_truep((C_word)C_eqp(t10,lf[66]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t10,lf[67]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t11=(C_word)C_i_car(t3);
if(C_truep((C_truep((C_word)C_eqp(t11,lf[50]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t11,lf[7]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t12=(C_word)C_i_cadr(t2);
/* match.scm: 1906 guarantees */
t13=((C_word*)t0)[2];
f_6199(t13,t7,t4,t12);}
else{
t12=t7;
f_5324(2,t12,C_SCHEME_FALSE);}}
else{
t11=t7;
f_5324(2,t11,C_SCHEME_FALSE);}}
else{
t10=t7;
f_5324(2,t10,C_SCHEME_FALSE);}}}}

/* k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_eqp(t3,lf[51]);
if(C_truep(t4)){
t5=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t6=t2;
f_5330(t6,(C_word)C_i_equalp(t5,((C_word*)t0)[3]));}
else{
t5=t2;
f_5330(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5330(t3,C_SCHEME_FALSE);}}}

/* k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_5330(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5330,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[52]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[52],t7);
t9=(C_word)C_i_caddr(((C_word*)t0)[6]);
t10=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_a_i_list(&a,4,lf[51],t8,t9,((C_word*)t0)[3]));}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_list(&a,3,lf[52],((C_word*)t0)[5],t5);
t7=(C_word)C_i_caddr(((C_word*)t0)[6]);
t8=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,4,lf[51],t6,t7,((C_word*)t0)[3]));}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,lf[53]);
if(C_truep(t4)){
t5=(C_word)C_i_cdr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6129,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1923 caadr */
t8=*((C_word*)lf[64]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[6]);}
else{
t7=t2;
f_5388(t7,C_SCHEME_FALSE);}}
else{
t6=t2;
f_5388(t6,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5388(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5388(t3,C_SCHEME_FALSE);}}}

/* k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6129,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[21]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1924 cdadr */
t4=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6125,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1925 cadadr */
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6121,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1926 cadadr */
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6117,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1927 cddadr */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6109,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1928 cddadr */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6105,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6097,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1929 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k6095 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1929 caar */
t2=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6093,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[22]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6089,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1930 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k6087 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1930 cdar */
t2=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6085,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6081,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1931 cddadr */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k6079 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1931 cadar */
t2=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6077,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6073,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1932 cddadr */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k6071 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1932 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6069,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6065,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1933 cddadr */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k6063 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1933 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6061,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6053,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1934 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k6051 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1934 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6049,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6037,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6041,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1935 cddadr */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k6039 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1935 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6035 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1935 caadr */
t2=*((C_word*)lf[64]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6033,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[21]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6025,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6029,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1936 cddadr */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k6027 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1936 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6023 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1936 cdadr */
t2=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6021,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6013,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6017,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1937 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k6015 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1937 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6011 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1937 cadadr */
t2=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6009,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6001,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6005,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1938 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k6003 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1938 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5999 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1938 cddadr */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5997,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5989,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5993,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1939 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k5991 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1939 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5987 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1939 cddadr */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5985,2,t0,t1);}
t2=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5969,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5973,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5977,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1940 cddadr */
t7=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k5975 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1940 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5971 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1940 cddadr */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5967 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1940 cdar */
t2=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5965,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5953,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5957,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5961,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1941 cddadr */
t6=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k5959 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1941 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5955 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1941 cddadr */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5951 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1941 cddar */
t2=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5941,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5945,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1942 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k5943 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1942 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5939 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1942 cddadr */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5937,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5929,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1943 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k5927 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1943 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5925,2,t0,t1);}
t2=(C_word)C_i_cddr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5917,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1944 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k5915 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1944 cdadar */
t2=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5913,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5909,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1945 cddadr */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k5907 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1945 cddar */
t2=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5903 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5905,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5901,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1946 cddadr */
t4=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k5899 in k5903 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1946 cdddar */
t2=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5895 in k5903 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5897,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1947 cddadr */
t3=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_5388(t2,C_SCHEME_FALSE);}}

/* k5891 in k5895 in k5903 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5893,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5873,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5877,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5881,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1949 cddadr */
t8=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
f_5388(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5388(t3,C_SCHEME_FALSE);}}

/* k5879 in k5891 in k5895 in k5903 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1949 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5875 in k5891 in k5895 in k5903 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1949 cddadr */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5871 in k5891 in k5895 in k5903 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1949 cadar */
t2=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5867 in k5891 in k5895 in k5903 in k5911 in k5923 in k5935 in k5947 in k5963 in k5983 in k5995 in k6007 in k6019 in k6031 in k6047 in k6059 in k6067 in k6075 in k6083 in k6091 in k6103 in k6107 in k6115 in k6119 in k6123 in k6127 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_5388(t2,(C_word)C_i_equalp(((C_word*)t0)[2],t1));}

/* k5386 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_5388(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5388,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* match.scm: 1949 cadadr */
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[51],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6]));}}

/* k5450 in k5386 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5448,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1952 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k5446 in k5450 in k5386 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1951 caadar */
t2=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5442 in k5450 in k5386 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* match.scm: 1955 cddadr */
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k5438 in k5442 in k5450 in k5386 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 1954 caddar */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5395 in k5442 in k5450 in k5386 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5397,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* match.scm: 1961 assm */
t9=((C_word*)((C_word*)t0)[3])[1];
f_5305(t9,t7,((C_word*)t0)[2],t8,t1);}

/* k5418 in k5395 in k5442 in k5450 in k5386 in k5328 in k5322 in assm in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5420,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[22],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,3,lf[21],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[53],t3));}

/* guarantees in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6199(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6199,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6203,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* match.scm: 1992 add-a */
t5=((C_word*)t0)[2];
f_6736(t5,t4,t3);}

/* k6201 in guarantees in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6206,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* match.scm: 1992 add-d */
t3=((C_word*)t0)[3];
f_6769(t3,t2,((C_word*)t0)[2]);}

/* k6204 in k6201 in guarantees in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6206,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6211,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6211(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6204 in k6201 in guarantees in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6211(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6211,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_eqp(t3,lf[50]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[7]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_equalp(t2,((C_word*)t0)[4]);
t5=(C_truep(t4)?t4:(C_word)C_i_equalp(t2,((C_word*)t0)[3]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[51]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6242,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_i_cadr(t2);
/* match.scm: 1998 loop */
t17=t8;
t18=t9;
t1=t17;
t2=t18;
goto loop;}
else{
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[21]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6278,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=t10;
f_6278(t14,(C_word)C_i_symbolp(t13));}
else{
t13=t10;
f_6278(t13,C_SCHEME_FALSE);}}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6276 in loop in k6204 in k6201 in guarantees in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6278,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* match.scm: 2006 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6211(t4,t2,t3);}}

/* k6279 in k6276 in loop in k6204 in k6201 in guarantees in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 2007 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6211(t3,((C_word*)t0)[4],t2);}}

/* k6240 in loop in k6204 in k6201 in guarantees in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6242,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
/* match.scm: 1999 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6211(t4,t2,t3);}}

/* k6249 in k6240 in loop in k6204 in k6201 in guarantees in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadddr(((C_word*)t0)[4]);
/* match.scm: 2001 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6211(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6330(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6330,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_member(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6340,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[46]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_list(&a,2,lf[48],t8);
t10=(C_word)C_i_member(t9,t3);
if(C_truep(t10)){
t11=t5;
f_6340(t11,t10);}
else{
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,2,lf[49],t11);
t13=t5;
f_6340(t13,(C_word)C_i_member(t12,t3));}}
else{
t8=t5;
f_6340(t8,C_SCHEME_FALSE);}}}

/* k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6340,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[45]);
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* match.scm: 2015 equal-test? */
f_6640(t5,t4);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6355,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word)li13),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_6363(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=f_6726(((C_word*)t0)[6]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6481,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_6481(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_i_car(((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,lf[46]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t6,a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6547(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* mem in k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6547,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6560,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6726(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_memq(t8,lf[47]);
t10=t4;
f_6560(t10,(C_word)C_i_not(t9));}
else{
t8=t4;
f_6560(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6560(t7,C_SCHEME_FALSE);}}}

/* k6558 in mem in k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 2068 mem */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6547(t3,((C_word*)t0)[4],t2);}}

/* mem in k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6481(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6481,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6494,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6726(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_i_equalp(t8,t9);
t11=t4;
f_6494(t11,(C_word)C_i_not(t10));}
else{
t8=t4;
f_6494(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6494(t7,C_SCHEME_FALSE);}}}

/* k6492 in mem in k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6494(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 2054 mem */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6481(t3,((C_word*)t0)[4],t2);}}

/* mem in k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6363(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6363,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_cadr(t3);
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_equalp(t5,t6))){
t7=f_6726(t3);
if(C_truep(t7)){
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_equalp(((C_word*)t0)[5],t8);
t10=t4;
f_6376(t10,(C_word)C_i_not(t9));}
else{
t8=t4;
f_6376(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6376(t7,C_SCHEME_FALSE);}}}

/* k6374 in mem in k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_list(&a,2,lf[45],t3);
t5=(C_word)C_i_equalp(((C_word*)t0)[5],t4);
if(C_truep(t5)){
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[5]);
t8=(C_word)C_i_cadr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_equalp(t7,t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6407,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* match.scm: 2035 equal-test? */
f_6640(t9,((C_word*)t0)[5]);}
else{
t9=t6;
f_6388(t9,C_SCHEME_FALSE);}}}}

/* k6405 in k6374 in mem in k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_6407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=(C_word)C_i_equalp(t2,t3);
t5=((C_word*)t0)[2];
f_6388(t5,(C_word)C_i_not(t4));}
else{
t2=((C_word*)t0)[2];
f_6388(t2,C_SCHEME_FALSE);}}

/* k6386 in k6374 in mem in k6353 in k6338 in in in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6388(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* match.scm: 2041 mem */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6363(t3,((C_word*)t0)[4],t2);}}

/* equal-test? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6640(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6640,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(t3,lf[38]);
if(C_truep(t4)){
t5=(C_word)C_i_caddr(t2);
if(C_truep((C_word)C_i_stringp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[39]);}
else{
if(C_truep((C_word)C_booleanp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[40]);}
else{
if(C_truep((C_word)C_charp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[41]);}
else{
if(C_truep((C_word)C_i_numberp(t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[42]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6680,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_car(t5);
t10=(C_word)C_eqp(lf[44],t9);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t5);
t12=t6;
f_6680(t12,(C_word)C_i_symbolp(t11));}
else{
t11=t6;
f_6680(t11,C_SCHEME_FALSE);}}
else{
t9=t6;
f_6680(t9,C_SCHEME_FALSE);}}
else{
t8=t6;
f_6680(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_6680(t7,C_SCHEME_FALSE);}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k6678 in equal-test? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6680(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?lf[43]:C_SCHEME_FALSE));}

/* disjoint? in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static C_word C_fcall f_6726(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_car(t1);
return((C_word)C_i_memq(t2,*((C_word*)lf[13]+1)));}

/* add-a in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6736,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6740,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_6740(t5,(C_word)C_i_assq(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_6740(t4,C_SCHEME_FALSE);}}

/* k6738 in add-a in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6740,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[24],((C_word*)t0)[3]));}}

/* add-d in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6769(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6769,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6773,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_6773(t5,(C_word)C_i_assq(t4,((C_word*)t0)[2]));}
else{
t4=t3;
f_6773(t4,C_SCHEME_FALSE);}}

/* k6771 in add-d in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6773,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[25],((C_word*)t0)[3]));}}

/* setter in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6803(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[233],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6803,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6805,a[2]=((C_word*)t0)[3],a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(t2);
t8=(C_word)C_a_i_list(&a,2,lf[20],t7);
t9=(C_word)C_a_i_list(&a,1,t8);
t10=(C_word)C_a_i_list(&a,1,lf[30]);
t11=(C_word)C_i_caddr(t2);
t12=(C_word)C_a_i_list(&a,4,lf[31],lf[20],t11,lf[30]);
t13=(C_word)C_a_i_list(&a,3,lf[21],t10,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_list(&a,3,lf[22],t9,t13));}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(t7,lf[23]);
if(C_truep(t8)){
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_a_i_list(&a,2,lf[20],t9);
t11=(C_word)C_a_i_list(&a,1,t10);
t12=(C_word)C_a_i_list(&a,1,lf[30]);
t13=(C_word)C_a_i_list(&a,3,lf[32],lf[20],lf[30]);
t14=(C_word)C_a_i_list(&a,3,lf[21],t12,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[22],t11,t14));}
else{
t9=(C_word)C_i_car(t2);
t10=(C_word)C_eqp(t9,lf[24]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_a_i_list(&a,2,lf[20],t11);
t13=(C_word)C_a_i_list(&a,1,t12);
t14=(C_word)C_a_i_list(&a,1,lf[30]);
t15=(C_word)C_a_i_list(&a,3,lf[33],lf[20],lf[30]);
t16=(C_word)C_a_i_list(&a,3,lf[21],t14,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_list(&a,3,lf[22],t13,t16));}
else{
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(t11,lf[25]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_a_i_list(&a,2,lf[20],t13);
t15=(C_word)C_a_i_list(&a,1,t14);
t16=(C_word)C_a_i_list(&a,1,lf[30]);
t17=(C_word)C_a_i_list(&a,3,lf[34],lf[20],lf[30]);
t18=(C_word)C_a_i_list(&a,3,lf[21],t16,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,(C_word)C_a_i_list(&a,3,lf[22],t15,t18));}
else{
t13=(C_word)C_i_car(t2);
t14=(C_word)C_eqp(t13,lf[26]);
if(C_truep(t14)){
t15=(C_word)C_i_cadr(t2);
t16=(C_word)C_a_i_list(&a,2,lf[20],t15);
t17=(C_word)C_a_i_list(&a,1,t16);
t18=(C_word)C_a_i_list(&a,1,lf[30]);
t19=(C_word)C_i_caddr(t2);
t20=(C_word)C_a_i_list(&a,4,lf[35],lf[20],t19,lf[30]);
t21=(C_word)C_a_i_list(&a,3,lf[21],t18,t20);
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,(C_word)C_a_i_list(&a,3,lf[22],t17,t21));}
else{
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6997,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t16)){
t18=(C_word)C_i_cadr(t16);
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_a_i_list(&a,2,t18,t19);
t21=(C_word)C_a_i_list(&a,2,lf[20],t20);
t22=(C_word)C_a_i_list(&a,1,t21);
t23=(C_word)C_a_i_list(&a,1,lf[30]);
t24=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7058,a[2]=t22,a[3]=t17,a[4]=t23,tmp=(C_word)a,a+=5,tmp);
t25=(C_word)C_i_cddr(t16);
/* match.scm: 2136 mk-setter */
t26=t4;
f_6805(t26,t24,t25);}
else{
t18=t17;
f_6997(t18,C_SCHEME_FALSE);}}}}}}}
else{
/* match.scm: 2110 ##match#syntax-err */
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,lf[36]);}}

/* k7056 in setter in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7058,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,lf[20],lf[30]);
t3=(C_word)C_a_i_list(&a,3,lf[21],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
f_6997(t4,(C_word)C_a_i_list(&a,3,lf[22],((C_word*)t0)[2],t3));}

/* k6995 in setter in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6997(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6997,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[20],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_a_i_list(&a,1,lf[30]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7023,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[3]);
/* match.scm: 2138 mk-setter */
t8=((C_word*)t0)[2];
f_6805(t8,t6,t7);}}

/* k7021 in k6995 in setter in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7023,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,lf[20],lf[30]);
t3=(C_word)C_a_i_list(&a,3,lf[21],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[22],((C_word*)t0)[2],t3));}

/* mk-setter in setter in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_6805(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6805,NULL,3,t0,t1,t2);}
/* match.scm: 2108 symbol-append */
f_7373(t1,(C_word)C_a_i_list(&a,3,lf[28],t2,lf[29]));}

/* getter in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7108(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[214],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7108,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,lf[19]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_a_i_list(&a,2,lf[20],t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_caddr(t2);
t10=(C_word)C_a_i_list(&a,3,lf[19],lf[20],t9);
t11=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_list(&a,3,lf[22],t8,t11));}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[23]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_a_i_list(&a,2,lf[20],t8);
t10=(C_word)C_a_i_list(&a,1,t9);
t11=(C_word)C_a_i_list(&a,2,lf[23],lf[20]);
t12=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t11);
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_a_i_list(&a,3,lf[22],t10,t12));}
else{
t8=(C_word)C_i_car(t2);
t9=(C_word)C_eqp(t8,lf[24]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_a_i_list(&a,2,lf[20],t10);
t12=(C_word)C_a_i_list(&a,1,t11);
t13=(C_word)C_a_i_list(&a,2,lf[24],lf[20]);
t14=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t13);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_a_i_list(&a,3,lf[22],t12,t14));}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[25]);
if(C_truep(t11)){
t12=(C_word)C_i_cadr(t2);
t13=(C_word)C_a_i_list(&a,2,lf[20],t12);
t14=(C_word)C_a_i_list(&a,1,t13);
t15=(C_word)C_a_i_list(&a,2,lf[25],lf[20]);
t16=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t15);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_a_i_list(&a,3,lf[22],t14,t16));}
else{
t12=(C_word)C_i_car(t2);
t13=(C_word)C_eqp(t12,lf[26]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t2);
t15=(C_word)C_a_i_list(&a,2,lf[20],t14);
t16=(C_word)C_a_i_list(&a,1,t15);
t17=(C_word)C_i_caddr(t2);
t18=(C_word)C_a_i_list(&a,3,lf[26],lf[20],t17);
t19=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t18);
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_word)C_a_i_list(&a,3,lf[22],t16,t19));}
else{
t14=(C_word)C_i_car(t2);
t15=(C_word)C_i_assq(t14,((C_word*)t0)[2]);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7277,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t15)){
t17=(C_word)C_i_cadr(t15);
t18=(C_word)C_i_cadr(t2);
t19=(C_word)C_a_i_list(&a,2,t17,t18);
t20=(C_word)C_a_i_list(&a,2,lf[20],t19);
t21=(C_word)C_a_i_list(&a,1,t20);
t22=(C_word)C_i_cddr(t15);
t23=(C_word)C_a_i_list(&a,2,t22,lf[20]);
t24=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t23);
t25=t16;
f_7277(t25,(C_word)C_a_i_list(&a,3,lf[22],t21,t24));}
else{
t17=t16;
f_7277(t17,C_SCHEME_FALSE);}}}}}}}
else{
/* match.scm: 2141 ##match#syntax-err */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,lf[27]);}}

/* k7275 in getter in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7277,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,2,lf[20],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t5,lf[20]);
t7=(C_word)C_a_i_list(&a,3,lf[21],C_SCHEME_END_OF_LIST,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_list(&a,3,lf[22],t4,t7));}}

/* symbol-append in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_fcall f_7373(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7373,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7381,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7385,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7387,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a7386 in symbol-append in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7387,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
/* match.scm: 2198 symbol->string */
t3=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* match.scm: 2199 number->string */
C_number_to_string(3,0,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k7383 in symbol-append in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[15]+1),t1);}

/* k7379 in symbol-append in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_7381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* match.scm: 2193 string->symbol */
t2=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##match#set-error-control in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_750,3,t0,t1,t2);}
t3=C_mutate((C_word*)lf[8]+1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##match#set-error in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_745,3,t0,t1,t2);}
t3=C_mutate((C_word*)lf[7]+1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##match#syntax-err in k735 in k732 in k729 in k726 in k723 in k720 in k717 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_739,4,t0,t1,t2,t3);}
/* match.scm: 660  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[5],t3,t2);}

/* every */
static void C_fcall f_692(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_692,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_705,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t3);
/* match.scm: 138  fn */
t7=t2;
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k703 in every */
static void C_ccall f_705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* match.scm: 138  every */
f_692(((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[697] = {
{"toplevelmatch.scm",(void*)C_match_toplevel},
{"f_10833match.scm",(void*)f_10833},
{"f_10914match.scm",(void*)f_10914},
{"f_10840match.scm",(void*)f_10840},
{"f_10849match.scm",(void*)f_10849},
{"f_10876match.scm",(void*)f_10876},
{"f_719match.scm",(void*)f_719},
{"f_10767match.scm",(void*)f_10767},
{"f_10807match.scm",(void*)f_10807},
{"f_10814match.scm",(void*)f_10814},
{"f_10774match.scm",(void*)f_10774},
{"f_10777match.scm",(void*)f_10777},
{"f_722match.scm",(void*)f_722},
{"f_10705match.scm",(void*)f_10705},
{"f_10741match.scm",(void*)f_10741},
{"f_10748match.scm",(void*)f_10748},
{"f_10712match.scm",(void*)f_10712},
{"f_10715match.scm",(void*)f_10715},
{"f_725match.scm",(void*)f_725},
{"f_9155match.scm",(void*)f_9155},
{"f_10685match.scm",(void*)f_10685},
{"f_10681match.scm",(void*)f_10681},
{"f_10677match.scm",(void*)f_10677},
{"f_10145match.scm",(void*)f_10145},
{"f_10560match.scm",(void*)f_10560},
{"f_10657match.scm",(void*)f_10657},
{"f_10653match.scm",(void*)f_10653},
{"f_10611match.scm",(void*)f_10611},
{"f_10634match.scm",(void*)f_10634},
{"f_10630match.scm",(void*)f_10630},
{"f_10573match.scm",(void*)f_10573},
{"f_10580match.scm",(void*)f_10580},
{"f_10584match.scm",(void*)f_10584},
{"f_10551match.scm",(void*)f_10551},
{"f_10547match.scm",(void*)f_10547},
{"f_10543match.scm",(void*)f_10543},
{"f_10539match.scm",(void*)f_10539},
{"f_10535match.scm",(void*)f_10535},
{"f_10527match.scm",(void*)f_10527},
{"f_10267match.scm",(void*)f_10267},
{"f_10398match.scm",(void*)f_10398},
{"f_10495match.scm",(void*)f_10495},
{"f_10491match.scm",(void*)f_10491},
{"f_10449match.scm",(void*)f_10449},
{"f_10472match.scm",(void*)f_10472},
{"f_10468match.scm",(void*)f_10468},
{"f_10411match.scm",(void*)f_10411},
{"f_10418match.scm",(void*)f_10418},
{"f_10422match.scm",(void*)f_10422},
{"f_10273match.scm",(void*)f_10273},
{"f_10309match.scm",(void*)f_10309},
{"f_10371match.scm",(void*)f_10371},
{"f_10367match.scm",(void*)f_10367},
{"f_10325match.scm",(void*)f_10325},
{"f_10348match.scm",(void*)f_10348},
{"f_10344match.scm",(void*)f_10344},
{"f_10280match.scm",(void*)f_10280},
{"f_10284match.scm",(void*)f_10284},
{"f_10288match.scm",(void*)f_10288},
{"f_10300match.scm",(void*)f_10300},
{"f_10157match.scm",(void*)f_10157},
{"f_10181match.scm",(void*)f_10181},
{"f_10243match.scm",(void*)f_10243},
{"f_10239match.scm",(void*)f_10239},
{"f_10197match.scm",(void*)f_10197},
{"f_10220match.scm",(void*)f_10220},
{"f_10216match.scm",(void*)f_10216},
{"f_10164match.scm",(void*)f_10164},
{"f_10168match.scm",(void*)f_10168},
{"f_10095match.scm",(void*)f_10095},
{"f_10118match.scm",(void*)f_10118},
{"f_10102match.scm",(void*)f_10102},
{"f_9439match.scm",(void*)f_9439},
{"f_10089match.scm",(void*)f_10089},
{"f_10085match.scm",(void*)f_10085},
{"f_10081match.scm",(void*)f_10081},
{"f_9543match.scm",(void*)f_9543},
{"f_9958match.scm",(void*)f_9958},
{"f_10055match.scm",(void*)f_10055},
{"f_10051match.scm",(void*)f_10051},
{"f_10009match.scm",(void*)f_10009},
{"f_10032match.scm",(void*)f_10032},
{"f_10028match.scm",(void*)f_10028},
{"f_9971match.scm",(void*)f_9971},
{"f_9978match.scm",(void*)f_9978},
{"f_9982match.scm",(void*)f_9982},
{"f_9949match.scm",(void*)f_9949},
{"f_9945match.scm",(void*)f_9945},
{"f_9941match.scm",(void*)f_9941},
{"f_9937match.scm",(void*)f_9937},
{"f_9933match.scm",(void*)f_9933},
{"f_9925match.scm",(void*)f_9925},
{"f_9665match.scm",(void*)f_9665},
{"f_9796match.scm",(void*)f_9796},
{"f_9893match.scm",(void*)f_9893},
{"f_9889match.scm",(void*)f_9889},
{"f_9847match.scm",(void*)f_9847},
{"f_9870match.scm",(void*)f_9870},
{"f_9866match.scm",(void*)f_9866},
{"f_9809match.scm",(void*)f_9809},
{"f_9816match.scm",(void*)f_9816},
{"f_9820match.scm",(void*)f_9820},
{"f_9671match.scm",(void*)f_9671},
{"f_9707match.scm",(void*)f_9707},
{"f_9769match.scm",(void*)f_9769},
{"f_9765match.scm",(void*)f_9765},
{"f_9723match.scm",(void*)f_9723},
{"f_9746match.scm",(void*)f_9746},
{"f_9742match.scm",(void*)f_9742},
{"f_9678match.scm",(void*)f_9678},
{"f_9682match.scm",(void*)f_9682},
{"f_9686match.scm",(void*)f_9686},
{"f_9698match.scm",(void*)f_9698},
{"f_9555match.scm",(void*)f_9555},
{"f_9579match.scm",(void*)f_9579},
{"f_9641match.scm",(void*)f_9641},
{"f_9637match.scm",(void*)f_9637},
{"f_9595match.scm",(void*)f_9595},
{"f_9618match.scm",(void*)f_9618},
{"f_9614match.scm",(void*)f_9614},
{"f_9562match.scm",(void*)f_9562},
{"f_9566match.scm",(void*)f_9566},
{"f_9445match.scm",(void*)f_9445},
{"f_9457match.scm",(void*)f_9457},
{"f_9519match.scm",(void*)f_9519},
{"f_9515match.scm",(void*)f_9515},
{"f_9473match.scm",(void*)f_9473},
{"f_9496match.scm",(void*)f_9496},
{"f_9492match.scm",(void*)f_9492},
{"f_9267match.scm",(void*)f_9267},
{"f_9276match.scm",(void*)f_9276},
{"f_9406match.scm",(void*)f_9406},
{"f_9402match.scm",(void*)f_9402},
{"f_9360match.scm",(void*)f_9360},
{"f_9383match.scm",(void*)f_9383},
{"f_9379match.scm",(void*)f_9379},
{"f_9289match.scm",(void*)f_9289},
{"f_9295match.scm",(void*)f_9295},
{"f_9298match.scm",(void*)f_9298},
{"f_9307match.scm",(void*)f_9307},
{"f_9208match.scm",(void*)f_9208},
{"f_9212match.scm",(void*)f_9212},
{"f_9215match.scm",(void*)f_9215},
{"f_9199match.scm",(void*)f_9199},
{"f_9166match.scm",(void*)f_9166},
{"f_9194match.scm",(void*)f_9194},
{"f_9170match.scm",(void*)f_9170},
{"f_9173match.scm",(void*)f_9173},
{"f_9180match.scm",(void*)f_9180},
{"f_9157match.scm",(void*)f_9157},
{"f_728match.scm",(void*)f_728},
{"f_8967match.scm",(void*)f_8967},
{"f_9142match.scm",(void*)f_9142},
{"f_9138match.scm",(void*)f_9138},
{"f_9134match.scm",(void*)f_9134},
{"f_9130match.scm",(void*)f_9130},
{"f_9024match.scm",(void*)f_9024},
{"f_9027match.scm",(void*)f_9027},
{"f_9030match.scm",(void*)f_9030},
{"f_9033match.scm",(void*)f_9033},
{"f_9042match.scm",(void*)f_9042},
{"f_8995match.scm",(void*)f_8995},
{"f_8969match.scm",(void*)f_8969},
{"f_731match.scm",(void*)f_731},
{"f_7600match.scm",(void*)f_7600},
{"f_8951match.scm",(void*)f_8951},
{"f_8947match.scm",(void*)f_8947},
{"f_8943match.scm",(void*)f_8943},
{"f_8411match.scm",(void*)f_8411},
{"f_8826match.scm",(void*)f_8826},
{"f_8923match.scm",(void*)f_8923},
{"f_8919match.scm",(void*)f_8919},
{"f_8877match.scm",(void*)f_8877},
{"f_8900match.scm",(void*)f_8900},
{"f_8896match.scm",(void*)f_8896},
{"f_8839match.scm",(void*)f_8839},
{"f_8846match.scm",(void*)f_8846},
{"f_8850match.scm",(void*)f_8850},
{"f_8817match.scm",(void*)f_8817},
{"f_8813match.scm",(void*)f_8813},
{"f_8809match.scm",(void*)f_8809},
{"f_8805match.scm",(void*)f_8805},
{"f_8801match.scm",(void*)f_8801},
{"f_8793match.scm",(void*)f_8793},
{"f_8533match.scm",(void*)f_8533},
{"f_8664match.scm",(void*)f_8664},
{"f_8761match.scm",(void*)f_8761},
{"f_8757match.scm",(void*)f_8757},
{"f_8715match.scm",(void*)f_8715},
{"f_8738match.scm",(void*)f_8738},
{"f_8734match.scm",(void*)f_8734},
{"f_8677match.scm",(void*)f_8677},
{"f_8684match.scm",(void*)f_8684},
{"f_8688match.scm",(void*)f_8688},
{"f_8539match.scm",(void*)f_8539},
{"f_8575match.scm",(void*)f_8575},
{"f_8637match.scm",(void*)f_8637},
{"f_8633match.scm",(void*)f_8633},
{"f_8591match.scm",(void*)f_8591},
{"f_8614match.scm",(void*)f_8614},
{"f_8610match.scm",(void*)f_8610},
{"f_8546match.scm",(void*)f_8546},
{"f_8550match.scm",(void*)f_8550},
{"f_8554match.scm",(void*)f_8554},
{"f_8566match.scm",(void*)f_8566},
{"f_8423match.scm",(void*)f_8423},
{"f_8447match.scm",(void*)f_8447},
{"f_8509match.scm",(void*)f_8509},
{"f_8505match.scm",(void*)f_8505},
{"f_8463match.scm",(void*)f_8463},
{"f_8486match.scm",(void*)f_8486},
{"f_8482match.scm",(void*)f_8482},
{"f_8430match.scm",(void*)f_8430},
{"f_8434match.scm",(void*)f_8434},
{"f_8361match.scm",(void*)f_8361},
{"f_8384match.scm",(void*)f_8384},
{"f_8368match.scm",(void*)f_8368},
{"f_7705match.scm",(void*)f_7705},
{"f_8355match.scm",(void*)f_8355},
{"f_8351match.scm",(void*)f_8351},
{"f_8347match.scm",(void*)f_8347},
{"f_7809match.scm",(void*)f_7809},
{"f_8224match.scm",(void*)f_8224},
{"f_8321match.scm",(void*)f_8321},
{"f_8317match.scm",(void*)f_8317},
{"f_8275match.scm",(void*)f_8275},
{"f_8298match.scm",(void*)f_8298},
{"f_8294match.scm",(void*)f_8294},
{"f_8237match.scm",(void*)f_8237},
{"f_8244match.scm",(void*)f_8244},
{"f_8248match.scm",(void*)f_8248},
{"f_8215match.scm",(void*)f_8215},
{"f_8211match.scm",(void*)f_8211},
{"f_8207match.scm",(void*)f_8207},
{"f_8203match.scm",(void*)f_8203},
{"f_8199match.scm",(void*)f_8199},
{"f_8191match.scm",(void*)f_8191},
{"f_7931match.scm",(void*)f_7931},
{"f_8062match.scm",(void*)f_8062},
{"f_8159match.scm",(void*)f_8159},
{"f_8155match.scm",(void*)f_8155},
{"f_8113match.scm",(void*)f_8113},
{"f_8136match.scm",(void*)f_8136},
{"f_8132match.scm",(void*)f_8132},
{"f_8075match.scm",(void*)f_8075},
{"f_8082match.scm",(void*)f_8082},
{"f_8086match.scm",(void*)f_8086},
{"f_7937match.scm",(void*)f_7937},
{"f_7973match.scm",(void*)f_7973},
{"f_8035match.scm",(void*)f_8035},
{"f_8031match.scm",(void*)f_8031},
{"f_7989match.scm",(void*)f_7989},
{"f_8012match.scm",(void*)f_8012},
{"f_8008match.scm",(void*)f_8008},
{"f_7944match.scm",(void*)f_7944},
{"f_7948match.scm",(void*)f_7948},
{"f_7952match.scm",(void*)f_7952},
{"f_7964match.scm",(void*)f_7964},
{"f_7821match.scm",(void*)f_7821},
{"f_7845match.scm",(void*)f_7845},
{"f_7907match.scm",(void*)f_7907},
{"f_7903match.scm",(void*)f_7903},
{"f_7861match.scm",(void*)f_7861},
{"f_7884match.scm",(void*)f_7884},
{"f_7880match.scm",(void*)f_7880},
{"f_7828match.scm",(void*)f_7828},
{"f_7832match.scm",(void*)f_7832},
{"f_7711match.scm",(void*)f_7711},
{"f_7723match.scm",(void*)f_7723},
{"f_7785match.scm",(void*)f_7785},
{"f_7781match.scm",(void*)f_7781},
{"f_7739match.scm",(void*)f_7739},
{"f_7762match.scm",(void*)f_7762},
{"f_7758match.scm",(void*)f_7758},
{"f_7664match.scm",(void*)f_7664},
{"f_7639match.scm",(void*)f_7639},
{"f_7659match.scm",(void*)f_7659},
{"f_7630match.scm",(void*)f_7630},
{"f_7605match.scm",(void*)f_7605},
{"f_734match.scm",(void*)f_734},
{"f_7497match.scm",(void*)f_7497},
{"f_7522match.scm",(void*)f_7522},
{"f_7558match.scm",(void*)f_7558},
{"f_7528match.scm",(void*)f_7528},
{"f_7502match.scm",(void*)f_7502},
{"f_737match.scm",(void*)f_737},
{"f_7495match.scm",(void*)f_7495},
{"f_7478match.scm",(void*)f_7478},
{"f_7462match.scm",(void*)f_7462},
{"f_7431match.scm",(void*)f_7431},
{"f_7449match.scm",(void*)f_7449},
{"f_7408match.scm",(void*)f_7408},
{"f_1127match.scm",(void*)f_1127},
{"f_1131match.scm",(void*)f_1131},
{"f_1134match.scm",(void*)f_1134},
{"f_1301match.scm",(void*)f_1301},
{"f_1137match.scm",(void*)f_1137},
{"f_1149match.scm",(void*)f_1149},
{"f_1155match.scm",(void*)f_1155},
{"f_1293match.scm",(void*)f_1293},
{"f_1158match.scm",(void*)f_1158},
{"f_1281match.scm",(void*)f_1281},
{"f_1161match.scm",(void*)f_1161},
{"f_1164match.scm",(void*)f_1164},
{"f_1275match.scm",(void*)f_1275},
{"f_1175match.scm",(void*)f_1175},
{"f_1245match.scm",(void*)f_1245},
{"f_1235match.scm",(void*)f_1235},
{"f_1231match.scm",(void*)f_1231},
{"f_1215match.scm",(void*)f_1215},
{"f_1183match.scm",(void*)f_1183},
{"f_1171match.scm",(void*)f_1171},
{"f_971match.scm",(void*)f_971},
{"f_975match.scm",(void*)f_975},
{"f_978match.scm",(void*)f_978},
{"f_1125match.scm",(void*)f_1125},
{"f_981match.scm",(void*)f_981},
{"f_993match.scm",(void*)f_993},
{"f_999match.scm",(void*)f_999},
{"f_1117match.scm",(void*)f_1117},
{"f_1002match.scm",(void*)f_1002},
{"f_1105match.scm",(void*)f_1105},
{"f_1005match.scm",(void*)f_1005},
{"f_1008match.scm",(void*)f_1008},
{"f_1075match.scm",(void*)f_1075},
{"f_1027match.scm",(void*)f_1027},
{"f_1069match.scm",(void*)f_1069},
{"f_1067match.scm",(void*)f_1067},
{"f_1063match.scm",(void*)f_1063},
{"f_1047match.scm",(void*)f_1047},
{"f_1023match.scm",(void*)f_1023},
{"f_759match.scm",(void*)f_759},
{"f_763match.scm",(void*)f_763},
{"f_766match.scm",(void*)f_766},
{"f_827match.scm",(void*)f_827},
{"f_965match.scm",(void*)f_965},
{"f_831match.scm",(void*)f_831},
{"f_843match.scm",(void*)f_843},
{"f_953match.scm",(void*)f_953},
{"f_949match.scm",(void*)f_949},
{"f_945match.scm",(void*)f_945},
{"f_941match.scm",(void*)f_941},
{"f_846match.scm",(void*)f_846},
{"f_874match.scm",(void*)f_874},
{"f_863match.scm",(void*)f_863},
{"f_772match.scm",(void*)f_772},
{"f_825match.scm",(void*)f_825},
{"f_775match.scm",(void*)f_775},
{"f_778match.scm",(void*)f_778},
{"f_1397match.scm",(void*)f_1397},
{"f_1434match.scm",(void*)f_1434},
{"f_1437match.scm",(void*)f_1437},
{"f_1446match.scm",(void*)f_1446},
{"f_1421match.scm",(void*)f_1421},
{"f_1409match.scm",(void*)f_1409},
{"f_1475match.scm",(void*)f_1475},
{"f_1481match.scm",(void*)f_1481},
{"f_1505match.scm",(void*)f_1505},
{"f_2530match.scm",(void*)f_2530},
{"f_2550match.scm",(void*)f_2550},
{"f_2554match.scm",(void*)f_2554},
{"f_2268match.scm",(void*)f_2268},
{"f_2486match.scm",(void*)f_2486},
{"f_2489match.scm",(void*)f_2489},
{"f_2499match.scm",(void*)f_2499},
{"f_2514match.scm",(void*)f_2514},
{"f_2496match.scm",(void*)f_2496},
{"f_2469match.scm",(void*)f_2469},
{"f_2465match.scm",(void*)f_2465},
{"f_2461match.scm",(void*)f_2461},
{"f_2352match.scm",(void*)f_2352},
{"f_2424match.scm",(void*)f_2424},
{"f_2391match.scm",(void*)f_2391},
{"f_2404match.scm",(void*)f_2404},
{"f_2367match.scm",(void*)f_2367},
{"f_2377match.scm",(void*)f_2377},
{"f_2381match.scm",(void*)f_2381},
{"f_2361match.scm",(void*)f_2361},
{"f_2315match.scm",(void*)f_2315},
{"f_2270match.scm",(void*)f_2270},
{"f_2278match.scm",(void*)f_2278},
{"f_2282match.scm",(void*)f_2282},
{"f_1538match.scm",(void*)f_1538},
{"f_1570match.scm",(void*)f_1570},
{"f_2214match.scm",(void*)f_2214},
{"f_2217match.scm",(void*)f_2217},
{"f_2227match.scm",(void*)f_2227},
{"f_2242match.scm",(void*)f_2242},
{"f_2224match.scm",(void*)f_2224},
{"f_2142match.scm",(void*)f_2142},
{"f_2109match.scm",(void*)f_2109},
{"f_2122match.scm",(void*)f_2122},
{"f_2054match.scm",(void*)f_2054},
{"f_2034match.scm",(void*)f_2034},
{"f_2007match.scm",(void*)f_2007},
{"f_1987match.scm",(void*)f_1987},
{"f_1923match.scm",(void*)f_1923},
{"f_1940match.scm",(void*)f_1940},
{"f_1876match.scm",(void*)f_1876},
{"f_1886match.scm",(void*)f_1886},
{"f_1829match.scm",(void*)f_1829},
{"f_1839match.scm",(void*)f_1839},
{"f_1782match.scm",(void*)f_1782},
{"f_1792match.scm",(void*)f_1792},
{"f_1722match.scm",(void*)f_1722},
{"f_1735match.scm",(void*)f_1735},
{"f_1668match.scm",(void*)f_1668},
{"f_1685match.scm",(void*)f_1685},
{"f_1631match.scm",(void*)f_1631},
{"f_1588match.scm",(void*)f_1588},
{"f_1540match.scm",(void*)f_1540},
{"f_1548match.scm",(void*)f_1548},
{"f_1552match.scm",(void*)f_1552},
{"f_1508match.scm",(void*)f_1508},
{"f_1303match.scm",(void*)f_1303},
{"f_1327match.scm",(void*)f_1327},
{"f_2570match.scm",(void*)f_2570},
{"f_3456match.scm",(void*)f_3456},
{"f_3464match.scm",(void*)f_3464},
{"f_3364match.scm",(void*)f_3364},
{"f_3383match.scm",(void*)f_3383},
{"f_3393match.scm",(void*)f_3393},
{"f_3271match.scm",(void*)f_3271},
{"f_3335match.scm",(void*)f_3335},
{"f_3289match.scm",(void*)f_3289},
{"f_3312match.scm",(void*)f_3312},
{"f_3318match.scm",(void*)f_3318},
{"f_3273match.scm",(void*)f_3273},
{"f_2574match.scm",(void*)f_2574},
{"f_2612match.scm",(void*)f_2612},
{"f_2621match.scm",(void*)f_2621},
{"f_2713match.scm",(void*)f_2713},
{"f_2790match.scm",(void*)f_2790},
{"f_2813match.scm",(void*)f_2813},
{"f_2902match.scm",(void*)f_2902},
{"f_2967match.scm",(void*)f_2967},
{"f_3015match.scm",(void*)f_3015},
{"f_3046match.scm",(void*)f_3046},
{"f_3076match.scm",(void*)f_3076},
{"f_3146match.scm",(void*)f_3146},
{"f_3148match.scm",(void*)f_3148},
{"f_3156match.scm",(void*)f_3156},
{"f_3115match.scm",(void*)f_3115},
{"f_3125match.scm",(void*)f_3125},
{"f_3024match.scm",(void*)f_3024},
{"f_2976match.scm",(void*)f_2976},
{"f_2980match.scm",(void*)f_2980},
{"f_2995match.scm",(void*)f_2995},
{"f_2999match.scm",(void*)f_2999},
{"f_3005match.scm",(void*)f_3005},
{"f_3003match.scm",(void*)f_3003},
{"f_2932match.scm",(void*)f_2932},
{"f_2953match.scm",(void*)f_2953},
{"f_2936match.scm",(void*)f_2936},
{"f_2822match.scm",(void*)f_2822},
{"f_2846match.scm",(void*)f_2846},
{"f_2865match.scm",(void*)f_2865},
{"f_2896match.scm",(void*)f_2896},
{"f_2869match.scm",(void*)f_2869},
{"f_2878match.scm",(void*)f_2878},
{"f_2832match.scm",(void*)f_2832},
{"f_2799match.scm",(void*)f_2799},
{"f_2722match.scm",(void*)f_2722},
{"f_2757match.scm",(void*)f_2757},
{"f_2725match.scm",(void*)f_2725},
{"f_2659match.scm",(void*)f_2659},
{"f_2662match.scm",(void*)f_2662},
{"f_2593match.scm",(void*)f_2593},
{"f_3403match.scm",(void*)f_3403},
{"f_3421match.scm",(void*)f_3421},
{"f_3427match.scm",(void*)f_3427},
{"f_3439match.scm",(void*)f_3439},
{"f_3466match.scm",(void*)f_3466},
{"f_3726match.scm",(void*)f_3726},
{"f_3755match.scm",(void*)f_3755},
{"f_3475match.scm",(void*)f_3475},
{"f_3489match.scm",(void*)f_3489},
{"f_3493match.scm",(void*)f_3493},
{"f_3758match.scm",(void*)f_3758},
{"f_3780match.scm",(void*)f_3780},
{"f_3515match.scm",(void*)f_3515},
{"f_3529match.scm",(void*)f_3529},
{"f_3533match.scm",(void*)f_3533},
{"f_3791match.scm",(void*)f_3791},
{"f_3746match.scm",(void*)f_3746},
{"f_3653match.scm",(void*)f_3653},
{"f_3631match.scm",(void*)f_3631},
{"f_3549match.scm",(void*)f_3549},
{"f_3850match.scm",(void*)f_3850},
{"f_3975match.scm",(void*)f_3975},
{"f_3977match.scm",(void*)f_3977},
{"f_4088match.scm",(void*)f_4088},
{"f_4101match.scm",(void*)f_4101},
{"f_4117match.scm",(void*)f_4117},
{"f_4138match.scm",(void*)f_4138},
{"f_4180match.scm",(void*)f_4180},
{"f_4223match.scm",(void*)f_4223},
{"f_4236match.scm",(void*)f_4236},
{"f_4298match.scm",(void*)f_4298},
{"f_4323match.scm",(void*)f_4323},
{"f_4348match.scm",(void*)f_4348},
{"f_4687match.scm",(void*)f_4687},
{"f_4977match.scm",(void*)f_4977},
{"f_4980match.scm",(void*)f_4980},
{"f_4925match.scm",(void*)f_4925},
{"f_4939match.scm",(void*)f_4939},
{"f_4941match.scm",(void*)f_4941},
{"f_4966match.scm",(void*)f_4966},
{"f_4937match.scm",(void*)f_4937},
{"f_4693match.scm",(void*)f_4693},
{"f_4708match.scm",(void*)f_4708},
{"f_4720match.scm",(void*)f_4720},
{"f_4729match.scm",(void*)f_4729},
{"f_4731match.scm",(void*)f_4731},
{"f_4753match.scm",(void*)f_4753},
{"f_4841match.scm",(void*)f_4841},
{"f_4859match.scm",(void*)f_4859},
{"f_4867match.scm",(void*)f_4867},
{"f_4857match.scm",(void*)f_4857},
{"f_4778match.scm",(void*)f_4778},
{"f_4831match.scm",(void*)f_4831},
{"f_4782match.scm",(void*)f_4782},
{"f_4811match.scm",(void*)f_4811},
{"f_4809match.scm",(void*)f_4809},
{"f_4801match.scm",(void*)f_4801},
{"f_4727match.scm",(void*)f_4727},
{"f_4724match.scm",(void*)f_4724},
{"f_4655match.scm",(void*)f_4655},
{"f_4667match.scm",(void*)f_4667},
{"f_4669match.scm",(void*)f_4669},
{"f_4681match.scm",(void*)f_4681},
{"f_4357match.scm",(void*)f_4357},
{"f_4361match.scm",(void*)f_4361},
{"f_4362match.scm",(void*)f_4362},
{"f_4471match.scm",(void*)f_4471},
{"f_4555match.scm",(void*)f_4555},
{"f_4573match.scm",(void*)f_4573},
{"f_4581match.scm",(void*)f_4581},
{"f_4571match.scm",(void*)f_4571},
{"f_4490match.scm",(void*)f_4490},
{"f_4541match.scm",(void*)f_4541},
{"f_4539match.scm",(void*)f_4539},
{"f_4535match.scm",(void*)f_4535},
{"f_4494match.scm",(void*)f_4494},
{"f_4523match.scm",(void*)f_4523},
{"f_4521match.scm",(void*)f_4521},
{"f_4513match.scm",(void*)f_4513},
{"f_4464match.scm",(void*)f_4464},
{"f_4461match.scm",(void*)f_4461},
{"f_4384match.scm",(void*)f_4384},
{"f_4405match.scm",(void*)f_4405},
{"f_4387match.scm",(void*)f_4387},
{"f_4398match.scm",(void*)f_4398},
{"f_4402match.scm",(void*)f_4402},
{"f_4342match.scm",(void*)f_4342},
{"f_4317match.scm",(void*)f_4317},
{"f_4292match.scm",(void*)f_4292},
{"f_4257match.scm",(void*)f_4257},
{"f_4259match.scm",(void*)f_4259},
{"f_4284match.scm",(void*)f_4284},
{"f_4255match.scm",(void*)f_4255},
{"f_4189match.scm",(void*)f_4189},
{"f_4209match.scm",(void*)f_4209},
{"f_4147match.scm",(void*)f_4147},
{"f_4166match.scm",(void*)f_4166},
{"f_3879match.scm",(void*)f_3879},
{"f_3948match.scm",(void*)f_3948},
{"f_3941match.scm",(void*)f_3941},
{"f_3933match.scm",(void*)f_3933},
{"f_3870match.scm",(void*)f_3870},
{"f_3861match.scm",(void*)f_3861},
{"f_1329match.scm",(void*)f_1329},
{"f_1345match.scm",(void*)f_1345},
{"f_1387match.scm",(void*)f_1387},
{"f_1383match.scm",(void*)f_1383},
{"f_1372match.scm",(void*)f_1372},
{"f_1379match.scm",(void*)f_1379},
{"f_5123match.scm",(void*)f_5123},
{"f_5130match.scm",(void*)f_5130},
{"f_5139match.scm",(void*)f_5139},
{"f_5261match.scm",(void*)f_5261},
{"f_5148match.scm",(void*)f_5148},
{"f_5154match.scm",(void*)f_5154},
{"f_5183match.scm",(void*)f_5183},
{"f_5157match.scm",(void*)f_5157},
{"f_5175match.scm",(void*)f_5175},
{"f_5160match.scm",(void*)f_5160},
{"f_5305match.scm",(void*)f_5305},
{"f_5324match.scm",(void*)f_5324},
{"f_5330match.scm",(void*)f_5330},
{"f_6129match.scm",(void*)f_6129},
{"f_6125match.scm",(void*)f_6125},
{"f_6121match.scm",(void*)f_6121},
{"f_6117match.scm",(void*)f_6117},
{"f_6109match.scm",(void*)f_6109},
{"f_6105match.scm",(void*)f_6105},
{"f_6097match.scm",(void*)f_6097},
{"f_6093match.scm",(void*)f_6093},
{"f_6089match.scm",(void*)f_6089},
{"f_6085match.scm",(void*)f_6085},
{"f_6081match.scm",(void*)f_6081},
{"f_6077match.scm",(void*)f_6077},
{"f_6073match.scm",(void*)f_6073},
{"f_6069match.scm",(void*)f_6069},
{"f_6065match.scm",(void*)f_6065},
{"f_6061match.scm",(void*)f_6061},
{"f_6053match.scm",(void*)f_6053},
{"f_6049match.scm",(void*)f_6049},
{"f_6041match.scm",(void*)f_6041},
{"f_6037match.scm",(void*)f_6037},
{"f_6033match.scm",(void*)f_6033},
{"f_6029match.scm",(void*)f_6029},
{"f_6025match.scm",(void*)f_6025},
{"f_6021match.scm",(void*)f_6021},
{"f_6017match.scm",(void*)f_6017},
{"f_6013match.scm",(void*)f_6013},
{"f_6009match.scm",(void*)f_6009},
{"f_6005match.scm",(void*)f_6005},
{"f_6001match.scm",(void*)f_6001},
{"f_5997match.scm",(void*)f_5997},
{"f_5993match.scm",(void*)f_5993},
{"f_5989match.scm",(void*)f_5989},
{"f_5985match.scm",(void*)f_5985},
{"f_5977match.scm",(void*)f_5977},
{"f_5973match.scm",(void*)f_5973},
{"f_5969match.scm",(void*)f_5969},
{"f_5965match.scm",(void*)f_5965},
{"f_5961match.scm",(void*)f_5961},
{"f_5957match.scm",(void*)f_5957},
{"f_5953match.scm",(void*)f_5953},
{"f_5949match.scm",(void*)f_5949},
{"f_5945match.scm",(void*)f_5945},
{"f_5941match.scm",(void*)f_5941},
{"f_5937match.scm",(void*)f_5937},
{"f_5929match.scm",(void*)f_5929},
{"f_5925match.scm",(void*)f_5925},
{"f_5917match.scm",(void*)f_5917},
{"f_5913match.scm",(void*)f_5913},
{"f_5909match.scm",(void*)f_5909},
{"f_5905match.scm",(void*)f_5905},
{"f_5901match.scm",(void*)f_5901},
{"f_5897match.scm",(void*)f_5897},
{"f_5893match.scm",(void*)f_5893},
{"f_5881match.scm",(void*)f_5881},
{"f_5877match.scm",(void*)f_5877},
{"f_5873match.scm",(void*)f_5873},
{"f_5869match.scm",(void*)f_5869},
{"f_5388match.scm",(void*)f_5388},
{"f_5452match.scm",(void*)f_5452},
{"f_5448match.scm",(void*)f_5448},
{"f_5444match.scm",(void*)f_5444},
{"f_5440match.scm",(void*)f_5440},
{"f_5397match.scm",(void*)f_5397},
{"f_5420match.scm",(void*)f_5420},
{"f_6199match.scm",(void*)f_6199},
{"f_6203match.scm",(void*)f_6203},
{"f_6206match.scm",(void*)f_6206},
{"f_6211match.scm",(void*)f_6211},
{"f_6278match.scm",(void*)f_6278},
{"f_6281match.scm",(void*)f_6281},
{"f_6242match.scm",(void*)f_6242},
{"f_6251match.scm",(void*)f_6251},
{"f_6330match.scm",(void*)f_6330},
{"f_6340match.scm",(void*)f_6340},
{"f_6355match.scm",(void*)f_6355},
{"f_6547match.scm",(void*)f_6547},
{"f_6560match.scm",(void*)f_6560},
{"f_6481match.scm",(void*)f_6481},
{"f_6494match.scm",(void*)f_6494},
{"f_6363match.scm",(void*)f_6363},
{"f_6376match.scm",(void*)f_6376},
{"f_6407match.scm",(void*)f_6407},
{"f_6388match.scm",(void*)f_6388},
{"f_6640match.scm",(void*)f_6640},
{"f_6680match.scm",(void*)f_6680},
{"f_6726match.scm",(void*)f_6726},
{"f_6736match.scm",(void*)f_6736},
{"f_6740match.scm",(void*)f_6740},
{"f_6769match.scm",(void*)f_6769},
{"f_6773match.scm",(void*)f_6773},
{"f_6803match.scm",(void*)f_6803},
{"f_7058match.scm",(void*)f_7058},
{"f_6997match.scm",(void*)f_6997},
{"f_7023match.scm",(void*)f_7023},
{"f_6805match.scm",(void*)f_6805},
{"f_7108match.scm",(void*)f_7108},
{"f_7277match.scm",(void*)f_7277},
{"f_7373match.scm",(void*)f_7373},
{"f_7387match.scm",(void*)f_7387},
{"f_7385match.scm",(void*)f_7385},
{"f_7381match.scm",(void*)f_7381},
{"f_750match.scm",(void*)f_750},
{"f_745match.scm",(void*)f_745},
{"f_739match.scm",(void*)f_739},
{"f_692match.scm",(void*)f_692},
{"f_705match.scm",(void*)f_705},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
