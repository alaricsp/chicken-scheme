/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:22
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: csc.scm -optimize-level 2 -include-path . -include-path . -no-lambda-info -output-file csc.c
   used units: library eval data_structures ports extras srfi_69 data_structures ports srfi_1 srfi_13 utils files extras
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif

#ifndef C_TARGET_CFLAGS
# define C_TARGET_CFLAGS  C_INSTALL_CFLAGS
#endif

#ifndef C_TARGET_LDFLAGS
# define C_TARGET_LDFLAGS  C_INSTALL_LDFLAGS
#endif

#ifndef C_TARGET_BIN_HOME
# define C_TARGET_BIN_HOME  C_INSTALL_BIN_HOME
#endif

#ifndef C_TARGET_LIB_HOME
# define C_TARGET_LIB_HOME  C_INSTALL_LIB_HOME
#endif

#ifndef C_TARGET_STATIC_LIB_HOME
# define C_TARGET_STATIC_LIB_HOME  C_INSTALL_STATIC_LIB_HOME
#endif

#ifndef C_TARGET_INCLUDE_HOME
# define C_TARGET_INCLUDE_HOME  C_INSTALL_INCLUDE_HOME
#endif

#ifndef C_TARGET_SHARE_HOME
# define C_TARGET_SHARE_HOME  C_INSTALL_SHARE_HOME
#endif

#ifndef C_TARGET_RUN_LIB_HOME
# define C_TARGET_RUN_LIB_HOME    C_TARGET_LIB_HOME
#endif

#ifndef C_CHICKEN_PROGRAM
# define C_CHICKEN_PROGRAM     "chicken"
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[370];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_953)
static void C_ccall f_953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_977)
static void C_ccall f_977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_980)
static void C_ccall f_980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_ccall f_3853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1005)
static void C_fcall f_1005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_ccall f_1079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_fcall f_1169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_fcall f_1177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1194)
static void C_fcall f_1194(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_fcall f_1207(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_ccall f_3513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_fcall f_1305(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_fcall f_1972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_fcall f_2213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_fcall f_2216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2219)
static void C_fcall f_2219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_fcall f_2270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_fcall f_2279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_fcall f_2505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_fcall f_2357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2347)
static void C_ccall f_2347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_ccall f_2210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1871)
static void C_ccall f_1871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_fcall f_1863(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_fcall f_1708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_fcall f_1408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_fcall f_1411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_fcall f_2881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_fcall f_2822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_fcall f_2837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_fcall f_3019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_fcall f_1276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_fcall f_1237(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_fcall f_1230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_ccall f_3503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_fcall f_3463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_fcall f_3379(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3409)
static void C_fcall f_3409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_fcall f_3277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3225)
static void C_fcall f_3225(C_word t0) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3128)
static void C_fcall f_3128(C_word t0) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_fcall f_3138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_fcall f_3143(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_fcall f_3184(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_fcall f_3188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_fcall f_2976(C_word t0) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1049)
static void C_fcall f_1049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1056)
static void C_ccall f_1056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_fcall f_1036(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1007)
static void C_fcall f_1007(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1005)
static void C_fcall trf_1005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1005(t0,t1);}

C_noret_decl(trf_1169)
static void C_fcall trf_1169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1169(t0,t1);}

C_noret_decl(trf_1177)
static void C_fcall trf_1177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1177(t0,t1);}

C_noret_decl(trf_1194)
static void C_fcall trf_1194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1194(t0,t1);}

C_noret_decl(trf_1207)
static void C_fcall trf_1207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1207(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1207(t0,t1);}

C_noret_decl(trf_1305)
static void C_fcall trf_1305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1305(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1305(t0,t1,t2);}

C_noret_decl(trf_1972)
static void C_fcall trf_1972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1972(t0,t1);}

C_noret_decl(trf_2213)
static void C_fcall trf_2213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2213(t0,t1);}

C_noret_decl(trf_2216)
static void C_fcall trf_2216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2216(t0,t1);}

C_noret_decl(trf_2219)
static void C_fcall trf_2219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2219(t0,t1);}

C_noret_decl(trf_2270)
static void C_fcall trf_2270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2270(t0,t1);}

C_noret_decl(trf_2279)
static void C_fcall trf_2279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2279(t0,t1);}

C_noret_decl(trf_2505)
static void C_fcall trf_2505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2505(t0,t1);}

C_noret_decl(trf_2357)
static void C_fcall trf_2357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2357(t0,t1);}

C_noret_decl(trf_1863)
static void C_fcall trf_1863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1863(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1863(t0,t1);}

C_noret_decl(trf_1708)
static void C_fcall trf_1708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1708(t0,t1);}

C_noret_decl(trf_1408)
static void C_fcall trf_1408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1408(t0,t1);}

C_noret_decl(trf_1411)
static void C_fcall trf_1411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1411(t0,t1);}

C_noret_decl(trf_2881)
static void C_fcall trf_2881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2881(t0,t1);}

C_noret_decl(trf_2822)
static void C_fcall trf_2822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2822(t0,t1);}

C_noret_decl(trf_2837)
static void C_fcall trf_2837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2837(t0,t1);}

C_noret_decl(trf_3019)
static void C_fcall trf_3019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3019(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3019(t0,t1);}

C_noret_decl(trf_1276)
static void C_fcall trf_1276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1276(t0,t1);}

C_noret_decl(trf_1237)
static void C_fcall trf_1237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1237(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1237(t0,t1,t2,t3);}

C_noret_decl(trf_1230)
static void C_fcall trf_1230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1230(t0,t1);}

C_noret_decl(trf_3463)
static void C_fcall trf_3463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3463(t0,t1);}

C_noret_decl(trf_3379)
static void C_fcall trf_3379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3379(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3379(t0,t1,t2);}

C_noret_decl(trf_3409)
static void C_fcall trf_3409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3409(t0,t1);}

C_noret_decl(trf_3277)
static void C_fcall trf_3277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3277(t0,t1);}

C_noret_decl(trf_3225)
static void C_fcall trf_3225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3225(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3225(t0);}

C_noret_decl(trf_3128)
static void C_fcall trf_3128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3128(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3128(t0);}

C_noret_decl(trf_3138)
static void C_fcall trf_3138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3138(t0,t1);}

C_noret_decl(trf_3143)
static void C_fcall trf_3143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3143(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3143(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3184)
static void C_fcall trf_3184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3184(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3184(t0,t1);}

C_noret_decl(trf_3188)
static void C_fcall trf_3188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3188(t0,t1);}

C_noret_decl(trf_2976)
static void C_fcall trf_2976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2976(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2976(t0);}

C_noret_decl(trf_1049)
static void C_fcall trf_1049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1049(t0,t1);}

C_noret_decl(trf_1036)
static void C_fcall trf_1036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1036(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1036(t0,t1,t2,t3);}

C_noret_decl(trf_1007)
static void C_fcall trf_1007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1007(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1007(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2520)){
C_save(t1);
C_rereclaim2(2520*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,370);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[10]=C_h_intern(&lf[10],4,"exit");
lf[11]=C_h_intern(&lf[11],7,"fprintf");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011csc: ~\077~%");
lf[13]=C_h_intern(&lf[13],18,"current-error-port");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[22]=C_h_intern(&lf[22],13,"string-append");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[25]=C_h_intern(&lf[25],10,"string-any");
lf[26]=C_h_intern(&lf[26],16,"char-whitespace\077");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[49]=C_h_intern(&lf[49],26,"\003sysload-dynamic-extension");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[51]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[107]=C_h_intern(&lf[107],18,"string-intersperse");
lf[108]=C_h_intern(&lf[108],7,"\003sysmap");
lf[110]=C_h_intern(&lf[110],6,"append");
lf[112]=C_h_intern(&lf[112],7,"reverse");
lf[113]=C_h_intern(&lf[113],6,"static");
lf[114]=C_h_intern(&lf[114],14,"static-options");
lf[115]=C_h_intern(&lf[115],21,"extension-information");
lf[116]=C_h_intern(&lf[116],15,"repository-path");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[121]=C_h_intern(&lf[121],9,"\003syserror");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[126]=C_h_intern(&lf[126],17,"string-translate*");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[128]=C_h_intern(&lf[128],16,"\003syslist->string");
lf[129]=C_h_intern(&lf[129],5,"cons*");
lf[130]=C_h_intern(&lf[130],16,"\003sysstring->list");
lf[131]=C_h_intern(&lf[131],3,"any");
lf[134]=C_h_intern(&lf[134],6,"printf");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\0006*** Shell command terminated with exit status ~S: ~A~%");
lf[136]=C_h_intern(&lf[136],6,"system");
lf[137]=C_h_intern(&lf[137],5,"print");
lf[139]=C_h_intern(&lf[139],11,"delete-file");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[141]=C_h_intern(&lf[141],25,"\003sysimplicit-exit-handler");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[150]=C_h_intern(&lf[150],12,"\003sysfor-each");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[156]=C_h_intern(&lf[156],17,"\003syspeek-c-string");
lf[157]=C_h_intern(&lf[157],7,"sprintf");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\014mv ~A ~A.old");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000TWarning: output file will overwrite source file `~A\047 - renaming source to `"
"~A.old\047~%");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[161]=C_h_intern(&lf[161],26,"pathname-replace-extension");
lf[162]=C_h_intern(&lf[162],4,"last");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[164]=C_h_intern(&lf[164],12,"post-process");
lf[165]=C_h_intern(&lf[165],9,"c-options");
lf[166]=C_h_intern(&lf[166],12,"link-options");
lf[167]=C_h_intern(&lf[167],5,"error");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000!invalid entry in csc control file");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000!invalid entry in csc control file");
lf[170]=C_h_intern(&lf[170],9,"read-file");
lf[171]=C_h_intern(&lf[171],9,"read-line");
lf[172]=C_h_intern(&lf[172],20,"with-input-from-file");
lf[173]=C_h_intern(&lf[173],12,"file-exists\077");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[175]=C_h_intern(&lf[175],4,"conc");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\006-uses ");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\005#%eof");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[185]=C_h_intern(&lf[185],7,"newline");
lf[186]=C_h_intern(&lf[186],6,"print*");
lf[187]=C_h_intern(&lf[187],5,"-help");
lf[188]=C_h_intern(&lf[188],6,"--help");
lf[189]=C_h_intern(&lf[189],7,"display");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\036\210Usage: csc FILENAME | OPTION ...\012\012  `csc\047 is a driver program for the CHICK"
"EN compiler. Any Scheme, C or object\012  files and all libraries given on the comm"
"and line are translated, compiled or\012  linked as needed.\012\012  General options:\012\012  "
"  -h  -help                   display this text and exit\012    -v                 "
"         show intermediate compilation stages\012    -v2  -verbose               di"
"splay information about translation progress\012    -v3                         dis"
"play information about all compilation stages\012    -V  -version                di"
"splay Scheme compiler version and exit\012    -release                    display r"
"elease number and exit\012\012  File and pathname options:\012\012    -o -output-file FILENA"
"ME    specifies target executable name\012    -I -include-path PATHNAME   specifies"
" alternative path for included files\012    -to-stdout                  write compi"
"ler to stdout (implies -t)\012    -s -shared -dynamic         generate dynamically "
"loadable shared object file\012\012  Language options:\012\012    -D  -DSYMBOL  -feature SYM"
"BOL \012                                register feature identifier\012    -c++       "
"                 Compile via a C++ source file (.cpp) \012    -objc                "
"       Compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    "
"-i -case-insensitive        don\047t preserve case of read symbols    \012    -K -keyw"
"ord-style STYLE     allow alternative keyword syntax (prefix, suffix or none)\012  "
"  -compile-syntax             macros are made available at run-time\012    -j -emit"
"-import-library MODULE \012                                write compile-time modul"
"e information into separate file\012\012  Translation options:\012\012    -x  -explicit-use "
"          do not use units `library\047 and `eval\047 by default\012    -P  -check-syntax"
"           stop compilation after macro-expansion\012    -A  -analyze-only         "
"  stop compilation after first analysis pass\012\012  Debugging options:\012\012    -w  -no-"
"warnings            disable warnings\012    -disable-warning CLASS      disable spe"
"cific class of warnings\012    -d0 -d1 -d2 -debug-level NUMBER\012                    "
"            set level of available debugging information\012    -no-trace          "
"         disable rudimentary debugging information\012    -profile                 "
"   executable emits profiling information \012    -accumulate-profile         execu"
"table emits profiling information in append mode\012    -profile-name FILENAME     "
" name of the generated profile information file\012    -emit-debug-info            "
"emit additional debug-information\012\012  Optimization options:\012\012    -O -O1 -O2 -O3 -"
"optimize-level NUMBER\012\011\011\011        enable certain sets of optimization options\012   "
" -optimize-leaf-routines     enable leaf routine optimization\012    -N  -no-usual-"
"integrations  standard procedures may be redefined\012    -u  -unsafe              "
"   disable safety checks\012    -b  -block                  enable block-compilatio"
"n\012    -disable-interrupts         disable interrupts in compiled code\012    -f  -f"
"ixnum-arithmetic      assume all numbers are fixnums\012    -Ob  -benchmark-mode   "
"     equivalent to \047-block -optimize-level 3 \012                                 -"
"debug-level 0 -fixnum-arithmetic -lambda-lift \012                                 "
"-disable-interrupts\047\012    -lambda-lift                perform lambda-lifting\012    "
"-unsafe-libraries           link with unsafe runtime system\012    -disable-stack-o"
"verflow-checks  disables detection of stack-overflows\012    -inline               "
"      enable inlining\012    -inline-limit               set inlining threshold\012   "
" -disable-compiler-macros    disable expansion of compiler macros\012\012  Configurati"
"on options:\012\012    -unit NAME                  compile file as a library unit\012    "
"-uses NAME                  declare library unit as used.\012    -heap-size NUMBER "
"          specifies heap-size of compiled executable\012    -heap-initial-size NUMB"
"ER   specifies heap-size at startup time\012    -heap-growth PERCENTAGE     specifi"
"es growth-rate of expanding heap\012    -heap-shrinkage PERCENTAGE  specifies shrin"
"k-rate of contracting heap\012    -nursery NUMBER  -stack-size NUMBER\012\011\011           "
"     specifies nursery size of compiled executable\012    -X -extend FILENAME      "
"   load file before compilation commences\012    -prelude EXPRESSION         add ex"
"pression to beginning of source file\012    -postlude EXPRESSION        add express"
"ion to end of source file\012    -prologue FILENAME          include file before ma"
"in source file\012    -epilogue FILENAME          include file after main source fi"
"le\012\012    -e  -embedded               compile as embedded (don\047t generate `main()\047"
")\012    -W  -windows                compile as Windows GUI application (MSVC only)"
"\012    -R  -require-extension NAME require extension and import in compiled code\012 "
"   -E  -extension              compile as extension (dynamic or static)\012    -dll"
" -library               compile multiple units into a dynamic library\012\012  Options"
" to other passes:\012\012    -C OPTION                   pass option to C compiler\012   "
" -L OPTION                   pass option to linker\012    -I<DIR>                  "
"   pass \042-I<DIR>\042 to C compiler (add include path)\012    -L<DIR>                  "
"   pass \042-L<DIR>\042 to linker (add library path)\012    -k                          k"
"eep intermediate files\012    -c                          stop after compilation to"
" object files\012    -t                          stop after translation to C\012    -c"
"c COMPILER                select other C compiler than the default one\012    -cxx "
"COMPILER               select other C++ compiler than the default one\012    -ld CO"
"MPILER                select other linker than the default one\012    -lLIBNAME    "
"               link with given library (`libLIBNAME\047 on UNIX,\012                  "
"               `LIBNAME.lib\047 on Windows)                                \012    -st"
"atic-libs                link with static CHICKEN libraries\012    -static         "
"            generate completely statically linked executable\012    -static-extensi"
"ons          link with static extensions (if available)\012    -F<DIR>             "
"        pass \042-F<DIR>\042 to C compiler (add framework \012                           "
"      header path on Mac OS X)\012    -framework NAME             passed to linker "
"on Mac OS X\012    -rpath PATHNAME             add directory to runtime library sea"
"rch path\012    -Wl,...                     pass linker options\012    -strip         "
"             strip resulting binary\012\012  Inquiry options:\012\012    -home              "
"         show home-directory (where support files go)\012    -cflags               "
"      show required C-compiler flags and exit\012    -ldflags                    sh"
"ow required linker flags and exit\012    -libs                       show required "
"libraries and exit\012    -cc-name                    show name of default C compil"
"er used\012    -cxx-name                   show name of default C++ compiler used\012 "
"   -ld-name                    show name of default linker used\012    -dry-run    "
"                just show commands executed, don\047t run them \012                   "
"              (implies `-v\047)\012\012  Obscure options:\012\012    -debug MODES              "
"  display debugging output for the given modes\012    -compiler PATHNAME          u"
"se other compiler than default `chicken\047\012    -disable-c-syntax-checks    disable"
" syntax checks of C code fragments\012    -raw                        do not genera"
"te implicit init- and exit code\011\011\011       \012    -emit-external-prototypes-first  e"
"mit protoypes for callbacks before foreign\012                                 decl"
"arations\012    -keep-shadowed-macros       do not remove shadowed macro\012    -host "
"                      compile for host when configured for cross-compiling\012\012  Op"
"tions can be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same as\012\012    -v -"
"k -fixnum-arithmetic -optimize\012\012  The contents of the environment variable CSC_O"
"PTIONS are implicitly\012  passed to every invocation of `csc\047.\012");
lf[191]=C_h_intern(&lf[191],8,"-release");
lf[192]=C_h_intern(&lf[192],15,"chicken-version");
lf[193]=C_h_intern(&lf[193],8,"-version");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[195]=C_h_intern(&lf[195],4,"-c++");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[197]=C_h_intern(&lf[197],5,"-objc");
lf[198]=C_h_intern(&lf[198],7,"-static");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[201]=C_h_intern(&lf[201],12,"-static-libs");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[204]=C_h_intern(&lf[204],18,"-static-extensions");
lf[205]=C_h_intern(&lf[205],7,"-cflags");
lf[206]=C_h_intern(&lf[206],8,"-ldflags");
lf[207]=C_h_intern(&lf[207],8,"-cc-name");
lf[208]=C_h_intern(&lf[208],9,"-cxx-name");
lf[209]=C_h_intern(&lf[209],8,"-ld-name");
lf[210]=C_h_intern(&lf[210],5,"-home");
lf[211]=C_h_intern(&lf[211],5,"-libs");
lf[212]=C_h_intern(&lf[212],2,"-v");
lf[213]=C_h_intern(&lf[213],3,"-v2");
lf[214]=C_h_intern(&lf[214],8,"-verbose");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[216]=C_h_intern(&lf[216],2,"-w");
lf[217]=C_h_intern(&lf[217],12,"-no-warnings");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[220]=C_h_intern(&lf[220],3,"-v3");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[226]=C_h_intern(&lf[226],2,"-A");
lf[227]=C_h_intern(&lf[227],13,"-analyze-only");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[229]=C_h_intern(&lf[229],2,"-P");
lf[230]=C_h_intern(&lf[230],13,"-check-syntax");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[232]=C_h_intern(&lf[232],2,"-k");
lf[233]=C_h_intern(&lf[233],2,"-c");
lf[234]=C_h_intern(&lf[234],2,"-t");
lf[235]=C_h_intern(&lf[235],2,"-e");
lf[236]=C_h_intern(&lf[236],9,"-embedded");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[238]=C_h_intern(&lf[238],18,"-require-extension");
lf[239]=C_h_intern(&lf[239],2,"-R");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[241]=C_h_intern(&lf[241],8,"-windows");
lf[242]=C_h_intern(&lf[242],2,"-W");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\017-DC_WINDOWS_GUI");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[252]=C_h_intern(&lf[252],10,"-framework");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[254]=C_h_intern(&lf[254],2,"-o");
lf[255]=C_h_intern(&lf[255],2,"-O");
lf[256]=C_h_intern(&lf[256],3,"-O1");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[259]=C_h_intern(&lf[259],3,"-O2");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[262]=C_h_intern(&lf[262],3,"-O3");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[265]=C_h_intern(&lf[265],3,"-d0");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[268]=C_h_intern(&lf[268],3,"-d1");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[271]=C_h_intern(&lf[271],3,"-d2");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[274]=C_h_intern(&lf[274],8,"-dry-run");
lf[275]=C_h_intern(&lf[275],2,"-s");
lf[276]=C_h_intern(&lf[276],4,"-dll");
lf[277]=C_h_intern(&lf[277],8,"-library");
lf[278]=C_h_intern(&lf[278],9,"-compiler");
lf[279]=C_h_intern(&lf[279],3,"-cc");
lf[280]=C_h_intern(&lf[280],4,"-cxx");
lf[281]=C_h_intern(&lf[281],3,"-ld");
lf[282]=C_h_intern(&lf[282],2,"-I");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[284]=C_h_intern(&lf[284],2,"-C");
lf[285]=C_h_intern(&lf[285],12,"string-split");
lf[286]=C_h_intern(&lf[286],6,"-strip");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[288]=C_h_intern(&lf[288],2,"-L");
lf[289]=C_h_intern(&lf[289],17,"-unsafe-libraries");
lf[290]=C_h_intern(&lf[290],6,"-rpath");
lf[291]=C_h_intern(&lf[291],3,"gnu");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[293]=C_h_intern(&lf[293],14,"build-platform");
lf[294]=C_h_intern(&lf[294],5,"-host");
lf[295]=C_h_intern(&lf[295],1,"-");
lf[296]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[298]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-E\376\003\000\000\002\376B\000\000\012-extension\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003-Ob\376\003\000\000\002\376B\000\000\017-benchmark-mode\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-featu"
"re\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-"
"keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026"
"-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-G\376\003\000\000\002\376B\000\000\016-check-imports\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376"
"\001\000\000\002-j\376\003\000\000\002\376B\000\000\024-emit-import-library\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\017-benchmark-mode\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000"
"\000\017-compile-syntax\376\003\000\000\002\376\001\000\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dynam"
"ic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002\376\001\000\000\020-emit-debug-info\376\003\000\000\002\376\001\000\000\016-c"
"heck-imports\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000\012"
"-extension\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\022-static-extensions\376\003\000\000\002\376\001\000\000\015-analyze-only\376"
"\003\000\000\002\376\001\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\030-disable-compiler-macros\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\007-import\376\003\000\000\002\376\001\000\000\031-require-static-extension\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000"
"\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap"
"-initial-size\376\003\000\000\002\376\001\000\000\015-emit-exports\376\003\000\000\002\376\001\000\000\022-compress-literals\376\003\000\000\002\376\001\000\000\024-emit-"
"import-library\376\377\016");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[302]=C_h_intern(&lf[302],9,"substring");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[305]=C_h_intern(&lf[305],15,"lset-difference");
lf[306]=C_h_intern(&lf[306],6,"char=\077");
lf[307]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000G\376\377\016");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[310]=C_h_intern(&lf[310],18,"decompose-pathname");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[325]=C_h_intern(&lf[325],15,"-optimize-level");
lf[326]=C_h_intern(&lf[326],15,"-benchmark-mode");
lf[327]=C_h_intern(&lf[327],10,"-to-stdout");
lf[328]=C_h_intern(&lf[328],7,"-unsafe");
lf[329]=C_h_intern(&lf[329],7,"-shared");
lf[330]=C_h_intern(&lf[330],8,"-dynamic");
lf[331]=C_h_intern(&lf[331],14,"string->symbol");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[333]=C_h_intern(&lf[333],6,"getenv");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\011-LIBPATH:");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\007 -Wl,-R");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-luchicken\376\377\016");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[351]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\023libuchicken-static.");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\014libuchicken.");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[364]=C_h_intern(&lf[364],22,"command-line-arguments");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[366]=C_h_intern(&lf[366],4,"hpux");
lf[367]=C_h_intern(&lf[367],4,"hppa");
lf[368]=C_h_intern(&lf[368],12,"machine-type");
lf[369]=C_h_intern(&lf[369],16,"software-version");
C_register_lf2(lf,370,create_ptable());
t2=C_mutate(&lf[0] /* c201 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_953,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k951 */
static void C_ccall f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k954 in k951 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k957 in k954 in k951 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k960 in k957 in k954 in k951 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_968,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_977,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3853,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 106  build-platform");
t3=C_retrieve(lf[293]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3853,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3] /* mingw ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 107  build-platform");
t5=C_retrieve(lf[293]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5] /* msvc ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 108  software-version");
t5=C_retrieve(lf[369]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7] /* osx ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3841,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 109  software-version");
t6=C_retrieve(lf[369]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k3839 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[366]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 110  machine-type");
t4=C_retrieve(lf[368]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_1005(t3,C_SCHEME_FALSE);}}

/* k3835 in k3839 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1005(t2,(C_word)C_eqp(t1,lf[367]));}

/* k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1005,NULL,2,t0,t1);}
t2=C_mutate(&lf[8] /* hpux-hppa ...) */,t1);
t3=C_mutate(&lf[9] /* quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1007,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 116  getenv");
t5=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[365]);}

/* k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=C_mutate(&lf[14] /* chicken-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 117  command-line-arguments");
t4=C_retrieve(lf[364]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=C_mutate(&lf[15] /* arguments ...) */,t1);
t3=(C_word)C_i_member(lf[16],C_retrieve2(lf[15],"arguments"));
t4=C_mutate(&lf[17] /* host-mode ...) */,t3);
t5=(C_word)C_fudge(C_fix(39));
t6=C_mutate(&lf[18] /* cross-chicken ...) */,t5);
t7=C_mutate(&lf[19] /* prefix ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1036,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[21] /* quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1049,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3817,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3821,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t12=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k3819 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 133  prefix");
f_1036(((C_word*)t0)[2],lf[362],lf[363],t1);}

/* k3815 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 132  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1063,2,t0,t1);}
t2=C_mutate(&lf[27] /* home ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3795,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3799,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3803,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_BIN_HOME),C_fix(0));}}

/* k3801 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3807,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k3805 in k3801 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 138  make-pathname");
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3797 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 137  prefix");
f_1036(((C_word*)t0)[2],lf[360],lf[361],t1);}

/* k3793 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 136  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=C_mutate(&lf[28] /* translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1071,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3785,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3783 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 142  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1071,2,t0,t1);}
t2=C_mutate(&lf[29] /* compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1075,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3775,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k3773 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 143  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1075,2,t0,t1);}
t2=C_mutate(&lf[30] /* c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1079,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3762(2,t5,lf[359]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* k3760 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 144  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1079,2,t0,t1);}
t2=C_mutate(&lf[31] /* linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3749,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=t4;
f_3749(2,t5,lf[358]);}
else{
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* k3747 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 145  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1083,2,t0,t1);}
t2=C_mutate(&lf[32] /* c++-linker ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[33]:lf[34]);
t4=C_mutate(&lf[35] /* object-extension ...) */,t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[36]:lf[37]);
t6=C_mutate(&lf[38] /* library-extension ...) */,t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[39]:lf[40]);
t8=C_mutate(&lf[41] /* link-output-flag ...) */,t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[42]:lf[43]);
t10=C_mutate(&lf[44] /* executable-extension ...) */,t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[45]:lf[46]);
t12=C_mutate(&lf[47] /* compile-output-flag ...) */,t11);
t13=C_mutate(&lf[48] /* shared-library-extension ...) */,C_retrieve(lf[49]));
t14=(C_truep(lf[3])?lf[3]:C_retrieve2(lf[5],"msvc"));
t15=(C_truep(t14)?lf[50]:lf[51]);
t16=C_mutate(&lf[52] /* pic-options ...) */,t15);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[356]:lf[357]);
C_trace("csc.scm: 156  string-append");
t19=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t18,C_retrieve2(lf[38],"library-extension"));}

/* k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=C_mutate(&lf[53] /* default-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[354]:lf[355]);
C_trace("csc.scm: 159  string-append");
t5=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[38],"library-extension"));}

/* k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1118,2,t0,t1);}
t2=C_mutate(&lf[54] /* default-unsafe-library ...) */,t1);
t3=(C_truep(lf[3])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3733,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3728,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[55] /* cleanup-filename ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3718,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k3716 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 168  string-split");
t2=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=C_mutate(&lf[56] /* default-compilation-optimization-options ...) */,t1);
t3=C_mutate(&lf[57] /* best-compilation-optimization-options ...) */,C_retrieve2(lf[56],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3708,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3706 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 170  string-split");
t2=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=C_mutate(&lf[58] /* default-linking-optimization-options ...) */,t1);
t3=C_mutate(&lf[59] /* best-linking-optimization-options ...) */,C_retrieve2(lf[58],"default-linking-optimization-options"));
t4=lf[60] /* scheme-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[61] /* c-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[62] /* generated-c-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[63] /* object-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[64] /* generated-object-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[65] /* cpp-mode */ =C_SCHEME_FALSE;;
t10=lf[66] /* objc-mode */ =C_SCHEME_FALSE;;
t11=lf[67] /* embedded */ =C_SCHEME_FALSE;;
t12=lf[68] /* inquiry-only */ =C_SCHEME_FALSE;;
t13=lf[69] /* show-cflags */ =C_SCHEME_FALSE;;
t14=lf[70] /* show-ldflags */ =C_SCHEME_FALSE;;
t15=lf[71] /* show-libs */ =C_SCHEME_FALSE;;
t16=lf[72] /* dry-run */ =C_SCHEME_FALSE;;
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t18=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1157,2,t0,t1);}
t2=C_mutate(&lf[73] /* extra-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
t2=C_mutate(&lf[74] /* extra-shared-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3674,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3682,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3680 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3686,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 246  string-append");
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[353],C_retrieve2(lf[53],"default-library"));}

/* k3684 in k3680 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 244  string-append");
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3676 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 243  prefix");
f_1036(((C_word*)t0)[2],C_retrieve2(lf[53],"default-library"),lf[352],t1);}

/* k3672 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 242  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3670,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[75] /* default-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3666,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 248  string-append");
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[350],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_1169(t5,lf[351]);}}

/* k3664 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1169(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1169,NULL,2,t0,t1);}
t2=C_mutate(&lf[76] /* default-shared-library-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3641,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3645,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3649,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3647 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3653,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 256  string-append");
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[349],C_retrieve2(lf[54],"default-unsafe-library"));}

/* k3651 in k3647 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 254  string-append");
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3643 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 253  prefix");
f_1036(((C_word*)t0)[2],C_retrieve2(lf[54],"default-unsafe-library"),lf[348],t1);}

/* k3639 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 252  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[77] /* unsafe-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3633,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 258  string-append");
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,lf[346],C_retrieve2(lf[38],"library-extension"));}
else{
t5=t4;
f_1177(t5,lf[347]);}}

/* k3631 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3633,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1177(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1177,NULL,2,t0,t1);}
t2=C_mutate(&lf[78] /* unsafe-shared-library-files ...) */,t1);
t3=C_mutate(&lf[79] /* gui-library-files ...) */,C_retrieve2(lf[75],"default-library-files"));
t4=C_mutate(&lf[80] /* gui-shared-library-files ...) */,C_retrieve2(lf[76],"default-shared-library-files"));
t5=C_mutate(&lf[81] /* library-files ...) */,C_retrieve2(lf[75],"default-library-files"));
t6=C_mutate(&lf[82] /* shared-library-files ...) */,C_retrieve2(lf[76],"default-shared-library-files"));
t7=C_mutate(&lf[83] /* translate-options ...) */,lf[84]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3620,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t10=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k3618 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 268  prefix");
f_1036(((C_word*)t0)[2],lf[344],lf[345],t1);}

/* k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1186,2,t0,t1);}
t2=(C_word)C_i_member(t1,lf[85]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[86] /* include-dir ...) */,t3);
t5=lf[87] /* compile-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1194,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[86],"include-dir"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3605,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 275  quotewrap");
f_1049(t8,C_retrieve2(lf[86],"include-dir"));}
else{
t7=t6;
f_1194(t7,C_SCHEME_END_OF_LIST);}}

/* k3607 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 275  conc");
t2=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[343],t1);}

/* k3603 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3605,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1194(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1194,NULL,2,t0,t1);}
t2=C_mutate(&lf[88] /* builtin-compile-options ...) */,t1);
t3=C_mutate(&lf[89] /* compilation-optimization-options ...) */,C_retrieve2(lf[56],"default-compilation-optimization-options"));
t4=C_mutate(&lf[90] /* linking-optimization-options ...) */,C_retrieve2(lf[58],"default-linking-optimization-options"));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t7=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k3590 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 283  prefix");
f_1036(((C_word*)t0)[2],lf[341],lf[342],t1);}

/* k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1202,2,t0,t1);}
t2=C_mutate(&lf[91] /* library-dir ...) */,t1);
t3=lf[92] /* link-options */ =C_SCHEME_END_OF_LIST;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[7],"osx"):(C_truep(C_retrieve2(lf[8],"hpux-hppa"))?C_retrieve2(lf[8],"hpux-hppa"):lf[3]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3534,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 291  quotewrap");
f_1049(t7,C_retrieve2(lf[91],"library-dir"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3548,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3552,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 293  quotewrap");
f_1049(t7,C_retrieve2(lf[91],"library-dir"));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3585,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 296  quotewrap");
f_1049(t7,C_retrieve2(lf[91],"library-dir"));}}}

/* k3583 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 296  conc");
t2=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[340],t1);}

/* k3557 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3563,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3567,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t6=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}

/* k3573 in k3557 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 297  prefix");
f_1036(((C_word*)t0)[2],lf[338],lf[339],t1);}

/* k3569 in k3557 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 297  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k3565 in k3557 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 297  conc");
t2=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[337],t1);}

/* k3561 in k3557 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3563,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1207(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3550 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 293  conc");
t2=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[336],t1);}

/* k3546 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3548,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1207(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k3536 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 291  conc");
t2=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[335],t1);}

/* k3532 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1207(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1207(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1207,NULL,2,t0,t1);}
t2=C_mutate(&lf[93] /* builtin-link-options ...) */,t1);
t3=lf[94] /* target-filename */ =C_SCHEME_FALSE;;
t4=lf[95] /* verbose */ =C_SCHEME_FALSE;;
t5=lf[96] /* keep-files */ =C_SCHEME_FALSE;;
t6=lf[97] /* translate-only */ =C_SCHEME_FALSE;;
t7=lf[98] /* compile-only */ =C_SCHEME_FALSE;;
t8=lf[99] /* to-stdout */ =C_SCHEME_FALSE;;
t9=lf[100] /* shared */ =C_SCHEME_FALSE;;
t10=lf[101] /* static */ =C_SCHEME_FALSE;;
t11=lf[102] /* static-libs */ =C_SCHEME_FALSE;;
t12=lf[103] /* static-extensions */ =C_SCHEME_FALSE;;
t13=lf[104] /* required-extensions */ =C_SCHEME_END_OF_LIST;;
t14=lf[105] /* gui */ =C_SCHEME_FALSE;;
t15=C_mutate(&lf[106] /* compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2976,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[111] /* static-extension-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3128,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[117] /* linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3225,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[120] /* linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3277,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[122] /* constant761 ...) */,lf[123]);
t20=C_mutate(&lf[109] /* quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3426,tmp=(C_word)a,a+=2,tmp));
t21=lf[132] /* last-exit-code */ =C_SCHEME_FALSE;;
t22=C_mutate(&lf[133] /* $system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3455,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[138] /* $delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3487,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3503,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3513,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3517,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3521,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 960  getenv");
t28=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,lf[334]);}

/* k3519 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[332]);
C_trace("csc.scm: 960  string-split");
t3=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k3515 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 960  append");
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[15],"arguments"));}

/* k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1230,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1237,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1276,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1305,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1305(t8,((C_word*)t0)[2],t1);}

/* loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1305(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1305,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 502  append");
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[87],"compile-options"),C_retrieve2(lf[88],"builtin-compile-options"));}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1487,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
C_trace("csc.scm: 544  string->symbol");
t8=*((C_word*)lf[331]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word ab[117],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,lf[187]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[188]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 319  display");
t6=*((C_word*)lf[189]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[190]);}
else{
t5=(C_word)C_eqp(t1,lf[191]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1514,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1521,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 550  chicken-version");
t8=C_retrieve(lf[192]);
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t6=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1537,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 553  sprintf");
t9=C_retrieve(lf[157]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[28],"translator"),lf[194]);}
else{
t7=(C_word)C_eqp(t1,lf[195]);
if(C_truep(t7)){
t8=lf[65] /* cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[196],C_retrieve2(lf[87],"compile-options"));
t10=C_mutate(&lf[87] /* compile-options ...) */,t9);
t11=t2;
f_1490(2,t11,t10);}
else{
t9=t2;
f_1490(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(C_word)C_eqp(t1,lf[197]);
if(C_truep(t8)){
t9=lf[66] /* objc-mode */ =C_SCHEME_TRUE;;
t10=t2;
f_1490(2,t10,t9);}
else{
t9=(C_word)C_eqp(t1,lf[198]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1568,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 561  cons*");
t11=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t10,lf[199],lf[200],C_retrieve2(lf[83],"translate-options"));}
else{
t10=(C_word)C_eqp(t1,lf[201]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 564  cons*");
t12=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,lf[202],lf[203],C_retrieve2(lf[83],"translate-options"));}
else{
t11=(C_word)C_eqp(t1,lf[204]);
if(C_truep(t11)){
t12=lf[103] /* static-extensions */ =C_SCHEME_TRUE;;
t13=t2;
f_1490(2,t13,t12);}
else{
t12=(C_word)C_eqp(t1,lf[205]);
if(C_truep(t12)){
t13=lf[68] /* inquiry-only */ =C_SCHEME_TRUE;;
t14=lf[69] /* show-cflags */ =C_SCHEME_TRUE;;
t15=t2;
f_1490(2,t15,t14);}
else{
t13=(C_word)C_eqp(t1,lf[206]);
if(C_truep(t13)){
t14=lf[68] /* inquiry-only */ =C_SCHEME_TRUE;;
t15=lf[70] /* show-ldflags */ =C_SCHEME_TRUE;;
t16=t2;
f_1490(2,t16,t15);}
else{
t14=(C_word)C_eqp(t1,lf[207]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 574  print");
t16=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,C_retrieve2(lf[29],"compiler"));}
else{
t15=(C_word)C_eqp(t1,lf[208]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 575  print");
t17=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,C_retrieve2(lf[30],"c++-compiler"));}
else{
t16=(C_word)C_eqp(t1,lf[209]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 576  print");
t18=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,C_retrieve2(lf[31],"linker"));}
else{
t17=(C_word)C_eqp(t1,lf[210]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1648,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 577  print");
t19=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,C_retrieve2(lf[27],"home"));}
else{
t18=(C_word)C_eqp(t1,lf[211]);
if(C_truep(t18)){
t19=lf[68] /* inquiry-only */ =C_SCHEME_TRUE;;
t20=lf[71] /* show-libs */ =C_SCHEME_TRUE;;
t21=t2;
f_1490(2,t21,t20);}
else{
t19=(C_word)C_eqp(t1,lf[212]);
if(C_truep(t19)){
t20=lf[95] /* verbose */ =C_SCHEME_TRUE;;
t21=t2;
f_1490(2,t21,t20);}
else{
t20=(C_word)C_eqp(t1,lf[213]);
t21=(C_truep(t20)?t20:(C_word)C_eqp(t1,lf[214]));
if(C_truep(t21)){
t22=lf[95] /* verbose */ =C_SCHEME_TRUE;;
C_trace("csc.scm: 585  t-options");
f_1230(t2,(C_word)C_a_i_list(&a,1,lf[215]));}
else{
t22=(C_word)C_eqp(t1,lf[216]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[217]));
if(C_truep(t23)){
t24=(C_word)C_a_i_cons(&a,2,lf[218],C_retrieve2(lf[87],"compile-options"));
t25=C_mutate(&lf[87] /* compile-options ...) */,t24);
C_trace("csc.scm: 588  t-options");
f_1230(t2,(C_word)C_a_i_list(&a,1,lf[219]));}
else{
t24=(C_word)C_eqp(t1,lf[220]);
if(C_truep(t24)){
t25=lf[95] /* verbose */ =C_SCHEME_TRUE;;
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1705,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 591  t-options");
f_1230(t26,(C_word)C_a_i_list(&a,1,lf[225]));}
else{
t25=(C_word)C_eqp(t1,lf[226]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t1,lf[227]));
if(C_truep(t26)){
t27=lf[97] /* translate-only */ =C_SCHEME_TRUE;;
C_trace("csc.scm: 597  t-options");
f_1230(t2,(C_word)C_a_i_list(&a,1,lf[228]));}
else{
t27=(C_word)C_eqp(t1,lf[229]);
t28=(C_truep(t27)?t27:(C_word)C_eqp(t1,lf[230]));
if(C_truep(t28)){
t29=lf[97] /* translate-only */ =C_SCHEME_TRUE;;
C_trace("csc.scm: 600  t-options");
f_1230(t2,(C_word)C_a_i_list(&a,1,lf[231]));}
else{
t29=(C_word)C_eqp(t1,lf[232]);
if(C_truep(t29)){
t30=lf[96] /* keep-files */ =C_SCHEME_TRUE;;
t31=t2;
f_1490(2,t31,t30);}
else{
t30=(C_word)C_eqp(t1,lf[233]);
if(C_truep(t30)){
t31=lf[98] /* compile-only */ =C_SCHEME_TRUE;;
t32=t2;
f_1490(2,t32,t31);}
else{
t31=(C_word)C_eqp(t1,lf[234]);
if(C_truep(t31)){
t32=lf[97] /* translate-only */ =C_SCHEME_TRUE;;
t33=t2;
f_1490(2,t33,t32);}
else{
t32=(C_word)C_eqp(t1,lf[235]);
t33=(C_truep(t32)?t32:(C_word)C_eqp(t1,lf[236]));
if(C_truep(t33)){
t34=lf[67] /* embedded */ =C_SCHEME_TRUE;;
t35=(C_word)C_a_i_cons(&a,2,lf[237],C_retrieve2(lf[87],"compile-options"));
t36=C_mutate(&lf[87] /* compile-options ...) */,t35);
t37=t2;
f_1490(2,t37,t36);}
else{
t34=(C_word)C_eqp(t1,lf[238]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[239]));
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1796,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("csc.scm: 608  check");
f_1237(t36,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t36=(C_word)C_eqp(t1,lf[241]);
t37=(C_truep(t36)?t36:(C_word)C_eqp(t1,lf[242]));
if(C_truep(t37)){
t38=lf[105] /* gui */ =C_SCHEME_TRUE;;
if(C_truep(lf[3])){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1836,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 617  cons*");
t40=C_retrieve(lf[129]);
((C_proc7)C_retrieve_proc(t40))(7,t40,t39,lf[244],lf[245],lf[246],lf[247],C_retrieve2(lf[92],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t39=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1847,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 622  cons*");
t40=C_retrieve(lf[129]);
((C_proc6)C_retrieve_proc(t40))(6,t40,t39,lf[249],lf[250],lf[251],C_retrieve2(lf[92],"link-options"));}
else{
t39=t2;
f_1490(2,t39,C_SCHEME_UNDEFINED);}}}
else{
t38=(C_word)C_eqp(t1,lf[252]);
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1860,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 625  check");
f_1237(t39,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t39=(C_word)C_eqp(t1,lf[254]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 630  check");
f_1237(t40,t1,((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t40=(C_word)C_eqp(t1,lf[255]);
t41=(C_truep(t40)?t40:(C_word)C_eqp(t1,lf[256]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1905,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 634  cons*");
t43=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t43))(5,t43,t42,lf[257],lf[258],((C_word*)((C_word*)t0)[6])[1]);}
else{
t42=(C_word)C_eqp(t1,lf[259]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1915,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 635  cons*");
t44=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t44))(5,t44,t43,lf[260],lf[261],((C_word*)((C_word*)t0)[6])[1]);}
else{
t43=(C_word)C_eqp(t1,lf[262]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1925,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 636  cons*");
t45=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t45))(5,t45,t44,lf[263],lf[264],((C_word*)((C_word*)t0)[6])[1]);}
else{
t44=(C_word)C_eqp(t1,lf[265]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1935,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 637  cons*");
t46=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t46))(5,t46,t45,lf[266],lf[267],((C_word*)((C_word*)t0)[6])[1]);}
else{
t45=(C_word)C_eqp(t1,lf[268]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1945,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 638  cons*");
t47=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t47))(5,t47,t46,lf[269],lf[270],((C_word*)((C_word*)t0)[6])[1]);}
else{
t46=(C_word)C_eqp(t1,lf[271]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 639  cons*");
t48=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t48))(5,t48,t47,lf[272],lf[273],((C_word*)((C_word*)t0)[6])[1]);}
else{
t47=(C_word)C_eqp(t1,lf[274]);
if(C_truep(t47)){
t48=lf[95] /* verbose */ =C_SCHEME_TRUE;;
t49=lf[72] /* dry-run */ =C_SCHEME_TRUE;;
t50=t2;
f_1490(2,t50,t49);}
else{
t48=(C_word)C_eqp(t1,lf[275]);
t49=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t48)){
t50=t49;
f_1972(t50,t48);}
else{
t50=(C_word)C_eqp(t1,lf[329]);
t51=t49;
f_1972(t51,(C_truep(t50)?t50:(C_word)C_eqp(t1,lf[330])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[55],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1972,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("csc.scm: 644  shared-build");
f_1276(((C_word*)t0)[7],C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[276]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[6],lf[277]));
if(C_truep(t3)){
C_trace("csc.scm: 646  shared-build");
f_1276(((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[278]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 648  check");
f_1237(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[279]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 652  check");
f_1237(t6,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[6],lf[280]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 656  check");
f_1237(t7,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[6],lf[281]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 660  check");
f_1237(t8,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[6],lf[282]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 664  check");
f_1237(t9,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[6],lf[284]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 667  check");
f_1237(t10,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[6],lf[286]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,lf[287]);
C_trace("csc.scm: 671  append");
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[92],"link-options"),t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[6],lf[288]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 673  check");
f_1237(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[6],lf[289]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 677  t-options");
f_1230(t13,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t13=(C_word)C_eqp(((C_word*)t0)[6],lf[290]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 681  check");
f_1237(t14,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[6],lf[294]);
if(C_truep(t14)){
t15=((C_word*)t0)[7];
f_1490(2,t15,C_SCHEME_FALSE);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[6],lf[295]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 687  make-pathname");
t17=C_retrieve(lf[20]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t16,C_SCHEME_FALSE,lf[297],C_retrieve2(lf[44],"executable-extension"));}
else{
t16=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t17=((C_word*)t0)[6];
if(C_truep((C_truep((C_word)C_eqp(t17,lf[328]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t17,lf[326]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t18=(C_word)C_eqp(((C_word*)t0)[6],lf[326]);
if(C_truep(t18)){
t19=C_mutate(&lf[81] /* library-files ...) */,C_retrieve2(lf[77],"unsafe-library-files"));
t20=C_mutate(&lf[82] /* shared-library-files ...) */,C_retrieve2(lf[78],"unsafe-shared-library-files"));
t21=t16;
f_2213(t21,t20);}
else{
t19=t16;
f_2213(t19,C_SCHEME_UNDEFINED);}}
else{
t18=t16;
f_2213(t18,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}}

/* k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2213,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[327]);
if(C_truep(t3)){
t4=lf[99] /* to-stdout */ =C_SCHEME_TRUE;;
t5=lf[97] /* translate-only */ =C_SCHEME_TRUE;;
t6=t2;
f_2216(t6,t5);}
else{
t4=t2;
f_2216(t4,C_SCHEME_UNDEFINED);}}

/* k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2216,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[325]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[326]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[89] /* compilation-optimization-options ...) */,C_retrieve2(lf[57],"best-compilation-optimization-options"));
t5=C_mutate(&lf[90] /* linking-optimization-options ...) */,C_retrieve2(lf[59],"best-linking-optimization-options"));
t6=t2;
f_2219(t6,t5);}
else{
t4=t2;
f_2219(t4,C_SCHEME_UNDEFINED);}}

/* k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2219,NULL,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[7],lf[298]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[6])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=((C_word*)t0)[5];
f_1490(2,t6,t5);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[299]))){
C_trace("csc.scm: 701  t-options");
f_1230(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[7],lf[300]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("csc.scm: 703  check");
f_1237(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2601,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 708  substring");
t6=*((C_word*)lf[302]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_2270(t5,C_SCHEME_FALSE);}}}}}

/* k2599 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2270(t2,(C_word)C_i_string_equal_p(lf[324],t1));}

/* k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2270,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("csc.scm: 709  t-options");
f_1230(((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t3,C_fix(1)))){
t4=(C_word)C_i_string_ref(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_2279(t5,(C_word)C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_2279(t4,C_SCHEME_FALSE);}}}

/* k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2279,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
C_trace("csc.scm: 713  append");
t6=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,C_retrieve2(lf[92],"link-options"),t5);}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
C_trace("csc.scm: 715  append");
t8=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[92],"link-options"),t7);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2317,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
C_trace("csc.scm: 717  append");
t10=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,C_retrieve2(lf[87],"compile-options"),t9);}
else{
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t9=(C_word)C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2334,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 719  substring");
t11=*((C_word*)lf[302]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,((C_word*)t0)[6],C_fix(2));}
else{
t10=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(1));
t11=(C_word)C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2347,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t13=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
C_trace("csc.scm: 722  append");
t14=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t12,C_retrieve2(lf[87],"compile-options"),t13);}
else{
t12=((C_word*)t0)[5];
f_1490(2,t12,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 723  substring");
t15=*((C_word*)lf[302]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[6],C_fix(0),C_fix(4));}
else{
t14=t12;
f_2357(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("csc.scm: 732  file-exists?");
t3=C_retrieve(lf[173]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2456,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("csc.scm: 749  string-append");
t3=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[4],lf[323]);}}

/* k2562 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("csc.scm: 750  file-exists?");
t3=C_retrieve(lf[173]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2568 in k2562 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=((C_word*)t0)[3];
f_1490(2,t4,t3);}
else{
C_trace("csc.scm: 752  quit");
f_1007(((C_word*)t0)[3],lf[322],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2466 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[37],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2467,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t6,lf[311]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t6,lf[312]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2492,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("csc.scm: 736  append");
t9=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve2(lf[61],"c-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t7,lf[313]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[314]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[315]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[316]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t7,lf[317]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=(C_word)C_a_i_cons(&a,2,lf[318],C_retrieve2(lf[87],"compile-options"));
t10=C_mutate(&lf[87] /* compile-options ...) */,t9);
t11=t8;
f_2505(t11,t10);}
else{
t9=t8;
f_2505(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep((C_word)C_i_equalp(t8,lf[319]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[320]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t8,lf[321]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[66] /* objc-mode */ =C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2529,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("csc.scm: 743  append");
t12=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t12))(4,t12,t10,C_retrieve2(lf[61],"c-files"),t11);}
else{
t9=(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[35],"object-extension"));
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(t4,C_retrieve2(lf[38],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("csc.scm: 746  append");
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[63],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2554,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("csc.scm: 747  append");
t13=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t13))(4,t13,t11,C_retrieve2(lf[60],"scheme-files"),t12);}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2478,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("csc.scm: 734  append");
t8=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[60],"scheme-files"),t7);}}

/* k2476 in a2466 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2552 in a2466 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2544 in a2466 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63] /* object-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2527 in a2466 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2503 in a2466 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2505,NULL,2,t0,t1);}
t2=lf[65] /* cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("csc.scm: 740  append");
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_retrieve2(lf[61],"c-files"),t4);}

/* k2508 in k2503 in a2466 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2490 in a2466 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a2460 in k2454 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2461,2,t0,t1);}
C_trace("csc.scm: 733  decompose-pathname");
t2=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2424 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2357(t2,(C_word)C_i_string_equal_p(lf[309],t1));}

/* k2355 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2357,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2361,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
C_trace("csc.scm: 724  append");
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,C_retrieve2(lf[92],"link-options"),t3);}
else{
t2=(C_word)C_i_string_length(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2409,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("string->list");
t4=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
C_trace("csc.scm: 731  quit");
f_1007(((C_word*)t0)[5],lf[308],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k2407 in k2355 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2409,2,t0,t1);}
t2=(C_word)C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("csc.scm: 727  lset-difference");
t4=C_retrieve(lf[305]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[306]+1),t2,lf[307]);}

/* k2403 in k2407 in k2355 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2384,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2390,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}
else{
C_trace("csc.scm: 730  quit");
f_1007(((C_word*)t0)[4],lf[304],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2389 in k2403 in k2407 in k2355 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2390,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
C_trace("csc.scm: 729  string-append");
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[303],t3);}

/* k2386 in k2403 in k2407 in k2355 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 729  append");
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2382 in k2403 in k2407 in k2355 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2359 in k2355 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2345 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2332 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2334,2,t0,t1);}
C_trace("csc.scm: 719  t-options");
f_1230(((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,lf[301],t1));}

/* k2315 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2301 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2287 in k2277 in k2268 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2249 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2251,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2257,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("csc.scm: 705  string->number");
C_string_to_number(3,0,t3,t2);}

/* k2255 in k2249 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 706  t-options");
f_1230(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2258 in k2255 in k2249 in k2217 in k2214 in k2211 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1490(2,t4,t3);}

/* k2204 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2206,2,t0,t1);}
t2=C_mutate(&lf[94] /* target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 688  append");
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[60],"scheme-files"),lf[296]);}

/* k2208 in k2204 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2158 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 682  build-platform");
t3=C_retrieve(lf[293]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2188 in k2158 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=(C_word)C_eqp(lf[291],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
C_trace("csc.scm: 683  string-append");
t6=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[292],t5);}
else{
t3=((C_word*)t0)[2];
f_1490(2,t3,C_SCHEME_UNDEFINED);}}

/* k2180 in k2188 in k2158 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2182,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
C_trace("csc.scm: 683  append");
t3=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t2);}

/* k2168 in k2188 in k2158 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1490(2,t5,t4);}

/* k2147 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[81] /* library-files ...) */,C_retrieve2(lf[77],"unsafe-library-files"));
t3=C_mutate(&lf[82] /* shared-library-files ...) */,C_retrieve2(lf[78],"unsafe-shared-library-files"));
t4=((C_word*)t0)[2];
f_1490(2,t4,t3);}

/* k2122 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
C_trace("csc.scm: 674  string-split");
t5=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2134 in k2122 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 674  append");
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[92],"link-options"),t1);}

/* k2126 in k2122 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1490(2,t5,t4);}

/* k2109 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2083 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
C_trace("csc.scm: 668  string-split");
t5=C_retrieve(lf[285]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k2095 in k2083 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 668  append");
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[87],"compile-options"),t1);}

/* k2087 in k2083 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[87] /* compile-options ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1490(2,t5,t4);}

/* k2062 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
C_trace("csc.scm: 665  cons*");
t5=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[283],t3,t4);}

/* k2066 in k2062 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k2045 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[31] /* linker ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1490(2,t6,t5);}

/* k2028 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[30] /* c++-compiler ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1490(2,t6,t5);}

/* k2011 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[29] /* compiler ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1490(2,t6,t5);}

/* k1994 in k1970 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(&lf[28] /* translator ...) */,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_1490(2,t6,t5);}

/* k1953 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k1943 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k1933 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k1923 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k1913 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k1903 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1490(2,t3,t2);}

/* k1882 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_mutate(&lf[94] /* target-filename ...) */,t2);
t6=((C_word*)t0)[2];
f_1490(2,t6,t5);}

/* k1858 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1871,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
C_trace("csc.scm: 627  cons*");
t5=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,lf[253],t4,C_retrieve2(lf[92],"link-options"));}
else{
t3=t2;
f_1863(t3,C_SCHEME_UNDEFINED);}}

/* k1869 in k1858 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1863(t3,t2);}

/* k1861 in k1858 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1863(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1490(2,t4,t3);}

/* k1845 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[248],C_retrieve2(lf[87],"compile-options"));
t4=C_mutate(&lf[87] /* compile-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1490(2,t5,t4);}

/* k1834 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[243],C_retrieve2(lf[87],"compile-options"));
t4=C_mutate(&lf[87] /* compile-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1490(2,t5,t4);}

/* k1794 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
C_trace("csc.scm: 609  append");
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_retrieve2(lf[104],"required-extensions"),t4);}

/* k1798 in k1794 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
t2=C_mutate(&lf[104] /* required-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)((C_word*)t0)[4])[1]);
C_trace("csc.scm: 610  t-options");
f_1230(t3,(C_word)C_a_i_list(&a,2,lf[240],t4));}

/* k1801 in k1798 in k1794 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1490(2,t4,t3);}

/* k1703 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t3=t2;
f_1708(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 593  cons*");
t4=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[223],lf[224],C_retrieve2(lf[87],"compile-options"));}}

/* k1721 in k1703 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* compile-options ...) */,t1);
t3=((C_word*)t0)[2];
f_1708(t3,t2);}

/* k1706 in k1703 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1708,NULL,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[221]:lf[222]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_retrieve2(lf[92],"link-options"));
t4=C_mutate(&lf[92] /* link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1490(2,t5,t4);}

/* k1646 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 577  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1634 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 576  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1622 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 575  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1610 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 574  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k1577 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83] /* translate-options ...) */,t1);
t3=lf[102] /* static-libs */ =C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_1490(2,t4,t3);}

/* k1566 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[83] /* translate-options ...) */,t1);
t3=lf[101] /* static */ =C_SCHEME_TRUE;;
t4=((C_word*)t0)[2];
f_1490(2,t4,t3);}

/* k1535 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 553  system");
t2=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1528 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 554  exit");
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1519 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 550  print");
t2=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1512 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 551  exit");
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1500 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 548  exit");
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1488 in k1485 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 753  loop");
t2=((C_word*)((C_word*)t0)[4])[1];
f_1305(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1316,2,t0,t1);}
t2=C_mutate(&lf[87] /* compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 503  append");
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[92],"link-options"),C_retrieve2(lf[93],"builtin-link-options"));}

/* k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[69],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1478,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 506  compiler-options");
f_2976(t5);}
else{
t5=t4;
f_1445(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1323(2,t4,C_SCHEME_UNDEFINED);}}

/* k1476 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 506  print*");
t2=*((C_word*)lf[186]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k1443 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[70],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 507  linker-options");
f_3225(t3);}
else{
t3=t2;
f_1448(2,t3,C_SCHEME_UNDEFINED);}}

/* k1469 in k1443 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 507  print*");
t2=*((C_word*)lf[186]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k1446 in k1443 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1464,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 508  linker-libraries");
f_3277(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=t2;
f_1451(2,t3,C_SCHEME_UNDEFINED);}}

/* k1462 in k1446 in k1443 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 508  print*");
t2=*((C_word*)lf[186]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k1449 in k1446 in k1443 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 509  newline");
t3=*((C_word*)lf[185]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1452 in k1449 in k1446 in k1443 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 510  exit");
t2=C_retrieve(lf[10]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1370,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t5=(C_truep(t4)?(C_word)C_i_nullp(C_retrieve2(lf[63],"object-files")):C_SCHEME_FALSE);
if(C_truep(t5)){
C_trace("csc.scm: 516  quit");
f_1007(t3,lf[163],C_SCHEME_END_OF_LIST);}
else{
t6=t3;
f_1370(2,t6,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1408,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[100],"shared"))?(C_word)C_i_not(C_retrieve2(lf[67],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,lf[184],C_retrieve2(lf[83],"translate-options"));
t6=C_mutate(&lf[83] /* translate-options ...) */,t5);
t7=t3;
f_1408(t7,t6);}
else{
t5=t3;
f_1408(t5,C_SCHEME_UNDEFINED);}}}

/* k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1408,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[94],"target-filename"))){
t3=t2;
f_1411(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[100],"shared"))){
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
C_trace("csc.scm: 529  pathname-replace-extension");
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[48],"shared-library-extension"));}
else{
t4=(C_word)C_i_car(C_retrieve2(lf[60],"scheme-files"));
C_trace("csc.scm: 530  pathname-replace-extension");
t5=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[44],"executable-extension"));}}}

/* k1416 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1411(t3,t2);}

/* k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1411,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2679,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t4=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[60],"scheme-files"));}

/* a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2679,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2683,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 761  pathname-replace-extension");
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[183]);}

/* k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2887,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 762  file-exists?");
t5=C_retrieve(lf[173]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2885 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 763  with-input-from-file");
t3=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_retrieve(lf[171]));}
else{
t2=((C_word*)t0)[3];
f_2881(t2,C_SCHEME_FALSE);}}

/* k2888 in k2885 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eofp(t1);
t3=((C_word*)t0)[2];
f_2881(t3,(C_truep(t2)?t2:(C_word)C_i_string_equal_p(lf[182],t1)));}

/* k2879 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("csc.scm: 765  $delete-file");
t2=C_retrieve2(lf[138],"$delete-file");
f_3487(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2686(2,t2,C_SCHEME_UNDEFINED);}}

/* k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_length(C_retrieve2(lf[60],"scheme-files"));
t4=(C_word)C_i_nequalp(C_fix(1),t3);
t5=(C_truep(t4)?C_retrieve2(lf[94],"target-filename"):((C_word*)t0)[2]);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?lf[179]:(C_truep(C_retrieve2(lf[66],"objc-mode"))?lf[180]:lf[181]));
C_trace("csc.scm: 766  pathname-replace-extension");
t7=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,t5,t6);}

/* k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2692,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2802,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2806,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2810,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2814,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 776  cleanup-filename");
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2818,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[99],"to-stdout"))){
t4=t3;
f_2822(t4,lf[177]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2860,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 780  cleanup-filename");
t5=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}}

/* k2858 in k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
f_2822(t3,(C_word)C_a_i_cons(&a,2,lf[178],t2));}

/* k2820 in k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2822,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2826,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[101],"static");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2837,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t4;
f_2837(t5,t3);}
else{
t5=C_retrieve2(lf[102],"static-libs");
t6=t4;
f_2837(t6,(C_truep(t5)?t5:C_retrieve2(lf[103],"static-extensions")));}}

/* k2835 in k2820 in k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2837,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2842,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t3=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[104],"required-extensions"));}
else{
t2=((C_word*)t0)[2];
f_2826(2,t2,C_SCHEME_END_OF_LIST);}}

/* a2841 in k2835 in k2820 in k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2842,3,t0,t1,t2);}
C_trace("csc.scm: 782  conc");
t3=C_retrieve(lf[175]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[176],t2);}

/* k2824 in k2820 in k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2830,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2834,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 784  append");
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),C_SCHEME_END_OF_LIST);}

/* k2832 in k2824 in k2820 in k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[109],"quote-option"),t1);}

/* k2828 in k2824 in k2820 in k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 777  append");
t2=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2816 in k2812 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 776  cons*");
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve2(lf[28],"translator"),((C_word*)t0)[2],t1);}

/* k2808 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 775  string-intersperse");
t2=C_retrieve(lf[107]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[174]);}

/* k2804 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 774  $system");
t2=C_retrieve2(lf[133],"$system");
f_3455(3,t2,((C_word*)t0)[2],t1);}

/* k2800 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2692(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 786  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("csc.scm: 787  append");
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_retrieve2(lf[61],"c-files"));}

/* k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
t2=C_mutate(&lf[61] /* c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("csc.scm: 788  append");
t5=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_retrieve2(lf[62],"generated-c-files"));}

/* k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
t2=C_mutate(&lf[62] /* generated-c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 789  file-exists?");
t4=C_retrieve(lf[173]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2714,tmp=(C_word)a,a+=2,tmp);
C_trace("csc.scm: 790  with-input-from-file");
t4=C_retrieve(lf[172]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a2713 in k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 792  read-line");
t3=C_retrieve(lf[171]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2716 in a2713 in k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2723,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 805  read-file");
t4=C_retrieve(lf[170]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k2782 in k2716 in a2713 in k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2722 in k2716 in a2713 in k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2723,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2727,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=t3;
f_2727(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 796  error");
t4=*((C_word*)lf[167]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[169],t2);}}

/* k2725 in a2722 in k2716 in a2713 in k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_eqp(t2,lf[164]);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("for-each");
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],C_retrieve2(lf[133],"$system"),t4);}
else{
t4=(C_word)C_eqp(t2,lf[165]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("csc.scm: 801  append");
t7=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,C_retrieve2(lf[87],"compile-options"),t6);}
else{
t5=(C_word)C_eqp(t2,lf[166]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("csc.scm: 803  append");
t8=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,C_retrieve2(lf[92],"link-options"),t7);}
else{
C_trace("csc.scm: 804  error");
t6=*((C_word*)lf[167]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[2],lf[168],((C_word*)t0)[3]);}}}}

/* k2765 in k2725 in a2722 in k2716 in a2713 in k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[92] /* link-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2751 in k2725 in a2722 in k2716 in a2713 in k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* compile-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2707 in k2704 in k2698 in k2694 in k2690 in k2687 in k2684 in k2681 in a2678 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 806  $delete-file");
t2=C_retrieve2(lf[138],"$delete-file");
f_3487(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2669 in k1409 in k1406 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t2=((C_word*)t0)[2];
f_1326(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("for-each");
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_SCHEME_END_OF_LIST);}}

/* k1368 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_nullp(C_retrieve2(lf[61],"c-files"));
t4=(C_truep(t3)?C_retrieve2(lf[63],"object-files"):C_retrieve2(lf[61],"c-files"));
C_trace("csc.scm: 517  last");
t5=C_retrieve(lf[162]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k1371 in k1368 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
if(C_truep(C_retrieve2(lf[94],"target-filename"))){
t2=((C_word*)t0)[2];
f_1326(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[100],"shared"))){
C_trace("csc.scm: 521  pathname-replace-extension");
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[48],"shared-library-extension"));}
else{
C_trace("csc.scm: 522  pathname-replace-extension");
t3=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_retrieve2(lf[44],"executable-extension"));}}}

/* k1378 in k1371 in k1368 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1326(2,t3,t2);}

/* k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
if(C_truep(C_retrieve2(lf[97],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2905,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2921,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t7=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_retrieve2(lf[61],"c-files"));}}

/* a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2921,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2925,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("csc.scm: 817  pathname-replace-extension");
t4=C_retrieve(lf[161]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,C_retrieve2(lf[35],"object-extension"));}

/* k2923 in a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2946,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2950,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[30],"c++-compiler"):C_retrieve2(lf[29],"compiler"));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2962,a[2]=t1,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("csc.scm: 823  cleanup-filename");
t7=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2960 in k2923 in a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 824  cleanup-filename");
t4=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2972 in k2960 in k2923 in a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 824  string-append");
t2=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[47],"compile-output-flag"),t1);}

/* k2964 in k2960 in k2923 in a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("csc.scm: 826  compiler-options");
f_2976(t2);}

/* k2968 in k2964 in k2960 in k2923 in a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[160],t1);
C_trace("csc.scm: 820  string-intersperse");
t3=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k2948 in k2923 in a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 819  $system");
t2=C_retrieve2(lf[133],"$system");
f_3455(3,t2,((C_word*)t0)[2],t1);}

/* k2944 in k2923 in a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_2928(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 827  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k2926 in k2923 in a2920 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[64],"generated-object-files"));
t3=C_mutate(&lf[64] /* generated-object-files ...) */,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2903 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2919,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 831  reverse");
t4=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2917 in k2903 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 831  append");
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[63],"object-files"));}

/* k2907 in k2903 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[63] /* object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t3=((C_word*)t0)[2];
f_1332(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("for-each");
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[62],"generated-c-files"));}}

/* k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
if(C_truep(C_retrieve2(lf[98],"compile-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_member(C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1347,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 536  printf");
t4=C_retrieve(lf[134]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[159],C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[94],"target-filename"));}
else{
t3=t2;
f_1338(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1345 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1364,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 538  sprintf");
t4=C_retrieve(lf[157]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[158],C_retrieve2(lf[94],"target-filename"),C_retrieve2(lf[94],"target-filename"));}

/* k1362 in k1345 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 538  $system");
t2=C_retrieve2(lf[133],"$system");
f_3455(3,t2,((C_word*)t0)[2],t1);}

/* k1358 in k1345 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_1338(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 539  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1338,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3114,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3116,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3122,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t5,t6,t7);}

/* a3121 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3122r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3122r(t0,t1,t2);}}

static void C_ccall f_3122r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a3115 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
C_trace("csc.scm: 848  static-extension-info");
f_3128(t1);}

/* k3112 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 847  append");
t2=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[63],"object-files"),t1);}

/* k3108 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[55],"cleanup-filename"),t1);}

/* k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3004,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 849  cleanup-filename");
t3=C_retrieve2(lf[55],"cleanup-filename");
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve2(lf[94],"target-filename"));}

/* k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3007,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3074,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3078,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_truep(C_retrieve2(lf[65],"cpp-mode"))?C_retrieve2(lf[32],"c++-linker"):C_retrieve2(lf[31],"linker"));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3090,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 857  string-append");
t9=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,C_retrieve2(lf[41],"link-output-flag"),t1);}

/* k3096 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("csc.scm: 858  linker-options");
f_3225(t2);}

/* k3100 in k3096 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("csc.scm: 859  linker-libraries");
f_3277(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k3104 in k3100 in k3096 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
C_trace("csc.scm: 855  append");
t3=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3088 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 853  cons*");
t2=C_retrieve(lf[129]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3080 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 852  string-intersperse");
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3076 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 851  $system");
t2=C_retrieve2(lf[133],"$system");
f_3455(3,t2,((C_word*)t0)[2],t1);}

/* k3072 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_3007(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 860  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=(C_word)C_i_not(C_retrieve2(lf[18],"cross-chicken"));
t5=t3;
f_3019(t5,(C_truep(t4)?t4:C_retrieve2(lf[17],"host-mode")));}
else{
t4=t3;
f_3019(t4,C_SCHEME_FALSE);}}

/* k3017 in k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3019(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3019,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3036,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3044,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3048,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[17],"host-mode"))){
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}
else{
t2=((C_word*)t0)[3];
f_3010(2,t2,C_SCHEME_UNDEFINED);}}

/* k3050 in k3017 in k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 867  prefix");
f_1036(((C_word*)t0)[2],lf[154],lf[155],t1);}

/* k3046 in k3017 in k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 866  make-pathname");
t2=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[153]);}

/* k3042 in k3017 in k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 865  quotewrap");
f_1049(((C_word*)t0)[2],t1);}

/* k3038 in k3017 in k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 863  string-append");
t2=*((C_word*)lf[22]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[151],t1,lf[152],((C_word*)t0)[2]);}

/* k3034 in k3017 in k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 862  $system");
t2=C_retrieve2(lf[133],"$system");
f_3455(3,t2,((C_word*)t0)[2],t1);}

/* k3030 in k3017 in k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[2];
f_3010(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 874  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve2(lf[132],"last-exit-code"));}}

/* k3008 in k3005 in k3002 in k2999 in k1336 in k1330 in k1324 in k1321 in k1318 in k1314 in loop in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[96],"keep-files"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("for-each");
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[138],"$delete-file"),C_retrieve2(lf[64],"generated-object-files"));}}

/* shared-build in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1276(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1276,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1281,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 490  cons*");
t4=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[148],lf[149],C_retrieve2(lf[83],"translate-options"));}

/* k1279 in shared-build in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=C_mutate(&lf[83] /* translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 491  append");
t4=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_retrieve2(lf[52],"pic-options"),lf[147],C_retrieve2(lf[87],"compile-options"));}

/* k1283 in k1279 in shared-build in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=C_mutate(&lf[87] /* compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?lf[143]:lf[144]):(C_truep(C_retrieve2(lf[5],"msvc"))?lf[145]:lf[146]));
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[92],"link-options"));
t5=C_mutate(&lf[92] /* link-options ...) */,t4);
t6=lf[100] /* shared */ =C_SCHEME_TRUE;;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* check in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1237(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1237,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1255,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t7=t6;
f_1255(2,t7,C_fix(1));}
else{
t7=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_1255(2,t8,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t8=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k1253 in check in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1255,2,t0,t1);}
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 487  quit");
f_1007(((C_word*)t0)[3],lf[142],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1230(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1230,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1235,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 483  append");
t4=*((C_word*)lf[110]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve2(lf[83],"translate-options"),t2);}

/* k1233 in t-options in k3511 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[83] /* translate-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3501 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3509,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#implicit-exit-handler");
t4=C_retrieve(lf[141]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3507 in k3501 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3504 in k3501 in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3487,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3491,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[95],"verbose"))){
C_trace("csc.scm: 954  print");
t4=*((C_word*)lf[137]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[140],t2);}
else{
t4=t3;
f_3491(2,t4,C_SCHEME_UNDEFINED);}}

/* k3489 in $delete-file in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 955  delete-file");
t2=C_retrieve(lf[139]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* $system in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3455,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3459,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[95],"verbose"))){
C_trace("csc.scm: 941  print");
t4=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_3459(2,t4,C_SCHEME_UNDEFINED);}}

/* k3457 in $system in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[72],"dry-run"))){
t3=t2;
f_3463(t3,C_fix(0));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3482,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 945  system");
t4=C_retrieve(lf[136]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k3480 in k3457 in $system in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_3463(t3,(C_truep(t2)?C_fix(0):C_fix(1)));}

/* k3461 in k3457 in $system in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3463,NULL,2,t0,t1);}
t2=C_mutate(&lf[132] /* last-exit-code ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_zerop(C_retrieve2(lf[132],"last-exit-code")))){
t4=t3;
f_3466(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("csc.scm: 949  printf");
t4=C_retrieve(lf[134]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[135],C_retrieve2(lf[132],"last-exit-code"),((C_word*)t0)[2]);}}

/* k3464 in k3461 in k3457 in $system in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve2(lf[132],"last-exit-code"));}

/* quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3426,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3433,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3438,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3452,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("string->list");
t6=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3450 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 932  any");
t2=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3437 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3438,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,lf[122])));}

/* k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3359,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3377,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("string->list");
t9=C_retrieve(lf[130]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k3375 in k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3379(t5,((C_word*)t0)[2],t1);}

/* fold in k3375 in k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3379(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3379,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_memq(t3,lf[122]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3402,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
C_trace("csc.scm: 923  fold");
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_3409(t6,t5);}
else{
t5=t4;
f_3409(t5,C_SCHEME_UNDEFINED);}}}}

/* k3407 in fold in k3375 in k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3409,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("csc.scm: 926  fold");
t4=((C_word*)((C_word*)t0)[2])[1];
f_3379(t4,t2,t3);}

/* k3414 in k3407 in fold in k3375 in k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3416,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3400 in fold in k3375 in k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 923  cons*");
t2=C_retrieve(lf[129]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k3371 in k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("list->string");
t2=C_retrieve(lf[128]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3357 in k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3359,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 928  string-translate*");
t3=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,lf[127]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k3367 in k3357 in k3431 in quote-option in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 928  string-append");
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[124],t1,lf[125]);}

/* linker-libraries in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3277(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3277,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3281(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3281(2,t5,(C_word)C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3279 in linker-libraries in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3292,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3323,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3329,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_3292(2,t4,C_SCHEME_END_OF_LIST);}}

/* a3328 in k3279 in linker-libraries in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3329r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3329r(t0,t1,t2);}}

static void C_ccall f_3329r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(0)));}

/* a3322 in k3279 in linker-libraries in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
C_trace("csc.scm: 903  static-extension-info");
f_3128(t1);}

/* k3290 in k3279 in linker-libraries in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3292,2,t0,t1);}
t2=C_retrieve2(lf[101],"static");
t3=(C_truep(t2)?t2:C_retrieve2(lf[102],"static-libs"));
t4=(C_truep(t3)?(C_truep(C_retrieve2(lf[105],"gui"))?C_retrieve2(lf[79],"gui-library-files"):C_retrieve2(lf[81],"library-files")):(C_truep(C_retrieve2(lf[105],"gui"))?C_retrieve2(lf[80],"gui-shared-library-files"):C_retrieve2(lf[82],"shared-library-files")));
t5=C_retrieve2(lf[101],"static");
t6=(C_truep(t5)?t5:C_retrieve2(lf[102],"static-libs"));
t7=(C_truep(t6)?(C_word)C_a_i_list(&a,1,C_retrieve2(lf[73],"extra-libraries")):(C_word)C_a_i_list(&a,1,C_retrieve2(lf[74],"extra-shared-libraries")));
C_trace("csc.scm: 902  append");
t8=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,((C_word*)t0)[2],t1,t4,t7);}

/* k3286 in k3279 in linker-libraries in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 901  string-intersperse");
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* linker-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3225(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3225,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3233,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3263,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3265,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3271,tmp=(C_word)a,a+=2,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t4,t5,t6);}

/* a3270 in linker-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3271r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3271r(t0,t1,t2);}}

static void C_ccall f_3271r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a3264 in linker-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
C_trace("csc.scm: 897  static-extension-info");
f_3128(t1);}

/* k3261 in linker-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 896  append");
t2=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_retrieve2(lf[90],"linking-optimization-options"),C_retrieve2(lf[92],"link-options"),t1);}

/* k3257 in linker-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 895  string-intersperse");
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3231 in linker-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[101],"static"))?(C_truep(lf[3])?C_SCHEME_FALSE:(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve2(lf[7],"osx")))):C_SCHEME_FALSE);
t3=(C_truep(t2)?lf[118]:lf[119]);
C_trace("csc.scm: 894  string-append");
t4=*((C_word*)lf[22]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t1,t3);}

/* static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3128(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3128,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3132,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("csc.scm: 878  repository-path");
t3=C_retrieve(lf[116]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=C_retrieve2(lf[101],"static");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3138,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_3138(t4,t2);}
else{
t4=C_retrieve2(lf[102],"static-libs");
t5=t3;
f_3138(t5,(C_truep(t4)?t4:C_retrieve2(lf[103],"static-extensions")));}}

/* k3136 in k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3138,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3143,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3143(t5,((C_word*)t0)[2],C_retrieve2(lf[104],"required-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
C_trace("csc.scm: 891  values");
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k3136 in k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3143(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3143,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3157,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 882  reverse");
t6=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3164,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_i_car(t2);
C_trace("csc.scm: 883  extension-information");
t7=C_retrieve(lf[115]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}

/* k3162 in loop in k3136 in k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[113],t1);
t3=(C_word)C_i_assq(lf[114],t1);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3202,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
C_trace("csc.scm: 888  make-pathname");
t8=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_3184(t6,((C_word*)t0)[3]);}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
C_trace("csc.scm: 890  loop");
t3=((C_word*)((C_word*)t0)[6])[1];
f_3143(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k3200 in k3162 in loop in k3136 in k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3184(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k3182 in k3162 in loop in k3136 in k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3184(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3184,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3188,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t2;
f_3188(t4,(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}
else{
t3=t2;
f_3188(t3,((C_word*)t0)[2]);}}

/* k3186 in k3182 in k3162 in loop in k3136 in k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_3188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 887  loop");
t2=((C_word*)((C_word*)t0)[5])[1];
f_3143(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3155 in loop in k3136 in k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 882  reverse");
t3=*((C_word*)lf[112]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3159 in k3155 in loop in k3136 in k3130 in static-extension-info in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 882  values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* compiler-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_2976(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2976,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[101],"static");
t5=(C_truep(t4)?t4:C_retrieve2(lf[102],"static-libs"));
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_END_OF_LIST);
C_trace("csc.scm: 837  append");
t7=*((C_word*)lf[110]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t3,t6,C_retrieve2(lf[89],"compilation-optimization-options"),C_retrieve2(lf[87],"compile-options"));}

/* k2986 in compiler-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[108]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[109],"quote-option"),t1);}

/* k2982 in compiler-options in k1205 in k1200 in k1192 in k1184 in k1175 in k3635 in k1167 in k3668 in k1159 in k1155 in k1129 in k1124 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 835  string-intersperse");
t2=C_retrieve(lf[107]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_3728 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3728,3,t0,t1,t2);}
C_trace("csc.scm: 165  quotewrap");
f_1049(t1,t2);}

/* f_3733 in k1116 in k1112 in k1081 in k1077 in k1073 in k1069 in k1065 in k1061 in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3733,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* quotewrap in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1049(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1049,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1056,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("csc.scm: 127  string-any");
t4=C_retrieve(lf[25]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,*((C_word*)lf[26]+1),t2);}

/* k1054 in quotewrap in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("csc.scm: 128  string-append");
t2=*((C_word*)lf[22]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[23],((C_word*)t0)[2],lf[24]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* prefix in k1024 in k1020 in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1036(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1036,NULL,4,t1,t2,t3,t4);}
if(C_truep(C_retrieve2(lf[14],"chicken-prefix"))){
t5=(C_word)C_a_i_list(&a,2,C_retrieve2(lf[14],"chicken-prefix"),t3);
C_trace("csc.scm: 123  make-pathname");
t6=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t5,t2);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* quit in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_fcall f_1007(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1007,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1011,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1018,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("csc.scm: 113  current-error-port");
t6=C_retrieve(lf[13]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k1016 in quit in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 113  fprintf");
t2=C_retrieve(lf[11]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],t1,lf[12],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1009 in quit in k1003 in k3843 in k3847 in k3851 in k987 in k984 in k981 in k978 in k975 in k972 in k969 in k966 in k963 in k960 in k957 in k954 in k951 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("csc.scm: 114  exit");
t2=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[319] = {
{"toplevelcsc.scm",(void*)C_toplevel},
{"f_953csc.scm",(void*)f_953},
{"f_956csc.scm",(void*)f_956},
{"f_959csc.scm",(void*)f_959},
{"f_962csc.scm",(void*)f_962},
{"f_965csc.scm",(void*)f_965},
{"f_968csc.scm",(void*)f_968},
{"f_971csc.scm",(void*)f_971},
{"f_974csc.scm",(void*)f_974},
{"f_977csc.scm",(void*)f_977},
{"f_980csc.scm",(void*)f_980},
{"f_983csc.scm",(void*)f_983},
{"f_986csc.scm",(void*)f_986},
{"f_989csc.scm",(void*)f_989},
{"f_3853csc.scm",(void*)f_3853},
{"f_3849csc.scm",(void*)f_3849},
{"f_3845csc.scm",(void*)f_3845},
{"f_3841csc.scm",(void*)f_3841},
{"f_3837csc.scm",(void*)f_3837},
{"f_1005csc.scm",(void*)f_1005},
{"f_1022csc.scm",(void*)f_1022},
{"f_1026csc.scm",(void*)f_1026},
{"f_3821csc.scm",(void*)f_3821},
{"f_3817csc.scm",(void*)f_3817},
{"f_1063csc.scm",(void*)f_1063},
{"f_3803csc.scm",(void*)f_3803},
{"f_3807csc.scm",(void*)f_3807},
{"f_3799csc.scm",(void*)f_3799},
{"f_3795csc.scm",(void*)f_3795},
{"f_1067csc.scm",(void*)f_1067},
{"f_3785csc.scm",(void*)f_3785},
{"f_1071csc.scm",(void*)f_1071},
{"f_3775csc.scm",(void*)f_3775},
{"f_1075csc.scm",(void*)f_1075},
{"f_3762csc.scm",(void*)f_3762},
{"f_1079csc.scm",(void*)f_1079},
{"f_3749csc.scm",(void*)f_3749},
{"f_1083csc.scm",(void*)f_1083},
{"f_1114csc.scm",(void*)f_1114},
{"f_1118csc.scm",(void*)f_1118},
{"f_3718csc.scm",(void*)f_3718},
{"f_1126csc.scm",(void*)f_1126},
{"f_3708csc.scm",(void*)f_3708},
{"f_1131csc.scm",(void*)f_1131},
{"f_1157csc.scm",(void*)f_1157},
{"f_1161csc.scm",(void*)f_1161},
{"f_3682csc.scm",(void*)f_3682},
{"f_3686csc.scm",(void*)f_3686},
{"f_3678csc.scm",(void*)f_3678},
{"f_3674csc.scm",(void*)f_3674},
{"f_3670csc.scm",(void*)f_3670},
{"f_3666csc.scm",(void*)f_3666},
{"f_1169csc.scm",(void*)f_1169},
{"f_3649csc.scm",(void*)f_3649},
{"f_3653csc.scm",(void*)f_3653},
{"f_3645csc.scm",(void*)f_3645},
{"f_3641csc.scm",(void*)f_3641},
{"f_3637csc.scm",(void*)f_3637},
{"f_3633csc.scm",(void*)f_3633},
{"f_1177csc.scm",(void*)f_1177},
{"f_3620csc.scm",(void*)f_3620},
{"f_1186csc.scm",(void*)f_1186},
{"f_3609csc.scm",(void*)f_3609},
{"f_3605csc.scm",(void*)f_3605},
{"f_1194csc.scm",(void*)f_1194},
{"f_3592csc.scm",(void*)f_3592},
{"f_1202csc.scm",(void*)f_1202},
{"f_3585csc.scm",(void*)f_3585},
{"f_3559csc.scm",(void*)f_3559},
{"f_3575csc.scm",(void*)f_3575},
{"f_3571csc.scm",(void*)f_3571},
{"f_3567csc.scm",(void*)f_3567},
{"f_3563csc.scm",(void*)f_3563},
{"f_3552csc.scm",(void*)f_3552},
{"f_3548csc.scm",(void*)f_3548},
{"f_3538csc.scm",(void*)f_3538},
{"f_3534csc.scm",(void*)f_3534},
{"f_1207csc.scm",(void*)f_1207},
{"f_3521csc.scm",(void*)f_3521},
{"f_3517csc.scm",(void*)f_3517},
{"f_3513csc.scm",(void*)f_3513},
{"f_1305csc.scm",(void*)f_1305},
{"f_1487csc.scm",(void*)f_1487},
{"f_1972csc.scm",(void*)f_1972},
{"f_2213csc.scm",(void*)f_2213},
{"f_2216csc.scm",(void*)f_2216},
{"f_2219csc.scm",(void*)f_2219},
{"f_2601csc.scm",(void*)f_2601},
{"f_2270csc.scm",(void*)f_2270},
{"f_2279csc.scm",(void*)f_2279},
{"f_2456csc.scm",(void*)f_2456},
{"f_2564csc.scm",(void*)f_2564},
{"f_2570csc.scm",(void*)f_2570},
{"f_2467csc.scm",(void*)f_2467},
{"f_2478csc.scm",(void*)f_2478},
{"f_2554csc.scm",(void*)f_2554},
{"f_2546csc.scm",(void*)f_2546},
{"f_2529csc.scm",(void*)f_2529},
{"f_2505csc.scm",(void*)f_2505},
{"f_2510csc.scm",(void*)f_2510},
{"f_2492csc.scm",(void*)f_2492},
{"f_2461csc.scm",(void*)f_2461},
{"f_2426csc.scm",(void*)f_2426},
{"f_2357csc.scm",(void*)f_2357},
{"f_2409csc.scm",(void*)f_2409},
{"f_2405csc.scm",(void*)f_2405},
{"f_2390csc.scm",(void*)f_2390},
{"f_2388csc.scm",(void*)f_2388},
{"f_2384csc.scm",(void*)f_2384},
{"f_2361csc.scm",(void*)f_2361},
{"f_2347csc.scm",(void*)f_2347},
{"f_2334csc.scm",(void*)f_2334},
{"f_2317csc.scm",(void*)f_2317},
{"f_2303csc.scm",(void*)f_2303},
{"f_2289csc.scm",(void*)f_2289},
{"f_2251csc.scm",(void*)f_2251},
{"f_2257csc.scm",(void*)f_2257},
{"f_2260csc.scm",(void*)f_2260},
{"f_2206csc.scm",(void*)f_2206},
{"f_2210csc.scm",(void*)f_2210},
{"f_2160csc.scm",(void*)f_2160},
{"f_2190csc.scm",(void*)f_2190},
{"f_2182csc.scm",(void*)f_2182},
{"f_2170csc.scm",(void*)f_2170},
{"f_2149csc.scm",(void*)f_2149},
{"f_2124csc.scm",(void*)f_2124},
{"f_2136csc.scm",(void*)f_2136},
{"f_2128csc.scm",(void*)f_2128},
{"f_2111csc.scm",(void*)f_2111},
{"f_2085csc.scm",(void*)f_2085},
{"f_2097csc.scm",(void*)f_2097},
{"f_2089csc.scm",(void*)f_2089},
{"f_2064csc.scm",(void*)f_2064},
{"f_2068csc.scm",(void*)f_2068},
{"f_2047csc.scm",(void*)f_2047},
{"f_2030csc.scm",(void*)f_2030},
{"f_2013csc.scm",(void*)f_2013},
{"f_1996csc.scm",(void*)f_1996},
{"f_1955csc.scm",(void*)f_1955},
{"f_1945csc.scm",(void*)f_1945},
{"f_1935csc.scm",(void*)f_1935},
{"f_1925csc.scm",(void*)f_1925},
{"f_1915csc.scm",(void*)f_1915},
{"f_1905csc.scm",(void*)f_1905},
{"f_1884csc.scm",(void*)f_1884},
{"f_1860csc.scm",(void*)f_1860},
{"f_1871csc.scm",(void*)f_1871},
{"f_1863csc.scm",(void*)f_1863},
{"f_1847csc.scm",(void*)f_1847},
{"f_1836csc.scm",(void*)f_1836},
{"f_1796csc.scm",(void*)f_1796},
{"f_1800csc.scm",(void*)f_1800},
{"f_1803csc.scm",(void*)f_1803},
{"f_1705csc.scm",(void*)f_1705},
{"f_1723csc.scm",(void*)f_1723},
{"f_1708csc.scm",(void*)f_1708},
{"f_1648csc.scm",(void*)f_1648},
{"f_1636csc.scm",(void*)f_1636},
{"f_1624csc.scm",(void*)f_1624},
{"f_1612csc.scm",(void*)f_1612},
{"f_1579csc.scm",(void*)f_1579},
{"f_1568csc.scm",(void*)f_1568},
{"f_1537csc.scm",(void*)f_1537},
{"f_1530csc.scm",(void*)f_1530},
{"f_1521csc.scm",(void*)f_1521},
{"f_1514csc.scm",(void*)f_1514},
{"f_1502csc.scm",(void*)f_1502},
{"f_1490csc.scm",(void*)f_1490},
{"f_1316csc.scm",(void*)f_1316},
{"f_1320csc.scm",(void*)f_1320},
{"f_1478csc.scm",(void*)f_1478},
{"f_1445csc.scm",(void*)f_1445},
{"f_1471csc.scm",(void*)f_1471},
{"f_1448csc.scm",(void*)f_1448},
{"f_1464csc.scm",(void*)f_1464},
{"f_1451csc.scm",(void*)f_1451},
{"f_1454csc.scm",(void*)f_1454},
{"f_1323csc.scm",(void*)f_1323},
{"f_1408csc.scm",(void*)f_1408},
{"f_1418csc.scm",(void*)f_1418},
{"f_1411csc.scm",(void*)f_1411},
{"f_2679csc.scm",(void*)f_2679},
{"f_2683csc.scm",(void*)f_2683},
{"f_2887csc.scm",(void*)f_2887},
{"f_2890csc.scm",(void*)f_2890},
{"f_2881csc.scm",(void*)f_2881},
{"f_2686csc.scm",(void*)f_2686},
{"f_2689csc.scm",(void*)f_2689},
{"f_2814csc.scm",(void*)f_2814},
{"f_2860csc.scm",(void*)f_2860},
{"f_2822csc.scm",(void*)f_2822},
{"f_2837csc.scm",(void*)f_2837},
{"f_2842csc.scm",(void*)f_2842},
{"f_2826csc.scm",(void*)f_2826},
{"f_2834csc.scm",(void*)f_2834},
{"f_2830csc.scm",(void*)f_2830},
{"f_2818csc.scm",(void*)f_2818},
{"f_2810csc.scm",(void*)f_2810},
{"f_2806csc.scm",(void*)f_2806},
{"f_2802csc.scm",(void*)f_2802},
{"f_2692csc.scm",(void*)f_2692},
{"f_2696csc.scm",(void*)f_2696},
{"f_2700csc.scm",(void*)f_2700},
{"f_2706csc.scm",(void*)f_2706},
{"f_2714csc.scm",(void*)f_2714},
{"f_2718csc.scm",(void*)f_2718},
{"f_2784csc.scm",(void*)f_2784},
{"f_2723csc.scm",(void*)f_2723},
{"f_2727csc.scm",(void*)f_2727},
{"f_2767csc.scm",(void*)f_2767},
{"f_2753csc.scm",(void*)f_2753},
{"f_2709csc.scm",(void*)f_2709},
{"f_2671csc.scm",(void*)f_2671},
{"f_1370csc.scm",(void*)f_1370},
{"f_1373csc.scm",(void*)f_1373},
{"f_1380csc.scm",(void*)f_1380},
{"f_1326csc.scm",(void*)f_1326},
{"f_2921csc.scm",(void*)f_2921},
{"f_2925csc.scm",(void*)f_2925},
{"f_2962csc.scm",(void*)f_2962},
{"f_2974csc.scm",(void*)f_2974},
{"f_2966csc.scm",(void*)f_2966},
{"f_2970csc.scm",(void*)f_2970},
{"f_2950csc.scm",(void*)f_2950},
{"f_2946csc.scm",(void*)f_2946},
{"f_2928csc.scm",(void*)f_2928},
{"f_2905csc.scm",(void*)f_2905},
{"f_2919csc.scm",(void*)f_2919},
{"f_2909csc.scm",(void*)f_2909},
{"f_1332csc.scm",(void*)f_1332},
{"f_1347csc.scm",(void*)f_1347},
{"f_1364csc.scm",(void*)f_1364},
{"f_1360csc.scm",(void*)f_1360},
{"f_1338csc.scm",(void*)f_1338},
{"f_3122csc.scm",(void*)f_3122},
{"f_3116csc.scm",(void*)f_3116},
{"f_3114csc.scm",(void*)f_3114},
{"f_3110csc.scm",(void*)f_3110},
{"f_3001csc.scm",(void*)f_3001},
{"f_3004csc.scm",(void*)f_3004},
{"f_3098csc.scm",(void*)f_3098},
{"f_3102csc.scm",(void*)f_3102},
{"f_3106csc.scm",(void*)f_3106},
{"f_3090csc.scm",(void*)f_3090},
{"f_3082csc.scm",(void*)f_3082},
{"f_3078csc.scm",(void*)f_3078},
{"f_3074csc.scm",(void*)f_3074},
{"f_3007csc.scm",(void*)f_3007},
{"f_3019csc.scm",(void*)f_3019},
{"f_3052csc.scm",(void*)f_3052},
{"f_3048csc.scm",(void*)f_3048},
{"f_3044csc.scm",(void*)f_3044},
{"f_3040csc.scm",(void*)f_3040},
{"f_3036csc.scm",(void*)f_3036},
{"f_3032csc.scm",(void*)f_3032},
{"f_3010csc.scm",(void*)f_3010},
{"f_1276csc.scm",(void*)f_1276},
{"f_1281csc.scm",(void*)f_1281},
{"f_1285csc.scm",(void*)f_1285},
{"f_1237csc.scm",(void*)f_1237},
{"f_1255csc.scm",(void*)f_1255},
{"f_1230csc.scm",(void*)f_1230},
{"f_1235csc.scm",(void*)f_1235},
{"f_3503csc.scm",(void*)f_3503},
{"f_3509csc.scm",(void*)f_3509},
{"f_3506csc.scm",(void*)f_3506},
{"f_3487csc.scm",(void*)f_3487},
{"f_3491csc.scm",(void*)f_3491},
{"f_3455csc.scm",(void*)f_3455},
{"f_3459csc.scm",(void*)f_3459},
{"f_3482csc.scm",(void*)f_3482},
{"f_3463csc.scm",(void*)f_3463},
{"f_3466csc.scm",(void*)f_3466},
{"f_3426csc.scm",(void*)f_3426},
{"f_3452csc.scm",(void*)f_3452},
{"f_3438csc.scm",(void*)f_3438},
{"f_3433csc.scm",(void*)f_3433},
{"f_3377csc.scm",(void*)f_3377},
{"f_3379csc.scm",(void*)f_3379},
{"f_3409csc.scm",(void*)f_3409},
{"f_3416csc.scm",(void*)f_3416},
{"f_3402csc.scm",(void*)f_3402},
{"f_3373csc.scm",(void*)f_3373},
{"f_3359csc.scm",(void*)f_3359},
{"f_3369csc.scm",(void*)f_3369},
{"f_3277csc.scm",(void*)f_3277},
{"f_3281csc.scm",(void*)f_3281},
{"f_3329csc.scm",(void*)f_3329},
{"f_3323csc.scm",(void*)f_3323},
{"f_3292csc.scm",(void*)f_3292},
{"f_3288csc.scm",(void*)f_3288},
{"f_3225csc.scm",(void*)f_3225},
{"f_3271csc.scm",(void*)f_3271},
{"f_3265csc.scm",(void*)f_3265},
{"f_3263csc.scm",(void*)f_3263},
{"f_3259csc.scm",(void*)f_3259},
{"f_3233csc.scm",(void*)f_3233},
{"f_3128csc.scm",(void*)f_3128},
{"f_3132csc.scm",(void*)f_3132},
{"f_3138csc.scm",(void*)f_3138},
{"f_3143csc.scm",(void*)f_3143},
{"f_3164csc.scm",(void*)f_3164},
{"f_3202csc.scm",(void*)f_3202},
{"f_3184csc.scm",(void*)f_3184},
{"f_3188csc.scm",(void*)f_3188},
{"f_3157csc.scm",(void*)f_3157},
{"f_3161csc.scm",(void*)f_3161},
{"f_2976csc.scm",(void*)f_2976},
{"f_2988csc.scm",(void*)f_2988},
{"f_2984csc.scm",(void*)f_2984},
{"f_3728csc.scm",(void*)f_3728},
{"f_3733csc.scm",(void*)f_3733},
{"f_1049csc.scm",(void*)f_1049},
{"f_1056csc.scm",(void*)f_1056},
{"f_1036csc.scm",(void*)f_1036},
{"f_1007csc.scm",(void*)f_1007},
{"f_1018csc.scm",(void*)f_1018},
{"f_1011csc.scm",(void*)f_1011},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
