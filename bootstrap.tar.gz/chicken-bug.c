/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:23
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: chicken-bug.scm -optimize-level 2 -include-path . -include-path . -no-lambda-info -output-file chicken-bug.c
   used units: library eval data_structures ports extras srfi_69 srfi_13 posix tcp data_structures utils extras
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[148];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_327)
static void C_ccall f_327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_330)
static void C_ccall f_330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_333)
static void C_ccall f_333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_336)
static void C_ccall f_336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_339)
static void C_ccall f_339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_342)
static void C_ccall f_342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_345)
static void C_ccall f_345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_351)
static void C_ccall f_351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_354)
static void C_ccall f_354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_357)
static void C_ccall f_357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1075)
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_779)
static void C_fcall f_779(C_word t0,C_word t1) C_noret;
C_noret_decl(f_911)
static void C_ccall f_911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_790)
static void C_fcall f_790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_826)
static void C_ccall f_826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_802)
static void C_ccall f_802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_752)
static void C_ccall f_752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_737)
static void C_ccall f_737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_684)
static void C_ccall f_684(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_725)
static void C_ccall f_725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_721)
static void C_ccall f_721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_700)
static void C_ccall f_700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_696)
static void C_ccall f_696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_607)
static void C_ccall f_607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_682)
static void C_ccall f_682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_678)
static void C_ccall f_678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_610)
static void C_fcall f_610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_674)
static void C_ccall f_674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_666)
static void C_ccall f_666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_670)
static void C_ccall f_670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_641)
static void C_ccall f_641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_651)
static void C_ccall f_651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_584)
static void C_ccall f_584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_588)
static void C_ccall f_588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_575)
static void C_ccall f_575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_560)
static void C_ccall f_560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_366)
static void C_ccall f_366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_370)
static void C_ccall f_370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_554)
static void C_ccall f_554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_550)
static void C_ccall f_550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_376)
static void C_ccall f_376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_542)
static void C_ccall f_542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_538)
static void C_ccall f_538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_534)
static void C_ccall f_534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_391)
static void C_ccall f_391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_526)
static void C_ccall f_526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_394)
static void C_ccall f_394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_522)
static void C_ccall f_522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_ccall f_397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_518)
static void C_ccall f_518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_403)
static void C_ccall f_403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_514)
static void C_ccall f_514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_510)
static void C_ccall f_510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_506)
static void C_ccall f_506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_482)
static void C_ccall f_482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_409)
static void C_ccall f_409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_457)
static void C_ccall f_457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_ccall f_459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_ccall f_467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_415)
static void C_ccall f_415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_418)
static void C_ccall f_418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_453)
static void C_ccall f_453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_ccall f_427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_443)
static void C_ccall f_443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_779)
static void C_fcall trf_779(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_779(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_779(t0,t1);}

C_noret_decl(trf_790)
static void C_fcall trf_790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_790(t0,t1);}

C_noret_decl(trf_610)
static void C_fcall trf_610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_610(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(626)){
C_save(t1);
C_rereclaim2(626*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,148);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000Ochicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-janitors@nongnu.org");
lf[7]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014mx10.gnu.org\376\003\000\000\002\376B\000\000\014mx20.gnu.org\376\377\016");
lf[8]=C_h_intern(&lf[8],12,"collect-info");
lf[9]=C_h_intern(&lf[9],7,"newline");
lf[10]=C_h_intern(&lf[10],7,"display");
lf[11]=C_h_intern(&lf[11],8,"read-all");
lf[12]=C_h_intern(&lf[12],20,"with-input-from-pipe");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[14]=C_h_intern(&lf[14],5,"print");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[17]=C_h_intern(&lf[17],8,"feature\077");
lf[18]=C_h_intern(&lf[18],4,"unix");
lf[19]=C_h_intern(&lf[19],17,"\003syspeek-c-string");
lf[20]=C_h_intern(&lf[20],20,"with-input-from-file");
lf[21]=C_h_intern(&lf[21],13,"make-pathname");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[24]=C_h_intern(&lf[24],6,"printf");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[26]=C_h_intern(&lf[26],11,"make-string");
lf[27]=C_h_intern(&lf[27],12,"\003sysfor-each");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[29]=C_h_intern(&lf[29],4,"chop");
lf[30]=C_h_intern(&lf[30],4,"sort");
lf[31]=C_h_intern(&lf[31],8,"string<\077");
lf[32]=C_h_intern(&lf[32],7,"\003sysmap");
lf[33]=C_h_intern(&lf[33],15,"keyword->string");
lf[34]=C_h_intern(&lf[34],12,"\003sysfeatures");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024Include path:\011~s~%~%");
lf[37]=C_h_intern(&lf[37],21,"\003sysinclude-pathnames");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[40]=C_h_intern(&lf[40],12,"chicken-home");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[43]=C_h_intern(&lf[43],15,"chicken-version");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[46]=C_h_intern(&lf[46],14,"build-platform");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[48]=C_h_intern(&lf[48],16,"software-version");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[50]=C_h_intern(&lf[50],13,"software-type");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[52]=C_h_intern(&lf[52],12,"machine-type");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\030User information:\011~s~%~%");
lf[55]=C_h_intern(&lf[55],16,"user-information");
lf[56]=C_h_intern(&lf[56],15,"current-user-id");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[59]=C_h_intern(&lf[59],15,"seconds->string");
lf[60]=C_h_intern(&lf[60],15,"current-seconds");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[63]=C_h_intern(&lf[63],5,"usage");
lf[64]=C_h_intern(&lf[64],4,"exit");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[66]=C_h_intern(&lf[66],10,"user-input");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\001VThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012once you have fini"
"shed. Press CTRL-C to abort the program. You can\012also pass the description from "
"a file (just abort now and re-invoke\012\042chicken-bug\042 with one or more input files "
"given on the command-line)\012");
lf[68]=C_h_intern(&lf[68],13,"\003systty-port\077");
lf[69]=C_h_intern(&lf[69],18,"current-input-port");
lf[70]=C_h_intern(&lf[70],7,"justify");
lf[71]=C_h_intern(&lf[71],13,"string-append");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[73]=C_h_intern(&lf[73],4,"main");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_h_intern(&lf[75],8,"try-mail");
lf[76]=C_h_intern(&lf[76],21,"with-output-to-string");
lf[77]=C_h_intern(&lf[77],12,"mail-headers");
lf[78]=C_h_intern(&lf[78],7,"sprintf");
lf[79]=C_h_intern(&lf[79],19,"seconds->local-time");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000G\012Could not send mail automatically!\012\012A bug report has been written to `");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[92]=C_h_intern(&lf[92],19,"with-output-to-file");
lf[93]=C_h_intern(&lf[93],9,"send-mail");
lf[94]=C_h_intern(&lf[94],13,"mail-date-str");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[99]=C_h_intern(&lf[99],10,"string-pad");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[124]=C_h_intern(&lf[124],17,"seconds->utc-time");
lf[125]=C_h_intern(&lf[125],9,"mail-read");
lf[126]=C_h_intern(&lf[126],9,"substring");
lf[127]=C_h_intern(&lf[127],9,"condition");
lf[128]=C_h_intern(&lf[128],17,"close-output-port");
lf[129]=C_h_intern(&lf[129],16,"close-input-port");
lf[130]=C_h_intern(&lf[130],9,"read-line");
lf[131]=C_h_intern(&lf[131],22,"with-exception-handler");
lf[132]=C_h_intern(&lf[132],30,"call-with-current-continuation");
lf[133]=C_h_intern(&lf[133],10,"mail-write");
lf[134]=C_h_intern(&lf[134],10,"mail-check");
lf[135]=C_h_intern(&lf[135],11,"tcp-connect");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000QBug report successfully mailed to the Chicken maintainers.\012Thank you very m"
"uch!\012\012");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[146]=C_h_intern(&lf[146],25,"\003sysimplicit-exit-handler");
lf[147]=C_h_intern(&lf[147],22,"command-line-arguments");
C_register_lf2(lf,148,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_327,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k325 */
static void C_ccall f_327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_330,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k328 in k325 */
static void C_ccall f_330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k331 in k328 in k325 */
static void C_ccall f_333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k334 in k331 in k328 in k325 */
static void C_ccall f_336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_339,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_345,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_360,2,t0,t1);}
t2=C_mutate(&lf[0] /* constant14 ...) */,lf[1]);
t3=C_mutate(&lf[2] /* constant19 ...) */,lf[3]);
t4=C_mutate(&lf[4] /* constant25 ...) */,lf[5]);
t5=C_mutate(&lf[6] /* constant32 ...) */,lf[7]);
t6=C_mutate((C_word*)lf[8]+1 /* collect-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_366,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[63]+1 /* usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_556,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[66]+1 /* user-input ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_565,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[70]+1 /* justify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_584,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[73]+1 /* main ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_603,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[75]+1 /* try-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_727,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[94]+1 /* mail-date-str ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_768,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[77]+1 /* mail-headers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_956,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[125]+1 /* mail-read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_974,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[133]+1 /* mail-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1060,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[134]+1 /* mail-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1129,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[93]+1 /* send-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1150,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1243,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 265  command-line-arguments");
t20=C_retrieve(lf[147]);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}

/* k1241 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 265  main");
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1231 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#implicit-exit-handler");
t4=C_retrieve(lf[146]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1237 in k1231 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1234 in k1231 in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1150,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1154,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("chicken-bug.scm: 248  print");
t7=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[144],t2,lf[145]);}

/* k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1159,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1165,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
C_trace("chicken-bug.scm: 251  call-with-current-continuation");
t5=*((C_word*)lf[132]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}

/* a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1171,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1230,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("chicken-bug.scm: 253  mail-read");
t5=*((C_word*)lf[125]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1228 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 253  mail-check");
t2=*((C_word*)lf[134]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1226,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("chicken-bug.scm: 254  mail-write");
t4=*((C_word*)lf[133]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[143]);}

/* k1224 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 254  mail-check");
t2=*((C_word*)lf[134]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1222,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("chicken-bug.scm: 255  mail-write");
t4=*((C_word*)lf[133]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[142]);}

/* k1220 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 255  mail-check");
t2=*((C_word*)lf[134]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("chicken-bug.scm: 256  mail-write");
t4=*((C_word*)lf[133]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[141]);}

/* k1216 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 256  mail-check");
t2=*((C_word*)lf[134]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("chicken-bug.scm: 257  mail-write");
t4=*((C_word*)lf[133]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[140]);}

/* k1212 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 257  mail-check");
t2=*((C_word*)lf[134]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1185 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1206,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-bug.scm: 258  string-append");
t5=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[138],((C_word*)t0)[2],lf[139]);}

/* k1208 in k1185 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 258  mail-write");
t2=*((C_word*)lf[133]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1204 in k1185 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 258  mail-check");
t2=*((C_word*)lf[134]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-bug.scm: 259  display");
t3=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[137],((C_word*)t0)[3]);}

/* k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-bug.scm: 260  close-input-port");
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1199,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 261  close-output-port");
t3=*((C_word*)lf[128]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1197 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1202,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 262  print");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[136]);}

/* k1200 in k1197 in k1194 in k1191 in k1188 in k1185 in k1182 in k1179 in k1176 in k1173 in a1170 in a1164 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* a1158 in k1152 in send-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1159,2,t0,t1);}
C_trace("chicken-bug.scm: 250  tcp-connect");
t2=C_retrieve(lf[135]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_fix(25));}

/* mail-check in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1129,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?(C_word)C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1139,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-bug.scm: 243  close-input-port");
t9=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t2);}}

/* k1137 in mail-check in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-bug.scm: 244  close-output-port");
t3=*((C_word*)lf[128]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1140 in k1137 in mail-check in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 245  k");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1060,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1064,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1075,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("call-with-current-continuation");
t8=*((C_word*)lf[132]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}

/* a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1075,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1081,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1105,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
t5=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1104 in a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a1116 in a1104 in a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1117r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1117r(t0,t1,t2);}}

static void C_ccall f_1117r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("k222227");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1122 in a1116 in a1104 in a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1110 in a1104 in a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
C_trace("chicken-bug.scm: 233  display");
t2=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1080 in a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1081,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("k222227");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1086 in a1080 in a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1087,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[127]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1094,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-bug.scm: 234  close-input-port");
t5=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1092 in a1086 in a1080 in a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 234  close-output-port");
t3=*((C_word*)lf[128]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1095 in k1092 in a1086 in a1080 in a1074 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1071 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1062 in mail-write in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("chicken-bug.scm: 236  mail-read");
t2=*((C_word*)lf[125]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_974,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_978,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1006,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("call-with-current-continuation");
t7=*((C_word*)lf[132]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1006,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1012,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1036,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("with-exception-handler");
t5=C_retrieve(lf[131]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1035 in a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a1047 in a1035 in a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1048r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1048r(t0,t1,t2);}}

static void C_ccall f_1048r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("k176181");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1053 in a1047 in a1035 in a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1041 in a1035 in a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1042,2,t0,t1);}
C_trace("chicken-bug.scm: 224  read-line");
t2=C_retrieve(lf[130]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a1011 in a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1012,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("k176181");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1017 in a1011 in a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1018,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[127]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-bug.scm: 225  close-input-port");
t5=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1023 in a1017 in a1011 in a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 225  close-output-port");
t3=*((C_word*)lf[128]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1026 in k1023 in a1017 in a1011 in a1005 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1002 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k976 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 228  substring");
t4=*((C_word*)lf[126]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t1,C_fix(0),C_fix(3));}
else{
C_trace("chicken-bug.scm: 229  mail-read");
t3=*((C_word*)lf[125]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k992 in k976 in mail-read in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 228  string->number");
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_964,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_968,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_972,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 218  current-seconds");
t5=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k970 in mail-headers in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 218  seconds->utc-time");
t2=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k966 in mail-headers in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 218  mail-date-str");
t2=*((C_word*)lf[94]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k962 in mail-headers in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 217  string-append");
t2=*((C_word*)lf[71]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[2],lf[119],t1,lf[120],lf[121],lf[122],lf[123]);}

/* mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_768,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_779,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_779(t5,lf[112]);
case C_fix(1):
t5=t4;
f_779(t5,lf[113]);
case C_fix(2):
t5=t4;
f_779(t5,lf[114]);
case C_fix(3):
t5=t4;
f_779(t5,lf[115]);
case C_fix(4):
t5=t4;
f_779(t5,lf[116]);
case C_fix(5):
t5=t4;
f_779(t5,lf[117]);
default:
t5=(C_word)C_eqp(t3,C_fix(6));
t6=t4;
f_779(t6,(C_truep(t5)?lf[118]:C_SCHEME_UNDEFINED));}}

/* k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_fcall f_779(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_779,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_783,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
C_trace("chicken-bug.scm: 193  number->string");
C_number_to_string(3,0,t3,t4);}

/* k909 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 193  string-pad");
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_790,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_790(t4,lf[100]);
case C_fix(1):
t4=t3;
f_790(t4,lf[101]);
case C_fix(2):
t4=t3;
f_790(t4,lf[102]);
case C_fix(3):
t4=t3;
f_790(t4,lf[103]);
case C_fix(4):
t4=t3;
f_790(t4,lf[104]);
case C_fix(5):
t4=t3;
f_790(t4,lf[105]);
case C_fix(6):
t4=t3;
f_790(t4,lf[106]);
case C_fix(7):
t4=t3;
f_790(t4,lf[107]);
case C_fix(8):
t4=t3;
f_790(t4,lf[108]);
case C_fix(9):
t4=t3;
f_790(t4,lf[109]);
case C_fix(10):
t4=t3;
f_790(t4,lf[110]);
default:
t4=(C_word)C_eqp(t2,C_fix(11));
t5=t3;
f_790(t5,(C_truep(t4)?lf[111]:C_SCHEME_UNDEFINED));}}

/* k788 in k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_fcall f_790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_790,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=(C_word)C_a_i_plus(&a,2,C_fix(1900),t3);
C_trace("chicken-bug.scm: 207  number->string");
C_number_to_string(3,0,t2,t4);}

/* k792 in k788 in k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_798,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_826,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
C_trace("chicken-bug.scm: 209  number->string");
C_number_to_string(3,0,t3,t4);}

/* k824 in k792 in k788 in k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 209  string-pad");
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k796 in k792 in k788 in k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_802,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_818,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
C_trace("chicken-bug.scm: 211  number->string");
C_number_to_string(3,0,t3,t4);}

/* k816 in k796 in k792 in k788 in k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 211  string-pad");
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k800 in k796 in k792 in k788 in k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_806,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_810,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
C_trace("chicken-bug.scm: 213  number->string");
C_number_to_string(3,0,t3,t4);}

/* k808 in k800 in k796 in k792 in k788 in k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 213  string-pad");
t2=C_retrieve(lf[99]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k804 in k800 in k796 in k792 in k788 in k781 in k777 in mail-date-str in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 184  string-append");
t2=*((C_word*)lf[71]+1);
((C_proc13)C_retrieve_proc(t2))(13,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[95],((C_word*)t0)[3],lf[96],((C_word*)t0)[2],lf[97],t1,lf[98]);}

/* try-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_727,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_737,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 176  with-output-to-file");
t8=C_retrieve(lf[92]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_752,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_car(t2);
C_trace("chicken-bug.scm: 180  send-mail");
t8=*((C_word*)lf[93]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t6,t7,t5,t4,t3);}}

/* k750 in try-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
C_trace("chicken-bug.scm: 181  try-mail");
t3=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a744 in try-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_745,2,t0,t1);}
C_trace("chicken-bug.scm: 177  print");
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k735 in try-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 178  print");
t3=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[90],((C_word*)t0)[2],lf[91]);}

/* k738 in k735 in try-mail in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 179  print");
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[89],lf[3]);}

/* main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_603,3,t0,t1,t2);}
t3=lf[74];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_607,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_684,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t2);}

/* a683 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_684(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_684,3,t0,t1,t2);}
if(C_truep((C_word)C_i_string_equal_p(lf[81],t2))){
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_696,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_700,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-bug.scm: 130  user-input");
t6=*((C_word*)lf[66]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[83]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[84]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[85]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
C_trace("chicken-bug.scm: 132  usage");
t4=*((C_word*)lf[63]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[86],t2))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_721,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_725,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-bug.scm: 141  read-all");
t7=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}}}

/* k723 in a683 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 138  string-append");
t2=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[87],((C_word*)t0)[2],lf[88],t1);}

/* k719 in a683 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k698 in a683 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 130  string-append");
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[82],t1);}

/* k694 in a683 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_610(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_678,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_682,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-bug.scm: 144  user-input");
t5=*((C_word*)lf[66]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k680 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 144  string-append");
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[80],t1);}

/* k676 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_610(t3,t2);}

/* k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_fcall f_610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_610,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-bug.scm: 145  newline");
t3=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_674,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 146  current-seconds");
t4=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k672 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 146  seconds->local-time");
t2=C_retrieve(lf[79]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_616,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(3));
t3=(C_word)C_i_vector_ref(t1,C_fix(4));
t4=(C_word)C_i_vector_ref(t1,C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_631,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 152  print");
t6=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_666,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-bug.scm: 156  justify");
t8=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k664 in k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_670,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-bug.scm: 156  justify");
t3=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k668 in k664 in k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 156  sprintf");
t2=C_retrieve(lf[78]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[1],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k639 in k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_645,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("chicken-bug.scm: 157  mail-headers");
t3=*((C_word*)lf[77]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k643 in k639 in k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_649,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_651,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 158  with-output-to-string");
t4=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a650 in k643 in k639 in k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_655,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 160  print");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k653 in a650 in k643 in k639 in k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 161  collect-info");
t2=*((C_word*)lf[8]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k647 in k643 in k639 in k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 154  try-mail");
t2=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k629 in k614 in k611 in k608 in k605 in main in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 153  collect-info");
t2=*((C_word*)lf[8]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* justify in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_584,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_588,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 117  number->string");
C_number_to_string(3,0,t3,t2);}

/* k586 in justify in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(1)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
C_trace("chicken-bug.scm: 120  string-append");
t3=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[72],t1);}}

/* user-input in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_569,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_575,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_582,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 104  current-input-port");
t5=*((C_word*)lf[69]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k580 in user-input in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 104  ##sys#tty-port?");
t2=C_retrieve(lf[68]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k573 in user-input in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("chicken-bug.scm: 105  print");
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[67]);}
else{
t2=((C_word*)t0)[2];
f_569(2,t2,C_SCHEME_UNDEFINED);}}

/* k567 in user-input in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 114  read-all");
t2=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* usage in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_556,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_560,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-bug.scm: 89   print");
t4=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[65]);}

/* k558 in usage in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 101  exit");
t2=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_370,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 55   print");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[62]);}

/* k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 56   print");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[61]);}

/* k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_550,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_554,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 57   current-seconds");
t5=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k552 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 57   seconds->string");
t2=C_retrieve(lf[59]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k548 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 57   print");
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[57],t1,lf[58]);}

/* k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_542,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_546,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 58   current-user-id");
t5=C_retrieve(lf[56]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k544 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 58   user-information");
t2=C_retrieve(lf[55]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k540 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 58   printf");
t2=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[54],t1);}

/* k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 59   print");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_538,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 60   machine-type");
t4=C_retrieve(lf[52]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k536 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 60   print");
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_534,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 61   software-type");
t4=C_retrieve(lf[50]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k532 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 61   print");
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[49],t1);}

/* k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 62   software-version");
t4=C_retrieve(lf[48]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k528 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 62   print");
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[47],t1);}

/* k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_526,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 63   build-platform");
t4=C_retrieve(lf[46]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k524 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 63   print");
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[44],t1,lf[45]);}

/* k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_522,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 64   chicken-version");
t4=C_retrieve(lf[43]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k520 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 64   print");
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[41],t1,lf[42]);}

/* k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_518,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 65   chicken-home");
t4=C_retrieve(lf[40]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k516 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 65   print");
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[38],t1,lf[39]);}

/* k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 66   printf");
t3=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[36],C_retrieve(lf[37]));}

/* k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 67   print");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[35]);}

/* k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_473,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_506,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_510,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_514,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("map");
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[33]),C_retrieve(lf[34]));}

/* k512 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 75   sort");
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[31]+1));}

/* k508 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 75   chop");
t2=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k504 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a472 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_473,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_477,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-bug.scm: 70   display");
t4=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[28]);}

/* k475 in a472 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_482,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a481 in k475 in a472 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_482,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_490,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
C_trace("chicken-bug.scm: 73   make-string");
t7=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k488 in a481 in k475 in a472 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 73   printf");
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[25],((C_word*)t0)[2],t1);}

/* k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 76   print");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[23]);}

/* k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_457,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_471,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k469 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 77   make-pathname");
t2=C_retrieve(lf[21]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[22]);}

/* k455 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_459,tmp=(C_word)a,a+=2,tmp);
C_trace("chicken-bug.scm: 77   with-input-from-file");
t3=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a458 in k455 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_467,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 79   read-all");
t3=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k465 in a458 in k455 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 79   display");
t2=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 80   newline");
t3=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_453,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k451 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(t1,lf[16]))){
C_trace("chicken-bug.scm: 81   feature?");
t2=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[18]);}
else{
t2=((C_word*)t0)[2];
f_427(2,t2,C_SCHEME_FALSE);}}

/* k425 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_427,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 82   print");
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[15]);}
else{
t2=((C_word*)t0)[2];
f_421(2,t2,C_SCHEME_UNDEFINED);}}

/* k428 in k425 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_435,tmp=(C_word)a,a+=2,tmp);
C_trace("chicken-bug.scm: 83   with-input-from-pipe");
t3=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[13],t2);}

/* a434 in k428 in k425 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_443,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-bug.scm: 85   read-all");
t3=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k441 in a434 in k428 in k425 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 85   display");
t2=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k419 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 in k374 in k371 in k368 in collect-info in k358 in k355 in k352 in k349 in k346 in k343 in k340 in k337 in k334 in k331 in k328 in k325 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("chicken-bug.scm: 86   newline");
t2=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[163] = {
{"toplevelchicken-bug.scm",(void*)C_toplevel},
{"f_327chicken-bug.scm",(void*)f_327},
{"f_330chicken-bug.scm",(void*)f_330},
{"f_333chicken-bug.scm",(void*)f_333},
{"f_336chicken-bug.scm",(void*)f_336},
{"f_339chicken-bug.scm",(void*)f_339},
{"f_342chicken-bug.scm",(void*)f_342},
{"f_345chicken-bug.scm",(void*)f_345},
{"f_348chicken-bug.scm",(void*)f_348},
{"f_351chicken-bug.scm",(void*)f_351},
{"f_354chicken-bug.scm",(void*)f_354},
{"f_357chicken-bug.scm",(void*)f_357},
{"f_360chicken-bug.scm",(void*)f_360},
{"f_1243chicken-bug.scm",(void*)f_1243},
{"f_1233chicken-bug.scm",(void*)f_1233},
{"f_1239chicken-bug.scm",(void*)f_1239},
{"f_1236chicken-bug.scm",(void*)f_1236},
{"f_1150chicken-bug.scm",(void*)f_1150},
{"f_1154chicken-bug.scm",(void*)f_1154},
{"f_1165chicken-bug.scm",(void*)f_1165},
{"f_1171chicken-bug.scm",(void*)f_1171},
{"f_1230chicken-bug.scm",(void*)f_1230},
{"f_1175chicken-bug.scm",(void*)f_1175},
{"f_1226chicken-bug.scm",(void*)f_1226},
{"f_1178chicken-bug.scm",(void*)f_1178},
{"f_1222chicken-bug.scm",(void*)f_1222},
{"f_1181chicken-bug.scm",(void*)f_1181},
{"f_1218chicken-bug.scm",(void*)f_1218},
{"f_1184chicken-bug.scm",(void*)f_1184},
{"f_1214chicken-bug.scm",(void*)f_1214},
{"f_1187chicken-bug.scm",(void*)f_1187},
{"f_1210chicken-bug.scm",(void*)f_1210},
{"f_1206chicken-bug.scm",(void*)f_1206},
{"f_1190chicken-bug.scm",(void*)f_1190},
{"f_1193chicken-bug.scm",(void*)f_1193},
{"f_1196chicken-bug.scm",(void*)f_1196},
{"f_1199chicken-bug.scm",(void*)f_1199},
{"f_1202chicken-bug.scm",(void*)f_1202},
{"f_1159chicken-bug.scm",(void*)f_1159},
{"f_1129chicken-bug.scm",(void*)f_1129},
{"f_1139chicken-bug.scm",(void*)f_1139},
{"f_1142chicken-bug.scm",(void*)f_1142},
{"f_1060chicken-bug.scm",(void*)f_1060},
{"f_1075chicken-bug.scm",(void*)f_1075},
{"f_1105chicken-bug.scm",(void*)f_1105},
{"f_1117chicken-bug.scm",(void*)f_1117},
{"f_1123chicken-bug.scm",(void*)f_1123},
{"f_1111chicken-bug.scm",(void*)f_1111},
{"f_1081chicken-bug.scm",(void*)f_1081},
{"f_1087chicken-bug.scm",(void*)f_1087},
{"f_1094chicken-bug.scm",(void*)f_1094},
{"f_1097chicken-bug.scm",(void*)f_1097},
{"f_1073chicken-bug.scm",(void*)f_1073},
{"f_1064chicken-bug.scm",(void*)f_1064},
{"f_974chicken-bug.scm",(void*)f_974},
{"f_1006chicken-bug.scm",(void*)f_1006},
{"f_1036chicken-bug.scm",(void*)f_1036},
{"f_1048chicken-bug.scm",(void*)f_1048},
{"f_1054chicken-bug.scm",(void*)f_1054},
{"f_1042chicken-bug.scm",(void*)f_1042},
{"f_1012chicken-bug.scm",(void*)f_1012},
{"f_1018chicken-bug.scm",(void*)f_1018},
{"f_1025chicken-bug.scm",(void*)f_1025},
{"f_1028chicken-bug.scm",(void*)f_1028},
{"f_1004chicken-bug.scm",(void*)f_1004},
{"f_978chicken-bug.scm",(void*)f_978},
{"f_994chicken-bug.scm",(void*)f_994},
{"f_956chicken-bug.scm",(void*)f_956},
{"f_972chicken-bug.scm",(void*)f_972},
{"f_968chicken-bug.scm",(void*)f_968},
{"f_964chicken-bug.scm",(void*)f_964},
{"f_768chicken-bug.scm",(void*)f_768},
{"f_779chicken-bug.scm",(void*)f_779},
{"f_911chicken-bug.scm",(void*)f_911},
{"f_783chicken-bug.scm",(void*)f_783},
{"f_790chicken-bug.scm",(void*)f_790},
{"f_794chicken-bug.scm",(void*)f_794},
{"f_826chicken-bug.scm",(void*)f_826},
{"f_798chicken-bug.scm",(void*)f_798},
{"f_818chicken-bug.scm",(void*)f_818},
{"f_802chicken-bug.scm",(void*)f_802},
{"f_810chicken-bug.scm",(void*)f_810},
{"f_806chicken-bug.scm",(void*)f_806},
{"f_727chicken-bug.scm",(void*)f_727},
{"f_752chicken-bug.scm",(void*)f_752},
{"f_745chicken-bug.scm",(void*)f_745},
{"f_737chicken-bug.scm",(void*)f_737},
{"f_740chicken-bug.scm",(void*)f_740},
{"f_603chicken-bug.scm",(void*)f_603},
{"f_684chicken-bug.scm",(void*)f_684},
{"f_725chicken-bug.scm",(void*)f_725},
{"f_721chicken-bug.scm",(void*)f_721},
{"f_700chicken-bug.scm",(void*)f_700},
{"f_696chicken-bug.scm",(void*)f_696},
{"f_607chicken-bug.scm",(void*)f_607},
{"f_682chicken-bug.scm",(void*)f_682},
{"f_678chicken-bug.scm",(void*)f_678},
{"f_610chicken-bug.scm",(void*)f_610},
{"f_613chicken-bug.scm",(void*)f_613},
{"f_674chicken-bug.scm",(void*)f_674},
{"f_616chicken-bug.scm",(void*)f_616},
{"f_666chicken-bug.scm",(void*)f_666},
{"f_670chicken-bug.scm",(void*)f_670},
{"f_641chicken-bug.scm",(void*)f_641},
{"f_645chicken-bug.scm",(void*)f_645},
{"f_651chicken-bug.scm",(void*)f_651},
{"f_655chicken-bug.scm",(void*)f_655},
{"f_649chicken-bug.scm",(void*)f_649},
{"f_631chicken-bug.scm",(void*)f_631},
{"f_584chicken-bug.scm",(void*)f_584},
{"f_588chicken-bug.scm",(void*)f_588},
{"f_565chicken-bug.scm",(void*)f_565},
{"f_582chicken-bug.scm",(void*)f_582},
{"f_575chicken-bug.scm",(void*)f_575},
{"f_569chicken-bug.scm",(void*)f_569},
{"f_556chicken-bug.scm",(void*)f_556},
{"f_560chicken-bug.scm",(void*)f_560},
{"f_366chicken-bug.scm",(void*)f_366},
{"f_370chicken-bug.scm",(void*)f_370},
{"f_373chicken-bug.scm",(void*)f_373},
{"f_554chicken-bug.scm",(void*)f_554},
{"f_550chicken-bug.scm",(void*)f_550},
{"f_376chicken-bug.scm",(void*)f_376},
{"f_546chicken-bug.scm",(void*)f_546},
{"f_542chicken-bug.scm",(void*)f_542},
{"f_379chicken-bug.scm",(void*)f_379},
{"f_382chicken-bug.scm",(void*)f_382},
{"f_538chicken-bug.scm",(void*)f_538},
{"f_385chicken-bug.scm",(void*)f_385},
{"f_534chicken-bug.scm",(void*)f_534},
{"f_388chicken-bug.scm",(void*)f_388},
{"f_530chicken-bug.scm",(void*)f_530},
{"f_391chicken-bug.scm",(void*)f_391},
{"f_526chicken-bug.scm",(void*)f_526},
{"f_394chicken-bug.scm",(void*)f_394},
{"f_522chicken-bug.scm",(void*)f_522},
{"f_397chicken-bug.scm",(void*)f_397},
{"f_518chicken-bug.scm",(void*)f_518},
{"f_400chicken-bug.scm",(void*)f_400},
{"f_403chicken-bug.scm",(void*)f_403},
{"f_406chicken-bug.scm",(void*)f_406},
{"f_514chicken-bug.scm",(void*)f_514},
{"f_510chicken-bug.scm",(void*)f_510},
{"f_506chicken-bug.scm",(void*)f_506},
{"f_473chicken-bug.scm",(void*)f_473},
{"f_477chicken-bug.scm",(void*)f_477},
{"f_482chicken-bug.scm",(void*)f_482},
{"f_490chicken-bug.scm",(void*)f_490},
{"f_409chicken-bug.scm",(void*)f_409},
{"f_412chicken-bug.scm",(void*)f_412},
{"f_471chicken-bug.scm",(void*)f_471},
{"f_457chicken-bug.scm",(void*)f_457},
{"f_459chicken-bug.scm",(void*)f_459},
{"f_467chicken-bug.scm",(void*)f_467},
{"f_415chicken-bug.scm",(void*)f_415},
{"f_418chicken-bug.scm",(void*)f_418},
{"f_453chicken-bug.scm",(void*)f_453},
{"f_427chicken-bug.scm",(void*)f_427},
{"f_430chicken-bug.scm",(void*)f_430},
{"f_435chicken-bug.scm",(void*)f_435},
{"f_443chicken-bug.scm",(void*)f_443},
{"f_421chicken-bug.scm",(void*)f_421},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
