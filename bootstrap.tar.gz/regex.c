/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-10-29 11:59
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: regex.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -include-path ./pcre -output-file regex.c
   unit: regex
*/

#include "chicken.h"

#include "pcre.h"

static const char *C_regex_error;
static int C_regex_error_offset;


#define OVECTOR_LENGTH_MULTIPLE 3
#define STATIC_OVECTOR_LEN 256
static int C_regex_ovector[OVECTOR_LENGTH_MULTIPLE * STATIC_OVECTOR_LEN];


static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[108];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,99,104,101,99,107,45,99,104,97,114,100,101,102,45,116,97,98,108,101,32,120,51,50,32,108,111,99,51,51,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,21),40,112,99,114,101,45,111,112,116,105,111,110,45,62,110,117,109,98,101,114,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,111,112,116,115,57,56,32,111,112,116,57,57,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,29),40,112,99,114,101,45,111,112,116,105,111,110,115,45,62,110,117,109,98,101,114,32,111,112,116,115,57,52,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,22),40,114,101,45,102,105,110,97,108,105,122,101,114,32,97,49,48,52,49,48,56,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,20),40,102,95,49,49,55,52,32,120,49,51,48,32,116,97,103,49,51,49,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,27),40,114,101,103,101,120,45,99,104,97,114,100,101,102,45,116,97,98,108,101,63,32,120,49,50,56,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,22),40,102,95,49,49,57,55,32,112,116,114,49,52,55,32,116,97,103,49,52,56,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,38),40,114,101,45,109,97,107,101,45,99,104,97,114,100,101,102,45,116,97,98,108,101,45,116,121,112,101,32,116,97,98,108,101,115,49,52,53,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,33),40,114,101,103,101,120,45,99,104,97,114,100,101,102,45,116,97,98,108,101,32,46,32,116,109,112,49,53,57,49,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,102,95,49,50,54,50,32,120,49,56,50,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,114,101,103,101,120,112,63,32,120,49,56,48,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,34),40,114,101,45,101,114,114,111,114,32,108,111,99,49,57,49,32,109,115,103,49,57,50,32,46,32,97,114,103,115,49,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,36),40,114,101,45,99,111,109,112,105,108,101,32,97,49,57,56,50,48,50,32,97,49,57,55,50,48,51,32,97,49,57,54,50,48,52,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,59),40,114,101,45,99,104,101,99,107,101,100,45,99,111,109,112,105,108,101,32,112,97,116,116,101,114,110,50,49,50,32,111,112,116,105,111,110,115,50,49,51,32,116,97,98,108,101,115,50,49,52,32,108,111,99,50,49,53,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,17),40,97,49,51,51,48,32,105,50,51,50,32,111,50,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,18),40,111,112,116,105,111,110,115,45,62,105,110,116,101,103,101,114,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,16),40,102,95,49,51,52,51,32,99,111,100,101,50,51,54,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,32),40,114,101,103,101,120,112,32,112,97,116,116,101,114,110,50,50,55,32,46,32,111,112,116,105,111,110,115,50,50,56,41};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,95,49,51,55,54,32,99,111,100,101,50,54,54,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,50,53,49,32,111,112,116,105,111,110,115,50,54,49,32,116,97,98,108,101,115,50,54,50,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,30),40,100,101,102,45,116,97,98,108,101,115,50,53,52,32,37,111,112,116,105,111,110,115,50,52,57,50,55,52,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,111,112,116,105,111,110,115,50,53,51,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,30),40,114,101,103,101,120,112,42,32,112,97,116,116,101,114,110,50,52,49,32,46,32,97,114,103,115,50,52,50,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,18),40,114,101,45,115,116,117,100,121,32,97,50,56,56,50,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,23),40,102,95,49,52,55,52,32,114,120,51,49,48,32,101,120,116,114,97,51,49,49,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,14),40,102,95,49,52,56,57,32,114,120,51,48,48,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,23),40,114,101,103,101,120,112,45,111,112,116,105,109,105,122,101,32,114,120,50,57,55,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,27),40,111,118,101,99,116,111,114,45,115,116,97,114,116,45,114,101,102,32,97,51,50,49,51,50,52,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,25),40,111,118,101,99,116,111,114,45,101,110,100,45,114,101,102,32,97,51,50,55,51,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,52,51,41,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,35),40,103,97,116,104,101,114,45,114,101,115,117,108,116,45,112,111,115,105,116,105,111,110,115,32,114,101,115,117,108,116,51,51,52,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,97,49,53,57,50,32,112,111,115,115,51,54,56,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,33),40,103,97,116,104,101,114,45,114,101,115,117,108,116,115,32,115,116,114,51,54,49,32,114,101,115,117,108,116,51,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,58),40,114,101,45,109,97,116,99,104,32,97,51,55,56,51,56,50,32,97,51,55,55,51,56,51,32,97,51,55,54,51,56,52,32,97,51,55,53,51,56,53,32,97,51,55,52,51,56,54,32,97,51,55,51,51,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,40),40,114,101,45,109,97,116,99,104,45,99,97,112,116,117,114,101,45,99,111,117,110,116,32,97,51,57,51,51,57,55,32,97,51,57,50,51,57,56,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,102,95,49,54,57,50,32,114,120,52,50,57,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,14),40,102,95,49,54,57,55,32,114,120,52,50,55,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,14),40,102,95,49,55,48,50,32,114,120,52,50,53,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,13),40,102,95,49,55,49,48,32,120,52,50,51,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,49),40,112,101,114,102,111,114,109,45,109,97,116,99,104,32,114,103,120,112,52,48,52,32,115,116,114,52,48,53,32,115,105,52,48,54,32,114,105,52,48,55,32,108,111,99,52,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,46),40,112,114,101,112,97,114,101,45,109,97,116,99,104,32,114,103,120,112,52,52,55,32,115,116,114,52,52,56,32,115,116,97,114,116,52,52,57,32,108,111,99,52,53,48,41,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,40),40,115,116,114,105,110,103,45,109,97,116,99,104,32,114,103,120,112,52,53,54,32,115,116,114,52,53,55,32,46,32,115,116,97,114,116,52,53,56,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,50),40,115,116,114,105,110,103,45,109,97,116,99,104,45,112,111,115,105,116,105,111,110,115,32,114,103,120,112,52,54,48,32,115,116,114,52,54,49,32,46,32,115,116,97,114,116,52,54,50,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,57),40,112,114,101,112,97,114,101,45,115,101,97,114,99,104,32,114,103,120,112,52,55,49,32,115,116,114,52,55,50,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,52,55,51,32,108,111,99,52,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,51),40,115,116,114,105,110,103,45,115,101,97,114,99,104,32,114,103,120,112,52,56,57,32,115,116,114,52,57,48,32,46,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,52,57,49,41,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,61),40,115,116,114,105,110,103,45,115,101,97,114,99,104,45,112,111,115,105,116,105,111,110,115,32,114,103,120,112,52,57,51,32,115,116,114,52,57,52,32,46,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,52,57,53,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,31),40,102,95,49,57,53,49,32,115,116,97,114,116,53,52,57,32,102,114,111,109,53,53,48,32,116,111,53,53,49,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,31),40,102,95,49,57,53,54,32,115,116,97,114,116,53,53,51,32,102,114,111,109,53,53,52,32,116,111,53,53,53,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,109,115,53,54,49,32,115,116,97,114,116,53,54,50,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,102,95,49,57,54,55,32,109,115,53,50,53,32,115,116,97,114,116,53,50,54,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,23),40,102,95,49,57,56,55,32,109,115,53,50,56,32,115,116,97,114,116,53,50,57,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,49,51,32,109,115,53,51,49,32,115,116,97,114,116,53,51,50,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,56),40,115,116,114,105,110,103,45,115,112,108,105,116,45,102,105,101,108,100,115,32,114,103,120,112,53,48,52,32,115,116,114,53,48,53,32,46,32,109,111,100,101,45,97,110,100,45,115,116,97,114,116,53,48,54,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,6),40,112,117,115,104,41,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,116,97,114,116,54,48,57,32,105,110,100,101,120,54,49,48,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,23),40,115,117,98,115,116,105,116,117,116,101,32,109,97,116,99,104,101,115,54,48,53,41,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,110,100,101,120,54,50,55,32,99,111,117,110,116,54,50,56,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,57),40,115,116,114,105,110,103,45,115,117,98,115,116,105,116,117,116,101,32,114,101,103,101,120,53,56,51,32,115,117,98,115,116,53,56,52,32,115,116,114,105,110,103,53,56,53,32,46,32,102,108,97,103,53,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,115,116,114,54,56,48,32,115,109,97,112,54,56,49,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,45),40,115,116,114,105,110,103,45,115,117,98,115,116,105,116,117,116,101,42,32,115,116,114,54,55,48,32,115,109,97,112,54,55,49,32,46,32,109,111,100,101,54,55,50,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,105,100,120,54,57,53,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,14),40,103,108,111,98,63,32,115,116,114,54,57,49,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,50,32,114,101,115,116,55,53,57,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,99,115,55,52,49,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,45,62,114,101,103,101,120,112,32,115,55,51,55,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,56,48,53,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,21),40,103,114,101,112,32,114,103,120,112,56,48,48,32,108,115,116,56,48,49,41,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,50,52,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,22),40,114,101,103,101,120,112,45,101,115,99,97,112,101,32,115,116,114,56,49,55,41,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,25),40,102,95,50,56,49,56,32,114,120,56,56,48,32,111,112,116,105,111,110,115,56,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,14),40,102,95,50,56,51,49,32,114,120,56,56,51,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,56,53,50,32,110,111,115,56,54,50,32,110,111,101,56,54,51,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,110,111,101,56,53,53,32,37,110,111,115,56,53,48,56,57,48,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,110,111,115,56,53,52,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,97,110,99,104,111,114,101,100,45,112,97,116,116,101,114,110,32,114,103,120,112,56,52,50,32,46,32,97,114,103,115,56,52,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k1639 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub394(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub394(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
int cc;pcre_fullinfo(code, extra, PCRE_INFO_CAPTURECOUNT, &cc);return(cc + 1);
C_ret:
#undef return

return C_r;}

/* from k1625 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub379(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub379(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
void * str=(void * )C_data_pointer(C_a2);
int start=(int )C_unfix(C_a3);
int range=(int )C_unfix(C_a4);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a5);
return(pcre_exec(code, extra, str, start + range, start, options, C_regex_ovector, STATIC_OVECTOR_LEN * OVECTOR_LENGTH_MULTIPLE));
C_ret:
#undef return

return C_r;}

/* from k1505 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub328(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub328(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[(i * 2) + 1]);
C_ret:
#undef return

return C_r;}

/* from k1498 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub322(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub322(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[i * 2]);
C_ret:
#undef return

return C_r;}

/* from k1447 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub289(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub289(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
return(pcre_study(code, 0, &C_regex_error));
C_ret:
#undef return

return C_r;}

/* from k1293 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub199(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub199(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * patt=(char * )C_c_string(C_a0);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a1);
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a2);
return(pcre_compile(patt, options, &C_regex_error, &C_regex_error_offset, tables));
C_ret:
#undef return

return C_r;}

/* from re-maketables */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub140(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub140(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
return (pcre_maketables ());
C_ret:
#undef return

return C_r;}

/* from k1162 */
static C_word C_fcall stub105(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub105(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2847)
static void C_fcall f_2847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_fcall f_2842(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2786)
static void C_fcall f_2786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2735)
static void C_ccall f_2735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_fcall f_2743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2697)
static void C_fcall f_2697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_fcall f_2428(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_fcall f_2490(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2520)
static void C_fcall f_2520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_fcall f_2549(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_ccall f_2597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2339)
static void C_fcall f_2339(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2358)
static void C_fcall f_2358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2289)
static void C_fcall f_2289(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2167)
static void C_fcall f_2167(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_fcall f_2061(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2067)
static void C_fcall f_2067(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static C_word C_fcall f_2046(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1868)
static void C_fcall f_1868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_fcall f_1876(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_fcall f_1783(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1796)
static void C_fcall f_1796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1697)
static void C_ccall f_1697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1527)
static void C_fcall f_1527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1561)
static void C_fcall f_1561(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1396)
static void C_fcall f_1396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_fcall f_1391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1358)
static void C_fcall f_1358(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_fcall f_1321(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1268)
static void C_ccall f_1268r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1280)
static void C_ccall f_1280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1262)
static void C_ccall f_1262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_fcall f_1192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1201)
static void C_ccall f_1201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1125)
static void C_fcall f_1125(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_960)
static C_word C_fcall f_960(C_word *a,C_word t0);
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2847)
static void C_fcall trf_2847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2847(t0,t1);}

C_noret_decl(trf_2842)
static void C_fcall trf_2842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2842(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2842(t0,t1,t2);}

C_noret_decl(trf_2786)
static void C_fcall trf_2786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2786(t0,t1,t2,t3);}

C_noret_decl(trf_2743)
static void C_fcall trf_2743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2743(t0,t1,t2);}

C_noret_decl(trf_2697)
static void C_fcall trf_2697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2697(t0,t1,t2);}

C_noret_decl(trf_2428)
static void C_fcall trf_2428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2428(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2428(t0,t1,t2);}

C_noret_decl(trf_2490)
static void C_fcall trf_2490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2490(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2490(t0,t1,t2);}

C_noret_decl(trf_2520)
static void C_fcall trf_2520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2520(t0,t1);}

C_noret_decl(trf_2549)
static void C_fcall trf_2549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2549(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2549(t0,t1);}

C_noret_decl(trf_2339)
static void C_fcall trf_2339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2339(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2339(t0,t1,t2);}

C_noret_decl(trf_2358)
static void C_fcall trf_2358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2358(t0,t1);}

C_noret_decl(trf_2289)
static void C_fcall trf_2289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2289(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2289(t0,t1,t2,t3);}

C_noret_decl(trf_2167)
static void C_fcall trf_2167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2167(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2167(t0,t1,t2,t3);}

C_noret_decl(trf_2061)
static void C_fcall trf_2061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2061(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2061(t0,t1,t2);}

C_noret_decl(trf_2067)
static void C_fcall trf_2067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2067(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2067(t0,t1,t2,t3);}

C_noret_decl(trf_1868)
static void C_fcall trf_1868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1868(t0,t1);}

C_noret_decl(trf_1876)
static void C_fcall trf_1876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1876(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1876(t0,t1,t2,t3);}

C_noret_decl(trf_1783)
static void C_fcall trf_1783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1783(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1783(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1796)
static void C_fcall trf_1796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1796(t0,t1);}

C_noret_decl(trf_1718)
static void C_fcall trf_1718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1718(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1718(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1527)
static void C_fcall trf_1527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1527(t0,t1,t2);}

C_noret_decl(trf_1561)
static void C_fcall trf_1561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1561(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1561(t0,t1);}

C_noret_decl(trf_1396)
static void C_fcall trf_1396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1396(t0,t1);}

C_noret_decl(trf_1391)
static void C_fcall trf_1391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1391(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1391(t0,t1,t2);}

C_noret_decl(trf_1358)
static void C_fcall trf_1358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1358(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1358(t0,t1,t2,t3);}

C_noret_decl(trf_1321)
static void C_fcall trf_1321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1321(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1321(t0,t1);}

C_noret_decl(trf_1192)
static void C_fcall trf_1192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1192(t0,t1);}

C_noret_decl(trf_1125)
static void C_fcall trf_1125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1125(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1125(t0,t1);}

C_noret_decl(trf_1131)
static void C_fcall trf_1131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1131(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1131(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(6);
if(!C_demand(6)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(919)){
C_save(t1);
C_rereclaim2(919*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(6);
C_initialize_lf(lf,108);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],23,"\003syscheck-chardef-table");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000-invalid character definition tables structure");
lf[5]=C_h_intern(&lf[5],20,"regex-chardef-table\077");
lf[7]=C_h_intern(&lf[7],8,"caseless");
lf[8]=C_h_intern(&lf[8],9,"multiline");
lf[9]=C_h_intern(&lf[9],6,"dotall");
lf[10]=C_h_intern(&lf[10],8,"extended");
lf[11]=C_h_intern(&lf[11],8,"anchored");
lf[12]=C_h_intern(&lf[12],14,"dollar-endonly");
lf[13]=C_h_intern(&lf[13],5,"extra");
lf[14]=C_h_intern(&lf[14],6,"notbol");
lf[15]=C_h_intern(&lf[15],6,"noteol");
lf[16]=C_h_intern(&lf[16],8,"ungreedy");
lf[17]=C_h_intern(&lf[17],8,"notempty");
lf[18]=C_h_intern(&lf[18],4,"utf8");
lf[19]=C_h_intern(&lf[19],15,"no-auto-capture");
lf[20]=C_h_intern(&lf[20],13,"no-utf8-check");
lf[21]=C_h_intern(&lf[21],12,"auto-callout");
lf[22]=C_h_intern(&lf[22],7,"partial");
lf[23]=C_h_intern(&lf[23],12,"dfa-shortest");
lf[24]=C_h_intern(&lf[24],11,"dfa-restart");
lf[25]=C_h_intern(&lf[25],9,"firstline");
lf[26]=C_h_intern(&lf[26],8,"dupnames");
lf[27]=C_h_intern(&lf[27],10,"newline-cr");
lf[28]=C_h_intern(&lf[28],10,"newline-lf");
lf[29]=C_h_intern(&lf[29],12,"newline-crlf");
lf[30]=C_h_intern(&lf[30],11,"newline-any");
lf[31]=C_h_intern(&lf[31],15,"newline-anycrlf");
lf[32]=C_h_intern(&lf[32],11,"bsr-anycrlf");
lf[33]=C_h_intern(&lf[33],11,"bsr-unicode");
lf[35]=C_h_intern(&lf[35],12,"re-finalizer");
lf[36]=C_h_intern(&lf[36],13,"chardef-table");
lf[37]=C_h_intern(&lf[37],23,"\003sysmake-tagged-pointer");
lf[38]=C_h_intern(&lf[38],19,"regex-chardef-table");
lf[39]=C_h_intern(&lf[39],15,"\003syssignal-hook");
lf[40]=C_h_intern(&lf[40],11,"\000type-error");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[42]=C_h_intern(&lf[42],14,"set-finalizer!");
lf[43]=C_h_intern(&lf[43],14,"\003syserror-hook");
lf[44]=C_h_intern(&lf[44],7,"regexp\077");
lf[45]=C_h_intern(&lf[45],6,"regexp");
lf[46]=C_h_intern(&lf[46],13,"string-append");
lf[47]=C_h_intern(&lf[47],8,"re-error");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[49]=C_h_intern(&lf[49],17,"\003syspeek-c-string");
lf[50]=C_h_intern(&lf[50],10,"re-compile");
lf[51]=C_h_intern(&lf[51],17,"\003sysmake-c-string");
lf[52]=C_h_intern(&lf[52],18,"re-checked-compile");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000!cannot compile regular expression");
lf[54]=C_h_intern(&lf[54],4,"zero");
lf[55]=C_h_intern(&lf[55],3,"map");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010caseless\376\003\000\000\002\376\001\000\000\010extended\376\003\000\000\002\376\001\000\000\004utf8\376\377\016");
lf[57]=C_h_intern(&lf[57],7,"regexp*");
lf[58]=C_h_intern(&lf[58],8,"re-study");
lf[59]=C_h_intern(&lf[59],15,"regexp-optimize");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot optimize regular expression");
lf[61]=C_h_intern(&lf[61],17,"ovector-start-ref");
lf[62]=C_h_intern(&lf[62],15,"ovector-end-ref");
lf[63]=C_h_intern(&lf[63],23,"gather-result-positions");
lf[64]=C_h_intern(&lf[64],9,"substring");
lf[65]=C_h_intern(&lf[65],14,"gather-results");
lf[66]=C_h_intern(&lf[66],7,"\003sysmap");
lf[67]=C_h_intern(&lf[67],8,"re-match");
lf[68]=C_h_intern(&lf[68],22,"re-match-capture-count");
lf[69]=C_h_intern(&lf[69],13,"perform-match");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\077bad argument type - not a string or compiled regular expression");
lf[71]=C_h_intern(&lf[71],12,"string-match");
lf[72]=C_h_intern(&lf[72],22,"string-match-positions");
lf[73]=C_h_intern(&lf[73],21,"make-anchored-pattern");
lf[74]=C_h_intern(&lf[74],13,"string-search");
lf[75]=C_h_intern(&lf[75],23,"string-search-positions");
lf[76]=C_h_intern(&lf[76],7,"reverse");
lf[77]=C_h_intern(&lf[77],19,"string-split-fields");
lf[78]=C_h_intern(&lf[78],6,"\000infix");
lf[79]=C_h_intern(&lf[79],7,"\000suffix");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[82]=C_h_intern(&lf[82],11,"make-string");
lf[83]=C_h_intern(&lf[83],17,"string-substitute");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[85]=C_h_intern(&lf[85],21,"\003sysfragments->string");
lf[86]=C_h_intern(&lf[86],18,"string-substitute*");
lf[87]=C_h_intern(&lf[87],5,"glob\077");
lf[88]=C_h_intern(&lf[88],12,"list->string");
lf[89]=C_h_intern(&lf[89],12,"string->list");
lf[90]=C_h_intern(&lf[90],12,"glob->regexp");
lf[91]=C_h_intern(&lf[91],10,"\003sysappend");
lf[92]=C_h_intern(&lf[92],5,"error");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[94]=C_h_intern(&lf[94],4,"grep");
lf[95]=C_h_intern(&lf[95],18,"open-output-string");
lf[96]=C_h_intern(&lf[96],17,"get-output-string");
lf[97]=C_h_intern(&lf[97],13,"regexp-escape");
lf[98]=C_h_intern(&lf[98],16,"\003syswrite-char-0");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001^");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\001$");
lf[103]=C_h_intern(&lf[103],7,"warning");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000<cannot select partial anchor for compiled regular expression");
lf[105]=C_h_intern(&lf[105],17,"register-feature!");
lf[106]=C_h_intern(&lf[106],5,"regex");
lf[107]=C_h_intern(&lf[107],4,"pcre");
C_register_lf2(lf,108,create_ptable());
t2=C_mutate(&lf[0] /* (set! c171 ...) */,lf[1]);
t3=C_mutate((C_word*)lf[2]+1 /* (set! check-chardef-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_945,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_958,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 94   register-feature! */
t5=*((C_word*)lf[105]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[106],lf[107]);}

/* k956 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word ab[125],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=C_mutate(&lf[6] /* (set! pcre-option->number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_960,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[34] /* (set! pcre-options->number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1125,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[35]+1 /* (set! re-finalizer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1159,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! regex-chardef-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1169,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1192,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t7=C_mutate((C_word*)lf[38]+1 /* (set! regex-chardef-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1202,a[2]=t6,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t8=C_mutate((C_word*)lf[44]+1 /* (set! regexp? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1257,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[46]+1);
t10=C_mutate((C_word*)lf[47]+1 /* (set! re-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1268,a[2]=t9,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[50]+1 /* (set! re-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1282,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[52]+1 /* (set! re-checked-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1304,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[45]+1 /* (set! regexp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[57]+1 /* (set! regexp* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1356,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[58]+1 /* (set! re-study ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[59]+1 /* (set! regexp-optimize ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[61]+1 /* (set! ovector-start-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[62]+1 /* (set! ovector-end-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[63]+1 /* (set! gather-result-positions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1509,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t20=*((C_word*)lf[64]+1);
t21=C_mutate((C_word*)lf[65]+1 /* (set! gather-results ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1581,a[2]=t20,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t22=C_mutate((C_word*)lf[67]+1 /* (set! re-match ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1602,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[68]+1 /* (set! re-match-capture-count ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1632,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[69]+1 /* (set! perform-match ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(lf[71] /* string-match */,0,C_SCHEME_UNDEFINED);
t26=C_set_block_item(lf[72] /* string-match-positions */,0,C_SCHEME_UNDEFINED);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
t28=C_mutate((C_word*)lf[71]+1 /* (set! string-match ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1761,a[2]=t27,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t29=C_mutate((C_word*)lf[72]+1 /* (set! string-match-positions ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1771,a[2]=t27,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp));
t30=C_set_block_item(lf[74] /* string-search */,0,C_SCHEME_UNDEFINED);
t31=C_set_block_item(lf[75] /* string-search-positions */,0,C_SCHEME_UNDEFINED);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1783,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t33=C_mutate((C_word*)lf[74]+1 /* (set! string-search ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1829,a[2]=t32,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp));
t34=C_mutate((C_word*)lf[75]+1 /* (set! string-search-positions ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1839,a[2]=t32,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t35=*((C_word*)lf[76]+1);
t36=*((C_word*)lf[64]+1);
t37=*((C_word*)lf[75]+1);
t38=C_mutate((C_word*)lf[77]+1 /* (set! string-split-fields ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1849,a[2]=t35,a[3]=t37,a[4]=t36,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t39=*((C_word*)lf[64]+1);
t40=*((C_word*)lf[76]+1);
t41=*((C_word*)lf[82]+1);
t42=*((C_word*)lf[75]+1);
t43=C_mutate((C_word*)lf[83]+1 /* (set! string-substitute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2031,a[2]=t42,a[3]=t40,a[4]=t39,a[5]=((C_word)li58),tmp=(C_word)a,a+=6,tmp));
t44=*((C_word*)lf[83]+1);
t45=C_mutate((C_word*)lf[86]+1 /* (set! string-substitute* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2274,a[2]=t44,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[87]+1 /* (set! glob? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t47=*((C_word*)lf[88]+1);
t48=*((C_word*)lf[89]+1);
t49=C_mutate((C_word*)lf[90]+1 /* (set! glob->regexp ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2411,a[2]=t48,a[3]=t47,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t50=*((C_word*)lf[74]+1);
t51=C_mutate((C_word*)lf[94]+1 /* (set! grep ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2688,a[2]=t50,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp));
t52=*((C_word*)lf[95]+1);
t53=*((C_word*)lf[96]+1);
t54=C_mutate((C_word*)lf[97]+1 /* (set! regexp-escape ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2728,a[2]=t52,a[3]=t53,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp));
t55=*((C_word*)lf[46]+1);
t56=C_mutate((C_word*)lf[73]+1 /* (set! make-anchored-pattern ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t55,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));
t57=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t57+1)))(2,t57,C_SCHEME_UNDEFINED);}

/* make-anchored-pattern in k956 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2784r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2784r(t0,t1,t2,t3);}}

static void C_ccall f_2784r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2842,a[2]=t4,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2847,a[2]=t5,a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-nos854893 */
t7=t6;
f_2847(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-noe855889 */
t9=t5;
f_2842(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body852861 */
t11=t4;
f_2786(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-nos854 in make-anchored-pattern in k956 */
static void C_fcall f_2847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2847,NULL,2,t0,t1);}
/* def-noe855889 */
t2=((C_word*)t0)[2];
f_2842(t2,t1,C_SCHEME_FALSE);}

/* def-noe855 in make-anchored-pattern in k956 */
static void C_fcall f_2842(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2842,NULL,3,t0,t1,t2);}
/* body852861 */
t3=((C_word*)t0)[2];
f_2786(t3,t1,t2,C_SCHEME_FALSE);}

/* body852 in make-anchored-pattern in k956 */
static void C_fcall f_2786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2786,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t4=(C_truep(t2)?lf[99]:lf[100]);
t5=(C_truep(t3)?lf[101]:lf[102]);
/* regex.scm: 665  string-append */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t4,((C_word*)t0)[3],t5);}
else{
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[45],lf[73]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=(C_truep(t6)?t6:t3);
if(C_truep(t7)){
/* regex.scm: 669  warning */
t8=*((C_word*)lf[103]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,lf[73],lf[104]);}
else{
t8=t5;
f_2810(2,t8,C_SCHEME_UNDEFINED);}}}

/* k2808 in body852 in make-anchored-pattern in k956 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2831,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[45]+1));}

/* f_2831 in k2808 in body852 in make-anchored-pattern in k956 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2831,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2824 in k2808 in body852 in make-anchored-pattern in k956 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[439],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=f_960(C_a_i(&a,432),lf[11]);
t3=(C_word)C_a_i_plus(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2818,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* f_2818 in k2824 in k2808 in body852 in make-anchored-pattern in k956 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2818,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t2,C_fix(3),t3));}

/* k2811 in k2808 in body852 in make-anchored-pattern in k956 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* regexp-escape in k956 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2728,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2735,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 644  open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2733 in regexp-escape in k956 */
static void C_ccall f_2735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2735,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2743,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word)li68),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2743(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k2733 in regexp-escape in k956 */
static void C_fcall f_2743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2743,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* regex.scm: 647  get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2762,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 650  ##sys#write-char-0 */
t5=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2775,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 654  ##sys#write-char-0 */
t5=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k2773 in loop in k2733 in regexp-escape in k956 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 655  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2743(t3,((C_word*)t0)[2],t2);}

/* k2760 in loop in k2733 in regexp-escape in k956 */
static void C_ccall f_2762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2765,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 651  ##sys#write-char-0 */
t3=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k2763 in k2760 in loop in k2733 in regexp-escape in k956 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 652  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2743(t3,((C_word*)t0)[2],t2);}

/* grep in k956 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2688,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[94]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2697,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2697(t8,t1,t3);}

/* loop in grep in k956 */
static void C_fcall f_2697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2697,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2716,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 632  string-search */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k2714 in loop in grep in k956 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 633  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2697(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 634  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2697(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2721 in k2714 in loop in grep in k956 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2723,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k956 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2411,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2422,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2426,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 593  string->list */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k2424 in glob->regexp in k956 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2426,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2428,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2428(t5,((C_word*)t0)[2],t1);}

/* loop in k2424 in glob->regexp in k956 */
static void C_fcall f_2428(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(31);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2428,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2458,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2462,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 598  loop */
t18=t6;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 599  loop */
t18=t5;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2488,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2490,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2490(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2668,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 617  loop */
t18=t7;
t19=t4;
t1=t18;
t2=t19;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2679,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2683,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 618  loop */
t18=t8;
t19=t4;
t1=t18;
t2=t19;
goto loop;}}}}

/* k2681 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2677 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k2666 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k2424 in glob->regexp in k956 */
static void C_fcall f_2490(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2490,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(C_make_character(93),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2510,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* regex.scm: 606  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2428(t7,t5,t6);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(C_make_character(45),t6);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=t5;
f_2520(t9,(C_word)C_i_pairp(t8));}
else{
t8=t5;
f_2520(t8,C_SCHEME_FALSE);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2518 in loop2 in loop in k2424 in glob->regexp in k956 */
static void C_fcall f_2520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2520,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2539,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* regex.scm: 608  loop2 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2490(t6,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=t2;
f_2549(t6,(C_word)C_eqp(C_make_character(45),t5));}
else{
t5=t2;
f_2549(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_2549(t4,C_SCHEME_FALSE);}}}

/* k2547 in k2518 in loop2 in loop in k2424 in glob->regexp in k956 */
static void C_fcall f_2549(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2549,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2572,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2576,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* regex.scm: 612  loop2 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_2490(t7,t5,t6);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2597,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* regex.scm: 614  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2490(t5,t3,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* regex.scm: 616  error */
t2=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[90],lf[93],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}}

/* k2595 in k2547 in k2518 in loop2 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2597,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2574 in k2547 in k2518 in loop2 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2570 in k2547 in k2518 in loop2 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2572,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2537 in k2518 in loop2 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2533 in k2518 in loop2 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k2508 in loop2 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* k2486 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k2473 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k2460 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2456 in loop in k2424 in glob->regexp in k956 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k2420 in glob->regexp in k956 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 592  list->string */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k956 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2326,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2339,a[2]=t7,a[3]=t2,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2339(t9,t1,t5);}

/* loop in glob? in k956 */
static void C_fcall f_2339(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2339,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_2358(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_2358(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2356 in loop in glob? in k956 */
static void C_fcall f_2358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 583  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_2339(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 585  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2339(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k956 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2274r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2274r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2274r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_string_2(t2,lf[86]);
t6=(C_word)C_i_check_list_2(t3,lf[86]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2289,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2289(t12,t1,t2,t3);}

/* loop in string-substitute* in k956 */
static void C_fcall f_2289(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2289,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2306,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_cdr(t4);
/* regex.scm: 568  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k2304 in loop in string-substitute* in k956 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* regex.scm: 568  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2289(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k956 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+34)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2031r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2031r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2031r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(34);
t6=(C_word)C_i_check_string_2(t3,lf[83]);
t7=(C_word)C_notvemptyp(t5);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t5,C_fix(0)):C_fix(1));
t9=(C_word)C_block_size(t3);
t10=(C_word)C_fixnum_difference(t9,C_fix(1));
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_fix(0);
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2046,a[2]=t14,a[3]=t12,a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2061,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t15,a[7]=t10,a[8]=((C_word)li56),tmp=(C_word)a,a+=9,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=((C_word*)t0)[3],a[5]=t14,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=t16,a[9]=t18,a[10]=t15,a[11]=t8,a[12]=t2,a[13]=((C_word)li57),tmp=(C_word)a,a+=14,tmp));
t20=((C_word*)t18)[1];
f_2167(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k956 */
static void C_fcall f_2167(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2167,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* regex.scm: 539  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[12],((C_word*)t0)[6],t2);}

/* k2169 in loop in string-substitute in k956 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 544  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[83],lf[84],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2211,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
/* regex.scm: 548  substring */
t13=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t13))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2229,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 552  substring */
t12=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 555  substring */
t4=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k2260 in k2169 in loop in string-substitute in k956 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2262,2,t0,t1);}
t2=f_2046(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 556  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2256 in k2260 in k2169 in loop in string-substitute in k956 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 556  ##sys#fragments->string */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2227 in k2169 in loop in string-substitute in k956 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=f_2046(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 553  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2167(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k2209 in k2169 in loop in string-substitute in k956 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=f_2046(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2204,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 549  substitute */
t4=((C_word*)t0)[3];
f_2061(t4,t3,((C_word*)t0)[2]);}

/* k2202 in k2209 in k2169 in loop in string-substitute in k956 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 550  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2167(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k956 */
static void C_fcall f_2061(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2061,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word)li55),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2067(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k956 */
static void C_fcall f_2067(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2067,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_2081(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 526  substring */
t6=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 533  substring */
t14=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t14))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_fixnum_plus(t5,C_fix(1));
/* regex.scm: 536  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 537  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k2132 in loop in substitute in string-substitute in k956 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=f_2046(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 534  substring */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k2120 in k2132 in loop in substitute in string-substitute in k956 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=f_2046(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 535  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2067(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k2079 in loop in substitute in string-substitute in k956 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
/* regex.scm: 526  push */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_2046(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k956 */
static C_word C_fcall f_2046(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k956 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+28)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1849r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1849r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1849r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(28);
t5=(C_word)C_i_check_string_2(t3,lf[77]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_i_vector_ref(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1868,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[79]);
if(C_truep(t13)){
t14=t12;
f_1868(t14,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,a[6]=((C_word)li50),tmp=(C_word)a,a+=7,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[78]);
t15=t12;
f_1868(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1987,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=((C_word)li51),tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[2],a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp)));}}

/* f_2013 in string-split-fields in k956 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2013,4,t0,t1,t2,t3);}
/* regex.scm: 488  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* f_1987 in string-split-fields in k956 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1987,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[81],t2);
/* regex.scm: 486  reverse */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2012,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 487  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k2010 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 487  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* f_1967 in string-split-fields in k956 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1967,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 480  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[77],lf[80],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 482  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* k1866 in string-split-fields in k956 */
static void C_fcall f_1868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1868,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[78]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[79]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1956,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word)li49),tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_1876(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k1866 in string-split-fields in k956 */
static void C_fcall f_1876(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1876,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 493  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1878 in loop in k1866 in string-split-fields in k956 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 500  fini */
t7=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_fixnum_plus(t4,C_fix(2));
/* regex.scm: 501  fetch */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1941,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 502  fetch */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 503  fini */
t2=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1939 in k1878 in loop in k1866 in string-split-fields in k956 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 502  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1876(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1920 in k1878 in loop in k1866 in string-split-fields in k956 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 501  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1876(t4,((C_word*)t0)[2],t2,t3);}

/* f_1956 in k1866 in string-split-fields in k956 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1956,5,t0,t1,t2,t3,t4);}
/* regex.scm: 491  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_1951 in k1866 in string-split-fields in k956 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1951,5,t0,t1,t2,t3,t4);}
/* regex.scm: 490  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k956 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1839r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1839r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1839r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1847,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 461  prepare-search */
f_1783(t5,t2,t3,t4,lf[75]);}

/* k1845 in string-search-positions in k956 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 461  gather-result-positions */
t2=*((C_word*)lf[63]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-search in k956 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1829r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1829r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1829r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 457  prepare-search */
f_1783(t5,t2,t3,t4,lf[74]);}

/* k1835 in string-search in k956 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 457  gather-results */
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-search in k956 */
static void C_fcall f_1783(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1783,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t9=(C_truep(t8)?(C_word)C_i_car(t4):C_fix(0));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1796,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t11=t10;
f_1796(t11,(C_word)C_i_car(t8));}
else{
t11=(C_word)C_block_size(t3);
t12=t10;
f_1796(t12,(C_word)C_fixnum_difference(t11,t9));}}

/* k1794 in prepare-search in k956 */
static void C_fcall f_1796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_check_exact_2(t1,((C_word*)t0)[5]);
/* regex.scm: 453  perform-match */
t4=*((C_word*)lf[69]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],t1,((C_word*)t0)[5]);}

/* string-match-positions in k956 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1771r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1771r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1771r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1779,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 434  prepare-match */
f_1718(t5,t2,t3,t4,lf[72]);}

/* k1777 in string-match-positions in k956 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 434  gather-result-positions */
t2=*((C_word*)lf[63]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-match in k956 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1761r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1761r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1761r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1769,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 430  prepare-match */
f_1718(t5,t2,t3,t4,lf[71]);}

/* k1767 in string-match in k956 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 430  gather-results */
t2=*((C_word*)lf[65]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-match in k956 */
static void C_fcall f_1718(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1718,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_i_car(t4):C_fix(0));
t9=(C_word)C_i_check_exact_2(t8,t5);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1735,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t11=(C_word)C_fixnum_lessp(C_fix(0),t8);
/* regex.scm: 423  make-anchored-pattern */
t12=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t2,t11);}
else{
t11=t10;
f_1735(2,t11,t2);}}

/* k1733 in prepare-match in k956 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_difference(t2,((C_word*)t0)[4]);
/* regex.scm: 422  perform-match */
t4=*((C_word*)lf[69]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],t1,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[2]);}

/* perform-match in k956 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1646,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1650,a[2]=t10,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t8,a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* regex.scm: 394  re-checked-compile */
t12=*((C_word*)lf[52]+1);
((C_proc6)C_retrieve_proc(t12))(6,t12,t11,t2,C_fix(0),C_SCHEME_FALSE,t6);}
else{
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1680,a[2]=t6,a[3]=t2,a[4]=t11,a[5]=t10,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1710,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t2);}}

/* f_1710 in perform-match in k956 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1710,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[45]));}

/* k1678 in perform-match in k956 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1680,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1702,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* regex.scm: 400  ##sys#signal-hook */
t2=*((C_word*)lf[39]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[40],((C_word*)t0)[2],lf[70],((C_word*)t0)[3]);}}

/* f_1702 in k1678 in perform-match in k956 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1702,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k1682 in k1678 in perform-match in k956 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1697,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_1697 in k1682 in k1678 in perform-match in k956 */
static void C_ccall f_1697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1697,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k1686 in k1682 in k1678 in perform-match in k956 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1688,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_1692 in k1686 in k1682 in k1678 in perform-match in k956 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1692,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k1648 in perform-match in k956 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 404  re-match-capture-count */
t3=*((C_word*)lf[68]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)((C_word*)t0)[6])[1]);}

/* k1651 in k1648 in perform-match in k956 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 405  re-match */
t3=*((C_word*)lf[67]+1);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1654 in k1651 in k1648 in perform-match in k956 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
/* regex.scm: 406  re-finalizer */
t3=*((C_word*)lf[35]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1659(2,t3,C_SCHEME_UNDEFINED);}}

/* k1657 in k1654 in k1651 in k1648 in perform-match in k956 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1659,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* re-match-capture-count in k956 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1632,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub394(C_SCHEME_UNDEFINED,t4,t5));}

/* re-match in k956 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_1602,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_foreign_pointer_argumentp(t2);
t9=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t10=(C_word)C_i_foreign_block_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_unsigned_integer_argumentp(t7);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)stub379(C_SCHEME_UNDEFINED,t8,t9,t10,t11,t12,t13));}

/* gather-results in k956 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1581,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1585,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 370  gather-result-positions */
t5=*((C_word*)lf[63]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1583 in gather-results in k956 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 372  ##sys#map */
t3=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1592 in k1583 in gather-results in k956 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1593,3,t0,t1,t2);}
if(C_truep(t2)){
C_apply(5,0,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* gather-result-positions in k956 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1509,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1527,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word)li30),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1527(t8,t1,C_fix(0));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* loop in gather-result-positions in k956 */
static void C_fcall f_1527(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1527,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1547,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* regex.scm: 360  loop */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 362  ovector-start-ref */
t4=*((C_word*)lf[61]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}}

/* k1552 in loop in gather-result-positions in k956 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1579,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 364  ovector-end-ref */
t4=*((C_word*)lf[62]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=t2;
f_1561(t3,C_SCHEME_FALSE);}}

/* k1577 in k1552 in loop in gather-result-positions in k956 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1579,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1561(t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k1559 in k1552 in loop in gather-result-positions in k956 */
static void C_fcall f_1561(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1561,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1565,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* regex.scm: 365  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1527(t4,t2,t3);}

/* k1563 in k1559 in k1552 in loop in gather-result-positions in k956 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1545 in loop in gather-result-positions in k956 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* ovector-end-ref in k956 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1502,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub328(C_SCHEME_UNDEFINED,t3));}

/* ovector-start-ref in k956 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1495,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub322(C_SCHEME_UNDEFINED,t3));}

/* regexp-optimize in k956 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1451,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[59]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1458,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1488,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1489,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* f_1489 in regexp-optimize in k956 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1489,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k1486 in regexp-optimize in k956 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 319  re-study */
t2=*((C_word*)lf[58]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1456 in regexp-optimize in k956 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1464,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k1462 in k1456 in regexp-optimize in k956 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1464,2,t0,t1);}
if(C_truep(t1)){
/* regex.scm: 321  re-error */
t2=*((C_word*)lf[47]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],lf[59],lf[60],((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1474,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* f_1474 in k1462 in k1456 in regexp-optimize in k956 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1474,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1478,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex.scm: 209  set-finalizer! */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,*((C_word*)lf[35]+1));}
else{
t5=t4;
f_1478(2,t5,C_SCHEME_UNDEFINED);}}

/* k1476 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]));}

/* k1471 in k1462 in k1456 in regexp-optimize in k956 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* re-study in k956 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1444,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub289(t3,t4));}

/* regexp* in k956 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1356r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1356r(t0,t1,t2,t3);}}

static void C_ccall f_1356r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1358,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1391,a[2]=t4,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1396,a[2]=t5,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-options253277 */
t7=t6;
f_1396(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-tables254273 */
t9=t5;
f_1391(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body251260 */
t11=t4;
f_1358(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-options253 in regexp* in k956 */
static void C_fcall f_1396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1396,NULL,2,t0,t1);}
/* def-tables254273 */
t2=((C_word*)t0)[2];
f_1391(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-tables254 in regexp* in k956 */
static void C_fcall f_1391(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1391,NULL,3,t0,t1,t2);}
/* body251260 */
t3=((C_word*)t0)[2];
f_1358(t3,t1,t2,C_SCHEME_FALSE);}

/* body251 in regexp* in k956 */
static void C_fcall f_1358(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1358,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[57]);
t5=(C_word)C_i_check_list_2(t2,lf[57]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1368,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
/* regex.scm: 302  ##sys#check-chardef-table */
t7=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,lf[57]);}
else{
t7=t6;
f_1368(2,t7,C_SCHEME_UNDEFINED);}}

/* k1366 in body251 in regexp* in k956 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 303  pcre-options->number */
f_1125(t3,((C_word*)t0)[2]);}

/* k1385 in k1366 in body251 in regexp* in k956 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 303  re-checked-compile */
t2=*((C_word*)lf[52]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[57]);}

/* k1373 in k1366 in body251 in regexp* in k956 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1376,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_1376 in k1373 in k1366 in body251 in regexp* in k956 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1376,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1380,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 193  set-finalizer! */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,*((C_word*)lf[35]+1));}

/* k1378 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1380,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[45],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* regexp in k956 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1319r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1319r(t0,t1,t2,t3);}}

static void C_ccall f_1319r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=t3,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1354,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 294  options->integer */
t7=t4;
f_1321(t7,t6);}

/* k1352 in regexp in k956 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 294  re-checked-compile */
t2=*((C_word*)lf[52]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[45]);}

/* k1340 in regexp in k956 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_1343 in k1340 in regexp in k956 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1343,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1347,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 193  set-finalizer! */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,*((C_word*)lf[35]+1));}

/* k1345 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[45],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* options->integer in regexp in k956 */
static void C_fcall f_1321(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1321,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 293  map */
t4=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[2],lf[56]);}

/* a1330 in options->integer in regexp in k956 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1331,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t2)?t3:lf[54]));}

/* k1327 in options->integer in regexp in k956 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 293  pcre-options->number */
f_1125(((C_word*)t0)[2],t1);}

/* re-checked-compile in k956 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1304,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t2,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1311,a[2]=t2,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 283  re-compile */
t8=*((C_word*)lf[50]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t2,t3,C_SCHEME_FALSE);}

/* k1309 in re-checked-compile in k956 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* regex.scm: 284  re-error */
t2=*((C_word*)lf[47]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[53],((C_word*)t0)[2],C_fix((C_word)C_regex_error_offset));}}

/* re-compile in k956 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1282,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1287,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k1285 in re-compile in k956 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_foreign_unsigned_integer_argumentp(((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub199(((C_word*)t0)[2],t1,t2,t4));}

/* re-error in k956 */
static void C_ccall f_1268(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1268r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1268r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1268r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1276,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1280,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k1278 in re-error in k956 */
static void C_ccall f_1280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 271  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[48],t1);}

/* k1274 in re-error in k956 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],*((C_word*)lf[3]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* regexp? in k956 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1262,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_1262 in regexp? in k956 */
static void C_ccall f_1262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1262,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[45]));}

/* regex-chardef-table in k956 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1202r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1202r(t0,t1,t2);}}

static void C_ccall f_1202r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1206,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1206(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1206(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1204 in regex-chardef-table in k956 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1206,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_pointerp(t1))){
/* regex.scm: 240  re-make-chardef-table-type */
f_1192(((C_word*)t0)[2],t1);}
else{
/* regex.scm: 241  ##sys#signal-hook */
t2=*((C_word*)lf[39]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[40],lf[38],lf[41],t1);}}
else{
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t3=(C_word)stub140(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 246  re-make-chardef-table-type */
f_1192(t4,t3);}
else{
/* regex.scm: 249  ##sys#error-hook */
t4=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],C_fix(6),lf[38]);}}}

/* k1228 in k1204 in regex-chardef-table in k956 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 247  set-finalizer! */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,*((C_word*)lf[35]+1));}

/* k1231 in k1228 in k1204 in regex-chardef-table in k956 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* re-make-chardef-table-type in k956 */
static void C_fcall f_1192(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1192,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1197,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[36]);}

/* f_1197 in re-make-chardef-table-type in k956 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1197,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1201,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 100  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1199 */
static void C_ccall f_1201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_pointer(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* regex-chardef-table? in k956 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1169,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[36]);}

/* f_1174 in regex-chardef-table? in k956 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1174,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* re-finalizer in k956 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1159,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub105(C_SCHEME_UNDEFINED,t3));}

/* pcre-options->number in k956 */
static void C_fcall f_1125(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1125,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1131,a[2]=t4,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1131(t6,t1,t2,C_fix(0));}

/* loop in pcre-options->number in k956 */
static void C_fcall f_1131(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(436);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1131,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=f_960(C_a_i(&a,432),t5);
t7=(C_word)C_a_i_plus(&a,2,t3,t6);
/* regex.scm: 185  loop */
t9=t1;
t10=t4;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* pcre-option->number in k956 */
static C_word C_fcall f_960(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_stack_check;
t2=(C_word)C_eqp(t1,lf[7]);
if(C_truep(t2)){
return(C_unsigned_int_to_num(&a,PCRE_CASELESS));}
else{
t3=(C_word)C_eqp(t1,lf[8]);
if(C_truep(t3)){
return(C_unsigned_int_to_num(&a,PCRE_MULTILINE));}
else{
t4=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t4)){
return(C_unsigned_int_to_num(&a,PCRE_DOTALL));}
else{
t5=(C_word)C_eqp(t1,lf[10]);
if(C_truep(t5)){
return(C_unsigned_int_to_num(&a,PCRE_EXTENDED));}
else{
t6=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t6)){
return(C_unsigned_int_to_num(&a,PCRE_ANCHORED));}
else{
t7=(C_word)C_eqp(t1,lf[12]);
if(C_truep(t7)){
return(C_unsigned_int_to_num(&a,PCRE_DOLLAR_ENDONLY));}
else{
t8=(C_word)C_eqp(t1,lf[13]);
if(C_truep(t8)){
return(C_unsigned_int_to_num(&a,PCRE_EXTRA));}
else{
t9=(C_word)C_eqp(t1,lf[14]);
if(C_truep(t9)){
return(C_unsigned_int_to_num(&a,PCRE_NOTBOL));}
else{
t10=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t10)){
return(C_unsigned_int_to_num(&a,PCRE_NOTEOL));}
else{
t11=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t11)){
return(C_unsigned_int_to_num(&a,PCRE_UNGREEDY));}
else{
t12=(C_word)C_eqp(t1,lf[17]);
if(C_truep(t12)){
return(C_unsigned_int_to_num(&a,PCRE_NOTEMPTY));}
else{
t13=(C_word)C_eqp(t1,lf[18]);
if(C_truep(t13)){
return(C_unsigned_int_to_num(&a,PCRE_UTF8));}
else{
t14=(C_word)C_eqp(t1,lf[19]);
if(C_truep(t14)){
return(C_unsigned_int_to_num(&a,PCRE_NO_AUTO_CAPTURE));}
else{
t15=(C_word)C_eqp(t1,lf[20]);
if(C_truep(t15)){
return(C_unsigned_int_to_num(&a,PCRE_NO_UTF8_CHECK));}
else{
t16=(C_word)C_eqp(t1,lf[21]);
if(C_truep(t16)){
return(C_unsigned_int_to_num(&a,PCRE_AUTO_CALLOUT));}
else{
t17=(C_word)C_eqp(t1,lf[22]);
if(C_truep(t17)){
return(C_unsigned_int_to_num(&a,PCRE_PARTIAL));}
else{
t18=(C_word)C_eqp(t1,lf[23]);
if(C_truep(t18)){
return(C_unsigned_int_to_num(&a,PCRE_DFA_SHORTEST));}
else{
t19=(C_word)C_eqp(t1,lf[24]);
if(C_truep(t19)){
return(C_unsigned_int_to_num(&a,PCRE_DFA_RESTART));}
else{
t20=(C_word)C_eqp(t1,lf[25]);
if(C_truep(t20)){
return(C_unsigned_int_to_num(&a,PCRE_FIRSTLINE));}
else{
t21=(C_word)C_eqp(t1,lf[26]);
if(C_truep(t21)){
return(C_unsigned_int_to_num(&a,PCRE_DUPNAMES));}
else{
t22=(C_word)C_eqp(t1,lf[27]);
if(C_truep(t22)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_CR));}
else{
t23=(C_word)C_eqp(t1,lf[28]);
if(C_truep(t23)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_LF));}
else{
t24=(C_word)C_eqp(t1,lf[29]);
if(C_truep(t24)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_CRLF));}
else{
t25=(C_word)C_eqp(t1,lf[30]);
if(C_truep(t25)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANY));}
else{
t26=(C_word)C_eqp(t1,lf[31]);
if(C_truep(t26)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANYCRLF));}
else{
t27=(C_word)C_eqp(t1,lf[32]);
if(C_truep(t27)){
return(C_unsigned_int_to_num(&a,PCRE_BSR_ANYCRLF));}
else{
t28=(C_word)C_eqp(t1,lf[33]);
return((C_truep(t28)?C_unsigned_int_to_num(&a,PCRE_BSR_UNICODE):C_fix(0)));}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* ##sys#check-chardef-table */
static void C_ccall f_945(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_945,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_952,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 75   regex-chardef-table? */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k950 in ##sys#check-chardef-table */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* regex.scm: 76   ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[4],((C_word*)t0)[2]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[162] = {
{"toplevelregex.scm",(void*)C_regex_toplevel},
{"f_958regex.scm",(void*)f_958},
{"f_2784regex.scm",(void*)f_2784},
{"f_2847regex.scm",(void*)f_2847},
{"f_2842regex.scm",(void*)f_2842},
{"f_2786regex.scm",(void*)f_2786},
{"f_2810regex.scm",(void*)f_2810},
{"f_2831regex.scm",(void*)f_2831},
{"f_2826regex.scm",(void*)f_2826},
{"f_2818regex.scm",(void*)f_2818},
{"f_2813regex.scm",(void*)f_2813},
{"f_2728regex.scm",(void*)f_2728},
{"f_2735regex.scm",(void*)f_2735},
{"f_2743regex.scm",(void*)f_2743},
{"f_2775regex.scm",(void*)f_2775},
{"f_2762regex.scm",(void*)f_2762},
{"f_2765regex.scm",(void*)f_2765},
{"f_2688regex.scm",(void*)f_2688},
{"f_2697regex.scm",(void*)f_2697},
{"f_2716regex.scm",(void*)f_2716},
{"f_2723regex.scm",(void*)f_2723},
{"f_2411regex.scm",(void*)f_2411},
{"f_2426regex.scm",(void*)f_2426},
{"f_2428regex.scm",(void*)f_2428},
{"f_2683regex.scm",(void*)f_2683},
{"f_2679regex.scm",(void*)f_2679},
{"f_2668regex.scm",(void*)f_2668},
{"f_2490regex.scm",(void*)f_2490},
{"f_2520regex.scm",(void*)f_2520},
{"f_2549regex.scm",(void*)f_2549},
{"f_2597regex.scm",(void*)f_2597},
{"f_2576regex.scm",(void*)f_2576},
{"f_2572regex.scm",(void*)f_2572},
{"f_2539regex.scm",(void*)f_2539},
{"f_2535regex.scm",(void*)f_2535},
{"f_2510regex.scm",(void*)f_2510},
{"f_2488regex.scm",(void*)f_2488},
{"f_2475regex.scm",(void*)f_2475},
{"f_2462regex.scm",(void*)f_2462},
{"f_2458regex.scm",(void*)f_2458},
{"f_2422regex.scm",(void*)f_2422},
{"f_2326regex.scm",(void*)f_2326},
{"f_2339regex.scm",(void*)f_2339},
{"f_2358regex.scm",(void*)f_2358},
{"f_2274regex.scm",(void*)f_2274},
{"f_2289regex.scm",(void*)f_2289},
{"f_2306regex.scm",(void*)f_2306},
{"f_2031regex.scm",(void*)f_2031},
{"f_2167regex.scm",(void*)f_2167},
{"f_2171regex.scm",(void*)f_2171},
{"f_2262regex.scm",(void*)f_2262},
{"f_2258regex.scm",(void*)f_2258},
{"f_2229regex.scm",(void*)f_2229},
{"f_2211regex.scm",(void*)f_2211},
{"f_2204regex.scm",(void*)f_2204},
{"f_2061regex.scm",(void*)f_2061},
{"f_2067regex.scm",(void*)f_2067},
{"f_2134regex.scm",(void*)f_2134},
{"f_2122regex.scm",(void*)f_2122},
{"f_2081regex.scm",(void*)f_2081},
{"f_2046regex.scm",(void*)f_2046},
{"f_1849regex.scm",(void*)f_1849},
{"f_2013regex.scm",(void*)f_2013},
{"f_1987regex.scm",(void*)f_1987},
{"f_2012regex.scm",(void*)f_2012},
{"f_1967regex.scm",(void*)f_1967},
{"f_1868regex.scm",(void*)f_1868},
{"f_1876regex.scm",(void*)f_1876},
{"f_1880regex.scm",(void*)f_1880},
{"f_1941regex.scm",(void*)f_1941},
{"f_1922regex.scm",(void*)f_1922},
{"f_1956regex.scm",(void*)f_1956},
{"f_1951regex.scm",(void*)f_1951},
{"f_1839regex.scm",(void*)f_1839},
{"f_1847regex.scm",(void*)f_1847},
{"f_1829regex.scm",(void*)f_1829},
{"f_1837regex.scm",(void*)f_1837},
{"f_1783regex.scm",(void*)f_1783},
{"f_1796regex.scm",(void*)f_1796},
{"f_1771regex.scm",(void*)f_1771},
{"f_1779regex.scm",(void*)f_1779},
{"f_1761regex.scm",(void*)f_1761},
{"f_1769regex.scm",(void*)f_1769},
{"f_1718regex.scm",(void*)f_1718},
{"f_1735regex.scm",(void*)f_1735},
{"f_1646regex.scm",(void*)f_1646},
{"f_1710regex.scm",(void*)f_1710},
{"f_1680regex.scm",(void*)f_1680},
{"f_1702regex.scm",(void*)f_1702},
{"f_1684regex.scm",(void*)f_1684},
{"f_1697regex.scm",(void*)f_1697},
{"f_1688regex.scm",(void*)f_1688},
{"f_1692regex.scm",(void*)f_1692},
{"f_1650regex.scm",(void*)f_1650},
{"f_1653regex.scm",(void*)f_1653},
{"f_1656regex.scm",(void*)f_1656},
{"f_1659regex.scm",(void*)f_1659},
{"f_1632regex.scm",(void*)f_1632},
{"f_1602regex.scm",(void*)f_1602},
{"f_1581regex.scm",(void*)f_1581},
{"f_1585regex.scm",(void*)f_1585},
{"f_1593regex.scm",(void*)f_1593},
{"f_1509regex.scm",(void*)f_1509},
{"f_1527regex.scm",(void*)f_1527},
{"f_1554regex.scm",(void*)f_1554},
{"f_1579regex.scm",(void*)f_1579},
{"f_1561regex.scm",(void*)f_1561},
{"f_1565regex.scm",(void*)f_1565},
{"f_1547regex.scm",(void*)f_1547},
{"f_1502regex.scm",(void*)f_1502},
{"f_1495regex.scm",(void*)f_1495},
{"f_1451regex.scm",(void*)f_1451},
{"f_1489regex.scm",(void*)f_1489},
{"f_1488regex.scm",(void*)f_1488},
{"f_1458regex.scm",(void*)f_1458},
{"f_1464regex.scm",(void*)f_1464},
{"f_1474regex.scm",(void*)f_1474},
{"f_1478regex.scm",(void*)f_1478},
{"f_1473regex.scm",(void*)f_1473},
{"f_1444regex.scm",(void*)f_1444},
{"f_1356regex.scm",(void*)f_1356},
{"f_1396regex.scm",(void*)f_1396},
{"f_1391regex.scm",(void*)f_1391},
{"f_1358regex.scm",(void*)f_1358},
{"f_1368regex.scm",(void*)f_1368},
{"f_1387regex.scm",(void*)f_1387},
{"f_1375regex.scm",(void*)f_1375},
{"f_1376regex.scm",(void*)f_1376},
{"f_1380regex.scm",(void*)f_1380},
{"f_1319regex.scm",(void*)f_1319},
{"f_1354regex.scm",(void*)f_1354},
{"f_1342regex.scm",(void*)f_1342},
{"f_1343regex.scm",(void*)f_1343},
{"f_1347regex.scm",(void*)f_1347},
{"f_1321regex.scm",(void*)f_1321},
{"f_1331regex.scm",(void*)f_1331},
{"f_1329regex.scm",(void*)f_1329},
{"f_1304regex.scm",(void*)f_1304},
{"f_1311regex.scm",(void*)f_1311},
{"f_1282regex.scm",(void*)f_1282},
{"f_1287regex.scm",(void*)f_1287},
{"f_1268regex.scm",(void*)f_1268},
{"f_1280regex.scm",(void*)f_1280},
{"f_1276regex.scm",(void*)f_1276},
{"f_1257regex.scm",(void*)f_1257},
{"f_1262regex.scm",(void*)f_1262},
{"f_1202regex.scm",(void*)f_1202},
{"f_1206regex.scm",(void*)f_1206},
{"f_1230regex.scm",(void*)f_1230},
{"f_1233regex.scm",(void*)f_1233},
{"f_1192regex.scm",(void*)f_1192},
{"f_1197regex.scm",(void*)f_1197},
{"f_1201regex.scm",(void*)f_1201},
{"f_1169regex.scm",(void*)f_1169},
{"f_1174regex.scm",(void*)f_1174},
{"f_1159regex.scm",(void*)f_1159},
{"f_1125regex.scm",(void*)f_1125},
{"f_1131regex.scm",(void*)f_1131},
{"f_960regex.scm",(void*)f_960},
{"f_945regex.scm",(void*)f_945},
{"f_952regex.scm",(void*)f_952},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
