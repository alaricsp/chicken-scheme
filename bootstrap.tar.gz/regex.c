/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-14 11:28
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   SVN rev. 11596	compiled 2008-08-11 on dill (Linux)
   command line: regex.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -explicit-use -include-path ./pcre -output-file regex.c
   unit: regex
*/

#include "chicken.h"

#include "pcre.h"

static const char *C_regex_error;
static int C_regex_error_offset;


#define OVECTOR_LENGTH_MULTIPLE 3
#define STATIC_OVECTOR_LEN 256
static int C_regex_ovector[OVECTOR_LENGTH_MULTIPLE * STATIC_OVECTOR_LEN];


static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[102];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,99,104,101,99,107,45,99,104,97,114,100,101,102,45,116,97,98,108,101,32,120,51,50,32,108,111,99,51,51,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,21),40,112,99,114,101,45,111,112,116,105,111,110,45,62,110,117,109,98,101,114,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,111,112,116,115,49,48,49,32,111,112,116,49,48,50,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,29),40,112,99,114,101,45,111,112,116,105,111,110,115,45,62,110,117,109,98,101,114,32,111,112,116,115,57,53,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,22),40,114,101,45,102,105,110,97,108,105,122,101,114,32,97,49,48,55,49,49,49,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,20),40,102,95,49,50,48,48,32,120,49,51,51,32,116,97,103,49,51,52,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,27),40,114,101,103,101,120,45,99,104,97,114,100,101,102,45,116,97,98,108,101,63,32,120,49,51,49,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,22),40,102,95,49,50,50,51,32,112,116,114,49,53,48,32,116,97,103,49,53,49,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,38),40,114,101,45,109,97,107,101,45,99,104,97,114,100,101,102,45,116,97,98,108,101,45,116,121,112,101,32,116,97,98,108,101,115,49,52,56,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,33),40,114,101,103,101,120,45,99,104,97,114,100,101,102,45,116,97,98,108,101,32,46,32,116,109,112,49,54,50,49,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,102,95,49,50,56,56,32,120,49,56,53,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,114,101,103,101,120,112,63,32,120,49,56,51,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,32),40,114,101,45,101,114,114,111,114,32,108,111,99,49,57,52,32,109,115,103,49,57,53,32,97,114,103,115,49,57,54,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,49),40,114,101,45,99,104,101,99,107,101,100,45,99,111,109,112,105,108,101,32,112,97,116,116,101,114,110,50,49,53,32,111,112,116,105,111,110,115,50,49,54,32,108,111,99,50,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,17),40,97,49,51,53,54,32,105,50,51,53,32,111,50,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,18),40,111,112,116,105,111,110,115,45,62,105,110,116,101,103,101,114,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,16),40,102,95,49,51,54,57,32,99,111,100,101,50,51,57,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,32),40,114,101,103,101,120,112,32,112,97,116,116,101,114,110,50,51,48,32,46,32,111,112,116,105,111,110,115,50,51,49,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,16),40,102,95,49,52,48,50,32,99,111,100,101,50,54,57,41};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,50,53,52,32,111,112,116,105,111,110,115,50,54,52,32,116,97,98,108,101,115,50,54,53,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,30),40,100,101,102,45,116,97,98,108,101,115,50,53,55,32,37,111,112,116,105,111,110,115,50,53,50,50,55,55,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,111,112,116,105,111,110,115,50,53,54,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,30),40,114,101,103,101,120,112,42,32,112,97,116,116,101,114,110,50,52,52,32,46,32,97,114,103,115,50,52,53,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,23),40,102,95,49,53,48,48,32,114,120,51,49,51,32,101,120,116,114,97,51,49,52,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,14),40,102,95,49,53,49,53,32,114,120,51,48,51,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,23),40,114,101,103,101,120,112,45,111,112,116,105,109,105,122,101,32,114,120,51,48,48,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,51,52,56,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,35),40,103,97,116,104,101,114,45,114,101,115,117,108,116,45,112,111,115,105,116,105,111,110,115,32,114,101,115,117,108,116,51,51,55,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,97,49,54,49,56,32,112,111,115,115,51,55,51,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,33),40,103,97,116,104,101,114,45,114,101,115,117,108,116,115,32,115,116,114,51,54,54,32,114,101,115,117,108,116,51,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,14),40,102,95,49,55,49,56,32,114,120,52,51,52,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,14),40,102,95,49,55,50,51,32,114,120,52,51,50,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,14),40,102,95,49,55,50,56,32,114,120,52,51,48,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,13),40,102,95,49,55,51,54,32,120,52,50,56,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,49),40,112,101,114,102,111,114,109,45,109,97,116,99,104,32,114,103,120,112,52,48,57,32,115,116,114,52,49,48,32,115,105,52,49,49,32,114,105,52,49,50,32,108,111,99,52,49,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,46),40,112,114,101,112,97,114,101,45,109,97,116,99,104,32,114,103,120,112,52,53,50,32,115,116,114,52,53,51,32,115,116,97,114,116,52,53,52,32,108,111,99,52,53,53,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,40),40,115,116,114,105,110,103,45,109,97,116,99,104,32,114,103,120,112,52,54,49,32,115,116,114,52,54,50,32,46,32,115,116,97,114,116,52,54,51,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,50),40,115,116,114,105,110,103,45,109,97,116,99,104,45,112,111,115,105,116,105,111,110,115,32,114,103,120,112,52,54,53,32,115,116,114,52,54,54,32,46,32,115,116,97,114,116,52,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,57),40,112,114,101,112,97,114,101,45,115,101,97,114,99,104,32,114,103,120,112,52,55,54,32,115,116,114,52,55,55,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,52,55,56,32,108,111,99,52,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,51),40,115,116,114,105,110,103,45,115,101,97,114,99,104,32,114,103,120,112,52,57,52,32,115,116,114,52,57,53,32,46,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,52,57,54,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,61),40,115,116,114,105,110,103,45,115,101,97,114,99,104,45,112,111,115,105,116,105,111,110,115,32,114,103,120,112,52,57,56,32,115,116,114,52,57,57,32,46,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,53,48,48,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,31),40,102,95,49,57,55,55,32,115,116,97,114,116,53,53,54,32,102,114,111,109,53,53,55,32,116,111,53,53,56,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,31),40,102,95,49,57,56,50,32,115,116,97,114,116,53,54,48,32,102,114,111,109,53,54,49,32,116,111,53,54,50,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,109,115,53,55,48,32,115,116,97,114,116,53,55,49,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,23),40,102,95,49,57,57,51,32,109,115,53,51,49,32,115,116,97,114,116,53,51,50,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,49,51,32,109,115,53,51,52,32,115,116,97,114,116,53,51,53,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,23),40,102,95,50,48,51,57,32,109,115,53,51,55,32,115,116,97,114,116,53,51,56,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,56),40,115,116,114,105,110,103,45,115,112,108,105,116,45,102,105,101,108,100,115,32,114,103,120,112,53,48,57,32,115,116,114,53,49,48,32,46,32,109,111,100,101,45,97,110,100,45,115,116,97,114,116,53,49,49,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,6),40,112,117,115,104,41,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,116,97,114,116,54,50,49,32,105,110,100,101,120,54,50,50,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,23),40,115,117,98,115,116,105,116,117,116,101,32,109,97,116,99,104,101,115,54,49,53,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,110,100,101,120,54,52,48,32,99,111,117,110,116,54,52,49,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,57),40,115,116,114,105,110,103,45,115,117,98,115,116,105,116,117,116,101,32,114,101,103,101,120,53,57,50,32,115,117,98,115,116,53,57,51,32,115,116,114,105,110,103,53,57,52,32,46,32,102,108,97,103,53,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,115,116,114,54,57,53,32,115,109,97,112,54,57,54,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,45),40,115,116,114,105,110,103,45,115,117,98,115,116,105,116,117,116,101,42,32,115,116,114,54,56,51,32,115,109,97,112,54,56,52,32,46,32,109,111,100,101,54,56,53,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,105,100,120,55,49,50,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,14),40,103,108,111,98,63,32,115,116,114,55,48,54,41,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,50,32,114,101,115,116,55,56,49,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,99,115,55,54,49,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,45,62,114,101,103,101,120,112,32,115,55,53,53,41,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,56,50,57,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,21),40,103,114,101,112,32,114,103,120,112,56,50,50,32,108,115,116,56,50,51,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,53,48,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,22),40,114,101,103,101,120,112,45,101,115,99,97,112,101,32,115,116,114,56,52,49,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,25),40,102,95,50,56,52,52,32,114,120,57,48,54,32,111,112,116,105,111,110,115,57,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,14),40,102,95,50,56,53,55,32,114,120,57,48,57,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,56,55,56,32,110,111,115,56,56,56,32,110,111,101,56,56,57,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,110,111,101,56,56,49,32,37,110,111,115,56,55,54,57,49,54,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,110,111,115,56,56,48,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,97,110,99,104,111,114,101,100,45,112,97,116,116,101,114,110,32,114,103,120,112,56,54,56,32,46,32,97,114,103,115,56,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k1665 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub399(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub399(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
int cc;pcre_fullinfo(code, extra, PCRE_INFO_CAPTURECOUNT, &cc);return(cc + 1);
C_ret:
#undef return

return C_r;}

/* from k1651 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub384(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub384(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
void * str=(void * )C_data_pointer(C_a2);
int start=(int )C_unfix(C_a3);
int range=(int )C_unfix(C_a4);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a5);
return(pcre_exec(code, extra, str, start + range, start, options, C_regex_ovector, STATIC_OVECTOR_LEN * OVECTOR_LENGTH_MULTIPLE));
C_ret:
#undef return

return C_r;}

/* from k1531 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub331(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub331(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[(i * 2) + 1]);
C_ret:
#undef return

return C_r;}

/* from k1524 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub325(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub325(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[i * 2]);
C_ret:
#undef return

return C_r;}

/* from k1473 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub292(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub292(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
return(pcre_study(code, 0, &C_regex_error));
C_ret:
#undef return

return C_r;}

/* from k1319 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub202(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub202(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * patt=(char * )C_c_string(C_a0);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a1);
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a2);
return(pcre_compile(patt, options, &C_regex_error, &C_regex_error_offset, tables));
C_ret:
#undef return

return C_r;}

/* from re-maketables */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub143(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub143(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
return (pcre_maketables ());
C_ret:
#undef return

return C_r;}

/* from k1188 */
static C_word C_fcall stub108(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub108(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2873)
static void C_fcall f_2873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2812)
static void C_fcall f_2812(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2836)
static void C_ccall f_2836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2844)
static void C_ccall f_2844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_fcall f_2769(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2723)
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_fcall f_2516(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2546)
static void C_fcall f_2546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_fcall f_2575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2365)
static void C_fcall f_2365(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2384)
static void C_fcall f_2384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2315)
static void C_fcall f_2315(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2193)
static void C_fcall f_2193(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_fcall f_2087(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2093)
static void C_fcall f_2093(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2072)
static C_word C_fcall f_2072(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1894)
static void C_fcall f_1894(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_fcall f_1902(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_fcall f_1809(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1822)
static void C_fcall f_1822(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1787)
static void C_ccall f_1787r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_fcall f_1744(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_fcall f_1672(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1706)
static void C_ccall f_1706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_fcall f_1607(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1535)
static void C_fcall f_1535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_fcall f_1553(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1587)
static void C_fcall f_1587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1515)
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1514)
static void C_ccall f_1514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1422)
static void C_fcall f_1422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_fcall f_1417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1384)
static void C_fcall f_1384(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_fcall f_1347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_fcall f_1330(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_fcall f_1294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1256)
static void C_ccall f_1256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_fcall f_1218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_ccall f_1223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1151)
static void C_fcall f_1151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1157)
static void C_fcall f_1157(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_986)
static C_word C_fcall f_986(C_word *a,C_word t0);
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2873)
static void C_fcall trf_2873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2873(t0,t1);}

C_noret_decl(trf_2868)
static void C_fcall trf_2868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2868(t0,t1,t2);}

C_noret_decl(trf_2812)
static void C_fcall trf_2812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2812(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2812(t0,t1,t2,t3);}

C_noret_decl(trf_2769)
static void C_fcall trf_2769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2769(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2769(t0,t1,t2);}

C_noret_decl(trf_2723)
static void C_fcall trf_2723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2723(t0,t1,t2);}

C_noret_decl(trf_2454)
static void C_fcall trf_2454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2454(t0,t1,t2);}

C_noret_decl(trf_2516)
static void C_fcall trf_2516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2516(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2516(t0,t1,t2);}

C_noret_decl(trf_2546)
static void C_fcall trf_2546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2546(t0,t1);}

C_noret_decl(trf_2575)
static void C_fcall trf_2575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2575(t0,t1);}

C_noret_decl(trf_2365)
static void C_fcall trf_2365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2365(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2365(t0,t1,t2);}

C_noret_decl(trf_2384)
static void C_fcall trf_2384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2384(t0,t1);}

C_noret_decl(trf_2315)
static void C_fcall trf_2315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2315(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2315(t0,t1,t2,t3);}

C_noret_decl(trf_2193)
static void C_fcall trf_2193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2193(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2193(t0,t1,t2,t3);}

C_noret_decl(trf_2087)
static void C_fcall trf_2087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2087(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2087(t0,t1,t2);}

C_noret_decl(trf_2093)
static void C_fcall trf_2093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2093(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2093(t0,t1,t2,t3);}

C_noret_decl(trf_1894)
static void C_fcall trf_1894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1894(t0,t1);}

C_noret_decl(trf_1902)
static void C_fcall trf_1902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1902(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1902(t0,t1,t2,t3);}

C_noret_decl(trf_1809)
static void C_fcall trf_1809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1809(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1809(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1822)
static void C_fcall trf_1822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1822(t0,t1);}

C_noret_decl(trf_1744)
static void C_fcall trf_1744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1744(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1744(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1672)
static void C_fcall trf_1672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1672(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1672(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1607)
static void C_fcall trf_1607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1607(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1607(t0,t1,t2,t3);}

C_noret_decl(trf_1535)
static void C_fcall trf_1535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1535(t0,t1);}

C_noret_decl(trf_1553)
static void C_fcall trf_1553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1553(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1553(t0,t1,t2);}

C_noret_decl(trf_1587)
static void C_fcall trf_1587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1587(t0,t1);}

C_noret_decl(trf_1422)
static void C_fcall trf_1422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1422(t0,t1);}

C_noret_decl(trf_1417)
static void C_fcall trf_1417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1417(t0,t1,t2);}

C_noret_decl(trf_1384)
static void C_fcall trf_1384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1384(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1384(t0,t1,t2,t3);}

C_noret_decl(trf_1347)
static void C_fcall trf_1347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1347(t0,t1);}

C_noret_decl(trf_1330)
static void C_fcall trf_1330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1330(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1330(t0,t1,t2,t3);}

C_noret_decl(trf_1294)
static void C_fcall trf_1294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1294(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1294(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1218)
static void C_fcall trf_1218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1218(t0,t1);}

C_noret_decl(trf_1151)
static void C_fcall trf_1151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1151(t0,t1);}

C_noret_decl(trf_1157)
static void C_fcall trf_1157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1157(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1157(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(6);
if(!C_demand(6)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(799)){
C_save(t1);
C_rereclaim2(799*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(6);
C_initialize_lf(lf,102);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],23,"\003syscheck-chardef-table");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000-invalid character definition tables structure");
lf[5]=C_h_intern(&lf[5],20,"regex-chardef-table\077");
lf[7]=C_h_intern(&lf[7],8,"caseless");
lf[8]=C_h_intern(&lf[8],9,"multiline");
lf[9]=C_h_intern(&lf[9],6,"dotall");
lf[10]=C_h_intern(&lf[10],8,"extended");
lf[11]=C_h_intern(&lf[11],8,"anchored");
lf[12]=C_h_intern(&lf[12],14,"dollar-endonly");
lf[13]=C_h_intern(&lf[13],5,"extra");
lf[14]=C_h_intern(&lf[14],6,"notbol");
lf[15]=C_h_intern(&lf[15],6,"noteol");
lf[16]=C_h_intern(&lf[16],8,"ungreedy");
lf[17]=C_h_intern(&lf[17],8,"notempty");
lf[18]=C_h_intern(&lf[18],4,"utf8");
lf[19]=C_h_intern(&lf[19],15,"no-auto-capture");
lf[20]=C_h_intern(&lf[20],13,"no-utf8-check");
lf[21]=C_h_intern(&lf[21],12,"auto-callout");
lf[22]=C_h_intern(&lf[22],7,"partial");
lf[23]=C_h_intern(&lf[23],12,"dfa-shortest");
lf[24]=C_h_intern(&lf[24],11,"dfa-restart");
lf[25]=C_h_intern(&lf[25],9,"firstline");
lf[26]=C_h_intern(&lf[26],8,"dupnames");
lf[27]=C_h_intern(&lf[27],10,"newline-cr");
lf[28]=C_h_intern(&lf[28],10,"newline-lf");
lf[29]=C_h_intern(&lf[29],12,"newline-crlf");
lf[30]=C_h_intern(&lf[30],11,"newline-any");
lf[31]=C_h_intern(&lf[31],15,"newline-anycrlf");
lf[32]=C_h_intern(&lf[32],11,"bsr-anycrlf");
lf[33]=C_h_intern(&lf[33],11,"bsr-unicode");
lf[36]=C_h_intern(&lf[36],13,"chardef-table");
lf[37]=C_h_intern(&lf[37],23,"\003sysmake-tagged-pointer");
lf[38]=C_h_intern(&lf[38],19,"regex-chardef-table");
lf[39]=C_h_intern(&lf[39],15,"\003syssignal-hook");
lf[40]=C_h_intern(&lf[40],11,"\000type-error");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[42]=C_h_intern(&lf[42],14,"set-finalizer!");
lf[43]=C_h_intern(&lf[43],14,"\003syserror-hook");
lf[44]=C_h_intern(&lf[44],7,"regexp\077");
lf[45]=C_h_intern(&lf[45],6,"regexp");
lf[46]=C_h_intern(&lf[46],13,"string-append");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[49]=C_h_intern(&lf[49],17,"\003syspeek-c-string");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000!cannot compile regular expression");
lf[52]=C_h_intern(&lf[52],17,"\003sysmake-c-string");
lf[53]=C_h_intern(&lf[53],4,"zero");
lf[54]=C_h_intern(&lf[54],3,"map");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010caseless\376\003\000\000\002\376\001\000\000\010extended\376\003\000\000\002\376\001\000\000\004utf8\376\377\016");
lf[56]=C_h_intern(&lf[56],7,"regexp*");
lf[57]=C_h_intern(&lf[57],15,"regexp-optimize");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot optimize regular expression");
lf[60]=C_h_intern(&lf[60],9,"substring");
lf[62]=C_h_intern(&lf[62],7,"\003sysmap");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\077bad argument type - not a string or compiled regular expression");
lf[65]=C_h_intern(&lf[65],12,"string-match");
lf[66]=C_h_intern(&lf[66],22,"string-match-positions");
lf[67]=C_h_intern(&lf[67],21,"make-anchored-pattern");
lf[68]=C_h_intern(&lf[68],13,"string-search");
lf[69]=C_h_intern(&lf[69],23,"string-search-positions");
lf[70]=C_h_intern(&lf[70],7,"reverse");
lf[71]=C_h_intern(&lf[71],19,"string-split-fields");
lf[72]=C_h_intern(&lf[72],6,"\000infix");
lf[73]=C_h_intern(&lf[73],7,"\000suffix");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[76]=C_h_intern(&lf[76],11,"make-string");
lf[77]=C_h_intern(&lf[77],17,"string-substitute");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[79]=C_h_intern(&lf[79],21,"\003sysfragments->string");
lf[80]=C_h_intern(&lf[80],18,"string-substitute*");
lf[81]=C_h_intern(&lf[81],5,"glob\077");
lf[82]=C_h_intern(&lf[82],12,"list->string");
lf[83]=C_h_intern(&lf[83],12,"string->list");
lf[84]=C_h_intern(&lf[84],12,"glob->regexp");
lf[85]=C_h_intern(&lf[85],10,"\003sysappend");
lf[86]=C_h_intern(&lf[86],5,"error");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[88]=C_h_intern(&lf[88],4,"grep");
lf[89]=C_h_intern(&lf[89],18,"open-output-string");
lf[90]=C_h_intern(&lf[90],17,"get-output-string");
lf[91]=C_h_intern(&lf[91],13,"regexp-escape");
lf[92]=C_h_intern(&lf[92],16,"\003syswrite-char-0");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001^");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001$");
lf[97]=C_h_intern(&lf[97],7,"warning");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000<cannot select partial anchor for compiled regular expression");
lf[99]=C_h_intern(&lf[99],17,"register-feature!");
lf[100]=C_h_intern(&lf[100],5,"regex");
lf[101]=C_h_intern(&lf[101],4,"pcre");
C_register_lf2(lf,102,create_ptable());
t2=C_mutate(&lf[0] /* c174 ...) */,lf[1]);
t3=C_mutate((C_word*)lf[2]+1 /* check-chardef-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_971,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_984,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 94   register-feature! */
t5=*((C_word*)lf[99]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[100],lf[101]);}

/* k982 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word ab[107],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_984,2,t0,t1);}
t2=C_mutate(&lf[6] /* pcre-option->number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_986,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[34] /* pcre-options->number ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1151,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[35] /* re-finalizer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1185,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* regex-chardef-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1195,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1218,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t7=C_mutate((C_word*)lf[38]+1 /* regex-chardef-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1228,a[2]=t6,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t8=C_mutate((C_word*)lf[44]+1 /* regexp? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1283,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[46]+1);
t10=C_mutate(&lf[47] /* re-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=t9,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t11=C_mutate(&lf[50] /* re-checked-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[45]+1 /* regexp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[56]+1 /* regexp* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1382,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[57]+1 /* regexp-optimize ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[59] /* gather-result-positions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t16=*((C_word*)lf[60]+1);
t17=C_mutate(&lf[61] /* gather-results ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1607,a[2]=t16,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp));
t18=C_mutate(&lf[63] /* perform-match ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1672,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t19=C_set_block_item(lf[65] /* string-match */,0,C_SCHEME_UNDEFINED);
t20=C_set_block_item(lf[66] /* string-match-positions */,0,C_SCHEME_UNDEFINED);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1744,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[65]+1 /* string-match ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1787,a[2]=t21,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[66]+1 /* string-match-positions ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1797,a[2]=t21,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t24=C_set_block_item(lf[68] /* string-search */,0,C_SCHEME_UNDEFINED);
t25=C_set_block_item(lf[69] /* string-search-positions */,0,C_SCHEME_UNDEFINED);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1809,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t27=C_mutate((C_word*)lf[68]+1 /* string-search ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1855,a[2]=t26,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[69]+1 /* string-search-positions ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1865,a[2]=t26,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t29=*((C_word*)lf[70]+1);
t30=*((C_word*)lf[60]+1);
t31=*((C_word*)lf[69]+1);
t32=C_mutate((C_word*)lf[71]+1 /* string-split-fields ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1875,a[2]=t29,a[3]=t31,a[4]=t30,a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp));
t33=*((C_word*)lf[60]+1);
t34=*((C_word*)lf[70]+1);
t35=*((C_word*)lf[76]+1);
t36=*((C_word*)lf[69]+1);
t37=C_mutate((C_word*)lf[77]+1 /* string-substitute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2057,a[2]=t36,a[3]=t34,a[4]=t33,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t38=*((C_word*)lf[77]+1);
t39=C_mutate((C_word*)lf[80]+1 /* string-substitute* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2300,a[2]=t38,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp));
t40=C_mutate((C_word*)lf[81]+1 /* glob? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2352,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t41=*((C_word*)lf[82]+1);
t42=*((C_word*)lf[83]+1);
t43=C_mutate((C_word*)lf[84]+1 /* glob->regexp ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2437,a[2]=t42,a[3]=t41,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp));
t44=*((C_word*)lf[68]+1);
t45=C_mutate((C_word*)lf[88]+1 /* grep ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2714,a[2]=t44,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp));
t46=*((C_word*)lf[89]+1);
t47=*((C_word*)lf[90]+1);
t48=C_mutate((C_word*)lf[91]+1 /* regexp-escape ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2754,a[2]=t46,a[3]=t47,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t49=*((C_word*)lf[46]+1);
t50=C_mutate((C_word*)lf[67]+1 /* make-anchored-pattern ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=t49,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp));
t51=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t51+1)))(2,t51,C_SCHEME_UNDEFINED);}

/* make-anchored-pattern in k982 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2810r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2810r(t0,t1,t2,t3);}}

static void C_ccall f_2810r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2868,a[2]=t4,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2873,a[2]=t5,a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-nos880919 */
t7=t6;
f_2873(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-noe881915 */
t9=t5;
f_2868(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body878887 */
t11=t4;
f_2812(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-nos880 in make-anchored-pattern in k982 */
static void C_fcall f_2873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2873,NULL,2,t0,t1);}
/* def-noe881915 */
t2=((C_word*)t0)[2];
f_2868(t2,t1,C_SCHEME_FALSE);}

/* def-noe881 in make-anchored-pattern in k982 */
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2868,NULL,3,t0,t1,t2);}
/* body878887 */
t3=((C_word*)t0)[2];
f_2812(t3,t1,t2,C_SCHEME_FALSE);}

/* body878 in make-anchored-pattern in k982 */
static void C_fcall f_2812(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2812,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t4=(C_truep(t2)?lf[93]:lf[94]);
t5=(C_truep(t3)?lf[95]:lf[96]);
/* regex.scm: 665  string-append */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t4,((C_word*)t0)[3],t5);}
else{
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[45],lf[67]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=(C_truep(t6)?t6:t3);
if(C_truep(t7)){
/* regex.scm: 669  warning */
t8=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,lf[67],lf[98]);}
else{
t8=t5;
f_2836(2,t8,C_SCHEME_UNDEFINED);}}}

/* k2834 in body878 in make-anchored-pattern in k982 */
static void C_ccall f_2836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2857,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[45]+1));}

/* f_2857 in k2834 in body878 in make-anchored-pattern in k982 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2857,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2850 in k2834 in body878 in make-anchored-pattern in k982 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[439],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=f_986(C_a_i(&a,432),lf[11]);
t3=(C_word)C_a_i_plus(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2844,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* f_2844 in k2850 in k2834 in body878 in make-anchored-pattern in k982 */
static void C_ccall f_2844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2844,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t2,C_fix(3),t3));}

/* k2837 in k2834 in body878 in make-anchored-pattern in k982 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* regexp-escape in k982 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2754,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[91]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2761,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 644  open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2759 in regexp-escape in k982 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2769,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word)li62),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2769(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k2759 in regexp-escape in k982 */
static void C_fcall f_2769(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2769,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* regex.scm: 647  get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 650  ##sys#write-char-0 */
t5=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2801,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 654  ##sys#write-char-0 */
t5=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k2799 in loop in k2759 in regexp-escape in k982 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 655  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2769(t3,((C_word*)t0)[2],t2);}

/* k2786 in loop in k2759 in regexp-escape in k982 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 651  ##sys#write-char-0 */
t3=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k2789 in k2786 in loop in k2759 in regexp-escape in k982 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 652  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2769(t3,((C_word*)t0)[2],t2);}

/* grep in k982 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2714,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[88]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2723,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2723(t8,t1,t3);}

/* loop in grep in k982 */
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2723,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2742,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 632  string-search */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k2740 in loop in grep in k982 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 633  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2723(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 634  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2723(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2747 in k2740 in loop in grep in k982 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2749,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k982 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2437,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2448,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2452,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 593  string->list */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k2450 in glob->regexp in k982 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2454(t5,((C_word*)t0)[2],t1);}

/* loop in k2450 in glob->regexp in k982 */
static void C_fcall f_2454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(31);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2454,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2484,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2488,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 598  loop */
t18=t6;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2501,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 599  loop */
t18=t5;
t19=t4;
t1=t18;
t2=t19;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2516(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 617  loop */
t18=t7;
t19=t4;
t1=t18;
t2=t19;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2705,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2709,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 618  loop */
t18=t8;
t19=t4;
t1=t18;
t2=t19;
goto loop;}}}}

/* k2707 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2703 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2705,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k2692 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2694,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k2450 in glob->regexp in k982 */
static void C_fcall f_2516(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2516,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(C_make_character(93),t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t2);
/* regex.scm: 606  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2454(t7,t5,t6);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(C_make_character(45),t6);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
t9=t5;
f_2546(t9,(C_word)C_i_pairp(t8));}
else{
t8=t5;
f_2546(t8,C_SCHEME_FALSE);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2544 in loop2 in loop in k2450 in glob->regexp in k982 */
static void C_fcall f_2546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2546,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2565,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* regex.scm: 608  loop2 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2516(t6,t4,t5);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=t2;
f_2575(t6,(C_word)C_eqp(C_make_character(45),t5));}
else{
t5=t2;
f_2575(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_2575(t4,C_SCHEME_FALSE);}}}

/* k2573 in k2544 in loop2 in loop in k2450 in glob->regexp in k982 */
static void C_fcall f_2575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2575,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2598,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2602,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdddr(((C_word*)t0)[5]);
/* regex.scm: 612  loop2 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_2516(t7,t5,t6);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2623,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* regex.scm: 614  loop2 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2516(t5,t3,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* regex.scm: 616  error */
t2=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[84],lf[87],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}}

/* k2621 in k2573 in k2544 in loop2 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2623,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2600 in k2573 in k2544 in loop2 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2596 in k2573 in k2544 in loop2 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2563 in k2544 in loop2 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2559 in k2544 in loop2 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k2534 in loop2 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* k2512 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k2499 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2501,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k2486 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2482 in loop in k2450 in glob->regexp in k982 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k2446 in glob->regexp in k982 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 592  list->string */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k982 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2352,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[81]);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2365,a[2]=t7,a[3]=t2,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2365(t9,t1,t5);}

/* loop in glob? in k982 */
static void C_fcall f_2365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2365,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_2384(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_2384(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2382 in loop in glob? in k982 */
static void C_fcall f_2384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 583  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_2365(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 585  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2365(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k982 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2300r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2300r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2300r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_string_2(t2,lf[80]);
t6=(C_word)C_i_check_list_2(t3,lf[80]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2315,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2315(t12,t1,t2,t3);}

/* loop in string-substitute* in k982 */
static void C_fcall f_2315(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2315,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2332,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_cdr(t4);
/* regex.scm: 568  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k2330 in loop in string-substitute* in k982 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* regex.scm: 568  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2315(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k982 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+34)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2057r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2057r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2057r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(34);
t6=(C_word)C_i_check_string_2(t3,lf[77]);
t7=(C_word)C_notvemptyp(t5);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t5,C_fix(0)):C_fix(1));
t9=(C_word)C_block_size(t3);
t10=(C_word)C_fixnum_difference(t9,C_fix(1));
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_fix(0);
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2072,a[2]=t14,a[3]=t12,a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2087,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t15,a[7]=t10,a[8]=((C_word)li50),tmp=(C_word)a,a+=9,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=((C_word*)t0)[3],a[5]=t14,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=t16,a[9]=t18,a[10]=t15,a[11]=t8,a[12]=t2,a[13]=((C_word)li51),tmp=(C_word)a,a+=14,tmp));
t20=((C_word*)t18)[1];
f_2193(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k982 */
static void C_fcall f_2193(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2193,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* regex.scm: 539  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[12],((C_word*)t0)[6],t2);}

/* k2195 in loop in string-substitute in k982 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 544  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[77],lf[78],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2237,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
/* regex.scm: 548  substring */
t13=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t13))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2255,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 552  substring */
t12=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2288,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 555  substring */
t4=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k2286 in k2195 in loop in string-substitute in k982 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=f_2072(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 556  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2282 in k2286 in k2195 in loop in string-substitute in k982 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 556  ##sys#fragments->string */
t2=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2253 in k2195 in loop in string-substitute in k982 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=f_2072(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 553  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2193(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k2235 in k2195 in loop in string-substitute in k982 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=f_2072(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2230,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 549  substitute */
t4=((C_word*)t0)[3];
f_2087(t4,t3,((C_word*)t0)[2]);}

/* k2228 in k2235 in k2195 in loop in string-substitute in k982 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 550  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2193(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k982 */
static void C_fcall f_2087(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2087,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word)li49),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_2093(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k982 */
static void C_fcall f_2093(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2093,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_2107(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 526  substring */
t6=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 533  substring */
t14=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t14))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_fixnum_plus(t5,C_fix(1));
/* regex.scm: 536  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 537  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k2158 in loop in substitute in string-substitute in k982 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=f_2072(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 534  substring */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k2146 in k2158 in loop in substitute in string-substitute in k982 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=f_2072(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 535  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2093(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k2105 in loop in substitute in string-substitute in k982 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
/* regex.scm: 526  push */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_2072(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k982 */
static C_word C_fcall f_2072(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k982 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+28)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1875r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1875r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1875r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(28);
t5=(C_word)C_i_check_string_2(t3,lf[71]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_i_vector_ref(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1894,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[73]);
if(C_truep(t13)){
t14=t12;
f_1894(t14,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,a[6]=((C_word)li44),tmp=(C_word)a,a+=7,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[72]);
t15=t12;
f_1894(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2013,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[2],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp)));}}

/* f_2039 in string-split-fields in k982 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2039,4,t0,t1,t2,t3);}
/* regex.scm: 488  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* f_2013 in string-split-fields in k982 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2013,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[75],t2);
/* regex.scm: 486  reverse */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2038,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 487  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k2036 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 487  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* f_1993 in string-split-fields in k982 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1993,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 480  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[71],lf[74],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 482  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* k1892 in string-split-fields in k982 */
static void C_fcall f_1894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1894,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[72]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[73]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word)li43),tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_1902(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k1892 in string-split-fields in k982 */
static void C_fcall f_1902(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1902,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 493  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1904 in loop in k1892 in string-split-fields in k982 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 500  fini */
t7=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1948,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_fixnum_plus(t4,C_fix(2));
/* regex.scm: 501  fetch */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1967,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 502  fetch */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 503  fini */
t2=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1965 in k1904 in loop in k1892 in string-split-fields in k982 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 502  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1902(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1946 in k1904 in loop in k1892 in string-split-fields in k982 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1948,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 501  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1902(t4,((C_word*)t0)[2],t2,t3);}

/* f_1982 in k1892 in string-split-fields in k982 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1982,5,t0,t1,t2,t3,t4);}
/* regex.scm: 491  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_1977 in k1892 in string-split-fields in k982 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1977,5,t0,t1,t2,t3,t4);}
/* regex.scm: 490  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k982 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1865r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1865r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1865r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 461  prepare-search */
f_1809(t5,t2,t3,t4,lf[69]);}

/* k1871 in string-search-positions in k982 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 461  gather-result-positions */
f_1535(((C_word*)t0)[2],t1);}

/* string-search in k982 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1855r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1855r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1855r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 457  prepare-search */
f_1809(t5,t2,t3,t4,lf[68]);}

/* k1861 in string-search in k982 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 457  gather-results */
t2=lf[61];
f_1607(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-search in k982 */
static void C_fcall f_1809(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1809,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t9=(C_truep(t8)?(C_word)C_i_car(t4):C_fix(0));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1822,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t11=t10;
f_1822(t11,(C_word)C_i_car(t8));}
else{
t11=(C_word)C_block_size(t3);
t12=t10;
f_1822(t12,(C_word)C_fixnum_difference(t11,t9));}}

/* k1820 in prepare-search in k982 */
static void C_fcall f_1822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_check_exact_2(t1,((C_word*)t0)[5]);
/* regex.scm: 453  perform-match */
f_1672(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],t1,((C_word*)t0)[5]);}

/* string-match-positions in k982 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1797r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1797r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1797r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 434  prepare-match */
f_1744(t5,t2,t3,t4,lf[66]);}

/* k1803 in string-match-positions in k982 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 434  gather-result-positions */
f_1535(((C_word*)t0)[2],t1);}

/* string-match in k982 */
static void C_ccall f_1787(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1787r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1787r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1787r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1795,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 430  prepare-match */
f_1744(t5,t2,t3,t4,lf[65]);}

/* k1793 in string-match in k982 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 430  gather-results */
t2=lf[61];
f_1607(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-match in k982 */
static void C_fcall f_1744(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1744,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_i_car(t4):C_fix(0));
t9=(C_word)C_i_check_exact_2(t8,t5);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1761,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t11=(C_word)C_fixnum_lessp(C_fix(0),t8);
/* regex.scm: 423  make-anchored-pattern */
t12=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t2,t11);}
else{
t11=t10;
f_1761(2,t11,t2);}}

/* k1759 in prepare-match in k982 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_difference(t2,((C_word*)t0)[4]);
/* regex.scm: 422  perform-match */
f_1672(((C_word*)t0)[3],t1,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[2]);}

/* perform-match in k982 */
static void C_fcall f_1672(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1672,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1676,a[2]=t2,a[3]=t1,a[4]=t10,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* regex.scm: 394  re-checked-compile */
f_1330(t11,t2,C_fix(0),t6);}
else{
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1706,a[2]=t6,a[3]=t2,a[4]=t11,a[5]=t10,a[6]=t8,tmp=(C_word)a,a+=7,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1736,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t2);}}

/* f_1736 in perform-match in k982 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1736,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[45]));}

/* k1704 in perform-match in k982 */
static void C_ccall f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1706,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* regex.scm: 400  ##sys#signal-hook */
t2=*((C_word*)lf[39]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[40],((C_word*)t0)[2],lf[64],((C_word*)t0)[3]);}}

/* f_1728 in k1704 in perform-match in k982 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1728,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k1708 in k1704 in perform-match in k982 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1710,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1723,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* f_1723 in k1708 in k1704 in perform-match in k982 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1723,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k1712 in k1708 in k1704 in perform-match in k982 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_1718 in k1712 in k1708 in k1704 in perform-match in k982 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1718,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k1674 in perform-match in k982 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=t1;
t3=((C_word*)((C_word*)t0)[8])[1];
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)stub399(C_SCHEME_UNDEFINED,t4,t5);
t7=t1;
t8=((C_word*)((C_word*)t0)[8])[1];
t9=((C_word*)t0)[7];
t10=((C_word*)t0)[6];
t11=((C_word*)t0)[5];
t12=((C_word*)((C_word*)t0)[4])[1];
t13=(C_word)C_i_foreign_pointer_argumentp(t7);
t14=(C_truep(t8)?(C_word)C_i_foreign_pointer_argumentp(t8):C_SCHEME_FALSE);
t15=(C_word)C_i_foreign_block_argumentp(t9);
t16=(C_word)C_i_foreign_fixnum_argumentp(t10);
t17=(C_word)C_i_foreign_fixnum_argumentp(t11);
t18=(C_word)C_i_foreign_unsigned_integer_argumentp(t12);
t19=(C_word)stub384(C_SCHEME_UNDEFINED,t13,t14,t15,t16,t17,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1685,a[2]=t6,a[3]=t19,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* regex.scm: 406  re-finalizer */
t21=lf[35];
f_1185(3,t21,t20,t1);}
else{
t21=t20;
f_1685(2,t21,C_SCHEME_UNDEFINED);}}

/* k1683 in k1674 in perform-match in k982 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* gather-results in k982 */
static void C_fcall f_1607(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1607,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1611,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 370  gather-result-positions */
f_1535(t4,t3);}

/* k1609 in gather-results in k982 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 372  ##sys#map */
t3=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1618 in k1609 in gather-results in k982 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1619,3,t0,t1,t2);}
if(C_truep(t2)){
C_apply(5,0,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* gather-result-positions in k982 */
static void C_fcall f_1535(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1535,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1553,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1553(t8,t1,C_fix(0));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* loop in gather-result-positions in k982 */
static void C_fcall f_1553(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1553,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1573,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* regex.scm: 360  loop */
t13=t3;
t14=t4;
t1=t13;
t2=t14;
goto loop;}
else{
t3=t2;
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=(C_word)stub325(C_SCHEME_UNDEFINED,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(0)))){
t7=t2;
t8=(C_word)C_i_foreign_fixnum_argumentp(t7);
t9=(C_word)stub331(C_SCHEME_UNDEFINED,t8);
t10=t6;
f_1587(t10,(C_word)C_a_i_list(&a,2,t5,t9));}
else{
t7=t6;
f_1587(t7,C_SCHEME_FALSE);}}}}

/* k1585 in loop in gather-result-positions in k982 */
static void C_fcall f_1587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1587,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1591,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* regex.scm: 365  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1553(t4,t2,t3);}

/* k1589 in k1585 in loop in gather-result-positions in k982 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1591,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1571 in loop in gather-result-positions in k982 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1573,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* regexp-optimize in k982 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1477,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[57]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1514,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1515,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_1515 in regexp-optimize in k982 */
static void C_ccall f_1515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1515,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k1512 in regexp-optimize in k982 */
static void C_ccall f_1514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1514,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t3=(C_word)C_i_foreign_pointer_argumentp(t1);
t4=(C_word)stub292(t2,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1490,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k1488 in k1512 in regexp-optimize in k982 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1490,2,t0,t1);}
if(C_truep(t1)){
/* regex.scm: 321  re-error */
t2=lf[47];
f_1294(t2,((C_word*)t0)[4],lf[57],lf[58],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1500,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* f_1500 in k1488 in k1512 in regexp-optimize in k982 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1500,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1504,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex.scm: 209  set-finalizer! */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[35]);}
else{
t5=t4;
f_1504(2,t5,C_SCHEME_UNDEFINED);}}

/* k1502 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]));}

/* k1497 in k1488 in k1512 in regexp-optimize in k982 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* regexp* in k982 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1382r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1382r(t0,t1,t2,t3);}}

static void C_ccall f_1382r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1384,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1417,a[2]=t4,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1422,a[2]=t5,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-options256280 */
t7=t6;
f_1422(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-tables257276 */
t9=t5;
f_1417(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body254263 */
t11=t4;
f_1384(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-options256 in regexp* in k982 */
static void C_fcall f_1422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1422,NULL,2,t0,t1);}
/* def-tables257276 */
t2=((C_word*)t0)[2];
f_1417(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-tables257 in regexp* in k982 */
static void C_fcall f_1417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1417,NULL,3,t0,t1,t2);}
/* body254263 */
t3=((C_word*)t0)[2];
f_1384(t3,t1,t2,C_SCHEME_FALSE);}

/* body254 in regexp* in k982 */
static void C_fcall f_1384(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1384,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[56]);
t5=(C_word)C_i_check_list_2(t2,lf[56]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1394,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex.scm: 302  ##sys#check-chardef-table */
t7=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,lf[56]);}
else{
t7=t6;
f_1394(2,t7,C_SCHEME_UNDEFINED);}}

/* k1392 in body254 in regexp* in k982 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 303  pcre-options->number */
f_1151(t3,((C_word*)t0)[2]);}

/* k1411 in k1392 in body254 in regexp* in k982 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 303  re-checked-compile */
f_1330(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[56]);}

/* k1399 in k1392 in body254 in regexp* in k982 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1402,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_1402 in k1399 in k1392 in body254 in regexp* in k982 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1402,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1406,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 193  set-finalizer! */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[35]);}

/* k1404 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1406,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[45],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* regexp in k982 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1345r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1345r(t0,t1,t2,t3);}}

static void C_ccall f_1345r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1347,a[2]=t3,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1368,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1380,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 294  options->integer */
t7=t4;
f_1347(t7,t6);}

/* k1378 in regexp in k982 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 294  re-checked-compile */
f_1330(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[45]);}

/* k1366 in regexp in k982 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1369,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_1369 in k1366 in regexp in k982 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1369,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1373,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 193  set-finalizer! */
t4=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[35]);}

/* k1371 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1373,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[45],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* options->integer in regexp in k982 */
static void C_fcall f_1347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1347,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 293  map */
t4=*((C_word*)lf[54]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[2],lf[55]);}

/* a1356 in options->integer in regexp in k982 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1357,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t2)?t3:lf[53]));}

/* k1353 in options->integer in regexp in k982 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 293  pcre-options->number */
f_1151(((C_word*)t0)[2],t1);}

/* re-checked-compile in k982 */
static void C_fcall f_1330(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1330,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=t2;
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1313,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t7,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}

/* k1311 in re-checked-compile in k982 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=(C_word)C_i_foreign_unsigned_integer_argumentp(((C_word*)t0)[6]);
t3=(C_word)stub202(((C_word*)t0)[5],t1,t2,C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* regex.scm: 284  re-error */
t4=lf[47];
f_1294(t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[51],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_fix((C_word)C_regex_error_offset)));}}

/* re-error in k982 */
static void C_fcall f_1294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1294,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1302,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1306,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k1304 in re-error in k982 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 271  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[48],t1);}

/* k1300 in re-error in k982 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],*((C_word*)lf[3]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* regexp? in k982 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1283,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1288,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_1288 in regexp? in k982 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1288,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[45]));}

/* regex-chardef-table in k982 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1228r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1228r(t0,t1,t2);}}

static void C_ccall f_1228r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1232,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1232(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_1232(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1230 in regex-chardef-table in k982 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1232,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_pointerp(t1))){
/* regex.scm: 240  re-make-chardef-table-type */
f_1218(((C_word*)t0)[2],t1);}
else{
/* regex.scm: 241  ##sys#signal-hook */
t2=*((C_word*)lf[39]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[40],lf[38],lf[41],t1);}}
else{
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t3=(C_word)stub143(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 246  re-make-chardef-table-type */
f_1218(t4,t3);}
else{
/* regex.scm: 249  ##sys#error-hook */
t4=*((C_word*)lf[43]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],C_fix(6),lf[38]);}}}

/* k1254 in k1230 in regex-chardef-table in k982 */
static void C_ccall f_1256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1259,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 247  set-finalizer! */
t3=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[35]);}

/* k1257 in k1254 in k1230 in regex-chardef-table in k982 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* re-make-chardef-table-type in k982 */
static void C_fcall f_1218(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1218,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1223,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[36]);}

/* f_1223 in re-make-chardef-table-type in k982 */
static void C_ccall f_1223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1223,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1227,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 100  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[37]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1225 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_pointer(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* regex-chardef-table? in k982 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1195,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1200,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[36]);}

/* f_1200 in regex-chardef-table? in k982 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1200,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* re-finalizer in k982 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1185,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub108(C_SCHEME_UNDEFINED,t3));}

/* pcre-options->number in k982 */
static void C_fcall f_1151(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1151,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1157,a[2]=t4,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1157(t6,t1,t2,C_fix(0));}

/* loop in pcre-options->number in k982 */
static void C_fcall f_1157(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(436);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1157,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=f_986(C_a_i(&a,432),t5);
t7=(C_word)C_a_i_plus(&a,2,t3,t6);
/* regex.scm: 185  loop */
t9=t1;
t10=t4;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* pcre-option->number in k982 */
static C_word C_fcall f_986(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_stack_check;
t2=(C_word)C_eqp(t1,lf[7]);
if(C_truep(t2)){
return(C_unsigned_int_to_num(&a,PCRE_CASELESS));}
else{
t3=(C_word)C_eqp(t1,lf[8]);
if(C_truep(t3)){
return(C_unsigned_int_to_num(&a,PCRE_MULTILINE));}
else{
t4=(C_word)C_eqp(t1,lf[9]);
if(C_truep(t4)){
return(C_unsigned_int_to_num(&a,PCRE_DOTALL));}
else{
t5=(C_word)C_eqp(t1,lf[10]);
if(C_truep(t5)){
return(C_unsigned_int_to_num(&a,PCRE_EXTENDED));}
else{
t6=(C_word)C_eqp(t1,lf[11]);
if(C_truep(t6)){
return(C_unsigned_int_to_num(&a,PCRE_ANCHORED));}
else{
t7=(C_word)C_eqp(t1,lf[12]);
if(C_truep(t7)){
return(C_unsigned_int_to_num(&a,PCRE_DOLLAR_ENDONLY));}
else{
t8=(C_word)C_eqp(t1,lf[13]);
if(C_truep(t8)){
return(C_unsigned_int_to_num(&a,PCRE_EXTRA));}
else{
t9=(C_word)C_eqp(t1,lf[14]);
if(C_truep(t9)){
return(C_unsigned_int_to_num(&a,PCRE_NOTBOL));}
else{
t10=(C_word)C_eqp(t1,lf[15]);
if(C_truep(t10)){
return(C_unsigned_int_to_num(&a,PCRE_NOTEOL));}
else{
t11=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t11)){
return(C_unsigned_int_to_num(&a,PCRE_UNGREEDY));}
else{
t12=(C_word)C_eqp(t1,lf[17]);
if(C_truep(t12)){
return(C_unsigned_int_to_num(&a,PCRE_NOTEMPTY));}
else{
t13=(C_word)C_eqp(t1,lf[18]);
if(C_truep(t13)){
return(C_unsigned_int_to_num(&a,PCRE_UTF8));}
else{
t14=(C_word)C_eqp(t1,lf[19]);
if(C_truep(t14)){
return(C_unsigned_int_to_num(&a,PCRE_NO_AUTO_CAPTURE));}
else{
t15=(C_word)C_eqp(t1,lf[20]);
if(C_truep(t15)){
return(C_unsigned_int_to_num(&a,PCRE_NO_UTF8_CHECK));}
else{
t16=(C_word)C_eqp(t1,lf[21]);
if(C_truep(t16)){
return(C_unsigned_int_to_num(&a,PCRE_AUTO_CALLOUT));}
else{
t17=(C_word)C_eqp(t1,lf[22]);
if(C_truep(t17)){
return(C_unsigned_int_to_num(&a,PCRE_PARTIAL));}
else{
t18=(C_word)C_eqp(t1,lf[23]);
if(C_truep(t18)){
return(C_unsigned_int_to_num(&a,PCRE_DFA_SHORTEST));}
else{
t19=(C_word)C_eqp(t1,lf[24]);
if(C_truep(t19)){
return(C_unsigned_int_to_num(&a,PCRE_DFA_RESTART));}
else{
t20=(C_word)C_eqp(t1,lf[25]);
if(C_truep(t20)){
return(C_unsigned_int_to_num(&a,PCRE_FIRSTLINE));}
else{
t21=(C_word)C_eqp(t1,lf[26]);
if(C_truep(t21)){
return(C_unsigned_int_to_num(&a,PCRE_DUPNAMES));}
else{
t22=(C_word)C_eqp(t1,lf[27]);
if(C_truep(t22)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_CR));}
else{
t23=(C_word)C_eqp(t1,lf[28]);
if(C_truep(t23)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_LF));}
else{
t24=(C_word)C_eqp(t1,lf[29]);
if(C_truep(t24)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_CRLF));}
else{
t25=(C_word)C_eqp(t1,lf[30]);
if(C_truep(t25)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANY));}
else{
t26=(C_word)C_eqp(t1,lf[31]);
if(C_truep(t26)){
return(C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANYCRLF));}
else{
t27=(C_word)C_eqp(t1,lf[32]);
if(C_truep(t27)){
return(C_unsigned_int_to_num(&a,PCRE_BSR_ANYCRLF));}
else{
t28=(C_word)C_eqp(t1,lf[33]);
return((C_truep(t28)?C_unsigned_int_to_num(&a,PCRE_BSR_UNICODE):C_fix(0)));}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* ##sys#check-chardef-table */
static void C_ccall f_971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_971,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_978,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 75   regex-chardef-table? */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k976 in ##sys#check-chardef-table */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* regex.scm: 76   ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[4],((C_word*)t0)[2]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[150] = {
{"toplevelregex.scm",(void*)C_regex_toplevel},
{"f_984regex.scm",(void*)f_984},
{"f_2810regex.scm",(void*)f_2810},
{"f_2873regex.scm",(void*)f_2873},
{"f_2868regex.scm",(void*)f_2868},
{"f_2812regex.scm",(void*)f_2812},
{"f_2836regex.scm",(void*)f_2836},
{"f_2857regex.scm",(void*)f_2857},
{"f_2852regex.scm",(void*)f_2852},
{"f_2844regex.scm",(void*)f_2844},
{"f_2839regex.scm",(void*)f_2839},
{"f_2754regex.scm",(void*)f_2754},
{"f_2761regex.scm",(void*)f_2761},
{"f_2769regex.scm",(void*)f_2769},
{"f_2801regex.scm",(void*)f_2801},
{"f_2788regex.scm",(void*)f_2788},
{"f_2791regex.scm",(void*)f_2791},
{"f_2714regex.scm",(void*)f_2714},
{"f_2723regex.scm",(void*)f_2723},
{"f_2742regex.scm",(void*)f_2742},
{"f_2749regex.scm",(void*)f_2749},
{"f_2437regex.scm",(void*)f_2437},
{"f_2452regex.scm",(void*)f_2452},
{"f_2454regex.scm",(void*)f_2454},
{"f_2709regex.scm",(void*)f_2709},
{"f_2705regex.scm",(void*)f_2705},
{"f_2694regex.scm",(void*)f_2694},
{"f_2516regex.scm",(void*)f_2516},
{"f_2546regex.scm",(void*)f_2546},
{"f_2575regex.scm",(void*)f_2575},
{"f_2623regex.scm",(void*)f_2623},
{"f_2602regex.scm",(void*)f_2602},
{"f_2598regex.scm",(void*)f_2598},
{"f_2565regex.scm",(void*)f_2565},
{"f_2561regex.scm",(void*)f_2561},
{"f_2536regex.scm",(void*)f_2536},
{"f_2514regex.scm",(void*)f_2514},
{"f_2501regex.scm",(void*)f_2501},
{"f_2488regex.scm",(void*)f_2488},
{"f_2484regex.scm",(void*)f_2484},
{"f_2448regex.scm",(void*)f_2448},
{"f_2352regex.scm",(void*)f_2352},
{"f_2365regex.scm",(void*)f_2365},
{"f_2384regex.scm",(void*)f_2384},
{"f_2300regex.scm",(void*)f_2300},
{"f_2315regex.scm",(void*)f_2315},
{"f_2332regex.scm",(void*)f_2332},
{"f_2057regex.scm",(void*)f_2057},
{"f_2193regex.scm",(void*)f_2193},
{"f_2197regex.scm",(void*)f_2197},
{"f_2288regex.scm",(void*)f_2288},
{"f_2284regex.scm",(void*)f_2284},
{"f_2255regex.scm",(void*)f_2255},
{"f_2237regex.scm",(void*)f_2237},
{"f_2230regex.scm",(void*)f_2230},
{"f_2087regex.scm",(void*)f_2087},
{"f_2093regex.scm",(void*)f_2093},
{"f_2160regex.scm",(void*)f_2160},
{"f_2148regex.scm",(void*)f_2148},
{"f_2107regex.scm",(void*)f_2107},
{"f_2072regex.scm",(void*)f_2072},
{"f_1875regex.scm",(void*)f_1875},
{"f_2039regex.scm",(void*)f_2039},
{"f_2013regex.scm",(void*)f_2013},
{"f_2038regex.scm",(void*)f_2038},
{"f_1993regex.scm",(void*)f_1993},
{"f_1894regex.scm",(void*)f_1894},
{"f_1902regex.scm",(void*)f_1902},
{"f_1906regex.scm",(void*)f_1906},
{"f_1967regex.scm",(void*)f_1967},
{"f_1948regex.scm",(void*)f_1948},
{"f_1982regex.scm",(void*)f_1982},
{"f_1977regex.scm",(void*)f_1977},
{"f_1865regex.scm",(void*)f_1865},
{"f_1873regex.scm",(void*)f_1873},
{"f_1855regex.scm",(void*)f_1855},
{"f_1863regex.scm",(void*)f_1863},
{"f_1809regex.scm",(void*)f_1809},
{"f_1822regex.scm",(void*)f_1822},
{"f_1797regex.scm",(void*)f_1797},
{"f_1805regex.scm",(void*)f_1805},
{"f_1787regex.scm",(void*)f_1787},
{"f_1795regex.scm",(void*)f_1795},
{"f_1744regex.scm",(void*)f_1744},
{"f_1761regex.scm",(void*)f_1761},
{"f_1672regex.scm",(void*)f_1672},
{"f_1736regex.scm",(void*)f_1736},
{"f_1706regex.scm",(void*)f_1706},
{"f_1728regex.scm",(void*)f_1728},
{"f_1710regex.scm",(void*)f_1710},
{"f_1723regex.scm",(void*)f_1723},
{"f_1714regex.scm",(void*)f_1714},
{"f_1718regex.scm",(void*)f_1718},
{"f_1676regex.scm",(void*)f_1676},
{"f_1685regex.scm",(void*)f_1685},
{"f_1607regex.scm",(void*)f_1607},
{"f_1611regex.scm",(void*)f_1611},
{"f_1619regex.scm",(void*)f_1619},
{"f_1535regex.scm",(void*)f_1535},
{"f_1553regex.scm",(void*)f_1553},
{"f_1587regex.scm",(void*)f_1587},
{"f_1591regex.scm",(void*)f_1591},
{"f_1573regex.scm",(void*)f_1573},
{"f_1477regex.scm",(void*)f_1477},
{"f_1515regex.scm",(void*)f_1515},
{"f_1514regex.scm",(void*)f_1514},
{"f_1490regex.scm",(void*)f_1490},
{"f_1500regex.scm",(void*)f_1500},
{"f_1504regex.scm",(void*)f_1504},
{"f_1499regex.scm",(void*)f_1499},
{"f_1382regex.scm",(void*)f_1382},
{"f_1422regex.scm",(void*)f_1422},
{"f_1417regex.scm",(void*)f_1417},
{"f_1384regex.scm",(void*)f_1384},
{"f_1394regex.scm",(void*)f_1394},
{"f_1413regex.scm",(void*)f_1413},
{"f_1401regex.scm",(void*)f_1401},
{"f_1402regex.scm",(void*)f_1402},
{"f_1406regex.scm",(void*)f_1406},
{"f_1345regex.scm",(void*)f_1345},
{"f_1380regex.scm",(void*)f_1380},
{"f_1368regex.scm",(void*)f_1368},
{"f_1369regex.scm",(void*)f_1369},
{"f_1373regex.scm",(void*)f_1373},
{"f_1347regex.scm",(void*)f_1347},
{"f_1357regex.scm",(void*)f_1357},
{"f_1355regex.scm",(void*)f_1355},
{"f_1330regex.scm",(void*)f_1330},
{"f_1313regex.scm",(void*)f_1313},
{"f_1294regex.scm",(void*)f_1294},
{"f_1306regex.scm",(void*)f_1306},
{"f_1302regex.scm",(void*)f_1302},
{"f_1283regex.scm",(void*)f_1283},
{"f_1288regex.scm",(void*)f_1288},
{"f_1228regex.scm",(void*)f_1228},
{"f_1232regex.scm",(void*)f_1232},
{"f_1256regex.scm",(void*)f_1256},
{"f_1259regex.scm",(void*)f_1259},
{"f_1218regex.scm",(void*)f_1218},
{"f_1223regex.scm",(void*)f_1223},
{"f_1227regex.scm",(void*)f_1227},
{"f_1195regex.scm",(void*)f_1195},
{"f_1200regex.scm",(void*)f_1200},
{"f_1185regex.scm",(void*)f_1185},
{"f_1151regex.scm",(void*)f_1151},
{"f_1157regex.scm",(void*)f_1157},
{"f_986regex.scm",(void*)f_986},
{"f_971regex.scm",(void*)f_971},
{"f_978regex.scm",(void*)f_978},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
