/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2007-10-25 22:02
   Version 2.713 - macosx-unix-gnu-ppc - [ manyargs dload ptables applyhook ]
(c)2000-2007 Felix L. Winkelmann | compiled 2007-09-29 on o3184.o.pppool.de (Darwin)
   command line: regex.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file regex.c
   unit: regex
*/

#include "chicken.h"

static void
out_of_memory_failure(const char *modnam, const char *prcnam, const char *typnam)
{
  fprintf(stderr, "%s@%s: out of memory - cannot allocate %s\\n", modnam, prcnam, typnam);
  exit(EXIT_FAILURE);
}
#include "pcre/pcre.h"
static const char *C_regex_error;
static int C_regex_error_offset;
#define OVECTOR_LENGTH_MULTIPLE 3
#define STATIC_OVECTOR_LEN 256
static int C_regex_ovector[OVECTOR_LENGTH_MULTIPLE * STATIC_OVECTOR_LEN];

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[153];


/* from k1270 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub172(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub172(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
int cc;pcre_fullinfo(code, extra, PCRE_INFO_CAPTURECOUNT, &cc);return(cc + 1);
C_ret:
#undef return

return C_r;}

/* from k1252 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub160(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub160(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
char * str=(char * )C_c_string(C_a2);
int start=(int )C_unfix(C_a3);
int range=(int )C_unfix(C_a4);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a5);
return(pcre_exec(code, extra, str, start + range, start, options, C_regex_ovector, STATIC_OVECTOR_LEN * OVECTOR_LENGTH_MULTIPLE));
C_ret:
#undef return

return C_r;}

/* from k1132 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub139(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub139(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[(i * 2) + 1]);
C_ret:
#undef return

return C_r;}

/* from k1125 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[i * 2]);
C_ret:
#undef return

return C_r;}

/* from k1084 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub122(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
return(pcre_study(code, 0, &C_regex_error));
C_ret:
#undef return

return C_r;}

/* from k903 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub74(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub74(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * patt=(char * )C_c_string(C_a0);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a1);
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a2);
return(pcre_compile(patt, options, &C_regex_error, &C_regex_error_offset, tables));
C_ret:
#undef return

return C_r;}

/* from k865 */
static C_word C_fcall stub49(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub49(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_460)
static void C_ccall f_460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2450)
static void C_fcall f_2450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_fcall f_2445(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2400)
static void C_fcall f_2400(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_fcall f_2357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_ccall f_2302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2311)
static void C_fcall f_2311(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_fcall f_2051(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_fcall f_2109(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2191)
static void C_fcall f_2191(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_fcall f_2111(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_fcall f_1962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1981)
static void C_fcall f_1981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1912)
static void C_fcall f_1912(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1790)
static void C_fcall f_1790(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_fcall f_1684(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1690)
static void C_fcall f_1690(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static C_word C_fcall f_1669(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_fcall f_1499(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_fcall f_1406(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1419)
static void C_fcall f_1419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1335)
static void C_fcall f_1335(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_fcall f_1277(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1136)
static void C_fcall f_1136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_fcall f_1154(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1188)
static void C_fcall f_1188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1033)
static void C_fcall f_1033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_fcall f_1028(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1001)
static void C_fcall f_1001(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_997)
static void C_ccall f_997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_fcall f_931(C_word t0,C_word t1) C_noret;
C_noret_decl(f_952)
static void C_fcall f_952(C_word t0,C_word t1) C_noret;
C_noret_decl(f_914)
static void C_fcall f_914(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_878)
static void C_fcall f_878(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_862)
static void C_ccall f_862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_490)
static void C_fcall f_490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_500)
static void C_fcall f_500(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_2450)
static void C_fcall trf_2450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2450(t0,t1);}

C_noret_decl(trf_2445)
static void C_fcall trf_2445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2445(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2445(t0,t1,t2);}

C_noret_decl(trf_2400)
static void C_fcall trf_2400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2400(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2400(t0,t1,t2,t3);}

C_noret_decl(trf_2357)
static void C_fcall trf_2357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2357(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2357(t0,t1,t2);}

C_noret_decl(trf_2311)
static void C_fcall trf_2311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2311(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2311(t0,t1,t2);}

C_noret_decl(trf_2051)
static void C_fcall trf_2051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2051(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2051(t0,t1,t2);}

C_noret_decl(trf_2109)
static void C_fcall trf_2109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2109(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2109(t0,t1,t2);}

C_noret_decl(trf_2191)
static void C_fcall trf_2191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2191(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2191(t0,t1);}

C_noret_decl(trf_2111)
static void C_fcall trf_2111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2111(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2111(t0,t1,t2,t3);}

C_noret_decl(trf_1962)
static void C_fcall trf_1962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1962(t0,t1,t2);}

C_noret_decl(trf_1981)
static void C_fcall trf_1981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1981(t0,t1);}

C_noret_decl(trf_1912)
static void C_fcall trf_1912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1912(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1912(t0,t1,t2,t3);}

C_noret_decl(trf_1790)
static void C_fcall trf_1790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1790(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1790(t0,t1,t2,t3);}

C_noret_decl(trf_1684)
static void C_fcall trf_1684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1684(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1684(t0,t1,t2);}

C_noret_decl(trf_1690)
static void C_fcall trf_1690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1690(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1690(t0,t1,t2,t3);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1491(t0,t1);}

C_noret_decl(trf_1499)
static void C_fcall trf_1499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1499(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1499(t0,t1,t2,t3);}

C_noret_decl(trf_1406)
static void C_fcall trf_1406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1406(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1406(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1419)
static void C_fcall trf_1419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1419(t0,t1);}

C_noret_decl(trf_1335)
static void C_fcall trf_1335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1335(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1335(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1277)
static void C_fcall trf_1277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1277(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1277(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1208)
static void C_fcall trf_1208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1208(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1208(t0,t1,t2,t3);}

C_noret_decl(trf_1136)
static void C_fcall trf_1136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1136(t0,t1);}

C_noret_decl(trf_1154)
static void C_fcall trf_1154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1154(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1154(t0,t1,t2);}

C_noret_decl(trf_1188)
static void C_fcall trf_1188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1188(t0,t1);}

C_noret_decl(trf_1033)
static void C_fcall trf_1033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1033(t0,t1);}

C_noret_decl(trf_1028)
static void C_fcall trf_1028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1028(t0,t1,t2);}

C_noret_decl(trf_1001)
static void C_fcall trf_1001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1001(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1001(t0,t1,t2,t3);}

C_noret_decl(trf_931)
static void C_fcall trf_931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_931(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_931(t0,t1);}

C_noret_decl(trf_952)
static void C_fcall trf_952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_952(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_952(t0,t1);}

C_noret_decl(trf_914)
static void C_fcall trf_914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_914(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_914(t0,t1,t2,t3);}

C_noret_decl(trf_878)
static void C_fcall trf_878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_878(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_878(t0,t1,t2,t3,t4);}

C_noret_decl(trf_490)
static void C_fcall trf_490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_490(t0,t1);}

C_noret_decl(trf_500)
static void C_fcall trf_500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_500(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_500(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(740)){
C_save(t1);
C_rereclaim2(740*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,153);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[2]=C_h_intern(&lf[2],24,"\003sysregex-chardef-table\077");
lf[3]=C_h_intern(&lf[3],13,"chardef-table");
lf[4]=C_static_lambda_info(C_heaptop,31,"(##sys#regex-chardef-table\077 x2)");
lf[5]=C_h_intern(&lf[5],23,"\003syscheck-chardef-table");
lf[6]=C_h_intern(&lf[6],9,"\003syserror");
lf[7]=C_static_string(C_heaptop,45,"invalid character definition tables structure");
lf[8]=C_static_lambda_info(C_heaptop,35,"(##sys#check-chardef-table x5 loc6)");
lf[10]=C_h_intern(&lf[10],8,"caseless");
lf[11]=C_h_intern(&lf[11],9,"multiline");
lf[12]=C_h_intern(&lf[12],6,"dotall");
lf[13]=C_h_intern(&lf[13],8,"extended");
lf[14]=C_h_intern(&lf[14],8,"anchored");
lf[15]=C_h_intern(&lf[15],14,"dollar-endonly");
lf[16]=C_h_intern(&lf[16],5,"extra");
lf[17]=C_h_intern(&lf[17],6,"notbol");
lf[18]=C_h_intern(&lf[18],6,"noteol");
lf[19]=C_h_intern(&lf[19],8,"ungreedy");
lf[20]=C_h_intern(&lf[20],8,"notempty");
lf[21]=C_h_intern(&lf[21],4,"utf8");
lf[22]=C_h_intern(&lf[22],15,"no-auto-capture");
lf[23]=C_h_intern(&lf[23],13,"no-utf8-check");
lf[24]=C_h_intern(&lf[24],12,"auto-callout");
lf[25]=C_h_intern(&lf[25],7,"partial");
lf[26]=C_h_intern(&lf[26],12,"dfa-shortest");
lf[27]=C_h_intern(&lf[27],11,"dfa-restart");
lf[28]=C_h_intern(&lf[28],9,"firstline");
lf[29]=C_h_intern(&lf[29],8,"dupnames");
lf[30]=C_h_intern(&lf[30],10,"newline-cr");
lf[31]=C_h_intern(&lf[31],10,"newline-lf");
lf[32]=C_h_intern(&lf[32],12,"newline-crlf");
lf[33]=C_h_intern(&lf[33],11,"newline-any");
lf[34]=C_h_intern(&lf[34],15,"newline-anycrlf");
lf[35]=C_h_intern(&lf[35],11,"bsr-anycrlf");
lf[36]=C_h_intern(&lf[36],11,"bsr-unicode");
lf[37]=C_h_intern(&lf[37],5,"error");
lf[38]=C_static_string(C_heaptop,20,"not a member of enum");
lf[39]=C_h_intern(&lf[39],11,"pcre-option");
lf[40]=C_static_lambda_info(C_heaptop,19,"(loop syms36 sum37)");
lf[41]=C_static_lambda_info(C_heaptop,28,"(pcre-option->number syms34)");
lf[43]=C_static_lambda_info(C_heaptop,20,"(re-finalizer a4852)");
lf[44]=C_h_intern(&lf[44],7,"regexp\077");
lf[45]=C_h_intern(&lf[45],6,"regexp");
lf[46]=C_static_lambda_info(C_heaptop,13,"(regexp\077 x65)");
lf[47]=C_h_intern(&lf[47],13,"string-append");
lf[49]=C_static_string(C_heaptop,3," - ");
lf[50]=C_h_intern(&lf[50],17,"\003syspeek-c-string");
lf[51]=C_static_lambda_info(C_heaptop,29,"(re-error loc68 msg69 args70)");
lf[53]=C_static_string(C_heaptop,33,"cannot compile regular expression");
lf[54]=C_h_intern(&lf[54],17,"\003sysmake-c-string");
lf[55]=C_static_lambda_info(C_heaptop,46,"(re-checked-compile pattern82 options83 loc85)");
lf[56]=C_static_lambda_info(C_heaptop,18,"(options->integer)");
lf[57]=C_h_intern(&lf[57],14,"set-finalizer!");
lf[58]=C_static_lambda_info(C_heaptop,30,"(regexp pattern89 . options90)");
lf[59]=C_h_intern(&lf[59],7,"regexp*");
lf[60]=C_static_lambda_info(C_heaptop,30,"(body100 options106 tables107)");
lf[61]=C_static_lambda_info(C_heaptop,29,"(def-tables103 %options98114)");
lf[62]=C_static_lambda_info(C_heaptop,16,"(def-options102)");
lf[63]=C_static_lambda_info(C_heaptop,28,"(regexp* pattern96 . args97)");
lf[64]=C_h_intern(&lf[64],15,"regexp-optimize");
lf[65]=C_static_string(C_heaptop,34,"cannot optimize regular expression");
lf[66]=C_static_lambda_info(C_heaptop,23,"(regexp-optimize rx126)");
lf[68]=C_static_lambda_info(C_heaptop,11,"(loop i146)");
lf[69]=C_static_lambda_info(C_heaptop,35,"(gather-result-positions result142)");
lf[70]=C_h_intern(&lf[70],9,"substring");
lf[72]=C_static_lambda_info(C_heaptop,15,"(a1219 poss153)");
lf[73]=C_h_intern(&lf[73],7,"\003sysmap");
lf[74]=C_static_lambda_info(C_heaptop,33,"(gather-results str150 result151)");
lf[76]=C_h_intern(&lf[76],15,"\003syssignal-hook");
lf[77]=C_h_intern(&lf[77],11,"\000type-error");
lf[78]=C_static_string(C_heaptop,63,"bad argument type - not a string or compiled regular expression");
lf[79]=C_static_lambda_info(C_heaptop,49,"(perform-match rgxp178 str179 si180 ri181 loc182)");
lf[80]=C_h_intern(&lf[80],19,"\003sysundefined-value");
lf[81]=C_h_intern(&lf[81],12,"string-match");
lf[82]=C_h_intern(&lf[82],22,"string-match-positions");
lf[83]=C_h_intern(&lf[83],21,"make-anchored-pattern");
lf[84]=C_static_lambda_info(C_heaptop,46,"(prepare-match rgxp196 str197 start198 loc199)");
lf[85]=C_static_lambda_info(C_heaptop,40,"(string-match rgxp203 str204 . start205)");
lf[86]=C_static_lambda_info(C_heaptop,50,"(string-match-positions rgxp206 str207 . start208)");
lf[87]=C_h_intern(&lf[87],13,"string-search");
lf[88]=C_h_intern(&lf[88],23,"string-search-positions");
lf[89]=C_static_lambda_info(C_heaptop,57,"(prepare-search rgxp212 str213 start-and-range214 loc215)");
lf[90]=C_static_lambda_info(C_heaptop,51,"(string-search rgxp222 str223 . start-and-range224)");
lf[91]=C_static_lambda_info(C_heaptop,61,"(string-search-positions rgxp225 str226 . start-and-range227)");
lf[92]=C_h_intern(&lf[92],7,"reverse");
lf[93]=C_h_intern(&lf[93],19,"string-split-fields");
lf[94]=C_h_intern(&lf[94],6,"\000infix");
lf[95]=C_h_intern(&lf[95],7,"\000suffix");
lf[96]=C_static_lambda_info(C_heaptop,31,"(f_1574 start254 from255 to256)");
lf[97]=C_static_lambda_info(C_heaptop,31,"(f_1579 start257 from258 to259)");
lf[98]=C_static_lambda_info(C_heaptop,21,"(loop ms261 start262)");
lf[99]=C_static_string(C_heaptop,31,"record does not end with suffix");
lf[100]=C_static_lambda_info(C_heaptop,23,"(f_1590 ms243 start244)");
lf[101]=C_static_string(C_heaptop,0,"");
lf[102]=C_static_lambda_info(C_heaptop,23,"(f_1610 ms245 start246)");
lf[103]=C_static_lambda_info(C_heaptop,23,"(f_1636 ms247 start248)");
lf[104]=C_static_lambda_info(C_heaptop,56,"(string-split-fields rgxp233 str234 . mode-and-start235)");
lf[105]=C_h_intern(&lf[105],11,"make-string");
lf[106]=C_h_intern(&lf[106],17,"string-substitute");
lf[107]=C_static_lambda_info(C_heaptop,6,"(push)");
lf[108]=C_static_lambda_info(C_heaptop,24,"(loop start288 index289)");
lf[109]=C_static_lambda_info(C_heaptop,23,"(substitute matches286)");
lf[110]=C_static_string(C_heaptop,24,"empty substitution match");
lf[111]=C_h_intern(&lf[111],21,"\003sysfragments->string");
lf[112]=C_static_lambda_info(C_heaptop,24,"(loop index298 count299)");
lf[113]=C_static_lambda_info(C_heaptop,57,"(string-substitute regex273 subst274 string275 . flag276)");
lf[114]=C_h_intern(&lf[114],18,"string-substitute*");
lf[115]=C_static_lambda_info(C_heaptop,21,"(loop str319 smap320)");
lf[116]=C_static_lambda_info(C_heaptop,45,"(string-substitute* str314 smap315 . mode316)");
lf[117]=C_h_intern(&lf[117],5,"glob\077");
lf[118]=C_static_lambda_info(C_heaptop,13,"(loop idx327)");
lf[119]=C_static_lambda_info(C_heaptop,14,"(glob\077 str325)");
lf[120]=C_h_intern(&lf[120],12,"list->string");
lf[121]=C_h_intern(&lf[121],12,"string->list");
lf[122]=C_h_intern(&lf[122],12,"glob->regexp");
lf[123]=C_static_lambda_info(C_heaptop,19,"(g353 c357 more358)");
lf[124]=C_static_string(C_heaptop,33,"unexpected end of character class");
lf[125]=C_h_intern(&lf[125],15,"\003sysmatch-error");
lf[126]=C_static_lambda_info(C_heaptop,15,"(loop2 rest348)");
lf[127]=C_static_lambda_info(C_heaptop,12,"(loop cs344)");
lf[128]=C_static_lambda_info(C_heaptop,19,"(glob->regexp s342)");
lf[129]=C_h_intern(&lf[129],4,"grep");
lf[130]=C_static_lambda_info(C_heaptop,13,"(loop lst374)");
lf[131]=C_static_lambda_info(C_heaptop,21,"(grep rgxp371 lst372)");
lf[132]=C_h_intern(&lf[132],18,"open-output-string");
lf[133]=C_h_intern(&lf[133],17,"get-output-string");
lf[134]=C_h_intern(&lf[134],13,"regexp-escape");
lf[135]=C_h_intern(&lf[135],16,"\003syswrite-char-0");
lf[136]=C_static_lambda_info(C_heaptop,11,"(loop i385)");
lf[137]=C_static_lambda_info(C_heaptop,22,"(regexp-escape str381)");
lf[138]=C_static_string(C_heaptop,0,"");
lf[139]=C_static_string(C_heaptop,1,"^");
lf[140]=C_static_string(C_heaptop,0,"");
lf[141]=C_static_string(C_heaptop,1,"$");
lf[142]=C_h_intern(&lf[142],10,"bitwise-or");
lf[143]=C_h_intern(&lf[143],7,"warning");
lf[144]=C_static_string(C_heaptop,60,"cannot select partial anchor for compiled regular expression");
lf[145]=C_static_lambda_info(C_heaptop,23,"(body396 nos402 noe403)");
lf[146]=C_static_lambda_info(C_heaptop,23,"(def-noe399 %nos394413)");
lf[147]=C_static_lambda_info(C_heaptop,12,"(def-nos398)");
lf[148]=C_static_lambda_info(C_heaptop,41,"(make-anchored-pattern rgxp392 . args393)");
lf[149]=C_h_intern(&lf[149],17,"register-feature!");
lf[150]=C_h_intern(&lf[150],5,"regex");
lf[151]=C_h_intern(&lf[151],4,"pcre");
lf[152]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf2(lf,153,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_460,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 125  register-feature! */
t4=*((C_word*)lf[149]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[150],lf[151]);}

/* k458 */
static void C_ccall f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word ab[100],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_462,a[2]=lf[4],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_478,a[2]=lf[8],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_490,a[2]=lf[41],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_862,a[2]=lf[43],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_872,a[2]=lf[46],tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[47]+1);
t8=C_mutate(&lf[48],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_878,a[2]=t7,a[3]=lf[51],tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[52],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_914,a[2]=lf[55],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_929,a[2]=lf[58],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=lf[63],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1088,a[2]=lf[66],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[67],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1136,a[2]=lf[69],tmp=(C_word)a,a+=3,tmp));
t14=*((C_word*)lf[70]+1);
t15=C_mutate(&lf[71],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1208,a[2]=t14,a[3]=lf[74],tmp=(C_word)a,a+=4,tmp));
t16=C_mutate(&lf[75],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=lf[79],tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[80]+1);
t18=C_mutate((C_word*)lf[81]+1,t17);
t19=*((C_word*)lf[80]+1);
t20=C_mutate((C_word*)lf[82]+1,t19);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1335,a[2]=lf[84],tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1378,a[2]=t21,a[3]=lf[85],tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1388,a[2]=t21,a[3]=lf[86],tmp=(C_word)a,a+=4,tmp));
t24=*((C_word*)lf[80]+1);
t25=C_mutate((C_word*)lf[87]+1,t24);
t26=*((C_word*)lf[80]+1);
t27=C_mutate((C_word*)lf[88]+1,t26);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=lf[89],tmp=(C_word)a,a+=3,tmp);
t29=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1452,a[2]=t28,a[3]=lf[90],tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1462,a[2]=t28,a[3]=lf[91],tmp=(C_word)a,a+=4,tmp));
t31=*((C_word*)lf[92]+1);
t32=*((C_word*)lf[70]+1);
t33=*((C_word*)lf[88]+1);
t34=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1472,a[2]=t31,a[3]=t33,a[4]=t32,a[5]=lf[104],tmp=(C_word)a,a+=6,tmp));
t35=*((C_word*)lf[70]+1);
t36=*((C_word*)lf[92]+1);
t37=*((C_word*)lf[105]+1);
t38=*((C_word*)lf[88]+1);
t39=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1654,a[2]=t38,a[3]=t36,a[4]=t35,a[5]=lf[113],tmp=(C_word)a,a+=6,tmp));
t40=*((C_word*)lf[106]+1);
t41=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1897,a[2]=t40,a[3]=lf[116],tmp=(C_word)a,a+=4,tmp));
t42=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1949,a[2]=lf[119],tmp=(C_word)a,a+=3,tmp));
t43=*((C_word*)lf[120]+1);
t44=*((C_word*)lf[121]+1);
t45=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2034,a[2]=t44,a[3]=t43,a[4]=lf[128],tmp=(C_word)a,a+=5,tmp));
t46=*((C_word*)lf[87]+1);
t47=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2302,a[2]=t46,a[3]=lf[131],tmp=(C_word)a,a+=4,tmp));
t48=*((C_word*)lf[132]+1);
t49=*((C_word*)lf[133]+1);
t50=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2342,a[2]=t48,a[3]=t49,a[4]=lf[137],tmp=(C_word)a,a+=5,tmp));
t51=*((C_word*)lf[47]+1);
t52=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2398,a[2]=t51,a[3]=lf[148],tmp=(C_word)a,a+=4,tmp));
t53=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t53+1)))(2,t53,C_SCHEME_UNDEFINED);}

/* make-anchored-pattern in k458 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2398r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2398r(t0,t1,t2,t3);}}

static void C_ccall f_2398r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[145],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2445,a[2]=t4,a[3]=lf[146],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2450,a[2]=t5,a[3]=lf[147],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-nos398414 */
t7=t6;
f_2450(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-noe399412 */
t9=t5;
f_2445(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body396401 */
t11=t4;
f_2400(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-nos398 in make-anchored-pattern in k458 */
static void C_fcall f_2450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2450,NULL,2,t0,t1);}
/* def-noe399412 */
t2=((C_word*)t0)[2];
f_2445(t2,t1,C_SCHEME_FALSE);}

/* def-noe399 in make-anchored-pattern in k458 */
static void C_fcall f_2445(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2445,NULL,3,t0,t1,t2);}
/* body396401 */
t3=((C_word*)t0)[2];
f_2400(t3,t1,t2,C_SCHEME_FALSE);}

/* body396 in make-anchored-pattern in k458 */
static void C_fcall f_2400(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2400,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t4=(C_truep(t2)?lf[138]:lf[139]);
t5=(C_truep(t3)?lf[140]:lf[141]);
/* regex.scm: 638  string-append */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t4,((C_word*)t0)[3],t5);}
else{
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[45],lf[83]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2424,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=(C_truep(t6)?t6:t3);
if(C_truep(t7)){
/* regex.scm: 642  warning */
t8=*((C_word*)lf[143]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,lf[83],lf[144]);}
else{
t8=t5;
f_2424(2,t8,C_SCHEME_UNDEFINED);}}}

/* k2422 in body396 in make-anchored-pattern in k458 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[45]+1);
t5=(C_word)C_slot(t4,C_fix(3));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2438,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 646  pcre-option->number */
f_490(t6,lf[14]);}

/* k2436 in k2422 in body396 in make-anchored-pattern in k458 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 645  bitwise-or */
t2=*((C_word*)lf[142]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2425 in k2422 in body396 in make-anchored-pattern in k458 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* regexp-escape in k458 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2342,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[134]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2349,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 617  open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2347 in regexp-escape in k458 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2357,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=lf[136],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2357(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k2347 in regexp-escape in k458 */
static void C_fcall f_2357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2357,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* regex.scm: 620  get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 623  ##sys#write-char-0 */
t5=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2389,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 627  ##sys#write-char-0 */
t5=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k2387 in loop in k2347 in regexp-escape in k458 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 628  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2357(t3,((C_word*)t0)[2],t2);}

/* k2374 in loop in k2347 in regexp-escape in k458 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 624  ##sys#write-char-0 */
t3=*((C_word*)lf[135]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k2377 in k2374 in loop in k2347 in regexp-escape in k458 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 625  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2357(t3,((C_word*)t0)[2],t2);}

/* grep in k458 */
static void C_ccall f_2302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2302,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[129]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2311,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=lf[130],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2311(t8,t1,t3);}

/* loop in grep in k458 */
static void C_fcall f_2311(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2311,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2330,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 605  string-search */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k2328 in loop in grep in k458 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2330,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 606  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2311(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 607  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2311(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2335 in k2328 in loop in grep in k458 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k458 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2034,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[122]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2045,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2049,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 572  string->list */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k2047 in glob->regexp in k458 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=lf[127],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2051(t5,((C_word*)t0)[2],t1);}

/* loop in k2047 in glob->regexp in k458 */
static void C_fcall f_2051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2051,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2081,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 577  loop */
t16=t5;
t17=t4;
t1=t16;
t2=t17;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 578  loop */
t16=t5;
t17=t4;
t1=t16;
t2=t17;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2107,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=lf[126],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2109(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2286,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 590  loop */
t16=t7;
t17=t4;
t1=t16;
t2=t17;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 591  loop */
t16=t7;
t17=t4;
t1=t16;
t2=t17;
goto loop;}}}}

/* k2295 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2297,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k2284 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2286,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k2047 in glob->regexp in k458 */
static void C_fcall f_2109(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2109,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[4],a[3]=lf[123],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,C_make_character(93));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2141,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 584  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2051(t8,t7,t6);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,C_make_character(45));
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_i_cddr(t2);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2170,a[2]=t1,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* loop2347 */
t22=t11;
t23=t10;
t1=t22;
t2=t23;
goto loop;}
else{
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cdr(t2);
/* g353356 */
t11=t3;
f_2111(t11,t1,t9,t10);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2191,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_eqp(t10,C_make_character(45));
if(C_truep(t11)){
t12=(C_word)C_i_cddr(t2);
t13=t8;
f_2191(t13,(C_word)C_i_pairp(t12));}
else{
t12=t8;
f_2191(t12,C_SCHEME_FALSE);}}
else{
t10=t8;
f_2191(t10,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* error */
t4=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[122],lf[124],((C_word*)t0)[2]);}
else{
/* ##sys#match-error */
t4=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}}

/* k2189 in loop2 in loop in k2047 in glob->regexp in k458 */
static void C_fcall f_2191(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2191,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2215,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* loop2347 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2109(t6,t5,t4);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g353356 */
t4=((C_word*)t0)[2];
f_2111(t4,((C_word*)t0)[4],t2,t3);}}

/* k2213 in k2189 in loop2 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2168 in loop2 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2170,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k2139 in loop2 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2141,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* g353 in loop2 in loop in k2047 in glob->regexp in k458 */
static void C_fcall f_2111(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2111,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2119,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 587  loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2109(t5,t4,t3);}

/* k2117 in g353 in loop2 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2105 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k2092 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k2079 in loop in k2047 in glob->regexp in k458 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k2043 in glob->regexp in k458 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 571  list->string */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k458 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1949,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[117]);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1962,a[2]=t7,a[3]=t2,a[4]=lf[118],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1962(t9,t1,t5);}

/* loop in glob? in k458 */
static void C_fcall f_1962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1962,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1981(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_1981(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1979 in loop in glob? in k458 */
static void C_fcall f_1981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 562  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1962(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 564  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1962(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k458 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1897r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1897r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1897r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_string_2(t2,lf[114]);
t6=(C_word)C_i_check_list_2(t3,lf[114]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1912,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=lf[115],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_1912(t12,t1,t2,t3);}

/* loop in string-substitute* in k458 */
static void C_fcall f_1912(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1912,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1929,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_cdr(t4);
/* regex.scm: 547  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k1927 in loop in string-substitute* in k458 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* regex.scm: 547  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1912(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k458 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+34)){
C_save_and_reclaim((void*)tr5rv,(void*)f_1654r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_1654r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1654r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(34);
t6=(C_word)C_i_check_string_2(t3,lf[106]);
t7=(C_word)C_notvemptyp(t5);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t5,C_fix(0)):C_fix(1));
t9=(C_word)C_block_size(t3);
t10=(C_word)C_fixnum_difference(t9,C_fix(1));
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_fix(0);
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1669,a[2]=t14,a[3]=t12,a[4]=lf[107],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1684,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t15,a[7]=t10,a[8]=lf[109],tmp=(C_word)a,a+=9,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=((C_word*)t0)[3],a[5]=t14,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=t16,a[9]=t18,a[10]=t15,a[11]=t8,a[12]=t2,a[13]=lf[112],tmp=(C_word)a,a+=14,tmp));
t20=((C_word*)t18)[1];
f_1790(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k458 */
static void C_fcall f_1790(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1790,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* regex.scm: 518  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[12],((C_word*)t0)[6],t2);}

/* k1792 in loop in string-substitute in k458 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 523  ##sys#error */
t8=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[106],lf[110],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1834,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
/* regex.scm: 527  substring */
t13=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t13))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1852,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 531  substring */
t12=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 534  substring */
t4=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k1883 in k1792 in loop in string-substitute in k458 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=f_1669(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 535  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1879 in k1883 in k1792 in loop in string-substitute in k458 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 535  ##sys#fragments->string */
t2=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1850 in k1792 in loop in string-substitute in k458 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=f_1669(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 532  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1790(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1832 in k1792 in loop in string-substitute in k458 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=f_1669(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 528  substitute */
t4=((C_word*)t0)[3];
f_1684(t4,t3,((C_word*)t0)[2]);}

/* k1825 in k1832 in k1792 in loop in string-substitute in k458 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 529  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1790(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k458 */
static void C_fcall f_1684(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1684,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=lf[108],tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_1690(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k458 */
static void C_fcall f_1690(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1690,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1704,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_1704(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 505  substring */
t6=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 512  substring */
t14=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t14))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_fixnum_plus(t5,C_fix(1));
/* regex.scm: 515  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 516  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k1755 in loop in substitute in string-substitute in k458 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1757,2,t0,t1);}
t2=f_1669(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 513  substring */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k1743 in k1755 in loop in substitute in string-substitute in k458 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=f_1669(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 514  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1690(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k1702 in loop in substitute in string-substitute in k458 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
/* regex.scm: 505  push */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_1669(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k458 */
static C_word C_fcall f_1669(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k458 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+28)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1472r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1472r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1472r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(28);
t5=(C_word)C_i_check_string_2(t3,lf[93]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_i_vector_ref(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1491,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[95]);
if(C_truep(t13)){
t14=t12;
f_1491(t14,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,a[6]=lf[100],tmp=(C_word)a,a+=7,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[94]);
t15=t12;
f_1491(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1610,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=lf[102],tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],a[3]=lf[103],tmp=(C_word)a,a+=4,tmp)));}}

/* f_1636 in string-split-fields in k458 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1636,4,t0,t1,t2,t3);}
/* regex.scm: 467  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* f_1610 in string-split-fields in k458 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1610,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[101],t2);
/* regex.scm: 465  reverse */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1635,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 466  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k1633 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 466  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* f_1590 in string-split-fields in k458 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1590,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 459  ##sys#error */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[93],lf[99],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 461  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* k1489 in string-split-fields in k458 */
static void C_fcall f_1491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1491,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[94]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[95]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[96],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=lf[97],tmp=(C_word)a,a+=5,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=lf[98],tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_1499(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k1489 in string-split-fields in k458 */
static void C_fcall f_1499(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1499,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1503,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 472  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1501 in loop in k1489 in string-split-fields in k458 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1503,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 479  fini */
t7=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_fixnum_plus(t4,C_fix(2));
/* regex.scm: 480  fetch */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1564,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 481  fetch */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 482  fini */
t2=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1562 in k1501 in loop in k1489 in string-split-fields in k458 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1564,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 481  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1499(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1543 in k1501 in loop in k1489 in string-split-fields in k458 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 480  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1499(t4,((C_word*)t0)[2],t2,t3);}

/* f_1579 in k1489 in string-split-fields in k458 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1579,5,t0,t1,t2,t3,t4);}
/* regex.scm: 470  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_1574 in k1489 in string-split-fields in k458 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1574,5,t0,t1,t2,t3,t4);}
/* regex.scm: 469  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k458 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1462r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1462r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1462r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1470,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 440  prepare-search */
f_1406(t5,t2,t3,t4,lf[88]);}

/* k1468 in string-search-positions in k458 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 440  gather-result-positions */
f_1136(((C_word*)t0)[2],t1);}

/* string-search in k458 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1452r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1452r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1452r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 436  prepare-search */
f_1406(t5,t2,t3,t4,lf[87]);}

/* k1458 in string-search in k458 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 436  gather-results */
t2=lf[71];
f_1208(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-search in k458 */
static void C_fcall f_1406(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1406,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t9=(C_truep(t8)?(C_word)C_i_car(t4):C_fix(0));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1419,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t11=t10;
f_1419(t11,(C_word)C_i_car(t8));}
else{
t11=(C_word)C_block_size(t3);
t12=t10;
f_1419(t12,(C_word)C_fixnum_difference(t11,t9));}}

/* k1417 in prepare-search in k458 */
static void C_fcall f_1419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_check_exact_2(t1,((C_word*)t0)[5]);
/* regex.scm: 432  perform-match */
f_1277(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],t1,((C_word*)t0)[5]);}

/* string-match-positions in k458 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1388r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1388r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1388r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1396,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 413  prepare-match */
f_1335(t5,t2,t3,t4,lf[82]);}

/* k1394 in string-match-positions in k458 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 413  gather-result-positions */
f_1136(((C_word*)t0)[2],t1);}

/* string-match in k458 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1378r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1378r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1378r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1386,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 409  prepare-match */
f_1335(t5,t2,t3,t4,lf[81]);}

/* k1384 in string-match in k458 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 409  gather-results */
t2=lf[71];
f_1208(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-match in k458 */
static void C_fcall f_1335(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1335,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_i_car(t4):C_fix(0));
t9=(C_word)C_i_check_exact_2(t8,t5);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1352,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t11=(C_word)C_fixnum_lessp(C_fix(0),t8);
/* regex.scm: 402  make-anchored-pattern */
t12=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t2,t11);}
else{
t11=t10;
f_1352(2,t11,t2);}}

/* k1350 in prepare-match in k458 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_difference(t2,((C_word*)t0)[4]);
/* regex.scm: 401  perform-match */
f_1277(((C_word*)t0)[3],t1,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[2]);}

/* perform-match in k458 */
static void C_fcall f_1277(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1277,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1281,a[2]=t2,a[3]=t1,a[4]=t10,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* regex.scm: 373  re-checked-compile */
f_914(t11,t2,C_fix(0),t6);}
else{
t12=t2;
if(C_truep((C_word)C_i_structurep(t12,lf[45]))){
t13=t2;
t14=(C_word)C_slot(t13,C_fix(2));
t15=C_set_block_item(t8,0,t14);
t16=t2;
t17=(C_word)C_slot(t16,C_fix(3));
t18=C_set_block_item(t10,0,t17);
t19=t2;
t20=t11;
f_1281(2,t20,(C_word)C_slot(t19,C_fix(1)));}
else{
/* regex.scm: 379  ##sys#signal-hook */
t13=*((C_word*)lf[76]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t11,lf[77],t6,lf[78],t2);}}}

/* k1279 in perform-match in k458 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=t1;
t3=((C_word*)((C_word*)t0)[8])[1];
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)stub172(C_SCHEME_UNDEFINED,t4,t5);
t7=t1;
t8=((C_word*)((C_word*)t0)[8])[1];
t9=((C_word*)t0)[7];
t10=((C_word*)t0)[6];
t11=((C_word*)t0)[5];
t12=((C_word*)((C_word*)t0)[4])[1];
t13=(C_word)C_i_foreign_pointer_argumentp(t7);
t14=(C_truep(t8)?(C_word)C_i_foreign_pointer_argumentp(t8):C_SCHEME_FALSE);
t15=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1242,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=t14,a[7]=t13,a[8]=t12,a[9]=t11,a[10]=t10,tmp=(C_word)a,a+=11,tmp);
t16=(C_word)C_i_foreign_string_argumentp(t9);
/* ##sys#make-c-string */
t17=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t15,t16);}

/* k1240 in k1279 in perform-match in k458 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[10]);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[9]);
t4=(C_word)C_i_foreign_unsigned_integer_argumentp(((C_word*)t0)[8]);
t5=(C_word)stub160(C_SCHEME_UNDEFINED,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2,t3,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1290,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
/* regex.scm: 385  re-finalizer */
t7=lf[42];
f_862(3,t7,t6,((C_word*)t0)[2]);}
else{
t7=t6;
f_1290(2,t7,C_SCHEME_UNDEFINED);}}

/* k1288 in k1240 in k1279 in perform-match in k458 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1290,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* gather-results in k458 */
static void C_fcall f_1208(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1208,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 349  gather-result-positions */
f_1136(t4,t3);}

/* k1210 in gather-results in k458 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[72],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 351  ##sys#map */
t3=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1219 in k1210 in gather-results in k458 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1220,3,t0,t1,t2);}
if(C_truep(t2)){
C_apply(5,0,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* gather-result-positions in k458 */
static void C_fcall f_1136(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1136,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1154,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=lf[68],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1154(t8,t1,C_fix(0));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* loop in gather-result-positions in k458 */
static void C_fcall f_1154(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1154,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* regex.scm: 339  loop */
t13=t3;
t14=t4;
t1=t13;
t2=t14;
goto loop;}
else{
t3=t2;
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=(C_word)stub135(C_SCHEME_UNDEFINED,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1188,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(0)))){
t7=t2;
t8=(C_word)C_i_foreign_fixnum_argumentp(t7);
t9=(C_word)stub139(C_SCHEME_UNDEFINED,t8);
t10=t6;
f_1188(t10,(C_word)C_a_i_list(&a,2,t5,t9));}
else{
t7=t6;
f_1188(t7,C_SCHEME_FALSE);}}}}

/* k1186 in loop in gather-result-positions in k458 */
static void C_fcall f_1188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1188,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1192,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* regex.scm: 344  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1154(t4,t2,t3);}

/* k1190 in k1186 in loop in gather-result-positions in k458 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1172 in loop in gather-result-positions in k458 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* regexp-optimize in k458 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1088,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[45],lf[64]);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t7=(C_word)C_i_foreign_pointer_argumentp(t5);
t8=(C_word)stub122(t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1101,a[2]=t8,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k1099 in regexp-optimize in k458 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1101,2,t0,t1);}
if(C_truep(t1)){
/* regex.scm: 299  re-error */
t2=lf[48];
f_878(t2,((C_word*)t0)[4],lf[64],lf[65],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1110,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* set-finalizer! */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[42]);}
else{
t4=t3;
f_1110(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k1108 in k1099 in regexp-optimize in k458 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* regexp* in k458 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_999r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_999r(t0,t1,t2,t3);}}

static void C_ccall f_999r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1001,a[2]=t2,a[3]=lf[60],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1028,a[2]=t4,a[3]=lf[61],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1033,a[2]=t5,a[3]=lf[62],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-options102115 */
t7=t6;
f_1033(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-tables103113 */
t9=t5;
f_1028(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body100105 */
t11=t4;
f_1001(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-options102 in regexp* in k458 */
static void C_fcall f_1033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1033,NULL,2,t0,t1);}
/* def-tables103113 */
t2=((C_word*)t0)[2];
f_1028(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-tables103 in regexp* in k458 */
static void C_fcall f_1028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1028,NULL,3,t0,t1,t2);}
/* body100105 */
t3=((C_word*)t0)[2];
f_1001(t3,t1,t2,C_SCHEME_FALSE);}

/* body100 in regexp* in k458 */
static void C_fcall f_1001(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1001,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[59]);
t5=(C_word)C_i_check_list_2(t2,lf[59]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1011,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex.scm: 280  ##sys#check-chardef-table */
t7=*((C_word*)lf[5]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,lf[59]);}
else{
t7=t6;
f_1011(2,t7,C_SCHEME_UNDEFINED);}}

/* k1009 in body100 in regexp* in k458 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 281  pcre-option->number */
f_490(t3,((C_word*)t0)[2]);}

/* k1022 in k1009 in body100 in regexp* in k458 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 281  re-checked-compile */
f_914(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[59]);}

/* k1012 in k1009 in body100 in regexp* in k458 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1017,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* set-finalizer! */
t3=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[42]);}

/* k1015 in k1012 in k1009 in body100 in regexp* in k458 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[45],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* regexp in k458 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_929r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_929r(t0,t1,t2,t3);}}

static void C_ccall f_929r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_931,a[2]=t3,a[3]=lf[56],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_987,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_997,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 272  options->integer */
t7=t4;
f_931(t7,t6);}

/* k995 in regexp in k458 */
static void C_ccall f_997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 272  re-checked-compile */
f_914(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[45]);}

/* k985 in regexp in k458 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_990,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* set-finalizer! */
t3=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[42]);}

/* k988 in k985 in regexp in k458 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_990,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[45],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* options->integer in regexp in k458 */
static void C_fcall f_931(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_931,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_truep(t2)?C_unsigned_int_to_num(&a,PCRE_CASELESS):C_fix(0));
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_952,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_952(t6,C_fix(0));}
else{
t6=(C_word)C_i_car(t4);
t7=(C_truep(t6)?C_unsigned_int_to_num(&a,PCRE_EXTENDED):C_fix(0));
t8=(C_word)C_i_cdr(t4);
t9=(C_word)C_i_pairp(t8);
t10=(C_truep(t9)?(C_word)C_i_car(t8):C_SCHEME_FALSE);
t11=(C_truep(t10)?C_unsigned_int_to_num(&a,PCRE_UTF8):C_fix(0));
t12=t5;
f_952(t12,(C_word)C_a_i_plus(&a,2,t7,t11));}}}

/* k950 in options->integer in regexp in k458 */
static void C_fcall f_952(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_952,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* re-checked-compile in k458 */
static void C_fcall f_914(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_914,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=t2;
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_897,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t7,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}

/* k895 in re-checked-compile in k458 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_897,2,t0,t1);}
t2=(C_word)C_i_foreign_unsigned_integer_argumentp(((C_word*)t0)[6]);
t3=(C_word)stub74(((C_word*)t0)[5],t1,t2,C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* regex.scm: 256  re-error */
t4=lf[48];
f_878(t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[53],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_fix((C_word)C_regex_error_offset)));}}

/* re-error in k458 */
static void C_fcall f_878(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_878,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_886,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_890,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k888 in re-error in k458 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 243  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[49],t1);}

/* k884 in re-error in k458 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],*((C_word*)lf[6]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* regexp? in k458 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_872,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[45]));}

/* re-finalizer in k458 */
static void C_ccall f_862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_862,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub49(C_SCHEME_UNDEFINED,t3));}

/* pcre-option->number in k458 */
static void C_fcall f_490(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_490,NULL,2,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_500,a[2]=t6,a[3]=lf[40],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_500(t8,t1,t4,C_fix(0));}

/* loop in pcre-option->number in k458 */
static void C_fcall f_500(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_500,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_525,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t7)){
t8=t6;
f_525(2,t8,C_unsigned_int_to_num(&a,PCRE_CASELESS));}
else{
t8=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t8)){
t9=t6;
f_525(2,t9,C_unsigned_int_to_num(&a,PCRE_MULTILINE));}
else{
t9=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t9)){
t10=t6;
f_525(2,t10,C_unsigned_int_to_num(&a,PCRE_DOTALL));}
else{
t10=(C_word)C_eqp(t5,lf[13]);
if(C_truep(t10)){
t11=t6;
f_525(2,t11,C_unsigned_int_to_num(&a,PCRE_EXTENDED));}
else{
t11=(C_word)C_eqp(t5,lf[14]);
if(C_truep(t11)){
t12=t6;
f_525(2,t12,C_unsigned_int_to_num(&a,PCRE_ANCHORED));}
else{
t12=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t12)){
t13=t6;
f_525(2,t13,C_unsigned_int_to_num(&a,PCRE_DOLLAR_ENDONLY));}
else{
t13=(C_word)C_eqp(t5,lf[16]);
if(C_truep(t13)){
t14=t6;
f_525(2,t14,C_unsigned_int_to_num(&a,PCRE_EXTRA));}
else{
t14=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t14)){
t15=t6;
f_525(2,t15,C_unsigned_int_to_num(&a,PCRE_NOTBOL));}
else{
t15=(C_word)C_eqp(t5,lf[18]);
if(C_truep(t15)){
t16=t6;
f_525(2,t16,C_unsigned_int_to_num(&a,PCRE_NOTEOL));}
else{
t16=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t16)){
t17=t6;
f_525(2,t17,C_unsigned_int_to_num(&a,PCRE_UNGREEDY));}
else{
t17=(C_word)C_eqp(t5,lf[20]);
if(C_truep(t17)){
t18=t6;
f_525(2,t18,C_unsigned_int_to_num(&a,PCRE_NOTEMPTY));}
else{
t18=(C_word)C_eqp(t5,lf[21]);
if(C_truep(t18)){
t19=t6;
f_525(2,t19,C_unsigned_int_to_num(&a,PCRE_UTF8));}
else{
t19=(C_word)C_eqp(t5,lf[22]);
if(C_truep(t19)){
t20=t6;
f_525(2,t20,C_unsigned_int_to_num(&a,PCRE_NO_AUTO_CAPTURE));}
else{
t20=(C_word)C_eqp(t5,lf[23]);
if(C_truep(t20)){
t21=t6;
f_525(2,t21,C_unsigned_int_to_num(&a,PCRE_NO_UTF8_CHECK));}
else{
t21=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t21)){
t22=t6;
f_525(2,t22,C_unsigned_int_to_num(&a,PCRE_AUTO_CALLOUT));}
else{
t22=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t22)){
t23=t6;
f_525(2,t23,C_unsigned_int_to_num(&a,PCRE_PARTIAL));}
else{
t23=(C_word)C_eqp(t5,lf[26]);
if(C_truep(t23)){
t24=t6;
f_525(2,t24,C_unsigned_int_to_num(&a,PCRE_DFA_SHORTEST));}
else{
t24=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t24)){
t25=t6;
f_525(2,t25,C_unsigned_int_to_num(&a,PCRE_DFA_RESTART));}
else{
t25=(C_word)C_eqp(t5,lf[28]);
if(C_truep(t25)){
t26=t6;
f_525(2,t26,C_unsigned_int_to_num(&a,PCRE_FIRSTLINE));}
else{
t26=(C_word)C_eqp(t5,lf[29]);
if(C_truep(t26)){
t27=t6;
f_525(2,t27,C_unsigned_int_to_num(&a,PCRE_DUPNAMES));}
else{
t27=(C_word)C_eqp(t5,lf[30]);
if(C_truep(t27)){
t28=t6;
f_525(2,t28,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CR));}
else{
t28=(C_word)C_eqp(t5,lf[31]);
if(C_truep(t28)){
t29=t6;
f_525(2,t29,C_unsigned_int_to_num(&a,PCRE_NEWLINE_LF));}
else{
t29=(C_word)C_eqp(t5,lf[32]);
if(C_truep(t29)){
t30=t6;
f_525(2,t30,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CRLF));}
else{
t30=(C_word)C_eqp(t5,lf[33]);
if(C_truep(t30)){
t31=t6;
f_525(2,t31,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANY));}
else{
t31=(C_word)C_eqp(t5,lf[34]);
if(C_truep(t31)){
t32=t6;
f_525(2,t32,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANYCRLF));}
else{
t32=(C_word)C_eqp(t5,lf[35]);
if(C_truep(t32)){
t33=t6;
f_525(2,t33,C_unsigned_int_to_num(&a,PCRE_BSR_ANYCRLF));}
else{
t33=(C_word)C_eqp(t5,lf[36]);
if(C_truep(t33)){
t34=t6;
f_525(2,t34,C_unsigned_int_to_num(&a,PCRE_BSR_UNICODE));}
else{
/* regex.scm: 164  error */
t34=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t34+1)))(5,t34,t6,lf[38],t5,lf[39]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k523 in loop in pcre-option->number in k458 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_525,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex.scm: 164  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_500(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#check-chardef-table in k458 */
static void C_ccall f_478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_478,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_485,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 146  ##sys#regex-chardef-table? */
t5=*((C_word*)lf[2]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k483 in ##sys#check-chardef-table in k458 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* regex.scm: 147  ##sys#error */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[7],((C_word*)t0)[2]);}}

/* ##sys#regex-chardef-table? in k458 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_462,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[3],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[122] = {
{"toplevelregex.scm",(void*)C_regex_toplevel},
{"f_460regex.scm",(void*)f_460},
{"f_2398regex.scm",(void*)f_2398},
{"f_2450regex.scm",(void*)f_2450},
{"f_2445regex.scm",(void*)f_2445},
{"f_2400regex.scm",(void*)f_2400},
{"f_2424regex.scm",(void*)f_2424},
{"f_2438regex.scm",(void*)f_2438},
{"f_2427regex.scm",(void*)f_2427},
{"f_2342regex.scm",(void*)f_2342},
{"f_2349regex.scm",(void*)f_2349},
{"f_2357regex.scm",(void*)f_2357},
{"f_2389regex.scm",(void*)f_2389},
{"f_2376regex.scm",(void*)f_2376},
{"f_2379regex.scm",(void*)f_2379},
{"f_2302regex.scm",(void*)f_2302},
{"f_2311regex.scm",(void*)f_2311},
{"f_2330regex.scm",(void*)f_2330},
{"f_2337regex.scm",(void*)f_2337},
{"f_2034regex.scm",(void*)f_2034},
{"f_2049regex.scm",(void*)f_2049},
{"f_2051regex.scm",(void*)f_2051},
{"f_2297regex.scm",(void*)f_2297},
{"f_2286regex.scm",(void*)f_2286},
{"f_2109regex.scm",(void*)f_2109},
{"f_2191regex.scm",(void*)f_2191},
{"f_2215regex.scm",(void*)f_2215},
{"f_2170regex.scm",(void*)f_2170},
{"f_2141regex.scm",(void*)f_2141},
{"f_2111regex.scm",(void*)f_2111},
{"f_2119regex.scm",(void*)f_2119},
{"f_2107regex.scm",(void*)f_2107},
{"f_2094regex.scm",(void*)f_2094},
{"f_2081regex.scm",(void*)f_2081},
{"f_2045regex.scm",(void*)f_2045},
{"f_1949regex.scm",(void*)f_1949},
{"f_1962regex.scm",(void*)f_1962},
{"f_1981regex.scm",(void*)f_1981},
{"f_1897regex.scm",(void*)f_1897},
{"f_1912regex.scm",(void*)f_1912},
{"f_1929regex.scm",(void*)f_1929},
{"f_1654regex.scm",(void*)f_1654},
{"f_1790regex.scm",(void*)f_1790},
{"f_1794regex.scm",(void*)f_1794},
{"f_1885regex.scm",(void*)f_1885},
{"f_1881regex.scm",(void*)f_1881},
{"f_1852regex.scm",(void*)f_1852},
{"f_1834regex.scm",(void*)f_1834},
{"f_1827regex.scm",(void*)f_1827},
{"f_1684regex.scm",(void*)f_1684},
{"f_1690regex.scm",(void*)f_1690},
{"f_1757regex.scm",(void*)f_1757},
{"f_1745regex.scm",(void*)f_1745},
{"f_1704regex.scm",(void*)f_1704},
{"f_1669regex.scm",(void*)f_1669},
{"f_1472regex.scm",(void*)f_1472},
{"f_1636regex.scm",(void*)f_1636},
{"f_1610regex.scm",(void*)f_1610},
{"f_1635regex.scm",(void*)f_1635},
{"f_1590regex.scm",(void*)f_1590},
{"f_1491regex.scm",(void*)f_1491},
{"f_1499regex.scm",(void*)f_1499},
{"f_1503regex.scm",(void*)f_1503},
{"f_1564regex.scm",(void*)f_1564},
{"f_1545regex.scm",(void*)f_1545},
{"f_1579regex.scm",(void*)f_1579},
{"f_1574regex.scm",(void*)f_1574},
{"f_1462regex.scm",(void*)f_1462},
{"f_1470regex.scm",(void*)f_1470},
{"f_1452regex.scm",(void*)f_1452},
{"f_1460regex.scm",(void*)f_1460},
{"f_1406regex.scm",(void*)f_1406},
{"f_1419regex.scm",(void*)f_1419},
{"f_1388regex.scm",(void*)f_1388},
{"f_1396regex.scm",(void*)f_1396},
{"f_1378regex.scm",(void*)f_1378},
{"f_1386regex.scm",(void*)f_1386},
{"f_1335regex.scm",(void*)f_1335},
{"f_1352regex.scm",(void*)f_1352},
{"f_1277regex.scm",(void*)f_1277},
{"f_1281regex.scm",(void*)f_1281},
{"f_1242regex.scm",(void*)f_1242},
{"f_1290regex.scm",(void*)f_1290},
{"f_1208regex.scm",(void*)f_1208},
{"f_1212regex.scm",(void*)f_1212},
{"f_1220regex.scm",(void*)f_1220},
{"f_1136regex.scm",(void*)f_1136},
{"f_1154regex.scm",(void*)f_1154},
{"f_1188regex.scm",(void*)f_1188},
{"f_1192regex.scm",(void*)f_1192},
{"f_1174regex.scm",(void*)f_1174},
{"f_1088regex.scm",(void*)f_1088},
{"f_1101regex.scm",(void*)f_1101},
{"f_1110regex.scm",(void*)f_1110},
{"f_999regex.scm",(void*)f_999},
{"f_1033regex.scm",(void*)f_1033},
{"f_1028regex.scm",(void*)f_1028},
{"f_1001regex.scm",(void*)f_1001},
{"f_1011regex.scm",(void*)f_1011},
{"f_1024regex.scm",(void*)f_1024},
{"f_1014regex.scm",(void*)f_1014},
{"f_1017regex.scm",(void*)f_1017},
{"f_929regex.scm",(void*)f_929},
{"f_997regex.scm",(void*)f_997},
{"f_987regex.scm",(void*)f_987},
{"f_990regex.scm",(void*)f_990},
{"f_931regex.scm",(void*)f_931},
{"f_952regex.scm",(void*)f_952},
{"f_914regex.scm",(void*)f_914},
{"f_897regex.scm",(void*)f_897},
{"f_878regex.scm",(void*)f_878},
{"f_890regex.scm",(void*)f_890},
{"f_886regex.scm",(void*)f_886},
{"f_872regex.scm",(void*)f_872},
{"f_862regex.scm",(void*)f_862},
{"f_490regex.scm",(void*)f_490},
{"f_500regex.scm",(void*)f_500},
{"f_525regex.scm",(void*)f_525},
{"f_478regex.scm",(void*)f_478},
{"f_485regex.scm",(void*)f_485},
{"f_462regex.scm",(void*)f_462},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
