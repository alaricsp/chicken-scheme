/* Generated from regex.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-07 10:48
   Version 3.3.4 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   compiled 2008-07-29 on pequod (Linux)
   command line: regex.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path . -explicit-use -include-path ./pcre -output-file regex.c
   unit: regex
*/

#include "chicken.h"

#include "pcre.h"

static const char *C_regex_error;
static int C_regex_error_offset;


#define OVECTOR_LENGTH_MULTIPLE 3
#define STATIC_OVECTOR_LEN 256
static int C_regex_ovector[OVECTOR_LENGTH_MULTIPLE * STATIC_OVECTOR_LEN];


static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[101];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,99,104,101,99,107,45,99,104,97,114,100,101,102,45,116,97,98,108,101,32,120,48,32,108,111,99,49,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,115,121,109,115,51,56,32,115,117,109,51,57,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,112,99,114,101,45,111,112,116,105,111,110,45,62,110,117,109,98,101,114,32,115,121,109,115,51,54,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,20),40,114,101,45,102,105,110,97,108,105,122,101,114,32,97,53,48,53,52,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,26),40,114,101,103,101,120,45,99,104,97,114,100,101,102,45,116,97,98,108,101,63,32,120,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,37),40,114,101,45,109,97,107,101,45,99,104,97,114,100,101,102,45,116,97,98,108,101,45,116,121,112,101,32,116,97,98,108,101,115,55,53,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,114,101,103,101,120,45,99,104,97,114,100,101,102,45,116,97,98,108,101,32,46,32,103,56,48,56,49,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,13),40,114,101,103,101,120,112,63,32,120,56,57,41,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,29),40,114,101,45,101,114,114,111,114,32,108,111,99,57,50,32,109,115,103,57,51,32,97,114,103,115,57,52,41,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,49),40,114,101,45,99,104,101,99,107,101,100,45,99,111,109,112,105,108,101,32,112,97,116,116,101,114,110,49,48,54,32,111,112,116,105,111,110,115,49,48,55,32,108,111,99,49,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,18),40,111,112,116,105,111,110,115,45,62,105,110,116,101,103,101,114,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,114,101,103,101,120,112,32,112,97,116,116,101,114,110,49,49,51,32,46,32,111,112,116,105,111,110,115,49,49,52,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,49,50,52,32,111,112,116,105,111,110,115,49,51,48,32,116,97,98,108,101,115,49,51,49,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,30),40,100,101,102,45,116,97,98,108,101,115,49,50,55,32,37,111,112,116,105,111,110,115,49,50,50,49,51,56,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,111,112,116,105,111,110,115,49,50,54,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,30),40,114,101,103,101,120,112,42,32,112,97,116,116,101,114,110,49,50,48,32,46,32,97,114,103,115,49,50,49,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,23),40,114,101,103,101,120,112,45,111,112,116,105,109,105,122,101,32,114,120,49,52,57,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,49,54,57,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,35),40,103,97,116,104,101,114,45,114,101,115,117,108,116,45,112,111,115,105,116,105,111,110,115,32,114,101,115,117,108,116,49,54,53,41,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,15),40,97,49,51,48,53,32,112,111,115,115,49,55,54,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,33),40,103,97,116,104,101,114,45,114,101,115,117,108,116,115,32,115,116,114,49,55,51,32,114,101,115,117,108,116,49,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,49),40,112,101,114,102,111,114,109,45,109,97,116,99,104,32,114,103,120,112,50,48,49,32,115,116,114,50,48,50,32,115,105,50,48,51,32,114,105,50,48,52,32,108,111,99,50,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,46),40,112,114,101,112,97,114,101,45,109,97,116,99,104,32,114,103,120,112,50,49,57,32,115,116,114,50,50,48,32,115,116,97,114,116,50,50,49,32,108,111,99,50,50,50,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,40),40,115,116,114,105,110,103,45,109,97,116,99,104,32,114,103,120,112,50,50,54,32,115,116,114,50,50,55,32,46,32,115,116,97,114,116,50,50,56,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,50),40,115,116,114,105,110,103,45,109,97,116,99,104,45,112,111,115,105,116,105,111,110,115,32,114,103,120,112,50,50,57,32,115,116,114,50,51,48,32,46,32,115,116,97,114,116,50,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,57),40,112,114,101,112,97,114,101,45,115,101,97,114,99,104,32,114,103,120,112,50,51,53,32,115,116,114,50,51,54,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,50,51,55,32,108,111,99,50,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,51),40,115,116,114,105,110,103,45,115,101,97,114,99,104,32,114,103,120,112,50,52,53,32,115,116,114,50,52,54,32,46,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,50,52,55,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,61),40,115,116,114,105,110,103,45,115,101,97,114,99,104,45,112,111,115,105,116,105,111,110,115,32,114,103,120,112,50,52,56,32,115,116,114,50,52,57,32,46,32,115,116,97,114,116,45,97,110,100,45,114,97,110,103,101,50,53,48,41,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,31),40,102,95,49,54,53,54,32,115,116,97,114,116,50,55,55,32,102,114,111,109,50,55,56,32,116,111,50,55,57,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,31),40,102,95,49,54,54,49,32,115,116,97,114,116,50,56,48,32,102,114,111,109,50,56,49,32,116,111,50,56,50,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,109,115,50,56,52,32,115,116,97,114,116,50,56,53,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,23),40,102,95,49,54,55,50,32,109,115,50,54,54,32,115,116,97,114,116,50,54,55,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,23),40,102,95,49,54,57,50,32,109,115,50,54,56,32,115,116,97,114,116,50,54,57,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,102,95,49,55,49,56,32,109,115,50,55,48,32,115,116,97,114,116,50,55,49,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,56),40,115,116,114,105,110,103,45,115,112,108,105,116,45,102,105,101,108,100,115,32,114,103,120,112,50,53,54,32,115,116,114,50,53,55,32,46,32,109,111,100,101,45,97,110,100,45,115,116,97,114,116,50,53,56,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,6),40,112,117,115,104,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,116,97,114,116,51,49,49,32,105,110,100,101,120,51,49,50,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,23),40,115,117,98,115,116,105,116,117,116,101,32,109,97,116,99,104,101,115,51,48,57,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,105,110,100,101,120,51,50,49,32,99,111,117,110,116,51,50,50,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,57),40,115,116,114,105,110,103,45,115,117,98,115,116,105,116,117,116,101,32,114,101,103,101,120,50,57,54,32,115,117,98,115,116,50,57,55,32,115,116,114,105,110,103,50,57,56,32,46,32,102,108,97,103,50,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,115,116,114,51,52,50,32,115,109,97,112,51,52,51,41,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,45),40,115,116,114,105,110,103,45,115,117,98,115,116,105,116,117,116,101,42,32,115,116,114,51,51,55,32,115,109,97,112,51,51,56,32,46,32,109,111,100,101,51,51,57,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,105,100,120,51,53,48,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,14),40,103,108,111,98,63,32,115,116,114,51,52,56,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,19),40,103,51,55,54,32,99,51,56,48,32,109,111,114,101,51,56,49,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,50,32,114,101,115,116,51,55,49,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,99,115,51,54,55,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,45,62,114,101,103,101,120,112,32,115,51,54,53,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,51,57,55,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,21),40,103,114,101,112,32,114,103,120,112,51,57,52,32,108,115,116,51,57,53,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,52,48,56,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,22),40,114,101,103,101,120,112,45,101,115,99,97,112,101,32,115,116,114,52,48,52,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,23),40,98,111,100,121,52,49,57,32,110,111,115,52,50,53,32,110,111,101,52,50,54,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,110,111,101,52,50,50,32,37,110,111,115,52,49,55,52,51,54,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,110,111,115,52,50,49,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,97,110,99,104,111,114,101,100,45,112,97,116,116,101,114,110,32,114,103,120,112,52,49,53,32,46,32,97,114,103,115,52,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k1352 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub195(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub195(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
int cc;pcre_fullinfo(code, extra, PCRE_INFO_CAPTURECOUNT, &cc);return(cc + 1);
C_ret:
#undef return

return C_r;}

/* from k1338 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub183(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub183(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *extra=(const pcre_extra *)C_c_pointer_or_null(C_a1);
void * str=(void * )C_data_pointer(C_a2);
int start=(int )C_unfix(C_a3);
int range=(int )C_unfix(C_a4);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a5);
return(pcre_exec(code, extra, str, start + range, start, options, C_regex_ovector, STATIC_OVECTOR_LEN * OVECTOR_LENGTH_MULTIPLE));
C_ret:
#undef return

return C_r;}

/* from k1218 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub162(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub162(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[(i * 2) + 1]);
C_ret:
#undef return

return C_r;}

/* from k1211 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[i * 2]);
C_ret:
#undef return

return C_r;}

/* from k1170 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub145(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub145(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
return(pcre_study(code, 0, &C_regex_error));
C_ret:
#undef return

return C_r;}

/* from k989 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * patt=(char * )C_c_string(C_a0);
unsigned int options=(unsigned int )C_num_to_unsigned_int(C_a1);
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a2);
return(pcre_compile(patt, options, &C_regex_error, &C_regex_error_offset, tables));
C_ret:
#undef return

return C_r;}

/* from re-maketables */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub72(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub72(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
return (pcre_maketables ());
C_ret:
#undef return

return C_r;}

/* from k873 */
static C_word C_fcall stub51(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub51(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

C_noret_decl(C_regex_toplevel)
C_externexport void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_496)
static void C_ccall f_496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2532)
static void C_fcall f_2532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_fcall f_2527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2482)
static void C_fcall f_2482(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_fcall f_2439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2393)
static void C_fcall f_2393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_fcall f_2133(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2273)
static void C_fcall f_2273(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_fcall f_2193(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2044)
static void C_fcall f_2044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2063)
static void C_fcall f_2063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1994)
static void C_fcall f_1994(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1872)
static void C_fcall f_1872(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_fcall f_1766(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1772)
static void C_fcall f_1772(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static C_word C_fcall f_1751(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1573)
static void C_fcall f_1573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1581)
static void C_fcall f_1581(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_fcall f_1488(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1501)
static void C_fcall f_1501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_fcall f_1417(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1359)
static void C_fcall f_1359(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_fcall f_1294(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1222)
static void C_fcall f_1222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1240)
static void C_fcall f_1240(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1274)
static void C_fcall f_1274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1085)
static void C_ccall f_1085r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1119)
static void C_fcall f_1119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_fcall f_1114(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1087)
static void C_fcall f_1087(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_fcall f_1017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_fcall f_1038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_fcall f_1000(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_fcall f_964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_976)
static void C_ccall f_976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_903)
static void C_ccall f_903r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_907)
static void C_ccall f_907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_898)
static void C_fcall f_898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_880)
static void C_ccall f_880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_498)
static void C_fcall f_498(C_word t0,C_word t1) C_noret;
C_noret_decl(f_508)
static void C_fcall f_508(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_533)
static void C_ccall f_533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_483)
static void C_ccall f_483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_490)
static void C_ccall f_490(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2532)
static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2532(t0,t1);}

C_noret_decl(trf_2527)
static void C_fcall trf_2527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2527(t0,t1,t2);}

C_noret_decl(trf_2482)
static void C_fcall trf_2482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2482(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2482(t0,t1,t2,t3);}

C_noret_decl(trf_2439)
static void C_fcall trf_2439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2439(t0,t1,t2);}

C_noret_decl(trf_2393)
static void C_fcall trf_2393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2393(t0,t1,t2);}

C_noret_decl(trf_2133)
static void C_fcall trf_2133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2133(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2133(t0,t1,t2);}

C_noret_decl(trf_2191)
static void C_fcall trf_2191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2191(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2191(t0,t1,t2);}

C_noret_decl(trf_2273)
static void C_fcall trf_2273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2273(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2273(t0,t1);}

C_noret_decl(trf_2193)
static void C_fcall trf_2193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2193(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2193(t0,t1,t2,t3);}

C_noret_decl(trf_2044)
static void C_fcall trf_2044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2044(t0,t1,t2);}

C_noret_decl(trf_2063)
static void C_fcall trf_2063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2063(t0,t1);}

C_noret_decl(trf_1994)
static void C_fcall trf_1994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1994(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1994(t0,t1,t2,t3);}

C_noret_decl(trf_1872)
static void C_fcall trf_1872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1872(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1872(t0,t1,t2,t3);}

C_noret_decl(trf_1766)
static void C_fcall trf_1766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1766(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1766(t0,t1,t2);}

C_noret_decl(trf_1772)
static void C_fcall trf_1772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1772(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1772(t0,t1,t2,t3);}

C_noret_decl(trf_1573)
static void C_fcall trf_1573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1573(t0,t1);}

C_noret_decl(trf_1581)
static void C_fcall trf_1581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1581(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1581(t0,t1,t2,t3);}

C_noret_decl(trf_1488)
static void C_fcall trf_1488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1488(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1488(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1501)
static void C_fcall trf_1501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1501(t0,t1);}

C_noret_decl(trf_1417)
static void C_fcall trf_1417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1417(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1417(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1359)
static void C_fcall trf_1359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1359(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1359(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1294)
static void C_fcall trf_1294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1294(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1294(t0,t1,t2,t3);}

C_noret_decl(trf_1222)
static void C_fcall trf_1222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1222(t0,t1);}

C_noret_decl(trf_1240)
static void C_fcall trf_1240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1240(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1240(t0,t1,t2);}

C_noret_decl(trf_1274)
static void C_fcall trf_1274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1274(t0,t1);}

C_noret_decl(trf_1119)
static void C_fcall trf_1119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1119(t0,t1);}

C_noret_decl(trf_1114)
static void C_fcall trf_1114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1114(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1114(t0,t1,t2);}

C_noret_decl(trf_1087)
static void C_fcall trf_1087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1087(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1087(t0,t1,t2,t3);}

C_noret_decl(trf_1017)
static void C_fcall trf_1017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1017(t0,t1);}

C_noret_decl(trf_1038)
static void C_fcall trf_1038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1038(t0,t1);}

C_noret_decl(trf_1000)
static void C_fcall trf_1000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1000(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1000(t0,t1,t2,t3);}

C_noret_decl(trf_964)
static void C_fcall trf_964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_964(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_964(t0,t1,t2,t3,t4);}

C_noret_decl(trf_898)
static void C_fcall trf_898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_898(t0,t1);}

C_noret_decl(trf_498)
static void C_fcall trf_498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_498(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_498(t0,t1);}

C_noret_decl(trf_508)
static void C_fcall trf_508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_508(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_508(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(6);
if(!C_demand(6)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(760)){
C_save(t1);
C_rereclaim2(760*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(6);
C_initialize_lf(lf,101);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],23,"\003syscheck-chardef-table");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000-invalid character definition tables structure");
lf[5]=C_h_intern(&lf[5],20,"regex-chardef-table\077");
lf[7]=C_h_intern(&lf[7],8,"caseless");
lf[8]=C_h_intern(&lf[8],9,"multiline");
lf[9]=C_h_intern(&lf[9],6,"dotall");
lf[10]=C_h_intern(&lf[10],8,"extended");
lf[11]=C_h_intern(&lf[11],8,"anchored");
lf[12]=C_h_intern(&lf[12],14,"dollar-endonly");
lf[13]=C_h_intern(&lf[13],5,"extra");
lf[14]=C_h_intern(&lf[14],6,"notbol");
lf[15]=C_h_intern(&lf[15],6,"noteol");
lf[16]=C_h_intern(&lf[16],8,"ungreedy");
lf[17]=C_h_intern(&lf[17],8,"notempty");
lf[18]=C_h_intern(&lf[18],4,"utf8");
lf[19]=C_h_intern(&lf[19],15,"no-auto-capture");
lf[20]=C_h_intern(&lf[20],13,"no-utf8-check");
lf[21]=C_h_intern(&lf[21],12,"auto-callout");
lf[22]=C_h_intern(&lf[22],7,"partial");
lf[23]=C_h_intern(&lf[23],12,"dfa-shortest");
lf[24]=C_h_intern(&lf[24],11,"dfa-restart");
lf[25]=C_h_intern(&lf[25],9,"firstline");
lf[26]=C_h_intern(&lf[26],8,"dupnames");
lf[27]=C_h_intern(&lf[27],10,"newline-cr");
lf[28]=C_h_intern(&lf[28],10,"newline-lf");
lf[29]=C_h_intern(&lf[29],12,"newline-crlf");
lf[30]=C_h_intern(&lf[30],11,"newline-any");
lf[31]=C_h_intern(&lf[31],15,"newline-anycrlf");
lf[32]=C_h_intern(&lf[32],11,"bsr-anycrlf");
lf[33]=C_h_intern(&lf[33],11,"bsr-unicode");
lf[34]=C_h_intern(&lf[34],5,"error");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[36]=C_h_intern(&lf[36],11,"pcre-option");
lf[38]=C_h_intern(&lf[38],13,"chardef-table");
lf[39]=C_h_intern(&lf[39],23,"\003sysmake-tagged-pointer");
lf[40]=C_h_intern(&lf[40],19,"regex-chardef-table");
lf[41]=C_h_intern(&lf[41],15,"\003syssignal-hook");
lf[42]=C_h_intern(&lf[42],11,"\000type-error");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[44]=C_h_intern(&lf[44],14,"set-finalizer!");
lf[45]=C_h_intern(&lf[45],14,"\003syserror-hook");
lf[46]=C_h_intern(&lf[46],7,"regexp\077");
lf[47]=C_h_intern(&lf[47],6,"regexp");
lf[48]=C_h_intern(&lf[48],13,"string-append");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[51]=C_h_intern(&lf[51],17,"\003syspeek-c-string");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000!cannot compile regular expression");
lf[54]=C_h_intern(&lf[54],17,"\003sysmake-c-string");
lf[55]=C_h_intern(&lf[55],7,"regexp*");
lf[56]=C_h_intern(&lf[56],15,"regexp-optimize");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot optimize regular expression");
lf[59]=C_h_intern(&lf[59],9,"substring");
lf[61]=C_h_intern(&lf[61],7,"\003sysmap");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\077bad argument type - not a string or compiled regular expression");
lf[64]=C_h_intern(&lf[64],19,"\003sysundefined-value");
lf[65]=C_h_intern(&lf[65],12,"string-match");
lf[66]=C_h_intern(&lf[66],22,"string-match-positions");
lf[67]=C_h_intern(&lf[67],21,"make-anchored-pattern");
lf[68]=C_h_intern(&lf[68],13,"string-search");
lf[69]=C_h_intern(&lf[69],23,"string-search-positions");
lf[70]=C_h_intern(&lf[70],7,"reverse");
lf[71]=C_h_intern(&lf[71],19,"string-split-fields");
lf[72]=C_h_intern(&lf[72],6,"\000infix");
lf[73]=C_h_intern(&lf[73],7,"\000suffix");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\037record does not end with suffix");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[76]=C_h_intern(&lf[76],11,"make-string");
lf[77]=C_h_intern(&lf[77],17,"string-substitute");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\030empty substitution match");
lf[79]=C_h_intern(&lf[79],21,"\003sysfragments->string");
lf[80]=C_h_intern(&lf[80],18,"string-substitute*");
lf[81]=C_h_intern(&lf[81],5,"glob\077");
lf[82]=C_h_intern(&lf[82],12,"list->string");
lf[83]=C_h_intern(&lf[83],12,"string->list");
lf[84]=C_h_intern(&lf[84],12,"glob->regexp");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000!unexpected end of character class");
lf[86]=C_h_intern(&lf[86],15,"\003sysmatch-error");
lf[87]=C_h_intern(&lf[87],4,"grep");
lf[88]=C_h_intern(&lf[88],18,"open-output-string");
lf[89]=C_h_intern(&lf[89],17,"get-output-string");
lf[90]=C_h_intern(&lf[90],13,"regexp-escape");
lf[91]=C_h_intern(&lf[91],16,"\003syswrite-char-0");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001^");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001$");
lf[96]=C_h_intern(&lf[96],7,"warning");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000<cannot select partial anchor for compiled regular expression");
lf[98]=C_h_intern(&lf[98],17,"register-feature!");
lf[99]=C_h_intern(&lf[99],5,"regex");
lf[100]=C_h_intern(&lf[100],4,"pcre");
C_register_lf2(lf,101,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_483,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_496,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 109  register-feature! */
t5=*((C_word*)lf[98]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[99],lf[100]);}

/* k494 */
static void C_ccall f_496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[104],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_496,2,t0,t1);}
t2=C_mutate(&lf[6],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_498,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[37],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_870,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[5]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_880,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_898,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_903,a[2]=t5,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_958,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[48]+1);
t9=C_mutate(&lf[49],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_964,a[2]=t8,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate(&lf[52],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1015,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1085,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1222,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[59]+1);
t16=C_mutate(&lf[60],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=t15,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate(&lf[62],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1359,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t18=*((C_word*)lf[64]+1);
t19=C_mutate((C_word*)lf[65]+1,t18);
t20=*((C_word*)lf[64]+1);
t21=C_mutate((C_word*)lf[66]+1,t20);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1417,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
t23=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1460,a[2]=t22,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1470,a[2]=t22,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp));
t25=*((C_word*)lf[64]+1);
t26=C_mutate((C_word*)lf[68]+1,t25);
t27=*((C_word*)lf[64]+1);
t28=C_mutate((C_word*)lf[69]+1,t27);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1488,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
t30=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1534,a[2]=t29,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp));
t31=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1544,a[2]=t29,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp));
t32=*((C_word*)lf[70]+1);
t33=*((C_word*)lf[59]+1);
t34=*((C_word*)lf[69]+1);
t35=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1554,a[2]=t32,a[3]=t34,a[4]=t33,a[5]=((C_word)li34),tmp=(C_word)a,a+=6,tmp));
t36=*((C_word*)lf[59]+1);
t37=*((C_word*)lf[70]+1);
t38=*((C_word*)lf[76]+1);
t39=*((C_word*)lf[69]+1);
t40=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1736,a[2]=t39,a[3]=t37,a[4]=t36,a[5]=((C_word)li39),tmp=(C_word)a,a+=6,tmp));
t41=*((C_word*)lf[77]+1);
t42=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1979,a[2]=t41,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp));
t43=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2031,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t44=*((C_word*)lf[82]+1);
t45=*((C_word*)lf[83]+1);
t46=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2116,a[2]=t45,a[3]=t44,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp));
t47=*((C_word*)lf[68]+1);
t48=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2384,a[2]=t47,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp));
t49=*((C_word*)lf[88]+1);
t50=*((C_word*)lf[89]+1);
t51=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2424,a[2]=t49,a[3]=t50,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t52=*((C_word*)lf[48]+1);
t53=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2480,a[2]=t52,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp));
t54=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t54+1)))(2,t54,C_SCHEME_UNDEFINED);}

/* make-anchored-pattern in k494 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2480r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2480r(t0,t1,t2,t3);}}

static void C_ccall f_2480r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2527,a[2]=t4,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2532,a[2]=t5,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-nos421437 */
t7=t6;
f_2532(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-noe422435 */
t9=t5;
f_2527(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body419424 */
t11=t4;
f_2482(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-nos421 in make-anchored-pattern in k494 */
static void C_fcall f_2532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2532,NULL,2,t0,t1);}
/* def-noe422435 */
t2=((C_word*)t0)[2];
f_2527(t2,t1,C_SCHEME_FALSE);}

/* def-noe422 in make-anchored-pattern in k494 */
static void C_fcall f_2527(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2527,NULL,3,t0,t1,t2);}
/* body419424 */
t3=((C_word*)t0)[2];
f_2482(t3,t1,t2,C_SCHEME_FALSE);}

/* body419 in make-anchored-pattern in k494 */
static void C_fcall f_2482(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2482,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t4=(C_truep(t2)?lf[92]:lf[93]);
t5=(C_truep(t3)?lf[94]:lf[95]);
/* regex.scm: 647  string-append */
t6=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t4,((C_word*)t0)[3],t5);}
else{
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[3],lf[47],lf[67]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2506,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=(C_truep(t6)?t6:t3);
if(C_truep(t7)){
/* regex.scm: 651  warning */
t8=*((C_word*)lf[96]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,lf[67],lf[97]);}
else{
t8=t5;
f_2506(2,t8,C_SCHEME_UNDEFINED);}}}

/* k2504 in body419 in make-anchored-pattern in k494 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=*((C_word*)lf[47]+1);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 655  pcre-option->number */
f_498(t5,lf[11]);}

/* k2518 in k2504 in body419 in make-anchored-pattern in k494 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}

/* regexp-escape in k494 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2424,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2431,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 626  open-output-string */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2429 in regexp-escape in k494 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2431,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2439,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word)li50),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2439(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k2429 in regexp-escape in k494 */
static void C_fcall f_2439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2439,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* regex.scm: 629  get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(46)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 632  ##sys#write-char-0 */
t5=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2471,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 636  ##sys#write-char-0 */
t5=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k2469 in loop in k2429 in regexp-escape in k494 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 637  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2439(t3,((C_word*)t0)[2],t2);}

/* k2456 in loop in k2429 in regexp-escape in k494 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 633  ##sys#write-char-0 */
t3=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k2459 in k2456 in loop in k2429 in regexp-escape in k494 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 634  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2439(t3,((C_word*)t0)[2],t2);}

/* grep in k494 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2384,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[87]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2393,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2393(t8,t1,t3);}

/* loop in grep in k494 */
static void C_fcall f_2393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2393,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2412,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 614  string-search */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k2410 in loop in grep in k494 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 615  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2393(t3,t2,((C_word*)t0)[2]);}
else{
/* regex.scm: 616  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2393(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2417 in k2410 in loop in grep in k494 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k494 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2116,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2131,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 581  string->list */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k2129 in glob->regexp in k494 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2131,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2133(t5,((C_word*)t0)[2],t1);}

/* loop in k2129 in glob->regexp in k494 */
static void C_fcall f_2133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(25);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2133,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2163,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 586  loop */
t16=t5;
t17=t4;
t1=t16;
t2=t17;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2176,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 587  loop */
t16=t5;
t17=t4;
t1=t16;
t2=t17;
goto loop;
case C_make_character(91):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2189,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2191(t9,t5,t4);
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 599  loop */
t16=t7;
t17=t4;
t1=t16;
t2=t17;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 600  loop */
t16=t7;
t17=t4;
t1=t16;
t2=t17;
goto loop;}}}}

/* k2377 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(92),t2));}

/* k2366 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop2 in loop in k2129 in glob->regexp in k494 */
static void C_fcall f_2191(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2191,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[4],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(t4,C_make_character(93));
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 593  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2133(t8,t7,t6);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,C_make_character(45));
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cadr(t2);
t10=(C_word)C_i_cddr(t2);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2252,a[2]=t1,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* loop2370 */
t22=t11;
t23=t10;
t1=t22;
t2=t23;
goto loop;}
else{
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_cdr(t2);
/* g376379 */
t11=t3;
f_2193(t11,t1,t9,t10);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2273,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t9))){
t10=(C_word)C_i_cadr(t2);
t11=(C_word)C_eqp(t10,C_make_character(45));
if(C_truep(t11)){
t12=(C_word)C_i_cddr(t2);
t13=t8;
f_2273(t13,(C_word)C_i_pairp(t12));}
else{
t12=t8;
f_2273(t12,C_SCHEME_FALSE);}}
else{
t10=t8;
f_2273(t10,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t2))){
/* error */
t4=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[84],lf[85],((C_word*)t0)[2]);}
else{
/* ##sys#match-error */
t4=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}}

/* k2271 in loop2 in loop in k2129 in glob->regexp in k494 */
static void C_fcall f_2273(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2273,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2297,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* loop2370 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2191(t6,t5,t4);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* g376379 */
t4=((C_word*)t0)[2];
f_2193(t4,((C_word*)t0)[4],t2,t3);}}

/* k2295 in k2271 in loop2 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2297,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,C_make_character(45),t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2250 in loop2 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(45),t2));}

/* k2221 in loop2 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2223,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(93),t1));}

/* g376 in loop2 in loop in k2129 in glob->regexp in k494 */
static void C_fcall f_2193(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2193,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2201,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 596  loop2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2191(t5,t4,t3);}

/* k2199 in g376 in loop2 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2201,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2187 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(91),t1));}

/* k2174 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k2161 in loop in k2129 in glob->regexp in k494 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(42),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,C_make_character(46),t2));}

/* k2125 in glob->regexp in k494 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 580  list->string */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* glob? in k494 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2031,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[81]);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2044,a[2]=t7,a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2044(t9,t1,t5);}

/* loop in glob? in k494 */
static void C_fcall f_2044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2044,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(C_fix(0),t2))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(42));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_2063(t6,t4);}
else{
t6=(C_word)C_eqp(t3,C_make_character(93));
t7=t5;
f_2063(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,C_make_character(63))));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2061 in loop in glob? in k494 */
static void C_fcall f_2063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(C_fix(0),((C_word*)t0)[5]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t3);
t5=(C_word)C_eqp(C_make_character(92),t4);
t6=(C_word)C_i_not(t5);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 571  loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_2044(t8,((C_word*)t0)[4],t7);}}}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 573  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2044(t3,((C_word*)t0)[4],t2);}}

/* string-substitute* in k494 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1979r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1979r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1979r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t5=(C_word)C_i_check_string_2(t2,lf[80]);
t6=(C_word)C_i_check_list_2(t3,lf[80]);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1994,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=((C_word)li40),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_1994(t12,t1,t2,t3);}

/* loop in string-substitute* in k494 */
static void C_fcall f_1994(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1994,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2011,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_car(t4);
t7=(C_word)C_i_cdr(t4);
/* regex.scm: 556  string-substitute */
t8=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t8))(6,t8,t5,t6,t7,t2,((C_word*)t0)[2]);}}

/* k2009 in loop in string-substitute* in k494 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* regex.scm: 556  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1994(t3,((C_word*)t0)[2],t1,t2);}

/* string-substitute in k494 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+34)){
C_save_and_reclaim((void*)tr5rv,(void*)f_1736r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_1736r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1736r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(34);
t6=(C_word)C_i_check_string_2(t3,lf[77]);
t7=(C_word)C_notvemptyp(t5);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t5,C_fix(0)):C_fix(1));
t9=(C_word)C_block_size(t3);
t10=(C_word)C_fixnum_difference(t9,C_fix(1));
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_fix(0);
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1751,a[2]=t14,a[3]=t12,a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1766,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t15,a[7]=t10,a[8]=((C_word)li37),tmp=(C_word)a,a+=9,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=t12,a[4]=((C_word*)t0)[3],a[5]=t14,a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=t16,a[9]=t18,a[10]=t15,a[11]=t8,a[12]=t2,a[13]=((C_word)li38),tmp=(C_word)a,a+=14,tmp));
t20=((C_word*)t18)[1];
f_1872(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k494 */
static void C_fcall f_1872(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1872,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t3,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t1,tmp=(C_word)a,a+=15,tmp);
/* regex.scm: 527  string-search-positions */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[12],((C_word*)t0)[6],t2);}

/* k1874 in loop in string-substitute in k494 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_car(t2);
t6=(C_word)C_fixnum_difference(t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* regex.scm: 532  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[14],lf[77],lf[78],((C_word*)t0)[13]);}
else{
t8=(C_word)C_fixnump(((C_word*)t0)[12]);
t9=(C_word)C_i_not(t8);
t10=(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[12]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1916,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t12=(C_word)C_i_car(t2);
/* regex.scm: 536  substring */
t13=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t13))(5,t13,t11,((C_word*)t0)[6],((C_word*)t0)[5],t12);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1934,a[2]=t3,a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* regex.scm: 540  substring */
t12=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t12))(5,t12,t11,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* regex.scm: 543  substring */
t4=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k1965 in k1874 in loop in string-substitute in k494 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=f_1751(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 544  reverse */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1961 in k1965 in k1874 in loop in string-substitute in k494 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 544  ##sys#fragments->string */
t2=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1932 in k1874 in loop in string-substitute in k494 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=f_1751(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* regex.scm: 541  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1872(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1914 in k1874 in loop in string-substitute in k494 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1916,2,t0,t1);}
t2=f_1751(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 537  substitute */
t4=((C_word*)t0)[3];
f_1766(t4,t3,((C_word*)t0)[2]);}

/* k1907 in k1914 in k1874 in loop in string-substitute in k494 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 538  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1872(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* substitute in string-substitute in k494 */
static void C_fcall f_1766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1766,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word)li36),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_1772(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k494 */
static void C_fcall f_1772(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1772,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_1786(2,t6,((C_word*)t0)[7]);}
else{
/* regex.scm: 514  substring */
t6=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:(C_word)C_u_i_char_numericp(t7));
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t7));
t11=(C_word)C_fixnum_difference(t10,C_fix(48));
t12=(C_word)C_i_list_ref(((C_word*)t0)[4],t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* regex.scm: 521  substring */
t14=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t14))(5,t14,t13,((C_word*)t0)[7],t2,t3);}
else{
t10=(C_word)C_fixnum_plus(t5,C_fix(1));
/* regex.scm: 524  loop */
t18=t1;
t19=t2;
t20=t10;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}
else{
/* regex.scm: 525  loop */
t18=t1;
t19=t2;
t20=t5;
t1=t18;
t2=t19;
t3=t20;
goto loop;}}}

/* k1837 in loop in substitute in string-substitute in k494 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=f_1751(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* regex.scm: 522  substring */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k1825 in k1837 in loop in substitute in string-substitute in k494 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=f_1751(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* regex.scm: 523  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1772(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k1784 in loop in substitute in string-substitute in k494 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
/* regex.scm: 514  push */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_1751(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k494 */
static C_word C_fcall f_1751(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k494 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+28)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1554r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1554r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1554r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(28);
t5=(C_word)C_i_check_string_2(t3,lf[71]);
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_fixnum_greaterp(t6,C_fix(0));
t9=(C_truep(t8)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_TRUE);
t10=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t11=(C_truep(t10)?(C_word)C_i_vector_ref(t4,C_fix(1)):C_fix(0));
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1573,a[2]=t11,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t7,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_eqp(t9,lf[73]);
if(C_truep(t13)){
t14=t12;
f_1573(t14,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t7,a[6]=((C_word)li31),tmp=(C_word)a,a+=7,tmp));}
else{
t14=(C_word)C_eqp(t9,lf[72]);
t15=t12;
f_1573(t15,(C_truep(t14)?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1692,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=((C_word)li32),tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1718,a[2]=((C_word*)t0)[2],a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp)));}}

/* f_1718 in string-split-fields in k494 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1718,4,t0,t1,t2,t3);}
/* regex.scm: 476  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* f_1692 in string-split-fields in k494 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1692,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=(C_word)C_a_i_cons(&a,2,lf[75],t2);
/* regex.scm: 474  reverse */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1717,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 475  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k1715 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1717,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* regex.scm: 475  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* f_1672 in string-split-fields in k494 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1672,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* regex.scm: 468  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[71],lf[74],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* regex.scm: 470  reverse */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* k1571 in string-split-fields in k494 */
static void C_fcall f_1573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1573,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[72]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[73]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1661,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1581,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word)li30),tmp=(C_word)a,a+=10,tmp));
t8=((C_word*)t6)[1];
f_1581(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k1571 in string-split-fields in k494 */
static void C_fcall f_1581(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1581,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* regex.scm: 481  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1583 in loop in k1571 in string-split-fields in k494 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* regex.scm: 488  fini */
t7=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_fixnum_plus(t4,C_fix(2));
/* regex.scm: 489  fetch */
t10=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t10))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1646,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex.scm: 490  fetch */
t7=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* regex.scm: 491  fini */
t2=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1644 in k1583 in loop in k1571 in string-split-fields in k494 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* regex.scm: 490  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1581(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1625 in k1583 in loop in k1571 in string-split-fields in k494 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1627,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* regex.scm: 489  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1581(t4,((C_word*)t0)[2],t2,t3);}

/* f_1661 in k1571 in string-split-fields in k494 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1661,5,t0,t1,t2,t3,t4);}
/* regex.scm: 479  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_1656 in k1571 in string-split-fields in k494 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1656,5,t0,t1,t2,t3,t4);}
/* regex.scm: 478  substring */
t5=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k494 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1544r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1544r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1544r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1552,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 449  prepare-search */
f_1488(t5,t2,t3,t4,lf[69]);}

/* k1550 in string-search-positions in k494 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 449  gather-result-positions */
f_1222(((C_word*)t0)[2],t1);}

/* string-search in k494 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1534r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1534r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1534r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1542,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 445  prepare-search */
f_1488(t5,t2,t3,t4,lf[68]);}

/* k1540 in string-search in k494 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 445  gather-results */
t2=lf[60];
f_1294(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-search in k494 */
static void C_fcall f_1488(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1488,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t9=(C_truep(t8)?(C_word)C_i_car(t4):C_fix(0));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1501,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t11=t10;
f_1501(t11,(C_word)C_i_car(t8));}
else{
t11=(C_word)C_block_size(t3);
t12=t10;
f_1501(t12,(C_word)C_fixnum_difference(t11,t9));}}

/* k1499 in prepare-search in k494 */
static void C_fcall f_1501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(C_word)C_i_check_exact_2(t1,((C_word*)t0)[5]);
/* regex.scm: 441  perform-match */
f_1359(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],t1,((C_word*)t0)[5]);}

/* string-match-positions in k494 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_1470r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1470r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1470r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1478,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 422  prepare-match */
f_1417(t5,t2,t3,t4,lf[66]);}

/* k1476 in string-match-positions in k494 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 422  gather-result-positions */
f_1222(((C_word*)t0)[2],t1);}

/* string-match in k494 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_1460r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1460r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1460r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1468,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 418  prepare-match */
f_1417(t5,t2,t3,t4,lf[65]);}

/* k1466 in string-match in k494 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 418  gather-results */
t2=lf[60];
f_1294(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* prepare-match in k494 */
static void C_fcall f_1417(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1417,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_string_2(t3,t5);
t7=(C_word)C_i_pairp(t4);
t8=(C_truep(t7)?(C_word)C_i_car(t4):C_fix(0));
t9=(C_word)C_i_check_exact_2(t8,t5);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1434,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t11=(C_word)C_fixnum_lessp(C_fix(0),t8);
/* regex.scm: 411  make-anchored-pattern */
t12=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t2,t11);}
else{
t11=t10;
f_1434(2,t11,t2);}}

/* k1432 in prepare-match in k494 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_difference(t2,((C_word*)t0)[4]);
/* regex.scm: 410  perform-match */
f_1359(((C_word*)t0)[3],t1,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[2]);}

/* perform-match in k494 */
static void C_fcall f_1359(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1359,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1363,a[2]=t2,a[3]=t1,a[4]=t10,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=t8,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* regex.scm: 382  re-checked-compile */
f_1000(t11,t2,C_fix(0),t6);}
else{
t12=t2;
if(C_truep((C_word)C_i_structurep(t12,lf[47]))){
t13=t2;
t14=(C_word)C_slot(t13,C_fix(2));
t15=C_set_block_item(t8,0,t14);
t16=t2;
t17=(C_word)C_slot(t16,C_fix(3));
t18=C_set_block_item(t10,0,t17);
t19=t2;
t20=t11;
f_1363(2,t20,(C_word)C_slot(t19,C_fix(1)));}
else{
/* regex.scm: 388  ##sys#signal-hook */
t13=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t11,lf[42],t6,lf[63],t2);}}}

/* k1361 in perform-match in k494 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=t1;
t3=((C_word*)((C_word*)t0)[8])[1];
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)stub195(C_SCHEME_UNDEFINED,t4,t5);
t7=t1;
t8=((C_word*)((C_word*)t0)[8])[1];
t9=((C_word*)t0)[7];
t10=((C_word*)t0)[6];
t11=((C_word*)t0)[5];
t12=((C_word*)((C_word*)t0)[4])[1];
t13=(C_word)C_i_foreign_pointer_argumentp(t7);
t14=(C_truep(t8)?(C_word)C_i_foreign_pointer_argumentp(t8):C_SCHEME_FALSE);
t15=(C_word)C_i_foreign_block_argumentp(t9);
t16=(C_word)C_i_foreign_fixnum_argumentp(t10);
t17=(C_word)C_i_foreign_fixnum_argumentp(t11);
t18=(C_word)C_i_foreign_unsigned_integer_argumentp(t12);
t19=(C_word)stub183(C_SCHEME_UNDEFINED,t13,t14,t15,t16,t17,t18);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1372,a[2]=t6,a[3]=t19,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* regex.scm: 394  re-finalizer */
t21=lf[37];
f_870(3,t21,t20,t1);}
else{
t21=t20;
f_1372(2,t21,C_SCHEME_UNDEFINED);}}

/* k1370 in k1361 in perform-match in k494 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* gather-results in k494 */
static void C_fcall f_1294(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1294,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1298,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 358  gather-result-positions */
f_1222(t4,t3);}

/* k1296 in gather-results in k494 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 360  ##sys#map */
t3=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1305 in k1296 in gather-results in k494 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1306,3,t0,t1,t2);}
if(C_truep(t2)){
C_apply(5,0,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* gather-result-positions in k494 */
static void C_fcall f_1222(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1222,NULL,2,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1240,a[2]=t6,a[3]=t3,a[4]=t4,a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1240(t8,t1,C_fix(0));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* loop in gather-result-positions in k494 */
static void C_fcall f_1240(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1240,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1260,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* regex.scm: 348  loop */
t13=t3;
t14=t4;
t1=t13;
t2=t14;
goto loop;}
else{
t3=t2;
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=(C_word)stub158(C_SCHEME_UNDEFINED,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(0)))){
t7=t2;
t8=(C_word)C_i_foreign_fixnum_argumentp(t7);
t9=(C_word)stub162(C_SCHEME_UNDEFINED,t8);
t10=t6;
f_1274(t10,(C_word)C_a_i_list(&a,2,t5,t9));}
else{
t7=t6;
f_1274(t7,C_SCHEME_FALSE);}}}}

/* k1272 in loop in gather-result-positions in k494 */
static void C_fcall f_1274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1274,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1278,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* regex.scm: 353  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1240(t4,t2,t3);}

/* k1276 in k1272 in loop in gather-result-positions in k494 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1278,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1258 in loop in gather-result-positions in k494 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* regexp-optimize in k494 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1174,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[47],lf[56]);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t7=(C_word)C_i_foreign_pointer_argumentp(t5);
t8=(C_word)stub145(t6,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1187,a[2]=t8,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k1185 in regexp-optimize in k494 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1187,2,t0,t1);}
if(C_truep(t1)){
/* regex.scm: 309  re-error */
t2=lf[49];
f_964(t2,((C_word*)t0)[4],lf[56],lf[57],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* set-finalizer! */
t4=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[37]);}
else{
t4=t3;
f_1196(2,t4,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k1194 in k1185 in regexp-optimize in k494 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* regexp* in k494 */
static void C_ccall f_1085(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1085r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1085r(t0,t1,t2,t3);}}

static void C_ccall f_1085r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1087,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1114,a[2]=t4,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1119,a[2]=t5,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-options126139 */
t7=t6;
f_1119(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-tables127137 */
t9=t5;
f_1114(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body124129 */
t11=t4;
f_1087(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-options126 in regexp* in k494 */
static void C_fcall f_1119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1119,NULL,2,t0,t1);}
/* def-tables127137 */
t2=((C_word*)t0)[2];
f_1114(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-tables127 in regexp* in k494 */
static void C_fcall f_1114(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1114,NULL,3,t0,t1,t2);}
/* body124129 */
t3=((C_word*)t0)[2];
f_1087(t3,t1,t2,C_SCHEME_FALSE);}

/* body124 in regexp* in k494 */
static void C_fcall f_1087(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1087,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[55]);
t5=(C_word)C_i_check_list_2(t2,lf[55]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1097,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex.scm: 290  ##sys#check-chardef-table */
t7=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,lf[55]);}
else{
t7=t6;
f_1097(2,t7,C_SCHEME_UNDEFINED);}}

/* k1095 in body124 in regexp* in k494 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1110,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 291  pcre-option->number */
f_498(t3,((C_word*)t0)[2]);}

/* k1108 in k1095 in body124 in regexp* in k494 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 291  re-checked-compile */
f_1000(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[55]);}

/* k1098 in k1095 in body124 in regexp* in k494 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1103,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* set-finalizer! */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[37]);}

/* k1101 in k1098 in k1095 in body124 in regexp* in k494 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[47],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* regexp in k494 */
static void C_ccall f_1015(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1015r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1015r(t0,t1,t2,t3);}}

static void C_ccall f_1015r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1017,a[2]=t3,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1083,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 282  options->integer */
t7=t4;
f_1017(t7,t6);}

/* k1081 in regexp in k494 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 282  re-checked-compile */
f_1000(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[47]);}

/* k1071 in regexp in k494 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1076,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* set-finalizer! */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[37]);}

/* k1074 in k1071 in regexp in k494 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1076,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[47],((C_word*)t0)[2],C_SCHEME_FALSE,C_fix(0)));}

/* options->integer in regexp in k494 */
static void C_fcall f_1017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1017,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[2]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_truep(t2)?C_unsigned_int_to_num(&a,PCRE_CASELESS):C_fix(0));
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1038,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1038(t6,C_fix(0));}
else{
t6=(C_word)C_i_car(t4);
t7=(C_truep(t6)?C_unsigned_int_to_num(&a,PCRE_EXTENDED):C_fix(0));
t8=(C_word)C_i_cdr(t4);
t9=(C_word)C_i_pairp(t8);
t10=(C_truep(t9)?(C_word)C_i_car(t8):C_SCHEME_FALSE);
t11=(C_truep(t10)?C_unsigned_int_to_num(&a,PCRE_UTF8):C_fix(0));
t12=t5;
f_1038(t12,(C_word)C_a_i_plus(&a,2,t7,t11));}}}

/* k1036 in options->integer in regexp in k494 */
static void C_fcall f_1038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1038,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* re-checked-compile in k494 */
static void C_fcall f_1000(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1000,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=t2;
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_983,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t7,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}

/* k981 in re-checked-compile in k494 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(C_word)C_i_foreign_unsigned_integer_argumentp(((C_word*)t0)[6]);
t3=(C_word)stub98(((C_word*)t0)[5],t1,t2,C_SCHEME_FALSE);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* regex.scm: 266  re-error */
t4=lf[49];
f_964(t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[53],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],C_fix((C_word)C_regex_error_offset)));}}

/* re-error in k494 */
static void C_fcall f_964(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_964,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_972,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_976,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}

/* k974 in re-error in k494 */
static void C_ccall f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex.scm: 253  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[50],t1);}

/* k970 in re-error in k494 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],*((C_word*)lf[3]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* regexp? in k494 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_958,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[47]));}

/* regex-chardef-table in k494 */
static void C_ccall f_903(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_903r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_903r(t0,t1,t2);}}

static void C_ccall f_903r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_907,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_907(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_907(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k905 in regex-chardef-table in k494 */
static void C_ccall f_907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_907,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_pointerp(t1))){
/* regex.scm: 222  re-make-chardef-table-type */
f_898(((C_word*)t0)[2],t1);}
else{
/* regex.scm: 223  ##sys#signal-hook */
t2=*((C_word*)lf[41]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[42],lf[40],lf[43],t1);}}
else{
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t3=(C_word)stub72(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* regex.scm: 228  re-make-chardef-table-type */
f_898(t4,t3);}
else{
/* regex.scm: 231  ##sys#error-hook */
t4=*((C_word*)lf[45]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],C_fix(6),lf[40]);}}}

/* k929 in k905 in regex-chardef-table in k494 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_934,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* regex.scm: 229  set-finalizer! */
t3=*((C_word*)lf[44]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[37]);}

/* k932 in k929 in k905 in regex-chardef-table in k494 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* re-make-chardef-table-type in k494 */
static void C_fcall f_898(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_898,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_902,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#make-tagged-pointer */
t4=*((C_word*)lf[39]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[38]);}

/* k900 in re-make-chardef-table-type in k494 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_pointer(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* regex-chardef-table? in k494 */
static void C_ccall f_880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_880,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[38],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* re-finalizer in k494 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_870,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub51(C_SCHEME_UNDEFINED,t3));}

/* pcre-option->number in k494 */
static void C_fcall f_498(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_498,NULL,2,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_508,a[2]=t6,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_508(t8,t1,t4,C_fix(0));}

/* loop in pcre-option->number in k494 */
static void C_fcall f_508(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_508,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_533,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[7]);
if(C_truep(t7)){
t8=t6;
f_533(2,t8,C_unsigned_int_to_num(&a,PCRE_CASELESS));}
else{
t8=(C_word)C_eqp(t5,lf[8]);
if(C_truep(t8)){
t9=t6;
f_533(2,t9,C_unsigned_int_to_num(&a,PCRE_MULTILINE));}
else{
t9=(C_word)C_eqp(t5,lf[9]);
if(C_truep(t9)){
t10=t6;
f_533(2,t10,C_unsigned_int_to_num(&a,PCRE_DOTALL));}
else{
t10=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t10)){
t11=t6;
f_533(2,t11,C_unsigned_int_to_num(&a,PCRE_EXTENDED));}
else{
t11=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t11)){
t12=t6;
f_533(2,t12,C_unsigned_int_to_num(&a,PCRE_ANCHORED));}
else{
t12=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t12)){
t13=t6;
f_533(2,t13,C_unsigned_int_to_num(&a,PCRE_DOLLAR_ENDONLY));}
else{
t13=(C_word)C_eqp(t5,lf[13]);
if(C_truep(t13)){
t14=t6;
f_533(2,t14,C_unsigned_int_to_num(&a,PCRE_EXTRA));}
else{
t14=(C_word)C_eqp(t5,lf[14]);
if(C_truep(t14)){
t15=t6;
f_533(2,t15,C_unsigned_int_to_num(&a,PCRE_NOTBOL));}
else{
t15=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t15)){
t16=t6;
f_533(2,t16,C_unsigned_int_to_num(&a,PCRE_NOTEOL));}
else{
t16=(C_word)C_eqp(t5,lf[16]);
if(C_truep(t16)){
t17=t6;
f_533(2,t17,C_unsigned_int_to_num(&a,PCRE_UNGREEDY));}
else{
t17=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t17)){
t18=t6;
f_533(2,t18,C_unsigned_int_to_num(&a,PCRE_NOTEMPTY));}
else{
t18=(C_word)C_eqp(t5,lf[18]);
if(C_truep(t18)){
t19=t6;
f_533(2,t19,C_unsigned_int_to_num(&a,PCRE_UTF8));}
else{
t19=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t19)){
t20=t6;
f_533(2,t20,C_unsigned_int_to_num(&a,PCRE_NO_AUTO_CAPTURE));}
else{
t20=(C_word)C_eqp(t5,lf[20]);
if(C_truep(t20)){
t21=t6;
f_533(2,t21,C_unsigned_int_to_num(&a,PCRE_NO_UTF8_CHECK));}
else{
t21=(C_word)C_eqp(t5,lf[21]);
if(C_truep(t21)){
t22=t6;
f_533(2,t22,C_unsigned_int_to_num(&a,PCRE_AUTO_CALLOUT));}
else{
t22=(C_word)C_eqp(t5,lf[22]);
if(C_truep(t22)){
t23=t6;
f_533(2,t23,C_unsigned_int_to_num(&a,PCRE_PARTIAL));}
else{
t23=(C_word)C_eqp(t5,lf[23]);
if(C_truep(t23)){
t24=t6;
f_533(2,t24,C_unsigned_int_to_num(&a,PCRE_DFA_SHORTEST));}
else{
t24=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t24)){
t25=t6;
f_533(2,t25,C_unsigned_int_to_num(&a,PCRE_DFA_RESTART));}
else{
t25=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t25)){
t26=t6;
f_533(2,t26,C_unsigned_int_to_num(&a,PCRE_FIRSTLINE));}
else{
t26=(C_word)C_eqp(t5,lf[26]);
if(C_truep(t26)){
t27=t6;
f_533(2,t27,C_unsigned_int_to_num(&a,PCRE_DUPNAMES));}
else{
t27=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t27)){
t28=t6;
f_533(2,t28,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CR));}
else{
t28=(C_word)C_eqp(t5,lf[28]);
if(C_truep(t28)){
t29=t6;
f_533(2,t29,C_unsigned_int_to_num(&a,PCRE_NEWLINE_LF));}
else{
t29=(C_word)C_eqp(t5,lf[29]);
if(C_truep(t29)){
t30=t6;
f_533(2,t30,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CRLF));}
else{
t30=(C_word)C_eqp(t5,lf[30]);
if(C_truep(t30)){
t31=t6;
f_533(2,t31,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANY));}
else{
t31=(C_word)C_eqp(t5,lf[31]);
if(C_truep(t31)){
t32=t6;
f_533(2,t32,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANYCRLF));}
else{
t32=(C_word)C_eqp(t5,lf[32]);
if(C_truep(t32)){
t33=t6;
f_533(2,t33,C_unsigned_int_to_num(&a,PCRE_BSR_ANYCRLF));}
else{
t33=(C_word)C_eqp(t5,lf[33]);
if(C_truep(t33)){
t34=t6;
f_533(2,t34,C_unsigned_int_to_num(&a,PCRE_BSR_UNICODE));}
else{
/* regex.scm: 139  error */
t34=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t34+1)))(5,t34,t6,lf[35],t5,lf[36]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k531 in loop in pcre-option->number in k494 */
static void C_ccall f_533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_533,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex.scm: 139  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_508(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* ##sys#check-chardef-table */
static void C_ccall f_483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_483,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_490,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex.scm: 90   regex-chardef-table? */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k488 in ##sys#check-chardef-table */
static void C_ccall f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* regex.scm: 91   ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[4],((C_word*)t0)[2]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[126] = {
{"toplevelregex.scm",(void*)C_regex_toplevel},
{"f_496regex.scm",(void*)f_496},
{"f_2480regex.scm",(void*)f_2480},
{"f_2532regex.scm",(void*)f_2532},
{"f_2527regex.scm",(void*)f_2527},
{"f_2482regex.scm",(void*)f_2482},
{"f_2506regex.scm",(void*)f_2506},
{"f_2520regex.scm",(void*)f_2520},
{"f_2424regex.scm",(void*)f_2424},
{"f_2431regex.scm",(void*)f_2431},
{"f_2439regex.scm",(void*)f_2439},
{"f_2471regex.scm",(void*)f_2471},
{"f_2458regex.scm",(void*)f_2458},
{"f_2461regex.scm",(void*)f_2461},
{"f_2384regex.scm",(void*)f_2384},
{"f_2393regex.scm",(void*)f_2393},
{"f_2412regex.scm",(void*)f_2412},
{"f_2419regex.scm",(void*)f_2419},
{"f_2116regex.scm",(void*)f_2116},
{"f_2131regex.scm",(void*)f_2131},
{"f_2133regex.scm",(void*)f_2133},
{"f_2379regex.scm",(void*)f_2379},
{"f_2368regex.scm",(void*)f_2368},
{"f_2191regex.scm",(void*)f_2191},
{"f_2273regex.scm",(void*)f_2273},
{"f_2297regex.scm",(void*)f_2297},
{"f_2252regex.scm",(void*)f_2252},
{"f_2223regex.scm",(void*)f_2223},
{"f_2193regex.scm",(void*)f_2193},
{"f_2201regex.scm",(void*)f_2201},
{"f_2189regex.scm",(void*)f_2189},
{"f_2176regex.scm",(void*)f_2176},
{"f_2163regex.scm",(void*)f_2163},
{"f_2127regex.scm",(void*)f_2127},
{"f_2031regex.scm",(void*)f_2031},
{"f_2044regex.scm",(void*)f_2044},
{"f_2063regex.scm",(void*)f_2063},
{"f_1979regex.scm",(void*)f_1979},
{"f_1994regex.scm",(void*)f_1994},
{"f_2011regex.scm",(void*)f_2011},
{"f_1736regex.scm",(void*)f_1736},
{"f_1872regex.scm",(void*)f_1872},
{"f_1876regex.scm",(void*)f_1876},
{"f_1967regex.scm",(void*)f_1967},
{"f_1963regex.scm",(void*)f_1963},
{"f_1934regex.scm",(void*)f_1934},
{"f_1916regex.scm",(void*)f_1916},
{"f_1909regex.scm",(void*)f_1909},
{"f_1766regex.scm",(void*)f_1766},
{"f_1772regex.scm",(void*)f_1772},
{"f_1839regex.scm",(void*)f_1839},
{"f_1827regex.scm",(void*)f_1827},
{"f_1786regex.scm",(void*)f_1786},
{"f_1751regex.scm",(void*)f_1751},
{"f_1554regex.scm",(void*)f_1554},
{"f_1718regex.scm",(void*)f_1718},
{"f_1692regex.scm",(void*)f_1692},
{"f_1717regex.scm",(void*)f_1717},
{"f_1672regex.scm",(void*)f_1672},
{"f_1573regex.scm",(void*)f_1573},
{"f_1581regex.scm",(void*)f_1581},
{"f_1585regex.scm",(void*)f_1585},
{"f_1646regex.scm",(void*)f_1646},
{"f_1627regex.scm",(void*)f_1627},
{"f_1661regex.scm",(void*)f_1661},
{"f_1656regex.scm",(void*)f_1656},
{"f_1544regex.scm",(void*)f_1544},
{"f_1552regex.scm",(void*)f_1552},
{"f_1534regex.scm",(void*)f_1534},
{"f_1542regex.scm",(void*)f_1542},
{"f_1488regex.scm",(void*)f_1488},
{"f_1501regex.scm",(void*)f_1501},
{"f_1470regex.scm",(void*)f_1470},
{"f_1478regex.scm",(void*)f_1478},
{"f_1460regex.scm",(void*)f_1460},
{"f_1468regex.scm",(void*)f_1468},
{"f_1417regex.scm",(void*)f_1417},
{"f_1434regex.scm",(void*)f_1434},
{"f_1359regex.scm",(void*)f_1359},
{"f_1363regex.scm",(void*)f_1363},
{"f_1372regex.scm",(void*)f_1372},
{"f_1294regex.scm",(void*)f_1294},
{"f_1298regex.scm",(void*)f_1298},
{"f_1306regex.scm",(void*)f_1306},
{"f_1222regex.scm",(void*)f_1222},
{"f_1240regex.scm",(void*)f_1240},
{"f_1274regex.scm",(void*)f_1274},
{"f_1278regex.scm",(void*)f_1278},
{"f_1260regex.scm",(void*)f_1260},
{"f_1174regex.scm",(void*)f_1174},
{"f_1187regex.scm",(void*)f_1187},
{"f_1196regex.scm",(void*)f_1196},
{"f_1085regex.scm",(void*)f_1085},
{"f_1119regex.scm",(void*)f_1119},
{"f_1114regex.scm",(void*)f_1114},
{"f_1087regex.scm",(void*)f_1087},
{"f_1097regex.scm",(void*)f_1097},
{"f_1110regex.scm",(void*)f_1110},
{"f_1100regex.scm",(void*)f_1100},
{"f_1103regex.scm",(void*)f_1103},
{"f_1015regex.scm",(void*)f_1015},
{"f_1083regex.scm",(void*)f_1083},
{"f_1073regex.scm",(void*)f_1073},
{"f_1076regex.scm",(void*)f_1076},
{"f_1017regex.scm",(void*)f_1017},
{"f_1038regex.scm",(void*)f_1038},
{"f_1000regex.scm",(void*)f_1000},
{"f_983regex.scm",(void*)f_983},
{"f_964regex.scm",(void*)f_964},
{"f_976regex.scm",(void*)f_976},
{"f_972regex.scm",(void*)f_972},
{"f_958regex.scm",(void*)f_958},
{"f_903regex.scm",(void*)f_903},
{"f_907regex.scm",(void*)f_907},
{"f_931regex.scm",(void*)f_931},
{"f_934regex.scm",(void*)f_934},
{"f_898regex.scm",(void*)f_898},
{"f_902regex.scm",(void*)f_902},
{"f_880regex.scm",(void*)f_880},
{"f_870regex.scm",(void*)f_870},
{"f_498regex.scm",(void*)f_498},
{"f_508regex.scm",(void*)f_508},
{"f_533regex.scm",(void*)f_533},
{"f_483regex.scm",(void*)f_483},
{"f_490regex.scm",(void*)f_490},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
