/* Generated from regex-extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-01-18 12:10
   Version 3.0.0rc1 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook lockts ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-17 on dill (Linux)
   command line: regex-extras.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file regex-extras.c
   unit: regex_extras
*/

#include "chicken.h"

static void
out_of_memory_failure(const char *modnam, const char *prcnam, const char *typnam)
{
  fprintf(stderr, "%s@%s: out of memory - cannot allocate %s\\n", modnam, prcnam, typnam);
  exit(EXIT_FAILURE);
}
#include "pcre/pcre.h"
#include "pcre/pcre_internal.h"

typedef struct {
  char *nametable;
  int entrysize;
} pcre_nametable;

static int
get_nametable_entrycount(const pcre *code, const pcre_extra *extra)
{
  int val;
  pcre_fullinfo(code, extra, PCRE_INFO_NAMECOUNT, &val);
  return val;
}

static pcre_nametable *
get_nametable(const pcre *code, const pcre_extra *extra)
{
  pcre_nametable *nametable = (pcre_nametable *)(pcre_malloc)(sizeof(pcre_nametable));
  if (!nametable) out_of_memory_failure("regex-extras", "get_nametable", "pcre_nametable");
  pcre_fullinfo(code, extra, PCRE_INFO_NAMETABLE, &nametable->nametable);
  pcre_fullinfo(code, extra, PCRE_INFO_NAMEENTRYSIZE, &nametable->entrysize);
  return nametable;
}

static char *
get_nametable_entry(const pcre_nametable *nt, int idx, int *pcc)
{
  typedef struct {
    uint16_t cc;
    char name[1];
  } pcre_nametable_entry;

  pcre_nametable_entry *entry = ((pcre_nametable_entry *)(nt->nametable)) + (idx * nt->entrysize);
  /* Number of capturing parentheses is MSB */
# ifdef C_LITTLE_ENDIAN
  uint16_t cc;
  ((uint8_t *)&cc)[0] = ((uint8_t *)&entry->cc)[1];
  ((uint8_t *)&cc)[1] = ((uint8_t *)&entry->cc)[0];
  *pcc = cc;
# else
  *pcc = entry->cc;
# endif
  return entry->name;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[143];
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,7),40,102,95,54,51,54,41};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,15),40,114,101,103,101,120,45,118,101,114,115,105,111,110,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,115,121,109,115,51,57,32,115,117,109,52,48,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,28),40,112,99,114,101,45,111,112,116,105,111,110,45,62,110,117,109,98,101,114,32,115,121,109,115,51,55,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,22),40,114,101,45,102,105,110,97,108,105,122,101,114,32,97,49,48,52,49,48,56,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,28),40,114,101,45,99,104,97,114,100,101,102,45,116,97,98,108,101,32,116,97,98,108,101,115,49,49,57,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,21),40,114,101,103,101,120,45,99,104,97,114,100,101,102,45,116,97,98,108,101,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,115,121,109,115,49,52,49,32,115,117,109,49,52,50,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,27),40,112,99,114,101,45,99,98,105,116,45,62,110,117,109,98,101,114,32,115,121,109,115,49,51,57,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,115,121,109,115,49,54,49,32,115,117,109,49,54,50,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,28),40,112,99,114,101,45,99,116,121,112,101,45,62,110,117,109,98,101,114,32,115,121,109,115,49,53,57,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,44),40,99,104,97,114,100,101,102,45,99,108,97,115,115,45,115,101,116,33,32,97,50,50,49,50,50,53,32,97,50,50,48,50,50,54,32,97,50,49,57,50,50,55,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,39),40,99,104,97,114,100,101,102,45,99,108,97,115,115,32,97,50,51,49,50,51,53,32,97,50,51,48,50,51,54,32,97,50,50,57,50,51,55,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,14),40,97,49,56,54,55,32,115,121,109,50,52,49,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,41),40,99,104,97,114,100,101,102,45,99,108,97,115,115,101,115,45,99,108,101,97,114,33,32,116,97,98,108,101,115,50,51,57,32,105,100,120,50,52,48,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,37),40,99,104,97,114,100,101,102,45,116,121,112,101,45,99,108,101,97,114,33,32,97,50,52,51,50,52,55,32,97,50,52,50,50,52,56,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,43),40,99,104,97,114,100,101,102,45,116,121,112,101,45,115,101,116,33,32,97,50,53,50,50,53,54,32,97,50,53,49,50,53,55,32,97,50,53,48,50,53,56,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,38),40,99,104,97,114,100,101,102,45,116,121,112,101,32,97,50,54,50,50,54,54,32,97,50,54,49,50,54,55,32,97,50,54,48,50,54,56,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,49,57,55,49,32,115,121,109,50,56,49,41};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,49),40,115,101,116,45,115,121,109,98,111,108,115,32,115,121,109,115,50,55,55,32,99,108,101,97,114,50,55,56,32,115,121,109,45,62,110,117,109,50,55,57,32,115,101,116,50,56,48,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,56),40,114,101,103,101,120,45,99,104,97,114,100,101,102,45,115,101,116,33,32,116,97,98,108,101,115,50,55,48,32,105,100,120,45,111,114,45,99,104,97,114,50,55,49,32,99,104,97,114,100,101,102,50,55,50,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,14),40,100,111,50,57,54,32,105,100,120,50,57,56,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,46),40,114,101,103,101,120,45,99,104,97,114,100,101,102,115,45,117,112,100,97,116,101,33,32,116,97,98,108,101,115,50,57,52,32,99,104,97,114,100,101,102,115,50,57,53,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,21),40,108,111,111,112,32,115,121,109,115,51,49,54,32,108,115,116,51,49,55,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,40),40,103,101,116,45,115,121,109,98,111,108,115,32,115,121,109,115,51,49,50,32,103,101,116,51,49,51,32,115,121,109,45,62,110,117,109,51,49,52,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,14),40,100,111,51,48,55,32,105,100,120,51,48,57,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,26),40,114,101,103,101,120,45,99,104,97,114,100,101,102,115,32,116,97,98,108,101,115,51,48,53,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,102,95,50,50,49,51,32,97,51,51,55,51,52,48,32,97,51,51,54,51,52,49,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,24),40,102,95,50,50,51,53,32,97,51,52,52,51,52,55,32,97,51,52,51,51,52,56,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,24),40,102,95,50,50,53,55,32,97,51,53,49,51,53,52,32,97,51,53,48,51,53,53,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,24),40,102,95,50,50,55,57,32,97,51,53,56,51,54,50,32,97,51,53,55,51,54,51,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,97,114,103,115,52,48,51,41};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,48),40,114,101,45,101,120,116,114,97,45,102,105,101,108,100,115,45,115,101,116,33,32,108,111,99,51,57,57,32,101,120,116,114,97,52,48,48,32,46,32,97,114,103,115,52,48,49,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,40),40,114,101,103,101,120,112,45,101,120,116,114,97,45,105,110,102,111,45,115,101,116,33,32,114,120,52,48,56,32,46,32,97,114,103,115,52,48,57,41};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,24),40,102,95,50,51,48,55,32,97,51,55,50,51,55,53,32,97,51,55,49,51,55,54,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,24),40,102,95,50,51,50,54,32,97,51,55,56,51,56,49,32,97,51,55,55,51,56,50,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,24),40,102,95,50,51,52,53,32,97,51,56,52,51,56,55,32,97,51,56,51,51,56,56,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,24),40,102,95,50,51,54,56,32,97,51,57,49,51,57,53,32,97,51,57,48,51,57,54,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,14),40,97,50,52,53,56,32,115,121,109,52,50,51,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,37),40,114,101,103,101,120,112,45,101,120,116,114,97,45,105,110,102,111,32,114,120,52,49,57,32,46,32,102,105,101,108,100,115,52,50,48,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,40),40,114,101,103,101,120,112,45,111,112,116,105,111,110,115,45,115,101,116,33,32,114,120,52,51,48,32,46,32,111,112,116,105,111,110,115,52,51,49,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,14),40,97,50,52,55,55,32,115,121,109,52,50,56,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,23),40,114,101,103,101,120,112,45,111,112,116,105,111,110,115,32,111,98,106,52,51,53,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,115,121,109,115,54,57,32,115,117,109,55,48,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,14),40,97,50,54,50,50,32,115,121,109,52,56,54,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,31),40,114,101,103,101,120,112,45,105,110,102,111,32,114,120,52,56,48,32,46,32,102,105,101,108,100,115,52,56,49,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,100,120,53,51,52,32,108,115,116,53,51,53,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,29),40,114,101,103,101,120,112,45,105,110,102,111,45,110,97,109,101,116,97,98,108,101,32,114,120,53,50,54,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,115,121,109,115,57,50,32,115,117,109,57,51,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,14),40,97,50,56,51,54,32,115,121,109,53,53,50,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,37),40,114,101,103,101,120,45,98,117,105,108,100,45,99,111,110,102,105,103,45,105,110,102,111,32,46,32,102,105,101,108,100,115,53,53,49,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41};


/* from k2827 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub548(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub548(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fieldno=(int )C_unfix(C_a0);
int val;pcre_config(fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2820 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub544(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub544(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fieldno=(int )C_unfix(C_a0);
int val;pcre_config(fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2749 */
static C_word C_fcall stub518(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub518(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre_nametable *t0=(const pcre_nametable *)C_c_pointer_nn(C_a0);
int t1=(int )C_unfix(C_a1);
int *t2=(int *)C_c_pointer_or_null(C_a2);
C_r=C_mpointer(&C_a,(void*)get_nametable_entry(t0,t1,t2));
return C_r;}

/* from k2727 */
static C_word C_fcall stub508(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub508(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *t0=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *t1=(const pcre_extra *)C_c_pointer_or_null(C_a1);
C_r=C_mpointer(&C_a,(void*)get_nametable(t0,t1));
return C_r;}

/* from k2713 */
static C_word C_fcall stub500(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub500(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *t0=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *t1=(const pcre_extra *)C_c_pointer_or_null(C_a1);
C_r=C_fix((C_word)get_nametable_entrycount(t0,t1));
return C_r;}

/* from k2601 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub472(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub472(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
pcre_extra *extra=(pcre_extra *)C_c_pointer_or_null(C_a1);
int fieldno=(int )C_unfix(C_a2);
void *val;pcre_fullinfo(code, extra, fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2583 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub462(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub462(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
pcre_extra *extra=(pcre_extra *)C_c_pointer_or_null(C_a1);
int fieldno=(int )C_unfix(C_a2);
int val;pcre_fullinfo(code, extra, fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2565 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub452(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub452(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
pcre_extra *extra=(pcre_extra *)C_c_pointer_or_null(C_a1);
int fieldno=(int )C_unfix(C_a2);
int val;pcre_fullinfo(code, extra, fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2547 */
#define return(x) C_cblock C_r = (C_long_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub441(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub441(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
pcre_extra *extra=(pcre_extra *)C_c_pointer_or_null(C_a1);
int fieldno=(int )C_unfix(C_a2);
long int val;pcre_fullinfo(code, extra, fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2375 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub392(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub392(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
const unsigned C_char *val=(const unsigned C_char *)C_c_pointer_or_null(C_a1);
return(extra->tables);
C_ret:
#undef return

return C_r;}

/* from k2352 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub385(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub385(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned char * val=(unsigned char * )C_c_bytevector(C_a1);
return(extra->callout_data);
C_ret:
#undef return

return C_r;}

/* from k2333 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub379(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub379(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned long val=(unsigned long )C_num_to_unsigned_long(C_a1);
return(extra->match_limit_recursion);
C_ret:
#undef return

return C_r;}

/* from k2314 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub373(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub373(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned long val=(unsigned long )C_num_to_unsigned_long(C_a1);
return(extra->match_limit);
C_ret:
#undef return

return C_r;}

/* from k2286 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub359(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub359(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
const unsigned C_char *val=(const unsigned C_char *)C_c_pointer_or_null(C_a1);
extra->tables = val;extra->flags |= PCRE_EXTRA_TABLES;
C_ret:
#undef return

return C_r;}

/* from k2264 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub352(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub352(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned char * val=(unsigned char * )C_c_bytevector(C_a1);
extra->callout_data = val;extra->flags |= PCRE_EXTRA_CALLOUT_DATA;
C_ret:
#undef return

return C_r;}

/* from k2242 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub345(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub345(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned long val=(unsigned long )C_num_to_unsigned_long(C_a1);
extra->match_limit_recursion = val;extra->flags |= PCRE_EXTRA_MATCH_LIMIT_RECURSION;
C_ret:
#undef return

return C_r;}

/* from k2220 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub338(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub338(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned long val=(unsigned long )C_num_to_unsigned_long(C_a1);
extra->match_limit = val;extra->flags |= PCRE_EXTRA_MATCH_LIMIT;
C_ret:
#undef return

return C_r;}

/* from re-extra */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub327(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub327(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra = (pcre_extra *)(pcre_malloc)(sizeof(pcre_extra));if (!extra) out_of_memory_failure("regex-extras", "re-extra", "pcre_extra");extra->flags = 0;extra->study_data = NULL;extra->match_limit = 0;extra->match_limit_recursion = 0;extra->callout_data = NULL;extra->tables = NULL;return(extra);
C_ret:
#undef return

return C_r;}

/* from k1921 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub263(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub263(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int type=(unsigned int )C_unfix(C_a2);
return(tables[ctypes_offset + idx] & type);
C_ret:
#undef return

return C_r;}

/* from k1903 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int type=(unsigned int )C_unfix(C_a2);
tables[ctypes_offset + idx] += type;
C_ret:
#undef return

return C_r;}

/* from k1885 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub244(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub244(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
tables[ctypes_offset + idx] = 0;
C_ret:
#undef return

return C_r;}

/* from k1855 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub232(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub232(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int class=(unsigned int )C_unfix(C_a2);
return(tables[cbits_offset + class + idx/8] & (1 << (idx & 7)));
C_ret:
#undef return

return C_r;}

/* from k1837 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub222(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub222(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int class=(unsigned int )C_unfix(C_a2);
tables[cbits_offset + class + idx/8] |= 1 << (idx & 7);
C_ret:
#undef return

return C_r;}

/* from k1819 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub212(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub212(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int class=(unsigned int )C_unfix(C_a2);
tables[cbits_offset + class + idx/8] &= ~(1 << (idx & 7));
C_ret:
#undef return

return C_r;}

/* from k1801 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub203(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub203(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
return(tables[fcc_offset + idx]);
C_ret:
#undef return

return C_r;}

/* from k1787 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub194(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub194(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned C_char flipped=(unsigned C_char )C_character_code((C_word)C_a2);
tables[fcc_offset + idx] = flipped;
C_ret:
#undef return

return C_r;}

/* from k1769 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub185(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub185(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
return(tables[lcc_offset + idx]);
C_ret:
#undef return

return C_r;}

/* from k1755 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub176(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub176(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned C_char lower=(unsigned C_char )C_character_code((C_word)C_a2);
tables[lcc_offset + idx] = lower;
C_ret:
#undef return

return C_r;}

/* from re-maketables */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub124(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned char *tables = pcre_maketables();if (!tables) out_of_memory_failure("regex-extras", "re-maketables", "tables");return(tables);
C_ret:
#undef return

return C_r;}

/* from k1424 */
static C_word C_fcall stub105(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub105(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

/* from f_636 in regex-version in k620 in k617 */
static C_word C_fcall stub7(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub7(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_mpointer(&C_a,(void*)pcre_version());
return C_r;}

C_noret_decl(C_regex_extras_toplevel)
C_externexport void C_ccall C_regex_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_622)
static void C_ccall f_622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_fcall f_2786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_fcall f_1025(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_fcall f_2430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2391)
static void C_fcall f_2391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_fcall f_2096(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_fcall f_2116(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2122)
static void C_fcall f_2122(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_fcall f_1953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_fcall f_1959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_fcall f_1960(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1633)
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1464)
static void C_fcall f_1464(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_fcall f_1432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_642)
static void C_fcall f_642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_652)
static void C_fcall f_652(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_677)
static void C_ccall f_677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_624)
static void C_ccall f_624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_636)
static void C_ccall f_636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_628)
static void C_ccall f_628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1270)
static void C_fcall trf_1270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1270(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1270(t0,t1,t2,t3);}

C_noret_decl(trf_2786)
static void C_fcall trf_2786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2786(t0,t1,t2,t3);}

C_noret_decl(trf_1025)
static void C_fcall trf_1025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1025(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1025(t0,t1,t2,t3);}

C_noret_decl(trf_2430)
static void C_fcall trf_2430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2430(t0,t1);}

C_noret_decl(trf_2391)
static void C_fcall trf_2391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2391(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2391(t0,t1,t2);}

C_noret_decl(trf_2096)
static void C_fcall trf_2096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2096(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2096(t0,t1,t2);}

C_noret_decl(trf_2116)
static void C_fcall trf_2116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2116(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2116(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2122)
static void C_fcall trf_2122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2122(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2122(t0,t1,t2,t3);}

C_noret_decl(trf_2049)
static void C_fcall trf_2049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2049(t0,t1,t2);}

C_noret_decl(trf_1953)
static void C_fcall trf_1953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1953(t0,t1);}

C_noret_decl(trf_1959)
static void C_fcall trf_1959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1959(t0,t1);}

C_noret_decl(trf_1960)
static void C_fcall trf_1960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1960(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1960(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1633)
static void C_fcall trf_1633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1633(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1633(t0,t1,t2,t3);}

C_noret_decl(trf_1464)
static void C_fcall trf_1464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1464(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1464(t0,t1,t2,t3);}

C_noret_decl(trf_1432)
static void C_fcall trf_1432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1432(t0,t1);}

C_noret_decl(trf_642)
static void C_fcall trf_642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_642(t0,t1);}

C_noret_decl(trf_652)
static void C_fcall trf_652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_652(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_652(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2319)){
C_save(t1);
C_rereclaim2(2319*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,143);
lf[0]=C_h_intern(&lf[0],9,"substring");
lf[1]=C_h_intern(&lf[1],15,"substring-index");
lf[2]=C_h_intern(&lf[2],13,"regex-version");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[4]=C_h_intern(&lf[4],25,"\003syspeek-nonnull-c-string");
lf[6]=C_h_intern(&lf[6],8,"caseless");
lf[7]=C_h_intern(&lf[7],9,"multiline");
lf[8]=C_h_intern(&lf[8],6,"dotall");
lf[9]=C_h_intern(&lf[9],8,"extended");
lf[10]=C_h_intern(&lf[10],8,"anchored");
lf[11]=C_h_intern(&lf[11],14,"dollar-endonly");
lf[12]=C_h_intern(&lf[12],5,"extra");
lf[13]=C_h_intern(&lf[13],6,"notbol");
lf[14]=C_h_intern(&lf[14],6,"noteol");
lf[15]=C_h_intern(&lf[15],8,"ungreedy");
lf[16]=C_h_intern(&lf[16],8,"notempty");
lf[17]=C_h_intern(&lf[17],4,"utf8");
lf[18]=C_h_intern(&lf[18],15,"no-auto-capture");
lf[19]=C_h_intern(&lf[19],13,"no-utf8-check");
lf[20]=C_h_intern(&lf[20],12,"auto-callout");
lf[21]=C_h_intern(&lf[21],7,"partial");
lf[22]=C_h_intern(&lf[22],12,"dfa-shortest");
lf[23]=C_h_intern(&lf[23],11,"dfa-restart");
lf[24]=C_h_intern(&lf[24],9,"firstline");
lf[25]=C_h_intern(&lf[25],8,"dupnames");
lf[26]=C_h_intern(&lf[26],10,"newline-cr");
lf[27]=C_h_intern(&lf[27],10,"newline-lf");
lf[28]=C_h_intern(&lf[28],12,"newline-crlf");
lf[29]=C_h_intern(&lf[29],11,"newline-any");
lf[30]=C_h_intern(&lf[30],15,"newline-anycrlf");
lf[31]=C_h_intern(&lf[31],11,"bsr-anycrlf");
lf[32]=C_h_intern(&lf[32],11,"bsr-unicode");
lf[33]=C_h_intern(&lf[33],5,"error");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\024not a member of enum");
lf[35]=C_h_intern(&lf[35],11,"pcre-option");
lf[37]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007options\376\001\000\000\014long-integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004size\376\001\000\000\014long-integer\376\003\000\000\002"
"\376\003\000\000\002\376\001\000\000\014capturecount\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012backrefmax\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\011firstbyte\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011firstchar\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012fi"
"rsttable\376\001\000\000\007pointer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013lastliteral\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015nameent"
"rysize\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011namecount\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011nametable\376\001"
"\000\000\007pointer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011studysize\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016default-tables\376\001\000\000\007"
"pointer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011okpartial\376\001\000\000\007boolean\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010jchanged\376\001\000\000\007boolean\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\011hascrorlf\376\001\000\000\007boolean\376\377\016");
lf[40]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004utf8\376\001\000\000\007boolean\376\003\000\000\002\376\003\000\000\002\376\001\000\000\007newline\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"link-size\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\026posix-malloc-threshold\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\013match-limit\376\001\000\000\007integer\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014stackrecurse\376\001\000\000\007boolean\376\003\000\000\002\376\003\000\000\002\376\001\000"
"\000\022unicode-properties\376\001\000\000\007boolean\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025match-limit-recursion\376\001\000\000\007integer"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\003bsr\376\001\000\000\007boolean\376\377\016");
lf[43]=C_h_intern(&lf[43],20,"regex-chardef-table\077");
lf[44]=C_h_intern(&lf[44],24,"\003sysregex-chardef-table\077");
lf[46]=C_h_intern(&lf[46],23,"\003sysmake-tagged-pointer");
lf[47]=C_h_intern(&lf[47],13,"chardef-table");
lf[48]=C_h_intern(&lf[48],19,"regex-chardef-table");
lf[49]=C_h_intern(&lf[49],14,"set-finalizer!");
lf[51]=C_h_intern(&lf[51],5,"space");
lf[52]=C_h_intern(&lf[52],6,"xdigit");
lf[53]=C_h_intern(&lf[53],5,"digit");
lf[54]=C_h_intern(&lf[54],5,"upper");
lf[55]=C_h_intern(&lf[55],5,"lower");
lf[56]=C_h_intern(&lf[56],4,"word");
lf[57]=C_h_intern(&lf[57],5,"graph");
lf[58]=C_h_intern(&lf[58],5,"print");
lf[59]=C_h_intern(&lf[59],5,"punct");
lf[60]=C_h_intern(&lf[60],5,"cntrl");
lf[61]=C_h_intern(&lf[61],9,"pcre-cbit");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005space\376\003\000\000\002\376\001\000\000\006xdigit\376\003\000\000\002\376\001\000\000\005digit\376\003\000\000\002\376\001\000\000\005upper\376\003\000\000\002\376\001\000\000\005lower\376\003\000\000"
"\002\376\001\000\000\004word\376\003\000\000\002\376\001\000\000\005graph\376\003\000\000\002\376\001\000\000\005print\376\003\000\000\002\376\001\000\000\005punct\376\003\000\000\002\376\001\000\000\005cntrl\376\377\016");
lf[65]=C_h_intern(&lf[65],6,"letter");
lf[66]=C_h_intern(&lf[66],4,"meta");
lf[67]=C_h_intern(&lf[67],10,"pcre-ctype");
lf[71]=C_h_intern(&lf[71],12,"\003sysfor-each");
lf[75]=C_h_intern(&lf[75],18,"regex-chardef-set!");
lf[76]=C_h_intern(&lf[76],9,"\003syserror");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid chardef length - must be 4");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000,invalid character index - must be in [0 255]");
lf[79]=C_h_intern(&lf[79],23,"\003syscheck-chardef-table");
lf[80]=C_h_intern(&lf[80],22,"regex-chardefs-update!");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000%invalid chardefs length - must be 256");
lf[82]=C_h_intern(&lf[82],21,"regex-chardef-update!");
lf[83]=C_h_intern(&lf[83],14,"regex-chardefs");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005space\376\003\000\000\002\376\001\000\000\006xdigit\376\003\000\000\002\376\001\000\000\005digit\376\003\000\000\002\376\001\000\000\006letter\376\003\000\000\002\376\001\000\000\004word\376\003\000\000"
"\002\376\001\000\000\004meta\376\377\016");
lf[85]=C_h_intern(&lf[85],11,"make-vector");
lf[87]=C_h_intern(&lf[87],11,"match-limit");
lf[88]=C_h_intern(&lf[88],21,"match-limit-recursion");
lf[89]=C_h_intern(&lf[89],12,"callout-data");
lf[90]=C_h_intern(&lf[90],14,"\003syscheck-blob");
lf[91]=C_h_intern(&lf[91],6,"tables");
lf[92]=C_h_intern(&lf[92],7,"warning");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\034unrecognized extra field key");
lf[94]=C_h_intern(&lf[94],22,"regexp-extra-info-set!");
lf[95]=C_h_intern(&lf[95],6,"regexp");
lf[96]=C_h_intern(&lf[96],17,"regexp-extra-info");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\034unrecognized extra field key");
lf[98]=C_h_intern(&lf[98],7,"\003sysmap");
lf[99]=C_h_intern(&lf[99],19,"regexp-options-set!");
lf[100]=C_h_intern(&lf[100],14,"regexp-options");
lf[101]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010caseless\376\003\000\000\002\376\001\000\000\011multiline\376\003\000\000\002\376\001\000\000\006dotall\376\003\000\000\002\376\001\000\000\010extended\376\003\000\000\002\376\001\000\000"
"\010anchored\376\003\000\000\002\376\001\000\000\016dollar-endonly\376\003\000\000\002\376\001\000\000\005extra\376\003\000\000\002\376\001\000\000\006notbol\376\003\000\000\002\376\001\000\000\006noteol"
"\376\003\000\000\002\376\001\000\000\010ungreedy\376\003\000\000\002\376\001\000\000\010notempty\376\003\000\000\002\376\001\000\000\004utf8\376\003\000\000\002\376\001\000\000\017no-auto-capture\376\003\000\000\002"
"\376\001\000\000\015no-utf8-check\376\003\000\000\002\376\001\000\000\014auto-callout\376\003\000\000\002\376\001\000\000\007partial\376\003\000\000\002\376\001\000\000\014dfa-shortest\376"
"\003\000\000\002\376\001\000\000\013dfa-restart\376\003\000\000\002\376\001\000\000\011firstline\376\003\000\000\002\376\001\000\000\010dupnames\376\003\000\000\002\376\001\000\000\012newline-cr\376\003\000"
"\000\002\376\001\000\000\012newline-lf\376\003\000\000\002\376\001\000\000\014newline-crlf\376\003\000\000\002\376\001\000\000\013newline-any\376\003\000\000\002\376\001\000\000\017newline-an"
"ycrlf\376\003\000\000\002\376\001\000\000\013bsr-anycrlf\376\003\000\000\002\376\001\000\000\013bsr-unicode\376\377\016");
lf[102]=C_h_intern(&lf[102],15,"\003syssignal-hook");
lf[103]=C_h_intern(&lf[103],11,"\000type-error");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000Abad argument type - not an integer or compiled regular expression");
lf[105]=C_h_intern(&lf[105],11,"regexp-info");
lf[106]=C_h_intern(&lf[106],7,"boolean");
lf[107]=C_h_intern(&lf[107],12,"long-integer");
lf[108]=C_h_intern(&lf[108],7,"integer");
lf[109]=C_h_intern(&lf[109],7,"pointer");
lf[110]=C_h_intern(&lf[110],14,"default-tables");
lf[111]=C_h_intern(&lf[111],10,"firsttable");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\014unknown type");
lf[113]=C_h_intern(&lf[113],7,"options");
lf[114]=C_h_intern(&lf[114],4,"size");
lf[115]=C_h_intern(&lf[115],12,"capturecount");
lf[116]=C_h_intern(&lf[116],10,"backrefmax");
lf[117]=C_h_intern(&lf[117],9,"firstbyte");
lf[118]=C_h_intern(&lf[118],9,"firstchar");
lf[119]=C_h_intern(&lf[119],11,"lastliteral");
lf[120]=C_h_intern(&lf[120],13,"nameentrysize");
lf[121]=C_h_intern(&lf[121],9,"namecount");
lf[122]=C_h_intern(&lf[122],9,"nametable");
lf[123]=C_h_intern(&lf[123],9,"studysize");
lf[124]=C_h_intern(&lf[124],9,"okpartial");
lf[125]=C_h_intern(&lf[125],8,"jchanged");
lf[126]=C_h_intern(&lf[126],9,"hascrorlf");
lf[127]=C_h_intern(&lf[127],15,"pcre-info-field");
lf[128]=C_h_intern(&lf[128],9,"alist-ref");
lf[129]=C_h_intern(&lf[129],3,"eq\077");
lf[130]=C_h_intern(&lf[130],21,"regexp-info-nametable");
lf[131]=C_h_intern(&lf[131],17,"\003sysmake-locative");
lf[132]=C_h_intern(&lf[132],8,"location");
lf[133]=C_h_intern(&lf[133],23,"regex-build-config-info");
lf[134]=C_h_intern(&lf[134],7,"newline");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\014unknown type");
lf[136]=C_h_intern(&lf[136],9,"link-size");
lf[137]=C_h_intern(&lf[137],22,"posix-malloc-threshold");
lf[138]=C_h_intern(&lf[138],12,"stackrecurse");
lf[139]=C_h_intern(&lf[139],18,"unicode-properties");
lf[140]=C_h_intern(&lf[140],3,"bsr");
lf[141]=C_h_intern(&lf[141],17,"pcre-config-field");
lf[142]=C_h_intern(&lf[142],3,"car");
C_register_lf2(lf,143,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_619,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k617 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k620 in k617 */
static void C_ccall f_622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_622,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=*((C_word*)lf[1]+1);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_624,a[2]=t3,a[3]=t2,a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_642,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[36],lf[37]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[142]+1),lf[36]);}

/* k1256 in k620 in k617 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=C_mutate(&lf[38],t1);
t3=C_mutate(&lf[39],lf[40]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[142]+1),lf[39]);}

/* k1417 in k1256 in k620 in k617 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=C_mutate(&lf[41],t1);
t3=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[43]+1,*((C_word*)lf[44]+1));
t5=C_mutate(&lf[45],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1432,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[50],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[62],lf[63]);
t9=C_mutate(&lf[64],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1623,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[68],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1826,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[69],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1844,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[70],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[72],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1878,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[73],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[74],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1910,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2034,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2084,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[86],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[99]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2499,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2608,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2756,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[133]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2831,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t27=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,C_SCHEME_UNDEFINED);}

/* regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2831r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2831r(t0,t1,t2);}}

static void C_ccall f_2831r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2837,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(t2);
t5=(C_truep(t4)?lf[41]:t2);
/* map */
t6=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t3,t5);}

/* a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2837,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[133]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2848,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 799  alist-ref */
t5=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,lf[39],*((C_word*)lf[129]+1));}

/* k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_list(&a,1,t4):t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1270,a[2]=t8,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_1270(t10,t3,t6,C_fix(0));}
else{
t3=t2;
f_2851(2,t3,C_SCHEME_FALSE);}}

/* loop in k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1270,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1295,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t7)){
t8=t6;
f_1295(2,t8,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_UTF8));}
else{
t8=(C_word)C_eqp(t5,lf[134]);
if(C_truep(t8)){
t9=t6;
f_1295(2,t9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_NEWLINE));}
else{
t9=(C_word)C_eqp(t5,lf[136]);
if(C_truep(t9)){
t10=t6;
f_1295(2,t10,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_LINK_SIZE));}
else{
t10=(C_word)C_eqp(t5,lf[137]);
if(C_truep(t10)){
t11=t6;
f_1295(2,t11,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_POSIX_MALLOC_THRESHOLD));}
else{
t11=(C_word)C_eqp(t5,lf[87]);
if(C_truep(t11)){
t12=t6;
f_1295(2,t12,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_MATCH_LIMIT));}
else{
t12=(C_word)C_eqp(t5,lf[138]);
if(C_truep(t12)){
t13=t6;
f_1295(2,t13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_STACKRECURSE));}
else{
t13=(C_word)C_eqp(t5,lf[139]);
if(C_truep(t13)){
t14=t6;
f_1295(2,t14,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_UNICODE_PROPERTIES));}
else{
t14=(C_word)C_eqp(t5,lf[88]);
if(C_truep(t14)){
t15=t6;
f_1295(2,t15,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_MATCH_LIMIT_RECURSION));}
else{
t15=(C_word)C_eqp(t5,lf[140]);
if(C_truep(t15)){
t16=t6;
f_1295(2,t16,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_BSR));}
else{
/* regex-extras.scm: 241  error */
t16=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t6,lf[34],t5,lf[141]);}}}}}}}}}}}

/* k1293 in loop in k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1295,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 241  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1270(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2852 in k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[106]);
if(C_truep(t2)){
t3=t1;
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=((C_word*)t0)[3];
f_2851(2,t5,(C_word)stub548(C_SCHEME_UNDEFINED,t4));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[108]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=(C_word)stub544(C_SCHEME_UNDEFINED,t5);
t7=(C_word)C_eqp(lf[134],((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
f_2851(2,t8,(C_truep(t7)?(C_word)C_make_character((C_word)C_unfix(t6)):t6));}
else{
/* regex-extras.scm: 810  ##sys#error */
t4=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[133],lf[135],((C_word*)t0)[4]);}}}

/* k2849 in k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2756,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[95],lf[130]);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_foreign_pointer_argumentp(t5);
t9=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t10=(C_word)stub500(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t13=(C_word)C_i_foreign_pointer_argumentp(t5);
t14=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t15=(C_word)stub508(t12,t13,t14);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2781,a[2]=t1,a[3]=t15,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 767  set-finalizer! */
t17=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t16,t15,lf[42]);}}

/* k2779 in regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2786(t5,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in k2779 in regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2786,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2796,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2815,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#make-locative */
t8=*((C_word*)lf[131]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t7,t5,C_fix(0),C_SCHEME_FALSE,lf[132]);}}

/* k2813 in loop in k2779 in regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[3]);
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t1)?(C_word)C_i_foreign_pointer_argumentp(t1):C_SCHEME_FALSE);
t7=(C_word)stub518(t3,t4,t5,t6);
/* ##sys#peek-nonnull-c-string */
t8=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t7,C_fix(0));}

/* k2794 in loop in k2779 in regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[6],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[5]))));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* regex-extras.scm: 773  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2786(t5,((C_word*)t0)[2],t2,t4);}

/* regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2608r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2608r(t0,t1,t2,t3);}}

static void C_ccall f_2608r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[95],lf[105]);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2623,a[2]=t8,a[3]=t6,a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_nullp(t3);
t11=(C_truep(t10)?lf[38]:t3);
/* map */
t12=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,t9,t11);}

/* a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2623,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[105]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 679  alist-ref */
t5=*((C_word*)lf[128]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,lf[36],*((C_word*)lf[129]+1));}

/* k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_list(&a,1,t4):t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1025,a[2]=t8,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_1025(t10,t3,t6,C_fix(0));}
else{
t3=t2;
f_2637(2,t3,C_SCHEME_FALSE);}}

/* loop in k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1025(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1025,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1050,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[113]);
if(C_truep(t7)){
t8=t6;
f_1050(2,t8,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_OPTIONS));}
else{
t8=(C_word)C_eqp(t5,lf[114]);
if(C_truep(t8)){
t9=t6;
f_1050(2,t9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_SIZE));}
else{
t9=(C_word)C_eqp(t5,lf[115]);
if(C_truep(t9)){
t10=t6;
f_1050(2,t10,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_CAPTURECOUNT));}
else{
t10=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t10)){
t11=t6;
f_1050(2,t11,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_BACKREFMAX));}
else{
t11=(C_word)C_eqp(t5,lf[117]);
if(C_truep(t11)){
t12=t6;
f_1050(2,t12,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_FIRSTBYTE));}
else{
t12=(C_word)C_eqp(t5,lf[118]);
if(C_truep(t12)){
t13=t6;
f_1050(2,t13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_FIRSTCHAR));}
else{
t13=(C_word)C_eqp(t5,lf[111]);
if(C_truep(t13)){
t14=t6;
f_1050(2,t14,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_FIRSTTABLE));}
else{
t14=(C_word)C_eqp(t5,lf[119]);
if(C_truep(t14)){
t15=t6;
f_1050(2,t15,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_LASTLITERAL));}
else{
t15=(C_word)C_eqp(t5,lf[120]);
if(C_truep(t15)){
t16=t6;
f_1050(2,t16,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_NAMEENTRYSIZE));}
else{
t16=(C_word)C_eqp(t5,lf[121]);
if(C_truep(t16)){
t17=t6;
f_1050(2,t17,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_NAMECOUNT));}
else{
t17=(C_word)C_eqp(t5,lf[122]);
if(C_truep(t17)){
t18=t6;
f_1050(2,t18,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_NAMETABLE));}
else{
t18=(C_word)C_eqp(t5,lf[123]);
if(C_truep(t18)){
t19=t6;
f_1050(2,t19,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_STUDYSIZE));}
else{
t19=(C_word)C_eqp(t5,lf[110]);
if(C_truep(t19)){
t20=t6;
f_1050(2,t20,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_DEFAULT_TABLES));}
else{
t20=(C_word)C_eqp(t5,lf[124]);
if(C_truep(t20)){
t21=t6;
f_1050(2,t21,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_OKPARTIAL));}
else{
t21=(C_word)C_eqp(t5,lf[125]);
if(C_truep(t21)){
t22=t6;
f_1050(2,t22,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_JCHANGED));}
else{
t22=(C_word)C_eqp(t5,lf[126]);
if(C_truep(t22)){
t23=t6;
f_1050(2,t23,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_HASCRORLF));}
else{
/* regex-extras.scm: 203  error */
t23=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t23+1)))(5,t23,t6,lf[34],t5,lf[127]);}}}}}}}}}}}}}}}}}}

/* k1048 in loop in k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 203  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1025(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2638 in k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[106]);
if(C_truep(t2)){
t3=t1;
t4=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[5]);
t5=(C_truep(((C_word*)t0)[4])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[4]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=((C_word*)t0)[3];
f_2637(2,t7,(C_word)stub462(C_SCHEME_UNDEFINED,t4,t5,t6));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[107]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t6=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[5]);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[4]):C_SCHEME_FALSE);
t8=(C_word)C_i_foreign_fixnum_argumentp(t4);
t9=((C_word*)t0)[3];
f_2637(2,t9,(C_word)stub441(t5,t6,t7,t8));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[108]);
if(C_truep(t4)){
t5=t1;
t6=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[5]);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[4]):C_SCHEME_FALSE);
t8=(C_word)C_i_foreign_fixnum_argumentp(t5);
t9=((C_word*)t0)[3];
f_2637(2,t9,(C_word)stub452(C_SCHEME_UNDEFINED,t6,t7,t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[109]);
if(C_truep(t5)){
t6=t1;
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[5]);
t9=(C_truep(((C_word*)t0)[4])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[4]):C_SCHEME_FALSE);
t10=(C_word)C_i_foreign_fixnum_argumentp(t6);
t11=(C_word)stub472(t7,t8,t9,t10);
if(C_truep(t11)){
t12=((C_word*)t0)[2];
t13=(C_word)C_eqp(t12,lf[110]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t12,lf[111]));
if(C_truep(t14)){
/* regex-extras.scm: 692  re-chardef-table */
f_1432(((C_word*)t0)[3],t11);}
else{
t15=((C_word*)t0)[3];
f_2637(2,t15,t11);}}
else{
t12=((C_word*)t0)[3];
f_2637(2,t12,C_SCHEME_FALSE);}}
else{
/* regex-extras.scm: 696  ##sys#error */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[3],lf[105],lf[112],((C_word*)t0)[6]);}}}}}

/* k2635 in k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2511,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
if(C_truep((C_word)C_i_structurep(t4,lf[95]))){
t5=t2;
t6=t3;
f_2519(2,t6,(C_word)C_slot(t5,C_fix(3)));}
else{
if(C_truep((C_word)C_i_integerp(t2))){
t5=t3;
f_2519(2,t5,t2);}
else{
/* regex-extras.scm: 637  ##sys#signal-hook */
t5=*((C_word*)lf[102]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,lf[103],lf[100],lf[104],t2);}}}

/* k2517 in regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2476,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2478,a[2]=t4,a[3]=t1,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,lf[101]);}

/* a2477 in k2517 in regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2478,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 619  pcre-option->number */
f_642(t3,t2);}

/* k2495 in a2477 in k2517 in regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_and(&a,2,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2474 in k2517 in regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* regexp-options-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2499r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2499r(t0,t1,t2,t3);}}

static void C_ccall f_2499r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_structure_2(t2,lf[95],lf[99]);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2506,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 628  pcre-option->number */
f_642(t6,t3);}

/* k2504 in regexp-options-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(3),t1));}

/* regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2444r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2444r(t0,t1,t2,t3);}}

static void C_ccall f_2444r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_structure_2(t2,lf[95],lf[96]);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=t6,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* map */
t8=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_END_OF_LIST);}}

/* a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2459,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2470,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[87]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t4,((C_word*)t0)[2]);}
else{
t7=(C_word)C_eqp(t5,lf[88]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t4,((C_word*)t0)[2]);}
else{
t8=(C_word)C_eqp(t5,lf[89]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2345,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t4,((C_word*)t0)[2]);}
else{
t9=(C_word)C_eqp(t5,lf[91]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2367,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t0)[2]);}
else{
/* regex-extras.scm: 574  warning */
t10=*((C_word*)lf[92]+1);
((C_proc5)C_retrieve_proc(t10))(5,t10,t4,lf[96],lf[97],t5);}}}}}

/* f_2368 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2368,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_pointer_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub392(t4,t5,t6));}

/* k2365 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex-extras.scm: 569  re-chardef-table */
f_1432(((C_word*)t0)[2],t1);}

/* f_2345 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2345,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_pointer_argumentp(t2);
t6=(C_word)C_i_foreign_block_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub385(t4,t5,t6));}

/* f_2326 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2326,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub379(C_SCHEME_UNDEFINED,t4,t5));}

/* f_2307 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2307,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub373(C_SCHEME_UNDEFINED,t4,t5));}

/* k2468 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* regexp-extra-info-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2416r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2416r(t0,t1,t2,t3);}}

static void C_ccall f_2416r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(14);
t4=(C_word)C_i_check_structure_2(t2,lf[95],lf[94]);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2430,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
t8=t7;
f_2430(t8,t6);}
else{
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t9=(C_word)stub327(t8);
t10=t2;
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2436,a[2]=t7,a[3]=t9,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
/* set-finalizer! */
t12=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t9,lf[42]);}
else{
t12=t11;
f_2436(2,t12,C_SCHEME_UNDEFINED);}}}

/* k2434 in regexp-extra-info-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2430(t3,((C_word*)t0)[3]);}

/* k2428 in regexp-extra-info-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[3],lf[86],lf[94],t1,((C_word*)t0)[2]);}

/* re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2385r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2385r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2385r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2391,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=((C_word)li31),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2391(t8,t1,t4);}

/* loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2391(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2391,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2407,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_eqp(t3,lf[87]);
if(C_truep(t8)){
t9=(C_word)C_i_check_exact_2(*((C_word*)lf[87]+1),t6);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t5,t7,t4);}
else{
t9=(C_word)C_eqp(t3,lf[88]);
if(C_truep(t9)){
t10=(C_word)C_i_check_exact_2(*((C_word*)lf[88]+1),t6);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t5,t7,t4);}
else{
t10=(C_word)C_eqp(t3,lf[89]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2253,a[2]=t4,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 538  ##sys#check-blob */
t12=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[89]+1),t6);}
else{
t11=(C_word)C_eqp(t3,lf[91]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2275,a[2]=t4,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 544  ##sys#check-chardef-table */
t13=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,*((C_word*)lf[91]+1),t6);}
else{
/* regex-extras.scm: 550  warning */
t12=*((C_word*)lf[92]+1);
((C_proc5)C_retrieve_proc(t12))(5,t12,t5,t6,lf[93],t3);}}}}}}

/* k2273 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_2279 in k2273 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2279,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub359(C_SCHEME_UNDEFINED,t4,t5));}

/* k2251 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_2257 in k2251 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2257,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_block_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub352(C_SCHEME_UNDEFINED,t4,t5));}

/* f_2235 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2235,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub345(C_SCHEME_UNDEFINED,t4,t5));}

/* f_2213 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2213,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub338(C_SCHEME_UNDEFINED,t4,t5));}

/* k2405 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* regex-extras.scm: 584  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2391(t3,((C_word*)t0)[2],t2);}

/* regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2084,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2088,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 472  ##sys#check-chardef-table */
t4=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[83]);}

/* k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 474  make-vector */
t3=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2096,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word)li25),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2096(t5,((C_word*)t0)[2],C_fix(0));}

/* do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2096(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2096,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_fix(256),t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,4,t4,t4,t4,t4);
t6=(C_word)C_i_vector_set(((C_word*)t0)[4],t2,t5);
t7=((C_word*)t0)[3];
t8=t2;
t9=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t10=(C_word)C_i_foreign_fixnum_argumentp(t8);
t11=(C_word)stub185(C_SCHEME_UNDEFINED,t9,t10);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_i_vector_set(t5,C_fix(0),t12);
t14=((C_word*)t0)[3];
t15=t2;
t16=(C_truep(t14)?(C_word)C_i_foreign_pointer_argumentp(t14):C_SCHEME_FALSE);
t17=(C_word)C_i_foreign_fixnum_argumentp(t15);
t18=(C_word)stub203(C_SCHEME_UNDEFINED,t16,t17);
t19=(C_word)C_make_character((C_word)C_unfix(t18));
t20=(C_word)C_i_vector_set(t5,C_fix(1),t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2116,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp);
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2178,a[2]=t21,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* regex-extras.scm: 498  get-symbols */
t23=t21;
f_2116(t23,t22,lf[62],lf[69],lf[50]);}}

/* k2176 in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[6],C_fix(2),t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 500  get-symbols */
t4=((C_word*)t0)[2];
f_2116(t4,t3,lf[84],lf[74],lf[64]);}

/* k2172 in k2176 in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_vector_set(((C_word*)t0)[5],C_fix(3),t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2096(t4,((C_word*)t0)[2],t3);}

/* get-symbols in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2116(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2116,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2122,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t6,a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_2122(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in get-symbols in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2122(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2122,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2153,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 494  sym->num */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}

/* k2155 in loop in get-symbols in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex-extras.scm: 494  get */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2151 in loop in get-symbols in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
t3=(C_truep(t2)?((C_word*)t0)[6]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]));
/* regex-extras.scm: 493  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2122(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2034,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2038,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 455  ##sys#check-chardef-table */
t5=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[82]);}

/* k2036 in regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[4],lf[80]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t5=(C_word)C_eqp(C_fix(256),t4);
if(C_truep(t5)){
t6=t3;
f_2044(2,t6,C_SCHEME_UNDEFINED);}
else{
/* regex-extras.scm: 459  ##sys#error */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[80],lf[81],((C_word*)t0)[4]);}}

/* k2042 in k2036 in regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li21),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2049(t5,((C_word*)t0)[2],C_fix(0));}

/* do296 in k2042 in k2036 in regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2049,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_fix(256),t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2062,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
/* regex-extras.scm: 465  regex-chardef-set! */
t6=*((C_word*)lf[75]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,t4);}
else{
t6=t5;
f_2062(2,t6,C_SCHEME_FALSE);}}}

/* k2060 in do296 in k2042 in k2036 in regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2049(t3,((C_word*)t0)[2],t2);}

/* regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1928,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1932,a[2]=t1,a[3]=t2,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 415  ##sys#check-chardef-table */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[75]);}

/* k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1932,2,t0,t1);}
t2=(C_word)C_charp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5])):((C_word*)t0)[5]);
t4=(C_word)C_i_check_exact_2(t3,lf[75]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_less_or_equal_p(C_fix(0),t3);
t7=(C_truep(t6)?(C_word)C_fixnum_less_or_equal_p(t3,C_fix(255)):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t5;
f_1941(2,t8,C_SCHEME_UNDEFINED);}
else{
/* regex-extras.scm: 421  ##sys#error */
t8=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[75],lf[78],t3);}}

/* k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[5],lf[75]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_vector_length(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_fix(4),t4);
if(C_truep(t5)){
t6=t3;
f_1947(2,t6,C_SCHEME_UNDEFINED);}
else{
/* regex-extras.scm: 425  ##sys#error */
t6=*((C_word*)lf[76]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[75],lf[77],((C_word*)t0)[5]);}}

/* k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[4];
t5=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t7=(C_word)C_i_foreign_char_argumentp(t2);
t8=t3;
f_1953(t8,(C_word)stub176(C_SCHEME_UNDEFINED,t5,t6,t7));}
else{
t4=t3;
f_1953(t4,C_SCHEME_FALSE);}}

/* k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1953,NULL,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[4];
t5=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t7=(C_word)C_i_foreign_char_argumentp(t2);
t8=t3;
f_1959(t8,(C_word)stub194(C_SCHEME_UNDEFINED,t5,t6,t7));}
else{
t4=t3;
f_1959(t4,C_SCHEME_FALSE);}}

/* k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1959,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex-extras.scm: 443  set-symbols */
t5=t2;
f_1960(t5,t4,t3,lf[70],lf[50],lf[68]);}
else{
t5=t4;
f_1986(2,t5,C_SCHEME_FALSE);}}

/* k1984 in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(3));
if(C_truep(t2)){
/* regex-extras.scm: 446  set-symbols */
t3=((C_word*)t0)[3];
f_1960(t3,((C_word*)t0)[2],t2,lf[72],lf[64],lf[73]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* set-symbols in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1960(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1960,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_list_2(t2,lf[75]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1967,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* regex-extras.scm: 436  clear */
t8=t3;
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1965 in set-symbols in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li18),tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a1971 in k1965 in set-symbols in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1972,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 439  sym->num */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1978 in a1971 in k1965 in set-symbols in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex-extras.scm: 439  set */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chardef-type in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1910,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub263(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* chardef-type-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1892,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub253(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* chardef-type-clear! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1878,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub244(C_SCHEME_UNDEFINED,t4,t5));}

/* chardef-classes-clear! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1862,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1868,a[2]=t3,a[3]=t2,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t5=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,lf[62]);}

/* a1867 in chardef-classes-clear! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1868,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 389  pcre-cbit->number */
t4=lf[50];
f_1454(3,t4,t3,t2);}

/* k1874 in a1867 in chardef-classes-clear! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t1);
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub212(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* chardef-class in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1844,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub232(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* chardef-class-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1826,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub222(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* pcre-ctype->number in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1623,3,t0,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1633,a[2]=t6,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1633(t8,t1,t4,C_fix(0));}

/* loop in pcre-ctype->number in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1633,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1658,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[51]);
if(C_truep(t7)){
t8=t6;
f_1658(2,t8,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_space));}
else{
t8=(C_word)C_eqp(t5,lf[65]);
if(C_truep(t8)){
t9=t6;
f_1658(2,t9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_letter));}
else{
t9=(C_word)C_eqp(t5,lf[53]);
if(C_truep(t9)){
t10=t6;
f_1658(2,t10,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_digit));}
else{
t10=(C_word)C_eqp(t5,lf[52]);
if(C_truep(t10)){
t11=t6;
f_1658(2,t11,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_xdigit));}
else{
t11=(C_word)C_eqp(t5,lf[56]);
if(C_truep(t11)){
t12=t6;
f_1658(2,t12,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_word));}
else{
t12=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t12)){
t13=t6;
f_1658(2,t13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_meta));}
else{
/* regex-extras.scm: 346  error */
t13=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t6,lf[34],t5,lf[67]);}}}}}}}}

/* k1656 in loop in pcre-ctype->number in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 346  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1633(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* pcre-cbit->number in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1454,3,t0,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1464,a[2]=t6,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1464(t8,t1,t4,C_fix(0));}

/* loop in pcre-cbit->number in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1464(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1464,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1489,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[51]);
if(C_truep(t7)){
t8=t6;
f_1489(2,t8,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_space));}
else{
t8=(C_word)C_eqp(t5,lf[52]);
if(C_truep(t8)){
t9=t6;
f_1489(2,t9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_xdigit));}
else{
t9=(C_word)C_eqp(t5,lf[53]);
if(C_truep(t9)){
t10=t6;
f_1489(2,t10,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_digit));}
else{
t10=(C_word)C_eqp(t5,lf[54]);
if(C_truep(t10)){
t11=t6;
f_1489(2,t11,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_upper));}
else{
t11=(C_word)C_eqp(t5,lf[55]);
if(C_truep(t11)){
t12=t6;
f_1489(2,t12,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_lower));}
else{
t12=(C_word)C_eqp(t5,lf[56]);
if(C_truep(t12)){
t13=t6;
f_1489(2,t13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_word));}
else{
t13=(C_word)C_eqp(t5,lf[57]);
if(C_truep(t13)){
t14=t6;
f_1489(2,t14,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_graph));}
else{
t14=(C_word)C_eqp(t5,lf[58]);
if(C_truep(t14)){
t15=t6;
f_1489(2,t15,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_print));}
else{
t15=(C_word)C_eqp(t5,lf[59]);
if(C_truep(t15)){
t16=t6;
f_1489(2,t16,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_punct));}
else{
t16=(C_word)C_eqp(t5,lf[60]);
if(C_truep(t16)){
t17=t6;
f_1489(2,t17,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_cntrl));}
else{
/* regex-extras.scm: 330  error */
t17=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t6,lf[34],t5,lf[61]);}}}}}}}}}}}}

/* k1487 in loop in pcre-cbit->number in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 330  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1464(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* regex-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)stub124(t3);
/* regex-extras.scm: 324  re-chardef-table */
f_1432(t2,t4);}

/* k1443 in regex-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1448,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 325  set-finalizer! */
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[42]);}

/* k1446 in k1443 in regex-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* re-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1432(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1432,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1436,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#make-tagged-pointer */
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[47]);}

/* k1434 in re-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_pointer(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* re-finalizer in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1421,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub105(C_SCHEME_UNDEFINED,t3));}

/* pcre-option->number in k620 in k617 */
static void C_fcall f_642(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_642,NULL,2,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_652,a[2]=t6,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_652(t8,t1,t4,C_fix(0));}

/* loop in pcre-option->number in k620 in k617 */
static void C_fcall f_652(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_652,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_677,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[6]);
if(C_truep(t7)){
t8=t6;
f_677(2,t8,C_unsigned_int_to_num(&a,PCRE_CASELESS));}
else{
t8=(C_word)C_eqp(t5,lf[7]);
if(C_truep(t8)){
t9=t6;
f_677(2,t9,C_unsigned_int_to_num(&a,PCRE_MULTILINE));}
else{
t9=(C_word)C_eqp(t5,lf[8]);
if(C_truep(t9)){
t10=t6;
f_677(2,t10,C_unsigned_int_to_num(&a,PCRE_DOTALL));}
else{
t10=(C_word)C_eqp(t5,lf[9]);
if(C_truep(t10)){
t11=t6;
f_677(2,t11,C_unsigned_int_to_num(&a,PCRE_EXTENDED));}
else{
t11=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t11)){
t12=t6;
f_677(2,t12,C_unsigned_int_to_num(&a,PCRE_ANCHORED));}
else{
t12=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t12)){
t13=t6;
f_677(2,t13,C_unsigned_int_to_num(&a,PCRE_DOLLAR_ENDONLY));}
else{
t13=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t13)){
t14=t6;
f_677(2,t14,C_unsigned_int_to_num(&a,PCRE_EXTRA));}
else{
t14=(C_word)C_eqp(t5,lf[13]);
if(C_truep(t14)){
t15=t6;
f_677(2,t15,C_unsigned_int_to_num(&a,PCRE_NOTBOL));}
else{
t15=(C_word)C_eqp(t5,lf[14]);
if(C_truep(t15)){
t16=t6;
f_677(2,t16,C_unsigned_int_to_num(&a,PCRE_NOTEOL));}
else{
t16=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t16)){
t17=t6;
f_677(2,t17,C_unsigned_int_to_num(&a,PCRE_UNGREEDY));}
else{
t17=(C_word)C_eqp(t5,lf[16]);
if(C_truep(t17)){
t18=t6;
f_677(2,t18,C_unsigned_int_to_num(&a,PCRE_NOTEMPTY));}
else{
t18=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t18)){
t19=t6;
f_677(2,t19,C_unsigned_int_to_num(&a,PCRE_UTF8));}
else{
t19=(C_word)C_eqp(t5,lf[18]);
if(C_truep(t19)){
t20=t6;
f_677(2,t20,C_unsigned_int_to_num(&a,PCRE_NO_AUTO_CAPTURE));}
else{
t20=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t20)){
t21=t6;
f_677(2,t21,C_unsigned_int_to_num(&a,PCRE_NO_UTF8_CHECK));}
else{
t21=(C_word)C_eqp(t5,lf[20]);
if(C_truep(t21)){
t22=t6;
f_677(2,t22,C_unsigned_int_to_num(&a,PCRE_AUTO_CALLOUT));}
else{
t22=(C_word)C_eqp(t5,lf[21]);
if(C_truep(t22)){
t23=t6;
f_677(2,t23,C_unsigned_int_to_num(&a,PCRE_PARTIAL));}
else{
t23=(C_word)C_eqp(t5,lf[22]);
if(C_truep(t23)){
t24=t6;
f_677(2,t24,C_unsigned_int_to_num(&a,PCRE_DFA_SHORTEST));}
else{
t24=(C_word)C_eqp(t5,lf[23]);
if(C_truep(t24)){
t25=t6;
f_677(2,t25,C_unsigned_int_to_num(&a,PCRE_DFA_RESTART));}
else{
t25=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t25)){
t26=t6;
f_677(2,t26,C_unsigned_int_to_num(&a,PCRE_FIRSTLINE));}
else{
t26=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t26)){
t27=t6;
f_677(2,t27,C_unsigned_int_to_num(&a,PCRE_DUPNAMES));}
else{
t27=(C_word)C_eqp(t5,lf[26]);
if(C_truep(t27)){
t28=t6;
f_677(2,t28,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CR));}
else{
t28=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t28)){
t29=t6;
f_677(2,t29,C_unsigned_int_to_num(&a,PCRE_NEWLINE_LF));}
else{
t29=(C_word)C_eqp(t5,lf[28]);
if(C_truep(t29)){
t30=t6;
f_677(2,t30,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CRLF));}
else{
t30=(C_word)C_eqp(t5,lf[29]);
if(C_truep(t30)){
t31=t6;
f_677(2,t31,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANY));}
else{
t31=(C_word)C_eqp(t5,lf[30]);
if(C_truep(t31)){
t32=t6;
f_677(2,t32,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANYCRLF));}
else{
t32=(C_word)C_eqp(t5,lf[31]);
if(C_truep(t32)){
t33=t6;
f_677(2,t33,C_unsigned_int_to_num(&a,PCRE_BSR_ANYCRLF));}
else{
t33=(C_word)C_eqp(t5,lf[32]);
if(C_truep(t33)){
t34=t6;
f_677(2,t34,C_unsigned_int_to_num(&a,PCRE_BSR_UNICODE));}
else{
/* regex-extras.scm: 145  error */
t34=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t34+1)))(5,t34,t6,lf[34],t5,lf[35]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k675 in loop in pcre-option->number in k620 in k617 */
static void C_ccall f_677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_677,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 145  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_652(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* regex-version in k620 in k617 */
static void C_ccall f_624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_628,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_636,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_636 in regex-version in k620 in k617 */
static void C_ccall f_636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_636,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub7(t2),C_fix(0));}

/* k626 in regex-version in k620 in k617 */
static void C_ccall f_628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_635,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 132  substring-index */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[3],t1);}

/* k633 in k626 in regex-version in k620 in k617 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex-extras.scm: 132  substring */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[105] = {
{"toplevelregex-extras.scm",(void*)C_regex_extras_toplevel},
{"f_619regex-extras.scm",(void*)f_619},
{"f_622regex-extras.scm",(void*)f_622},
{"f_1258regex-extras.scm",(void*)f_1258},
{"f_1419regex-extras.scm",(void*)f_1419},
{"f_2831regex-extras.scm",(void*)f_2831},
{"f_2837regex-extras.scm",(void*)f_2837},
{"f_2848regex-extras.scm",(void*)f_2848},
{"f_1270regex-extras.scm",(void*)f_1270},
{"f_1295regex-extras.scm",(void*)f_1295},
{"f_2854regex-extras.scm",(void*)f_2854},
{"f_2851regex-extras.scm",(void*)f_2851},
{"f_2756regex-extras.scm",(void*)f_2756},
{"f_2781regex-extras.scm",(void*)f_2781},
{"f_2786regex-extras.scm",(void*)f_2786},
{"f_2815regex-extras.scm",(void*)f_2815},
{"f_2796regex-extras.scm",(void*)f_2796},
{"f_2608regex-extras.scm",(void*)f_2608},
{"f_2623regex-extras.scm",(void*)f_2623},
{"f_2634regex-extras.scm",(void*)f_2634},
{"f_1025regex-extras.scm",(void*)f_1025},
{"f_1050regex-extras.scm",(void*)f_1050},
{"f_2640regex-extras.scm",(void*)f_2640},
{"f_2637regex-extras.scm",(void*)f_2637},
{"f_2511regex-extras.scm",(void*)f_2511},
{"f_2519regex-extras.scm",(void*)f_2519},
{"f_2478regex-extras.scm",(void*)f_2478},
{"f_2497regex-extras.scm",(void*)f_2497},
{"f_2476regex-extras.scm",(void*)f_2476},
{"f_2499regex-extras.scm",(void*)f_2499},
{"f_2506regex-extras.scm",(void*)f_2506},
{"f_2444regex-extras.scm",(void*)f_2444},
{"f_2459regex-extras.scm",(void*)f_2459},
{"f_2368regex-extras.scm",(void*)f_2368},
{"f_2367regex-extras.scm",(void*)f_2367},
{"f_2345regex-extras.scm",(void*)f_2345},
{"f_2326regex-extras.scm",(void*)f_2326},
{"f_2307regex-extras.scm",(void*)f_2307},
{"f_2470regex-extras.scm",(void*)f_2470},
{"f_2416regex-extras.scm",(void*)f_2416},
{"f_2436regex-extras.scm",(void*)f_2436},
{"f_2430regex-extras.scm",(void*)f_2430},
{"f_2385regex-extras.scm",(void*)f_2385},
{"f_2391regex-extras.scm",(void*)f_2391},
{"f_2275regex-extras.scm",(void*)f_2275},
{"f_2279regex-extras.scm",(void*)f_2279},
{"f_2253regex-extras.scm",(void*)f_2253},
{"f_2257regex-extras.scm",(void*)f_2257},
{"f_2235regex-extras.scm",(void*)f_2235},
{"f_2213regex-extras.scm",(void*)f_2213},
{"f_2407regex-extras.scm",(void*)f_2407},
{"f_2084regex-extras.scm",(void*)f_2084},
{"f_2088regex-extras.scm",(void*)f_2088},
{"f_2091regex-extras.scm",(void*)f_2091},
{"f_2096regex-extras.scm",(void*)f_2096},
{"f_2178regex-extras.scm",(void*)f_2178},
{"f_2174regex-extras.scm",(void*)f_2174},
{"f_2116regex-extras.scm",(void*)f_2116},
{"f_2122regex-extras.scm",(void*)f_2122},
{"f_2157regex-extras.scm",(void*)f_2157},
{"f_2153regex-extras.scm",(void*)f_2153},
{"f_2034regex-extras.scm",(void*)f_2034},
{"f_2038regex-extras.scm",(void*)f_2038},
{"f_2044regex-extras.scm",(void*)f_2044},
{"f_2049regex-extras.scm",(void*)f_2049},
{"f_2062regex-extras.scm",(void*)f_2062},
{"f_1928regex-extras.scm",(void*)f_1928},
{"f_1932regex-extras.scm",(void*)f_1932},
{"f_1941regex-extras.scm",(void*)f_1941},
{"f_1947regex-extras.scm",(void*)f_1947},
{"f_1953regex-extras.scm",(void*)f_1953},
{"f_1959regex-extras.scm",(void*)f_1959},
{"f_1986regex-extras.scm",(void*)f_1986},
{"f_1960regex-extras.scm",(void*)f_1960},
{"f_1967regex-extras.scm",(void*)f_1967},
{"f_1972regex-extras.scm",(void*)f_1972},
{"f_1980regex-extras.scm",(void*)f_1980},
{"f_1910regex-extras.scm",(void*)f_1910},
{"f_1892regex-extras.scm",(void*)f_1892},
{"f_1878regex-extras.scm",(void*)f_1878},
{"f_1862regex-extras.scm",(void*)f_1862},
{"f_1868regex-extras.scm",(void*)f_1868},
{"f_1876regex-extras.scm",(void*)f_1876},
{"f_1844regex-extras.scm",(void*)f_1844},
{"f_1826regex-extras.scm",(void*)f_1826},
{"f_1623regex-extras.scm",(void*)f_1623},
{"f_1633regex-extras.scm",(void*)f_1633},
{"f_1658regex-extras.scm",(void*)f_1658},
{"f_1454regex-extras.scm",(void*)f_1454},
{"f_1464regex-extras.scm",(void*)f_1464},
{"f_1489regex-extras.scm",(void*)f_1489},
{"f_1441regex-extras.scm",(void*)f_1441},
{"f_1445regex-extras.scm",(void*)f_1445},
{"f_1448regex-extras.scm",(void*)f_1448},
{"f_1432regex-extras.scm",(void*)f_1432},
{"f_1436regex-extras.scm",(void*)f_1436},
{"f_1421regex-extras.scm",(void*)f_1421},
{"f_642regex-extras.scm",(void*)f_642},
{"f_652regex-extras.scm",(void*)f_652},
{"f_677regex-extras.scm",(void*)f_677},
{"f_624regex-extras.scm",(void*)f_624},
{"f_636regex-extras.scm",(void*)f_636},
{"f_628regex-extras.scm",(void*)f_628},
{"f_635regex-extras.scm",(void*)f_635},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
