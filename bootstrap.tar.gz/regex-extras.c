/* Generated from regex-extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2007-10-25 22:02
   Version 2.713 - macosx-unix-gnu-ppc - [ manyargs dload ptables applyhook ]
(c)2000-2007 Felix L. Winkelmann | compiled 2007-09-29 on o3184.o.pppool.de (Darwin)
   command line: regex-extras.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file regex-extras.c
   unit: regex_extras
*/

#include "chicken.h"

static void
out_of_memory_failure(const char *modnam, const char *prcnam, const char *typnam)
{
  fprintf(stderr, "%s@%s: out of memory - cannot allocate %s\\n", modnam, prcnam, typnam);
  exit(EXIT_FAILURE);
}
#include "pcre/pcre.h"
#include "pcre/pcre_internal.h"

typedef struct {
  char *nametable;
  int entrysize;
} pcre_nametable;

static int
get_nametable_entrycount(const pcre *code, const pcre_extra *extra)
{
  int val;
  pcre_fullinfo(code, extra, PCRE_INFO_NAMECOUNT, &val);
  return val;
}

static pcre_nametable *
get_nametable(const pcre *code, const pcre_extra *extra)
{
  pcre_nametable *nametable = (pcre_nametable *)(pcre_malloc)(sizeof(pcre_nametable));
  if (!nametable) out_of_memory_failure("regex-extras", "get_nametable", "pcre_nametable");
  pcre_fullinfo(code, extra, PCRE_INFO_NAMETABLE, &nametable->nametable);
  pcre_fullinfo(code, extra, PCRE_INFO_NAMEENTRYSIZE, &nametable->entrysize);
  return nametable;
}

static char *
get_nametable_entry(const pcre_nametable *nt, int idx, int *pcc)
{
  typedef struct {
    uint16_t cc;
    char name[1];
  } pcre_nametable_entry;

  pcre_nametable_entry *entry = ((pcre_nametable_entry *)(nt->nametable)) + (idx * nt->entrysize);
  /* Number of capturing parentheses is MSB */
# ifdef C_LITTLE_ENDIAN
  uint16_t cc;
  ((uint8_t *)&cc)[0] = ((uint8_t *)&entry->cc)[1];
  ((uint8_t *)&cc)[1] = ((uint8_t *)&entry->cc)[0];
  *pcc = cc;
# else
  *pcc = entry->cc;
# endif
  return entry->name;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[195];


/* from k2827 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub548(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub548(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fieldno=(int )C_unfix(C_a0);
int val;pcre_config(fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2820 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub544(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub544(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fieldno=(int )C_unfix(C_a0);
int val;pcre_config(fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2749 */
static C_word C_fcall stub518(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub518(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre_nametable *t0=(const pcre_nametable *)C_c_pointer_nn(C_a0);
int t1=(int )C_unfix(C_a1);
int *t2=(int *)C_c_pointer_or_null(C_a2);
C_r=C_mpointer(&C_a,(void*)get_nametable_entry(t0,t1,t2));
return C_r;}

/* from k2727 */
static C_word C_fcall stub508(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub508(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *t0=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *t1=(const pcre_extra *)C_c_pointer_or_null(C_a1);
C_r=C_mpointer(&C_a,(void*)get_nametable(t0,t1));
return C_r;}

/* from k2713 */
static C_word C_fcall stub500(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub500(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *t0=(const pcre *)C_c_pointer_nn(C_a0);
const pcre_extra *t1=(const pcre_extra *)C_c_pointer_or_null(C_a1);
C_r=C_fix((C_word)get_nametable_entrycount(t0,t1));
return C_r;}

/* from k2601 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub472(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub472(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
pcre_extra *extra=(pcre_extra *)C_c_pointer_or_null(C_a1);
int fieldno=(int )C_unfix(C_a2);
void *val;pcre_fullinfo(code, extra, fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2583 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub462(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub462(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
pcre_extra *extra=(pcre_extra *)C_c_pointer_or_null(C_a1);
int fieldno=(int )C_unfix(C_a2);
int val;pcre_fullinfo(code, extra, fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2565 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub452(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub452(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
pcre_extra *extra=(pcre_extra *)C_c_pointer_or_null(C_a1);
int fieldno=(int )C_unfix(C_a2);
int val;pcre_fullinfo(code, extra, fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2547 */
#define return(x) C_cblock C_r = (C_long_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub441(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub441(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const pcre *code=(const pcre *)C_c_pointer_nn(C_a0);
pcre_extra *extra=(pcre_extra *)C_c_pointer_or_null(C_a1);
int fieldno=(int )C_unfix(C_a2);
long int val;pcre_fullinfo(code, extra, fieldno, &val);return(val);
C_ret:
#undef return

return C_r;}

/* from k2375 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub392(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub392(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
const unsigned C_char *val=(const unsigned C_char *)C_c_pointer_or_null(C_a1);
return(extra->tables);
C_ret:
#undef return

return C_r;}

/* from k2352 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub385(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub385(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned char * val=(unsigned char * )C_c_bytevector(C_a1);
return(extra->callout_data);
C_ret:
#undef return

return C_r;}

/* from k2333 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub379(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub379(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned long val=(unsigned long )C_num_to_unsigned_long(C_a1);
return(extra->match_limit_recursion);
C_ret:
#undef return

return C_r;}

/* from k2314 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub373(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub373(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned long val=(unsigned long )C_num_to_unsigned_long(C_a1);
return(extra->match_limit);
C_ret:
#undef return

return C_r;}

/* from k2286 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub359(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub359(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
const unsigned C_char *val=(const unsigned C_char *)C_c_pointer_or_null(C_a1);
extra->tables = val;extra->flags |= PCRE_EXTRA_TABLES;
C_ret:
#undef return

return C_r;}

/* from k2264 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub352(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub352(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned char * val=(unsigned char * )C_c_bytevector(C_a1);
extra->callout_data = val;extra->flags |= PCRE_EXTRA_CALLOUT_DATA;
C_ret:
#undef return

return C_r;}

/* from k2242 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub345(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub345(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned long val=(unsigned long )C_num_to_unsigned_long(C_a1);
extra->match_limit_recursion = val;extra->flags |= PCRE_EXTRA_MATCH_LIMIT_RECURSION;
C_ret:
#undef return

return C_r;}

/* from k2220 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub338(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub338(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra=(pcre_extra *)C_c_pointer_nn(C_a0);
unsigned long val=(unsigned long )C_num_to_unsigned_long(C_a1);
extra->match_limit = val;extra->flags |= PCRE_EXTRA_MATCH_LIMIT;
C_ret:
#undef return

return C_r;}

/* from re-extra */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub327(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub327(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
pcre_extra *extra = (pcre_extra *)(pcre_malloc)(sizeof(pcre_extra));if (!extra) out_of_memory_failure("regex-extras", "re-extra", "pcre_extra");extra->flags = 0;extra->study_data = NULL;extra->match_limit = 0;extra->match_limit_recursion = 0;extra->callout_data = NULL;extra->tables = NULL;return(extra);
C_ret:
#undef return

return C_r;}

/* from k1921 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub263(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub263(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int type=(unsigned int )C_unfix(C_a2);
return(tables[ctypes_offset + idx] & type);
C_ret:
#undef return

return C_r;}

/* from k1903 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int type=(unsigned int )C_unfix(C_a2);
tables[ctypes_offset + idx] += type;
C_ret:
#undef return

return C_r;}

/* from k1885 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub244(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub244(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
tables[ctypes_offset + idx] = 0;
C_ret:
#undef return

return C_r;}

/* from k1855 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub232(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub232(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int class=(unsigned int )C_unfix(C_a2);
return(tables[cbits_offset + class + idx/8] & (1 << (idx & 7)));
C_ret:
#undef return

return C_r;}

/* from k1837 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub222(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub222(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int class=(unsigned int )C_unfix(C_a2);
tables[cbits_offset + class + idx/8] |= 1 << (idx & 7);
C_ret:
#undef return

return C_r;}

/* from k1819 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub212(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub212(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned int class=(unsigned int )C_unfix(C_a2);
tables[cbits_offset + class + idx/8] &= ~(1 << (idx & 7));
C_ret:
#undef return

return C_r;}

/* from k1801 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub203(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub203(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
return(tables[fcc_offset + idx]);
C_ret:
#undef return

return C_r;}

/* from k1787 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub194(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub194(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned C_char flipped=(unsigned C_char )C_character_code((C_word)C_a2);
tables[fcc_offset + idx] = flipped;
C_ret:
#undef return

return C_r;}

/* from k1769 */
#define return(x) C_cblock C_r = (C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub185(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub185(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned C_char *tables=(const unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
return(tables[lcc_offset + idx]);
C_ret:
#undef return

return C_r;}

/* from k1755 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub176(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub176(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned C_char *tables=(unsigned C_char *)C_c_pointer_or_null(C_a0);
int idx=(int )C_unfix(C_a1);
unsigned C_char lower=(unsigned C_char )C_character_code((C_word)C_a2);
tables[lcc_offset + idx] = lower;
C_ret:
#undef return

return C_r;}

/* from re-maketables */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub124(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
const unsigned char *tables = pcre_maketables();if (!tables) out_of_memory_failure("regex-extras", "re-maketables", "tables");return(tables);
C_ret:
#undef return

return C_r;}

/* from k1424 */
static C_word C_fcall stub105(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub105(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

/* from f_636 in regex-version in k620 in k617 */
static C_word C_fcall stub7(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub7(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_mpointer(&C_a,(void*)pcre_version());
return C_r;}

C_noret_decl(C_regex_extras_toplevel)
C_externexport void C_ccall C_regex_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_622)
static void C_ccall f_622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_fcall f_2786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_fcall f_1025(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2637)
static void C_ccall f_2637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2499)
static void C_ccall f_2499r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_fcall f_2430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2391)
static void C_fcall f_2391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_fcall f_2096(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_fcall f_2116(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2122)
static void C_fcall f_2122(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_fcall f_1953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_fcall f_1959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_fcall f_1960(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1633)
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1464)
static void C_fcall f_1464(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_fcall f_1432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_642)
static void C_fcall f_642(C_word t0,C_word t1) C_noret;
C_noret_decl(f_652)
static void C_fcall f_652(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_677)
static void C_ccall f_677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_624)
static void C_ccall f_624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_636)
static void C_ccall f_636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_628)
static void C_ccall f_628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1270)
static void C_fcall trf_1270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1270(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1270(t0,t1,t2,t3);}

C_noret_decl(trf_2786)
static void C_fcall trf_2786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2786(t0,t1,t2,t3);}

C_noret_decl(trf_1025)
static void C_fcall trf_1025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1025(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1025(t0,t1,t2,t3);}

C_noret_decl(trf_2430)
static void C_fcall trf_2430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2430(t0,t1);}

C_noret_decl(trf_2391)
static void C_fcall trf_2391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2391(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2391(t0,t1,t2);}

C_noret_decl(trf_2096)
static void C_fcall trf_2096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2096(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2096(t0,t1,t2);}

C_noret_decl(trf_2116)
static void C_fcall trf_2116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2116(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2116(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2122)
static void C_fcall trf_2122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2122(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2122(t0,t1,t2,t3);}

C_noret_decl(trf_2049)
static void C_fcall trf_2049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2049(t0,t1,t2);}

C_noret_decl(trf_1953)
static void C_fcall trf_1953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1953(t0,t1);}

C_noret_decl(trf_1959)
static void C_fcall trf_1959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1959(t0,t1);}

C_noret_decl(trf_1960)
static void C_fcall trf_1960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1960(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1960(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1633)
static void C_fcall trf_1633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1633(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1633(t0,t1,t2,t3);}

C_noret_decl(trf_1464)
static void C_fcall trf_1464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1464(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1464(t0,t1,t2,t3);}

C_noret_decl(trf_1432)
static void C_fcall trf_1432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1432(t0,t1);}

C_noret_decl(trf_642)
static void C_fcall trf_642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_642(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_642(t0,t1);}

C_noret_decl(trf_652)
static void C_fcall trf_652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_652(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_652(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_regex_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2319)){
C_save(t1);
C_rereclaim2(2319*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,195);
lf[0]=C_h_intern(&lf[0],9,"substring");
lf[1]=C_h_intern(&lf[1],15,"substring-index");
lf[2]=C_h_intern(&lf[2],13,"regex-version");
lf[3]=C_static_string(C_heaptop,1," ");
lf[4]=C_h_intern(&lf[4],25,"\003syspeek-nonnull-c-string");
lf[5]=C_static_lambda_info(C_heaptop,7,"(f_636)");
lf[6]=C_static_lambda_info(C_heaptop,15,"(regex-version)");
lf[8]=C_h_intern(&lf[8],8,"caseless");
lf[9]=C_h_intern(&lf[9],9,"multiline");
lf[10]=C_h_intern(&lf[10],6,"dotall");
lf[11]=C_h_intern(&lf[11],8,"extended");
lf[12]=C_h_intern(&lf[12],8,"anchored");
lf[13]=C_h_intern(&lf[13],14,"dollar-endonly");
lf[14]=C_h_intern(&lf[14],5,"extra");
lf[15]=C_h_intern(&lf[15],6,"notbol");
lf[16]=C_h_intern(&lf[16],6,"noteol");
lf[17]=C_h_intern(&lf[17],8,"ungreedy");
lf[18]=C_h_intern(&lf[18],8,"notempty");
lf[19]=C_h_intern(&lf[19],4,"utf8");
lf[20]=C_h_intern(&lf[20],15,"no-auto-capture");
lf[21]=C_h_intern(&lf[21],13,"no-utf8-check");
lf[22]=C_h_intern(&lf[22],12,"auto-callout");
lf[23]=C_h_intern(&lf[23],7,"partial");
lf[24]=C_h_intern(&lf[24],12,"dfa-shortest");
lf[25]=C_h_intern(&lf[25],11,"dfa-restart");
lf[26]=C_h_intern(&lf[26],9,"firstline");
lf[27]=C_h_intern(&lf[27],8,"dupnames");
lf[28]=C_h_intern(&lf[28],10,"newline-cr");
lf[29]=C_h_intern(&lf[29],10,"newline-lf");
lf[30]=C_h_intern(&lf[30],12,"newline-crlf");
lf[31]=C_h_intern(&lf[31],11,"newline-any");
lf[32]=C_h_intern(&lf[32],15,"newline-anycrlf");
lf[33]=C_h_intern(&lf[33],11,"bsr-anycrlf");
lf[34]=C_h_intern(&lf[34],11,"bsr-unicode");
lf[35]=C_h_intern(&lf[35],5,"error");
lf[36]=C_static_string(C_heaptop,20,"not a member of enum");
lf[37]=C_h_intern(&lf[37],11,"pcre-option");
lf[38]=C_static_lambda_info(C_heaptop,19,"(loop syms39 sum40)");
lf[39]=C_static_lambda_info(C_heaptop,28,"(pcre-option->number syms37)");
tmp=C_intern(C_heaptop,7,"options");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"long-integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,4,"size");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"long-integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,12,"capturecount");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,10,"backrefmax");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"firstbyte");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"firstchar");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,10,"firsttable");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"pointer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lastliteral");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,13,"nameentrysize");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"namecount");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"nametable");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"pointer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"studysize");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,14,"default-tables");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"pointer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"okpartial");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"boolean");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,8,"jchanged");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"boolean");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"hascrorlf");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"boolean");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[41]=C_h_list(16,C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(16);
tmp=C_intern(C_heaptop,4,"utf8");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"boolean");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,7,"newline");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,9,"link-size");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,22,"posix-malloc-threshold");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,11,"match-limit");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,12,"stackrecurse");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"boolean");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,18,"unicode-properties");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"boolean");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,21,"match-limit-recursion");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"integer");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,3,"bsr");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"boolean");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[44]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
lf[47]=C_static_lambda_info(C_heaptop,22,"(re-finalizer a104108)");
lf[48]=C_h_intern(&lf[48],20,"regex-chardef-table\077");
lf[49]=C_h_intern(&lf[49],24,"\003sysregex-chardef-table\077");
lf[51]=C_h_intern(&lf[51],23,"\003sysmake-tagged-pointer");
lf[52]=C_h_intern(&lf[52],13,"chardef-table");
lf[53]=C_static_lambda_info(C_heaptop,28,"(re-chardef-table tables119)");
lf[54]=C_h_intern(&lf[54],19,"regex-chardef-table");
lf[55]=C_h_intern(&lf[55],14,"set-finalizer!");
lf[56]=C_static_lambda_info(C_heaptop,21,"(regex-chardef-table)");
lf[58]=C_h_intern(&lf[58],5,"space");
lf[59]=C_h_intern(&lf[59],6,"xdigit");
lf[60]=C_h_intern(&lf[60],5,"digit");
lf[61]=C_h_intern(&lf[61],5,"upper");
lf[62]=C_h_intern(&lf[62],5,"lower");
lf[63]=C_h_intern(&lf[63],4,"word");
lf[64]=C_h_intern(&lf[64],5,"graph");
lf[65]=C_h_intern(&lf[65],5,"print");
lf[66]=C_h_intern(&lf[66],5,"punct");
lf[67]=C_h_intern(&lf[67],5,"cntrl");
lf[68]=C_h_intern(&lf[68],9,"pcre-cbit");
lf[69]=C_static_lambda_info(C_heaptop,21,"(loop syms141 sum142)");
lf[70]=C_static_lambda_info(C_heaptop,27,"(pcre-cbit->number syms139)");
tmp=C_intern(C_heaptop,5,"space");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"xdigit");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"digit");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"upper");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"lower");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"word");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"graph");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"print");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"punct");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cntrl");
C_save(tmp);
lf[72]=C_h_list(10,C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(10);
lf[74]=C_h_intern(&lf[74],6,"letter");
lf[75]=C_h_intern(&lf[75],4,"meta");
lf[76]=C_h_intern(&lf[76],10,"pcre-ctype");
lf[77]=C_static_lambda_info(C_heaptop,21,"(loop syms161 sum162)");
lf[78]=C_static_lambda_info(C_heaptop,28,"(pcre-ctype->number syms159)");
lf[80]=C_static_lambda_info(C_heaptop,44,"(chardef-class-set! a221225 a220226 a219227)");
lf[82]=C_static_lambda_info(C_heaptop,39,"(chardef-class a231235 a230236 a229237)");
lf[84]=C_static_lambda_info(C_heaptop,14,"(a1867 sym241)");
lf[85]=C_h_intern(&lf[85],12,"\003sysfor-each");
lf[86]=C_static_lambda_info(C_heaptop,41,"(chardef-classes-clear! tables239 idx240)");
lf[88]=C_static_lambda_info(C_heaptop,37,"(chardef-type-clear! a243247 a242248)");
lf[90]=C_static_lambda_info(C_heaptop,43,"(chardef-type-set! a252256 a251257 a250258)");
lf[92]=C_static_lambda_info(C_heaptop,38,"(chardef-type a262266 a261267 a260268)");
lf[93]=C_h_intern(&lf[93],18,"regex-chardef-set!");
lf[94]=C_static_lambda_info(C_heaptop,14,"(a1971 sym281)");
lf[95]=C_static_lambda_info(C_heaptop,49,"(set-symbols syms277 clear278 sym->num279 set280)");
lf[96]=C_h_intern(&lf[96],9,"\003syserror");
lf[97]=C_static_string(C_heaptop,34,"invalid chardef length - must be 4");
lf[98]=C_static_string(C_heaptop,44,"invalid character index - must be in [0 255]");
lf[99]=C_h_intern(&lf[99],23,"\003syscheck-chardef-table");
lf[100]=C_static_lambda_info(C_heaptop,56,"(regex-chardef-set! tables270 idx-or-char271 chardef272)");
lf[101]=C_h_intern(&lf[101],22,"regex-chardefs-update!");
lf[102]=C_static_lambda_info(C_heaptop,14,"(do296 idx298)");
lf[103]=C_static_string(C_heaptop,37,"invalid chardefs length - must be 256");
lf[104]=C_h_intern(&lf[104],21,"regex-chardef-update!");
lf[105]=C_static_lambda_info(C_heaptop,46,"(regex-chardefs-update! tables294 chardefs295)");
lf[106]=C_h_intern(&lf[106],14,"regex-chardefs");
lf[107]=C_static_lambda_info(C_heaptop,21,"(loop syms316 lst317)");
lf[108]=C_static_lambda_info(C_heaptop,40,"(get-symbols syms312 get313 sym->num314)");
tmp=C_intern(C_heaptop,5,"space");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"xdigit");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"digit");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"letter");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"word");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"meta");
C_save(tmp);
lf[109]=C_h_list(6,C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(6);
lf[110]=C_static_lambda_info(C_heaptop,14,"(do307 idx309)");
lf[111]=C_h_intern(&lf[111],11,"make-vector");
lf[112]=C_static_lambda_info(C_heaptop,26,"(regex-chardefs tables305)");
lf[114]=C_h_intern(&lf[114],11,"match-limit");
lf[115]=C_static_lambda_info(C_heaptop,24,"(f_2213 a337340 a336341)");
lf[116]=C_h_intern(&lf[116],21,"match-limit-recursion");
lf[117]=C_static_lambda_info(C_heaptop,24,"(f_2235 a344347 a343348)");
lf[118]=C_h_intern(&lf[118],12,"callout-data");
lf[119]=C_static_lambda_info(C_heaptop,24,"(f_2257 a351354 a350355)");
lf[120]=C_h_intern(&lf[120],14,"\003syscheck-blob");
lf[121]=C_h_intern(&lf[121],6,"tables");
lf[122]=C_static_lambda_info(C_heaptop,24,"(f_2279 a358362 a357363)");
lf[123]=C_h_intern(&lf[123],7,"warning");
lf[124]=C_static_string(C_heaptop,28,"unrecognized extra field key");
lf[125]=C_static_lambda_info(C_heaptop,14,"(loop args403)");
lf[126]=C_static_lambda_info(C_heaptop,48,"(re-extra-fields-set! loc399 extra400 . args401)");
lf[127]=C_h_intern(&lf[127],22,"regexp-extra-info-set!");
lf[128]=C_h_intern(&lf[128],6,"regexp");
lf[129]=C_static_lambda_info(C_heaptop,40,"(regexp-extra-info-set! rx408 . args409)");
lf[130]=C_h_intern(&lf[130],17,"regexp-extra-info");
lf[131]=C_static_lambda_info(C_heaptop,24,"(f_2307 a372375 a371376)");
lf[132]=C_static_lambda_info(C_heaptop,24,"(f_2326 a378381 a377382)");
lf[133]=C_static_lambda_info(C_heaptop,24,"(f_2345 a384387 a383388)");
lf[134]=C_static_lambda_info(C_heaptop,24,"(f_2368 a391395 a390396)");
lf[135]=C_static_string(C_heaptop,28,"unrecognized extra field key");
lf[136]=C_static_lambda_info(C_heaptop,14,"(a2458 sym423)");
lf[137]=C_h_intern(&lf[137],7,"\003sysmap");
lf[138]=C_static_lambda_info(C_heaptop,37,"(regexp-extra-info rx419 . fields420)");
lf[139]=C_h_intern(&lf[139],19,"regexp-options-set!");
lf[140]=C_static_lambda_info(C_heaptop,40,"(regexp-options-set! rx430 . options431)");
lf[141]=C_h_intern(&lf[141],14,"regexp-options");
lf[142]=C_static_lambda_info(C_heaptop,14,"(a2477 sym428)");
tmp=C_intern(C_heaptop,8,"caseless");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"multiline");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"dotall");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"extended");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"anchored");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"dollar-endonly");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"extra");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"notbol");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"noteol");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"ungreedy");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"notempty");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"utf8");
C_save(tmp);
tmp=C_intern(C_heaptop,15,"no-auto-capture");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"no-utf8-check");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"auto-callout");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"partial");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"dfa-shortest");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"dfa-restart");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"firstline");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"dupnames");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"newline-cr");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"newline-lf");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"newline-crlf");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"newline-any");
C_save(tmp);
tmp=C_intern(C_heaptop,15,"newline-anycrlf");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"bsr-anycrlf");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"bsr-unicode");
C_save(tmp);
lf[143]=C_h_list(27,C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(27);
lf[144]=C_h_intern(&lf[144],15,"\003syssignal-hook");
lf[145]=C_h_intern(&lf[145],11,"\000type-error");
lf[146]=C_static_string(C_heaptop,65,"bad argument type - not an integer or compiled regular expression");
lf[147]=C_static_lambda_info(C_heaptop,23,"(regexp-options obj435)");
lf[148]=C_h_intern(&lf[148],11,"regexp-info");
lf[149]=C_h_intern(&lf[149],7,"boolean");
lf[150]=C_h_intern(&lf[150],12,"long-integer");
lf[151]=C_h_intern(&lf[151],7,"integer");
lf[152]=C_h_intern(&lf[152],7,"pointer");
lf[153]=C_h_intern(&lf[153],14,"default-tables");
lf[154]=C_h_intern(&lf[154],10,"firsttable");
lf[155]=C_static_string(C_heaptop,12,"unknown type");
lf[156]=C_h_intern(&lf[156],7,"options");
lf[157]=C_h_intern(&lf[157],4,"size");
lf[158]=C_h_intern(&lf[158],12,"capturecount");
lf[159]=C_h_intern(&lf[159],10,"backrefmax");
lf[160]=C_h_intern(&lf[160],9,"firstbyte");
lf[161]=C_h_intern(&lf[161],9,"firstchar");
lf[162]=C_h_intern(&lf[162],11,"lastliteral");
lf[163]=C_h_intern(&lf[163],13,"nameentrysize");
lf[164]=C_h_intern(&lf[164],9,"namecount");
lf[165]=C_h_intern(&lf[165],9,"nametable");
lf[166]=C_h_intern(&lf[166],9,"studysize");
lf[167]=C_h_intern(&lf[167],9,"okpartial");
lf[168]=C_h_intern(&lf[168],8,"jchanged");
lf[169]=C_h_intern(&lf[169],9,"hascrorlf");
lf[170]=C_h_intern(&lf[170],15,"pcre-info-field");
lf[171]=C_static_lambda_info(C_heaptop,19,"(loop syms69 sum70)");
lf[172]=C_h_intern(&lf[172],9,"alist-ref");
lf[173]=C_h_intern(&lf[173],3,"eq\077");
lf[174]=C_static_lambda_info(C_heaptop,14,"(a2622 sym486)");
lf[175]=C_static_lambda_info(C_heaptop,31,"(regexp-info rx480 . fields481)");
lf[176]=C_h_intern(&lf[176],21,"regexp-info-nametable");
lf[177]=C_h_intern(&lf[177],17,"\003sysmake-locative");
lf[178]=C_h_intern(&lf[178],8,"location");
lf[179]=C_static_lambda_info(C_heaptop,20,"(loop idx534 lst535)");
lf[180]=C_static_lambda_info(C_heaptop,29,"(regexp-info-nametable rx526)");
lf[181]=C_h_intern(&lf[181],23,"regex-build-config-info");
lf[182]=C_h_intern(&lf[182],7,"newline");
lf[183]=C_static_string(C_heaptop,12,"unknown type");
lf[184]=C_h_intern(&lf[184],9,"link-size");
lf[185]=C_h_intern(&lf[185],22,"posix-malloc-threshold");
lf[186]=C_h_intern(&lf[186],12,"stackrecurse");
lf[187]=C_h_intern(&lf[187],18,"unicode-properties");
lf[188]=C_h_intern(&lf[188],3,"bsr");
lf[189]=C_h_intern(&lf[189],17,"pcre-config-field");
lf[190]=C_static_lambda_info(C_heaptop,19,"(loop syms92 sum93)");
lf[191]=C_static_lambda_info(C_heaptop,14,"(a2836 sym552)");
lf[192]=C_static_lambda_info(C_heaptop,37,"(regex-build-config-info . fields551)");
lf[193]=C_h_intern(&lf[193],3,"car");
lf[194]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf2(lf,195,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_619,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k617 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k620 in k617 */
static void C_ccall f_622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_622,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=*((C_word*)lf[1]+1);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_624,a[2]=t3,a[3]=t2,a[4]=lf[6],tmp=(C_word)a,a+=5,tmp));
t5=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_642,a[2]=lf[39],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[40],lf[41]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[193]+1),lf[40]);}

/* k1256 in k620 in k617 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=C_mutate(&lf[42],t1);
t3=C_mutate(&lf[43],lf[44]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[193]+1),lf[43]);}

/* k1417 in k1256 in k620 in k617 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=C_mutate(&lf[45],t1);
t3=C_mutate(&lf[46],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=lf[47],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[48]+1,*((C_word*)lf[49]+1));
t5=C_mutate(&lf[50],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1432,a[2]=lf[53],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=lf[56],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[57],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1454,a[2]=lf[70],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[71],lf[72]);
t9=C_mutate(&lf[73],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1623,a[2]=lf[78],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[79],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1826,a[2]=lf[80],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[81],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1844,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[83],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=lf[86],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[87],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1878,a[2]=lf[88],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate(&lf[89],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=lf[90],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[91],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1910,a[2]=lf[92],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=lf[100],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2034,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2084,a[2]=lf[112],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[113],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2385,a[2]=lf[126],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=lf[129],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=lf[138],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2499,a[2]=lf[140],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=lf[147],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[148]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2608,a[2]=lf[175],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2756,a[2]=lf[180],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[181]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2831,a[2]=lf[192],tmp=(C_word)a,a+=3,tmp));
t27=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,C_SCHEME_UNDEFINED);}

/* regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2831r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2831r(t0,t1,t2);}}

static void C_ccall f_2831r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2837,a[2]=lf[191],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_nullp(t2);
t5=(C_truep(t4)?lf[45]:t2);
/* map */
t6=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t3,t5);}

/* a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2837,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[181]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2848,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 799  alist-ref */
t5=*((C_word*)lf[172]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,lf[43],*((C_word*)lf[173]+1));}

/* k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_list(&a,1,t4):t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1270,a[2]=t8,a[3]=lf[190],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_1270(t10,t3,t6,C_fix(0));}
else{
t3=t2;
f_2851(2,t3,C_SCHEME_FALSE);}}

/* loop in k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1270,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1295,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t7)){
t8=t6;
f_1295(2,t8,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_UTF8));}
else{
t8=(C_word)C_eqp(t5,lf[182]);
if(C_truep(t8)){
t9=t6;
f_1295(2,t9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_NEWLINE));}
else{
t9=(C_word)C_eqp(t5,lf[184]);
if(C_truep(t9)){
t10=t6;
f_1295(2,t10,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_LINK_SIZE));}
else{
t10=(C_word)C_eqp(t5,lf[185]);
if(C_truep(t10)){
t11=t6;
f_1295(2,t11,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_POSIX_MALLOC_THRESHOLD));}
else{
t11=(C_word)C_eqp(t5,lf[114]);
if(C_truep(t11)){
t12=t6;
f_1295(2,t12,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_MATCH_LIMIT));}
else{
t12=(C_word)C_eqp(t5,lf[186]);
if(C_truep(t12)){
t13=t6;
f_1295(2,t13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_STACKRECURSE));}
else{
t13=(C_word)C_eqp(t5,lf[187]);
if(C_truep(t13)){
t14=t6;
f_1295(2,t14,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_UNICODE_PROPERTIES));}
else{
t14=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t14)){
t15=t6;
f_1295(2,t15,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_MATCH_LIMIT_RECURSION));}
else{
t15=(C_word)C_eqp(t5,lf[188]);
if(C_truep(t15)){
t16=t6;
f_1295(2,t16,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_CONFIG_BSR));}
else{
/* regex-extras.scm: 241  error */
t16=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t6,lf[36],t5,lf[189]);}}}}}}}}}}}

/* k1293 in loop in k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1295,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 241  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1270(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2852 in k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[149]);
if(C_truep(t2)){
t3=t1;
t4=(C_word)C_i_foreign_fixnum_argumentp(t3);
t5=((C_word*)t0)[3];
f_2851(2,t5,(C_word)stub548(C_SCHEME_UNDEFINED,t4));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[151]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=(C_word)stub544(C_SCHEME_UNDEFINED,t5);
t7=(C_word)C_eqp(lf[182],((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
f_2851(2,t8,(C_truep(t7)?(C_word)C_make_character((C_word)C_unfix(t6)):t6));}
else{
/* regex-extras.scm: 810  ##sys#error */
t4=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[181],lf[183],((C_word*)t0)[4]);}}}

/* k2849 in k2846 in a2836 in regex-build-config-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2756,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[128],lf[176]);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_foreign_pointer_argumentp(t5);
t9=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t10=(C_word)stub500(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t13=(C_word)C_i_foreign_pointer_argumentp(t5);
t14=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t15=(C_word)stub508(t12,t13,t14);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2781,a[2]=t1,a[3]=t15,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 767  set-finalizer! */
t17=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t16,t15,lf[46]);}}

/* k2779 in regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=lf[179],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2786(t5,((C_word*)t0)[2],C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in k2779 in regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2786,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2796,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2815,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#make-locative */
t8=*((C_word*)lf[177]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t7,t5,C_fix(0),C_SCHEME_FALSE,lf[178]);}}

/* k2813 in loop in k2779 in regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[3]);
t5=(C_word)C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t1)?(C_word)C_i_foreign_pointer_argumentp(t1):C_SCHEME_FALSE);
t7=(C_word)stub518(t3,t4,t5,t6);
/* ##sys#peek-nonnull-c-string */
t8=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t7,C_fix(0));}

/* k2794 in loop in k2779 in regexp-info-nametable in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[6],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[5]))));
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* regex-extras.scm: 773  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2786(t5,((C_word*)t0)[2],t2,t4);}

/* regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2608r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2608r(t0,t1,t2,t3);}}

static void C_ccall f_2608r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_structure_2(t2,lf[128],lf[148]);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(2));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2623,a[2]=t8,a[3]=t6,a[4]=lf[174],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_nullp(t3);
t11=(C_truep(t10)?lf[42]:t3);
/* map */
t12=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,t9,t11);}

/* a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2623,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[148]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 679  alist-ref */
t5=*((C_word*)lf[172]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,lf[40],*((C_word*)lf[173]+1));}

/* k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2637,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(C_word)C_i_symbolp(t4);
t6=(C_truep(t5)?(C_word)C_a_i_list(&a,1,t4):t4);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1025,a[2]=t8,a[3]=lf[171],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_1025(t10,t3,t6,C_fix(0));}
else{
t3=t2;
f_2637(2,t3,C_SCHEME_FALSE);}}

/* loop in k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1025(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1025,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1050,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[156]);
if(C_truep(t7)){
t8=t6;
f_1050(2,t8,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_OPTIONS));}
else{
t8=(C_word)C_eqp(t5,lf[157]);
if(C_truep(t8)){
t9=t6;
f_1050(2,t9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_SIZE));}
else{
t9=(C_word)C_eqp(t5,lf[158]);
if(C_truep(t9)){
t10=t6;
f_1050(2,t10,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_CAPTURECOUNT));}
else{
t10=(C_word)C_eqp(t5,lf[159]);
if(C_truep(t10)){
t11=t6;
f_1050(2,t11,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_BACKREFMAX));}
else{
t11=(C_word)C_eqp(t5,lf[160]);
if(C_truep(t11)){
t12=t6;
f_1050(2,t12,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_FIRSTBYTE));}
else{
t12=(C_word)C_eqp(t5,lf[161]);
if(C_truep(t12)){
t13=t6;
f_1050(2,t13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_FIRSTCHAR));}
else{
t13=(C_word)C_eqp(t5,lf[154]);
if(C_truep(t13)){
t14=t6;
f_1050(2,t14,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_FIRSTTABLE));}
else{
t14=(C_word)C_eqp(t5,lf[162]);
if(C_truep(t14)){
t15=t6;
f_1050(2,t15,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_LASTLITERAL));}
else{
t15=(C_word)C_eqp(t5,lf[163]);
if(C_truep(t15)){
t16=t6;
f_1050(2,t16,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_NAMEENTRYSIZE));}
else{
t16=(C_word)C_eqp(t5,lf[164]);
if(C_truep(t16)){
t17=t6;
f_1050(2,t17,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_NAMECOUNT));}
else{
t17=(C_word)C_eqp(t5,lf[165]);
if(C_truep(t17)){
t18=t6;
f_1050(2,t18,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_NAMETABLE));}
else{
t18=(C_word)C_eqp(t5,lf[166]);
if(C_truep(t18)){
t19=t6;
f_1050(2,t19,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_STUDYSIZE));}
else{
t19=(C_word)C_eqp(t5,lf[153]);
if(C_truep(t19)){
t20=t6;
f_1050(2,t20,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_DEFAULT_TABLES));}
else{
t20=(C_word)C_eqp(t5,lf[167]);
if(C_truep(t20)){
t21=t6;
f_1050(2,t21,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_OKPARTIAL));}
else{
t21=(C_word)C_eqp(t5,lf[168]);
if(C_truep(t21)){
t22=t6;
f_1050(2,t22,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_JCHANGED));}
else{
t22=(C_word)C_eqp(t5,lf[169]);
if(C_truep(t22)){
t23=t6;
f_1050(2,t23,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)PCRE_INFO_HASCRORLF));}
else{
/* regex-extras.scm: 203  error */
t23=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t23+1)))(5,t23,t6,lf[36],t5,lf[170]);}}}}}}}}}}}}}}}}}}

/* k1048 in loop in k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 203  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1025(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2638 in k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[149]);
if(C_truep(t2)){
t3=t1;
t4=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[5]);
t5=(C_truep(((C_word*)t0)[4])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[4]):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=((C_word*)t0)[3];
f_2637(2,t7,(C_word)stub462(C_SCHEME_UNDEFINED,t4,t5,t6));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],lf[150]);
if(C_truep(t3)){
t4=t1;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t6=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[5]);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[4]):C_SCHEME_FALSE);
t8=(C_word)C_i_foreign_fixnum_argumentp(t4);
t9=((C_word*)t0)[3];
f_2637(2,t9,(C_word)stub441(t5,t6,t7,t8));}
else{
t4=(C_word)C_eqp(((C_word*)t0)[6],lf[151]);
if(C_truep(t4)){
t5=t1;
t6=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[5]);
t7=(C_truep(((C_word*)t0)[4])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[4]):C_SCHEME_FALSE);
t8=(C_word)C_i_foreign_fixnum_argumentp(t5);
t9=((C_word*)t0)[3];
f_2637(2,t9,(C_word)stub452(C_SCHEME_UNDEFINED,t6,t7,t8));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[6],lf[152]);
if(C_truep(t5)){
t6=t1;
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[5]);
t9=(C_truep(((C_word*)t0)[4])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[4]):C_SCHEME_FALSE);
t10=(C_word)C_i_foreign_fixnum_argumentp(t6);
t11=(C_word)stub472(t7,t8,t9,t10);
if(C_truep(t11)){
t12=((C_word*)t0)[2];
t13=(C_word)C_eqp(t12,lf[153]);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t12,lf[154]));
if(C_truep(t14)){
/* regex-extras.scm: 692  re-chardef-table */
f_1432(((C_word*)t0)[3],t11);}
else{
t15=((C_word*)t0)[3];
f_2637(2,t15,t11);}}
else{
t12=((C_word*)t0)[3];
f_2637(2,t12,C_SCHEME_FALSE);}}
else{
/* regex-extras.scm: 696  ##sys#error */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[3],lf[148],lf[155],((C_word*)t0)[6]);}}}}}

/* k2635 in k2632 in a2622 in regexp-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2637,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2511,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2519,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
if(C_truep((C_word)C_i_structurep(t4,lf[128]))){
t5=t2;
t6=t3;
f_2519(2,t6,(C_word)C_slot(t5,C_fix(3)));}
else{
if(C_truep((C_word)C_i_integerp(t2))){
t5=t3;
f_2519(2,t5,t2);}
else{
/* regex-extras.scm: 637  ##sys#signal-hook */
t5=*((C_word*)lf[144]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,lf[145],lf[141],lf[146],t2);}}}

/* k2517 in regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2476,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2478,a[2]=t4,a[3]=t1,a[4]=lf[142],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,lf[143]);}

/* a2477 in k2517 in regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2478,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 619  pcre-option->number */
f_642(t3,t2);}

/* k2495 in a2477 in k2517 in regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_and(&a,2,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2474 in k2517 in regexp-options in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* regexp-options-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2499(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2499r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2499r(t0,t1,t2,t3);}}

static void C_ccall f_2499r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_structure_2(t2,lf[128],lf[139]);
t5=t2;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2506,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 628  pcre-option->number */
f_642(t6,t3);}

/* k2504 in regexp-options-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(3),t1));}

/* regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2444r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2444r(t0,t1,t2,t3);}}

static void C_ccall f_2444r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_structure_2(t2,lf[128],lf[130]);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2459,a[2]=t6,a[3]=lf[136],tmp=(C_word)a,a+=4,tmp);
/* map */
t8=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_END_OF_LIST);}}

/* a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2459,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[130]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2470,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[114]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2307,a[2]=lf[131],tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t4,((C_word*)t0)[2]);}
else{
t7=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=lf[132],tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t4,((C_word*)t0)[2]);}
else{
t8=(C_word)C_eqp(t5,lf[118]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2345,a[2]=lf[133],tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t4,((C_word*)t0)[2]);}
else{
t9=(C_word)C_eqp(t5,lf[121]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2367,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=lf[134],tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t0)[2]);}
else{
/* regex-extras.scm: 574  warning */
t10=*((C_word*)lf[123]+1);
((C_proc5)C_retrieve_proc(t10))(5,t10,t4,lf[130],lf[135],t5);}}}}}

/* f_2368 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2368,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_pointer_argumentp(t2);
t6=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub392(t4,t5,t6));}

/* k2365 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex-extras.scm: 569  re-chardef-table */
f_1432(((C_word*)t0)[2],t1);}

/* f_2345 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2345,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_pointer_argumentp(t2);
t6=(C_word)C_i_foreign_block_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub385(t4,t5,t6));}

/* f_2326 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2326,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub379(C_SCHEME_UNDEFINED,t4,t5));}

/* f_2307 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2307,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub373(C_SCHEME_UNDEFINED,t4,t5));}

/* k2468 in a2458 in regexp-extra-info in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* regexp-extra-info-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_2416r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2416r(t0,t1,t2,t3);}}

static void C_ccall f_2416r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(14);
t4=(C_word)C_i_check_structure_2(t2,lf[128],lf[127]);
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2430,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
t8=t7;
f_2430(t8,t6);}
else{
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t9=(C_word)stub327(t8);
t10=t2;
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2436,a[2]=t7,a[3]=t9,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
/* set-finalizer! */
t12=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t9,lf[46]);}
else{
t12=t11;
f_2436(2,t12,C_SCHEME_UNDEFINED);}}}

/* k2434 in regexp-extra-info-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_2430(t3,((C_word*)t0)[3]);}

/* k2428 in regexp-extra-info-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[3],lf[113],lf[127],t1,((C_word*)t0)[2]);}

/* re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2385r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2385r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2385r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2391,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=lf[125],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2391(t8,t1,t4);}

/* loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2391(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2391,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2407,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=(C_word)C_eqp(t3,lf[114]);
if(C_truep(t8)){
t9=(C_word)C_i_check_exact_2(*((C_word*)lf[114]+1),t6);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=lf[115],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t5,t7,t4);}
else{
t9=(C_word)C_eqp(t3,lf[116]);
if(C_truep(t9)){
t10=(C_word)C_i_check_exact_2(*((C_word*)lf[116]+1),t6);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2235,a[2]=lf[117],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t5,t7,t4);}
else{
t10=(C_word)C_eqp(t3,lf[118]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2253,a[2]=t4,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 538  ##sys#check-blob */
t12=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,*((C_word*)lf[118]+1),t6);}
else{
t11=(C_word)C_eqp(t3,lf[121]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2275,a[2]=t4,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 544  ##sys#check-chardef-table */
t13=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t12,*((C_word*)lf[121]+1),t6);}
else{
/* regex-extras.scm: 550  warning */
t12=*((C_word*)lf[123]+1);
((C_proc5)C_retrieve_proc(t12))(5,t12,t5,t6,lf[124],t3);}}}}}}

/* k2273 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=lf[122],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_2279 in k2273 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2279(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2279,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub359(C_SCHEME_UNDEFINED,t4,t5));}

/* k2251 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=lf[119],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_2257 in k2251 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2257,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_block_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub352(C_SCHEME_UNDEFINED,t4,t5));}

/* f_2235 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2235,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub345(C_SCHEME_UNDEFINED,t4,t5));}

/* f_2213 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2213,4,t0,t1,t2,t3);}
t4=(C_word)C_i_foreign_pointer_argumentp(t2);
t5=(C_word)C_i_foreign_unsigned_integer_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub338(C_SCHEME_UNDEFINED,t4,t5));}

/* k2405 in loop in re-extra-fields-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* regex-extras.scm: 584  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2391(t3,((C_word*)t0)[2],t2);}

/* regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2084,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2088,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 472  ##sys#check-chardef-table */
t4=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[106]);}

/* k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 474  make-vector */
t3=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}

/* k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2096,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[110],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2096(t5,((C_word*)t0)[2],C_fix(0));}

/* do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2096(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2096,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_fix(256),t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,4,t4,t4,t4,t4);
t6=(C_word)C_i_vector_set(((C_word*)t0)[4],t2,t5);
t7=((C_word*)t0)[3];
t8=t2;
t9=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t10=(C_word)C_i_foreign_fixnum_argumentp(t8);
t11=(C_word)stub185(C_SCHEME_UNDEFINED,t9,t10);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_i_vector_set(t5,C_fix(0),t12);
t14=((C_word*)t0)[3];
t15=t2;
t16=(C_truep(t14)?(C_word)C_i_foreign_pointer_argumentp(t14):C_SCHEME_FALSE);
t17=(C_word)C_i_foreign_fixnum_argumentp(t15);
t18=(C_word)stub203(C_SCHEME_UNDEFINED,t16,t17);
t19=(C_word)C_make_character((C_word)C_unfix(t18));
t20=(C_word)C_i_vector_set(t5,C_fix(1),t19);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2116,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=lf[108],tmp=(C_word)a,a+=5,tmp);
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2178,a[2]=t21,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* regex-extras.scm: 498  get-symbols */
t23=t21;
f_2116(t23,t22,lf[71],lf[81],lf[57]);}}

/* k2176 in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[6],C_fix(2),t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 500  get-symbols */
t4=((C_word*)t0)[2];
f_2116(t4,t3,lf[109],lf[91],lf[73]);}

/* k2172 in k2176 in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_vector_set(((C_word*)t0)[5],C_fix(3),t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2096(t4,((C_word*)t0)[2],t3);}

/* get-symbols in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2116(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2116,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2122,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t6,a[7]=lf[107],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_2122(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in get-symbols in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2122(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2122,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2153,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 494  sym->num */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t4);}}

/* k2155 in loop in get-symbols in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex-extras.scm: 494  get */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2151 in loop in get-symbols in do307 in k2089 in k2086 in regex-chardefs in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
t3=(C_truep(t2)?((C_word*)t0)[6]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]));
/* regex-extras.scm: 493  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2122(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2034,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2038,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 455  ##sys#check-chardef-table */
t5=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[104]);}

/* k2036 in regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[4],lf[101]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t5=(C_word)C_eqp(C_fix(256),t4);
if(C_truep(t5)){
t6=t3;
f_2044(2,t6,C_SCHEME_UNDEFINED);}
else{
/* regex-extras.scm: 459  ##sys#error */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[101],lf[103],((C_word*)t0)[4]);}}

/* k2042 in k2036 in regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=lf[102],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2049(t5,((C_word*)t0)[2],C_fix(0));}

/* do296 in k2042 in k2036 in regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2049,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_fix(256),t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_vector_ref(((C_word*)t0)[4],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2062,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
/* regex-extras.scm: 465  regex-chardef-set! */
t6=*((C_word*)lf[93]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t2,t4);}
else{
t6=t5;
f_2062(2,t6,C_SCHEME_FALSE);}}}

/* k2060 in do296 in k2042 in k2036 in regex-chardefs-update! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2049(t3,((C_word*)t0)[2],t2);}

/* regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1928,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1932,a[2]=t1,a[3]=t2,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 415  ##sys#check-chardef-table */
t6=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[93]);}

/* k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1932,2,t0,t1);}
t2=(C_word)C_charp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5])):((C_word*)t0)[5]);
t4=(C_word)C_i_check_exact_2(t3,lf[93]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_fixnum_less_or_equal_p(C_fix(0),t3);
t7=(C_truep(t6)?(C_word)C_fixnum_less_or_equal_p(t3,C_fix(255)):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t5;
f_1941(2,t8,C_SCHEME_UNDEFINED);}
else{
/* regex-extras.scm: 421  ##sys#error */
t8=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[93],lf[98],t3);}}

/* k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(C_word)C_i_check_vector_2(((C_word*)t0)[5],lf[93]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_vector_length(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_fix(4),t4);
if(C_truep(t5)){
t6=t3;
f_1947(2,t6,C_SCHEME_UNDEFINED);}
else{
/* regex-extras.scm: 425  ##sys#error */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[93],lf[97],((C_word*)t0)[5]);}}

/* k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[4];
t5=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t7=(C_word)C_i_foreign_char_argumentp(t2);
t8=t3;
f_1953(t8,(C_word)stub176(C_SCHEME_UNDEFINED,t5,t6,t7));}
else{
t4=t3;
f_1953(t4,C_SCHEME_FALSE);}}

/* k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1953,NULL,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=((C_word*)t0)[4];
t5=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t7=(C_word)C_i_foreign_char_argumentp(t2);
t8=t3;
f_1959(t8,(C_word)stub194(C_SCHEME_UNDEFINED,t5,t6,t7));}
else{
t4=t3;
f_1959(t4,C_SCHEME_FALSE);}}

/* k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1959,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=lf[95],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* regex-extras.scm: 443  set-symbols */
t5=t2;
f_1960(t5,t4,t3,lf[83],lf[57],lf[79]);}
else{
t5=t4;
f_1986(2,t5,C_SCHEME_FALSE);}}

/* k1984 in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(3));
if(C_truep(t2)){
/* regex-extras.scm: 446  set-symbols */
t3=((C_word*)t0)[3];
f_1960(t3,((C_word*)t0)[2],t2,lf[87],lf[73],lf[89]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* set-symbols in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1960(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1960,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_list_2(t2,lf[93]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1967,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* regex-extras.scm: 436  clear */
t8=t3;
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1965 in set-symbols in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=lf[94],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a1971 in k1965 in set-symbols in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1972,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* regex-extras.scm: 439  sym->num */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1978 in a1971 in k1965 in set-symbols in k1957 in k1951 in k1945 in k1939 in k1930 in regex-chardef-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex-extras.scm: 439  set */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chardef-type in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1910,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub263(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* chardef-type-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1892,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub253(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* chardef-type-clear! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1878,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub244(C_SCHEME_UNDEFINED,t4,t5));}

/* chardef-classes-clear! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1862,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1868,a[2]=t3,a[3]=t2,a[4]=lf[84],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,lf[71]);}

/* a1867 in chardef-classes-clear! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1868,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 389  pcre-cbit->number */
t4=lf[57];
f_1454(3,t4,t3,t2);}

/* k1874 in a1867 in chardef-classes-clear! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t1);
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub212(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* chardef-class in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1844,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub232(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* chardef-class-set! in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1826,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
t7=(C_word)C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub222(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* pcre-ctype->number in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1623,3,t0,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1633,a[2]=t6,a[3]=lf[77],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1633(t8,t1,t4,C_fix(0));}

/* loop in pcre-ctype->number in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1633,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1658,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[58]);
if(C_truep(t7)){
t8=t6;
f_1658(2,t8,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_space));}
else{
t8=(C_word)C_eqp(t5,lf[74]);
if(C_truep(t8)){
t9=t6;
f_1658(2,t9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_letter));}
else{
t9=(C_word)C_eqp(t5,lf[60]);
if(C_truep(t9)){
t10=t6;
f_1658(2,t10,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_digit));}
else{
t10=(C_word)C_eqp(t5,lf[59]);
if(C_truep(t10)){
t11=t6;
f_1658(2,t11,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_xdigit));}
else{
t11=(C_word)C_eqp(t5,lf[63]);
if(C_truep(t11)){
t12=t6;
f_1658(2,t12,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_word));}
else{
t12=(C_word)C_eqp(t5,lf[75]);
if(C_truep(t12)){
t13=t6;
f_1658(2,t13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)ctype_meta));}
else{
/* regex-extras.scm: 346  error */
t13=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t6,lf[36],t5,lf[76]);}}}}}}}}

/* k1656 in loop in pcre-ctype->number in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 346  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1633(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* pcre-cbit->number in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1454,3,t0,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1464,a[2]=t6,a[3]=lf[69],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_1464(t8,t1,t4,C_fix(0));}

/* loop in pcre-cbit->number in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1464(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1464,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1489,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[58]);
if(C_truep(t7)){
t8=t6;
f_1489(2,t8,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_space));}
else{
t8=(C_word)C_eqp(t5,lf[59]);
if(C_truep(t8)){
t9=t6;
f_1489(2,t9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_xdigit));}
else{
t9=(C_word)C_eqp(t5,lf[60]);
if(C_truep(t9)){
t10=t6;
f_1489(2,t10,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_digit));}
else{
t10=(C_word)C_eqp(t5,lf[61]);
if(C_truep(t10)){
t11=t6;
f_1489(2,t11,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_upper));}
else{
t11=(C_word)C_eqp(t5,lf[62]);
if(C_truep(t11)){
t12=t6;
f_1489(2,t12,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_lower));}
else{
t12=(C_word)C_eqp(t5,lf[63]);
if(C_truep(t12)){
t13=t6;
f_1489(2,t13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_word));}
else{
t13=(C_word)C_eqp(t5,lf[64]);
if(C_truep(t13)){
t14=t6;
f_1489(2,t14,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_graph));}
else{
t14=(C_word)C_eqp(t5,lf[65]);
if(C_truep(t14)){
t15=t6;
f_1489(2,t15,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_print));}
else{
t15=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t15)){
t16=t6;
f_1489(2,t16,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_punct));}
else{
t16=(C_word)C_eqp(t5,lf[67]);
if(C_truep(t16)){
t17=t6;
f_1489(2,t17,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)cbit_cntrl));}
else{
/* regex-extras.scm: 330  error */
t17=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t6,lf[36],t5,lf[68]);}}}}}}}}}}}}

/* k1487 in loop in pcre-cbit->number in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 330  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1464(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* regex-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)stub124(t3);
/* regex-extras.scm: 324  re-chardef-table */
f_1432(t2,t4);}

/* k1443 in regex-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1448,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* regex-extras.scm: 325  set-finalizer! */
t3=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[46]);}

/* k1446 in k1443 in regex-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* re-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_fcall f_1432(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1432,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1436,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#make-tagged-pointer */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[52]);}

/* k1434 in re-chardef-table in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_pointer(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* re-finalizer in k1417 in k1256 in k620 in k617 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1421,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub105(C_SCHEME_UNDEFINED,t3));}

/* pcre-option->number in k620 in k617 */
static void C_fcall f_642(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_642,NULL,2,t1,t2);}
t3=(C_word)C_i_symbolp(t2);
t4=(C_truep(t3)?(C_word)C_a_i_list(&a,1,t2):t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_652,a[2]=t6,a[3]=lf[38],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_652(t8,t1,t4,C_fix(0));}

/* loop in pcre-option->number in k620 in k617 */
static void C_fcall f_652(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[114],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_652,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_677,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(t5,lf[8]);
if(C_truep(t7)){
t8=t6;
f_677(2,t8,C_unsigned_int_to_num(&a,PCRE_CASELESS));}
else{
t8=(C_word)C_eqp(t5,lf[9]);
if(C_truep(t8)){
t9=t6;
f_677(2,t9,C_unsigned_int_to_num(&a,PCRE_MULTILINE));}
else{
t9=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t9)){
t10=t6;
f_677(2,t10,C_unsigned_int_to_num(&a,PCRE_DOTALL));}
else{
t10=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t10)){
t11=t6;
f_677(2,t11,C_unsigned_int_to_num(&a,PCRE_EXTENDED));}
else{
t11=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t11)){
t12=t6;
f_677(2,t12,C_unsigned_int_to_num(&a,PCRE_ANCHORED));}
else{
t12=(C_word)C_eqp(t5,lf[13]);
if(C_truep(t12)){
t13=t6;
f_677(2,t13,C_unsigned_int_to_num(&a,PCRE_DOLLAR_ENDONLY));}
else{
t13=(C_word)C_eqp(t5,lf[14]);
if(C_truep(t13)){
t14=t6;
f_677(2,t14,C_unsigned_int_to_num(&a,PCRE_EXTRA));}
else{
t14=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t14)){
t15=t6;
f_677(2,t15,C_unsigned_int_to_num(&a,PCRE_NOTBOL));}
else{
t15=(C_word)C_eqp(t5,lf[16]);
if(C_truep(t15)){
t16=t6;
f_677(2,t16,C_unsigned_int_to_num(&a,PCRE_NOTEOL));}
else{
t16=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t16)){
t17=t6;
f_677(2,t17,C_unsigned_int_to_num(&a,PCRE_UNGREEDY));}
else{
t17=(C_word)C_eqp(t5,lf[18]);
if(C_truep(t17)){
t18=t6;
f_677(2,t18,C_unsigned_int_to_num(&a,PCRE_NOTEMPTY));}
else{
t18=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t18)){
t19=t6;
f_677(2,t19,C_unsigned_int_to_num(&a,PCRE_UTF8));}
else{
t19=(C_word)C_eqp(t5,lf[20]);
if(C_truep(t19)){
t20=t6;
f_677(2,t20,C_unsigned_int_to_num(&a,PCRE_NO_AUTO_CAPTURE));}
else{
t20=(C_word)C_eqp(t5,lf[21]);
if(C_truep(t20)){
t21=t6;
f_677(2,t21,C_unsigned_int_to_num(&a,PCRE_NO_UTF8_CHECK));}
else{
t21=(C_word)C_eqp(t5,lf[22]);
if(C_truep(t21)){
t22=t6;
f_677(2,t22,C_unsigned_int_to_num(&a,PCRE_AUTO_CALLOUT));}
else{
t22=(C_word)C_eqp(t5,lf[23]);
if(C_truep(t22)){
t23=t6;
f_677(2,t23,C_unsigned_int_to_num(&a,PCRE_PARTIAL));}
else{
t23=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t23)){
t24=t6;
f_677(2,t24,C_unsigned_int_to_num(&a,PCRE_DFA_SHORTEST));}
else{
t24=(C_word)C_eqp(t5,lf[25]);
if(C_truep(t24)){
t25=t6;
f_677(2,t25,C_unsigned_int_to_num(&a,PCRE_DFA_RESTART));}
else{
t25=(C_word)C_eqp(t5,lf[26]);
if(C_truep(t25)){
t26=t6;
f_677(2,t26,C_unsigned_int_to_num(&a,PCRE_FIRSTLINE));}
else{
t26=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t26)){
t27=t6;
f_677(2,t27,C_unsigned_int_to_num(&a,PCRE_DUPNAMES));}
else{
t27=(C_word)C_eqp(t5,lf[28]);
if(C_truep(t27)){
t28=t6;
f_677(2,t28,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CR));}
else{
t28=(C_word)C_eqp(t5,lf[29]);
if(C_truep(t28)){
t29=t6;
f_677(2,t29,C_unsigned_int_to_num(&a,PCRE_NEWLINE_LF));}
else{
t29=(C_word)C_eqp(t5,lf[30]);
if(C_truep(t29)){
t30=t6;
f_677(2,t30,C_unsigned_int_to_num(&a,PCRE_NEWLINE_CRLF));}
else{
t30=(C_word)C_eqp(t5,lf[31]);
if(C_truep(t30)){
t31=t6;
f_677(2,t31,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANY));}
else{
t31=(C_word)C_eqp(t5,lf[32]);
if(C_truep(t31)){
t32=t6;
f_677(2,t32,C_unsigned_int_to_num(&a,PCRE_NEWLINE_ANYCRLF));}
else{
t32=(C_word)C_eqp(t5,lf[33]);
if(C_truep(t32)){
t33=t6;
f_677(2,t33,C_unsigned_int_to_num(&a,PCRE_BSR_ANYCRLF));}
else{
t33=(C_word)C_eqp(t5,lf[34]);
if(C_truep(t33)){
t34=t6;
f_677(2,t34,C_unsigned_int_to_num(&a,PCRE_BSR_UNICODE));}
else{
/* regex-extras.scm: 145  error */
t34=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t34+1)))(5,t34,t6,lf[36],t5,lf[37]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k675 in loop in pcre-option->number in k620 in k617 */
static void C_ccall f_677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_677,2,t0,t1);}
t2=(C_word)C_a_i_bitwise_ior(&a,2,((C_word*)t0)[5],t1);
/* regex-extras.scm: 145  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_652(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* regex-version in k620 in k617 */
static void C_ccall f_624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_628,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_636,a[2]=lf[5],tmp=(C_word)a,a+=3,tmp);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_636 in regex-version in k620 in k617 */
static void C_ccall f_636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_636,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub7(t2),C_fix(0));}

/* k626 in regex-version in k620 in k617 */
static void C_ccall f_628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_635,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* regex-extras.scm: 132  substring-index */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[3],t1);}

/* k633 in k626 in regex-version in k620 in k617 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regex-extras.scm: 132  substring */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[105] = {
{"toplevelregex-extras.scm",(void*)C_regex_extras_toplevel},
{"f_619regex-extras.scm",(void*)f_619},
{"f_622regex-extras.scm",(void*)f_622},
{"f_1258regex-extras.scm",(void*)f_1258},
{"f_1419regex-extras.scm",(void*)f_1419},
{"f_2831regex-extras.scm",(void*)f_2831},
{"f_2837regex-extras.scm",(void*)f_2837},
{"f_2848regex-extras.scm",(void*)f_2848},
{"f_1270regex-extras.scm",(void*)f_1270},
{"f_1295regex-extras.scm",(void*)f_1295},
{"f_2854regex-extras.scm",(void*)f_2854},
{"f_2851regex-extras.scm",(void*)f_2851},
{"f_2756regex-extras.scm",(void*)f_2756},
{"f_2781regex-extras.scm",(void*)f_2781},
{"f_2786regex-extras.scm",(void*)f_2786},
{"f_2815regex-extras.scm",(void*)f_2815},
{"f_2796regex-extras.scm",(void*)f_2796},
{"f_2608regex-extras.scm",(void*)f_2608},
{"f_2623regex-extras.scm",(void*)f_2623},
{"f_2634regex-extras.scm",(void*)f_2634},
{"f_1025regex-extras.scm",(void*)f_1025},
{"f_1050regex-extras.scm",(void*)f_1050},
{"f_2640regex-extras.scm",(void*)f_2640},
{"f_2637regex-extras.scm",(void*)f_2637},
{"f_2511regex-extras.scm",(void*)f_2511},
{"f_2519regex-extras.scm",(void*)f_2519},
{"f_2478regex-extras.scm",(void*)f_2478},
{"f_2497regex-extras.scm",(void*)f_2497},
{"f_2476regex-extras.scm",(void*)f_2476},
{"f_2499regex-extras.scm",(void*)f_2499},
{"f_2506regex-extras.scm",(void*)f_2506},
{"f_2444regex-extras.scm",(void*)f_2444},
{"f_2459regex-extras.scm",(void*)f_2459},
{"f_2368regex-extras.scm",(void*)f_2368},
{"f_2367regex-extras.scm",(void*)f_2367},
{"f_2345regex-extras.scm",(void*)f_2345},
{"f_2326regex-extras.scm",(void*)f_2326},
{"f_2307regex-extras.scm",(void*)f_2307},
{"f_2470regex-extras.scm",(void*)f_2470},
{"f_2416regex-extras.scm",(void*)f_2416},
{"f_2436regex-extras.scm",(void*)f_2436},
{"f_2430regex-extras.scm",(void*)f_2430},
{"f_2385regex-extras.scm",(void*)f_2385},
{"f_2391regex-extras.scm",(void*)f_2391},
{"f_2275regex-extras.scm",(void*)f_2275},
{"f_2279regex-extras.scm",(void*)f_2279},
{"f_2253regex-extras.scm",(void*)f_2253},
{"f_2257regex-extras.scm",(void*)f_2257},
{"f_2235regex-extras.scm",(void*)f_2235},
{"f_2213regex-extras.scm",(void*)f_2213},
{"f_2407regex-extras.scm",(void*)f_2407},
{"f_2084regex-extras.scm",(void*)f_2084},
{"f_2088regex-extras.scm",(void*)f_2088},
{"f_2091regex-extras.scm",(void*)f_2091},
{"f_2096regex-extras.scm",(void*)f_2096},
{"f_2178regex-extras.scm",(void*)f_2178},
{"f_2174regex-extras.scm",(void*)f_2174},
{"f_2116regex-extras.scm",(void*)f_2116},
{"f_2122regex-extras.scm",(void*)f_2122},
{"f_2157regex-extras.scm",(void*)f_2157},
{"f_2153regex-extras.scm",(void*)f_2153},
{"f_2034regex-extras.scm",(void*)f_2034},
{"f_2038regex-extras.scm",(void*)f_2038},
{"f_2044regex-extras.scm",(void*)f_2044},
{"f_2049regex-extras.scm",(void*)f_2049},
{"f_2062regex-extras.scm",(void*)f_2062},
{"f_1928regex-extras.scm",(void*)f_1928},
{"f_1932regex-extras.scm",(void*)f_1932},
{"f_1941regex-extras.scm",(void*)f_1941},
{"f_1947regex-extras.scm",(void*)f_1947},
{"f_1953regex-extras.scm",(void*)f_1953},
{"f_1959regex-extras.scm",(void*)f_1959},
{"f_1986regex-extras.scm",(void*)f_1986},
{"f_1960regex-extras.scm",(void*)f_1960},
{"f_1967regex-extras.scm",(void*)f_1967},
{"f_1972regex-extras.scm",(void*)f_1972},
{"f_1980regex-extras.scm",(void*)f_1980},
{"f_1910regex-extras.scm",(void*)f_1910},
{"f_1892regex-extras.scm",(void*)f_1892},
{"f_1878regex-extras.scm",(void*)f_1878},
{"f_1862regex-extras.scm",(void*)f_1862},
{"f_1868regex-extras.scm",(void*)f_1868},
{"f_1876regex-extras.scm",(void*)f_1876},
{"f_1844regex-extras.scm",(void*)f_1844},
{"f_1826regex-extras.scm",(void*)f_1826},
{"f_1623regex-extras.scm",(void*)f_1623},
{"f_1633regex-extras.scm",(void*)f_1633},
{"f_1658regex-extras.scm",(void*)f_1658},
{"f_1454regex-extras.scm",(void*)f_1454},
{"f_1464regex-extras.scm",(void*)f_1464},
{"f_1489regex-extras.scm",(void*)f_1489},
{"f_1441regex-extras.scm",(void*)f_1441},
{"f_1445regex-extras.scm",(void*)f_1445},
{"f_1448regex-extras.scm",(void*)f_1448},
{"f_1432regex-extras.scm",(void*)f_1432},
{"f_1436regex-extras.scm",(void*)f_1436},
{"f_1421regex-extras.scm",(void*)f_1421},
{"f_642regex-extras.scm",(void*)f_642},
{"f_652regex-extras.scm",(void*)f_652},
{"f_677regex-extras.scm",(void*)f_677},
{"f_624regex-extras.scm",(void*)f_624},
{"f_636regex-extras.scm",(void*)f_636},
{"f_628regex-extras.scm",(void*)f_628},
{"f_635regex-extras.scm",(void*)f_635},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
