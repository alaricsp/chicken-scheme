/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-04-15 09:10
   Version 4.0.1 - SVN rev. 14255
   windows-mingw32-x86 [ manyargs dload ptables applyhook ]
   compiled 2009-04-15 on lenovo-1 (MINGW32_NT-6.0)
   command line: lolevel.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[135];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,99,104,101,99,107,45,98,108,111,99,107,32,120,51,49,32,108,111,99,51,50,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,99,104,101,99,107,45,103,101,110,101,114,105,99,45,115,116,114,117,99,116,117,114,101,32,120,55,51,32,108,111,99,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,120,49,48,55,32,46,32,108,111,99,49,48,56,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,116,121,112,101,114,114,32,120,50,49,49,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,10),40,110,111,115,105,122,101,114,114,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,16),40,115,105,122,101,114,114,32,97,114,103,115,50,53,53,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,99,104,101,99,107,110,49,32,110,50,53,55,32,110,109,97,120,50,53,56,32,111,102,102,50,53,57,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,47),40,99,104,101,99,107,110,50,32,110,50,54,54,32,110,109,97,120,50,54,55,32,110,109,97,120,50,50,54,56,32,111,102,102,49,50,54,57,32,111,102,102,50,50,55,48,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,50,56,49,32,116,111,50,56,50,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,50,51,53,32,110,50,52,54,32,102,111,102,102,115,101,116,50,52,55,32,116,111,102,102,115,101,116,50,52,56,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,102,102,115,101,116,50,51,57,32,37,110,50,51,50,52,48,49,32,37,102,111,102,102,115,101,116,50,51,51,52,48,50,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,111,102,102,115,101,116,50,51,56,32,37,110,50,51,50,52,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,50,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,40),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,50,50,51,32,116,111,50,50,52,32,46,32,116,109,112,50,50,50,50,50,53,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,52,53,52,32,105,52,54,48,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,52,50,57,41,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,52,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,52,55,48,52,55,51,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,52,55,56,52,56,50,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,52,56,56,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,20),40,112,111,105,110,116,101,114,45,108,105,107,101,63,32,120,52,57,55,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,53,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,53,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,53,49,55,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,16),40,102,95,50,50,52,55,32,97,53,50,54,53,50,57,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,53,50,50,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,53,51,53,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,53,52,48,32,112,50,53,52,49,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,32),40,112,111,105,110,116,101,114,45,111,102,102,115,101,116,32,97,53,52,55,53,53,49,32,97,53,52,54,53,53,50,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,108,105,103,110,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,53,54,56,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,53,56,52,32,116,97,103,53,56,53,41,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,34),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,54,48,54,32,46,32,116,109,112,54,48,53,54,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,54,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,54,52,53,32,46,32,105,110,100,101,120,54,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,54,53,56,32,46,32,105,110,100,101,120,54,53,57,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,25),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,54,55,49,32,121,54,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,23),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,54,55,55,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,16),40,108,111,99,97,116,105,118,101,63,32,120,54,56,49,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,97,54,56,55,54,57,49,32,97,54,56,54,54,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,97,54,57,56,55,48,50,32,97,54,57,55,55,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,97,55,48,57,55,49,51,32,97,55,48,56,55,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,97,55,50,48,55,50,52,32,97,55,49,57,55,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,97,55,51,49,55,51,53,32,97,55,51,48,55,51,54,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,97,55,52,50,55,52,54,32,97,55,52,49,55,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,97,55,53,51,55,53,55,32,97,55,53,50,55,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,97,55,54,52,55,54,56,32,97,55,54,51,55,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,12),40,97,50,54,50,52,32,120,56,53,57,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,17),40,97,50,54,52,48,32,120,56,54,51,32,105,56,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,56,53,54,32,100,97,116,97,56,53,55,41,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,12),40,97,50,54,54,53,32,120,56,56,51,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,56,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,12),40,97,50,54,57,57,32,120,57,48,50,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,56,56,57,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,57,49,48,32,120,57,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,19),40,118,101,99,116,111,114,45,108,105,107,101,63,32,120,57,49,57,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,57,51,52,41,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,57,51,57,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,57,53,48,32,46,32,97,114,103,115,57,53,49,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,35),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,57,54,50,32,46,32,116,109,112,57,54,49,57,54,51,41,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,27),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,116,121,112,101,32,120,57,57,48,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,29),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,108,101,110,103,116,104,32,120,57,57,53,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,45),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,115,108,111,116,45,115,101,116,33,32,120,49,48,48,48,32,105,49,48,48,49,32,121,49,48,48,50,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,12),40,100,111,108,111,111,112,49,48,50,49,41,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,22),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,49,48,49,52,41,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,23),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,49,48,51,56,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,18),40,102,95,51,48,51,53,32,97,49,48,52,55,49,48,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,56,52,32,105,49,48,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,13),40,101,118,105,99,116,32,120,49,48,53,55,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,49,48,52,50,32,46,32,97,108,108,111,99,97,116,111,114,49,48,52,51,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,49,54,54,32,105,49,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,13),40,101,118,105,99,116,32,120,49,49,51,52,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,52),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,49,49,49,48,32,112,116,114,49,49,49,49,32,46,32,108,105,109,105,116,49,49,49,50,41,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,18),40,102,95,51,50,56,56,32,97,49,50,48,49,49,50,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,50,53,32,105,49,50,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,15),40,114,101,108,101,97,115,101,32,120,49,50,49,50,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,37),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,49,49,57,54,32,46,32,114,101,108,101,97,115,101,114,49,49,57,55,41,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,54,54,32,105,49,50,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,101,118,105,99,116,32,120,49,50,52,57,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,19),40,111,98,106,101,99,116,45,115,105,122,101,32,120,49,50,52,51,41,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,51,52,48,32,105,49,51,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,120,49,51,49,51,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,49,50,57,54,32,46,32,116,109,112,49,50,57,53,49,50,57,55,41,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,52,56,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,25),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,97,108,115,116,49,51,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,35),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,49,51,54,56,32,112,114,111,99,49,51,54,57,41,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,111,111,107,32,46,32,97,114,103,115,49,51,56,55,41,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,97,110,100,108,101,114,33,32,112,114,111,99,49,51,56,53,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,34),40,117,110,98,111,117,110,100,45,118,97,114,105,97,98,108,101,45,118,97,108,117,101,32,46,32,118,97,108,49,51,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,20),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,49,51,57,57,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,27),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,49,52,48,52,32,120,49,52,48,53,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,23),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,49,52,49,48,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,30),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,49,52,49,53,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,19),40,97,51,54,49,56,32,120,49,48,48,55,32,105,49,48,48,56,41,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,15),40,97,51,54,52,50,32,97,56,52,51,56,52,55,41,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,15),40,97,51,54,53,50,32,97,56,51,50,56,51,54,41,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,15),40,97,51,54,54,50,32,97,56,50,49,56,50,53,41,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,15),40,97,51,54,55,50,32,97,56,49,48,56,49,52,41,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,15),40,97,51,54,56,50,32,97,56,48,49,56,48,53,41,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,15),40,97,51,54,57,50,32,97,55,57,50,55,57,54,41,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,15),40,97,51,55,48,50,32,97,55,56,51,55,56,55,41,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,15),40,97,51,55,49,50,32,97,55,55,52,55,55,56,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k3291 */
static C_word C_fcall stub1202(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1202(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k3038 */
static C_word C_fcall stub1048(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1048(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k3646 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub844(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub844(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3656 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub833(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub833(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3666 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub822(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub822(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3676 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub811(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub811(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3686 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub802(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub802(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3696 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub793(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub793(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3706 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub784(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub784(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_ret:
#undef return

return C_r;}

/* from k3716 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub775(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub775(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k2573 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub765(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub765(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2559 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub754(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub754(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2545 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub743(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub743(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2531 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub732(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub732(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2517 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub721(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub721(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2503 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub710(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub710(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2489 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub699(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub699(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2475 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub688(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub688(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2282 */
static C_word C_fcall stub561(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub561(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k2272 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub548(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub548(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from f_2247 in object->pointer in k1506 in k1503 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub527(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub527(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k2188 */
static C_word C_fcall stub479(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub479(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2181 */
static C_word C_fcall stub471(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub471(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1759 */
static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1731 */
static C_word C_fcall stub178(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub178(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1703 */
static C_word C_fcall stub159(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub159(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1675 */
static C_word C_fcall stub140(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub140(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3597)
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3570)
static void C_fcall f_3570(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3556)
static void C_ccall f_3556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3549)
static void C_ccall f_3549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_ccall f_3511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1538)
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_fcall f_3394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_fcall f_3465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_fcall f_3341(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3215)
static void C_fcall f_3215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3260)
static void C_fcall f_3260(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_fcall f_3049(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_fcall f_3063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_fcall f_3088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_fcall f_3106(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2934)
static void C_ccall f_2934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_fcall f_2939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_fcall f_2965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_fcall f_2980(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2921)
static void C_ccall f_2921(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2898)
static C_word C_fcall f_2898(C_word t0,C_word t1);
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2789)
static void C_ccall f_2789r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1612)
static void C_fcall f_1612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2692)
static void C_ccall f_2692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2620)
static void C_ccall f_2620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static C_word C_fcall f_2279(C_word *a,C_word t0);
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2103)
static void C_fcall f_2103(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2034)
static void C_fcall f_2034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_fcall f_2029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2024)
static void C_fcall f_2024(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1775)
static void C_fcall f_1775(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_fcall f_1841(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_fcall f_1806(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1813)
static void C_fcall f_1813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_fcall f_1790(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1784)
static void C_fcall f_1784(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1778)
static void C_fcall f_1778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_fcall f_1768(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1583)
static void C_fcall f_1583(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1510)
static void C_fcall f_1510(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_3570)
static void C_fcall trf_3570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3570(t0,t1);}

C_noret_decl(trf_1538)
static void C_fcall trf_1538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1538(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1538(t0,t1,t2);}

C_noret_decl(trf_3394)
static void C_fcall trf_3394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3394(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3394(t0,t1,t2);}

C_noret_decl(trf_3465)
static void C_fcall trf_3465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3465(t0,t1,t2);}

C_noret_decl(trf_3307)
static void C_fcall trf_3307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3307(t0,t1,t2);}

C_noret_decl(trf_3341)
static void C_fcall trf_3341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3341(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3341(t0,t1,t2);}

C_noret_decl(trf_3215)
static void C_fcall trf_3215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3215(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3215(t0,t1,t2);}

C_noret_decl(trf_3260)
static void C_fcall trf_3260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3260(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3260(t0,t1,t2);}

C_noret_decl(trf_3049)
static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3049(t0,t1);}

C_noret_decl(trf_3063)
static void C_fcall trf_3063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3063(t0,t1,t2);}

C_noret_decl(trf_3088)
static void C_fcall trf_3088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3088(t0,t1);}

C_noret_decl(trf_3106)
static void C_fcall trf_3106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3106(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3106(t0,t1,t2);}

C_noret_decl(trf_2939)
static void C_fcall trf_2939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2939(t0,t1,t2);}

C_noret_decl(trf_2965)
static void C_fcall trf_2965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2965(t0,t1);}

C_noret_decl(trf_2980)
static void C_fcall trf_2980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2980(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2980(t0,t1,t2);}

C_noret_decl(trf_1612)
static void C_fcall trf_1612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1612(t0,t1);}

C_noret_decl(trf_2103)
static void C_fcall trf_2103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2103(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2103(t0,t1,t2);}

C_noret_decl(trf_2148)
static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2148(t0,t1,t2);}

C_noret_decl(trf_2034)
static void C_fcall trf_2034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2034(t0,t1);}

C_noret_decl(trf_2029)
static void C_fcall trf_2029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2029(t0,t1,t2);}

C_noret_decl(trf_2024)
static void C_fcall trf_2024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2024(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2024(t0,t1,t2,t3);}

C_noret_decl(trf_1775)
static void C_fcall trf_1775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1775(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1775(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1841)
static void C_fcall trf_1841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1841(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1841(t0,t1,t2,t3);}

C_noret_decl(trf_1806)
static void C_fcall trf_1806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1806(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1806(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1813)
static void C_fcall trf_1813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1813(t0,t1);}

C_noret_decl(trf_1790)
static void C_fcall trf_1790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1790(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1790(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1784)
static void C_fcall trf_1784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1784(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1784(t0,t1,t2);}

C_noret_decl(trf_1778)
static void C_fcall trf_1778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1778(t0,t1);}

C_noret_decl(trf_1768)
static void C_fcall trf_1768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1768(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1768(t0,t1);}

C_noret_decl(trf_1583)
static void C_fcall trf_1583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1583(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1583(t0,t1,t2);}

C_noret_decl(trf_1510)
static void C_fcall trf_1510(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1510(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1510(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1297)){
C_save(t1);
C_rereclaim2(1297*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,135);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_h_intern(&lf[3],14,"\003syserror-hook");
lf[5]=C_h_intern(&lf[5],15,"\003syssignal-hook");
lf[6]=C_h_intern(&lf[6],11,"\000type-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[8]=C_h_intern(&lf[8],17,"\003syscheck-pointer");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[10]=C_h_intern(&lf[10],12,"move-memory!");
lf[11]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[12]=C_h_intern(&lf[12],9,"\003syserror");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[15]=C_h_intern(&lf[15],15,"\003sysbytevector\077");
lf[16]=C_h_intern(&lf[16],11,"object-copy");
lf[17]=C_h_intern(&lf[17],15,"\003sysmake-vector");
lf[18]=C_h_intern(&lf[18],8,"allocate");
lf[19]=C_h_intern(&lf[19],4,"free");
lf[20]=C_h_intern(&lf[20],8,"pointer\077");
lf[21]=C_h_intern(&lf[21],13,"pointer-like\077");
lf[22]=C_h_intern(&lf[22],16,"address->pointer");
lf[23]=C_h_intern(&lf[23],20,"\003sysaddress->pointer");
lf[24]=C_h_intern(&lf[24],17,"\003syscheck-integer");
lf[25]=C_h_intern(&lf[25],16,"pointer->address");
lf[26]=C_h_intern(&lf[26],20,"\003syspointer->address");
lf[27]=C_h_intern(&lf[27],17,"\003syscheck-special");
lf[28]=C_h_intern(&lf[28],12,"null-pointer");
lf[29]=C_h_intern(&lf[29],16,"\003sysnull-pointer");
lf[30]=C_h_intern(&lf[30],13,"null-pointer\077");
lf[31]=C_h_intern(&lf[31],15,"object->pointer");
lf[32]=C_h_intern(&lf[32],15,"pointer->object");
lf[33]=C_h_intern(&lf[33],9,"pointer=\077");
lf[34]=C_h_intern(&lf[34],14,"pointer-offset");
lf[35]=C_h_intern(&lf[35],13,"align-to-word");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[37]=C_h_intern(&lf[37],11,"tag-pointer");
lf[38]=C_h_intern(&lf[38],23,"\003sysmake-tagged-pointer");
lf[39]=C_h_intern(&lf[39],15,"tagged-pointer\077");
lf[40]=C_h_intern(&lf[40],11,"pointer-tag");
lf[41]=C_h_intern(&lf[41],13,"make-locative");
lf[42]=C_h_intern(&lf[42],17,"\003sysmake-locative");
lf[43]=C_h_intern(&lf[43],18,"make-weak-locative");
lf[44]=C_h_intern(&lf[44],13,"locative-set!");
lf[45]=C_h_intern(&lf[45],12,"locative-ref");
lf[46]=C_h_intern(&lf[46],16,"locative->object");
lf[47]=C_h_intern(&lf[47],9,"locative\077");
lf[48]=C_h_intern(&lf[48],15,"pointer-u8-set!");
lf[49]=C_h_intern(&lf[49],15,"pointer-s8-set!");
lf[50]=C_h_intern(&lf[50],16,"pointer-u16-set!");
lf[51]=C_h_intern(&lf[51],16,"pointer-s16-set!");
lf[52]=C_h_intern(&lf[52],16,"pointer-u32-set!");
lf[53]=C_h_intern(&lf[53],16,"pointer-s32-set!");
lf[54]=C_h_intern(&lf[54],16,"pointer-f32-set!");
lf[55]=C_h_intern(&lf[55],16,"pointer-f64-set!");
lf[56]=C_h_intern(&lf[56],14,"pointer-u8-ref");
lf[57]=C_h_intern(&lf[57],14,"pointer-s8-ref");
lf[58]=C_h_intern(&lf[58],15,"pointer-u16-ref");
lf[59]=C_h_intern(&lf[59],15,"pointer-s16-ref");
lf[60]=C_h_intern(&lf[60],15,"pointer-u32-ref");
lf[61]=C_h_intern(&lf[61],15,"pointer-s32-ref");
lf[62]=C_h_intern(&lf[62],15,"pointer-f32-ref");
lf[63]=C_h_intern(&lf[63],15,"pointer-f64-ref");
lf[64]=C_h_intern(&lf[64],8,"extended");
lf[66]=C_h_intern(&lf[66],16,"extend-procedure");
lf[67]=C_h_intern(&lf[67],19,"\003sysdecorate-lambda");
lf[68]=C_h_intern(&lf[68],17,"\003syscheck-closure");
lf[69]=C_h_intern(&lf[69],19,"extended-procedure\077");
lf[70]=C_h_intern(&lf[70],21,"\003syslambda-decoration");
lf[71]=C_h_intern(&lf[71],14,"procedure-data");
lf[72]=C_h_intern(&lf[72],19,"set-procedure-data!");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[74]=C_h_intern(&lf[74],10,"block-set!");
lf[75]=C_h_intern(&lf[75],14,"\003sysblock-set!");
lf[76]=C_h_intern(&lf[76],9,"block-ref");
lf[77]=C_h_intern(&lf[77],12,"vector-like\077");
lf[78]=C_h_intern(&lf[78],15,"number-of-slots");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[80]=C_h_intern(&lf[80],15,"number-of-bytes");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[82]=C_h_intern(&lf[82],20,"make-record-instance");
lf[83]=C_h_intern(&lf[83],18,"\003sysmake-structure");
lf[84]=C_h_intern(&lf[84],16,"record-instance\077");
lf[85]=C_h_intern(&lf[85],20,"record-instance-type");
lf[86]=C_h_intern(&lf[86],22,"record-instance-length");
lf[87]=C_h_intern(&lf[87],25,"record-instance-slot-set!");
lf[88]=C_h_intern(&lf[88],15,"\003syscheck-range");
lf[89]=C_h_intern(&lf[89],20,"record-instance-slot");
lf[90]=C_h_intern(&lf[90],14,"record->vector");
lf[91]=C_h_intern(&lf[91],15,"object-evicted\077");
lf[92]=C_h_intern(&lf[92],12,"object-evict");
lf[93]=C_h_intern(&lf[93],15,"hash-table-set!");
lf[94]=C_h_intern(&lf[94],19,"\003sysundefined-value");
lf[95]=C_h_intern(&lf[95],22,"hash-table-ref/default");
lf[96]=C_h_intern(&lf[96],15,"make-hash-table");
lf[97]=C_h_intern(&lf[97],3,"eq\077");
lf[98]=C_h_intern(&lf[98],24,"object-evict-to-location");
lf[99]=C_h_intern(&lf[99],24,"\003sysset-pointer-address!");
lf[100]=C_h_intern(&lf[100],6,"signal");
lf[101]=C_h_intern(&lf[101],24,"make-composite-condition");
lf[102]=C_h_intern(&lf[102],23,"make-property-condition");
lf[103]=C_h_intern(&lf[103],5,"evict");
lf[104]=C_h_intern(&lf[104],5,"limit");
lf[105]=C_h_intern(&lf[105],3,"exn");
lf[106]=C_h_intern(&lf[106],8,"location");
lf[107]=C_h_intern(&lf[107],7,"message");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[109]=C_h_intern(&lf[109],9,"arguments");
lf[110]=C_h_intern(&lf[110],14,"object-release");
lf[111]=C_h_intern(&lf[111],11,"object-size");
lf[112]=C_h_intern(&lf[112],14,"object-unevict");
lf[113]=C_h_intern(&lf[113],15,"\003sysmake-string");
lf[114]=C_h_intern(&lf[114],14,"object-become!");
lf[115]=C_h_intern(&lf[115],11,"\003sysbecome!");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[117]=C_h_intern(&lf[117],16,"mutate-procedure");
lf[119]=C_h_intern(&lf[119],35,"set-invalid-procedure-call-handler!");
lf[120]=C_h_intern(&lf[120],31,"\003sysinvalid-procedure-call-hook");
lf[121]=C_h_intern(&lf[121],26,"\003syslast-invalid-procedure");
lf[122]=C_h_intern(&lf[122],22,"unbound-variable-value");
lf[123]=C_h_intern(&lf[123],31,"\003sysunbound-variable-value-hook");
lf[124]=C_h_intern(&lf[124],10,"global-ref");
lf[125]=C_h_intern(&lf[125],11,"global-set!");
lf[126]=C_h_intern(&lf[126],13,"global-bound\077");
lf[127]=C_h_intern(&lf[127],32,"\003syssymbol-has-toplevel-binding\077");
lf[128]=C_h_intern(&lf[128],20,"global-make-unbound!");
lf[129]=C_h_intern(&lf[129],28,"\003sysarbitrary-unbound-symbol");
lf[130]=C_h_intern(&lf[130],18,"getter-with-setter");
lf[131]=C_h_intern(&lf[131],13,"\003sysblock-ref");
lf[132]=C_h_intern(&lf[132],15,"pointer-s6-set!");
lf[133]=C_h_intern(&lf[133],17,"register-feature!");
lf[134]=C_h_intern(&lf[134],7,"lolevel");
C_register_lf2(lf,135,create_ptable());
t2=C_mutate(&lf[0] /* (set! c422 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1503 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 74   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[133]+1)))(3,*((C_word*)lf[133]+1),t2,lf[134]);}

/* k1506 in k1503 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[84],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! check-block ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1510,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[4] /* (set! check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1583,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! check-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1768,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
t6=lf[11];
t7=C_mutate((C_word*)lf[10]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1773,a[2]=t5,a[3]=t6,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[16]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[18]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2178,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[19]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2185,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[20]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2195,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[21]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[22]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2207,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[25]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2216,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[28]+1 /* (set! null-pointer ...) */,*((C_word*)lf[29]+1));
t16=C_mutate((C_word*)lf[30]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2226,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[31]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[32]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2250,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[33]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2256,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[34]+1 /* (set! pointer-offset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2265,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[35]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2285,a[2]=t21,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[37]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2317,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[39]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2332,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[40]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[41]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[43]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2423,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[44]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2452,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 344  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t29,t30,*((C_word*)lf[44]+1));}

/* k2455 in k1506 in k1503 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2457,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[46]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[47]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2462,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[48]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2468,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[49]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[50]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[51]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2510,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[52]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2524,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[53]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2538,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[54]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2552,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[55]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2566,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3713,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 361  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t13,t14,*((C_word*)lf[48]+1));}

/* a3712 in k2455 in k1506 in k1503 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3713,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub775(C_SCHEME_UNDEFINED,t3));}

/* k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=C_mutate((C_word*)lf[56]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3703,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 366  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[49]+1));}

/* a3702 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3703,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub784(C_SCHEME_UNDEFINED,t3));}

/* k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3693,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 371  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[50]+1));}

/* a3692 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3693,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub793(C_SCHEME_UNDEFINED,t3));}

/* k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2590,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2594,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3683,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 376  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[132]+1));}

/* a3682 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3683,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub802(C_SCHEME_UNDEFINED,t3));}

/* k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3673,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 381  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[52]+1));}

/* a3672 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3673,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub811(t3,t4));}

/* k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2598,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3663,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 386  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[53]+1));}

/* a3662 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3663,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub822(t3,t4));}

/* k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3653,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 391  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[54]+1));}

/* a3652 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3653,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub833(t3,t4));}

/* k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2606,2,t0,t1);}
t2=C_mutate((C_word*)lf[62]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3643,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 396  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t3,t4,*((C_word*)lf[55]+1));}

/* a3642 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3643,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub844(t3,t4));}

/* k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2610,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=(C_word)C_a_i_vector(&a,1,lf[64]);
t4=C_mutate(&lf[65] /* (set! xproc-tag ...) */,t3);
t5=C_mutate((C_word*)lf[66]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2616,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[69]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[71]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2682,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[66]+1);
t9=C_mutate((C_word*)lf[72]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2716,a[2]=t8,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[74]+1 /* (set! block-set! ...) */,*((C_word*)lf[75]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 440  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t11,*((C_word*)lf[131]+1),*((C_word*)lf[75]+1));}

/* k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[77]+1 /* (set! vector-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2736,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[78]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[80]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2758,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[82]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[84]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2789,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[85]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2833,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[86]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[87]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2855,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 490  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[130]+1)))(4,*((C_word*)lf[130]+1),t11,t12,*((C_word*)lf[87]+1));}

/* a3618 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3619,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3623,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 492  ##sys#check-generic-structure */
f_1583(t4,t2,(C_word)C_a_i_list(&a,1,lf[89]));}

/* k3621 in a3618 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 493  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[88]+1)))(6,*((C_word*)lf[88]+1),t2,((C_word*)t0)[4],C_fix(0),t4,lf[89]);}

/* k3624 in k3621 in a3618 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate((C_word*)lf[90]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[91]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2921,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[92]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2924,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[98]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3042,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[110]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3206,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[111]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[112]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3382,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[114]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3511,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[117]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t12=lf[118] /* ipc-hook-0 */ =C_SCHEME_FALSE;;
t13=C_mutate((C_word*)lf[119]+1 /* (set! set-invalid-procedure-call-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3552,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[122]+1 /* (set! unbound-variable-value ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3565,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[124]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3582,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[125]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[126]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3597,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[128]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3606,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3606,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[128]);
t4=(C_word)C_slot(lf[129],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3597,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[126]);
/* lolevel.scm: 678  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t1,t2);}

/* global-set! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3588,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[125]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3582,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[124]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3565r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3565r(t0,t1,t2);}}

static void C_ccall f_3565r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3570,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_3570(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_3570(t4,C_SCHEME_FALSE);}}

/* k3568 in unbound-variable-value in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[123]+1 /* (set! unbound-variable-value-hook ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* set-invalid-procedure-call-handler! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3552,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3556,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 654  ##sys#check-closure */
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[119]);}

/* k3554 in set-invalid-procedure-call-handler! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
t2=C_mutate(&lf[118] /* (set! ipc-hook-0 ...) */,((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[120]+1 /* (set! invalid-procedure-call-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k3554 in set-invalid-procedure-call-handler! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3559r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3559r(t0,t1,t2);}}

static void C_ccall f_3559r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 658  ipc-hook-0 */
((C_proc4)C_retrieve_proc(lf[118]))(4,lf[118],t1,*((C_word*)lf[121]+1),t2);}

/* mutate-procedure in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3520,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3524,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 640  ##sys#check-closure */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[117]);}

/* k3522 in mutate-procedure in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 641  ##sys#check-closure */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[117]);}

/* k3525 in k3522 in mutate-procedure in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 644  ##sys#make-vector */
t5=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3532 in k3525 in k3522 in mutate-procedure in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3537,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3549,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 645  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3547 in k3532 in k3525 in k3522 in mutate-procedure in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3549,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 645  ##sys#become! */
t4=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3535 in k3532 in k3525 in k3522 in mutate-procedure in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3511,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3515,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_i_check_list_2(t4,lf[114]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1538,a[2]=t4,a[3]=t7,a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_1538(t9,t3,t4);}

/* loop in object-become! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_1538(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1538,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_pair_2(t4,lf[114]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1560,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t4);
/* lolevel.scm: 115  ##sys#check-block */
f_1510(t6,t7,(C_word)C_a_i_list(&a,1,lf[114]));}
else{
/* lolevel.scm: 119  ##sys#signal-hook */
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[6],lf[114],lf[116],((C_word*)t0)[2]);}}}

/* k1558 in loop in object-become! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* lolevel.scm: 116  ##sys#check-block */
f_1510(t2,t3,(C_word)C_a_i_list(&a,1,lf[114]));}

/* k1561 in k1558 in loop in object-become! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* lolevel.scm: 117  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1538(t3,((C_word*)t0)[2],t2);}

/* k3513 in object-become! in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 637  ##sys#become! */
t2=*((C_word*)lf[115]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3382r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3382r(t0,t1,t2,t3);}}

static void C_ccall f_3382r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3386,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3386(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3386(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 608  make-hash-table */
t3=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[97]+1));}

/* k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3389,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3394,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li81),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3394(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3394,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 612  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3410,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 615  ##sys#make-string */
t4=*((C_word*)lf[113]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 620  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 625  ##sys#make-vector */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k3451 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 626  hash-table-set! */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k3454 in k3451 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li80),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3465(t7,t2,t3);}

/* doloop1340 in k3454 in k3451 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3465,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3486,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 629  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3394(t5,t3,t4);}}

/* k3484 in doloop1340 in k3454 in k3451 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3465(t4,((C_word*)t0)[2],t3);}

/* k3457 in k3454 in k3451 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3437 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3442,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 621  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3440 in k3437 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3421 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3423,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3426,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 616  hash-table-set! */
t4=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k3424 in k3421 in k3408 in copy in k3387 in k3384 in object-unevict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3298,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3302,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 591  make-hash-table */
t4=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[97]+1));}

/* k3300 in object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3302,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=t1,a[3]=t3,a[4]=((C_word)li78),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3307(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k3300 in object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3307,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 594  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k3318 in evict in k3300 in object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3320,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 598  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t3,t2);}
else{
t4=t3;
f_3377(2,t4,(C_word)C_bytes(t2));}}}

/* k3375 in k3318 in evict in k3300 in object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 600  hash-table-set! */
t6=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k3327 in k3375 in k3318 in evict in k3300 in object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_3332(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li77),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_3341(t9,t2,t5);}}

/* doloop1266 in k3327 in k3375 in k3318 in evict in k3300 in object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3341(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3341,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3363,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 604  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3307(t5,t3,t4);}}

/* k3361 in doloop1266 in k3327 in k3375 in k3318 in evict in k3300 in object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_3341(t5,((C_word*)t0)[2],t4);}

/* k3330 in k3327 in k3375 in k3318 in evict in k3300 in object-size in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-release in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3206r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3206r(t0,t1,t2,t3);}}

static void C_ccall f_3206r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3288,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3215,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li75),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3215(t11,t1,t2);}

/* release in object-release in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3215(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3215,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3244,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_3244(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_3260(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* doloop1225 in release in object-release in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3260(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3260,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3270,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 587  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3215(t5,t3,t4);}}

/* k3268 in doloop1225 in release in object-release in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3260(t3,((C_word*)t0)[2],t2);}

/* k3242 in release in object-release in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 588  ##sys#address->pointer */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k3249 in k3242 in release in object-release in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 588  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_3288 in object-release in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3288,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub1202(C_SCHEME_UNDEFINED,t3));}

/* object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3042r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3042r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3042r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3046,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 535  ##sys#check-special */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[98]);}

/* k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[98]);
t5=t2;
f_3049(t5,t3);}
else{
t3=t2;
f_3049(t3,C_SCHEME_FALSE);}}

/* k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3049(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3049,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3195,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 540  ##sys#pointer->address */
t6=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k3193 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 540  ##sys#address->pointer */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 541  make-hash-table */
t3=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[97]+1));}

/* k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3058,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3063(t6,t2,((C_word*)t0)[2]);}

/* evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3063,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 545  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 549  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t3,t2);}
else{
t4=t3;
f_3188(2,t4,(C_word)C_bytes(t2));}}}

/* k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3188,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3085,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3176,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 556  make-property-condition */
t9=*((C_word*)lf[102]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[105],lf[106],lf[98],lf[107],lf[108],lf[109],t8);}
else{
t6=t3;
f_3085(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_3085(2,t4,C_SCHEME_UNDEFINED);}}

/* k3174 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3180,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 560  make-property-condition */
t3=*((C_word*)lf[102]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[103],lf[104],((C_word*)((C_word*)t0)[2])[1]);}

/* k3178 in k3174 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 555  make-composite-condition */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3170 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 554  signal */
t2=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3083 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3085,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3088,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[8]))){
t4=*((C_word*)lf[94]+1);
t5=t3;
f_3088(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_3088(t4,C_SCHEME_UNDEFINED);}}

/* k3086 in k3083 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3088,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3091,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3145,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 563  ##sys#pointer->address */
t4=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3143 in k3086 in k3083 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3145,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 563  ##sys#set-pointer-address! */
t3=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3089 in k3086 in k3083 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 564  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k3092 in k3089 in k3086 in k3083 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_3097(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li70),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_3106(t9,t2,t5);}}

/* doloop1166 in k3092 in k3089 in k3086 in k3083 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_3106(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3106,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3127,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 568  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3063(t5,t3,t4);}}

/* k3125 in doloop1166 in k3092 in k3089 in k3086 in k3083 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3106(t4,((C_word*)t0)[2],t3);}

/* k3095 in k3092 in k3089 in k3086 in k3083 in k3186 in k3071 in evict in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3056 in k3053 in k3050 in k3047 in k3044 in object-evict-to-location in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 570  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2924r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2924r(t0,t1,t2,t3);}}

static void C_ccall f_2924r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3035,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2931,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 516  make-hash-table */
t7=*((C_word*)lf[96]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,*((C_word*)lf[97]+1));}

/* k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 517  ##sys#check-closure */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[92]);}

/* k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2934,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2939(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_2939(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2939,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 520  hash-table-ref/default */
t4=*((C_word*)lf[95]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2947 in evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2949,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 523  align-to-word */
((C_proc3)C_retrieve_proc(*((C_word*)lf[35]+1)))(3,*((C_word*)lf[35]+1),t3,t2);}
else{
t4=t3;
f_2958(2,t4,(C_word)C_bytes(t2));}}}

/* k2956 in k2947 in evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 524  allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2960 in k2956 in k2947 in evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t4=*((C_word*)lf[94]+1);
t5=t3;
f_2965(t5,(C_word)C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2965(t4,C_SCHEME_UNDEFINED);}}

/* k2963 in k2960 in k2956 in k2947 in evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_2965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2965,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 526  hash-table-set! */
t3=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2966 in k2963 in k2960 in k2956 in k2947 in evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2971(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li67),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2980(t9,t2,t5);}}

/* doloop1084 in k2966 in k2963 in k2960 in k2956 in k2947 in evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_2980(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2980,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3001,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 531  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2939(t5,t3,t4);}}

/* k2999 in doloop1084 in k2966 in k2963 in k2960 in k2956 in k2947 in evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2980(t4,((C_word*)t0)[2],t3);}

/* k2969 in k2966 in k2963 in k2960 in k2956 in k2947 in evict in k2932 in k2929 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3035 in object-evict in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3035,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub1048(t3,t4));}

/* object-evicted? in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2921(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2921,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* record->vector in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2883,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2887,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 498  ##sys#check-generic-structure */
f_1583(t3,t2,(C_word)C_a_i_list(&a,1,lf[90]));}

/* k2885 in record->vector in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 500  ##sys#make-vector */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2891 in k2885 in record->vector in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2898,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2898(t2,C_fix(0)));}

/* doloop1021 in k2891 in k2885 in record->vector in k2879 in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static C_word C_fcall f_2898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance-slot-set! in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2855,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2859,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 485  ##sys#check-generic-structure */
f_1583(t5,t2,(C_word)C_a_i_list(&a,1,lf[87]));}

/* k2857 in record-instance-slot-set! in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm: 486  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[88]+1)))(6,*((C_word*)lf[88]+1),t2,((C_word*)t0)[5],C_fix(0),t4,lf[87]);}

/* k2860 in k2857 in record-instance-slot-set! in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[3],t2,((C_word*)t0)[2]));}

/* record-instance-length in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2842,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2846,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 481  ##sys#check-generic-structure */
f_1583(t3,t2,(C_word)C_a_i_list(&a,1,lf[86]));}

/* k2844 in record-instance-length in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_difference(t2,C_fix(1)));}

/* record-instance-type in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2833,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2837,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 477  ##sys#check-generic-structure */
f_1583(t3,t2,(C_word)C_a_i_list(&a,1,lf[85]));}

/* k2835 in record-instance-type in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* record-instance? in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2789(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2789r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2789r(t0,t1,t2,t3);}}

static void C_ccall f_2789r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2793,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2793(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2793(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2791 in record-instance? in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t1,t5));}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* make-record-instance in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2780r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2780r(t0,t1,t2,t3);}}

static void C_ccall f_2780r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[82]);
C_apply(5,0,t1,*((C_word*)lf[83]+1),t2,t3);}

/* number-of-bytes in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2758,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 451  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[6],lf[80],lf[81],t2);}}

/* number-of-slots in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2749,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2753,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_list(&a,1,lf[78]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1612,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t4))){
t7=(C_word)C_specialp(t4);
t8=(C_truep(t7)?t7:(C_word)C_byteblockp(t4));
t9=t6;
f_1612(t9,(C_word)C_i_not(t8));}
else{
t7=t6;
f_1612(t7,C_SCHEME_FALSE);}}

/* k1610 in number-of-slots in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_fcall f_1612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2753(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[3]):C_SCHEME_FALSE);
/* lolevel.scm: 133  ##sys#signal-hook */
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[6],t3,lf[79],((C_word*)t0)[2]);}}

/* k2751 in number-of-slots in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* vector-like? in k2732 in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2736,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_specialp(t2);
t4=(C_truep(t3)?t3:(C_word)C_byteblockp(t2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_not(t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* set-procedure-data! in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2716,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2720,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 429  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k2718 in set-procedure-data! in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 432  ##sys#signal-hook */
t3=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[6],lf[72],lf[73],((C_word*)t0)[3]);}}

/* procedure-data in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2682,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2692,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 414  ##sys#lambda-decoration */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2699 in procedure-data in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2700,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2690 in procedure-data in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2651,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=t2;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2666,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 414  ##sys#lambda-decoration */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t3,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2665 in extended-procedure? in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2666,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2662 in extended-procedure? in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2616,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2620,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 407  ##sys#check-closure */
t5=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[66]);}

/* k2618 in extend-procedure in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2625,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2641,a[2]=((C_word*)t0)[4],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 408  ##sys#decorate-lambda */
t4=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2640 in k2618 in extend-procedure in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2641,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[65],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2624 in k2618 in extend-procedure in k2608 in k2604 in k2600 in k2596 in k2592 in k2588 in k2584 in k2580 in k2455 in k1506 in k1503 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2625,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[65],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-f64-set! in k2455 in k1506 in k1503 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2566,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub765(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-f32-set! in k2455 in k1506 in k1503 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2552,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub754(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s32-set! in k2455 in k1506 in k1503 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2538,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub743(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u32-set! in k2455 in k1506 in k1503 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2524,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub732(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s16-set! in k2455 in k1506 in k1503 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2510,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub721(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u16-set! in k2455 in k1506 in k1503 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2496,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub710(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s8-set! in k2455 in k1506 in k1503 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2482,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub699(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u8-set! in k2455 in k1506 in k1503 */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2468,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub688(C_SCHEME_UNDEFINED,t4,t5));}

/* locative? in k2455 in k1506 in k1503 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2462,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k2455 in k1506 in k1503 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2459,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1506 in k1503 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2452,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1506 in k1503 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2423r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2423r(t0,t1,t2,t3);}}

static void C_ccall f_2423r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2431,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2431(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2431(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2429 in make-weak-locative in k1506 in k1503 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 341  ##sys#make-locative */
t2=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[43]);}

/* make-locative in k1506 in k1503 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2394r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2394r(t0,t1,t2,t3);}}

static void C_ccall f_2394r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2402,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2402(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2402(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2400 in make-locative in k1506 in k1503 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 338  ##sys#make-locative */
t2=*((C_word*)lf[42]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[41]);}

/* pointer-tag in k1506 in k1503 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2376,3,t0,t1,t2);}
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 315  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[40],t2);}}

/* tagged-pointer? in k1506 in k1503 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2332r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2332r(t0,t1,t2,t3);}}

static void C_ccall f_2332r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2336,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2336(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2336(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2334 in tagged-pointer? in k1506 in k1503 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_blockp(((C_word*)t0)[3]))){
if(C_truep((C_word)C_taggedpointerp(((C_word*)t0)[3]))){
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_equalp(t1,t3));}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* tag-pointer in k1506 in k1503 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2317,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 300  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2319 in tag-pointer in k1506 in k1503 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_2324(2,t5,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 303  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t2,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[37],((C_word*)t0)[2]);}}

/* k2322 in k2319 in tag-pointer in k1506 in k1503 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* align-to-word in k1506 in k1503 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2285,3,t0,t1,t2);}
if(C_truep((C_word)C_i_integerp(t2))){
/* lolevel.scm: 288  align */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,f_2279(C_a_i(&a,6),t2));}
else{
t3=t2;
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2312,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 290  ##sys#pointer->address */
t6=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* lolevel.scm: 292  ##sys#signal-hook */
t5=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[6],lf[35],lf[36],t2);}}}

/* k2310 in align-to-word in k1506 in k1503 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=f_2279(C_a_i(&a,6),t1);
/* lolevel.scm: 290  ##sys#address->pointer */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k1506 in k1503 */
static C_word C_fcall f_2279(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)C_i_foreign_integer_argumentp(t1);
return((C_word)stub561(t2,t3));}

/* pointer-offset in k1506 in k1503 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2265,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub548(t4,t5,t6));}

/* pointer=? in k1506 in k1503 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2256,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2260,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 276  ##sys#check-special */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[33]);}

/* k2258 in pointer=? in k1506 in k1503 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 277  ##sys#check-special */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[33]);}

/* k2261 in k2258 in pointer=? in k1506 in k1503 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k1506 in k1503 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2250,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 272  ##sys#check-pointer */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[32]);}

/* k2252 in pointer->object in k1506 in k1503 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k1506 in k1503 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2239,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2247,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_2247 in object->pointer in k1506 in k1503 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2247,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub527(t3,t2));}

/* null-pointer? in k1506 in k1503 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2226,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2230,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 264  ##sys#check-special */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[30]);}

/* k2228 in null-pointer? in k1506 in k1503 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 265  ##sys#pointer->address */
t3=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2235 in k2228 in null-pointer? in k1506 in k1503 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k1506 in k1503 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2216,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2220,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 258  ##sys#check-special */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[25]);}

/* k2218 in pointer->address in k1506 in k1503 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 259  ##sys#pointer->address */
t2=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k1506 in k1503 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2207,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2211,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 254  ##sys#check-integer */
t4=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[22]);}

/* k2209 in address->pointer in k1506 in k1503 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 255  ##sys#address->pointer */
t2=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer-like? in k1506 in k1503 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2201,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE));}

/* pointer? in k1506 in k1503 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2195,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_anypointerp(t2):C_SCHEME_FALSE));}

/* free in k1506 in k1503 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2185,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub479(C_SCHEME_UNDEFINED,t3));}

/* allocate in k1506 in k1503 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2178,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub471(t3,t4));}

/* object-copy in k1506 in k1503 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2097,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2103,a[2]=t4,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2103(t6,t1,t2);}

/* copy in object-copy in k1506 in k1503 */
static void C_fcall f_2103(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2103,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 232  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 236  ##sys#make-vector */
t6=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2131 in copy in object-copy in k1506 in k1503 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2136,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_2136(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2148,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li14),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_2148(t10,t3,t6);}}

/* doloop454 in k2131 in copy in object-copy in k1506 in k1503 */
static void C_fcall f_2148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2148,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2169,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 240  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2103(t5,t3,t4);}}

/* k2167 in doloop454 in k2131 in copy in object-copy in k1506 in k1503 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2148(t4,((C_word*)t0)[2],t3);}

/* k2134 in k2131 in copy in object-copy in k1506 in k1503 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* move-memory! in k1506 in k1503 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr4r,(void*)f_1773r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1773r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1773r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(19);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word)li9),tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=t5,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2029,a[2]=t6,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2034,a[2]=t7,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n237409 */
t9=t8;
f_2034(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset238405 */
t11=t7;
f_2029(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset239400 */
t13=t6;
f_2024(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body235245 */
t15=t5;
f_1775(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n237 in move-memory! in k1506 in k1503 */
static void C_fcall f_2034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2034,NULL,2,t0,t1);}
/* def-foffset238405 */
t2=((C_word*)t0)[2];
f_2029(t2,t1,C_SCHEME_FALSE);}

/* def-foffset238 in move-memory! in k1506 in k1503 */
static void C_fcall f_2029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2029,NULL,3,t0,t1,t2);}
/* def-toffset239400 */
t3=((C_word*)t0)[2];
f_2024(t3,t1,t2,C_fix(0));}

/* def-toffset239 in move-memory! in k1506 in k1503 */
static void C_fcall f_2024(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2024,NULL,4,t0,t1,t2,t3);}
/* body235245 */
t4=((C_word*)t0)[2];
f_1775(t4,t1,t2,t3,C_fix(0));}

/* body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1775(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1775,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1790,a[2]=t6,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1806,a[2]=t6,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t8,a[6]=t7,a[7]=t5,a[8]=t3,a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[2],a[12]=((C_word*)t0)[3],tmp=(C_word)a,a+=13,tmp);
/* lolevel.scm: 196  ##sys#check-block */
f_1510(t9,((C_word*)t0)[5],(C_word)C_a_i_list(&a,1,lf[10]));}

/* k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* lolevel.scm: 197  ##sys#check-block */
f_1510(t2,((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,lf[10]));}

/* k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1836,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t3,a[10]=((C_word*)t0)[12],a[11]=((C_word)li8),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_1841(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1841(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1841,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 201  move */
t19=t1;
t20=t5;
t21=t3;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
/* lolevel.scm: 202  typerr */
f_1768(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 205  move */
t19=t1;
t20=t2;
t21=t5;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
/* lolevel.scm: 206  typerr */
f_1768(t1,t3);}}
else{
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=t3;
t8=(C_truep((C_word)C_blockp(t7))?(C_word)C_anypointerp(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:(C_word)C_locativep(t7));
if(C_truep(t9)){
t10=((C_word*)t0)[7];
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_1919(2,t12,t10);}
else{
/* lolevel.scm: 209  nosizerr */
t12=((C_word*)t0)[4];
f_1778(t12,t11);}}
else{
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 210  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t10,t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 214  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t7,t2);}}}}

/* k1959 in move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=((C_word*)t0)[9];
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:(C_word)C_locativep(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[5];
t9=(C_truep(t8)?t8:t3);
/* lolevel.scm: 217  checkn1 */
t10=((C_word*)t0)[4];
f_1790(t10,t7,t9,t3,((C_word*)t0)[6]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 218  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t7,((C_word*)t0)[9]);}}
else{
/* lolevel.scm: 224  typerr */
f_1768(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k1991 in k1959 in move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
/* lolevel.scm: 219  checkn2 */
t7=((C_word*)t0)[3];
f_1806(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* lolevel.scm: 222  typerr */
f_1768(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k2001 in k1991 in k1959 in move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub197(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1981 in k1959 in move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub159(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1926 in move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1942(2,t6,t4);}
else{
/* lolevel.scm: 211  nosizerr */
t6=((C_word*)t0)[3];
f_1778(t6,t5);}}
else{
/* lolevel.scm: 213  typerr */
f_1768(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1940 in k1926 in move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 211  checkn1 */
t3=((C_word*)t0)[4];
f_1790(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1936 in k1926 in move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub178(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1917 in move in k1834 in k1831 in body235 in move-memory! in k1506 in k1503 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub140(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1806(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1806,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1813,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_fixnum_difference(t4,t6);
t10=t7;
f_1813(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1813(t9,C_SCHEME_FALSE);}}

/* k1811 in checkn2 in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1813,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* lolevel.scm: 194  sizerr */
t2=((C_word*)t0)[4];
f_1784(t2,((C_word*)t0)[6],(C_word)C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* checkn1 in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1790(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1790,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
/* lolevel.scm: 189  sizerr */
t6=((C_word*)t0)[2];
f_1784(t6,t1,(C_word)C_a_i_list(&a,2,t2,t3));}}

/* sizerr in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1784(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1784,NULL,3,t0,t1,t2);}
C_apply(8,0,t1,*((C_word*)lf[12]+1),lf[10],lf[14],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* nosizerr in body235 in move-memory! in k1506 in k1503 */
static void C_fcall f_1778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1778,NULL,2,t0,t1);}
/* lolevel.scm: 181  ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[10],lf[13],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* typerr in k1506 in k1503 */
static void C_fcall f_1768(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1768,NULL,2,t1,t2);}
/* lolevel.scm: 172  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[10],t2);}

/* ##sys#check-pointer in k1506 in k1503 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1634r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1634r(t0,t1,t2,t3);}}

static void C_ccall f_1634r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_anypointerp(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
/* lolevel.scm: 139  ##sys#error-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[3]+1)))(6,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),t7,lf[9],t2);}}

/* ##sys#check-generic-structure in k1506 in k1503 */
static void C_fcall f_1583(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1583,NULL,3,t1,t2,t3);}
t4=t2;
t5=(C_truep((C_word)C_blockp(t4))?(C_word)C_structurep(t4):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_pairp(t3);
t7=(C_truep(t6)?(C_word)C_i_car(t3):C_SCHEME_FALSE);
/* lolevel.scm: 125  ##sys#signal-hook */
t8=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t1,lf[6],t7,lf[7],t2);}}

/* ##sys#check-block in k1506 in k1503 */
static void C_fcall f_1510(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1510,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_car(t3):C_SCHEME_FALSE);
/* lolevel.scm: 104  ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),t5,t2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[216] = {
{"toplevel:lolevel_scm",(void*)C_lolevel_toplevel},
{"f_1505:lolevel_scm",(void*)f_1505},
{"f_1508:lolevel_scm",(void*)f_1508},
{"f_2457:lolevel_scm",(void*)f_2457},
{"f_3713:lolevel_scm",(void*)f_3713},
{"f_2582:lolevel_scm",(void*)f_2582},
{"f_3703:lolevel_scm",(void*)f_3703},
{"f_2586:lolevel_scm",(void*)f_2586},
{"f_3693:lolevel_scm",(void*)f_3693},
{"f_2590:lolevel_scm",(void*)f_2590},
{"f_3683:lolevel_scm",(void*)f_3683},
{"f_2594:lolevel_scm",(void*)f_2594},
{"f_3673:lolevel_scm",(void*)f_3673},
{"f_2598:lolevel_scm",(void*)f_2598},
{"f_3663:lolevel_scm",(void*)f_3663},
{"f_2602:lolevel_scm",(void*)f_2602},
{"f_3653:lolevel_scm",(void*)f_3653},
{"f_2606:lolevel_scm",(void*)f_2606},
{"f_3643:lolevel_scm",(void*)f_3643},
{"f_2610:lolevel_scm",(void*)f_2610},
{"f_2734:lolevel_scm",(void*)f_2734},
{"f_3619:lolevel_scm",(void*)f_3619},
{"f_3623:lolevel_scm",(void*)f_3623},
{"f_3626:lolevel_scm",(void*)f_3626},
{"f_2881:lolevel_scm",(void*)f_2881},
{"f_3606:lolevel_scm",(void*)f_3606},
{"f_3597:lolevel_scm",(void*)f_3597},
{"f_3588:lolevel_scm",(void*)f_3588},
{"f_3582:lolevel_scm",(void*)f_3582},
{"f_3565:lolevel_scm",(void*)f_3565},
{"f_3570:lolevel_scm",(void*)f_3570},
{"f_3552:lolevel_scm",(void*)f_3552},
{"f_3556:lolevel_scm",(void*)f_3556},
{"f_3559:lolevel_scm",(void*)f_3559},
{"f_3520:lolevel_scm",(void*)f_3520},
{"f_3524:lolevel_scm",(void*)f_3524},
{"f_3527:lolevel_scm",(void*)f_3527},
{"f_3534:lolevel_scm",(void*)f_3534},
{"f_3549:lolevel_scm",(void*)f_3549},
{"f_3537:lolevel_scm",(void*)f_3537},
{"f_3511:lolevel_scm",(void*)f_3511},
{"f_1538:lolevel_scm",(void*)f_1538},
{"f_1560:lolevel_scm",(void*)f_1560},
{"f_1563:lolevel_scm",(void*)f_1563},
{"f_3515:lolevel_scm",(void*)f_3515},
{"f_3382:lolevel_scm",(void*)f_3382},
{"f_3386:lolevel_scm",(void*)f_3386},
{"f_3389:lolevel_scm",(void*)f_3389},
{"f_3394:lolevel_scm",(void*)f_3394},
{"f_3410:lolevel_scm",(void*)f_3410},
{"f_3453:lolevel_scm",(void*)f_3453},
{"f_3456:lolevel_scm",(void*)f_3456},
{"f_3465:lolevel_scm",(void*)f_3465},
{"f_3486:lolevel_scm",(void*)f_3486},
{"f_3459:lolevel_scm",(void*)f_3459},
{"f_3439:lolevel_scm",(void*)f_3439},
{"f_3442:lolevel_scm",(void*)f_3442},
{"f_3423:lolevel_scm",(void*)f_3423},
{"f_3426:lolevel_scm",(void*)f_3426},
{"f_3298:lolevel_scm",(void*)f_3298},
{"f_3302:lolevel_scm",(void*)f_3302},
{"f_3307:lolevel_scm",(void*)f_3307},
{"f_3320:lolevel_scm",(void*)f_3320},
{"f_3377:lolevel_scm",(void*)f_3377},
{"f_3329:lolevel_scm",(void*)f_3329},
{"f_3341:lolevel_scm",(void*)f_3341},
{"f_3363:lolevel_scm",(void*)f_3363},
{"f_3332:lolevel_scm",(void*)f_3332},
{"f_3206:lolevel_scm",(void*)f_3206},
{"f_3215:lolevel_scm",(void*)f_3215},
{"f_3260:lolevel_scm",(void*)f_3260},
{"f_3270:lolevel_scm",(void*)f_3270},
{"f_3244:lolevel_scm",(void*)f_3244},
{"f_3251:lolevel_scm",(void*)f_3251},
{"f_3288:lolevel_scm",(void*)f_3288},
{"f_3042:lolevel_scm",(void*)f_3042},
{"f_3046:lolevel_scm",(void*)f_3046},
{"f_3049:lolevel_scm",(void*)f_3049},
{"f_3195:lolevel_scm",(void*)f_3195},
{"f_3052:lolevel_scm",(void*)f_3052},
{"f_3055:lolevel_scm",(void*)f_3055},
{"f_3063:lolevel_scm",(void*)f_3063},
{"f_3073:lolevel_scm",(void*)f_3073},
{"f_3188:lolevel_scm",(void*)f_3188},
{"f_3176:lolevel_scm",(void*)f_3176},
{"f_3180:lolevel_scm",(void*)f_3180},
{"f_3172:lolevel_scm",(void*)f_3172},
{"f_3085:lolevel_scm",(void*)f_3085},
{"f_3088:lolevel_scm",(void*)f_3088},
{"f_3145:lolevel_scm",(void*)f_3145},
{"f_3091:lolevel_scm",(void*)f_3091},
{"f_3094:lolevel_scm",(void*)f_3094},
{"f_3106:lolevel_scm",(void*)f_3106},
{"f_3127:lolevel_scm",(void*)f_3127},
{"f_3097:lolevel_scm",(void*)f_3097},
{"f_3058:lolevel_scm",(void*)f_3058},
{"f_2924:lolevel_scm",(void*)f_2924},
{"f_2931:lolevel_scm",(void*)f_2931},
{"f_2934:lolevel_scm",(void*)f_2934},
{"f_2939:lolevel_scm",(void*)f_2939},
{"f_2949:lolevel_scm",(void*)f_2949},
{"f_2958:lolevel_scm",(void*)f_2958},
{"f_2962:lolevel_scm",(void*)f_2962},
{"f_2965:lolevel_scm",(void*)f_2965},
{"f_2968:lolevel_scm",(void*)f_2968},
{"f_2980:lolevel_scm",(void*)f_2980},
{"f_3001:lolevel_scm",(void*)f_3001},
{"f_2971:lolevel_scm",(void*)f_2971},
{"f_3035:lolevel_scm",(void*)f_3035},
{"f_2921:lolevel_scm",(void*)f_2921},
{"f_2883:lolevel_scm",(void*)f_2883},
{"f_2887:lolevel_scm",(void*)f_2887},
{"f_2893:lolevel_scm",(void*)f_2893},
{"f_2898:lolevel_scm",(void*)f_2898},
{"f_2855:lolevel_scm",(void*)f_2855},
{"f_2859:lolevel_scm",(void*)f_2859},
{"f_2862:lolevel_scm",(void*)f_2862},
{"f_2842:lolevel_scm",(void*)f_2842},
{"f_2846:lolevel_scm",(void*)f_2846},
{"f_2833:lolevel_scm",(void*)f_2833},
{"f_2837:lolevel_scm",(void*)f_2837},
{"f_2789:lolevel_scm",(void*)f_2789},
{"f_2793:lolevel_scm",(void*)f_2793},
{"f_2780:lolevel_scm",(void*)f_2780},
{"f_2758:lolevel_scm",(void*)f_2758},
{"f_2749:lolevel_scm",(void*)f_2749},
{"f_1612:lolevel_scm",(void*)f_1612},
{"f_2753:lolevel_scm",(void*)f_2753},
{"f_2736:lolevel_scm",(void*)f_2736},
{"f_2716:lolevel_scm",(void*)f_2716},
{"f_2720:lolevel_scm",(void*)f_2720},
{"f_2682:lolevel_scm",(void*)f_2682},
{"f_2700:lolevel_scm",(void*)f_2700},
{"f_2692:lolevel_scm",(void*)f_2692},
{"f_2651:lolevel_scm",(void*)f_2651},
{"f_2666:lolevel_scm",(void*)f_2666},
{"f_2664:lolevel_scm",(void*)f_2664},
{"f_2616:lolevel_scm",(void*)f_2616},
{"f_2620:lolevel_scm",(void*)f_2620},
{"f_2641:lolevel_scm",(void*)f_2641},
{"f_2625:lolevel_scm",(void*)f_2625},
{"f_2566:lolevel_scm",(void*)f_2566},
{"f_2552:lolevel_scm",(void*)f_2552},
{"f_2538:lolevel_scm",(void*)f_2538},
{"f_2524:lolevel_scm",(void*)f_2524},
{"f_2510:lolevel_scm",(void*)f_2510},
{"f_2496:lolevel_scm",(void*)f_2496},
{"f_2482:lolevel_scm",(void*)f_2482},
{"f_2468:lolevel_scm",(void*)f_2468},
{"f_2462:lolevel_scm",(void*)f_2462},
{"f_2459:lolevel_scm",(void*)f_2459},
{"f_2452:lolevel_scm",(void*)f_2452},
{"f_2423:lolevel_scm",(void*)f_2423},
{"f_2431:lolevel_scm",(void*)f_2431},
{"f_2394:lolevel_scm",(void*)f_2394},
{"f_2402:lolevel_scm",(void*)f_2402},
{"f_2376:lolevel_scm",(void*)f_2376},
{"f_2332:lolevel_scm",(void*)f_2332},
{"f_2336:lolevel_scm",(void*)f_2336},
{"f_2317:lolevel_scm",(void*)f_2317},
{"f_2321:lolevel_scm",(void*)f_2321},
{"f_2324:lolevel_scm",(void*)f_2324},
{"f_2285:lolevel_scm",(void*)f_2285},
{"f_2312:lolevel_scm",(void*)f_2312},
{"f_2279:lolevel_scm",(void*)f_2279},
{"f_2265:lolevel_scm",(void*)f_2265},
{"f_2256:lolevel_scm",(void*)f_2256},
{"f_2260:lolevel_scm",(void*)f_2260},
{"f_2263:lolevel_scm",(void*)f_2263},
{"f_2250:lolevel_scm",(void*)f_2250},
{"f_2254:lolevel_scm",(void*)f_2254},
{"f_2239:lolevel_scm",(void*)f_2239},
{"f_2247:lolevel_scm",(void*)f_2247},
{"f_2226:lolevel_scm",(void*)f_2226},
{"f_2230:lolevel_scm",(void*)f_2230},
{"f_2237:lolevel_scm",(void*)f_2237},
{"f_2216:lolevel_scm",(void*)f_2216},
{"f_2220:lolevel_scm",(void*)f_2220},
{"f_2207:lolevel_scm",(void*)f_2207},
{"f_2211:lolevel_scm",(void*)f_2211},
{"f_2201:lolevel_scm",(void*)f_2201},
{"f_2195:lolevel_scm",(void*)f_2195},
{"f_2185:lolevel_scm",(void*)f_2185},
{"f_2178:lolevel_scm",(void*)f_2178},
{"f_2097:lolevel_scm",(void*)f_2097},
{"f_2103:lolevel_scm",(void*)f_2103},
{"f_2133:lolevel_scm",(void*)f_2133},
{"f_2148:lolevel_scm",(void*)f_2148},
{"f_2169:lolevel_scm",(void*)f_2169},
{"f_2136:lolevel_scm",(void*)f_2136},
{"f_1773:lolevel_scm",(void*)f_1773},
{"f_2034:lolevel_scm",(void*)f_2034},
{"f_2029:lolevel_scm",(void*)f_2029},
{"f_2024:lolevel_scm",(void*)f_2024},
{"f_1775:lolevel_scm",(void*)f_1775},
{"f_1833:lolevel_scm",(void*)f_1833},
{"f_1836:lolevel_scm",(void*)f_1836},
{"f_1841:lolevel_scm",(void*)f_1841},
{"f_1961:lolevel_scm",(void*)f_1961},
{"f_1993:lolevel_scm",(void*)f_1993},
{"f_2003:lolevel_scm",(void*)f_2003},
{"f_1983:lolevel_scm",(void*)f_1983},
{"f_1928:lolevel_scm",(void*)f_1928},
{"f_1942:lolevel_scm",(void*)f_1942},
{"f_1938:lolevel_scm",(void*)f_1938},
{"f_1919:lolevel_scm",(void*)f_1919},
{"f_1806:lolevel_scm",(void*)f_1806},
{"f_1813:lolevel_scm",(void*)f_1813},
{"f_1790:lolevel_scm",(void*)f_1790},
{"f_1784:lolevel_scm",(void*)f_1784},
{"f_1778:lolevel_scm",(void*)f_1778},
{"f_1768:lolevel_scm",(void*)f_1768},
{"f_1634:lolevel_scm",(void*)f_1634},
{"f_1583:lolevel_scm",(void*)f_1583},
{"f_1510:lolevel_scm",(void*)f_1510},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
