/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-07-30 23:12
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-28 on dill (Linux)
   command line: lolevel.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_pointer_to_object(ptr)   ((C_word*)C_block_item(ptr, 0))
#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[132];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,5),40,101,114,114,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,10),40,120,101,114,114,32,120,57,48,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,25),40,99,104,101,99,107,110,32,110,57,49,32,110,109,97,120,57,50,32,111,102,102,57,51,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,42),40,99,104,101,99,107,110,50,32,110,57,52,32,110,109,97,120,57,53,32,110,109,97,120,50,57,54,32,111,102,102,49,57,55,32,111,102,102,50,57,56,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,49,48,48,32,116,111,49,48,49,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,32),40,98,111,100,121,55,54,32,110,56,51,32,102,111,102,102,115,101,116,56,52,32,116,111,102,102,115,101,116,56,53,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,37),40,100,101,102,45,116,111,102,102,115,101,116,56,48,32,37,110,55,51,49,50,57,32,37,102,111,102,102,115,101,116,55,52,49,51,48,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,23),40,100,101,102,45,102,111,102,102,115,101,116,55,57,32,37,110,55,51,49,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,9),40,100,101,102,45,110,55,56,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,34),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,55,48,32,116,111,55,49,32,46,32,103,54,57,55,50,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,112,116,114,49,52,49,32,108,111,99,49,52,50,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,49,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,49,53,48,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,49,53,50,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,49,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,102,95,49,49,51,49,32,97,49,53,55,49,54,48,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,49,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,49,54,50,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,49,54,52,32,112,50,49,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,49,54,56,49,55,49,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,49,55,51,49,55,55,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,108,105,103,110,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,49,56,53,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,32),40,112,111,105,110,116,101,114,45,111,102,102,115,101,116,32,97,49,56,55,49,57,49,32,97,49,56,54,49,57,50,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,97,49,57,54,50,48,48,32,97,49,57,53,50,48,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,97,50,48,52,50,48,56,32,97,50,48,51,50,48,57,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,97,50,49,50,50,49,54,32,97,50,49,49,50,49,55,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,97,50,50,48,50,50,52,32,97,50,49,57,50,50,53,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,97,50,50,56,50,51,50,32,97,50,50,55,50,51,51,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,97,50,51,54,50,52,48,32,97,50,51,53,50,52,49,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,97,50,52,52,50,52,56,32,97,50,52,51,50,52,57,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,97,50,53,50,50,53,54,32,97,50,53,49,50,53,55,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,51,49,49,32,116,97,103,51,49,50,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,29),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,51,49,53,32,116,97,103,51,49,54,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,51,49,55,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,49,52,50,51,32,120,51,50,48,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,17),40,97,49,52,51,57,32,120,51,50,49,32,105,51,50,50,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,51,49,56,32,100,97,116,97,51,49,57,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,49,52,54,55,32,120,51,50,54,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,51,50,53,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,12),40,97,49,53,48,49,32,120,51,50,57,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,51,50,55,41,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,51,51,49,32,120,51,51,50,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,51,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,51,52,48,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,51,52,49,32,46,32,97,114,103,115,51,52,50,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,23),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,51,52,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,100,111,51,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,51,52,53,41,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,100,111,51,54,49,32,105,51,54,51,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,51,53,53,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,51,53,51,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,51,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,16),40,102,95,49,56,51,56,32,97,51,55,51,51,55,54,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,12),40,100,111,51,56,53,32,105,51,56,55,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,51,55,57,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,51,54,57,32,46,32,97,108,108,111,99,97,116,111,114,51,55,48,41,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,16),40,102,95,49,57,50,55,32,97,52,48,48,52,48,52,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,12),40,100,111,52,48,57,32,105,52,49,49,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,52,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,51,57,54,32,46,32,114,101,108,101,97,115,101,114,51,57,55,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,12),40,100,111,52,51,52,32,105,52,51,54,41,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,52,50,55,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,52,49,55,32,112,116,114,52,49,56,32,46,32,108,105,109,105,116,52,49,57,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,12),40,100,111,52,53,52,32,105,52,53,54,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,52,53,49,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,115,105,122,101,32,120,52,52,56,41,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,12),40,100,111,52,56,51,32,105,52,56,53,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,52,55,52,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,31),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,52,54,53,32,46,32,103,52,54,52,52,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,108,115,116,52,57,52,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,23),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,108,115,116,52,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,33),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,53,48,52,32,112,114,111,99,53,48,53,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,53,49,49,32,46,32,105,110,100,101,120,53,49,50,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,53,49,53,32,46,32,105,110,100,101,120,53,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,25),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,53,49,57,32,121,53,50,48,41,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,23),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,53,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,16),40,108,111,99,97,116,105,118,101,63,32,120,53,50,50,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,45),40,35,35,115,121,115,35,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,111,111,107,32,46,32,97,114,103,115,53,50,52,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,45),40,115,101,116,45,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,97,110,100,108,101,114,33,32,112,114,111,99,53,50,51,41,0,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,33),40,117,110,98,111,117,110,100,45,118,97,114,105,97,98,108,101,45,118,97,108,117,101,32,46,32,118,97,108,53,50,55,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,53,50,56,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,25),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,53,51,48,32,120,53,51,49,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,22),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,53,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,29),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,53,51,53,41,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,15),40,97,50,53,55,49,32,97,51,48,52,51,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,15),40,97,50,53,56,49,32,97,50,57,55,51,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,97,50,53,57,49,32,97,50,57,48,50,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,50,54,48,49,32,97,50,56,51,50,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,50,54,49,49,32,97,50,55,55,50,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,15),40,97,50,54,50,49,32,97,50,55,49,50,55,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,15),40,97,50,54,51,49,32,97,50,54,53,50,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,15),40,97,50,54,52,49,32,97,50,53,57,50,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0};


/* from k1930 */
static C_word C_fcall stub401(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub401(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1841 */
static C_word C_fcall stub374(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub374(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k2575 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub305(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub305(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k2585 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub298(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub298(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k2595 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub291(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub291(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k2605 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub284(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub284(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k2615 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub278(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub278(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k2625 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub272(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub272(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k2635 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub266(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub266(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_ret:
#undef return

return C_r;}

/* from k2645 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub260(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub260(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k1323 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub253(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1309 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1295 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub237(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub237(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1281 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub229(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub229(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1267 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub221(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub221(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1253 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub213(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub213(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1239 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub205(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub205(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1225 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub197(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1211 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub188(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub188(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from k1169 */
static C_word C_fcall stub181(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub181(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1159 */
static C_word C_fcall stub174(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub174(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1152 */
static C_word C_fcall stub169(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub169(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from f_1131 in object->pointer in k611 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub158(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub158(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k718 */
static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k690 */
static C_word C_fcall stub42(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub42(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k662 */
static C_word C_fcall stub26(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub26(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k634 */
static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_613)
static void C_ccall f_613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_ccall f_2612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2522)
static void C_fcall f_2522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2338)
static void C_fcall f_2338(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_fcall f_2209(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_fcall f_2280(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_fcall f_2116(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_fcall f_2150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_fcall f_1944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_fcall f_1958(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_fcall f_2001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1854)
static void C_fcall f_1854(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1899)
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1734)
static void C_ccall f_1734r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1746)
static void C_fcall f_1746(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_fcall f_1787(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1656)
static void C_fcall f_1656(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1701)
static void C_fcall f_1701(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static C_word C_fcall f_1614(C_word t0,C_word t1);
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1538)
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1551)
static void C_fcall f_1551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1522)
static void C_ccall f_1522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_ccall f_1316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1199)
static void C_ccall f_1199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static C_word C_fcall f_1166(C_word *a,C_word t0);
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_ccall f_1082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1061)
static void C_fcall f_1061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_991)
static void C_fcall f_991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_fcall f_986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_981)
static void C_fcall f_981(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_729)
static void C_fcall f_729(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_789)
static void C_fcall f_789(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_912)
static void C_ccall f_912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_927)
static void C_ccall f_927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_ccall f_944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_860)
static void C_ccall f_860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_876)
static void C_ccall f_876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_890)
static void C_ccall f_890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_760)
static void C_fcall f_760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_767)
static void C_fcall f_767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_744)
static void C_fcall f_744(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_738)
static void C_fcall f_738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_732)
static void C_fcall f_732(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2522)
static void C_fcall trf_2522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2522(t0,t1);}

C_noret_decl(trf_2338)
static void C_fcall trf_2338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2338(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2338(t0,t1,t2);}

C_noret_decl(trf_2209)
static void C_fcall trf_2209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2209(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2209(t0,t1,t2);}

C_noret_decl(trf_2280)
static void C_fcall trf_2280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2280(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2280(t0,t1,t2);}

C_noret_decl(trf_2116)
static void C_fcall trf_2116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2116(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2116(t0,t1,t2);}

C_noret_decl(trf_2150)
static void C_fcall trf_2150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2150(t0,t1,t2);}

C_noret_decl(trf_1944)
static void C_fcall trf_1944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1944(t0,t1);}

C_noret_decl(trf_1958)
static void C_fcall trf_1958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1958(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1958(t0,t1,t2);}

C_noret_decl(trf_2001)
static void C_fcall trf_2001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2001(t0,t1,t2);}

C_noret_decl(trf_1854)
static void C_fcall trf_1854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1854(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1854(t0,t1,t2);}

C_noret_decl(trf_1899)
static void C_fcall trf_1899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1899(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1899(t0,t1,t2);}

C_noret_decl(trf_1746)
static void C_fcall trf_1746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1746(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1746(t0,t1,t2);}

C_noret_decl(trf_1787)
static void C_fcall trf_1787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1787(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1787(t0,t1,t2);}

C_noret_decl(trf_1656)
static void C_fcall trf_1656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1656(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1656(t0,t1,t2);}

C_noret_decl(trf_1701)
static void C_fcall trf_1701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1701(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1701(t0,t1,t2);}

C_noret_decl(trf_1551)
static void C_fcall trf_1551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1551(t0,t1);}

C_noret_decl(trf_1061)
static void C_fcall trf_1061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1061(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1061(t0,t1);}

C_noret_decl(trf_991)
static void C_fcall trf_991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_991(t0,t1);}

C_noret_decl(trf_986)
static void C_fcall trf_986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_986(t0,t1,t2);}

C_noret_decl(trf_981)
static void C_fcall trf_981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_981(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_981(t0,t1,t2,t3);}

C_noret_decl(trf_729)
static void C_fcall trf_729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_729(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_729(t0,t1,t2,t3,t4);}

C_noret_decl(trf_789)
static void C_fcall trf_789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_789(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_789(t0,t1,t2,t3);}

C_noret_decl(trf_760)
static void C_fcall trf_760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_760(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_760(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_767)
static void C_fcall trf_767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_767(t0,t1);}

C_noret_decl(trf_744)
static void C_fcall trf_744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_744(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_744(t0,t1,t2,t3,t4);}

C_noret_decl(trf_738)
static void C_fcall trf_738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_738(t0,t1);}

C_noret_decl(trf_732)
static void C_fcall trf_732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_732(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1177)){
C_save(t1);
C_rereclaim2(1177*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,132);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[3]=C_h_intern(&lf[3],12,"move-memory!");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],11,"\000type-error");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid argument type");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[11]=C_h_intern(&lf[11],15,"\003sysbytevector\077");
lf[12]=C_h_intern(&lf[12],13,"\003syslocative\077");
lf[13]=C_h_intern(&lf[13],17,"\003syscheck-pointer");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[15]=C_h_intern(&lf[15],12,"null-pointer");
lf[16]=C_h_intern(&lf[16],16,"\003sysnull-pointer");
lf[17]=C_h_intern(&lf[17],8,"pointer\077");
lf[18]=C_h_intern(&lf[18],16,"address->pointer");
lf[19]=C_h_intern(&lf[19],20,"\003sysaddress->pointer");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\042bad argument type - not an integer");
lf[21]=C_h_intern(&lf[21],16,"pointer->address");
lf[22]=C_h_intern(&lf[22],20,"\003syspointer->address");
lf[23]=C_h_intern(&lf[23],17,"\003syscheck-special");
lf[24]=C_h_intern(&lf[24],13,"null-pointer\077");
lf[25]=C_h_intern(&lf[25],15,"object->pointer");
lf[26]=C_h_intern(&lf[26],15,"pointer->object");
lf[27]=C_h_intern(&lf[27],9,"pointer=\077");
lf[28]=C_h_intern(&lf[28],8,"allocate");
lf[29]=C_h_intern(&lf[29],4,"free");
lf[30]=C_h_intern(&lf[30],13,"align-to-word");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000+bad argument type - not a pointer or fixnum");
lf[32]=C_h_intern(&lf[32],14,"pointer-offset");
lf[33]=C_h_intern(&lf[33],15,"pointer-u8-set!");
lf[34]=C_h_intern(&lf[34],15,"pointer-s8-set!");
lf[35]=C_h_intern(&lf[35],16,"pointer-u16-set!");
lf[36]=C_h_intern(&lf[36],16,"pointer-s16-set!");
lf[37]=C_h_intern(&lf[37],16,"pointer-u32-set!");
lf[38]=C_h_intern(&lf[38],16,"pointer-s32-set!");
lf[39]=C_h_intern(&lf[39],16,"pointer-f32-set!");
lf[40]=C_h_intern(&lf[40],16,"pointer-f64-set!");
lf[41]=C_h_intern(&lf[41],14,"pointer-u8-ref");
lf[42]=C_h_intern(&lf[42],14,"pointer-s8-ref");
lf[43]=C_h_intern(&lf[43],15,"pointer-u16-ref");
lf[44]=C_h_intern(&lf[44],15,"pointer-s16-ref");
lf[45]=C_h_intern(&lf[45],15,"pointer-u32-ref");
lf[46]=C_h_intern(&lf[46],15,"pointer-s32-ref");
lf[47]=C_h_intern(&lf[47],15,"pointer-f32-ref");
lf[48]=C_h_intern(&lf[48],15,"pointer-f64-ref");
lf[49]=C_h_intern(&lf[49],11,"tag-pointer");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[51]=C_h_intern(&lf[51],23,"\003sysmake-tagged-pointer");
lf[52]=C_h_intern(&lf[52],15,"tagged-pointer\077");
lf[53]=C_h_intern(&lf[53],11,"pointer-tag");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[55]=C_h_intern(&lf[55],8,"extended");
lf[57]=C_h_intern(&lf[57],16,"extend-procedure");
lf[58]=C_h_intern(&lf[58],19,"\003sysdecorate-lambda");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[60]=C_h_intern(&lf[60],19,"extended-procedure\077");
lf[61]=C_h_intern(&lf[61],21,"\003syslambda-decoration");
lf[62]=C_h_intern(&lf[62],14,"procedure-data");
lf[63]=C_h_intern(&lf[63],19,"set-procedure-data!");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[65]=C_h_intern(&lf[65],10,"block-set!");
lf[66]=C_h_intern(&lf[66],14,"\003sysblock-set!");
lf[67]=C_h_intern(&lf[67],9,"block-ref");
lf[68]=C_h_intern(&lf[68],15,"number-of-slots");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\024slots not accessible");
lf[70]=C_h_intern(&lf[70],15,"number-of-bytes");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\0003can not compute number of bytes of immediate object");
lf[72]=C_h_intern(&lf[72],20,"make-record-instance");
lf[73]=C_h_intern(&lf[73],18,"\003sysmake-structure");
lf[74]=C_h_intern(&lf[74],16,"record-instance\077");
lf[75]=C_h_intern(&lf[75],14,"record->vector");
lf[76]=C_h_intern(&lf[76],15,"\003sysmake-vector");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a record structure");
lf[78]=C_h_intern(&lf[78],11,"object-copy");
lf[79]=C_h_intern(&lf[79],15,"object-evicted\077");
lf[80]=C_h_intern(&lf[80],12,"object-evict");
lf[81]=C_h_intern(&lf[81],19,"\003syshash-table-set!");
lf[82]=C_h_intern(&lf[82],18,"\003syshash-table-ref");
lf[83]=C_h_intern(&lf[83],14,"object-release");
lf[84]=C_h_intern(&lf[84],24,"object-evict-to-location");
lf[85]=C_h_intern(&lf[85],24,"\003sysset-pointer-address!");
lf[86]=C_h_intern(&lf[86],6,"signal");
lf[87]=C_h_intern(&lf[87],24,"make-composite-condition");
lf[88]=C_h_intern(&lf[88],23,"make-property-condition");
lf[89]=C_h_intern(&lf[89],5,"evict");
lf[90]=C_h_intern(&lf[90],5,"limit");
lf[91]=C_h_intern(&lf[91],3,"exn");
lf[92]=C_h_intern(&lf[92],8,"location");
lf[93]=C_h_intern(&lf[93],7,"message");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000%can not evict object - limit exceeded");
lf[95]=C_h_intern(&lf[95],9,"arguments");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[97]=C_h_intern(&lf[97],11,"object-size");
lf[98]=C_h_intern(&lf[98],14,"object-unevict");
lf[99]=C_h_intern(&lf[99],15,"\003sysmake-string");
lf[100]=C_h_intern(&lf[100],14,"object-become!");
lf[101]=C_h_intern(&lf[101],11,"\003sysbecome!");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - new item is immediate");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - old item is immediate");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not an a-list");
lf[105]=C_h_intern(&lf[105],16,"mutate-procedure");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[107]=C_h_intern(&lf[107],13,"make-locative");
lf[108]=C_h_intern(&lf[108],17,"\003sysmake-locative");
lf[109]=C_h_intern(&lf[109],18,"make-weak-locative");
lf[110]=C_h_intern(&lf[110],13,"locative-set!");
lf[111]=C_h_intern(&lf[111],12,"locative-ref");
lf[112]=C_h_intern(&lf[112],16,"locative->object");
lf[113]=C_h_intern(&lf[113],9,"locative\077");
lf[115]=C_h_intern(&lf[115],35,"set-invalid-procedure-call-handler!");
lf[116]=C_h_intern(&lf[116],31,"\003sysinvalid-procedure-call-hook");
lf[117]=C_h_intern(&lf[117],26,"\003syslast-invalid-procedure");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[119]=C_h_intern(&lf[119],22,"unbound-variable-value");
lf[120]=C_h_intern(&lf[120],31,"\003sysunbound-variable-value-hook");
lf[121]=C_h_intern(&lf[121],10,"global-ref");
lf[122]=C_h_intern(&lf[122],11,"global-set!");
lf[123]=C_h_intern(&lf[123],13,"global-bound\077");
lf[124]=C_h_intern(&lf[124],32,"\003syssymbol-has-toplevel-binding\077");
lf[125]=C_h_intern(&lf[125],20,"global-make-unbound!");
lf[126]=C_h_intern(&lf[126],28,"\003sysarbitrary-unbound-symbol");
lf[127]=C_h_intern(&lf[127],18,"getter-with-setter");
lf[128]=C_h_intern(&lf[128],13,"\003sysblock-ref");
lf[129]=C_h_intern(&lf[129],15,"pointer-s6-set!");
lf[130]=C_h_intern(&lf[130],17,"register-feature!");
lf[131]=C_h_intern(&lf[131],7,"lolevel");
C_register_lf2(lf,132,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_613,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 66   register-feature! */
t4=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[131]);}

/* k611 */
static void C_ccall f_613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[74],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_613,2,t0,t1);}
t2=lf[2];
t3=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_727,a[2]=t2,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[15]+1,*((C_word*)lf[16]+1));
t6=C_mutate((C_word*)lf[17]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[18]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1082,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[21]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1110,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1134,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1149,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1156,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t16=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1172,a[2]=t15,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1204,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1218,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1232,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[35]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1246,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1260,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[38]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1288,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1302,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[40]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 186  getter-with-setter */
t28=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t28))(4,t28,t26,t27,*((C_word*)lf[33]+1));}

/* a2641 in k611 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2642,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub260(C_SCHEME_UNDEFINED,t3));}

/* k1330 in k611 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1332,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 191  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[34]+1));}

/* a2631 in k1330 in k611 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2632,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub266(C_SCHEME_UNDEFINED,t3));}

/* k1334 in k1330 in k611 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 196  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[35]+1));}

/* a2621 in k1334 in k1330 in k611 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2622,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub272(C_SCHEME_UNDEFINED,t3));}

/* k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1340,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2612,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 201  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[129]+1));}

/* a2611 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2612,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub278(C_SCHEME_UNDEFINED,t3));}

/* k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2602,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 206  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[37]+1));}

/* a2601 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2602,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub284(t3,t4));}

/* k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1348,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2592,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 211  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[38]+1));}

/* a2591 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2592,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub291(t3,t4));}

/* k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1352,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2582,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 216  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[39]+1));}

/* a2581 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2582,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub298(t3,t4));}

/* k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1356,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1360,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2572,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 221  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[40]+1));}

/* a2571 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2572,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub305(t3,t4));}

/* k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1360,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1,t1);
t3=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1362,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1377,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1393,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t6=(C_word)C_a_i_vector(&a,1,lf[55]);
t7=C_mutate(&lf[56],t6);
t8=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1484,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1518,a[2]=t11,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t13=C_mutate((C_word*)lf[65]+1,*((C_word*)lf[66]+1));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 283  getter-with-setter */
t15=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t15))(4,t15,t14,*((C_word*)lf[128]+1),*((C_word*)lf[66]+1));}

/* k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[57],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1536,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1,t1);
t3=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1538,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1559,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1581,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1590,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1596,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1650,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1734,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1845,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1937,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2107,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2191,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2389,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[107]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2423,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2452,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2481,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 523  getter-with-setter */
t22=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t22))(4,t22,t20,t21,*((C_word*)lf[110]+1));}

/* k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1,t1);
t3=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2488,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2491,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t5=lf[114]=C_SCHEME_FALSE;;
t6=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2498,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2517,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2534,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[122]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2549,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2558,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2558,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[125]);
t4=(C_word)C_slot(lf[126],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2549,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[123]);
/* lolevel.scm: 558  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* global-set! in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2540,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[122]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2534,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2517r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2517r(t0,t1,t2);}}

static void C_ccall f_2517r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2522,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_2522(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_2522(t4,C_SCHEME_FALSE);}}

/* k2520 in unbound-variable-value in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_2522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[120]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* set-invalid-procedure-call-handler! in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2498,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2502,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t4=t3;
f_2502(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 534  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[115],lf[118],t2);}}

/* k2500 in set-invalid-procedure-call-handler! in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2502,2,t0,t1);}
t2=C_mutate(&lf[114],((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[116]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2505,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k2500 in set-invalid-procedure-call-handler! in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2505r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2505r(t0,t1,t2);}}

static void C_ccall f_2505r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 538  ipc-hook-0 */
t3=lf[114];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,*((C_word*)lf[117]+1),t2);}

/* locative? in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2491,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k2484 in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2488,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2481,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2452r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2452r(t0,t1,t2,t3);}}

static void C_ccall f_2452r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2460,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2460(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2460(2,t6,(C_word)C_i_car(t3));}
else{
/* lolevel.scm: 520  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2458 in make-weak-locative in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 520  ##sys#make-locative */
t2=*((C_word*)lf[108]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[109]);}

/* make-locative in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2423r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2423r(t0,t1,t2,t3);}}

static void C_ccall f_2423r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2431,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2431(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2431(2,t6,(C_word)C_i_car(t3));}
else{
/* lolevel.scm: 517  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2429 in make-locative in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 517  ##sys#make-locative */
t2=*((C_word*)lf[108]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[107]);}

/* mutate-procedure in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2389,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2393,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t5=t4;
f_2393(2,t5,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 506  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[105],lf[106],t2);}}

/* k2391 in mutate-procedure in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 509  ##sys#make-vector */
t5=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2398 in k2391 in mutate-procedure in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2403,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 510  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2413 in k2398 in k2391 in mutate-procedure in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2415,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 510  ##sys#become! */
t4=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k2401 in k2398 in k2391 in mutate-procedure in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2326,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2333,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2338,a[2]=t6,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2338(t8,t4,t2);}

/* loop in object-become! in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_2338(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2338,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_pair_2(t4,lf[100]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2360,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
if(C_truep((C_word)C_blockp(t7))){
t8=t6;
f_2360(2,t8,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 497  ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[7],lf[100],lf[103],t4);}}
else{
/* lolevel.scm: 501  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[7],lf[100],lf[104]);}}}

/* k2358 in loop in object-become! in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_blockp(t3))){
t4=t2;
f_2363(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 499  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[100],lf[102],((C_word*)t0)[2]);}}

/* k2361 in k2358 in loop in object-become! in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lolevel.scm: 500  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2338(t3,((C_word*)t0)[2],t2);}

/* k2331 in object-become! in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 502  ##sys#become! */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2191r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2191r(t0,t1,t2,t3);}}

static void C_ccall f_2191r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2195,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2195(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2195(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 458  ##sys#make-vector */
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2209,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2209(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_2209(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2209,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 462  ##sys#hash-table-ref */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 465  ##sys#make-string */
t4=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 470  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 475  ##sys#make-vector */
t4=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2266 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 476  ##sys#hash-table-set! */
t4=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2269 in k2266 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li67),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2280(t7,t2,t3);}

/* do483 in k2269 in k2266 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_2280(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2280,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2301,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 479  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2209(t5,t3,t4);}}

/* k2299 in do483 in k2269 in k2266 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2280(t4,((C_word*)t0)[2],t3);}

/* k2272 in k2269 in k2266 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2252 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 471  ##sys#hash-table-set! */
t3=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2255 in k2252 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2236 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2241,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 466  ##sys#hash-table-set! */
t4=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2239 in k2236 in k2223 in copy in k2202 in k2193 in object-unevict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2107,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2111,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 435  ##sys#make-vector */
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2109 in object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2116,a[2]=t1,a[3]=t3,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2116(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2109 in object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_2116(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2116,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 438  ##sys#hash-table-ref */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2127 in evict in k2109 in object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2129,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 442  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2186(2,t4,(C_word)C_bytes(t2));}}}

/* k2184 in k2127 in evict in k2109 in object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 444  ##sys#hash-table-set! */
t6=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2136 in k2184 in k2127 in evict in k2109 in object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2141(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li64),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2150(t9,t2,t5);}}

/* do454 in k2136 in k2184 in k2127 in evict in k2109 in object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_2150(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2150,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2172,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 451  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2116(t5,t3,t4);}}

/* k2170 in do454 in k2136 in k2184 in k2127 in evict in k2109 in object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2150(t5,((C_word*)t0)[2],t4);}

/* k2139 in k2136 in k2184 in k2127 in evict in k2109 in object-size in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1937r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1937r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1937r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1941,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t5;
f_1941(2,t7,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 390  ##sys#signal-hook */
t7=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[7],lf[84],lf[96],t3);}}

/* k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[84]);
t5=t2;
f_1944(t5,t3);}
else{
t3=t2;
f_1944(t3,C_SCHEME_FALSE);}}

/* k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1944,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2086,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 398  ##sys#pointer->address */
t6=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2084 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 398  ##sys#address->pointer */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 399  ##sys#make-vector */
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li62),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1958(t6,t2,((C_word*)t0)[2]);}

/* evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1958(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1958,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 403  ##sys#hash-table-ref */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1968,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 407  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2079(2,t4,(C_word)C_bytes(t2));}}}

/* k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2079,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1980,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2063,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 414  make-property-condition */
t9=*((C_word*)lf[88]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[91],lf[92],lf[84],lf[93],lf[94],lf[95],t8);}
else{
t6=t3;
f_1980(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1980(2,t4,C_SCHEME_UNDEFINED);}}

/* k2065 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2071,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 418  make-property-condition */
t3=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[89],lf[90],((C_word*)((C_word*)t0)[2])[1]);}

/* k2069 in k2065 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 413  make-composite-condition */
t2=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2061 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 412  signal */
t2=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1978 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[8]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 421  ##sys#pointer->address */
t7=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[7]);}

/* k2038 in k1978 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 421  ##sys#set-pointer-address! */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1984 in k1978 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 422  ##sys#hash-table-set! */
t3=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1987 in k1984 in k1978 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_1992(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li61),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2001(t9,t2,t5);}}

/* do434 in k1987 in k1984 in k1978 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_2001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2001,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2022,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 429  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1958(t5,t3,t4);}}

/* k2020 in do434 in k1987 in k1984 in k1978 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2001(t4,((C_word*)t0)[2],t3);}

/* k1990 in k1987 in k1984 in k1978 in k2077 in k1966 in evict in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1951 in k1948 in k1945 in k1942 in k1939 in object-evict-to-location in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 431  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-release in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1845r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1845r(t0,t1,t2,t3);}}

static void C_ccall f_1845r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1927,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1854,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1854(t11,t1,t2);}

/* release in object-release in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1854(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1854,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1883,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_1883(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_1899(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* do409 in release in object-release in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1899,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1909,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 382  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1854(t5,t3,t4);}}

/* k1907 in do409 in release in object-release in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1899(t3,((C_word*)t0)[2],t2);}

/* k1881 in release in object-release in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 383  ##sys#address->pointer */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k1888 in k1881 in release in object-release in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 383  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_1927 in object-release in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1927,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub401(C_SCHEME_UNDEFINED,t3));}

/* object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1734(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1734r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1734r(t0,t1,t2,t3);}}

static void C_ccall f_1734r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1838,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1741,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 349  ##sys#make-vector */
t7=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1746,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1746(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1746(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1746,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 352  ##sys#hash-table-ref */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1754 in evict in k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 355  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_1765(2,t4,(C_word)C_bytes(t2));}}}

/* k1763 in k1754 in evict in k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 356  allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k1767 in k1763 in k1754 in evict in k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1769,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(C_word)C_i_symbolp(((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 358  ##sys#hash-table-set! */
t6=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k1773 in k1767 in k1763 in k1754 in evict in k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_1778(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li54),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_1787(t9,t2,t5);}}

/* do385 in k1773 in k1767 in k1763 in k1754 in evict in k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1787(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1787,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1808,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 363  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1746(t5,t3,t4);}}

/* k1806 in do385 in k1773 in k1767 in k1763 in k1754 in evict in k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1787(t4,((C_word*)t0)[2],t3);}

/* k1776 in k1773 in k1767 in k1763 in k1754 in evict in k1739 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_1838 in object-evict in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1838,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub374(t3,t4));}

/* object-evicted? in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1731,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* object-copy in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1650,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1656,a[2]=t4,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1656(t6,t1,t2);}

/* copy in object-copy in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1656(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1656,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 325  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 329  ##sys#make-vector */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1684 in copy in object-copy in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1689,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_1689(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1701,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1701(t10,t3,t6);}}

/* do361 in k1684 in copy in object-copy in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1701(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1701,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1722,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 333  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1656(t5,t3,t4);}}

/* k1720 in do361 in k1684 in copy in object-copy in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1701(t4,((C_word*)t0)[2],t3);}

/* k1687 in k1684 in copy in object-copy in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* record->vector in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1596,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_structurep(t2));
if(C_truep(t4)){
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1609,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 313  ##sys#make-vector */
t7=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
/* lolevel.scm: 317  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[7],lf[75],lf[77],t2);}}

/* k1607 in record->vector in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1614(t2,C_fix(0)));}

/* do348 in k1607 in record->vector in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static C_word C_fcall f_1614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance? in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1590,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE));}

/* make-record-instance in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1581r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1581r(t0,t1,t2,t3);}}

static void C_ccall f_1581r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[72]);
C_apply(5,0,t1,*((C_word*)lf[73]+1),t2,t3);}

/* number-of-bytes in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1559,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 295  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[70],lf[71],t2);}}

/* number-of-slots in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1538,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1542,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1551,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1551(t6,t4);}
else{
t6=(C_word)C_specialp(t2);
t7=t5;
f_1551(t7,(C_truep(t6)?t6:(C_word)C_byteblockp(t2)));}}

/* k1549 in number-of-slots in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_fcall f_1551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* lolevel.scm: 290  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[7],lf[68],lf[69],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1542(2,t2,C_SCHEME_UNDEFINED);}}

/* k1540 in number-of-slots in k1534 in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* set-procedure-data! in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1518,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1522,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 274  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k1520 in set-procedure-data! in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 277  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[7],lf[63],lf[64],((C_word*)t0)[3]);}}

/* procedure-data in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1484,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1494,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 268  ##sys#lambda-decoration */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1501 in procedure-data in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1502,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1492 in procedure-data in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1453,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1466,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1468,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 262  ##sys#lambda-decoration */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1467 in extended-procedure? in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1468,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1464 in extended-procedure? in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1415,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1419,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_closurep(t2))){
t5=t4;
f_1419(2,t5,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 251  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[57],lf[59],t2);}}

/* k1417 in extend-procedure in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1424,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[4],a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 252  ##sys#decorate-lambda */
t4=*((C_word*)lf[58]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1439 in k1417 in extend-procedure in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1440,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[56],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a1423 in k1417 in extend-procedure in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1424,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-tag in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1393,3,t0,t1,t2);}
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 241  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[53],lf[54],t2);}}

/* tagged-pointer? in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1377,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_equalp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* tag-pointer in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1362,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1366,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 226  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k1364 in tag-pointer in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_blockp(((C_word*)t0)[2]))?(C_word)C_specialp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1369(2,t4,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 229  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[49],lf[50],((C_word*)t0)[2]);}}

/* k1367 in k1364 in tag-pointer in k1358 in k1354 in k1350 in k1346 in k1342 in k1338 in k1334 in k1330 in k611 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pointer-f64-set! in k611 */
static void C_ccall f_1316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1316,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub253(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-f32-set! in k611 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1302,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub245(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s32-set! in k611 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1288,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub237(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u32-set! in k611 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1274,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub229(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s16-set! in k611 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1260,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub221(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u16-set! in k611 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1246,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub213(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s8-set! in k611 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1232,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub205(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u8-set! in k611 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1218,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub197(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-offset in k611 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1204,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub188(t4,t5,t6));}

/* align-to-word in k611 */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1172,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
/* lolevel.scm: 167  align */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,f_1166(C_a_i(&a,6),t2));}
else{
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1199,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 169  ##sys#pointer->address */
t5=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* lolevel.scm: 170  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[30],lf[31],t2);}}}

/* k1197 in align-to-word in k611 */
static void C_ccall f_1199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1199,2,t0,t1);}
t2=f_1166(C_a_i(&a,6),t1);
/* lolevel.scm: 169  ##sys#address->pointer */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k611 */
static C_word C_fcall f_1166(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)C_i_foreign_integer_argumentp(t1);
return((C_word)stub181(t2,t3));}

/* free in k611 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1156,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub174(C_SCHEME_UNDEFINED,t3));}

/* allocate in k611 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1149,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub169(t3,t4));}

/* pointer=? in k611 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1140,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1144,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 157  ##sys#check-special */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[27]);}

/* k1142 in pointer=? in k611 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 158  ##sys#check-special */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[27]);}

/* k1145 in k1142 in pointer=? in k611 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k611 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1134,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1138,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 153  ##sys#check-pointer */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[26]);}

/* k1136 in pointer->object in k611 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k611 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1123,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1131,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1131 in object->pointer in k611 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1131,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub158(t3,t2));}

/* null-pointer? in k611 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1110,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1114,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 143  ##sys#check-special */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[24]);}

/* k1112 in null-pointer? in k611 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1121,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 144  ##sys#pointer->address */
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1119 in k1112 in null-pointer? in k611 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k611 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1101,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1105,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 139  ##sys#check-special */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[21]);}

/* k1103 in pointer->address in k611 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 140  ##sys#pointer->address */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k611 */
static void C_ccall f_1082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1082,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_integerp(t2))){
t4=t3;
f_1086(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 134  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[18],lf[20],t2);}}

/* k1084 in address->pointer in k611 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 136  ##sys#address->pointer */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer? in k611 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1073,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_pointerp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_taggedpointerp(t2)));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#check-pointer in k611 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1054,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1061,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t2))){
t5=(C_word)C_pointerp(t2);
if(C_truep(t5)){
t6=t4;
f_1061(t6,t5);}
else{
t6=(C_word)C_swigpointerp(t2);
t7=t4;
f_1061(t7,(C_truep(t6)?t6:(C_word)C_taggedpointerp(t2)));}}
else{
t5=t4;
f_1061(t5,C_SCHEME_FALSE);}}

/* k1059 in ##sys#check-pointer in k611 */
static void C_fcall f_1061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 121  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],lf[14],((C_word*)t0)[2]);}}

/* move-memory! in k611 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_727r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_727r(t0,t1,t2,t3,t4);}}

static void C_ccall f_727r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_729,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_981,a[2]=t5,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_986,a[2]=t6,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_991,a[2]=t7,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n78133 */
t9=t8;
f_991(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset79131 */
t11=t7;
f_986(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset80128 */
t13=t6;
f_981(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body7682 */
t15=t5;
f_729(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n78 in move-memory! in k611 */
static void C_fcall f_991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_991,NULL,2,t0,t1);}
/* def-foffset79131 */
t2=((C_word*)t0)[2];
f_986(t2,t1,C_SCHEME_FALSE);}

/* def-foffset79 in move-memory! in k611 */
static void C_fcall f_986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_986,NULL,3,t0,t1,t2);}
/* def-toffset80128 */
t3=((C_word*)t0)[2];
f_981(t3,t1,t2,C_fix(0));}

/* def-toffset80 in move-memory! in k611 */
static void C_fcall f_981(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_981,NULL,4,t0,t1,t2,t3);}
/* body7682 */
t4=((C_word*)t0)[2];
f_729(t4,t1,t2,t3,C_fix(0));}

/* body76 in move-memory! in k611 */
static void C_fcall f_729(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_729,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_738,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_789,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t2,a[8]=t6,a[9]=t10,a[10]=((C_word*)t0)[2],a[11]=((C_word)li4),tmp=(C_word)a,a+=12,tmp));
t12=((C_word*)t10)[1];
f_789(t12,t1,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* move in body76 in move-memory! in k611 */
static void C_fcall f_789(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_789,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 91   move */
t11=t1;
t12=t5;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 92   xerr */
f_738(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 95   move */
t11=t1;
t12=t2;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 96   xerr */
f_738(t1,t3);}}
else{
t4=(C_word)C_pointerp(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_851(2,t6,t4);}
else{
/* lolevel.scm: 97   ##sys#locative? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}}

/* k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_851,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_pointerp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_860(2,t4,t2);}
else{
/* lolevel.scm: 98   ##sys#locative? */
t4=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 103  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k910 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_912,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=(C_word)C_pointerp(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_927(2,t6,t4);}
else{
/* lolevel.scm: 105  ##sys#locative? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[9]);}}
else{
/* lolevel.scm: 111  xerr */
f_738(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k925 in k910 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_927,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_934,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:((C_word*)t0)[5]);
/* lolevel.scm: 106  checkn */
t5=((C_word*)t0)[4];
f_744(t5,t2,t4,((C_word*)t0)[5],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 107  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}}

/* k942 in k925 in k910 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_944,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
/* lolevel.scm: 108  checkn2 */
t7=((C_word*)t0)[3];
f_760(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* lolevel.scm: 110  xerr */
f_738(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k952 in k942 in k925 in k910 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub58(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k932 in k925 in k910 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub26(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k858 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_860,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_867(2,t4,t2);}
else{
/* lolevel.scm: 99   err */
t4=((C_word*)t0)[4];
f_732(t4,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 100  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k874 in k858 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_876,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_886,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_890,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_890(2,t6,t4);}
else{
/* lolevel.scm: 101  err */
t6=((C_word*)t0)[3];
f_732(t6,t5);}}
else{
/* lolevel.scm: 102  xerr */
f_738(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k888 in k874 in k858 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 101  checkn */
t3=((C_word*)t0)[4];
f_744(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k884 in k874 in k858 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub42(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k865 in k858 in k849 in move in body76 in move-memory! in k611 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub10(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body76 in move-memory! in k611 */
static void C_fcall f_760(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_760,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_767,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_fixnum_difference(t4,t6);
t10=t7;
f_767(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_767(t9,C_SCHEME_FALSE);}}

/* k765 in checkn2 in body76 in move-memory! in k611 */
static void C_fcall f_767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
/* lolevel.scm: 87   ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[7],lf[3],lf[10],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* checkn in body76 in move-memory! in k611 */
static void C_fcall f_744(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_744,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
/* lolevel.scm: 83   ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t6+1)))(8,t6,t1,lf[3],lf[9],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}}

/* xerr in body76 in move-memory! in k611 */
static void C_fcall f_738(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_738,NULL,2,t1,t2);}
/* lolevel.scm: 79   ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[3],lf[8],t2);}

/* err in body76 in move-memory! in k611 */
static void C_fcall f_732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_732,NULL,2,t0,t1);}
/* lolevel.scm: 78   ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[3],lf[5],((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[194] = {
{"toplevellolevel.scm",(void*)C_lolevel_toplevel},
{"f_613lolevel.scm",(void*)f_613},
{"f_2642lolevel.scm",(void*)f_2642},
{"f_1332lolevel.scm",(void*)f_1332},
{"f_2632lolevel.scm",(void*)f_2632},
{"f_1336lolevel.scm",(void*)f_1336},
{"f_2622lolevel.scm",(void*)f_2622},
{"f_1340lolevel.scm",(void*)f_1340},
{"f_2612lolevel.scm",(void*)f_2612},
{"f_1344lolevel.scm",(void*)f_1344},
{"f_2602lolevel.scm",(void*)f_2602},
{"f_1348lolevel.scm",(void*)f_1348},
{"f_2592lolevel.scm",(void*)f_2592},
{"f_1352lolevel.scm",(void*)f_1352},
{"f_2582lolevel.scm",(void*)f_2582},
{"f_1356lolevel.scm",(void*)f_1356},
{"f_2572lolevel.scm",(void*)f_2572},
{"f_1360lolevel.scm",(void*)f_1360},
{"f_1536lolevel.scm",(void*)f_1536},
{"f_2486lolevel.scm",(void*)f_2486},
{"f_2558lolevel.scm",(void*)f_2558},
{"f_2549lolevel.scm",(void*)f_2549},
{"f_2540lolevel.scm",(void*)f_2540},
{"f_2534lolevel.scm",(void*)f_2534},
{"f_2517lolevel.scm",(void*)f_2517},
{"f_2522lolevel.scm",(void*)f_2522},
{"f_2498lolevel.scm",(void*)f_2498},
{"f_2502lolevel.scm",(void*)f_2502},
{"f_2505lolevel.scm",(void*)f_2505},
{"f_2491lolevel.scm",(void*)f_2491},
{"f_2488lolevel.scm",(void*)f_2488},
{"f_2481lolevel.scm",(void*)f_2481},
{"f_2452lolevel.scm",(void*)f_2452},
{"f_2460lolevel.scm",(void*)f_2460},
{"f_2423lolevel.scm",(void*)f_2423},
{"f_2431lolevel.scm",(void*)f_2431},
{"f_2389lolevel.scm",(void*)f_2389},
{"f_2393lolevel.scm",(void*)f_2393},
{"f_2400lolevel.scm",(void*)f_2400},
{"f_2415lolevel.scm",(void*)f_2415},
{"f_2403lolevel.scm",(void*)f_2403},
{"f_2326lolevel.scm",(void*)f_2326},
{"f_2338lolevel.scm",(void*)f_2338},
{"f_2360lolevel.scm",(void*)f_2360},
{"f_2363lolevel.scm",(void*)f_2363},
{"f_2333lolevel.scm",(void*)f_2333},
{"f_2191lolevel.scm",(void*)f_2191},
{"f_2195lolevel.scm",(void*)f_2195},
{"f_2204lolevel.scm",(void*)f_2204},
{"f_2209lolevel.scm",(void*)f_2209},
{"f_2225lolevel.scm",(void*)f_2225},
{"f_2268lolevel.scm",(void*)f_2268},
{"f_2271lolevel.scm",(void*)f_2271},
{"f_2280lolevel.scm",(void*)f_2280},
{"f_2301lolevel.scm",(void*)f_2301},
{"f_2274lolevel.scm",(void*)f_2274},
{"f_2254lolevel.scm",(void*)f_2254},
{"f_2257lolevel.scm",(void*)f_2257},
{"f_2238lolevel.scm",(void*)f_2238},
{"f_2241lolevel.scm",(void*)f_2241},
{"f_2107lolevel.scm",(void*)f_2107},
{"f_2111lolevel.scm",(void*)f_2111},
{"f_2116lolevel.scm",(void*)f_2116},
{"f_2129lolevel.scm",(void*)f_2129},
{"f_2186lolevel.scm",(void*)f_2186},
{"f_2138lolevel.scm",(void*)f_2138},
{"f_2150lolevel.scm",(void*)f_2150},
{"f_2172lolevel.scm",(void*)f_2172},
{"f_2141lolevel.scm",(void*)f_2141},
{"f_1937lolevel.scm",(void*)f_1937},
{"f_1941lolevel.scm",(void*)f_1941},
{"f_1944lolevel.scm",(void*)f_1944},
{"f_2086lolevel.scm",(void*)f_2086},
{"f_1947lolevel.scm",(void*)f_1947},
{"f_1950lolevel.scm",(void*)f_1950},
{"f_1958lolevel.scm",(void*)f_1958},
{"f_1968lolevel.scm",(void*)f_1968},
{"f_2079lolevel.scm",(void*)f_2079},
{"f_2067lolevel.scm",(void*)f_2067},
{"f_2071lolevel.scm",(void*)f_2071},
{"f_2063lolevel.scm",(void*)f_2063},
{"f_1980lolevel.scm",(void*)f_1980},
{"f_2040lolevel.scm",(void*)f_2040},
{"f_1986lolevel.scm",(void*)f_1986},
{"f_1989lolevel.scm",(void*)f_1989},
{"f_2001lolevel.scm",(void*)f_2001},
{"f_2022lolevel.scm",(void*)f_2022},
{"f_1992lolevel.scm",(void*)f_1992},
{"f_1953lolevel.scm",(void*)f_1953},
{"f_1845lolevel.scm",(void*)f_1845},
{"f_1854lolevel.scm",(void*)f_1854},
{"f_1899lolevel.scm",(void*)f_1899},
{"f_1909lolevel.scm",(void*)f_1909},
{"f_1883lolevel.scm",(void*)f_1883},
{"f_1890lolevel.scm",(void*)f_1890},
{"f_1927lolevel.scm",(void*)f_1927},
{"f_1734lolevel.scm",(void*)f_1734},
{"f_1741lolevel.scm",(void*)f_1741},
{"f_1746lolevel.scm",(void*)f_1746},
{"f_1756lolevel.scm",(void*)f_1756},
{"f_1765lolevel.scm",(void*)f_1765},
{"f_1769lolevel.scm",(void*)f_1769},
{"f_1775lolevel.scm",(void*)f_1775},
{"f_1787lolevel.scm",(void*)f_1787},
{"f_1808lolevel.scm",(void*)f_1808},
{"f_1778lolevel.scm",(void*)f_1778},
{"f_1838lolevel.scm",(void*)f_1838},
{"f_1731lolevel.scm",(void*)f_1731},
{"f_1650lolevel.scm",(void*)f_1650},
{"f_1656lolevel.scm",(void*)f_1656},
{"f_1686lolevel.scm",(void*)f_1686},
{"f_1701lolevel.scm",(void*)f_1701},
{"f_1722lolevel.scm",(void*)f_1722},
{"f_1689lolevel.scm",(void*)f_1689},
{"f_1596lolevel.scm",(void*)f_1596},
{"f_1609lolevel.scm",(void*)f_1609},
{"f_1614lolevel.scm",(void*)f_1614},
{"f_1590lolevel.scm",(void*)f_1590},
{"f_1581lolevel.scm",(void*)f_1581},
{"f_1559lolevel.scm",(void*)f_1559},
{"f_1538lolevel.scm",(void*)f_1538},
{"f_1551lolevel.scm",(void*)f_1551},
{"f_1542lolevel.scm",(void*)f_1542},
{"f_1518lolevel.scm",(void*)f_1518},
{"f_1522lolevel.scm",(void*)f_1522},
{"f_1484lolevel.scm",(void*)f_1484},
{"f_1502lolevel.scm",(void*)f_1502},
{"f_1494lolevel.scm",(void*)f_1494},
{"f_1453lolevel.scm",(void*)f_1453},
{"f_1468lolevel.scm",(void*)f_1468},
{"f_1466lolevel.scm",(void*)f_1466},
{"f_1415lolevel.scm",(void*)f_1415},
{"f_1419lolevel.scm",(void*)f_1419},
{"f_1440lolevel.scm",(void*)f_1440},
{"f_1424lolevel.scm",(void*)f_1424},
{"f_1393lolevel.scm",(void*)f_1393},
{"f_1377lolevel.scm",(void*)f_1377},
{"f_1362lolevel.scm",(void*)f_1362},
{"f_1366lolevel.scm",(void*)f_1366},
{"f_1369lolevel.scm",(void*)f_1369},
{"f_1316lolevel.scm",(void*)f_1316},
{"f_1302lolevel.scm",(void*)f_1302},
{"f_1288lolevel.scm",(void*)f_1288},
{"f_1274lolevel.scm",(void*)f_1274},
{"f_1260lolevel.scm",(void*)f_1260},
{"f_1246lolevel.scm",(void*)f_1246},
{"f_1232lolevel.scm",(void*)f_1232},
{"f_1218lolevel.scm",(void*)f_1218},
{"f_1204lolevel.scm",(void*)f_1204},
{"f_1172lolevel.scm",(void*)f_1172},
{"f_1199lolevel.scm",(void*)f_1199},
{"f_1166lolevel.scm",(void*)f_1166},
{"f_1156lolevel.scm",(void*)f_1156},
{"f_1149lolevel.scm",(void*)f_1149},
{"f_1140lolevel.scm",(void*)f_1140},
{"f_1144lolevel.scm",(void*)f_1144},
{"f_1147lolevel.scm",(void*)f_1147},
{"f_1134lolevel.scm",(void*)f_1134},
{"f_1138lolevel.scm",(void*)f_1138},
{"f_1123lolevel.scm",(void*)f_1123},
{"f_1131lolevel.scm",(void*)f_1131},
{"f_1110lolevel.scm",(void*)f_1110},
{"f_1114lolevel.scm",(void*)f_1114},
{"f_1121lolevel.scm",(void*)f_1121},
{"f_1101lolevel.scm",(void*)f_1101},
{"f_1105lolevel.scm",(void*)f_1105},
{"f_1082lolevel.scm",(void*)f_1082},
{"f_1086lolevel.scm",(void*)f_1086},
{"f_1073lolevel.scm",(void*)f_1073},
{"f_1054lolevel.scm",(void*)f_1054},
{"f_1061lolevel.scm",(void*)f_1061},
{"f_727lolevel.scm",(void*)f_727},
{"f_991lolevel.scm",(void*)f_991},
{"f_986lolevel.scm",(void*)f_986},
{"f_981lolevel.scm",(void*)f_981},
{"f_729lolevel.scm",(void*)f_729},
{"f_789lolevel.scm",(void*)f_789},
{"f_851lolevel.scm",(void*)f_851},
{"f_912lolevel.scm",(void*)f_912},
{"f_927lolevel.scm",(void*)f_927},
{"f_944lolevel.scm",(void*)f_944},
{"f_954lolevel.scm",(void*)f_954},
{"f_934lolevel.scm",(void*)f_934},
{"f_860lolevel.scm",(void*)f_860},
{"f_876lolevel.scm",(void*)f_876},
{"f_890lolevel.scm",(void*)f_890},
{"f_886lolevel.scm",(void*)f_886},
{"f_867lolevel.scm",(void*)f_867},
{"f_760lolevel.scm",(void*)f_760},
{"f_767lolevel.scm",(void*)f_767},
{"f_744lolevel.scm",(void*)f_744},
{"f_738lolevel.scm",(void*)f_738},
{"f_732lolevel.scm",(void*)f_732},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
