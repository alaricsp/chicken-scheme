/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:15
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: lolevel.scm -optimize-level 2 -include-path . -include-path . -explicit-use -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_pointer_to_object(ptr)   ((C_word*)C_block_item(ptr, 0))
#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[132];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,5),40,101,114,114,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,11),40,120,101,114,114,32,120,49,52,49,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,99,104,101,99,107,110,32,110,49,52,51,32,110,109,97,120,49,52,52,32,111,102,102,49,52,53,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,47),40,99,104,101,99,107,110,50,32,110,49,53,50,32,110,109,97,120,49,53,51,32,110,109,97,120,50,49,53,52,32,111,102,102,49,49,53,53,32,111,102,102,50,49,53,54,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,49,54,56,32,116,111,49,54,57,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,49,50,48,32,110,49,51,49,32,102,111,102,102,115,101,116,49,51,50,32,116,111,102,102,115,101,116,49,51,51,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,102,102,115,101,116,49,50,52,32,37,110,49,49,55,50,54,50,32,37,102,111,102,102,115,101,116,49,49,56,50,54,51,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,111,102,102,115,101,116,49,50,51,32,37,110,49,49,55,50,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,49,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,40),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,49,48,56,32,116,111,49,48,57,32,46,32,116,109,112,49,48,55,49,49,48,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,112,116,114,50,56,54,32,108,111,99,50,56,55,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,51,48,56,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,51,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,51,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,51,51,55,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,102,95,49,56,54,51,32,97,51,52,54,51,52,57,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,51,52,50,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,51,53,53,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,51,54,48,32,112,50,51,54,49,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,51,54,54,51,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,51,55,52,51,55,56,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,108,105,103,110,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,51,57,50,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,32),40,112,111,105,110,116,101,114,45,111,102,102,115,101,116,32,97,52,48,53,52,48,57,32,97,52,48,52,52,49,48,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,97,52,49,56,52,50,50,32,97,52,49,55,52,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,97,52,50,57,52,51,51,32,97,52,50,56,52,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,97,52,52,48,52,52,52,32,97,52,51,57,52,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,97,52,53,49,52,53,53,32,97,52,53,48,52,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,97,52,54,50,52,54,54,32,97,52,54,49,52,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,97,52,55,51,52,55,55,32,97,52,55,50,52,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,97,52,56,52,52,56,56,32,97,52,56,51,52,56,57,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,97,52,57,53,52,57,57,32,97,52,57,52,53,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,53,56,54,32,116,97,103,53,56,55,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,29),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,53,57,54,32,116,97,103,53,57,55,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,54,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,50,49,53,53,32,120,54,50,52,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,17),40,97,50,49,55,49,32,120,54,50,56,32,105,54,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,54,49,52,32,100,97,116,97,54,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,50,49,57,57,32,120,54,52,51,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,54,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,12),40,97,50,50,51,51,32,120,54,53,57,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,54,52,57,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,54,54,55,32,120,54,54,56,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,54,55,53,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,54,57,52,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,55,48,53,32,46,32,97,114,103,115,55,48,54,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,23),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,55,49,49,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,55,50,54,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,55,49,55,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,55,52,32,105,55,56,50,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,55,52,57,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,55,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,55,57,52,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,16),40,102,95,50,53,55,48,32,97,56,48,50,56,48,53,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,52,49,32,105,56,52,57,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,56,49,52,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,55,57,55,32,46,32,97,108,108,111,99,97,116,111,114,55,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,16),40,102,95,50,54,53,57,32,97,56,55,50,56,55,54,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,57,56,32,105,57,48,54,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,56,56,53,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,56,54,55,32,46,32,114,101,108,101,97,115,101,114,56,54,56,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,57,55,55,32,105,57,56,53,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,57,52,53,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,57,49,55,32,112,116,114,57,49,56,32,46,32,108,105,109,105,116,57,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,51,51,32,105,49,48,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,13),40,101,118,105,99,116,32,120,49,48,49,54,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,19),40,111,98,106,101,99,116,45,115,105,122,101,32,120,49,48,48,56,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,49,49,51,32,105,49,49,50,49,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,120,49,48,56,54,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,49,48,54,52,32,46,32,116,109,112,49,48,54,51,49,48,54,53,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,49,49,52,52,41,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,24),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,108,115,116,49,49,51,56,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,35),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,49,49,55,52,32,112,114,111,99,49,49,55,53,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,49,49,57,49,32,46,32,105,110,100,101,120,49,49,57,50,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,49,50,48,52,32,46,32,105,110,100,101,120,49,50,48,53,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,49,50,49,55,32,121,49,50,49,56,41,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,24),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,49,50,50,51,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,17),40,108,111,99,97,116,105,118,101,63,32,120,49,50,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,111,111,107,32,46,32,97,114,103,115,49,50,51,56,41,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,97,110,100,108,101,114,33,32,112,114,111,99,49,50,51,52,41,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,34),40,117,110,98,111,117,110,100,45,118,97,114,105,97,98,108,101,45,118,97,108,117,101,32,46,32,118,97,108,49,50,52,52,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,20),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,49,50,53,48,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,27),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,49,50,53,53,32,120,49,50,53,54,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,23),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,49,50,54,49,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,30),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,49,50,54,54,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,15),40,97,51,51,48,51,32,97,53,55,52,53,55,56,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,15),40,97,51,51,49,51,32,97,53,54,51,53,54,55,41,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,97,51,51,50,51,32,97,53,53,50,53,53,54,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,51,51,51,51,32,97,53,52,49,53,52,53,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,51,51,52,51,32,97,53,51,50,53,51,54,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,15),40,97,51,51,53,51,32,97,53,50,51,53,50,55,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,15),40,97,51,51,54,51,32,97,53,49,52,53,49,56,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,15),40,97,51,51,55,51,32,97,53,48,53,53,48,57,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2662 */
static C_word C_fcall stub873(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub873(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2573 */
static C_word C_fcall stub803(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub803(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k3307 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub575(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub575(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3317 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub564(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub564(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3327 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub553(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub553(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3337 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub542(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub542(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3347 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub533(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub533(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3357 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub524(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub524(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3367 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub515(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub515(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_ret:
#undef return

return C_r;}

/* from k3377 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub506(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub506(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k2055 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub496(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub496(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2041 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub485(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub485(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2027 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub474(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub474(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2013 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub463(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub463(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1999 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub452(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub452(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1985 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub441(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub441(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1971 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub430(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub430(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1957 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub419(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub419(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1943 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub406(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub406(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from k1901 */
static C_word C_fcall stub385(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub385(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1891 */
static C_word C_fcall stub375(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub375(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1884 */
static C_word C_fcall stub367(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub367(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from f_1863 in object->pointer in k1343 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub347(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub347(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1450 */
static C_word C_fcall stub87(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub87(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1422 */
static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1394 */
static C_word C_fcall stub49(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub49(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1366 */
static C_word C_fcall stub30(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub30(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2072)
static void C_ccall f_2072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3254)
static void C_fcall f_3254(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3070)
static void C_fcall f_3070(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_fcall f_2941(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_fcall f_3012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_fcall f_2882(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_fcall f_2676(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_fcall f_2690(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_fcall f_2733(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2586)
static void C_fcall f_2586(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2631)
static void C_fcall f_2631(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_fcall f_2478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_fcall f_2519(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2388)
static void C_fcall f_2388(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_fcall f_2433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static C_word C_fcall f_2346(C_word t0,C_word t1);
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2283)
static void C_fcall f_2283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2198)
static void C_ccall f_2198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static C_word C_fcall f_1898(C_word *a,C_word t0);
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_ccall f_1853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1793)
static void C_fcall f_1793(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1723)
static void C_fcall f_1723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1713)
static void C_fcall f_1713(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1461)
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1521)
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_fcall f_1492(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1499)
static void C_fcall f_1499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_fcall f_1476(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1470)
static void C_fcall f_1470(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_fcall f_1464(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3254)
static void C_fcall trf_3254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3254(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3254(t0,t1);}

C_noret_decl(trf_3070)
static void C_fcall trf_3070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3070(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3070(t0,t1,t2);}

C_noret_decl(trf_2941)
static void C_fcall trf_2941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2941(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2941(t0,t1,t2);}

C_noret_decl(trf_3012)
static void C_fcall trf_3012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3012(t0,t1,t2);}

C_noret_decl(trf_2848)
static void C_fcall trf_2848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2848(t0,t1,t2);}

C_noret_decl(trf_2882)
static void C_fcall trf_2882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2882(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2882(t0,t1,t2);}

C_noret_decl(trf_2676)
static void C_fcall trf_2676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2676(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2676(t0,t1);}

C_noret_decl(trf_2690)
static void C_fcall trf_2690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2690(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2690(t0,t1,t2);}

C_noret_decl(trf_2733)
static void C_fcall trf_2733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2733(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2733(t0,t1,t2);}

C_noret_decl(trf_2586)
static void C_fcall trf_2586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2586(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2586(t0,t1,t2);}

C_noret_decl(trf_2631)
static void C_fcall trf_2631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2631(t0,t1,t2);}

C_noret_decl(trf_2478)
static void C_fcall trf_2478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2478(t0,t1,t2);}

C_noret_decl(trf_2519)
static void C_fcall trf_2519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2519(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2519(t0,t1,t2);}

C_noret_decl(trf_2388)
static void C_fcall trf_2388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2388(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2388(t0,t1,t2);}

C_noret_decl(trf_2433)
static void C_fcall trf_2433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2433(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2433(t0,t1,t2);}

C_noret_decl(trf_2283)
static void C_fcall trf_2283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2283(t0,t1);}

C_noret_decl(trf_1793)
static void C_fcall trf_1793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1793(t0,t1);}

C_noret_decl(trf_1723)
static void C_fcall trf_1723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1723(t0,t1);}

C_noret_decl(trf_1718)
static void C_fcall trf_1718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1718(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1718(t0,t1,t2);}

C_noret_decl(trf_1713)
static void C_fcall trf_1713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1713(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1713(t0,t1,t2,t3);}

C_noret_decl(trf_1461)
static void C_fcall trf_1461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1461(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1461(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1521)
static void C_fcall trf_1521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1521(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1521(t0,t1,t2,t3);}

C_noret_decl(trf_1492)
static void C_fcall trf_1492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1492(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1492(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1499)
static void C_fcall trf_1499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1499(t0,t1);}

C_noret_decl(trf_1476)
static void C_fcall trf_1476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1476(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1476(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1470)
static void C_fcall trf_1470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1470(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1470(t0,t1);}

C_noret_decl(trf_1464)
static void C_fcall trf_1464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1464(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1177)){
C_save(t1);
C_rereclaim2(1177*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,132);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[3]=C_h_intern(&lf[3],12,"move-memory!");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],11,"\000type-error");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid argument type");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[11]=C_h_intern(&lf[11],15,"\003sysbytevector\077");
lf[12]=C_h_intern(&lf[12],13,"\003syslocative\077");
lf[13]=C_h_intern(&lf[13],17,"\003syscheck-pointer");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[15]=C_h_intern(&lf[15],12,"null-pointer");
lf[16]=C_h_intern(&lf[16],16,"\003sysnull-pointer");
lf[17]=C_h_intern(&lf[17],8,"pointer\077");
lf[18]=C_h_intern(&lf[18],16,"address->pointer");
lf[19]=C_h_intern(&lf[19],20,"\003sysaddress->pointer");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\042bad argument type - not an integer");
lf[21]=C_h_intern(&lf[21],16,"pointer->address");
lf[22]=C_h_intern(&lf[22],20,"\003syspointer->address");
lf[23]=C_h_intern(&lf[23],17,"\003syscheck-special");
lf[24]=C_h_intern(&lf[24],13,"null-pointer\077");
lf[25]=C_h_intern(&lf[25],15,"object->pointer");
lf[26]=C_h_intern(&lf[26],15,"pointer->object");
lf[27]=C_h_intern(&lf[27],9,"pointer=\077");
lf[28]=C_h_intern(&lf[28],8,"allocate");
lf[29]=C_h_intern(&lf[29],4,"free");
lf[30]=C_h_intern(&lf[30],13,"align-to-word");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000+bad argument type - not a pointer or fixnum");
lf[32]=C_h_intern(&lf[32],14,"pointer-offset");
lf[33]=C_h_intern(&lf[33],15,"pointer-u8-set!");
lf[34]=C_h_intern(&lf[34],15,"pointer-s8-set!");
lf[35]=C_h_intern(&lf[35],16,"pointer-u16-set!");
lf[36]=C_h_intern(&lf[36],16,"pointer-s16-set!");
lf[37]=C_h_intern(&lf[37],16,"pointer-u32-set!");
lf[38]=C_h_intern(&lf[38],16,"pointer-s32-set!");
lf[39]=C_h_intern(&lf[39],16,"pointer-f32-set!");
lf[40]=C_h_intern(&lf[40],16,"pointer-f64-set!");
lf[41]=C_h_intern(&lf[41],14,"pointer-u8-ref");
lf[42]=C_h_intern(&lf[42],14,"pointer-s8-ref");
lf[43]=C_h_intern(&lf[43],15,"pointer-u16-ref");
lf[44]=C_h_intern(&lf[44],15,"pointer-s16-ref");
lf[45]=C_h_intern(&lf[45],15,"pointer-u32-ref");
lf[46]=C_h_intern(&lf[46],15,"pointer-s32-ref");
lf[47]=C_h_intern(&lf[47],15,"pointer-f32-ref");
lf[48]=C_h_intern(&lf[48],15,"pointer-f64-ref");
lf[49]=C_h_intern(&lf[49],11,"tag-pointer");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[51]=C_h_intern(&lf[51],23,"\003sysmake-tagged-pointer");
lf[52]=C_h_intern(&lf[52],15,"tagged-pointer\077");
lf[53]=C_h_intern(&lf[53],11,"pointer-tag");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[55]=C_h_intern(&lf[55],8,"extended");
lf[57]=C_h_intern(&lf[57],16,"extend-procedure");
lf[58]=C_h_intern(&lf[58],19,"\003sysdecorate-lambda");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[60]=C_h_intern(&lf[60],19,"extended-procedure\077");
lf[61]=C_h_intern(&lf[61],21,"\003syslambda-decoration");
lf[62]=C_h_intern(&lf[62],14,"procedure-data");
lf[63]=C_h_intern(&lf[63],19,"set-procedure-data!");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[65]=C_h_intern(&lf[65],10,"block-set!");
lf[66]=C_h_intern(&lf[66],14,"\003sysblock-set!");
lf[67]=C_h_intern(&lf[67],9,"block-ref");
lf[68]=C_h_intern(&lf[68],15,"number-of-slots");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\024slots not accessible");
lf[70]=C_h_intern(&lf[70],15,"number-of-bytes");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\0003can not compute number of bytes of immediate object");
lf[72]=C_h_intern(&lf[72],20,"make-record-instance");
lf[73]=C_h_intern(&lf[73],18,"\003sysmake-structure");
lf[74]=C_h_intern(&lf[74],16,"record-instance\077");
lf[75]=C_h_intern(&lf[75],14,"record->vector");
lf[76]=C_h_intern(&lf[76],15,"\003sysmake-vector");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a record structure");
lf[78]=C_h_intern(&lf[78],11,"object-copy");
lf[79]=C_h_intern(&lf[79],15,"object-evicted\077");
lf[80]=C_h_intern(&lf[80],12,"object-evict");
lf[81]=C_h_intern(&lf[81],19,"\003syshash-table-set!");
lf[82]=C_h_intern(&lf[82],18,"\003syshash-table-ref");
lf[83]=C_h_intern(&lf[83],14,"object-release");
lf[84]=C_h_intern(&lf[84],24,"object-evict-to-location");
lf[85]=C_h_intern(&lf[85],24,"\003sysset-pointer-address!");
lf[86]=C_h_intern(&lf[86],6,"signal");
lf[87]=C_h_intern(&lf[87],24,"make-composite-condition");
lf[88]=C_h_intern(&lf[88],23,"make-property-condition");
lf[89]=C_h_intern(&lf[89],5,"evict");
lf[90]=C_h_intern(&lf[90],5,"limit");
lf[91]=C_h_intern(&lf[91],3,"exn");
lf[92]=C_h_intern(&lf[92],8,"location");
lf[93]=C_h_intern(&lf[93],7,"message");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000%can not evict object - limit exceeded");
lf[95]=C_h_intern(&lf[95],9,"arguments");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[97]=C_h_intern(&lf[97],11,"object-size");
lf[98]=C_h_intern(&lf[98],14,"object-unevict");
lf[99]=C_h_intern(&lf[99],15,"\003sysmake-string");
lf[100]=C_h_intern(&lf[100],14,"object-become!");
lf[101]=C_h_intern(&lf[101],11,"\003sysbecome!");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - new item is immediate");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - old item is immediate");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not an a-list");
lf[105]=C_h_intern(&lf[105],16,"mutate-procedure");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[107]=C_h_intern(&lf[107],13,"make-locative");
lf[108]=C_h_intern(&lf[108],17,"\003sysmake-locative");
lf[109]=C_h_intern(&lf[109],18,"make-weak-locative");
lf[110]=C_h_intern(&lf[110],13,"locative-set!");
lf[111]=C_h_intern(&lf[111],12,"locative-ref");
lf[112]=C_h_intern(&lf[112],16,"locative->object");
lf[113]=C_h_intern(&lf[113],9,"locative\077");
lf[115]=C_h_intern(&lf[115],35,"set-invalid-procedure-call-handler!");
lf[116]=C_h_intern(&lf[116],31,"\003sysinvalid-procedure-call-hook");
lf[117]=C_h_intern(&lf[117],26,"\003syslast-invalid-procedure");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[119]=C_h_intern(&lf[119],22,"unbound-variable-value");
lf[120]=C_h_intern(&lf[120],31,"\003sysunbound-variable-value-hook");
lf[121]=C_h_intern(&lf[121],10,"global-ref");
lf[122]=C_h_intern(&lf[122],11,"global-set!");
lf[123]=C_h_intern(&lf[123],13,"global-bound\077");
lf[124]=C_h_intern(&lf[124],32,"\003syssymbol-has-toplevel-binding\077");
lf[125]=C_h_intern(&lf[125],20,"global-make-unbound!");
lf[126]=C_h_intern(&lf[126],28,"\003sysarbitrary-unbound-symbol");
lf[127]=C_h_intern(&lf[127],18,"getter-with-setter");
lf[128]=C_h_intern(&lf[128],13,"\003sysblock-ref");
lf[129]=C_h_intern(&lf[129],15,"pointer-s6-set!");
lf[130]=C_h_intern(&lf[130],17,"register-feature!");
lf[131]=C_h_intern(&lf[131],7,"lolevel");
C_register_lf2(lf,132,create_ptable());
t2=C_mutate(&lf[0] /* c283 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 66   register-feature!");
t4=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[131]);}

/* k1343 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[74],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=lf[2];
t3=C_mutate((C_word*)lf[3]+1 /* move-memory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1459,a[2]=t2,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[13]+1 /* check-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[15]+1 /* null-pointer ...) */,*((C_word*)lf[16]+1));
t6=C_mutate((C_word*)lf[17]+1 /* pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[18]+1 /* address->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[21]+1 /* pointer->address ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1833,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[24]+1 /* null-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1842,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[25]+1 /* object->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1855,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[26]+1 /* pointer->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* pointer=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1872,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[28]+1 /* allocate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[29]+1 /* free ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t16=C_mutate((C_word*)lf[30]+1 /* align-to-word ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=t15,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[32]+1 /* pointer-offset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[33]+1 /* pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1950,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[34]+1 /* pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[35]+1 /* pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1978,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[36]+1 /* pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1992,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[37]+1 /* pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2006,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[38]+1 /* pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2020,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[39]+1 /* pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2034,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[40]+1 /* pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3374,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 186  getter-with-setter");
t28=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t28))(4,t28,t26,t27,*((C_word*)lf[33]+1));}

/* a3373 in k1343 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3374,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub506(C_SCHEME_UNDEFINED,t3));}

/* k2062 in k1343 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1 /* pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2068,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 191  getter-with-setter");
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[34]+1));}

/* a3363 in k2062 in k1343 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3364,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub515(C_SCHEME_UNDEFINED,t3));}

/* k2066 in k2062 in k1343 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2072,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3354,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 196  getter-with-setter");
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[35]+1));}

/* a3353 in k2066 in k2062 in k1343 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3354,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub524(C_SCHEME_UNDEFINED,t3));}

/* k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2072,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 201  getter-with-setter");
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[129]+1));}

/* a3343 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3344,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub533(C_SCHEME_UNDEFINED,t3));}

/* k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1 /* pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2080,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 206  getter-with-setter");
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[37]+1));}

/* a3333 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3334,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub542(t3,t4));}

/* k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2080,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3324,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 211  getter-with-setter");
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[38]+1));}

/* a3323 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3324,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub553(t3,t4));}

/* k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2084,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 216  getter-with-setter");
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[39]+1));}

/* a3313 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3314,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub564(t3,t4));}

/* k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1 /* pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 221  getter-with-setter");
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[40]+1));}

/* a3303 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3304,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub575(t3,t4));}

/* k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2092,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* pointer-f64-ref ...) */,t1);
t3=C_mutate((C_word*)lf[49]+1 /* tag-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[52]+1 /* tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2109,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[53]+1 /* pointer-tag ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t6=(C_word)C_a_i_vector(&a,1,lf[55]);
t7=C_mutate(&lf[56] /* xproc-tag ...) */,t6);
t8=C_mutate((C_word*)lf[57]+1 /* extend-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[60]+1 /* extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2185,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[62]+1 /* procedure-data ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2216,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[63]+1 /* set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2250,a[2]=t11,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t13=C_mutate((C_word*)lf[65]+1 /* block-set! ...) */,*((C_word*)lf[66]+1));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 283  getter-with-setter");
t15=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t15))(4,t15,t14,*((C_word*)lf[128]+1),*((C_word*)lf[66]+1));}

/* k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[57],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[68]+1 /* number-of-slots ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[70]+1 /* number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[72]+1 /* make-record-instance ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2313,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[74]+1 /* record-instance? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2322,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[75]+1 /* record->vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2328,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[78]+1 /* object-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2382,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[79]+1 /* object-evicted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[80]+1 /* object-evict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2466,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[83]+1 /* object-release ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[84]+1 /* object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2669,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[97]+1 /* object-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2839,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[98]+1 /* object-unevict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2923,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[100]+1 /* object-become! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[105]+1 /* mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3121,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[107]+1 /* make-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3155,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[109]+1 /* make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3184,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[110]+1 /* locative-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 523  getter-with-setter");
t22=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t22))(4,t22,t20,t21,*((C_word*)lf[110]+1));}

/* k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1 /* locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[112]+1 /* locative->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[113]+1 /* locative? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t5=lf[114] /* ipc-hook-0 */ =C_SCHEME_FALSE;;
t6=C_mutate((C_word*)lf[115]+1 /* set-invalid-procedure-call-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[119]+1 /* unbound-variable-value ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[121]+1 /* global-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3266,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[122]+1 /* global-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[123]+1 /* global-bound? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[125]+1 /* global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3290,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3290,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[125]);
t4=(C_word)C_slot(lf[126],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3281,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[123]);
C_trace("lolevel.scm: 558  ##sys#symbol-has-toplevel-binding?");
t4=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* global-set! in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3272,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[122]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3266,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3249r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3249r(t0,t1,t2);}}

static void C_ccall f_3249r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3254,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_3254(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_3254(t4,C_SCHEME_FALSE);}}

/* k3252 in unbound-variable-value in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_3254(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[120]+1 /* unbound-variable-value-hook ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* set-invalid-procedure-call-handler! in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3230,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3234,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t4=t3;
f_3234(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("lolevel.scm: 534  ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[115],lf[118],t2);}}

/* k3232 in set-invalid-procedure-call-handler! in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
t2=C_mutate(&lf[114] /* ipc-hook-0 ...) */,((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[116]+1 /* invalid-procedure-call-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3237,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k3232 in set-invalid-procedure-call-handler! in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3237r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3237r(t0,t1,t2);}}

static void C_ccall f_3237r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_trace("lolevel.scm: 538  ipc-hook-0");
t3=lf[114];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,*((C_word*)lf[117]+1),t2);}

/* locative? in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3223,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k3216 in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3220,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3213,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3184r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3184r(t0,t1,t2,t3);}}

static void C_ccall f_3184r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3192,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3192(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3192(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3190 in make-weak-locative in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 520  ##sys#make-locative");
t2=*((C_word*)lf[108]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[109]);}

/* make-locative in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3155r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3155r(t0,t1,t2,t3);}}

static void C_ccall f_3155r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3163,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3163(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3163(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3161 in make-locative in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 517  ##sys#make-locative");
t2=*((C_word*)lf[108]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[107]);}

/* mutate-procedure in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3121,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3125,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t5=t4;
f_3125(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("lolevel.scm: 506  ##sys#signal-hook");
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[105],lf[106],t2);}}

/* k3123 in mutate-procedure in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("lolevel.scm: 509  ##sys#make-vector");
t5=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3130 in k3123 in mutate-procedure in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3147,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 510  proc");
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3145 in k3130 in k3123 in mutate-procedure in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3147,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
C_trace("lolevel.scm: 510  ##sys#become!");
t4=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3133 in k3130 in k3123 in mutate-procedure in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3058,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3065,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=t6,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3070(t8,t4,t2);}

/* loop in object-become! in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_3070(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3070,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_pair_2(t4,lf[100]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3092,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
if(C_truep((C_word)C_blockp(t7))){
t8=t6;
f_3092(2,t8,C_SCHEME_UNDEFINED);}
else{
C_trace("lolevel.scm: 497  ##sys#signal-hook");
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[7],lf[100],lf[103],t4);}}
else{
C_trace("lolevel.scm: 501  ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[7],lf[100],lf[104]);}}}

/* k3090 in loop in object-become! in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_blockp(t3))){
t4=t2;
f_3095(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("lolevel.scm: 499  ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[100],lf[102],((C_word*)t0)[2]);}}

/* k3093 in k3090 in loop in object-become! in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
C_trace("lolevel.scm: 500  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3070(t3,((C_word*)t0)[2],t2);}

/* k3063 in object-become! in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 502  ##sys#become!");
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2923r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2923r(t0,t1,t2,t3);}}

static void C_ccall f_2923r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2927,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2927(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2927(2,t6,(C_word)C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("lolevel.scm: 458  ##sys#make-vector");
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2941,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2941(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2941(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2941,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("lolevel.scm: 462  ##sys#hash-table-ref");
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2957,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
C_trace("lolevel.scm: 465  ##sys#make-string");
t4=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("lolevel.scm: 470  ##sys#intern-symbol");
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("lolevel.scm: 475  ##sys#make-vector");
t4=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2998 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("lolevel.scm: 476  ##sys#hash-table-set!");
t4=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k3001 in k2998 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li67),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3012(t7,t2,t3);}

/* doloop1113 in k3001 in k2998 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_3012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3012,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3033,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
C_trace("lolevel.scm: 479  copy");
t5=((C_word*)((C_word*)t0)[2])[1];
f_2941(t5,t3,t4);}}

/* k3031 in doloop1113 in k3001 in k2998 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3012(t4,((C_word*)t0)[2],t3);}

/* k3004 in k3001 in k2998 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2984 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2989,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 471  ##sys#hash-table-set!");
t3=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2987 in k2984 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2968 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2973,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 466  ##sys#hash-table-set!");
t4=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2971 in k2968 in k2955 in copy in k2934 in k2925 in object-unevict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2839,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2843,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 435  ##sys#make-vector");
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2841 in object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2843,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2848,a[2]=t1,a[3]=t3,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2848(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2841 in object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2848,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("lolevel.scm: 438  ##sys#hash-table-ref");
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2859 in evict in k2841 in object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
C_trace("lolevel.scm: 442  align-to-word");
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2918(2,t4,(C_word)C_bytes(t2));}}}

/* k2916 in k2859 in evict in k2841 in object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("lolevel.scm: 444  ##sys#hash-table-set!");
t6=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2868 in k2916 in k2859 in evict in k2841 in object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2873,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2873(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li64),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2882(t9,t2,t5);}}

/* doloop1033 in k2868 in k2916 in k2859 in evict in k2841 in object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2882(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2882,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2904,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
C_trace("lolevel.scm: 451  evict");
t5=((C_word*)((C_word*)t0)[2])[1];
f_2848(t5,t3,t4);}}

/* k2902 in doloop1033 in k2868 in k2916 in k2859 in evict in k2841 in object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2882(t5,((C_word*)t0)[2],t4);}

/* k2871 in k2868 in k2916 in k2859 in evict in k2841 in object-size in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2669r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2669r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2669r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2673,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t5;
f_2673(2,t7,C_SCHEME_UNDEFINED);}
else{
C_trace("lolevel.scm: 390  ##sys#signal-hook");
t7=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[7],lf[84],lf[96],t3);}}

/* k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[84]);
t5=t2;
f_2676(t5,t3);}
else{
t3=t2;
f_2676(t3,C_SCHEME_FALSE);}}

/* k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2676(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2676,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2818,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 398  ##sys#pointer->address");
t6=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2816 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 398  ##sys#address->pointer");
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("lolevel.scm: 399  ##sys#make-vector");
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li62),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2690(t6,t2,((C_word*)t0)[2]);}

/* evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2690(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2690,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("lolevel.scm: 403  ##sys#hash-table-ref");
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2700,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
C_trace("lolevel.scm: 407  align-to-word");
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2811(2,t4,(C_word)C_bytes(t2));}}}

/* k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2712,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2795,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
C_trace("lolevel.scm: 414  make-property-condition");
t9=*((C_word*)lf[88]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[91],lf[92],lf[84],lf[93],lf[94],lf[95],t8);}
else{
t6=t3;
f_2712(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2712(2,t4,C_SCHEME_UNDEFINED);}}

/* k2797 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2803,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 418  make-property-condition");
t3=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[89],lf[90],((C_word*)((C_word*)t0)[2])[1]);}

/* k2801 in k2797 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 413  make-composite-condition");
t2=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2793 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 412  signal");
t2=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2710 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[8]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("lolevel.scm: 421  ##sys#pointer->address");
t7=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[7]);}

/* k2770 in k2710 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
C_trace("lolevel.scm: 421  ##sys#set-pointer-address!");
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2716 in k2710 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("lolevel.scm: 422  ##sys#hash-table-set!");
t3=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2719 in k2716 in k2710 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2724(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li61),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2733(t9,t2,t5);}}

/* doloop977 in k2719 in k2716 in k2710 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2733(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2733,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2754,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
C_trace("lolevel.scm: 429  evict");
t5=((C_word*)((C_word*)t0)[2])[1];
f_2690(t5,t3,t4);}}

/* k2752 in doloop977 in k2719 in k2716 in k2710 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2733(t4,((C_word*)t0)[2],t3);}

/* k2722 in k2719 in k2716 in k2710 in k2809 in k2698 in evict in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2683 in k2680 in k2677 in k2674 in k2671 in object-evict-to-location in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 431  values");
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-release in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2577r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2577r(t0,t1,t2,t3);}}

static void C_ccall f_2577r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2659,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2586,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2586(t11,t1,t2);}

/* release in object-release in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2586(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2586,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2615,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_2615(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_2631(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* doloop898 in release in object-release in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2631(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2631,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2641,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
C_trace("lolevel.scm: 382  release");
t5=((C_word*)((C_word*)t0)[2])[1];
f_2586(t5,t3,t4);}}

/* k2639 in doloop898 in release in object-release in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2631(t3,((C_word*)t0)[2],t2);}

/* k2613 in release in object-release in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 383  ##sys#address->pointer");
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2620 in k2613 in release in object-release in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 383  free");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_2659 in object-release in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2659,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub873(C_SCHEME_UNDEFINED,t3));}

/* object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2466r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2466r(t0,t1,t2,t3);}}

static void C_ccall f_2466r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2570,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2473,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("lolevel.scm: 349  ##sys#make-vector");
t7=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2473,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2478(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2478,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2488,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("lolevel.scm: 352  ##sys#hash-table-ref");
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2486 in evict in k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2488,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2497,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
C_trace("lolevel.scm: 355  align-to-word");
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2497(2,t4,(C_word)C_bytes(t2));}}}

/* k2495 in k2486 in evict in k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
C_trace("lolevel.scm: 356  allocator");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2499 in k2495 in k2486 in evict in k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2501,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(C_word)C_i_symbolp(((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("lolevel.scm: 358  ##sys#hash-table-set!");
t6=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2505 in k2499 in k2495 in k2486 in evict in k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2510(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li54),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2519(t9,t2,t5);}}

/* doloop841 in k2505 in k2499 in k2495 in k2486 in evict in k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2519(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2519,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2540,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
C_trace("lolevel.scm: 363  evict");
t5=((C_word*)((C_word*)t0)[2])[1];
f_2478(t5,t3,t4);}}

/* k2538 in doloop841 in k2505 in k2499 in k2495 in k2486 in evict in k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2519(t4,((C_word*)t0)[2],t3);}

/* k2508 in k2505 in k2499 in k2495 in k2486 in evict in k2471 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2570 in object-evict in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2570,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub803(t3,t4));}

/* object-evicted? in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2463,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* object-copy in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2382,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2388,a[2]=t4,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2388(t6,t1,t2);}

/* copy in object-copy in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2388(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2388,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
C_trace("lolevel.scm: 325  ##sys#intern-symbol");
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2418,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("lolevel.scm: 329  ##sys#make-vector");
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2416 in copy in object-copy in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2418,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2421,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_2421(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_2433(t10,t3,t6);}}

/* doloop774 in k2416 in copy in object-copy in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2433,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2454,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
C_trace("lolevel.scm: 333  copy");
t5=((C_word*)((C_word*)t0)[2])[1];
f_2388(t5,t3,t4);}}

/* k2452 in doloop774 in k2416 in copy in object-copy in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2433(t4,((C_word*)t0)[2],t3);}

/* k2419 in k2416 in copy in object-copy in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* record->vector in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2328,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_structurep(t2));
if(C_truep(t4)){
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2341,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("lolevel.scm: 313  ##sys#make-vector");
t7=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
C_trace("lolevel.scm: 317  ##sys#signal-hook");
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[7],lf[75],lf[77],t2);}}

/* k2339 in record->vector in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2346(t2,C_fix(0)));}

/* doloop726 in k2339 in record->vector in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static C_word C_fcall f_2346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance? in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2322,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE));}

/* make-record-instance in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2313r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2313r(t0,t1,t2,t3);}}

static void C_ccall f_2313r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[72]);
C_apply(5,0,t1,*((C_word*)lf[73]+1),t2,t3);}

/* number-of-bytes in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2291,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
C_trace("lolevel.scm: 295  ##sys#signal-hook");
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[70],lf[71],t2);}}

/* number-of-slots in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2270,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2274,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2283(t6,t4);}
else{
t6=(C_word)C_specialp(t2);
t7=t5;
f_2283(t7,(C_truep(t6)?t6:(C_word)C_byteblockp(t2)));}}

/* k2281 in number-of-slots in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_fcall f_2283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("lolevel.scm: 290  ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[7],lf[68],lf[69],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2274(2,t2,C_SCHEME_UNDEFINED);}}

/* k2272 in number-of-slots in k2266 in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* set-procedure-data! in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2250,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 274  extend-procedure");
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k2252 in set-procedure-data! in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
C_trace("lolevel.scm: 277  ##sys#signal-hook");
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[7],lf[63],lf[64],((C_word*)t0)[3]);}}

/* procedure-data in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2216,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2226,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2234,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 268  ##sys#lambda-decoration");
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2233 in procedure-data in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2234,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2224 in procedure-data in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2185,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2198,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2200,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 262  ##sys#lambda-decoration");
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2199 in extended-procedure? in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2200,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2196 in extended-procedure? in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2147,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2151,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_closurep(t2))){
t5=t4;
f_2151(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("lolevel.scm: 251  ##sys#signal-hook");
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[57],lf[59],t2);}}

/* k2149 in extend-procedure in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2172,a[2]=((C_word*)t0)[4],a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 252  ##sys#decorate-lambda");
t4=*((C_word*)lf[58]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2171 in k2149 in extend-procedure in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2172,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[56],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2155 in k2149 in extend-procedure in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2156,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-tag in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2125,3,t0,t1,t2);}
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
C_trace("lolevel.scm: 241  ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[53],lf[54],t2);}}

/* tagged-pointer? in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2109,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_equalp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* tag-pointer in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2094,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 226  ##sys#make-tagged-pointer");
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2096 in tag-pointer in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_blockp(((C_word*)t0)[2]))?(C_word)C_specialp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2101(2,t4,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
C_trace("lolevel.scm: 229  ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[49],lf[50],((C_word*)t0)[2]);}}

/* k2099 in k2096 in tag-pointer in k2090 in k2086 in k2082 in k2078 in k2074 in k2070 in k2066 in k2062 in k1343 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pointer-f64-set! in k1343 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2048,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub496(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-f32-set! in k1343 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2034,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub485(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s32-set! in k1343 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2020,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub474(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u32-set! in k1343 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2006,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub463(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s16-set! in k1343 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1992,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub452(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u16-set! in k1343 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1978,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub441(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s8-set! in k1343 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1964,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub430(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u8-set! in k1343 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1950,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub419(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-offset in k1343 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1936,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub406(t4,t5,t6));}

/* align-to-word in k1343 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1904,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
C_trace("lolevel.scm: 167  align");
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,f_1898(C_a_i(&a,6),t2));}
else{
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1931,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 169  ##sys#pointer->address");
t5=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
C_trace("lolevel.scm: 170  ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[30],lf[31],t2);}}}

/* k1929 in align-to-word in k1343 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=f_1898(C_a_i(&a,6),t1);
C_trace("lolevel.scm: 169  ##sys#address->pointer");
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k1343 */
static C_word C_fcall f_1898(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)C_i_foreign_integer_argumentp(t1);
return((C_word)stub385(t2,t3));}

/* free in k1343 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1888,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub375(C_SCHEME_UNDEFINED,t3));}

/* allocate in k1343 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1881,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub367(t3,t4));}

/* pointer=? in k1343 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1872,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1876,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("lolevel.scm: 157  ##sys#check-special");
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[27]);}

/* k1874 in pointer=? in k1343 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("lolevel.scm: 158  ##sys#check-special");
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[27]);}

/* k1877 in k1874 in pointer=? in k1343 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k1343 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1866,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 153  ##sys#check-pointer");
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[26]);}

/* k1868 in pointer->object in k1343 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k1343 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1855,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1863,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1863 in object->pointer in k1343 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1863,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub347(t3,t2));}

/* null-pointer? in k1343 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1842,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1846,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 143  ##sys#check-special");
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[24]);}

/* k1844 in null-pointer? in k1343 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1853,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("lolevel.scm: 144  ##sys#pointer->address");
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1851 in k1844 in null-pointer? in k1343 */
static void C_ccall f_1853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k1343 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1833,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("lolevel.scm: 139  ##sys#check-special");
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[21]);}

/* k1835 in pointer->address in k1343 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 140  ##sys#pointer->address");
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k1343 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1814,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1818,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_integerp(t2))){
t4=t3;
f_1818(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("lolevel.scm: 134  ##sys#signal-hook");
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[18],lf[20],t2);}}

/* k1816 in address->pointer in k1343 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("lolevel.scm: 136  ##sys#address->pointer");
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer? in k1343 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1805,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_pointerp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_taggedpointerp(t2)));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#check-pointer in k1343 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1786,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1793,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t2))){
t5=(C_word)C_pointerp(t2);
if(C_truep(t5)){
t6=t4;
f_1793(t6,t5);}
else{
t6=(C_word)C_swigpointerp(t2);
t7=t4;
f_1793(t7,(C_truep(t6)?t6:(C_word)C_taggedpointerp(t2)));}}
else{
t5=t4;
f_1793(t5,C_SCHEME_FALSE);}}

/* k1791 in ##sys#check-pointer in k1343 */
static void C_fcall f_1793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("lolevel.scm: 121  ##sys#signal-hook");
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],lf[14],((C_word*)t0)[2]);}}

/* move-memory! in k1343 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_1459r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1459r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1459r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1461,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1713,a[2]=t5,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1718,a[2]=t6,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1723,a[2]=t7,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
C_trace("def-n122270");
t9=t8;
f_1723(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
C_trace("def-foffset123266");
t11=t7;
f_1718(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
C_trace("def-toffset124261");
t13=t6;
f_1713(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
C_trace("body120130");
t15=t5;
f_1461(t15,t1,t9,t11,t13);}
else{
C_trace("##sys#error");
t15=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n122 in move-memory! in k1343 */
static void C_fcall f_1723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1723,NULL,2,t0,t1);}
C_trace("def-foffset123266");
t2=((C_word*)t0)[2];
f_1718(t2,t1,C_SCHEME_FALSE);}

/* def-foffset123 in move-memory! in k1343 */
static void C_fcall f_1718(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1718,NULL,3,t0,t1,t2);}
C_trace("def-toffset124261");
t3=((C_word*)t0)[2];
f_1713(t3,t1,t2,C_fix(0));}

/* def-toffset124 in move-memory! in k1343 */
static void C_fcall f_1713(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1713,NULL,4,t0,t1,t2,t3);}
C_trace("body120130");
t4=((C_word*)t0)[2];
f_1461(t4,t1,t2,t3,C_fix(0));}

/* body120 in move-memory! in k1343 */
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1461,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1470,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1521,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t2,a[8]=t6,a[9]=t10,a[10]=((C_word*)t0)[2],a[11]=((C_word)li4),tmp=(C_word)a,a+=12,tmp));
t12=((C_word*)t10)[1];
f_1521(t12,t1,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* move in body120 in move-memory! in k1343 */
static void C_fcall f_1521(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1521,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
C_trace("lolevel.scm: 91   move");
t11=t1;
t12=t5;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
C_trace("lolevel.scm: 92   xerr");
f_1470(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
C_trace("lolevel.scm: 95   move");
t11=t1;
t12=t2;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
C_trace("lolevel.scm: 96   xerr");
f_1470(t1,t3);}}
else{
t4=(C_word)C_pointerp(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_1583(2,t6,t4);}
else{
C_trace("lolevel.scm: 97   ##sys#locative?");
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}}

/* k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_pointerp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_1592(2,t4,t2);}
else{
C_trace("lolevel.scm: 98   ##sys#locative?");
t4=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
C_trace("lolevel.scm: 103  ##sys#bytevector?");
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k1642 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=(C_word)C_pointerp(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_1659(2,t6,t4);}
else{
C_trace("lolevel.scm: 105  ##sys#locative?");
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[9]);}}
else{
C_trace("lolevel.scm: 111  xerr");
f_1470(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k1657 in k1642 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1659,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:((C_word*)t0)[5]);
C_trace("lolevel.scm: 106  checkn");
t5=((C_word*)t0)[4];
f_1476(t5,t2,t4,((C_word*)t0)[5],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("lolevel.scm: 107  ##sys#bytevector?");
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}}

/* k1674 in k1657 in k1642 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
C_trace("lolevel.scm: 108  checkn2");
t7=((C_word*)t0)[3];
f_1492(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
C_trace("lolevel.scm: 110  xerr");
f_1470(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1684 in k1674 in k1657 in k1642 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub87(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1664 in k1657 in k1642 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub49(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1590 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_1599(2,t4,t2);}
else{
C_trace("lolevel.scm: 99   err");
t4=((C_word*)t0)[4];
f_1464(t4,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
C_trace("lolevel.scm: 100  ##sys#bytevector?");
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k1606 in k1590 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1622(2,t6,t4);}
else{
C_trace("lolevel.scm: 101  err");
t6=((C_word*)t0)[3];
f_1464(t6,t5);}}
else{
C_trace("lolevel.scm: 102  xerr");
f_1470(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1620 in k1606 in k1590 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
C_trace("lolevel.scm: 101  checkn");
t3=((C_word*)t0)[4];
f_1476(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1616 in k1606 in k1590 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub68(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1597 in k1590 in k1581 in move in body120 in move-memory! in k1343 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub30(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body120 in move-memory! in k1343 */
static void C_fcall f_1492(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1492,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1499,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_fixnum_difference(t4,t6);
t10=t7;
f_1499(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1499(t9,C_SCHEME_FALSE);}}

/* k1497 in checkn2 in body120 in move-memory! in k1343 */
static void C_fcall f_1499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
C_trace("lolevel.scm: 87   ##sys#error");
t2=*((C_word*)lf[4]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[7],lf[3],lf[10],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* checkn in body120 in move-memory! in k1343 */
static void C_fcall f_1476(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1476,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
C_trace("lolevel.scm: 83   ##sys#error");
t6=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t6+1)))(8,t6,t1,lf[3],lf[9],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}}

/* xerr in body120 in move-memory! in k1343 */
static void C_fcall f_1470(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1470,NULL,2,t1,t2);}
C_trace("lolevel.scm: 79   ##sys#signal-hook");
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[3],lf[8],t2);}

/* err in body120 in move-memory! in k1343 */
static void C_fcall f_1464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1464,NULL,2,t0,t1);}
C_trace("lolevel.scm: 78   ##sys#error");
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[3],lf[5],((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[194] = {
{"toplevellolevel.scm",(void*)C_lolevel_toplevel},
{"f_1345lolevel.scm",(void*)f_1345},
{"f_3374lolevel.scm",(void*)f_3374},
{"f_2064lolevel.scm",(void*)f_2064},
{"f_3364lolevel.scm",(void*)f_3364},
{"f_2068lolevel.scm",(void*)f_2068},
{"f_3354lolevel.scm",(void*)f_3354},
{"f_2072lolevel.scm",(void*)f_2072},
{"f_3344lolevel.scm",(void*)f_3344},
{"f_2076lolevel.scm",(void*)f_2076},
{"f_3334lolevel.scm",(void*)f_3334},
{"f_2080lolevel.scm",(void*)f_2080},
{"f_3324lolevel.scm",(void*)f_3324},
{"f_2084lolevel.scm",(void*)f_2084},
{"f_3314lolevel.scm",(void*)f_3314},
{"f_2088lolevel.scm",(void*)f_2088},
{"f_3304lolevel.scm",(void*)f_3304},
{"f_2092lolevel.scm",(void*)f_2092},
{"f_2268lolevel.scm",(void*)f_2268},
{"f_3218lolevel.scm",(void*)f_3218},
{"f_3290lolevel.scm",(void*)f_3290},
{"f_3281lolevel.scm",(void*)f_3281},
{"f_3272lolevel.scm",(void*)f_3272},
{"f_3266lolevel.scm",(void*)f_3266},
{"f_3249lolevel.scm",(void*)f_3249},
{"f_3254lolevel.scm",(void*)f_3254},
{"f_3230lolevel.scm",(void*)f_3230},
{"f_3234lolevel.scm",(void*)f_3234},
{"f_3237lolevel.scm",(void*)f_3237},
{"f_3223lolevel.scm",(void*)f_3223},
{"f_3220lolevel.scm",(void*)f_3220},
{"f_3213lolevel.scm",(void*)f_3213},
{"f_3184lolevel.scm",(void*)f_3184},
{"f_3192lolevel.scm",(void*)f_3192},
{"f_3155lolevel.scm",(void*)f_3155},
{"f_3163lolevel.scm",(void*)f_3163},
{"f_3121lolevel.scm",(void*)f_3121},
{"f_3125lolevel.scm",(void*)f_3125},
{"f_3132lolevel.scm",(void*)f_3132},
{"f_3147lolevel.scm",(void*)f_3147},
{"f_3135lolevel.scm",(void*)f_3135},
{"f_3058lolevel.scm",(void*)f_3058},
{"f_3070lolevel.scm",(void*)f_3070},
{"f_3092lolevel.scm",(void*)f_3092},
{"f_3095lolevel.scm",(void*)f_3095},
{"f_3065lolevel.scm",(void*)f_3065},
{"f_2923lolevel.scm",(void*)f_2923},
{"f_2927lolevel.scm",(void*)f_2927},
{"f_2936lolevel.scm",(void*)f_2936},
{"f_2941lolevel.scm",(void*)f_2941},
{"f_2957lolevel.scm",(void*)f_2957},
{"f_3000lolevel.scm",(void*)f_3000},
{"f_3003lolevel.scm",(void*)f_3003},
{"f_3012lolevel.scm",(void*)f_3012},
{"f_3033lolevel.scm",(void*)f_3033},
{"f_3006lolevel.scm",(void*)f_3006},
{"f_2986lolevel.scm",(void*)f_2986},
{"f_2989lolevel.scm",(void*)f_2989},
{"f_2970lolevel.scm",(void*)f_2970},
{"f_2973lolevel.scm",(void*)f_2973},
{"f_2839lolevel.scm",(void*)f_2839},
{"f_2843lolevel.scm",(void*)f_2843},
{"f_2848lolevel.scm",(void*)f_2848},
{"f_2861lolevel.scm",(void*)f_2861},
{"f_2918lolevel.scm",(void*)f_2918},
{"f_2870lolevel.scm",(void*)f_2870},
{"f_2882lolevel.scm",(void*)f_2882},
{"f_2904lolevel.scm",(void*)f_2904},
{"f_2873lolevel.scm",(void*)f_2873},
{"f_2669lolevel.scm",(void*)f_2669},
{"f_2673lolevel.scm",(void*)f_2673},
{"f_2676lolevel.scm",(void*)f_2676},
{"f_2818lolevel.scm",(void*)f_2818},
{"f_2679lolevel.scm",(void*)f_2679},
{"f_2682lolevel.scm",(void*)f_2682},
{"f_2690lolevel.scm",(void*)f_2690},
{"f_2700lolevel.scm",(void*)f_2700},
{"f_2811lolevel.scm",(void*)f_2811},
{"f_2799lolevel.scm",(void*)f_2799},
{"f_2803lolevel.scm",(void*)f_2803},
{"f_2795lolevel.scm",(void*)f_2795},
{"f_2712lolevel.scm",(void*)f_2712},
{"f_2772lolevel.scm",(void*)f_2772},
{"f_2718lolevel.scm",(void*)f_2718},
{"f_2721lolevel.scm",(void*)f_2721},
{"f_2733lolevel.scm",(void*)f_2733},
{"f_2754lolevel.scm",(void*)f_2754},
{"f_2724lolevel.scm",(void*)f_2724},
{"f_2685lolevel.scm",(void*)f_2685},
{"f_2577lolevel.scm",(void*)f_2577},
{"f_2586lolevel.scm",(void*)f_2586},
{"f_2631lolevel.scm",(void*)f_2631},
{"f_2641lolevel.scm",(void*)f_2641},
{"f_2615lolevel.scm",(void*)f_2615},
{"f_2622lolevel.scm",(void*)f_2622},
{"f_2659lolevel.scm",(void*)f_2659},
{"f_2466lolevel.scm",(void*)f_2466},
{"f_2473lolevel.scm",(void*)f_2473},
{"f_2478lolevel.scm",(void*)f_2478},
{"f_2488lolevel.scm",(void*)f_2488},
{"f_2497lolevel.scm",(void*)f_2497},
{"f_2501lolevel.scm",(void*)f_2501},
{"f_2507lolevel.scm",(void*)f_2507},
{"f_2519lolevel.scm",(void*)f_2519},
{"f_2540lolevel.scm",(void*)f_2540},
{"f_2510lolevel.scm",(void*)f_2510},
{"f_2570lolevel.scm",(void*)f_2570},
{"f_2463lolevel.scm",(void*)f_2463},
{"f_2382lolevel.scm",(void*)f_2382},
{"f_2388lolevel.scm",(void*)f_2388},
{"f_2418lolevel.scm",(void*)f_2418},
{"f_2433lolevel.scm",(void*)f_2433},
{"f_2454lolevel.scm",(void*)f_2454},
{"f_2421lolevel.scm",(void*)f_2421},
{"f_2328lolevel.scm",(void*)f_2328},
{"f_2341lolevel.scm",(void*)f_2341},
{"f_2346lolevel.scm",(void*)f_2346},
{"f_2322lolevel.scm",(void*)f_2322},
{"f_2313lolevel.scm",(void*)f_2313},
{"f_2291lolevel.scm",(void*)f_2291},
{"f_2270lolevel.scm",(void*)f_2270},
{"f_2283lolevel.scm",(void*)f_2283},
{"f_2274lolevel.scm",(void*)f_2274},
{"f_2250lolevel.scm",(void*)f_2250},
{"f_2254lolevel.scm",(void*)f_2254},
{"f_2216lolevel.scm",(void*)f_2216},
{"f_2234lolevel.scm",(void*)f_2234},
{"f_2226lolevel.scm",(void*)f_2226},
{"f_2185lolevel.scm",(void*)f_2185},
{"f_2200lolevel.scm",(void*)f_2200},
{"f_2198lolevel.scm",(void*)f_2198},
{"f_2147lolevel.scm",(void*)f_2147},
{"f_2151lolevel.scm",(void*)f_2151},
{"f_2172lolevel.scm",(void*)f_2172},
{"f_2156lolevel.scm",(void*)f_2156},
{"f_2125lolevel.scm",(void*)f_2125},
{"f_2109lolevel.scm",(void*)f_2109},
{"f_2094lolevel.scm",(void*)f_2094},
{"f_2098lolevel.scm",(void*)f_2098},
{"f_2101lolevel.scm",(void*)f_2101},
{"f_2048lolevel.scm",(void*)f_2048},
{"f_2034lolevel.scm",(void*)f_2034},
{"f_2020lolevel.scm",(void*)f_2020},
{"f_2006lolevel.scm",(void*)f_2006},
{"f_1992lolevel.scm",(void*)f_1992},
{"f_1978lolevel.scm",(void*)f_1978},
{"f_1964lolevel.scm",(void*)f_1964},
{"f_1950lolevel.scm",(void*)f_1950},
{"f_1936lolevel.scm",(void*)f_1936},
{"f_1904lolevel.scm",(void*)f_1904},
{"f_1931lolevel.scm",(void*)f_1931},
{"f_1898lolevel.scm",(void*)f_1898},
{"f_1888lolevel.scm",(void*)f_1888},
{"f_1881lolevel.scm",(void*)f_1881},
{"f_1872lolevel.scm",(void*)f_1872},
{"f_1876lolevel.scm",(void*)f_1876},
{"f_1879lolevel.scm",(void*)f_1879},
{"f_1866lolevel.scm",(void*)f_1866},
{"f_1870lolevel.scm",(void*)f_1870},
{"f_1855lolevel.scm",(void*)f_1855},
{"f_1863lolevel.scm",(void*)f_1863},
{"f_1842lolevel.scm",(void*)f_1842},
{"f_1846lolevel.scm",(void*)f_1846},
{"f_1853lolevel.scm",(void*)f_1853},
{"f_1833lolevel.scm",(void*)f_1833},
{"f_1837lolevel.scm",(void*)f_1837},
{"f_1814lolevel.scm",(void*)f_1814},
{"f_1818lolevel.scm",(void*)f_1818},
{"f_1805lolevel.scm",(void*)f_1805},
{"f_1786lolevel.scm",(void*)f_1786},
{"f_1793lolevel.scm",(void*)f_1793},
{"f_1459lolevel.scm",(void*)f_1459},
{"f_1723lolevel.scm",(void*)f_1723},
{"f_1718lolevel.scm",(void*)f_1718},
{"f_1713lolevel.scm",(void*)f_1713},
{"f_1461lolevel.scm",(void*)f_1461},
{"f_1521lolevel.scm",(void*)f_1521},
{"f_1583lolevel.scm",(void*)f_1583},
{"f_1644lolevel.scm",(void*)f_1644},
{"f_1659lolevel.scm",(void*)f_1659},
{"f_1676lolevel.scm",(void*)f_1676},
{"f_1686lolevel.scm",(void*)f_1686},
{"f_1666lolevel.scm",(void*)f_1666},
{"f_1592lolevel.scm",(void*)f_1592},
{"f_1608lolevel.scm",(void*)f_1608},
{"f_1622lolevel.scm",(void*)f_1622},
{"f_1618lolevel.scm",(void*)f_1618},
{"f_1599lolevel.scm",(void*)f_1599},
{"f_1492lolevel.scm",(void*)f_1492},
{"f_1499lolevel.scm",(void*)f_1499},
{"f_1476lolevel.scm",(void*)f_1476},
{"f_1470lolevel.scm",(void*)f_1470},
{"f_1464lolevel.scm",(void*)f_1464},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
