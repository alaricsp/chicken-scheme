/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-03 03:24
   Version 4.0.0x - linux-unix-gnu-x86	[ ptables applyhook ]
   SVN rev. 12299	compiled 2008-10-29 on dill (Linux)
   command line: lolevel.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -explicit-use -debug i -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_pointer_to_object(ptr)   ((C_word*)C_block_item(ptr, 0))
#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[132];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,5),40,101,114,114,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,11),40,120,101,114,114,32,120,49,52,48,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,28),40,99,104,101,99,107,110,32,110,49,52,50,32,110,109,97,120,49,52,51,32,111,102,102,49,52,52,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,47),40,99,104,101,99,107,110,50,32,110,49,53,49,32,110,109,97,120,49,53,50,32,110,109,97,120,50,49,53,51,32,111,102,102,49,49,53,52,32,111,102,102,50,49,53,53,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,49,54,54,32,116,111,49,54,55,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,49,50,48,32,110,49,51,49,32,102,111,102,102,115,101,116,49,51,50,32,116,111,102,102,115,101,116,49,51,51,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,102,102,115,101,116,49,50,52,32,37,110,49,49,55,50,54,48,32,37,102,111,102,102,115,101,116,49,49,56,50,54,49,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,111,102,102,115,101,116,49,50,51,32,37,110,49,49,55,50,54,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,49,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,40),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,49,48,56,32,116,111,49,48,57,32,46,32,116,109,112,49,48,55,49,49,48,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,112,116,114,50,56,52,32,108,111,99,50,56,53,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,51,48,54,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,51,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,51,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,51,51,53,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,102,95,49,56,51,51,32,97,51,52,52,51,52,55,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,51,52,48,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,51,53,51,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,51,53,56,32,112,50,51,53,57,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,51,54,52,51,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,51,55,50,51,55,54,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,108,105,103,110,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,51,57,48,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,32),40,112,111,105,110,116,101,114,45,111,102,102,115,101,116,32,97,52,48,51,52,48,55,32,97,52,48,50,52,48,56,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,97,52,49,54,52,50,48,32,97,52,49,53,52,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,33),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,97,52,50,55,52,51,49,32,97,52,50,54,52,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,97,52,51,56,52,52,50,32,97,52,51,55,52,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,97,52,52,57,52,53,51,32,97,52,52,56,52,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,97,52,54,48,52,54,52,32,97,52,53,57,52,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,97,52,55,49,52,55,53,32,97,52,55,48,52,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,97,52,56,50,52,56,54,32,97,52,56,49,52,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,34),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,97,52,57,51,52,57,55,32,97,52,57,50,52,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,53,56,52,32,116,97,103,53,56,53,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,29),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,53,57,52,32,116,97,103,53,57,53,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,54,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,50,49,50,53,32,120,54,50,50,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,17),40,97,50,49,52,49,32,120,54,50,54,32,105,54,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,54,49,50,32,100,97,116,97,54,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,12),40,97,50,49,54,57,32,120,54,52,49,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,54,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,12),40,97,50,50,48,51,32,120,54,53,55,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,54,52,55,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,54,54,53,32,120,54,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,54,55,51,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,54,57,50,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,55,48,51,32,46,32,97,114,103,115,55,48,52,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,23),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,55,48,57,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,55,50,52,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,55,49,53,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,54,56,32,105,55,55,52,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,55,52,51,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,55,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,55,56,54,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,16),40,102,95,50,53,52,48,32,97,55,57,52,55,57,55,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,51,49,32,105,56,51,55,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,56,48,52,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,55,56,57,32,46,32,97,108,108,111,99,97,116,111,114,55,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,16),40,102,95,50,54,50,57,32,97,56,54,48,56,54,52,41};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,56,56,52,32,105,56,57,48,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,56,55,49,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,56,53,53,32,46,32,114,101,108,101,97,115,101,114,56,53,54,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,57,53,57,32,105,57,54,53,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,57,50,55,41,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,57,48,49,32,112,116,114,57,48,50,32,46,32,108,105,109,105,116,57,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,49,49,32,105,49,48,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,57,57,52,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,115,105,122,101,32,120,57,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,56,55,32,105,49,48,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,12),40,99,111,112,121,32,120,49,48,54,48,41,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,49,48,52,48,32,46,32,116,109,112,49,48,51,57,49,48,52,49,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,108,115,116,49,49,49,52,41,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,24),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,108,115,116,49,49,49,48,41};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,35),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,49,49,52,52,32,112,114,111,99,49,49,52,53,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,49,49,54,49,32,46,32,105,110,100,101,120,49,49,54,50,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,49,49,55,52,32,46,32,105,110,100,101,120,49,49,55,53,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,27),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,49,49,56,55,32,121,49,49,56,56,41,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,24),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,49,49,57,51,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,17),40,108,111,99,97,116,105,118,101,63,32,120,49,49,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,46),40,35,35,115,121,115,35,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,111,111,107,32,46,32,97,114,103,115,49,50,48,56,41,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,46),40,115,101,116,45,105,110,118,97,108,105,100,45,112,114,111,99,101,100,117,114,101,45,99,97,108,108,45,104,97,110,100,108,101,114,33,32,112,114,111,99,49,50,48,52,41,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,34),40,117,110,98,111,117,110,100,45,118,97,114,105,97,98,108,101,45,118,97,108,117,101,32,46,32,118,97,108,49,50,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,20),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,49,50,50,48,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,27),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,49,50,50,53,32,120,49,50,50,54,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,23),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,49,50,51,49,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,30),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,49,50,51,54,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,15),40,97,51,50,55,51,32,97,53,55,50,53,55,54,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,15),40,97,51,50,56,51,32,97,53,54,49,53,54,53,41,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,15),40,97,51,50,57,51,32,97,53,53,48,53,53,52,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,15),40,97,51,51,48,51,32,97,53,51,57,53,52,51,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,97,51,51,49,51,32,97,53,51,48,53,51,52,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,15),40,97,51,51,50,51,32,97,53,50,49,53,50,53,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,15),40,97,51,51,51,51,32,97,53,49,50,53,49,54,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,15),40,97,51,51,52,51,32,97,53,48,51,53,48,55,41,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2632 */
static C_word C_fcall stub861(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub861(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2543 */
static C_word C_fcall stub795(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub795(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k3277 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub573(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub573(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_ret:
#undef return

return C_r;}

/* from k3287 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub562(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub562(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_ret:
#undef return

return C_r;}

/* from k3297 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub551(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub551(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3307 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_ret; C_cblockend
static C_word C_fcall stub540(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub540(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_ret:
#undef return

return C_r;}

/* from k3317 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub531(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub531(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_ret:
#undef return

return C_r;}

/* from k3327 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub522(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub522(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_ret:
#undef return

return C_r;}

/* from k3337 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub513(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub513(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_ret:
#undef return

return C_r;}

/* from k3347 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub504(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub504(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_ret:
#undef return

return C_r;}

/* from k2025 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub494(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub494(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k2011 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub483(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub483(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1997 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub472(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub472(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1983 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub461(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub461(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1969 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub450(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub450(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1955 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub439(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub439(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1941 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub428(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub428(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1927 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub417(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub417(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_ret:
#undef return

return C_r;}

/* from k1913 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub404(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub404(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

/* from k1871 */
static C_word C_fcall stub383(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub383(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1861 */
static C_word C_fcall stub373(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub373(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1854 */
static C_word C_fcall stub365(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub365(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from f_1833 in object->pointer in k1313 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub345(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub345(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1420 */
static C_word C_fcall stub87(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub87(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1392 */
static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1364 */
static C_word C_fcall stub49(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub49(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1336 */
static C_word C_fcall stub30(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub30(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3274)
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3224)
static void C_fcall f_3224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3040)
static void C_fcall f_3040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2906)
static void C_ccall f_2906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_fcall f_2911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_fcall f_2982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_fcall f_2818(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_fcall f_2852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_fcall f_2646(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_ccall f_2652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_fcall f_2660(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2781)
static void C_ccall f_2781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2703)
static void C_fcall f_2703(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2556)
static void C_fcall f_2556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2601)
static void C_fcall f_2601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_fcall f_2448(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_fcall f_2489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2358)
static void C_fcall f_2358(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_fcall f_2403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static C_word C_fcall f_2316(C_word t0,C_word t1);
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2283)
static void C_ccall f_2283r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2253)
static void C_fcall f_2253(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1920)
static void C_ccall f_1920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static C_word C_fcall f_1868(C_word *a,C_word t0);
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1763)
static void C_fcall f_1763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1429)
static void C_ccall f_1429r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1693)
static void C_fcall f_1693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_fcall f_1688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1683)
static void C_fcall f_1683(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1431)
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1491)
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_fcall f_1462(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1469)
static void C_fcall f_1469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_fcall f_1446(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1440)
static void C_fcall f_1440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_fcall f_1434(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3224)
static void C_fcall trf_3224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3224(t0,t1);}

C_noret_decl(trf_3040)
static void C_fcall trf_3040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3040(t0,t1,t2);}

C_noret_decl(trf_2911)
static void C_fcall trf_2911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2911(t0,t1,t2);}

C_noret_decl(trf_2982)
static void C_fcall trf_2982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2982(t0,t1,t2);}

C_noret_decl(trf_2818)
static void C_fcall trf_2818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2818(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2818(t0,t1,t2);}

C_noret_decl(trf_2852)
static void C_fcall trf_2852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2852(t0,t1,t2);}

C_noret_decl(trf_2646)
static void C_fcall trf_2646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2646(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2646(t0,t1);}

C_noret_decl(trf_2660)
static void C_fcall trf_2660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2660(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2660(t0,t1,t2);}

C_noret_decl(trf_2703)
static void C_fcall trf_2703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2703(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2703(t0,t1,t2);}

C_noret_decl(trf_2556)
static void C_fcall trf_2556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2556(t0,t1,t2);}

C_noret_decl(trf_2601)
static void C_fcall trf_2601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2601(t0,t1,t2);}

C_noret_decl(trf_2448)
static void C_fcall trf_2448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2448(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2448(t0,t1,t2);}

C_noret_decl(trf_2489)
static void C_fcall trf_2489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2489(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2489(t0,t1,t2);}

C_noret_decl(trf_2358)
static void C_fcall trf_2358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2358(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2358(t0,t1,t2);}

C_noret_decl(trf_2403)
static void C_fcall trf_2403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2403(t0,t1,t2);}

C_noret_decl(trf_2253)
static void C_fcall trf_2253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2253(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2253(t0,t1);}

C_noret_decl(trf_1763)
static void C_fcall trf_1763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1763(t0,t1);}

C_noret_decl(trf_1693)
static void C_fcall trf_1693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1693(t0,t1);}

C_noret_decl(trf_1688)
static void C_fcall trf_1688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1688(t0,t1,t2);}

C_noret_decl(trf_1683)
static void C_fcall trf_1683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1683(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1683(t0,t1,t2,t3);}

C_noret_decl(trf_1431)
static void C_fcall trf_1431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1431(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1431(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1491)
static void C_fcall trf_1491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1491(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1491(t0,t1,t2,t3);}

C_noret_decl(trf_1462)
static void C_fcall trf_1462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1462(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1462(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1469)
static void C_fcall trf_1469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1469(t0,t1);}

C_noret_decl(trf_1446)
static void C_fcall trf_1446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1446(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1446(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1440)
static void C_fcall trf_1440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1440(t0,t1);}

C_noret_decl(trf_1434)
static void C_fcall trf_1434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1434(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1177)){
C_save(t1);
C_rereclaim2(1177*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,132);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[3]=C_h_intern(&lf[3],12,"move-memory!");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],11,"\000type-error");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid argument type");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[11]=C_h_intern(&lf[11],15,"\003sysbytevector\077");
lf[12]=C_h_intern(&lf[12],13,"\003syslocative\077");
lf[13]=C_h_intern(&lf[13],17,"\003syscheck-pointer");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[15]=C_h_intern(&lf[15],12,"null-pointer");
lf[16]=C_h_intern(&lf[16],16,"\003sysnull-pointer");
lf[17]=C_h_intern(&lf[17],8,"pointer\077");
lf[18]=C_h_intern(&lf[18],16,"address->pointer");
lf[19]=C_h_intern(&lf[19],20,"\003sysaddress->pointer");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\042bad argument type - not an integer");
lf[21]=C_h_intern(&lf[21],16,"pointer->address");
lf[22]=C_h_intern(&lf[22],20,"\003syspointer->address");
lf[23]=C_h_intern(&lf[23],17,"\003syscheck-special");
lf[24]=C_h_intern(&lf[24],13,"null-pointer\077");
lf[25]=C_h_intern(&lf[25],15,"object->pointer");
lf[26]=C_h_intern(&lf[26],15,"pointer->object");
lf[27]=C_h_intern(&lf[27],9,"pointer=\077");
lf[28]=C_h_intern(&lf[28],8,"allocate");
lf[29]=C_h_intern(&lf[29],4,"free");
lf[30]=C_h_intern(&lf[30],13,"align-to-word");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000+bad argument type - not a pointer or fixnum");
lf[32]=C_h_intern(&lf[32],14,"pointer-offset");
lf[33]=C_h_intern(&lf[33],15,"pointer-u8-set!");
lf[34]=C_h_intern(&lf[34],15,"pointer-s8-set!");
lf[35]=C_h_intern(&lf[35],16,"pointer-u16-set!");
lf[36]=C_h_intern(&lf[36],16,"pointer-s16-set!");
lf[37]=C_h_intern(&lf[37],16,"pointer-u32-set!");
lf[38]=C_h_intern(&lf[38],16,"pointer-s32-set!");
lf[39]=C_h_intern(&lf[39],16,"pointer-f32-set!");
lf[40]=C_h_intern(&lf[40],16,"pointer-f64-set!");
lf[41]=C_h_intern(&lf[41],14,"pointer-u8-ref");
lf[42]=C_h_intern(&lf[42],14,"pointer-s8-ref");
lf[43]=C_h_intern(&lf[43],15,"pointer-u16-ref");
lf[44]=C_h_intern(&lf[44],15,"pointer-s16-ref");
lf[45]=C_h_intern(&lf[45],15,"pointer-u32-ref");
lf[46]=C_h_intern(&lf[46],15,"pointer-s32-ref");
lf[47]=C_h_intern(&lf[47],15,"pointer-f32-ref");
lf[48]=C_h_intern(&lf[48],15,"pointer-f64-ref");
lf[49]=C_h_intern(&lf[49],11,"tag-pointer");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[51]=C_h_intern(&lf[51],23,"\003sysmake-tagged-pointer");
lf[52]=C_h_intern(&lf[52],15,"tagged-pointer\077");
lf[53]=C_h_intern(&lf[53],11,"pointer-tag");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[55]=C_h_intern(&lf[55],8,"extended");
lf[57]=C_h_intern(&lf[57],16,"extend-procedure");
lf[58]=C_h_intern(&lf[58],19,"\003sysdecorate-lambda");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[60]=C_h_intern(&lf[60],19,"extended-procedure\077");
lf[61]=C_h_intern(&lf[61],21,"\003syslambda-decoration");
lf[62]=C_h_intern(&lf[62],14,"procedure-data");
lf[63]=C_h_intern(&lf[63],19,"set-procedure-data!");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[65]=C_h_intern(&lf[65],10,"block-set!");
lf[66]=C_h_intern(&lf[66],14,"\003sysblock-set!");
lf[67]=C_h_intern(&lf[67],9,"block-ref");
lf[68]=C_h_intern(&lf[68],15,"number-of-slots");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\024slots not accessible");
lf[70]=C_h_intern(&lf[70],15,"number-of-bytes");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\0003can not compute number of bytes of immediate object");
lf[72]=C_h_intern(&lf[72],20,"make-record-instance");
lf[73]=C_h_intern(&lf[73],18,"\003sysmake-structure");
lf[74]=C_h_intern(&lf[74],16,"record-instance\077");
lf[75]=C_h_intern(&lf[75],14,"record->vector");
lf[76]=C_h_intern(&lf[76],15,"\003sysmake-vector");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a record structure");
lf[78]=C_h_intern(&lf[78],11,"object-copy");
lf[79]=C_h_intern(&lf[79],15,"object-evicted\077");
lf[80]=C_h_intern(&lf[80],12,"object-evict");
lf[81]=C_h_intern(&lf[81],19,"\003syshash-table-set!");
lf[82]=C_h_intern(&lf[82],18,"\003syshash-table-ref");
lf[83]=C_h_intern(&lf[83],14,"object-release");
lf[84]=C_h_intern(&lf[84],24,"object-evict-to-location");
lf[85]=C_h_intern(&lf[85],24,"\003sysset-pointer-address!");
lf[86]=C_h_intern(&lf[86],6,"signal");
lf[87]=C_h_intern(&lf[87],24,"make-composite-condition");
lf[88]=C_h_intern(&lf[88],23,"make-property-condition");
lf[89]=C_h_intern(&lf[89],5,"evict");
lf[90]=C_h_intern(&lf[90],5,"limit");
lf[91]=C_h_intern(&lf[91],3,"exn");
lf[92]=C_h_intern(&lf[92],8,"location");
lf[93]=C_h_intern(&lf[93],7,"message");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000%can not evict object - limit exceeded");
lf[95]=C_h_intern(&lf[95],9,"arguments");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[97]=C_h_intern(&lf[97],11,"object-size");
lf[98]=C_h_intern(&lf[98],14,"object-unevict");
lf[99]=C_h_intern(&lf[99],15,"\003sysmake-string");
lf[100]=C_h_intern(&lf[100],14,"object-become!");
lf[101]=C_h_intern(&lf[101],11,"\003sysbecome!");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - new item is immediate");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - old item is immediate");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not an a-list");
lf[105]=C_h_intern(&lf[105],16,"mutate-procedure");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[107]=C_h_intern(&lf[107],13,"make-locative");
lf[108]=C_h_intern(&lf[108],17,"\003sysmake-locative");
lf[109]=C_h_intern(&lf[109],18,"make-weak-locative");
lf[110]=C_h_intern(&lf[110],13,"locative-set!");
lf[111]=C_h_intern(&lf[111],12,"locative-ref");
lf[112]=C_h_intern(&lf[112],16,"locative->object");
lf[113]=C_h_intern(&lf[113],9,"locative\077");
lf[115]=C_h_intern(&lf[115],35,"set-invalid-procedure-call-handler!");
lf[116]=C_h_intern(&lf[116],31,"\003sysinvalid-procedure-call-hook");
lf[117]=C_h_intern(&lf[117],26,"\003syslast-invalid-procedure");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a procedure");
lf[119]=C_h_intern(&lf[119],22,"unbound-variable-value");
lf[120]=C_h_intern(&lf[120],31,"\003sysunbound-variable-value-hook");
lf[121]=C_h_intern(&lf[121],10,"global-ref");
lf[122]=C_h_intern(&lf[122],11,"global-set!");
lf[123]=C_h_intern(&lf[123],13,"global-bound\077");
lf[124]=C_h_intern(&lf[124],32,"\003syssymbol-has-toplevel-binding\077");
lf[125]=C_h_intern(&lf[125],20,"global-make-unbound!");
lf[126]=C_h_intern(&lf[126],28,"\003sysarbitrary-unbound-symbol");
lf[127]=C_h_intern(&lf[127],18,"getter-with-setter");
lf[128]=C_h_intern(&lf[128],13,"\003sysblock-ref");
lf[129]=C_h_intern(&lf[129],15,"pointer-s6-set!");
lf[130]=C_h_intern(&lf[130],17,"register-feature!");
lf[131]=C_h_intern(&lf[131],7,"lolevel");
C_register_lf2(lf,132,create_ptable());
t2=C_mutate(&lf[0] /* (set! c281 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 66   register-feature! */
t4=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[131]);}

/* k1313 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[74],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=lf[2];
t3=C_mutate((C_word*)lf[3]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1429,a[2]=t2,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[13]+1 /* (set! check-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[15]+1 /* (set! null-pointer ...) */,*((C_word*)lf[16]+1));
t6=C_mutate((C_word*)lf[17]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1775,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[18]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[21]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1803,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[24]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[25]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1825,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[26]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1836,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1842,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[28]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1851,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[29]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1868,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
t16=C_mutate((C_word*)lf[30]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1874,a[2]=t15,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[32]+1 /* (set! pointer-offset ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1906,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[33]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1920,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[34]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1934,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[35]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[36]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1962,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[37]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1976,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[38]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1990,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[39]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2004,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[40]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2018,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3344,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 186  getter-with-setter */
t28=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t28))(4,t28,t26,t27,*((C_word*)lf[33]+1));}

/* a3343 in k1313 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3344,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub504(C_SCHEME_UNDEFINED,t3));}

/* k2032 in k1313 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 191  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[34]+1));}

/* a3333 in k2032 in k1313 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3334,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub513(C_SCHEME_UNDEFINED,t3));}

/* k2036 in k2032 in k1313 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3324,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 196  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[35]+1));}

/* a3323 in k2036 in k2032 in k1313 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3324,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub522(C_SCHEME_UNDEFINED,t3));}

/* k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 201  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[129]+1));}

/* a3313 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3314,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub531(C_SCHEME_UNDEFINED,t3));}

/* k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 206  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[37]+1));}

/* a3303 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3304,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub540(t3,t4));}

/* k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3294,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 211  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[38]+1));}

/* a3293 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3294,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub551(t3,t4));}

/* k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 216  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[39]+1));}

/* a3283 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3284,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub562(t3,t4));}

/* k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2058,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3274,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 221  getter-with-setter */
t5=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,*((C_word*)lf[40]+1));}

/* a3273 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3274,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub573(t3,t4));}

/* k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=C_mutate((C_word*)lf[49]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2064,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[52]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2079,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[53]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t6=(C_word)C_a_i_vector(&a,1,lf[55]);
t7=C_mutate(&lf[56] /* (set! xproc-tag ...) */,t6);
t8=C_mutate((C_word*)lf[57]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2117,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[60]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2155,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[62]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[63]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2220,a[2]=t11,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t13=C_mutate((C_word*)lf[65]+1 /* (set! block-set! ...) */,*((C_word*)lf[66]+1));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 283  getter-with-setter */
t15=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t15))(4,t15,t14,*((C_word*)lf[128]+1),*((C_word*)lf[66]+1));}

/* k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[57],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[68]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2240,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[70]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[72]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2283,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[74]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2292,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[75]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[78]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2352,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[79]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2433,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[80]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2436,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[83]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2547,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[84]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[97]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[98]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[100]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[105]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[107]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3125,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[109]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[110]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3183,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3188,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 523  getter-with-setter */
t22=*((C_word*)lf[127]+1);
((C_proc4)C_retrieve_proc(t22))(4,t22,t20,t21,*((C_word*)lf[110]+1));}

/* k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3188,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[112]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3190,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[113]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3193,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t5=lf[114] /* ipc-hook-0 */ =C_SCHEME_FALSE;;
t6=C_mutate((C_word*)lf[115]+1 /* (set! set-invalid-procedure-call-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3200,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[119]+1 /* (set! unbound-variable-value ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3219,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[121]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3236,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[122]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3242,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[123]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[125]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3260,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[125]);
t4=(C_word)C_slot(lf[126],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3251,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[123]);
/* lolevel.scm: 558  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* global-set! in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3242,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[122]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3236,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[121]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3219r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3219r(t0,t1,t2);}}

static void C_ccall f_3219r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3224,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_3224(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_3224(t4,C_SCHEME_FALSE);}}

/* k3222 in unbound-variable-value in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_3224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[120]+1 /* (set! unbound-variable-value-hook ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* set-invalid-procedure-call-handler! in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3200,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3204,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t4=t3;
f_3204(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 534  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[115],lf[118],t2);}}

/* k3202 in set-invalid-procedure-call-handler! in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=C_mutate(&lf[114] /* (set! ipc-hook-0 ...) */,((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[116]+1 /* (set! invalid-procedure-call-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3207,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k3202 in set-invalid-procedure-call-handler! in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3207r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3207r(t0,t1,t2);}}

static void C_ccall f_3207r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 538  ipc-hook-0 */
t3=lf[114];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,*((C_word*)lf[117]+1),t2);}

/* locative? in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3193,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k3186 in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3190,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3183,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3154r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3154r(t0,t1,t2,t3);}}

static void C_ccall f_3154r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3162,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3162(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3162(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3160 in make-weak-locative in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 520  ##sys#make-locative */
t2=*((C_word*)lf[108]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[109]);}

/* make-locative in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3125r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3125r(t0,t1,t2,t3);}}

static void C_ccall f_3125r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3133,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3133(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3133(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3131 in make-locative in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 517  ##sys#make-locative */
t2=*((C_word*)lf[108]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[107]);}

/* mutate-procedure in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3091,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3095,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t5=t4;
f_3095(2,t5,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 506  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[105],lf[106],t2);}}

/* k3093 in mutate-procedure in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3095,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 509  ##sys#make-vector */
t5=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k3100 in k3093 in mutate-procedure in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3117,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 510  proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k3115 in k3100 in k3093 in mutate-procedure in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
/* lolevel.scm: 510  ##sys#become! */
t4=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k3103 in k3100 in k3093 in mutate-procedure in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3028,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[100]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3035,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3040,a[2]=t6,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3040(t8,t4,t2);}

/* loop in object-become! in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_3040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3040,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_pair_2(t4,lf[100]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3062,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
if(C_truep((C_word)C_blockp(t7))){
t8=t6;
f_3062(2,t8,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 497  ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[7],lf[100],lf[103],t4);}}
else{
/* lolevel.scm: 501  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[7],lf[100],lf[104]);}}}

/* k3060 in loop in object-become! in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_blockp(t3))){
t4=t2;
f_3065(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 499  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[100],lf[102],((C_word*)t0)[2]);}}

/* k3063 in k3060 in loop in object-become! in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lolevel.scm: 500  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3040(t3,((C_word*)t0)[2],t2);}

/* k3033 in object-become! in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 502  ##sys#become! */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2893r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2893r(t0,t1,t2,t3);}}

static void C_ccall f_2893r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2897,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2897(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2897(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 458  ##sys#make-vector */
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2906,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2911,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2911(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2911,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 462  ##sys#hash-table-ref */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 465  ##sys#make-string */
t4=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm: 470  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 475  ##sys#make-vector */
t4=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}}}}

/* k2968 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 476  ##sys#hash-table-set! */
t4=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2971 in k2968 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li67),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2982(t7,t2,t3);}

/* doloop1087 in k2971 in k2968 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2982,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3003,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 479  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2911(t5,t3,t4);}}

/* k3001 in doloop1087 in k2971 in k2968 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2982(t4,((C_word*)t0)[2],t3);}

/* k2974 in k2971 in k2968 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2954 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2959,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 471  ##sys#hash-table-set! */
t3=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2957 in k2954 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2938 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 466  ##sys#hash-table-set! */
t4=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2941 in k2938 in k2925 in copy in k2904 in k2895 in object-unevict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2809,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2813,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 435  ##sys#make-vector */
t4=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2811 in object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2813,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2818,a[2]=t1,a[3]=t3,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2818(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2811 in object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2818(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2818,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 438  ##sys#hash-table-ref */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2829 in evict in k2811 in object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm: 442  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2888(2,t4,(C_word)C_bytes(t2));}}}

/* k2886 in k2829 in evict in k2811 in object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 444  ##sys#hash-table-set! */
t6=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2838 in k2886 in k2829 in evict in k2811 in object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2843,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2843(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li64),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2852(t9,t2,t5);}}

/* doloop1011 in k2838 in k2886 in k2829 in evict in k2811 in object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2852,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2874,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 451  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2818(t5,t3,t4);}}

/* k2872 in doloop1011 in k2838 in k2886 in k2829 in evict in k2811 in object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2852(t5,((C_word*)t0)[2],t4);}

/* k2841 in k2838 in k2886 in k2829 in evict in k2811 in object-size in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2639r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2639r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2639r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2643,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t5;
f_2643(2,t7,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 390  ##sys#signal-hook */
t7=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[7],lf[84],lf[96],t3);}}

/* k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[84]);
t5=t2;
f_2646(t5,t3);}
else{
t3=t2;
f_2646(t3,C_SCHEME_FALSE);}}

/* k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2646(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2646,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2788,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 398  ##sys#pointer->address */
t6=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2786 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 398  ##sys#address->pointer */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 399  ##sys#make-vector */
t3=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li62),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2660(t6,t2,((C_word*)t0)[2]);}

/* evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2660(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2660,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 403  ##sys#hash-table-ref */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 407  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2781(2,t4,(C_word)C_bytes(t2));}}}

/* k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2682,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2765,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm: 414  make-property-condition */
t9=*((C_word*)lf[88]+1);
((C_proc9)(void*)(*((C_word*)t9+1)))(9,t9,t7,lf[91],lf[92],lf[84],lf[93],lf[94],lf[95],t8);}
else{
t6=t3;
f_2682(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2682(2,t4,C_SCHEME_UNDEFINED);}}

/* k2767 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2773,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 418  make-property-condition */
t3=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[89],lf[90],((C_word*)((C_word*)t0)[2])[1]);}

/* k2771 in k2767 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 413  make-composite-condition */
t2=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2763 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 412  signal */
t2=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2680 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[8]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2742,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 421  ##sys#pointer->address */
t7=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[7]);}

/* k2740 in k2680 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 421  ##sys#set-pointer-address! */
t3=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2686 in k2680 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 422  ##sys#hash-table-set! */
t3=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2689 in k2686 in k2680 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2694(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li61),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2703(t9,t2,t5);}}

/* doloop959 in k2689 in k2686 in k2680 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2703,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2724,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 429  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2660(t5,t3,t4);}}

/* k2722 in doloop959 in k2689 in k2686 in k2680 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2703(t4,((C_word*)t0)[2],t3);}

/* k2692 in k2689 in k2686 in k2680 in k2779 in k2668 in evict in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2653 in k2650 in k2647 in k2644 in k2641 in object-evict-to-location in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 431  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-release in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2547r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2547r(t0,t1,t2,t3);}}

static void C_ccall f_2547r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2556,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2556(t11,t1,t2);}

/* release in object-release in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2556,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2585,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t7=t6;
f_2585(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_2601(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* doloop884 in release in object-release in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2601,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2611,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 382  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2556(t5,t3,t4);}}

/* k2609 in doloop884 in release in object-release in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2601(t3,((C_word*)t0)[2],t2);}

/* k2583 in release in object-release in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 383  ##sys#address->pointer */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2590 in k2583 in release in object-release in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 383  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_2629 in object-release in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2629,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub861(C_SCHEME_UNDEFINED,t3));}

/* object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2436r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2436r(t0,t1,t2,t3);}}

static void C_ccall f_2436r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2443,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 349  ##sys#make-vector */
t7=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2448(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2448,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 352  ##sys#hash-table-ref */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2456 in evict in k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2458,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm: 355  align-to-word */
t4=*((C_word*)lf[30]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2467(2,t4,(C_word)C_bytes(t2));}}}

/* k2465 in k2456 in evict in k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 356  allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2469 in k2465 in k2456 in evict in k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[6],t1);
t3=(C_word)C_i_symbolp(((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 358  ##sys#hash-table-set! */
t6=*((C_word*)lf[81]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2475 in k2469 in k2465 in k2456 in evict in k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2480(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li54),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2489(t9,t2,t5);}}

/* doloop831 in k2475 in k2469 in k2465 in k2456 in evict in k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2489(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2489,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2510,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 363  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2448(t5,t3,t4);}}

/* k2508 in doloop831 in k2475 in k2469 in k2465 in k2456 in evict in k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2489(t4,((C_word*)t0)[2],t3);}

/* k2478 in k2475 in k2469 in k2465 in k2456 in evict in k2441 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2540 in object-evict in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2540,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub795(t3,t4));}

/* object-evicted? in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2433,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* object-copy in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2352,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=t4,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2358(t6,t1,t2);}

/* copy in object-copy in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2358(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2358,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 325  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 329  ##sys#make-vector */
t6=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2386 in copy in object-copy in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2391,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_2391(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li49),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_2403(t10,t3,t6);}}

/* doloop768 in k2386 in copy in object-copy in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2403(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2403,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2424,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 333  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2358(t5,t3,t4);}}

/* k2422 in doloop768 in k2386 in copy in object-copy in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2403(t4,((C_word*)t0)[2],t3);}

/* k2389 in k2386 in copy in object-copy in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* record->vector in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2298,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_structurep(t2));
if(C_truep(t4)){
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2311,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 313  ##sys#make-vector */
t7=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
/* lolevel.scm: 317  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[7],lf[75],lf[77],t2);}}

/* k2309 in record->vector in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li47),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2316(t2,C_fix(0)));}

/* doloop724 in k2309 in record->vector in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static C_word C_fcall f_2316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance? in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2292,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE));}

/* make-record-instance in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2283(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2283r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2283r(t0,t1,t2,t3);}}

static void C_ccall f_2283r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[72]);
C_apply(5,0,t1,*((C_word*)lf[73]+1),t2,t3);}

/* number-of-bytes in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2261,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 295  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[70],lf[71],t2);}}

/* number-of-slots in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2240,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2253,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2253(t6,t4);}
else{
t6=(C_word)C_specialp(t2);
t7=t5;
f_2253(t7,(C_truep(t6)?t6:(C_word)C_byteblockp(t2)));}}

/* k2251 in number-of-slots in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_fcall f_2253(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* lolevel.scm: 290  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[7],lf[68],lf[69],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2244(2,t2,C_SCHEME_UNDEFINED);}}

/* k2242 in number-of-slots in k2236 in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* set-procedure-data! in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2220,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 274  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k2222 in set-procedure-data! in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 277  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[7],lf[63],lf[64],((C_word*)t0)[3]);}}

/* procedure-data in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2186,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2204,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 268  ##sys#lambda-decoration */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2203 in procedure-data in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2204,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2194 in procedure-data in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2155,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 262  ##sys#lambda-decoration */
t5=*((C_word*)lf[61]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a2169 in extended-procedure? in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2170,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2166 in extended-procedure? in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2117,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2121,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_closurep(t2))){
t5=t4;
f_2121(2,t5,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 251  ##sys#signal-hook */
t5=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[7],lf[57],lf[59],t2);}}

/* k2119 in extend-procedure in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2126,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[4],a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 252  ##sys#decorate-lambda */
t4=*((C_word*)lf[58]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a2141 in k2119 in extend-procedure in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2142,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[56],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a2125 in k2119 in extend-procedure in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2126,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[56],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-tag in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2095,3,t0,t1,t2);}
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 241  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[53],lf[54],t2);}}

/* tagged-pointer? in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2079,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_equalp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* tag-pointer in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2064,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2068,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 226  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2066 in tag-pointer in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2071,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_blockp(((C_word*)t0)[2]))?(C_word)C_specialp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_2071(2,t4,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 229  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[7],lf[49],lf[50],((C_word*)t0)[2]);}}

/* k2069 in k2066 in tag-pointer in k2060 in k2056 in k2052 in k2048 in k2044 in k2040 in k2036 in k2032 in k1313 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pointer-f64-set! in k1313 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2018,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub494(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-f32-set! in k1313 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2004,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub483(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s32-set! in k1313 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1990,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub472(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u32-set! in k1313 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1976,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub461(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s16-set! in k1313 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1962,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub450(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u16-set! in k1313 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1948,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub439(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s8-set! in k1313 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1934,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub428(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u8-set! in k1313 */
static void C_ccall f_1920(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1920,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub417(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-offset in k1313 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1906,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub404(t4,t5,t6));}

/* align-to-word in k1313 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1874,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
/* lolevel.scm: 167  align */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,f_1868(C_a_i(&a,6),t2));}
else{
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1901,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 169  ##sys#pointer->address */
t5=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* lolevel.scm: 170  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[7],lf[30],lf[31],t2);}}}

/* k1899 in align-to-word in k1313 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1901,2,t0,t1);}
t2=f_1868(C_a_i(&a,6),t1);
/* lolevel.scm: 169  ##sys#address->pointer */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k1313 */
static C_word C_fcall f_1868(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)C_i_foreign_integer_argumentp(t1);
return((C_word)stub383(t2,t3));}

/* free in k1313 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1858,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub373(C_SCHEME_UNDEFINED,t3));}

/* allocate in k1313 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1851,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub365(t3,t4));}

/* pointer=? in k1313 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1842,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1846,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 157  ##sys#check-special */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[27]);}

/* k1844 in pointer=? in k1313 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 158  ##sys#check-special */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[27]);}

/* k1847 in k1844 in pointer=? in k1313 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k1313 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1836,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1840,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 153  ##sys#check-pointer */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[26]);}

/* k1838 in pointer->object in k1313 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k1313 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1825,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1833,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1833 in object->pointer in k1313 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1833,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub345(t3,t2));}

/* null-pointer? in k1313 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1812,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1816,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 143  ##sys#check-special */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[24]);}

/* k1814 in null-pointer? in k1313 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1823,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 144  ##sys#pointer->address */
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1821 in k1814 in null-pointer? in k1313 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k1313 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1803,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1807,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 139  ##sys#check-special */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[21]);}

/* k1805 in pointer->address in k1313 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 140  ##sys#pointer->address */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k1313 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1788,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_integerp(t2))){
t4=t3;
f_1788(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 134  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[7],lf[18],lf[20],t2);}}

/* k1786 in address->pointer in k1313 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 136  ##sys#address->pointer */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer? in k1313 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1775,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_pointerp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_taggedpointerp(t2)));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#check-pointer in k1313 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1756,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1763,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t2))){
t5=(C_word)C_pointerp(t2);
if(C_truep(t5)){
t6=t4;
f_1763(t6,t5);}
else{
t6=(C_word)C_swigpointerp(t2);
t7=t4;
f_1763(t7,(C_truep(t6)?t6:(C_word)C_taggedpointerp(t2)));}}
else{
t5=t4;
f_1763(t5,C_SCHEME_FALSE);}}

/* k1761 in ##sys#check-pointer in k1313 */
static void C_fcall f_1763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 121  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],lf[14],((C_word*)t0)[2]);}}

/* move-memory! in k1313 */
static void C_ccall f_1429(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_1429r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1429r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1429r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1683,a[2]=t5,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1688,a[2]=t6,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1693,a[2]=t7,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-n122268 */
t9=t8;
f_1693(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-foffset123264 */
t11=t7;
f_1688(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-toffset124259 */
t13=t6;
f_1683(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body120130 */
t15=t5;
f_1431(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n122 in move-memory! in k1313 */
static void C_fcall f_1693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1693,NULL,2,t0,t1);}
/* def-foffset123264 */
t2=((C_word*)t0)[2];
f_1688(t2,t1,C_SCHEME_FALSE);}

/* def-foffset123 in move-memory! in k1313 */
static void C_fcall f_1688(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1688,NULL,3,t0,t1,t2);}
/* def-toffset124259 */
t3=((C_word*)t0)[2];
f_1683(t3,t1,t2,C_fix(0));}

/* def-toffset124 in move-memory! in k1313 */
static void C_fcall f_1683(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1683,NULL,4,t0,t1,t2,t3);}
/* body120130 */
t4=((C_word*)t0)[2];
f_1431(t4,t1,t2,t3,C_fix(0));}

/* body120 in move-memory! in k1313 */
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1431,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li0),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1440,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1491,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t3,a[6]=t4,a[7]=t2,a[8]=t6,a[9]=t10,a[10]=((C_word*)t0)[2],a[11]=((C_word)li4),tmp=(C_word)a,a+=12,tmp));
t12=((C_word*)t10)[1];
f_1491(t12,t1,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* move in body120 in move-memory! in k1313 */
static void C_fcall f_1491(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1491,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 91   move */
t11=t1;
t12=t5;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 92   xerr */
f_1440(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[10]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 95   move */
t11=t1;
t12=t2;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 96   xerr */
f_1440(t1,t3);}}
else{
t4=(C_word)C_pointerp(t2);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[7],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_1553(2,t6,t4);}
else{
/* lolevel.scm: 97   ##sys#locative? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}}

/* k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_pointerp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1562,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_1562(2,t4,t2);}
else{
/* lolevel.scm: 98   ##sys#locative? */
t4=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 103  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k1612 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1614,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[10]);
t4=(C_word)C_pointerp(((C_word*)t0)[9]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t4)){
t6=t5;
f_1629(2,t6,t4);}
else{
/* lolevel.scm: 105  ##sys#locative? */
t6=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[9]);}}
else{
/* lolevel.scm: 111  xerr */
f_1440(((C_word*)t0)[8],((C_word*)t0)[10]);}}

/* k1627 in k1612 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1629,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:((C_word*)t0)[5]);
/* lolevel.scm: 106  checkn */
t5=((C_word*)t0)[4];
f_1446(t5,t2,t4,((C_word*)t0)[5],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 107  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}}

/* k1644 in k1627 in k1612 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(C_truep(t4)?t4:((C_word*)t0)[4]);
t6=(C_word)C_block_size(((C_word*)t0)[10]);
/* lolevel.scm: 108  checkn2 */
t7=((C_word*)t0)[3];
f_1462(t7,t3,t5,((C_word*)t0)[4],t6,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* lolevel.scm: 110  xerr */
f_1440(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1654 in k1644 in k1627 in k1612 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub87(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1634 in k1627 in k1612 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub49(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1560 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1562,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_1569(2,t4,t2);}
else{
/* lolevel.scm: 99   err */
t4=((C_word*)t0)[4];
f_1434(t4,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* lolevel.scm: 100  ##sys#bytevector? */
t3=*((C_word*)lf[11]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}}

/* k1576 in k1560 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[10]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_1592(2,t6,t4);}
else{
/* lolevel.scm: 101  err */
t6=((C_word*)t0)[3];
f_1434(t6,t5);}}
else{
/* lolevel.scm: 102  xerr */
f_1440(((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k1590 in k1576 in k1560 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 101  checkn */
t3=((C_word*)t0)[4];
f_1446(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1586 in k1576 in k1560 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub68(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1567 in k1560 in k1551 in move in body120 in move-memory! in k1313 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_fixnum_argumentp(t1);
t10=(C_word)C_i_foreign_fixnum_argumentp(t5);
t11=(C_word)C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)stub30(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body120 in move-memory! in k1313 */
static void C_fcall f_1462(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1462,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1469,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_fixnum_difference(t3,t5);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t8))){
t9=(C_word)C_fixnum_difference(t4,t6);
t10=t7;
f_1469(t10,(C_word)C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1469(t9,C_SCHEME_FALSE);}}

/* k1467 in checkn2 in body120 in move-memory! in k1313 */
static void C_fcall f_1469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
/* lolevel.scm: 87   ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[7],lf[3],lf[10],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* checkn in body120 in move-memory! in k1313 */
static void C_fcall f_1446(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1446,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t3,t4);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
/* lolevel.scm: 83   ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t6+1)))(8,t6,t1,lf[3],lf[9],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}}

/* xerr in body120 in move-memory! in k1313 */
static void C_fcall f_1440(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1440,NULL,2,t1,t2);}
/* lolevel.scm: 79   ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[7],lf[3],lf[8],t2);}

/* err in body120 in move-memory! in k1313 */
static void C_fcall f_1434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1434,NULL,2,t0,t1);}
/* lolevel.scm: 78   ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[3],lf[5],((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[194] = {
{"toplevellolevel.scm",(void*)C_lolevel_toplevel},
{"f_1315lolevel.scm",(void*)f_1315},
{"f_3344lolevel.scm",(void*)f_3344},
{"f_2034lolevel.scm",(void*)f_2034},
{"f_3334lolevel.scm",(void*)f_3334},
{"f_2038lolevel.scm",(void*)f_2038},
{"f_3324lolevel.scm",(void*)f_3324},
{"f_2042lolevel.scm",(void*)f_2042},
{"f_3314lolevel.scm",(void*)f_3314},
{"f_2046lolevel.scm",(void*)f_2046},
{"f_3304lolevel.scm",(void*)f_3304},
{"f_2050lolevel.scm",(void*)f_2050},
{"f_3294lolevel.scm",(void*)f_3294},
{"f_2054lolevel.scm",(void*)f_2054},
{"f_3284lolevel.scm",(void*)f_3284},
{"f_2058lolevel.scm",(void*)f_2058},
{"f_3274lolevel.scm",(void*)f_3274},
{"f_2062lolevel.scm",(void*)f_2062},
{"f_2238lolevel.scm",(void*)f_2238},
{"f_3188lolevel.scm",(void*)f_3188},
{"f_3260lolevel.scm",(void*)f_3260},
{"f_3251lolevel.scm",(void*)f_3251},
{"f_3242lolevel.scm",(void*)f_3242},
{"f_3236lolevel.scm",(void*)f_3236},
{"f_3219lolevel.scm",(void*)f_3219},
{"f_3224lolevel.scm",(void*)f_3224},
{"f_3200lolevel.scm",(void*)f_3200},
{"f_3204lolevel.scm",(void*)f_3204},
{"f_3207lolevel.scm",(void*)f_3207},
{"f_3193lolevel.scm",(void*)f_3193},
{"f_3190lolevel.scm",(void*)f_3190},
{"f_3183lolevel.scm",(void*)f_3183},
{"f_3154lolevel.scm",(void*)f_3154},
{"f_3162lolevel.scm",(void*)f_3162},
{"f_3125lolevel.scm",(void*)f_3125},
{"f_3133lolevel.scm",(void*)f_3133},
{"f_3091lolevel.scm",(void*)f_3091},
{"f_3095lolevel.scm",(void*)f_3095},
{"f_3102lolevel.scm",(void*)f_3102},
{"f_3117lolevel.scm",(void*)f_3117},
{"f_3105lolevel.scm",(void*)f_3105},
{"f_3028lolevel.scm",(void*)f_3028},
{"f_3040lolevel.scm",(void*)f_3040},
{"f_3062lolevel.scm",(void*)f_3062},
{"f_3065lolevel.scm",(void*)f_3065},
{"f_3035lolevel.scm",(void*)f_3035},
{"f_2893lolevel.scm",(void*)f_2893},
{"f_2897lolevel.scm",(void*)f_2897},
{"f_2906lolevel.scm",(void*)f_2906},
{"f_2911lolevel.scm",(void*)f_2911},
{"f_2927lolevel.scm",(void*)f_2927},
{"f_2970lolevel.scm",(void*)f_2970},
{"f_2973lolevel.scm",(void*)f_2973},
{"f_2982lolevel.scm",(void*)f_2982},
{"f_3003lolevel.scm",(void*)f_3003},
{"f_2976lolevel.scm",(void*)f_2976},
{"f_2956lolevel.scm",(void*)f_2956},
{"f_2959lolevel.scm",(void*)f_2959},
{"f_2940lolevel.scm",(void*)f_2940},
{"f_2943lolevel.scm",(void*)f_2943},
{"f_2809lolevel.scm",(void*)f_2809},
{"f_2813lolevel.scm",(void*)f_2813},
{"f_2818lolevel.scm",(void*)f_2818},
{"f_2831lolevel.scm",(void*)f_2831},
{"f_2888lolevel.scm",(void*)f_2888},
{"f_2840lolevel.scm",(void*)f_2840},
{"f_2852lolevel.scm",(void*)f_2852},
{"f_2874lolevel.scm",(void*)f_2874},
{"f_2843lolevel.scm",(void*)f_2843},
{"f_2639lolevel.scm",(void*)f_2639},
{"f_2643lolevel.scm",(void*)f_2643},
{"f_2646lolevel.scm",(void*)f_2646},
{"f_2788lolevel.scm",(void*)f_2788},
{"f_2649lolevel.scm",(void*)f_2649},
{"f_2652lolevel.scm",(void*)f_2652},
{"f_2660lolevel.scm",(void*)f_2660},
{"f_2670lolevel.scm",(void*)f_2670},
{"f_2781lolevel.scm",(void*)f_2781},
{"f_2769lolevel.scm",(void*)f_2769},
{"f_2773lolevel.scm",(void*)f_2773},
{"f_2765lolevel.scm",(void*)f_2765},
{"f_2682lolevel.scm",(void*)f_2682},
{"f_2742lolevel.scm",(void*)f_2742},
{"f_2688lolevel.scm",(void*)f_2688},
{"f_2691lolevel.scm",(void*)f_2691},
{"f_2703lolevel.scm",(void*)f_2703},
{"f_2724lolevel.scm",(void*)f_2724},
{"f_2694lolevel.scm",(void*)f_2694},
{"f_2655lolevel.scm",(void*)f_2655},
{"f_2547lolevel.scm",(void*)f_2547},
{"f_2556lolevel.scm",(void*)f_2556},
{"f_2601lolevel.scm",(void*)f_2601},
{"f_2611lolevel.scm",(void*)f_2611},
{"f_2585lolevel.scm",(void*)f_2585},
{"f_2592lolevel.scm",(void*)f_2592},
{"f_2629lolevel.scm",(void*)f_2629},
{"f_2436lolevel.scm",(void*)f_2436},
{"f_2443lolevel.scm",(void*)f_2443},
{"f_2448lolevel.scm",(void*)f_2448},
{"f_2458lolevel.scm",(void*)f_2458},
{"f_2467lolevel.scm",(void*)f_2467},
{"f_2471lolevel.scm",(void*)f_2471},
{"f_2477lolevel.scm",(void*)f_2477},
{"f_2489lolevel.scm",(void*)f_2489},
{"f_2510lolevel.scm",(void*)f_2510},
{"f_2480lolevel.scm",(void*)f_2480},
{"f_2540lolevel.scm",(void*)f_2540},
{"f_2433lolevel.scm",(void*)f_2433},
{"f_2352lolevel.scm",(void*)f_2352},
{"f_2358lolevel.scm",(void*)f_2358},
{"f_2388lolevel.scm",(void*)f_2388},
{"f_2403lolevel.scm",(void*)f_2403},
{"f_2424lolevel.scm",(void*)f_2424},
{"f_2391lolevel.scm",(void*)f_2391},
{"f_2298lolevel.scm",(void*)f_2298},
{"f_2311lolevel.scm",(void*)f_2311},
{"f_2316lolevel.scm",(void*)f_2316},
{"f_2292lolevel.scm",(void*)f_2292},
{"f_2283lolevel.scm",(void*)f_2283},
{"f_2261lolevel.scm",(void*)f_2261},
{"f_2240lolevel.scm",(void*)f_2240},
{"f_2253lolevel.scm",(void*)f_2253},
{"f_2244lolevel.scm",(void*)f_2244},
{"f_2220lolevel.scm",(void*)f_2220},
{"f_2224lolevel.scm",(void*)f_2224},
{"f_2186lolevel.scm",(void*)f_2186},
{"f_2204lolevel.scm",(void*)f_2204},
{"f_2196lolevel.scm",(void*)f_2196},
{"f_2155lolevel.scm",(void*)f_2155},
{"f_2170lolevel.scm",(void*)f_2170},
{"f_2168lolevel.scm",(void*)f_2168},
{"f_2117lolevel.scm",(void*)f_2117},
{"f_2121lolevel.scm",(void*)f_2121},
{"f_2142lolevel.scm",(void*)f_2142},
{"f_2126lolevel.scm",(void*)f_2126},
{"f_2095lolevel.scm",(void*)f_2095},
{"f_2079lolevel.scm",(void*)f_2079},
{"f_2064lolevel.scm",(void*)f_2064},
{"f_2068lolevel.scm",(void*)f_2068},
{"f_2071lolevel.scm",(void*)f_2071},
{"f_2018lolevel.scm",(void*)f_2018},
{"f_2004lolevel.scm",(void*)f_2004},
{"f_1990lolevel.scm",(void*)f_1990},
{"f_1976lolevel.scm",(void*)f_1976},
{"f_1962lolevel.scm",(void*)f_1962},
{"f_1948lolevel.scm",(void*)f_1948},
{"f_1934lolevel.scm",(void*)f_1934},
{"f_1920lolevel.scm",(void*)f_1920},
{"f_1906lolevel.scm",(void*)f_1906},
{"f_1874lolevel.scm",(void*)f_1874},
{"f_1901lolevel.scm",(void*)f_1901},
{"f_1868lolevel.scm",(void*)f_1868},
{"f_1858lolevel.scm",(void*)f_1858},
{"f_1851lolevel.scm",(void*)f_1851},
{"f_1842lolevel.scm",(void*)f_1842},
{"f_1846lolevel.scm",(void*)f_1846},
{"f_1849lolevel.scm",(void*)f_1849},
{"f_1836lolevel.scm",(void*)f_1836},
{"f_1840lolevel.scm",(void*)f_1840},
{"f_1825lolevel.scm",(void*)f_1825},
{"f_1833lolevel.scm",(void*)f_1833},
{"f_1812lolevel.scm",(void*)f_1812},
{"f_1816lolevel.scm",(void*)f_1816},
{"f_1823lolevel.scm",(void*)f_1823},
{"f_1803lolevel.scm",(void*)f_1803},
{"f_1807lolevel.scm",(void*)f_1807},
{"f_1784lolevel.scm",(void*)f_1784},
{"f_1788lolevel.scm",(void*)f_1788},
{"f_1775lolevel.scm",(void*)f_1775},
{"f_1756lolevel.scm",(void*)f_1756},
{"f_1763lolevel.scm",(void*)f_1763},
{"f_1429lolevel.scm",(void*)f_1429},
{"f_1693lolevel.scm",(void*)f_1693},
{"f_1688lolevel.scm",(void*)f_1688},
{"f_1683lolevel.scm",(void*)f_1683},
{"f_1431lolevel.scm",(void*)f_1431},
{"f_1491lolevel.scm",(void*)f_1491},
{"f_1553lolevel.scm",(void*)f_1553},
{"f_1614lolevel.scm",(void*)f_1614},
{"f_1629lolevel.scm",(void*)f_1629},
{"f_1646lolevel.scm",(void*)f_1646},
{"f_1656lolevel.scm",(void*)f_1656},
{"f_1636lolevel.scm",(void*)f_1636},
{"f_1562lolevel.scm",(void*)f_1562},
{"f_1578lolevel.scm",(void*)f_1578},
{"f_1592lolevel.scm",(void*)f_1592},
{"f_1588lolevel.scm",(void*)f_1588},
{"f_1569lolevel.scm",(void*)f_1569},
{"f_1462lolevel.scm",(void*)f_1462},
{"f_1469lolevel.scm",(void*)f_1469},
{"f_1446lolevel.scm",(void*)f_1446},
{"f_1440lolevel.scm",(void*)f_1440},
{"f_1434lolevel.scm",(void*)f_1434},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
