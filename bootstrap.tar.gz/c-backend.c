/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-08-25 23:22
   Version 4.0.0x - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 11761	compiled 2008-08-25 on tesseract.thetesseract.org (Linux)
   command line: c-backend.scm -optimize-level 2 -include-path . -include-path . -no-lambda-info -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[822];
static double C_possibly_force_alignment;


/* from getsize in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2372(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2372(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2367(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2367(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9059)
static void C_ccall f_9059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9055)
static void C_ccall f_9055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8755)
static void C_ccall f_8755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9029)
static void C_ccall f_9029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9017)
static void C_ccall f_9017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8987)
static void C_ccall f_8987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8948)
static void C_ccall f_8948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8935)
static void C_ccall f_8935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8931)
static void C_ccall f_8931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static C_word C_fcall f_8764(C_word *a,C_word t0);
C_noret_decl(f_8761)
static C_word C_fcall f_8761(C_word t0);
C_noret_decl(f_8758)
static C_word C_fcall f_8758(C_word t0);
C_noret_decl(f_8357)
static void C_ccall f_8357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8444)
static void C_fcall f_8444(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8547)
static void C_fcall f_8547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8359)
static void C_fcall f_8359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7872)
static void C_ccall f_7872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7902)
static void C_fcall f_7902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7929)
static void C_fcall f_7929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8124)
static void C_fcall f_8124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_fcall f_8133(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8142)
static void C_ccall f_8142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8164)
static void C_fcall f_8164(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8241)
static void C_ccall f_8241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_fcall f_7874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7036)
static void C_ccall f_7036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7113)
static void C_fcall f_7113(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_fcall f_7215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7248)
static void C_fcall f_7248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_fcall f_7344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7359)
static void C_ccall f_7359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7399)
static void C_fcall f_7399(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_fcall f_7416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7433)
static void C_fcall f_7433(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_fcall f_7472(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_fcall f_7489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7506)
static void C_fcall f_7506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_fcall f_7523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7540)
static void C_fcall f_7540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7557)
static void C_fcall f_7557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7574)
static void C_fcall f_7574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7586)
static void C_ccall f_7586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7593)
static void C_ccall f_7593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7603)
static void C_ccall f_7603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7597)
static void C_ccall f_7597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7513)
static void C_ccall f_7513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7496)
static void C_ccall f_7496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7444)
static void C_ccall f_7444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7452)
static void C_ccall f_7452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_ccall f_7448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7440)
static void C_ccall f_7440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7427)
static void C_ccall f_7427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7043)
static void C_fcall f_7043(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7038)
static void C_fcall f_7038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6971)
static void C_ccall f_6971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6975)
static void C_ccall f_6975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6984)
static void C_ccall f_6984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7034)
static void C_ccall f_7034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7005)
static void C_ccall f_7005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6996)
static void C_ccall f_6996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6540)
static void C_ccall f_6540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6546)
static void C_ccall f_6546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6909)
static void C_ccall f_6909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6969)
static void C_ccall f_6969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6912)
static void C_ccall f_6912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6954)
static void C_ccall f_6954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6927)
static void C_ccall f_6927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6567)
static void C_ccall f_6567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6577)
static void C_fcall f_6577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_fcall f_6586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6598)
static void C_fcall f_6598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6610)
static void C_fcall f_6610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6650)
static void C_fcall f_6650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6307)
static void C_ccall f_6307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6313)
static void C_ccall f_6313(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6538)
static void C_ccall f_6538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6329)
static void C_ccall f_6329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6332)
static void C_ccall f_6332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6335)
static void C_ccall f_6335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6344)
static void C_ccall f_6344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6347)
static void C_ccall f_6347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_ccall f_6365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6377)
static void C_ccall f_6377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_ccall f_6395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6389)
static void C_ccall f_6389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6299)
static void C_ccall f_6299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6302)
static void C_ccall f_6302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6261)
static void C_ccall f_6261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6241)
static void C_ccall f_6241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6247)
static void C_ccall f_6247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6136)
static void C_ccall f_6136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6145)
static void C_fcall f_6145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6174)
static void C_fcall f_6174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_fcall f_6177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6161)
static void C_fcall f_6161(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6067)
static void C_ccall f_6067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6081)
static void C_fcall f_6081(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6097)
static void C_ccall f_6097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6034)
static void C_ccall f_6034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6037)
static void C_ccall f_6037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6052)
static void C_ccall f_6052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_ccall f_6055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_fcall f_5283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5293)
static void C_ccall f_5293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5296)
static void C_ccall f_5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_ccall f_5299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_fcall f_5311(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_ccall f_5320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5332)
static void C_ccall f_5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5957)
static void C_ccall f_5957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5362)
static void C_ccall f_5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_fcall f_5929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5932)
static void C_ccall f_5932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5374)
static void C_ccall f_5374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_fcall f_5377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_fcall f_5891(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5901)
static void C_ccall f_5901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_fcall f_5834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5855)
static void C_fcall f_5855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_fcall f_5798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5759)
static void C_ccall f_5759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5765)
static void C_fcall f_5765(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5768)
static void C_ccall f_5768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5774)
static void C_fcall f_5774(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5719)
static void C_fcall f_5719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5707)
static void C_ccall f_5707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5710)
static void C_ccall f_5710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5615)
static void C_ccall f_5615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_fcall f_5409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5427)
static void C_ccall f_5427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5445)
static void C_ccall f_5445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5448)
static void C_ccall f_5448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_fcall f_5469(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_fcall f_5021(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_ccall f_4935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_fcall f_4850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4856)
static void C_fcall f_4856(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_fcall f_5052(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_fcall f_5059(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_fcall f_5148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_fcall f_4887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_fcall f_5194(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_fcall f_5209(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5225)
static void C_fcall f_5225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5271)
static void C_fcall f_5271(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_fcall f_4564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4741)
static void C_ccall f_4741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_fcall f_4750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_fcall f_4753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4759)
static void C_ccall f_4759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_fcall f_4799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_fcall f_4603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4609)
static void C_ccall f_4609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4630)
static void C_ccall f_4630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_fcall f_4567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_fcall f_4580(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4313)
static void C_fcall f_4313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_ccall f_4348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_fcall f_4351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4357)
static void C_ccall f_4357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_fcall f_4372(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_ccall f_4378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_ccall f_4381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_fcall f_4437(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_ccall f_4390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_ccall f_4399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_fcall f_4164(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_fcall f_4185(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_fcall f_4227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_fcall f_4017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4020)
static void C_fcall f_4020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3985)
static void C_fcall f_3985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_fcall f_2535(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2539)
static void C_ccall f_2539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_fcall f_3871(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3751)
static void C_ccall f_3751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_ccall f_3638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_fcall f_3212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_fcall f_3218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_fcall f_3374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3300)
static void C_ccall f_3300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3158)
static void C_ccall f_3158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3151)
static void C_ccall f_3151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_fcall f_2717(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2522)
static void C_fcall f_2522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_fcall f_2490(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8444)
static void C_fcall trf_8444(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8444(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8444(t0,t1);}

C_noret_decl(trf_8547)
static void C_fcall trf_8547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8547(t0,t1);}

C_noret_decl(trf_8359)
static void C_fcall trf_8359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8359(t0,t1);}

C_noret_decl(trf_7902)
static void C_fcall trf_7902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7902(t0,t1);}

C_noret_decl(trf_7929)
static void C_fcall trf_7929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7929(t0,t1);}

C_noret_decl(trf_8124)
static void C_fcall trf_8124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8124(t0,t1);}

C_noret_decl(trf_8133)
static void C_fcall trf_8133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8133(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8133(t0,t1);}

C_noret_decl(trf_8164)
static void C_fcall trf_8164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8164(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8164(t0,t1);}

C_noret_decl(trf_7874)
static void C_fcall trf_7874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7874(t0,t1);}

C_noret_decl(trf_7113)
static void C_fcall trf_7113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7113(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7113(t0,t1);}

C_noret_decl(trf_7215)
static void C_fcall trf_7215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7215(t0,t1);}

C_noret_decl(trf_7248)
static void C_fcall trf_7248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7248(t0,t1);}

C_noret_decl(trf_7344)
static void C_fcall trf_7344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7344(t0,t1);}

C_noret_decl(trf_7399)
static void C_fcall trf_7399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7399(t0,t1);}

C_noret_decl(trf_7416)
static void C_fcall trf_7416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7416(t0,t1);}

C_noret_decl(trf_7433)
static void C_fcall trf_7433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7433(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7433(t0,t1);}

C_noret_decl(trf_7472)
static void C_fcall trf_7472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7472(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7472(t0,t1);}

C_noret_decl(trf_7489)
static void C_fcall trf_7489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7489(t0,t1);}

C_noret_decl(trf_7506)
static void C_fcall trf_7506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7506(t0,t1);}

C_noret_decl(trf_7523)
static void C_fcall trf_7523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7523(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7523(t0,t1);}

C_noret_decl(trf_7540)
static void C_fcall trf_7540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7540(t0,t1);}

C_noret_decl(trf_7557)
static void C_fcall trf_7557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7557(t0,t1);}

C_noret_decl(trf_7574)
static void C_fcall trf_7574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7574(t0,t1);}

C_noret_decl(trf_7043)
static void C_fcall trf_7043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7043(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7043(t0,t1,t2);}

C_noret_decl(trf_7038)
static void C_fcall trf_7038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7038(t0,t1);}

C_noret_decl(trf_6577)
static void C_fcall trf_6577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6577(t0,t1);}

C_noret_decl(trf_6586)
static void C_fcall trf_6586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6586(t0,t1);}

C_noret_decl(trf_6598)
static void C_fcall trf_6598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6598(t0,t1);}

C_noret_decl(trf_6610)
static void C_fcall trf_6610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6610(t0,t1);}

C_noret_decl(trf_6650)
static void C_fcall trf_6650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6650(t0,t1);}

C_noret_decl(trf_6145)
static void C_fcall trf_6145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6145(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6145(t0,t1,t2);}

C_noret_decl(trf_6174)
static void C_fcall trf_6174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6174(t0,t1);}

C_noret_decl(trf_6177)
static void C_fcall trf_6177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6177(t0,t1);}

C_noret_decl(trf_6161)
static void C_fcall trf_6161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6161(t0,t1);}

C_noret_decl(trf_6081)
static void C_fcall trf_6081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6081(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6081(t0,t1,t2);}

C_noret_decl(trf_5283)
static void C_fcall trf_5283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5283(t0,t1);}

C_noret_decl(trf_5311)
static void C_fcall trf_5311(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5311(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5311(t0,t1);}

C_noret_decl(trf_5929)
static void C_fcall trf_5929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5929(t0,t1);}

C_noret_decl(trf_5377)
static void C_fcall trf_5377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5377(t0,t1);}

C_noret_decl(trf_5891)
static void C_fcall trf_5891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5891(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5891(t0,t1,t2,t3);}

C_noret_decl(trf_5834)
static void C_fcall trf_5834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5834(t0,t1);}

C_noret_decl(trf_5855)
static void C_fcall trf_5855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5855(t0,t1);}

C_noret_decl(trf_5798)
static void C_fcall trf_5798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5798(t0,t1);}

C_noret_decl(trf_5765)
static void C_fcall trf_5765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5765(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5765(t0,t1);}

C_noret_decl(trf_5774)
static void C_fcall trf_5774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5774(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5774(t0,t1);}

C_noret_decl(trf_5719)
static void C_fcall trf_5719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5719(t0,t1);}

C_noret_decl(trf_5409)
static void C_fcall trf_5409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5409(t0,t1);}

C_noret_decl(trf_5469)
static void C_fcall trf_5469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5469(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5469(t0,t1,t2,t3);}

C_noret_decl(trf_5021)
static void C_fcall trf_5021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5021(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5021(t0,t1,t2,t3);}

C_noret_decl(trf_4850)
static void C_fcall trf_4850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4850(t0,t1);}

C_noret_decl(trf_4856)
static void C_fcall trf_4856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4856(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4856(t0,t1,t2,t3);}

C_noret_decl(trf_5052)
static void C_fcall trf_5052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5052(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5052(t0,t1,t2,t3);}

C_noret_decl(trf_5059)
static void C_fcall trf_5059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5059(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5059(t0,t1);}

C_noret_decl(trf_5148)
static void C_fcall trf_5148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5148(t0,t1);}

C_noret_decl(trf_4887)
static void C_fcall trf_4887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4887(t0,t1);}

C_noret_decl(trf_5194)
static void C_fcall trf_5194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5194(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5194(t0,t1,t2);}

C_noret_decl(trf_5209)
static void C_fcall trf_5209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5209(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5209(t0,t1,t2,t3);}

C_noret_decl(trf_5225)
static void C_fcall trf_5225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5225(t0,t1);}

C_noret_decl(trf_5271)
static void C_fcall trf_5271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5271(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5271(t0,t1,t2,t3);}

C_noret_decl(trf_4564)
static void C_fcall trf_4564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4564(t0,t1);}

C_noret_decl(trf_4750)
static void C_fcall trf_4750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4750(t0,t1);}

C_noret_decl(trf_4753)
static void C_fcall trf_4753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4753(t0,t1);}

C_noret_decl(trf_4799)
static void C_fcall trf_4799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4799(t0,t1);}

C_noret_decl(trf_4603)
static void C_fcall trf_4603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4603(t0,t1,t2);}

C_noret_decl(trf_4567)
static void C_fcall trf_4567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4567(t0,t1);}

C_noret_decl(trf_4580)
static void C_fcall trf_4580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4580(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4580(t0,t1,t2,t3);}

C_noret_decl(trf_4313)
static void C_fcall trf_4313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4313(t0,t1);}

C_noret_decl(trf_4351)
static void C_fcall trf_4351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4351(t0,t1);}

C_noret_decl(trf_4372)
static void C_fcall trf_4372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4372(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4372(t0,t1);}

C_noret_decl(trf_4437)
static void C_fcall trf_4437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4437(t0,t1);}

C_noret_decl(trf_4164)
static void C_fcall trf_4164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4164(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4164(t0,t1);}

C_noret_decl(trf_4185)
static void C_fcall trf_4185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4185(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4185(t0,t1,t2,t3);}

C_noret_decl(trf_4254)
static void C_fcall trf_4254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4254(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4254(t0,t1,t2);}

C_noret_decl(trf_4227)
static void C_fcall trf_4227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4227(t0,t1,t2);}

C_noret_decl(trf_4017)
static void C_fcall trf_4017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4017(t0,t1);}

C_noret_decl(trf_4020)
static void C_fcall trf_4020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4020(t0,t1);}

C_noret_decl(trf_2532)
static void C_fcall trf_2532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2532(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2532(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3985)
static void C_fcall trf_3985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3985(t0,t1,t2,t3);}

C_noret_decl(trf_2535)
static void C_fcall trf_2535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2535(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2535(t0,t1,t2,t3);}

C_noret_decl(trf_3871)
static void C_fcall trf_3871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3871(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3871(t0,t1,t2,t3);}

C_noret_decl(trf_3212)
static void C_fcall trf_3212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3212(t0,t1);}

C_noret_decl(trf_3218)
static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3218(t0,t1);}

C_noret_decl(trf_3374)
static void C_fcall trf_3374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3374(t0,t1);}

C_noret_decl(trf_2717)
static void C_fcall trf_2717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2717(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2717(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2522)
static void C_fcall trf_2522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2522(t0,t1);}

C_noret_decl(trf_2490)
static void C_fcall trf_2490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2490(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2490(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2414)){
C_save(t1);
C_rereclaim2(2414*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,822);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],15,"\010compileroutput");
lf[3]=C_h_intern(&lf[3],12,"\010compilergen");
lf[4]=C_h_intern(&lf[4],7,"newline");
lf[5]=C_h_intern(&lf[5],7,"display");
lf[6]=C_h_intern(&lf[6],12,"\003sysfor-each");
lf[7]=C_h_intern(&lf[7],17,"\010compilergen-list");
lf[8]=C_h_intern(&lf[8],11,"intersperse");
lf[9]=C_h_intern(&lf[9],18,"\010compilerunique-id");
lf[10]=C_h_intern(&lf[10],22,"\010compilergenerate-code");
lf[11]=C_h_intern(&lf[11],13,"\010compilerbomb");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[13]=C_h_intern(&lf[13],17,"lambda-literal-id");
lf[14]=C_h_intern(&lf[14],4,"find");
lf[15]=C_h_intern(&lf[15],17,"string-translate*");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[17]=C_h_intern(&lf[17],8,"->string");
lf[18]=C_h_intern(&lf[18],14,"\004coreimmediate");
lf[19]=C_h_intern(&lf[19],4,"bool");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[22]=C_h_intern(&lf[22],4,"char");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[24]=C_h_intern(&lf[24],3,"nil");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[26]=C_h_intern(&lf[26],3,"fix");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[28]=C_h_intern(&lf[28],3,"eof");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[31]=C_h_intern(&lf[31],12,"\004coreliteral");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[35]=C_h_intern(&lf[35],2,"if");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[39]=C_h_intern(&lf[39],9,"\004coreproc");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[41]=C_h_intern(&lf[41],9,"\004corebind");
lf[42]=C_h_intern(&lf[42],8,"\004coreref");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[45]=C_h_intern(&lf[45],10,"\004coreunbox");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[48]=C_h_intern(&lf[48],13,"\004coreupdate_i");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[50]=C_h_intern(&lf[50],11,"\004coreupdate");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[54]=C_h_intern(&lf[54],16,"\004coreupdatebox_i");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[57]=C_h_intern(&lf[57],14,"\004coreupdatebox");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[60]=C_h_intern(&lf[60],12,"\004coreclosure");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[65]=C_h_intern(&lf[65],8,"for-each");
lf[66]=C_h_intern(&lf[66],4,"iota");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[68]=C_h_intern(&lf[68],8,"\004corebox");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[71]=C_h_intern(&lf[71],10,"\004corelocal");
lf[72]=C_h_intern(&lf[72],13,"\004coresetlocal");
lf[73]=C_h_intern(&lf[73],11,"\004coreglobal");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[78]=C_h_intern(&lf[78],21,"\010compilerc-ify-string");
lf[79]=C_h_intern(&lf[79],14,"symbol->string");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[84]=C_h_intern(&lf[84],14,"\004coresetglobal");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\004 /* ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[91]=C_h_intern(&lf[91],16,"\004coresetglobal_i");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[98]=C_h_intern(&lf[98],14,"\004coreundefined");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[100]=C_h_intern(&lf[100],9,"\004corecall");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[106]=C_h_intern(&lf[106],26,"lambda-literal-temporaries");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_h_intern(&lf[108],22,"lambda-literal-looping");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[112]=C_h_intern(&lf[112],6,"unsafe");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[117]=C_h_intern(&lf[117],19,"no-procedure-checks");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[120]=C_h_intern(&lf[120],24,"\010compileremit-trace-info");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[123]=C_h_intern(&lf[123],16,"string-translate");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[128]=C_h_intern(&lf[128],27,"lambda-literal-closure-size");
lf[129]=C_h_intern(&lf[129],28,"\010compilersource-info->string");
lf[130]=C_h_intern(&lf[130],12,"\004corerecurse");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[134]=C_h_intern(&lf[134],16,"\004coredirect_call");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[136]=C_h_intern(&lf[136],13,"\004corecallunit");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[141]=C_h_intern(&lf[141],11,"\004corereturn");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[144]=C_h_intern(&lf[144],11,"\004coreinline");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[146]=C_h_intern(&lf[146],20,"\004coreinline_allocate");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[149]=C_h_intern(&lf[149],15,"\004coreinline_ref");
lf[150]=C_h_intern(&lf[150],34,"\010compilerforeign-result-conversion");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[152]=C_h_intern(&lf[152],18,"\004coreinline_update");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[155]=C_h_intern(&lf[155],36,"\010compilerforeign-argument-conversion");
lf[156]=C_h_intern(&lf[156],33,"\010compilerforeign-type-declaration");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[158]=C_h_intern(&lf[158],19,"\004coreinline_loc_ref");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[164]=C_h_intern(&lf[164],22,"\004coreinline_loc_update");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[170]=C_h_intern(&lf[170],11,"\004coreswitch");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[175]=C_h_intern(&lf[175],9,"\004corecond");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[179]=C_h_intern(&lf[179],13,"pair-for-each");
lf[180]=C_h_intern(&lf[180],13,"string-append");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[182]=C_h_intern(&lf[182],30,"\010compilerexternal-protos-first");
lf[183]=C_h_intern(&lf[183],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[184]=C_h_intern(&lf[184],22,"foreign-callback-stubs");
lf[185]=C_h_intern(&lf[185],29,"\010compilerforeign-declarations");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[188]=C_h_intern(&lf[188],28,"\010compilertarget-include-file");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[190]=C_h_intern(&lf[190],18,"\010compilerunit-name");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[192]=C_h_intern(&lf[192],19,"\010compilerused-units");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[194]=C_h_intern(&lf[194],27,"\010compilercompiler-arguments");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[200]=C_h_intern(&lf[200],18,"string-intersperse");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[204]=C_h_intern(&lf[204],7,"\003sysmap");
lf[205]=C_h_intern(&lf[205],12,"string-split");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[207]=C_h_intern(&lf[207],15,"chicken-version");
lf[208]=C_h_intern(&lf[208],18,"\003sysdecode-seconds");
lf[209]=C_h_intern(&lf[209],15,"current-seconds");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[214]=C_h_intern(&lf[214],23,"\003syslambda-info->string");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[224]=C_h_intern(&lf[224],9,"make-list");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[228]=C_h_intern(&lf[228],4,"none");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[239]=C_h_intern(&lf[239],8,"toplevel");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[242]=C_h_intern(&lf[242],27,"\010compileremit-unsafe-marker");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[255]=C_h_intern(&lf[255],21,"small-parameter-limit");
lf[256]=C_h_intern(&lf[256],11,"lset-adjoin");
lf[257]=C_h_intern(&lf[257],1,"=");
lf[258]=C_h_intern(&lf[258],32,"lambda-literal-callee-signatures");
lf[259]=C_h_intern(&lf[259],24,"lambda-literal-allocated");
lf[260]=C_h_intern(&lf[260],21,"lambda-literal-direct");
lf[261]=C_h_intern(&lf[261],33,"lambda-literal-rest-argument-mode");
lf[262]=C_h_intern(&lf[262],28,"lambda-literal-rest-argument");
lf[263]=C_h_intern(&lf[263],27,"\010compilermake-variable-list");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[265]=C_h_intern(&lf[265],27,"lambda-literal-customizable");
lf[266]=C_h_intern(&lf[266],29,"lambda-literal-argument-count");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[273]=C_h_intern(&lf[273],27,"\010compilermake-argument-list");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[313]=C_h_intern(&lf[313],6,"vector");
lf[314]=C_h_intern(&lf[314],23,"lambda-literal-external");
lf[315]=C_h_intern(&lf[315],14,"\003syscopy-bytes");
lf[316]=C_h_intern(&lf[316],11,"make-string");
lf[317]=C_h_intern(&lf[317],6,"modulo");
lf[318]=C_h_intern(&lf[318],3,"fx/");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[322]=C_h_intern(&lf[322],19,"\003sysundefined-value");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[333]=C_h_intern(&lf[333],23,"\010compilerencode-literal");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[335]=C_h_intern(&lf[335],32,"\010compilerblock-variable-literal\077");
lf[336]=C_h_intern(&lf[336],20,"\010compilerbig-fixnum\077");
lf[337]=C_h_intern(&lf[337],7,"sprintf");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[339]=C_h_intern(&lf[339],25,"\010compilerwords-per-flonum");
lf[340]=C_h_intern(&lf[340],6,"reduce");
lf[341]=C_h_intern(&lf[341],1,"+");
lf[342]=C_h_intern(&lf[342],12,"vector->list");
lf[343]=C_h_intern(&lf[343],14,"\010compilerwords");
lf[344]=C_h_intern(&lf[344],15,"\003sysbytevector\077");
lf[345]=C_h_intern(&lf[345],19,"\010compilerimmediate\077");
lf[346]=C_h_intern(&lf[346],19,"lambda-literal-body");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[359]=C_h_intern(&lf[359],4,"list");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[398]=C_h_intern(&lf[398],26,"\010compilertarget-stack-size");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[401]=C_h_intern(&lf[401],30,"\010compilertarget-heap-shrinkage");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[403]=C_h_intern(&lf[403],27,"\010compilertarget-heap-growth");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[405]=C_h_intern(&lf[405],33,"\010compilertarget-initial-heap-size");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[408]=C_h_intern(&lf[408],25,"\010compilertarget-heap-size");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[412]=C_h_intern(&lf[412],40,"\010compilerdisable-stack-overflow-checking");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[418]=C_h_intern(&lf[418],4,"fold");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[421]=C_h_intern(&lf[421],28,"\010compilerinsert-timer-checks");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[426]=C_h_intern(&lf[426],14,"no-argc-checks");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[473]=C_h_intern(&lf[473],16,"\010compilercleanup");
lf[474]=C_h_intern(&lf[474],18,"\010compilerdebugging");
lf[475]=C_h_intern(&lf[475],1,"o");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[481]=C_h_intern(&lf[481],18,"\010compilerreal-name");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[483]=C_h_intern(&lf[483],25,"emit-procedure-table-info");
lf[484]=C_h_intern(&lf[484],31,"generate-foreign-callback-stubs");
lf[485]=C_h_intern(&lf[485],31,"\010compilergenerate-foreign-stubs");
lf[486]=C_h_intern(&lf[486],29,"\010compilerforeign-lambda-stubs");
lf[487]=C_h_intern(&lf[487],36,"\010compilergenerate-external-variables");
lf[488]=C_h_intern(&lf[488],27,"\010compilerexternal-variables");
lf[489]=C_h_intern(&lf[489],1,"p");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[510]=C_h_intern(&lf[510],11,"string-copy");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[512]=C_h_intern(&lf[512],13,"list-tabulate");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[515]=C_h_intern(&lf[515],41,"\010compilergenerate-foreign-callback-header");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[528]=C_h_intern(&lf[528],4,"void");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[553]=C_h_intern(&lf[553],21,"foreign-stub-callback");
lf[554]=C_h_intern(&lf[554],16,"foreign-stub-cps");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[556]=C_h_intern(&lf[556],27,"foreign-stub-argument-names");
lf[557]=C_h_intern(&lf[557],17,"foreign-stub-body");
lf[558]=C_h_intern(&lf[558],17,"foreign-stub-name");
lf[559]=C_h_intern(&lf[559],24,"foreign-stub-return-type");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[562]=C_h_intern(&lf[562],27,"foreign-stub-argument-types");
lf[563]=C_h_intern(&lf[563],19,"\010compilerreal-name2");
lf[564]=C_h_intern(&lf[564],15,"foreign-stub-id");
lf[565]=C_h_intern(&lf[565],5,"float");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[567]=C_h_intern(&lf[567],8,"c-string");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[571]=C_h_intern(&lf[571],16,"nonnull-c-string");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[574]=C_h_intern(&lf[574],3,"ref");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[576]=C_h_intern(&lf[576],5,"const");
lf[577]=C_h_intern(&lf[577],7,"pointer");
lf[578]=C_h_intern(&lf[578],9,"c-pointer");
lf[579]=C_h_intern(&lf[579],15,"nonnull-pointer");
lf[580]=C_h_intern(&lf[580],17,"nonnull-c-pointer");
lf[581]=C_h_intern(&lf[581],8,"function");
lf[582]=C_h_intern(&lf[582],8,"instance");
lf[583]=C_h_intern(&lf[583],16,"nonnull-instance");
lf[584]=C_h_intern(&lf[584],12,"instance-ref");
lf[585]=C_h_intern(&lf[585],18,"\003syshash-table-ref");
lf[586]=C_h_intern(&lf[586],27,"\010compilerforeign-type-table");
lf[587]=C_h_intern(&lf[587],17,"nonnull-c-string*");
lf[588]=C_h_intern(&lf[588],25,"nonnull-unsigned-c-string");
lf[589]=C_h_intern(&lf[589],26,"nonnull-unsigned-c-string*");
lf[590]=C_h_intern(&lf[590],6,"symbol");
lf[591]=C_h_intern(&lf[591],9,"c-string*");
lf[592]=C_h_intern(&lf[592],17,"unsigned-c-string");
lf[593]=C_h_intern(&lf[593],18,"unsigned-c-string*");
lf[594]=C_h_intern(&lf[594],6,"double");
lf[595]=C_h_intern(&lf[595],16,"unsigned-integer");
lf[596]=C_h_intern(&lf[596],18,"unsigned-integer32");
lf[597]=C_h_intern(&lf[597],4,"long");
lf[598]=C_h_intern(&lf[598],7,"integer");
lf[599]=C_h_intern(&lf[599],9,"integer32");
lf[600]=C_h_intern(&lf[600],13,"unsigned-long");
lf[601]=C_h_intern(&lf[601],6,"number");
lf[602]=C_h_intern(&lf[602],9,"integer64");
lf[603]=C_h_intern(&lf[603],13,"c-string-list");
lf[604]=C_h_intern(&lf[604],14,"c-string-list*");
lf[605]=C_h_intern(&lf[605],3,"int");
lf[606]=C_h_intern(&lf[606],5,"int32");
lf[607]=C_h_intern(&lf[607],5,"short");
lf[608]=C_h_intern(&lf[608],14,"unsigned-short");
lf[609]=C_h_intern(&lf[609],13,"scheme-object");
lf[610]=C_h_intern(&lf[610],13,"unsigned-char");
lf[611]=C_h_intern(&lf[611],12,"unsigned-int");
lf[612]=C_h_intern(&lf[612],14,"unsigned-int32");
lf[613]=C_h_intern(&lf[613],4,"byte");
lf[614]=C_h_intern(&lf[614],13,"unsigned-byte");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[625]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[626]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[627]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[630]=C_h_intern(&lf[630],36,"foreign-callback-stub-argument-types");
lf[631]=C_h_intern(&lf[631],33,"foreign-callback-stub-return-type");
lf[632]=C_h_intern(&lf[632],24,"foreign-callback-stub-id");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[635]=C_h_intern(&lf[635],32,"foreign-callback-stub-qualifiers");
lf[636]=C_h_intern(&lf[636],26,"foreign-callback-stub-name");
lf[637]=C_h_intern(&lf[637],4,"quit");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[652]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[653]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[657]=C_h_intern(&lf[657],11,"byte-vector");
lf[658]=C_h_intern(&lf[658],19,"nonnull-byte-vector");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[660]=C_h_intern(&lf[660],4,"blob");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[662]=C_h_intern(&lf[662],9,"u16vector");
lf[663]=C_h_intern(&lf[663],17,"nonnull-u16vector");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[665]=C_h_intern(&lf[665],8,"s8vector");
lf[666]=C_h_intern(&lf[666],16,"nonnull-s8vector");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[668]=C_h_intern(&lf[668],9,"u32vector");
lf[669]=C_h_intern(&lf[669],17,"nonnull-u32vector");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[671]=C_h_intern(&lf[671],9,"s16vector");
lf[672]=C_h_intern(&lf[672],17,"nonnull-s16vector");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[674]=C_h_intern(&lf[674],9,"s32vector");
lf[675]=C_h_intern(&lf[675],17,"nonnull-s32vector");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[677]=C_h_intern(&lf[677],9,"f32vector");
lf[678]=C_h_intern(&lf[678],17,"nonnull-f32vector");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[680]=C_h_intern(&lf[680],9,"f64vector");
lf[681]=C_h_intern(&lf[681],17,"nonnull-f64vector");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[683]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[705]=C_h_intern(&lf[705],3,"...");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[710]=C_h_intern(&lf[710],9,"\003syserror");
lf[711]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[712]=C_h_intern(&lf[712],4,"enum");
lf[713]=C_h_intern(&lf[713],5,"union");
lf[714]=C_h_intern(&lf[714],6,"struct");
lf[715]=C_h_intern(&lf[715],8,"template");
lf[716]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[717]=C_h_intern(&lf[717],12,"nonnull-blob");
lf[718]=C_h_intern(&lf[718],8,"u8vector");
lf[719]=C_h_intern(&lf[719],16,"nonnull-u8vector");
lf[720]=C_h_intern(&lf[720],14,"scheme-pointer");
lf[721]=C_h_intern(&lf[721],22,"nonnull-scheme-pointer");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[816]=C_h_intern(&lf[816],17,"\003sysstring-append");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[818]=C_h_intern(&lf[818],5,"cons*");
lf[819]=C_h_intern(&lf[819],29,"\010compilerstring->c-identifier");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[821]=C_h_intern(&lf[821],6,"random");
C_register_lf2(lf,822,create_ptable());
t2=C_mutate(&lf[0] /* c2057 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2428,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k2426 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2429 in k2426 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2432 in k2429 in k2426 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=C_set_block_item(lf[2] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[3]+1 /* gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2446,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[7]+1 /* gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2467,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9055,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9059,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 100  random");
t8=C_retrieve(lf[821]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix(16777216));}

/* k9057 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_9059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9063,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 100  current-seconds");
t3=C_retrieve(lf[209]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9061 in k9057 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 100  sprintf");
t2=C_retrieve(lf[337]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[820],((C_word*)t0)[2],t1);}

/* k9053 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_9055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 99   string->c-identifier");
t2=C_retrieve(lf[819]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2485,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[10]+1 /* generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2487,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[483]+1 /* emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6063,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[473]+1 /* cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6136,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[263]+1 /* make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6225,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[273]+1 /* make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6241,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[487]+1 /* generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6257,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[183]+1 /* generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6289,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[485]+1 /* generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6307,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[484]+1 /* generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6540,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[515]+1 /* generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6971,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[156]+1 /* foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7036,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[155]+1 /* foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7872,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[150]+1 /* foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8357,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[333]+1 /* encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8755,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[51],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8755,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8758,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8761,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8764,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8817,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t7)){
t8=t6;
f_8817(2,t8,lf[803]);}
else{
t8=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t8)){
t9=t6;
f_8817(2,t9,lf[804]);}
else{
if(C_truep((C_word)C_charp(t2))){
t9=(C_word)C_fix((C_word)C_character_code(t2));
t10=f_8764(C_a_i(&a,4),t9);
C_trace("c-backend.scm: 1381 string-append");
t11=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[805],t10);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t9=t6;
f_8817(2,t9,lf[806]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t9=t6;
f_8817(2,t9,lf[807]);}
else{
t9=C_retrieve(lf[322]);
t10=(C_word)C_eqp(t9,t2);
if(C_truep(t10)){
t11=t6;
f_8817(2,t11,lf[808]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8935,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1386 big-fixnum?");
t12=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8948,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1395 number->string");
C_number_to_string(3,0,t11,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t11=(C_word)C_slot(t2,C_fix(1));
t12=(C_word)C_i_string_length(t11);
t13=f_8764(C_a_i(&a,4),t12);
C_trace("c-backend.scm: 1398 string-append");
t14=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t6,lf[814],t13,t11);}
else{
if(C_truep((C_word)C_immp(t2))){
C_trace("c-backend.scm: 1403 bomb");
t11=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[815],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8987,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t12=f_8758(t2);
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_string(&a,1,t13);
t15=f_8761(t2);
t16=f_8764(C_a_i(&a,4),t15);
C_trace("c-backend.scm: 1406 string-append");
t17=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,t11,t14,t16);}
else{
t11=f_8761(t2);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9017,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=f_8758(t2);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8764(C_a_i(&a,4),t11);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9029,a[2]=t16,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1416 list-tabulate");
t19=C_retrieve(lf[512]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t11,t18);}}}}}}}}}}}}

/* a9030 in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9031,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
C_trace("c-backend.scm: 1416 encode-literal");
t4=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k9027 in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_9029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1413 cons*");
t2=C_retrieve(lf[818]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9015 in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_9017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1412 string-intersperse");
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[817]);}

/* k8985 in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1405 ##sys#string-append");
t2=C_retrieve(lf[816]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8946 in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1395 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[812],t1,lf[813]);}

/* k8933 in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8935,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8931,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1393 number->string");
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
C_trace("c-backend.scm: 1387 string-append");
t14=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[3],lf[811],t13);}}

/* k8929 in k8933 in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1393 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[809],t1,lf[810]);}

/* k8815 in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8817,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
C_trace("c-backend.scm: 1377 string-append");
t4=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static C_word C_fcall f_8764(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* getsize in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static C_word C_fcall f_8761(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub2372(C_SCHEME_UNDEFINED,t1));}

/* getbits in ##compiler#encode-literal in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static C_word C_fcall f_8758(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub2367(C_SCHEME_UNDEFINED,t1));}

/* ##compiler#foreign-result-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8357(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8357,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8359,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[22]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[610]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[777]);}
else{
t8=(C_word)C_eqp(t5,lf[605]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[606]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[778]);}
else{
t10=(C_word)C_eqp(t5,lf[611]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[612]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[779]);}
else{
t12=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[780]);}
else{
t13=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[781]);}
else{
t14=(C_word)C_eqp(t5,lf[613]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[782]);}
else{
t15=(C_word)C_eqp(t5,lf[614]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[783]);}
else{
t16=(C_word)C_eqp(t5,lf[565]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[594]));
if(C_truep(t17)){
C_trace("c-backend.scm: 1315 sprintf");
t18=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[784],t3);}
else{
t18=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t18)){
C_trace("c-backend.scm: 1316 sprintf");
t19=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[785],t3);}
else{
t19=(C_word)C_eqp(t5,lf[571]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8444,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8444(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[567]);
if(C_truep(t21)){
t22=t20;
f_8444(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[580]);
if(C_truep(t22)){
t23=t20;
f_8444(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[591]);
if(C_truep(t23)){
t24=t20;
f_8444(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[587]);
if(C_truep(t24)){
t25=t20;
f_8444(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[592]);
if(C_truep(t25)){
t26=t20;
f_8444(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[593]);
if(C_truep(t26)){
t27=t20;
f_8444(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t27)){
t28=t20;
f_8444(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[589]);
if(C_truep(t28)){
t29=t20;
f_8444(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[590]);
if(C_truep(t29)){
t30=t20;
f_8444(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[603]);
t31=t20;
f_8444(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[604])));}}}}}}}}}}}}}}}}}}}}

/* k8442 in ##compiler#foreign-result-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_8444(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8444,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1320 sprintf");
t2=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[786],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[578]);
if(C_truep(t2)){
C_trace("c-backend.scm: 1321 sprintf");
t3=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[787],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[598]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[599]));
if(C_truep(t4)){
C_trace("c-backend.scm: 1322 sprintf");
t5=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[788],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t5)){
C_trace("c-backend.scm: 1323 sprintf");
t6=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[789],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[596]));
if(C_truep(t7)){
C_trace("c-backend.scm: 1324 sprintf");
t8=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[790],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t8)){
C_trace("c-backend.scm: 1325 sprintf");
t9=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[791],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t9)){
C_trace("c-backend.scm: 1326 sprintf");
t10=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[792],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[19]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[793]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[528]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[609]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[794]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 1330 ##sys#hash-table-ref");
t14=C_retrieve(lf[585]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[586]),((C_word*)t0)[3]);}
else{
t14=t13;
f_8525(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k8523 in k8442 in ##compiler#foreign-result-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8525,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
C_trace("c-backend.scm: 1332 foreign-result-conversion");
t4=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8547(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8547(t3,C_SCHEME_FALSE);}}}

/* k8545 in k8523 in k8442 in ##compiler#foreign-result-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_8547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[579]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[580]));
if(C_truep(t4)){
C_trace("c-backend.scm: 1336 sprintf");
t5=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],lf[795],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t5)){
C_trace("c-backend.scm: 1338 sprintf");
t6=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[4],lf[796],((C_word*)t0)[3]);}
else{
t6=(C_word)C_eqp(t2,lf[582]);
if(C_truep(t6)){
C_trace("c-backend.scm: 1340 sprintf");
t7=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[4],lf[797],((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(t2,lf[583]);
if(C_truep(t7)){
C_trace("c-backend.scm: 1342 sprintf");
t8=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[4],lf[798],((C_word*)t0)[3]);}
else{
t8=(C_word)C_eqp(t2,lf[584]);
if(C_truep(t8)){
C_trace("c-backend.scm: 1344 sprintf");
t9=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[4],lf[799],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("c-backend.scm: 1345 foreign-result-conversion");
t11=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t11))(4,t11,((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(t2,lf[577]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[578]));
if(C_truep(t11)){
C_trace("c-backend.scm: 1347 sprintf");
t12=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[4],lf[800],((C_word*)t0)[3]);}
else{
t12=(C_word)C_eqp(t2,lf[581]);
if(C_truep(t12)){
C_trace("c-backend.scm: 1348 sprintf");
t13=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t13))(4,t13,((C_word*)t0)[4],lf[801],((C_word*)t0)[3]);}
else{
t13=(C_word)C_eqp(t2,lf[712]);
if(C_truep(t13)){
C_trace("c-backend.scm: 1349 sprintf");
t14=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[4],lf[802],((C_word*)t0)[3]);}
else{
C_trace("c-backend.scm: 1350 err");
t14=((C_word*)t0)[2];
f_8359(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
C_trace("c-backend.scm: 1351 err");
t2=((C_word*)t0)[2];
f_8359(t2,((C_word*)t0)[4]);}}

/* err in ##compiler#foreign-result-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_8359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8359,NULL,2,t0,t1);}
C_trace("c-backend.scm: 1306 quit");
t2=C_retrieve(lf[637]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[776],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7872,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7874,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[609]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[723]);}
else{
t6=(C_word)C_eqp(t4,lf[22]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[610]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[724]);}
else{
t8=(C_word)C_eqp(t4,lf[613]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7902,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_7902(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[605]);
if(C_truep(t10)){
t11=t9;
f_7902(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[611]);
if(C_truep(t11)){
t12=t9;
f_7902(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[612]);
t13=t9;
f_7902(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[614])));}}}}}}

/* k7900 in ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7902,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[725]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[607]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[726]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[727]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[728]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[594]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_7929(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[601]);
t8=t6;
f_7929(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[565])));}}}}}}

/* k7927 in k7900 in ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7929,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[729]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[598]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[599]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[730]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[731]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[732]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[596]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[733]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[577]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[734]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[579]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[735]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[720]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[736]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[721]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[737]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[578]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[738]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[580]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[739]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[660]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[740]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[717]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[741]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[657]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[742]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[743]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[718]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[744]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[719]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[745]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[662]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[746]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[663]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[747]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[668]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[748]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[669]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[749]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[665]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[750]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[666]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[751]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[671]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[752]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[753]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[674]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[754]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[755]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[677]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[756]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[678]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[757]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[680]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[758]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[681]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[759]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[567]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8124(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[591]);
if(C_truep(t36)){
t37=t35;
f_8124(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
t38=t35;
f_8124(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[593])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8122 in k7927 in k7900 in ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_8124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8124,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[760]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[571]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8133(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
if(C_truep(t4)){
t5=t3;
f_8133(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
if(C_truep(t5)){
t6=t3;
f_8133(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t7=t3;
f_8133(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[590])));}}}}}

/* k8131 in k8122 in k7927 in k7900 in ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_8133(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8133,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[761]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[19]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[762]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 1279 ##sys#hash-table-ref");
t4=C_retrieve(lf[585]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[586]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8142(2,t4,C_SCHEME_FALSE);}}}}

/* k8140 in k8131 in k8122 in k7927 in k7900 in ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8142,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
C_trace("c-backend.scm: 1281 foreign-argument-conversion");
t4=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8164(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8164(t3,C_SCHEME_FALSE);}}}

/* k8162 in k8140 in k8131 in k8122 in k7927 in k7900 in ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_8164(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8164,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[763]);}
else{
t4=(C_word)C_eqp(t2,lf[579]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[764]);}
else{
t5=(C_word)C_eqp(t2,lf[578]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[765]);}
else{
t6=(C_word)C_eqp(t2,lf[580]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[766]);}
else{
t7=(C_word)C_eqp(t2,lf[582]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[767]);}
else{
t8=(C_word)C_eqp(t2,lf[583]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[768]);}
else{
t9=(C_word)C_eqp(t2,lf[581]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[769]);}
else{
t10=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1292 foreign-argument-conversion");
t12=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t12))(3,t12,((C_word*)t0)[3],t11);}
else{
t11=(C_word)C_eqp(t2,lf[712]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[770]);}
else{
t12=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8241,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1295 foreign-type-declaration");
t15=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,lf[773]);}
else{
t13=(C_word)C_eqp(t2,lf[584]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1298 string-append");
t15=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,((C_word*)t0)[3],lf[774],t14,lf[775]);}
else{
C_trace("c-backend.scm: 1299 err");
t14=((C_word*)t0)[2];
f_7874(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
C_trace("c-backend.scm: 1300 err");
t2=((C_word*)t0)[2];
f_7874(t2,((C_word*)t0)[3]);}}

/* k8239 in k8162 in k8140 in k8131 in k8122 in k7927 in k7900 in ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1295 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[771],t1,lf[772]);}

/* err in ##compiler#foreign-argument-conversion in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7874,NULL,2,t0,t1);}
C_trace("c-backend.scm: 1233 quit");
t2=C_retrieve(lf[637]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[722],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7036,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7038,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7043,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[609]);
if(C_truep(t7)){
C_trace("c-backend.scm: 1141 str");
t8=t5;
f_7043(t8,t1,lf[640]);}
else{
t8=(C_word)C_eqp(t6,lf[22]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[613]));
if(C_truep(t9)){
C_trace("c-backend.scm: 1142 str");
t10=t5;
f_7043(t10,t1,lf[641]);}
else{
t10=(C_word)C_eqp(t6,lf[610]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[614]));
if(C_truep(t11)){
C_trace("c-backend.scm: 1143 str");
t12=t5;
f_7043(t12,t1,lf[642]);}
else{
t12=(C_word)C_eqp(t6,lf[611]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[595]));
if(C_truep(t13)){
C_trace("c-backend.scm: 1144 str");
t14=t5;
f_7043(t14,t1,lf[643]);}
else{
t14=(C_word)C_eqp(t6,lf[612]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[596]));
if(C_truep(t15)){
C_trace("c-backend.scm: 1145 str");
t16=t5;
f_7043(t16,t1,lf[644]);}
else{
t16=(C_word)C_eqp(t6,lf[605]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7113,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7113(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[598]);
t19=t17;
f_7113(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[19])));}}}}}}}

/* k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7113(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7113,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1146 str");
t2=((C_word*)t0)[7];
f_7043(t2,((C_word*)t0)[6],lf[645]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[606]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[599]));
if(C_truep(t3)){
C_trace("c-backend.scm: 1147 str");
t4=((C_word*)t0)[7];
f_7043(t4,((C_word*)t0)[6],lf[646]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t4)){
C_trace("c-backend.scm: 1148 str");
t5=((C_word*)t0)[7];
f_7043(t5,((C_word*)t0)[6],lf[647]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[607]);
if(C_truep(t5)){
C_trace("c-backend.scm: 1149 str");
t6=((C_word*)t0)[7];
f_7043(t6,((C_word*)t0)[6],lf[648]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t6)){
C_trace("c-backend.scm: 1150 str");
t7=((C_word*)t0)[7];
f_7043(t7,((C_word*)t0)[6],lf[649]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t7)){
C_trace("c-backend.scm: 1151 str");
t8=((C_word*)t0)[7];
f_7043(t8,((C_word*)t0)[6],lf[650]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[600]);
if(C_truep(t8)){
C_trace("c-backend.scm: 1152 str");
t9=((C_word*)t0)[7];
f_7043(t9,((C_word*)t0)[6],lf[651]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[565]);
if(C_truep(t9)){
C_trace("c-backend.scm: 1153 str");
t10=((C_word*)t0)[7];
f_7043(t10,((C_word*)t0)[6],lf[652]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[601]));
if(C_truep(t11)){
C_trace("c-backend.scm: 1154 str");
t12=((C_word*)t0)[7];
f_7043(t12,((C_word*)t0)[6],lf[653]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[577]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[579]));
if(C_truep(t13)){
C_trace("c-backend.scm: 1156 str");
t14=((C_word*)t0)[7];
f_7043(t14,((C_word*)t0)[6],lf[654]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[578]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7215(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[580]);
if(C_truep(t16)){
t17=t15;
f_7215(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[720]);
t18=t15;
f_7215(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[721])));}}}}}}}}}}}}}

/* k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7215,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1157 str");
t2=((C_word*)t0)[7];
f_7043(t2,((C_word*)t0)[6],lf[655]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[604]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[656]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[657]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[658]));
if(C_truep(t5)){
C_trace("c-backend.scm: 1160 str");
t6=((C_word*)t0)[7];
f_7043(t6,((C_word*)t0)[6],lf[659]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[660]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7248(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[717]);
if(C_truep(t8)){
t9=t7;
f_7248(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[718]);
t10=t7;
f_7248(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[719])));}}}}}}

/* k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7248,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1161 str");
t2=((C_word*)t0)[7];
f_7043(t2,((C_word*)t0)[6],lf[661]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[662]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[663]));
if(C_truep(t3)){
C_trace("c-backend.scm: 1162 str");
t4=((C_word*)t0)[7];
f_7043(t4,((C_word*)t0)[6],lf[664]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[665]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[666]));
if(C_truep(t5)){
C_trace("c-backend.scm: 1163 str");
t6=((C_word*)t0)[7];
f_7043(t6,((C_word*)t0)[6],lf[667]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[668]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[669]));
if(C_truep(t7)){
C_trace("c-backend.scm: 1164 str");
t8=((C_word*)t0)[7];
f_7043(t8,((C_word*)t0)[6],lf[670]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[671]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[672]));
if(C_truep(t9)){
C_trace("c-backend.scm: 1165 str");
t10=((C_word*)t0)[7];
f_7043(t10,((C_word*)t0)[6],lf[673]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[674]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[675]));
if(C_truep(t11)){
C_trace("c-backend.scm: 1166 str");
t12=((C_word*)t0)[7];
f_7043(t12,((C_word*)t0)[6],lf[676]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[677]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[678]));
if(C_truep(t13)){
C_trace("c-backend.scm: 1167 str");
t14=((C_word*)t0)[7];
f_7043(t14,((C_word*)t0)[6],lf[679]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[680]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[681]));
if(C_truep(t15)){
C_trace("c-backend.scm: 1168 str");
t16=((C_word*)t0)[7];
f_7043(t16,((C_word*)t0)[6],lf[682]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7344(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[567]);
if(C_truep(t18)){
t19=t17;
f_7344(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t19)){
t20=t17;
f_7344(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t20)){
t21=t17;
f_7344(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
if(C_truep(t21)){
t22=t17;
f_7344(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t22)){
t23=t17;
f_7344(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
t24=t17;
f_7344(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[590])));}}}}}}}}}}}}}}}

/* k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7344,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1171 str");
t2=((C_word*)t0)[7];
f_7043(t2,((C_word*)t0)[6],lf[683]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[528]);
if(C_truep(t2)){
C_trace("c-backend.scm: 1172 str");
t3=((C_word*)t0)[7];
f_7043(t3,((C_word*)t0)[6],lf[684]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 1174 ##sys#hash-table-ref");
t4=C_retrieve(lf[585]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[586]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7359(2,t4,C_SCHEME_FALSE);}}}}

/* k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7359,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
C_trace("c-backend.scm: 1176 foreign-type-declaration");
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
C_trace("c-backend.scm: 1177 str");
t2=((C_word*)t0)[3];
f_7043(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7399,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_7399(t6,(C_word)C_i_memq(t5,lf[716]));}
else{
t5=t3;
f_7399(t5,C_SCHEME_FALSE);}}
else{
C_trace("c-backend.scm: 1227 err");
t2=((C_word*)t0)[2];
f_7038(t2,((C_word*)t0)[6]);}}}}

/* k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7399,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7410,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1184 string-append");
t4=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[685],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=t2;
f_7416(t5,(C_word)C_eqp(lf[574],t4));}
else{
t4=t2;
f_7416(t4,C_SCHEME_FALSE);}}}

/* k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7416,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7427,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1187 string-append");
t4=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[686],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7433(t4,(C_word)C_eqp(lf[715],t3));}
else{
t3=t2;
f_7433(t3,C_SCHEME_FALSE);}}}

/* k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7433(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7433,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7440,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7444,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("c-backend.scm: 1192 foreign-type-declaration");
t5=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[691]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7472(t5,(C_word)C_eqp(lf[576],t4));}
else{
t4=t2;
f_7472(t4,C_SCHEME_FALSE);}}}

/* k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7472(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7472,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
C_trace("c-backend.scm: 1199 foreign-type-declaration");
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7489(t5,(C_word)C_eqp(lf[714],t4));}
else{
t4=t2;
f_7489(t4,C_SCHEME_FALSE);}}}

/* k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7489,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7496,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1201 ->string");
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7506(t5,(C_word)C_eqp(lf[713],t4));}
else{
t4=t2;
f_7506(t4,C_SCHEME_FALSE);}}}

/* k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7506,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7513,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1203 ->string");
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7523(t5,(C_word)C_eqp(lf[712],t4));}
else{
t4=t2;
f_7523(t4,C_SCHEME_FALSE);}}}

/* k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7523,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7530,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1205 ->string");
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7540(t5,(C_word)C_i_memq(t4,lf[711]));}
else{
t4=t2;
f_7540(t4,C_SCHEME_FALSE);}}}

/* k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7540,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7547,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1207 ->string");
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7557(t5,(C_word)C_eqp(lf[584],t4));}
else{
t4=t2;
f_7557(t4,C_SCHEME_FALSE);}}}

/* k7555 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7557,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1209 ->string");
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7574(t4,(C_word)C_eqp(lf[581],t3));}
else{
t3=t2;
f_7574(t3,C_SCHEME_FALSE);}}}

/* k7572 in k7555 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7574,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7586,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7586(2,t6,lf[709]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7586(2,t7,(C_word)C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[710]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[1],t4);}}}
else{
C_trace("c-backend.scm: 1226 err");
t2=((C_word*)t0)[2];
f_7038(t2,((C_word*)t0)[4]);}}

/* k7584 in k7572 in k7555 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1215 foreign-type-declaration");
t3=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[708]);}

/* k7591 in k7584 in k7572 in k7555 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7597,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7601,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7603,tmp=(C_word)a,a+=2,tmp);
C_trace("map");
t5=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7602 in k7591 in k7584 in k7572 in k7555 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7603,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[705],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[706]);}
else{
C_trace("c-backend.scm: 1222 foreign-type-declaration");
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[707]);}}

/* k7599 in k7591 in k7584 in k7572 in k7555 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1218 string-intersperse");
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[704]);}

/* k7595 in k7591 in k7584 in k7572 in k7555 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1214 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[701],((C_word*)t0)[2],lf[702],t1,lf[703]);}

/* k7562 in k7555 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1209 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[700],((C_word*)t0)[2]);}

/* k7545 in k7538 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1207 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[699],((C_word*)t0)[2]);}

/* k7528 in k7521 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1205 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[697],t1,lf[698],((C_word*)t0)[2]);}

/* k7511 in k7504 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1203 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[695],t1,lf[696],((C_word*)t0)[2]);}

/* k7494 in k7487 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1201 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[693],t1,lf[694],((C_word*)t0)[2]);}

/* k7477 in k7470 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1199 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[692],t1);}

/* k7442 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7448,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7452,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7454,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
C_trace("map");
t6=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7453 in k7442 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7454,3,t0,t1,t2);}
C_trace("##compiler#foreign-type-declaration");
t3=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[690]);}

/* k7450 in k7442 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1194 string-intersperse");
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[689]);}

/* k7446 in k7442 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1191 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[687],t1,lf[688]);}

/* k7438 in k7431 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1190 str");
t2=((C_word*)t0)[3];
f_7043(t2,((C_word*)t0)[2],t1);}

/* k7425 in k7414 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1187 foreign-type-declaration");
t2=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7408 in k7397 in k7357 in k7342 in k7246 in k7213 in k7111 in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1184 foreign-type-declaration");
t2=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* str in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7043(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7043,NULL,3,t0,t1,t2);}
C_trace("c-backend.scm: 1139 string-append");
t3=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[639],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_7038(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7038,NULL,2,t0,t1);}
C_trace("c-backend.scm: 1138 quit");
t2=C_retrieve(lf[637]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[638],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6971,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6975,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1120 foreign-callback-stub-name");
t5=C_retrieve(lf[636]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6978,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1121 foreign-callback-stub-qualifiers");
t3=C_retrieve(lf[635]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1122 foreign-callback-stub-return-type");
t3=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6984,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1123 foreign-callback-stub-argument-types");
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6982 in k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6984,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 1125 make-argument-list");
t4=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[634]);}

/* k6988 in k6982 in k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6993,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1126 foreign-type-declaration");
t4=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[633]);}

/* k7032 in k6988 in k6982 in k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1126 gen");
t2=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k6991 in k6988 in k6982 in k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6996,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7001,tmp=(C_word)a,a+=2,tmp);
C_trace("c-backend.scm: 1127 pair-for-each");
t4=C_retrieve(lf[179]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7000 in k6991 in k6988 in k6982 in k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7001,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7005,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7022,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
C_trace("c-backend.scm: 1129 foreign-type-declaration");
t8=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k7020 in a7000 in k6991 in k6988 in k6982 in k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1129 gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7003 in a7000 in k6991 in k6988 in k6982 in k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_7005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
C_trace("c-backend.scm: 1130 gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6994 in k6991 in k6988 in k6982 in k6979 in k6976 in k6973 in ##compiler#generate-foreign-callback-header in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1132 gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6540(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6540,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6546,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6546,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1067 foreign-callback-stub-id");
t4=C_retrieve(lf[632]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1068 real-name2");
t3=C_retrieve(lf[563]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6556,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1069 foreign-callback-stub-return-type");
t3=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1070 foreign-callback-stub-argument-types");
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6559,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 1072 make-argument-list");
t4=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[629]);}

/* k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6567,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 1099 fold");
t6=C_retrieve(lf[418]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[628],((C_word*)t0)[4],t1);}

/* k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 1100 gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6969,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1102 cleanup");
t4=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6912(2,t3,C_SCHEME_UNDEFINED);}}

/* k6967 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1102 gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[626],t1,lf[627]);}

/* k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 1103 generate-foreign-callback-header");
t3=C_retrieve(lf[515]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[625],((C_word*)t0)[2]);}

/* k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6918,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 1104 gen");
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[623],((C_word*)t0)[2],lf[624]);}

/* k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 1105 gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[622]);}

/* k6919 in k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6954,tmp=(C_word)a,a+=2,tmp);
C_trace("c-backend.scm: 1106 for-each");
t4=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6953 in k6919 in k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6954,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6962,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1108 foreign-result-conversion");
t5=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[621]);}

/* k6960 in a6953 in k6919 in k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1108 gen");
t2=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[618],t1,((C_word*)t0)[2],lf[619],C_SCHEME_TRUE,lf[620]);}

/* k6922 in k6919 in k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[528],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_6927(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6952,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1113 foreign-argument-conversion");
t5=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k6950 in k6922 in k6919 in k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1113 gen");
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[617],t1);}

/* k6925 in k6922 in k6919 in k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 1114 gen");
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[616],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k6928 in k6925 in k6922 in k6919 in k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[528],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_6933(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 1115 gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k6931 in k6928 in k6925 in k6922 in k6919 in k6916 in k6913 in k6910 in k6907 in k6904 in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1116 gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[615]);}

/* compute-size in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6567(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6567,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[22]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6577,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6577(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t8)){
t9=t7;
f_6577(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t9)){
t10=t7;
f_6577(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t10)){
t11=t7;
f_6577(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[19]);
if(C_truep(t11)){
t12=t7;
f_6577(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[528]);
if(C_truep(t12)){
t13=t7;
f_6577(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t13)){
t14=t7;
f_6577(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t14)){
t15=t7;
f_6577(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[610]);
if(C_truep(t15)){
t16=t7;
f_6577(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[611]);
if(C_truep(t16)){
t17=t7;
f_6577(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[612]);
if(C_truep(t17)){
t18=t7;
f_6577(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[613]);
t19=t7;
f_6577(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[614])));}}}}}}}}}}}}

/* k6575 in compute-size in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6577,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[565]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6586(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t4)){
t5=t3;
f_6586(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[578]);
if(C_truep(t5)){
t6=t3;
f_6586(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t6)){
t7=t3;
f_6586(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t7)){
t8=t3;
f_6586(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t8)){
t9=t3;
f_6586(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
if(C_truep(t9)){
t10=t3;
f_6586(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[599]);
if(C_truep(t10)){
t11=t3;
f_6586(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[600]);
if(C_truep(t11)){
t12=t3;
f_6586(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[580]);
if(C_truep(t12)){
t13=t3;
f_6586(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
if(C_truep(t13)){
t14=t3;
f_6586(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t14)){
t15=t3;
f_6586(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
t16=t3;
f_6586(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[604])));}}}}}}}}}}}}}}

/* k6584 in k6575 in compute-size in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6586,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1081 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[566]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[567]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6598(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t4)){
t5=t3;
f_6598(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t5)){
t6=t3;
f_6598(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
t7=t3;
f_6598(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[593])));}}}}}

/* k6596 in k6584 in k6575 in compute-size in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6598,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1083 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[568],((C_word*)t0)[5],lf[569],((C_word*)t0)[5],lf[570]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[571]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6610(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
if(C_truep(t4)){
t5=t3;
f_6610(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
if(C_truep(t5)){
t6=t3;
f_6610(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t7=t3;
f_6610(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[590])));}}}}}

/* k6608 in k6596 in k6584 in k6575 in compute-size in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6610,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 1085 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[572],((C_word*)t0)[4],lf[573]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
C_trace("c-backend.scm: 1087 ##sys#hash-table-ref");
t3=C_retrieve(lf[585]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[586]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6616(2,t3,C_SCHEME_FALSE);}}}

/* k6614 in k6608 in k6596 in k6584 in k6575 in compute-size in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6616,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
C_trace("c-backend.scm: 1089 compute-size");
t4=((C_word*)((C_word*)t0)[6])[1];
f_6567(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[574]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6650,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6650(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t5)){
t6=t4;
f_6650(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[578]);
if(C_truep(t6)){
t7=t4;
f_6650(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[579]);
if(C_truep(t7)){
t8=t4;
f_6650(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[580]);
if(C_truep(t8)){
t9=t4;
f_6650(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[581]);
if(C_truep(t9)){
t10=t4;
f_6650(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[582]);
if(C_truep(t10)){
t11=t4;
f_6650(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[583]);
t12=t4;
f_6650(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[584])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6648 in k6614 in k6608 in k6596 in k6584 in k6575 in compute-size in k6563 in k6557 in k6554 in k6551 in k6548 in a6545 in generate-foreign-callback-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
C_trace("c-backend.scm: 1094 string-append");
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[575]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[576]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 1095 compute-size");
t4=((C_word*)((C_word*)t0)[3])[1];
f_6567(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6307,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6313,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6313(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6313,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1000 foreign-stub-id");
t4=C_retrieve(lf[564]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6320,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1001 real-name2");
t3=C_retrieve(lf[563]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6323,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1002 foreign-stub-argument-types");
t3=C_retrieve(lf[562]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6323,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6538,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1004 make-variable-list");
t5=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[561]);}

/* k6536 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6538,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[560],t1);
C_trace("c-backend.scm: 1004 intersperse");
t3=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 1005 foreign-stub-return-type");
t3=C_retrieve(lf[559]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 1006 foreign-stub-name");
t3=C_retrieve(lf[558]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 1007 foreign-stub-body");
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 1008 foreign-stub-argument-names");
t3=C_retrieve(lf[556]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_6344(2,t3,t1);}
else{
C_trace("c-backend.scm: 1008 make-list");
t3=C_retrieve(lf[224]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 1009 foreign-result-conversion");
t3=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[555]);}

/* k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
C_trace("c-backend.scm: 1010 foreign-stub-cps");
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_trace("c-backend.scm: 1011 foreign-stub-callback");
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
C_trace("c-backend.scm: 1012 gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1014 cleanup");
t4=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6359(2,t3,C_SCHEME_UNDEFINED);}}

/* k6525 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1014 gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[551],t1,lf[552]);}

/* k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
C_trace("c-backend.scm: 1016 gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[549],((C_word*)t0)[6],lf[550]);}
else{
t3=t2;
f_6362(2,t3,C_SCHEME_UNDEFINED);}}

/* k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
C_trace("c-backend.scm: 1019 gen");
t3=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[544],((C_word*)t0)[2],lf[545],C_SCHEME_TRUE,lf[546],((C_word*)t0)[2],lf[547]);}
else{
C_trace("c-backend.scm: 1021 gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[548],((C_word*)t0)[2],C_make_character(40));}}

/* k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[3]);}

/* k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
C_trace("c-backend.scm: 1024 gen");
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[539],C_SCHEME_TRUE,lf[540],((C_word*)t0)[2],lf[541]);}
else{
C_trace("c-backend.scm: 1025 gen");
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[542],C_SCHEME_TRUE,lf[543],((C_word*)t0)[2],C_make_character(40));}}

/* k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 1027 gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[538]);}

/* k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 1028 gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[537]);}

/* k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6383,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6475,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1037 iota");
t5=C_retrieve(lf[66]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k6503 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1029 for-each");
t2=*((C_word*)lf[65]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6474 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6475,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6483,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6495,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
C_trace("c-backend.scm: 1034 symbol->string");
t7=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
C_trace("c-backend.scm: 1034 sprintf");
t7=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[536],t3);}}

/* k6493 in a6474 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1032 foreign-type-declaration");
t2=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6481 in a6474 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1035 foreign-type-declaration");
t3=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[535]);}

/* k6485 in k6481 in a6474 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 1036 foreign-argument-conversion");
t3=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6489 in k6485 in k6481 in a6474 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1031 gen");
t2=*((C_word*)lf[3]+1);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[532],((C_word*)t0)[3],C_make_character(41),t1,lf[533],((C_word*)t0)[2],lf[534]);}

/* k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("c-backend.scm: 1038 gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[531]);}
else{
t3=t2;
f_6386(2,t3,C_SCHEME_UNDEFINED);}}

/* k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6395,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1040 gen");
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[522]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[528]);
if(C_truep(t4)){
C_trace("c-backend.scm: 1051 gen");
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
C_trace("c-backend.scm: 1050 gen");
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[530],((C_word*)t0)[2]);}}}

/* k6414 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 1052 gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k6417 in k6414 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6453,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6457,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 1053 make-argument-list");
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[529]);}

/* k6455 in k6417 in k6414 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1053 intersperse");
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k6451 in k6417 in k6414 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k6420 in k6417 in k6414 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6425,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[528]);
if(C_truep(t3)){
t4=t2;
f_6425(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 1054 gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k6423 in k6420 in k6417 in k6414 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1055 gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[527]);}

/* k6426 in k6423 in k6420 in k6417 in k6414 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 1057 gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[523],C_SCHEME_TRUE,lf[524]);}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 1059 gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[525]);}
else{
C_trace("c-backend.scm: 1060 gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[526]);}}}

/* k6393 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 1042 gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[521],C_SCHEME_TRUE);}

/* k6396 in k6393 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 1044 gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[517],C_SCHEME_TRUE,lf[518]);}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 1046 gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[519]);}
else{
C_trace("c-backend.scm: 1047 gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[520]);}}}

/* k6387 in k6384 in k6381 in k6378 in k6375 in k6372 in k6369 in k6366 in k6363 in k6360 in k6357 in k6354 in k6351 in k6348 in k6345 in k6342 in k6339 in k6336 in k6333 in k6330 in k6327 in k6321 in k6318 in k6315 in a6312 in ##compiler#generate-foreign-stubs in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 1061 gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6289,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6295,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6294 in ##compiler#generate-foreign-callback-stub-prototypes in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6295,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6299,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 992  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k6297 in a6294 in ##compiler#generate-foreign-callback-stub-prototypes in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6302,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 993  generate-foreign-callback-header");
t3=C_retrieve(lf[515]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[516],((C_word*)t0)[2]);}

/* k6300 in k6297 in a6294 in ##compiler#generate-foreign-callback-stub-prototypes in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 994  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6261,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 977  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k6259 in ##compiler#generate-external-variables in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6266,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6265 in k6259 in ##compiler#generate-external-variables in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6266,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=(C_word)C_i_vector_ref(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(t2,C_fix(2));
t6=(C_truep(t5)?lf[513]:lf[514]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6287,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 983  foreign-type-declaration");
t8=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t4,t3);}

/* k6285 in a6265 in k6259 in ##compiler#generate-external-variables in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 983  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6241(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6241,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6247,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 969  list-tabulate");
t5=C_retrieve(lf[512]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a6246 in ##compiler#make-argument-list in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6247,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6255,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 971  number->string");
C_number_to_string(3,0,t3,t2);}

/* k6253 in a6246 in ##compiler#make-argument-list in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 971  string-append");
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6225,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6231,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 964  list-tabulate");
t5=C_retrieve(lf[512]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a6230 in ##compiler#make-variable-list in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6231,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6239,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 966  number->string");
C_number_to_string(3,0,t3,t2);}

/* k6237 in a6230 in ##compiler#make-variable-list in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 966  string-append");
t2=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[511],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6136,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6145,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6145(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6145,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6161,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6174,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_6174(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_6174(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_6174(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_6174(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_6174(t10,C_SCHEME_FALSE);}}}}}

/* k6172 in loop in ##compiler#cleanup in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6174,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_6177(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6184,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 955  string-copy");
t4=C_retrieve(lf[510]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_6161(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k6182 in k6172 in loop in ##compiler#cleanup in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6177(t3,t2);}

/* k6175 in k6172 in loop in ##compiler#cleanup in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_6161(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k6159 in loop in ##compiler#cleanup in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
C_trace("c-backend.scm: 958  loop");
t3=((C_word*)((C_word*)t0)[3])[1];
f_6145(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6063,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6067,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
C_trace("c-backend.scm: 920  gen");
t7=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[507],C_SCHEME_TRUE,lf[508],t6,lf[509]);}

/* k6065 in emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6070,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6081,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6081(t6,t2,((C_word*)t0)[2]);}

/* doloop1247 in k6065 in emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_6081(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6081,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
C_trace("c-backend.scm: 924  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[500]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6094,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
C_trace("c-backend.scm: 925  lambda-literal-id");
t5=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k6092 in doloop1247 in k6065 in emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6097,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 926  gen");
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[505],t1,((C_word*)t0)[2],lf[506]);}

/* k6095 in k6092 in doloop1247 in k6065 in emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[239],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[190]))){
C_trace("c-backend.scm: 929  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[501],C_retrieve(lf[190]),lf[502]);}
else{
C_trace("c-backend.scm: 930  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[503]);}}
else{
C_trace("c-backend.scm: 931  gen");
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[504]);}}

/* k6098 in k6095 in k6092 in doloop1247 in k6065 in emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6081(t3,((C_word*)t0)[2],t2);}

/* k6068 in k6065 in emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 932  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[499]);}

/* k6071 in k6068 in k6065 in emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6076,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 933  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[498]);}

/* k6074 in k6071 in k6068 in k6065 in emit-procedure-table-info in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 934  gen");
t2=*((C_word*)lf[3]+1);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[491],C_SCHEME_TRUE,lf[492],C_SCHEME_TRUE,lf[493],C_SCHEME_TRUE,lf[494],C_SCHEME_TRUE,lf[495],C_SCHEME_TRUE,lf[496],C_SCHEME_TRUE,lf[497]);}

/* ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2487,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2490,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2522,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2532,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4017,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4164,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4313,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4564,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5271,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5194,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4887,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5052,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4850,a[2]=t2,a[3]=t19,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4893,a[2]=t18,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5283,a[2]=t4,a[3]=t8,a[4]=t22,a[5]=t20,a[6]=t2,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
t25=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6030,a[2]=t12,a[3]=t13,a[4]=t14,a[5]=t8,a[6]=t15,a[7]=t24,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 903  debugging");
t26=C_retrieve(lf[474]);
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[489],lf[490]);}

/* k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6030,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 905  header");
t4=((C_word*)t0)[2];
f_4017(t4,t3);}

/* k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 906  declarations");
t3=((C_word*)t0)[2];
f_4164(t3,t2);}

/* k6035 in k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 907  generate-external-variables");
t3=C_retrieve(lf[487]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[488]));}

/* k6038 in k6035 in k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 908  generate-foreign-stubs");
t3=C_retrieve(lf[485]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[486]),((C_word*)t0)[3]);}

/* k6041 in k6038 in k6035 in k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 909  prototypes");
t3=((C_word*)t0)[2];
f_4313(t3,t2);}

/* k6044 in k6041 in k6038 in k6035 in k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 910  generate-foreign-callback-stubs");
t3=C_retrieve(lf[484]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[184]),((C_word*)t0)[2]);}

/* k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 911  trampolines");
t3=((C_word*)t0)[2];
f_4564(t3,t2);}

/* k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6055,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 912  procedures");
t3=((C_word*)t0)[2];
f_5283(t3,t2);}

/* k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6058,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 913  emit-procedure-table-info");
t3=C_retrieve(lf[483]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6056 in k6053 in k6050 in k6047 in k6044 in k6041 in k6038 in k6035 in k6032 in k6028 in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
C_trace("c-backend.scm: 484  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[482],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5283,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5289,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 727  lambda-literal-argument-count");
t4=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 728  lambda-literal-id");
t3=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5299,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 729  real-name");
t3=C_retrieve(lf[481]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5302,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 730  lambda-literal-allocated");
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 731  lambda-literal-rest-argument");
t3=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5305,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 732  lambda-literal-customizable");
t5=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6027,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 733  lambda-literal-closure-size");
t4=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5311(t3,C_SCHEME_FALSE);}}

/* k6025 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5311(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5311(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5311,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5317,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
C_trace("c-backend.scm: 735  make-variable-list");
t5=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[480]);}

/* k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5320,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
C_trace("c-backend.scm: 736  make-argument-list");
t3=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[479]);}

/* k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5323,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
C_trace("c-backend.scm: 737  intersperse");
t4=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
C_trace("c-backend.scm: 738  intersperse");
t4=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
C_trace("c-backend.scm: 739  lambda-literal-external");
t3=C_retrieve(lf[314]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
C_trace("c-backend.scm: 740  lambda-literal-looping");
t3=C_retrieve(lf[108]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5335,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
C_trace("c-backend.scm: 741  lambda-literal-direct");
t3=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
C_trace("c-backend.scm: 742  lambda-literal-rest-argument-mode");
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
C_trace("c-backend.scm: 743  lambda-literal-temporaries");
t3=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[190]))){
C_trace("c-backend.scm: 745  string-append");
t3=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[190]),lf[477]);}
else{
t3=t2;
f_5344(2,t3,lf[478]);}}

/* k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 747  debugging");
t3=C_retrieve(lf[474]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[475],lf[476],((C_word*)t0)[14]);}
else{
t3=t2;
f_5347(2,t3,C_SCHEME_UNDEFINED);}}

/* k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
C_trace("c-backend.scm: 748  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5996,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 749  cleanup");
t4=C_retrieve(lf[473]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5994 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 749  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[471],t1,lf[472],C_SCHEME_TRUE);}

/* k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[239],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5979,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 758  gen");
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[465]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5957,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 751  gen");
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[470]);}}

/* k5955 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[468]:lf[469]);
C_trace("c-backend.scm: 752  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5958 in k5955 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 754  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[466]);}
else{
C_trace("c-backend.scm: 755  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[467]);}}

/* k5961 in k5958 in k5955 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 756  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5977 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[190]))){
t3=t2;
f_5982(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 760  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[464]);}}

/* k5980 in k5977 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 761  gen");
t2=*((C_word*)lf[3]+1);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[458],C_SCHEME_TRUE,lf[459],C_SCHEME_TRUE,lf[460],C_SCHEME_TRUE,lf[461],((C_word*)t0)[2],lf[462],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[463],((C_word*)t0)[2]);}

/* k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("c-backend.scm: 766  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5362(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 767  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[457]);}}

/* k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5929,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_5929(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5929(t4,C_SCHEME_FALSE);}}

/* k5927 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5929,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 769  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[456]);}
else{
t2=((C_word*)t0)[2];
f_5365(2,t2,C_SCHEME_UNDEFINED);}}

/* k5930 in k5927 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 770  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_5365(2,t2,C_SCHEME_UNDEFINED);}}

/* k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[15]);}

/* k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
C_trace("c-backend.scm: 772  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[455]);}
else{
t3=t2;
f_5371(2,t3,C_SCHEME_UNDEFINED);}}

/* k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("c-backend.scm: 773  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[454]);}

/* k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[228]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_5377(t5,t4);}
else{
t4=t2;
f_5377(t4,C_SCHEME_UNDEFINED);}}

/* k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5377,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_trace("c-backend.scm: 775  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[453]);}

/* k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
C_trace("c-backend.scm: 777  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[451],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5891,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5891(t8,t2,((C_word*)t0)[20],t4);}}

/* doloop995 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5891(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5891,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5901,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 781  gen");
t6=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[452],t2,C_make_character(59));}}

/* k5899 in doloop995 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5891(t4,((C_word*)t0)[2],t2,t3);}

/* k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[239],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5678,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 783  fold");
t6=C_retrieve(lf[418]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 817  gen");
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[432]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5756,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5834,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_5834(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_5834(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k5832 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5834,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
C_trace("c-backend.scm: 831  gen");
t2=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[442],C_SCHEME_TRUE,lf[443],C_SCHEME_TRUE,lf[444],((C_word*)t0)[3],lf[445]);}
else{
C_trace("c-backend.scm: 834  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[446],((C_word*)t0)[3],lf[447]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5846,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5846(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 836  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[450]);}}}

/* k5844 in k5832 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 837  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[449]);}
else{
t3=t2;
f_5849(2,t3,C_SCHEME_UNDEFINED);}}

/* k5847 in k5844 in k5832 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5855,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[112]);
t4=t2;
f_5855(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[412]))));}
else{
t3=t2;
f_5855(t3,C_SCHEME_FALSE);}}

/* k5853 in k5847 in k5844 in k5832 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("c-backend.scm: 839  gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[448]);}
else{
t2=((C_word*)t0)[2];
f_5756(2,t2,C_SCHEME_UNDEFINED);}}

/* k5754 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5759,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5798,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[112]);
if(C_truep(t4)){
t5=t3;
f_5798(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[426]);
t6=t3;
f_5798(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5798(t4,C_SCHEME_FALSE);}}

/* k5796 in k5754 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[228]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
C_trace("c-backend.scm: 843  gen");
t4=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[436],((C_word*)t0)[3],lf[437],((C_word*)t0)[3],lf[438]);}
else{
t4=((C_word*)t0)[2];
f_5759(2,t4,C_SCHEME_UNDEFINED);}}
else{
C_trace("c-backend.scm: 844  gen");
t3=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440],((C_word*)t0)[3],lf[441]);}}
else{
t2=((C_word*)t0)[2];
f_5759(2,t2,C_SCHEME_UNDEFINED);}}

/* k5757 in k5754 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5765,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5765(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_5765(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_5765(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k5763 in k5757 in k5754 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5765(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5765,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[421]))){
C_trace("c-backend.scm: 846  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[435]);}
else{
t3=t2;
f_5768(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_5386(2,t2,C_SCHEME_UNDEFINED);}}

/* k5766 in k5763 in k5757 in k5754 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5774,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_5774(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_5774(t3,C_SCHEME_FALSE);}}

/* k5772 in k5766 in k5763 in k5757 in k5754 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5774(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("c-backend.scm: 848  gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[433]);}
else{
C_trace("c-backend.scm: 849  gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[434]);}}

/* k5690 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 818  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[431]);}

/* k5693 in k5690 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 819  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[430]);}

/* k5696 in k5693 in k5690 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
C_trace("c-backend.scm: 821  gen");
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
C_trace("c-backend.scm: 822  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[429]);}}

/* k5699 in k5696 in k5693 in k5690 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 823  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[427],((C_word*)t0)[3],lf[428]);}

/* k5702 in k5699 in k5696 in k5693 in k5690 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5707,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5719,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[112]);
if(C_truep(t4)){
t5=t3;
f_5719(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[426]);
if(C_truep(t5)){
t6=t3;
f_5719(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_5719(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5717 in k5702 in k5699 in k5696 in k5693 in k5690 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("c-backend.scm: 825  gen");
t2=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[423],((C_word*)t0)[2],lf[424],((C_word*)t0)[2],lf[425]);}
else{
t2=((C_word*)t0)[3];
f_5707(2,t2,C_SCHEME_UNDEFINED);}}

/* k5705 in k5702 in k5699 in k5696 in k5693 in k5690 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[421]))){
C_trace("c-backend.scm: 826  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[422]);}
else{
t3=t2;
f_5710(2,t3,C_SCHEME_UNDEFINED);}}

/* k5708 in k5705 in k5702 in k5699 in k5696 in k5693 in k5690 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 827  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[419],((C_word*)t0)[2],lf[420]);}

/* a5677 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5678,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5686,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 783  literal-size");
t5=((C_word*)((C_word*)t0)[2])[1];
f_4893(3,t5,t4,t2);}

/* k5684 in a5677 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5603,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5609,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 785  gen");
t4=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[414],C_SCHEME_TRUE,lf[415],C_SCHEME_TRUE,lf[416],((C_word*)t0)[2],lf[417]);}

/* k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[412]))){
C_trace("c-backend.scm: 789  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[413]);}
else{
t3=t2;
f_5612(2,t3,C_SCHEME_UNDEFINED);}}

/* k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[190]))){
t3=t2;
f_5615(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5646,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[405]))){
C_trace("c-backend.scm: 792  gen");
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[406],C_retrieve(lf[405]),lf[407]);}
else{
if(C_truep(C_retrieve(lf[408]))){
C_trace("c-backend.scm: 794  gen");
t4=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[409],C_retrieve(lf[408]),lf[410],C_SCHEME_TRUE,lf[411]);}
else{
t4=t3;
f_5646(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k5644 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[403]))){
C_trace("c-backend.scm: 797  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[404],C_retrieve(lf[403]),C_make_character(59));}
else{
t3=t2;
f_5649(2,t3,C_SCHEME_UNDEFINED);}}

/* k5647 in k5644 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[401]))){
C_trace("c-backend.scm: 799  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[402],C_retrieve(lf[401]),C_make_character(59));}
else{
t3=t2;
f_5652(2,t3,C_SCHEME_UNDEFINED);}}

/* k5650 in k5647 in k5644 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[398]))){
C_trace("c-backend.scm: 801  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[399],C_retrieve(lf[398]),lf[400]);}
else{
t2=((C_word*)t0)[2];
f_5615(2,t2,C_SCHEME_UNDEFINED);}}

/* k5613 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 802  gen");
t3=*((C_word*)lf[3]+1);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[391],((C_word*)t0)[3],lf[392],C_SCHEME_TRUE,lf[393],((C_word*)t0)[3],lf[394],C_SCHEME_TRUE,lf[395],C_SCHEME_TRUE,lf[396],C_SCHEME_TRUE,lf[397]);}

/* k5616 in k5613 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 807  gen");
t3=*((C_word*)lf[3]+1);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[385],((C_word*)t0)[2],lf[386],C_SCHEME_TRUE,lf[387],C_SCHEME_TRUE,lf[388],((C_word*)t0)[2],lf[389],C_SCHEME_TRUE,lf[390]);}

/* k5619 in k5616 in k5613 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 811  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[383],((C_word*)t0)[2],lf[384]);}

/* k5622 in k5619 in k5616 in k5613 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5386(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 813  gen");
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[381],((C_word*)t0)[4],lf[382]);}}

/* k5631 in k5622 in k5619 in k5616 in k5613 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 814  literal-frame");
t3=((C_word*)t0)[2];
f_4850(t3,t2);}

/* k5634 in k5631 in k5622 in k5619 in k5616 in k5613 in k5610 in k5607 in k5601 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 815  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[379],((C_word*)t0)[2],lf[380]);}

/* k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5389,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5409,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[239],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_5409(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5409(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_5409(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_5409(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_5409(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5409,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[370]:lf[371]);
C_trace("c-backend.scm: 860  gen");
t5=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[372],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5544,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[376]:lf[377]);
C_trace("c-backend.scm: 886  gen");
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[378]);}}
else{
t2=((C_word*)t0)[10];
f_5389(2,t2,C_SCHEME_UNDEFINED);}}

/* k5542 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5547,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("c-backend.scm: 888  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[374]);}
else{
C_trace("c-backend.scm: 889  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[375],((C_word*)t0)[3]);}}

/* k5545 in k5542 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5550,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 891  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5550(2,t3,C_SCHEME_UNDEFINED);}}

/* k5557 in k5545 in k5542 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k5548 in k5545 in k5542 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 893  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[373]);}

/* k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[313]);
if(C_truep(t3)){
C_trace("c-backend.scm: 861  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_5418(2,t4,C_SCHEME_UNDEFINED);}}

/* k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 862  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[368],((C_word*)t0)[5],lf[369]);}

/* k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5424,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 864  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5424(2,t3,C_SCHEME_UNDEFINED);}}

/* k5523 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 866  gen");
t3=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[364],C_SCHEME_TRUE,lf[365],C_SCHEME_TRUE,lf[366],((C_word*)t0)[6],lf[367]);}

/* k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[359]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
C_trace("c-backend.scm: 870  gen");
t5=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[360],((C_word*)t0)[6],lf[361]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[313]);
if(C_truep(t5)){
C_trace("c-backend.scm: 871  gen");
t6=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[362],((C_word*)t0)[6],lf[363]);}
else{
t6=t2;
f_5430(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 872  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[358]);}

/* k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5494,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5498,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 873  make-argument-list");
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[357]);}

/* k5496 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 873  intersperse");
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5492 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 874  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[355],((C_word*)t0)[5],lf[356]);}

/* k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 876  gen");
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[353],((C_word*)t0)[2],lf[354]);}

/* k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5445,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 878  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[351],((C_word*)t0)[3],lf[352]);}

/* k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 879  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[350]);}

/* k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5469,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5469(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1162 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5469(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5469,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5479,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 883  gen");
t6=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[349],t2,C_make_character(59));}}

/* k5477 in doloop1162 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5469(t4,((C_word*)t0)[2],t2,t3);}

/* k5452 in k5449 in k5446 in k5443 in k5440 in k5437 in k5434 in k5431 in k5428 in k5425 in k5422 in k5419 in k5416 in k5413 in k5407 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
C_trace("c-backend.scm: 884  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[347],((C_word*)t0)[3],lf[348]);}
else{
t3=((C_word*)t0)[2];
f_5389(2,t3,C_SCHEME_UNDEFINED);}}

/* k5387 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 895  lambda-literal-body");
t4=C_retrieve(lf[346]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5397 in k5387 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
C_trace("c-backend.scm: 894  expression");
t3=((C_word*)t0)[4];
f_2532(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k5390 in k5387 in k5384 in k5381 in k5378 in k5375 in k5372 in k5369 in k5366 in k5363 in k5360 in k5357 in k5354 in k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5333 in k5330 in k5327 in k5324 in k5321 in k5318 in k5315 in k5309 in k5306 in k5303 in k5300 in k5297 in k5294 in k5291 in a5288 in procedures in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 900  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4893,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 662  immediate?");
t4=C_retrieve(lf[345]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[339]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 666  literal-size");
t4=((C_word*)((C_word*)t0)[3])[1];
f_4893(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4960,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4964,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 667  vector->list");
t6=*((C_word*)lf[342]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 668  block-variable-literal?");
t3=C_retrieve(lf[335]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k4972 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
C_trace("c-backend.scm: 669  bad-literal");
f_4887(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 671  ##sys#bytevector?");
t3=*((C_word*)lf[344]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k4990 in k4972 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
C_trace("c-backend.scm: 671  words");
t4=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5021(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
C_trace("c-backend.scm: 678  bad-literal");
f_4887(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k4990 in k4972 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5021(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5021,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5043,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
C_trace("c-backend.scm: 677  literal-size");
t8=((C_word*)((C_word*)t0)[2])[1];
f_4893(3,t8,t6,t7);}}

/* k5041 in loop in k4990 in k4972 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
C_trace("c-backend.scm: 677  loop");
t3=((C_word*)((C_word*)t0)[4])[1];
f_5021(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4997 in k4990 in k4972 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k4966 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4962 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 667  reduce");
t2=C_retrieve(lf[340]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[341]+1),C_fix(0),t1);}

/* k4958 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k4929 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4935,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
C_trace("c-backend.scm: 666  literal-size");
t4=((C_word*)((C_word*)t0)[2])[1];
f_4893(3,t4,t2,t3);}

/* k4933 in k4929 in k4898 in literal-size in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4850,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4856,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4856(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop798 in literal-frame in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4856(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4856,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4866,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4885,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 656  sprintf");
t7=C_retrieve(lf[337]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[338],t2);}}

/* k4883 in doloop798 in literal-frame in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 656  gen-lit");
t2=((C_word*)t0)[4];
f_5052(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4864 in doloop798 in literal-frame in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4856(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5052(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5052,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5192,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 682  big-fixnum?");
t6=C_retrieve(lf[336]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_5059(t5,C_SCHEME_FALSE);}}

/* k5190 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5059(t2,(C_word)C_i_not(t1));}

/* k5057 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5059(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5059,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("c-backend.scm: 683  gen");
t2=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[320],((C_word*)t0)[4],lf[321]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 684  block-variable-literal?");
t3=C_retrieve(lf[335]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k5063 in k5057 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5065,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[322]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
C_trace("c-backend.scm: 686  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[323]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[324]:lf[325]);
C_trace("c-backend.scm: 688  gen");
t5=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
C_trace("c-backend.scm: 690  gen");
t5=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[326],t4,lf[327]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5115,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 693  c-ify-string");
t6=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
C_trace("c-backend.scm: 698  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[331]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5148(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_5148(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k5146 in k5063 in k5057 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5151,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 702  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[334]);}
else{
C_trace("c-backend.scm: 705  bad-literal");
f_4887(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k5149 in k5146 in k5063 in k5057 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5161,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 703  encode-literal");
t4=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5159 in k5149 in k5146 in k5063 in k5057 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 703  gen-string-constant");
t2=((C_word*)t0)[3];
f_5194(t2,((C_word*)t0)[2],t1);}

/* k5152 in k5149 in k5146 in k5063 in k5057 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 704  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[332]);}

/* k5113 in k5063 in k5057 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5115,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5121,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 695  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[330]);}

/* k5119 in k5113 in k5063 in k5057 in gen-lit in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 696  gen");
t2=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[328],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[329]);}

/* bad-literal in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4887(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4887,NULL,2,t1,t2);}
C_trace("c-backend.scm: 659  bomb");
t3=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[319],t2);}

/* gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5194(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5194,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5201,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 709  fx/");
t5=*((C_word*)lf[318]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5204,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 710  modulo");
t3=*((C_word*)lf[317]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k5202 in k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5204,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5209,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5209(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop888 in k5202 in k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5209(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5209,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5225,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5225(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5225(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5246,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5261,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5265,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
C_trace("c-backend.scm: 716  string-like-substring");
f_5271(t7,((C_word*)t0)[4],t3,t8);}}

/* k5263 in doloop888 in k5202 in k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 716  c-ify-string");
t2=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5259 in doloop888 in k5202 in k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 716  gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5244 in doloop888 in k5202 in k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5209(t4,((C_word*)t0)[2],t2,t3);}

/* k5223 in doloop888 in k5202 in k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5225,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5232,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5236,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 715  string-like-substring");
f_5271(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5234 in k5223 in doloop888 in k5202 in k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 715  c-ify-string");
t2=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5230 in k5223 in doloop888 in k5202 in k5199 in gen-string-constant in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 715  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_5271(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5271,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5278,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 720  make-string");
t7=*((C_word*)lf[316]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k5276 in string-like-substring in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5281,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 721  ##sys#copy-bytes");
t3=C_retrieve(lf[315]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5279 in k5276 in string-like-substring in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4564,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4567,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4603,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4683,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4731,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
C_trace("for-each");
t12=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4731,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4735,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 615  lambda-literal-argument-count");
t4=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4738,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 616  lambda-literal-rest-argument");
t5=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4741,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 617  lambda-literal-rest-argument-mode");
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 618  lambda-literal-id");
t3=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4744,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 619  lambda-literal-customizable");
t3=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4848,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 620  lambda-literal-closure-size");
t4=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4750(t3,C_SCHEME_FALSE);}}

/* k4846 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4750(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4750(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4750,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_4753(t5,t4);}
else{
t3=t2;
f_4753(t3,C_SCHEME_UNDEFINED);}}

/* k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4753,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 622  lambda-literal-direct");
t3=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4759,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4765,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 624  gen");
t3=*((C_word*)lf[3]+1);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[309],((C_word*)t0)[9],lf[310],C_SCHEME_TRUE,lf[311],((C_word*)t0)[9],lf[312]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4793(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 632  lambda-literal-allocated");
t4=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k4835 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4793(2,t3,t2);}
else{
C_trace("c-backend.scm: 632  lambda-literal-external");
t3=C_retrieve(lf[314]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4791 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[228]);
t4=t2;
f_4799(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_4799(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4797 in k4791 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4799,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[313]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 635  lset-adjoin");
t4=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 636  lset-adjoin");
t4=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 637  lset-adjoin");
t3=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4815 in k4797 in k4791 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4811 in k4797 in k4791 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4807 in k4797 in k4791 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4763 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 626  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[307],((C_word*)t0)[3],lf[308]);}

/* k4766 in k4763 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 627  restore");
f_4567(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4769 in k4766 in k4763 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 628  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4772 in k4769 in k4766 in k4763 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 629  make-argument-list");
t3=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[306]);}

/* k4775 in k4772 in k4769 in k4766 in k4763 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4787,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 630  intersperse");
t4=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k4785 in k4775 in k4772 in k4769 in k4766 in k4763 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k4778 in k4775 in k4772 in k4769 in k4766 in k4763 in k4757 in k4751 in k4748 in k4745 in k4742 in k4739 in k4736 in k4733 in a4730 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 631  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[305]);}

/* k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4701 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4702,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 641  gen");
t4=*((C_word*)lf[3]+1);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[300],t2,lf[301],C_SCHEME_TRUE,lf[302],t2,lf[303],t2,lf[304]);}

/* k4704 in a4701 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 643  gen");
t3=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[297],((C_word*)t0)[3],lf[298],((C_word*)t0)[3],lf[299]);}

/* k4707 in k4704 in a4701 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 644  restore");
f_4567(t2,((C_word*)t0)[3]);}

/* k4710 in k4707 in k4704 in a4701 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 645  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[296],((C_word*)t0)[2],C_make_character(44));}

/* k4713 in k4710 in k4707 in k4704 in a4701 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4725,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4729,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 646  make-argument-list");
t5=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[295]);}

/* k4727 in k4713 in k4710 in k4707 in k4704 in a4701 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 646  intersperse");
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4723 in k4713 in k4710 in k4707 in k4704 in a4701 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k4716 in k4713 in k4710 in k4707 in k4704 in a4701 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 647  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[294]);}

/* k4684 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4689,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 649  emitter");
t4=((C_word*)t0)[3];
f_4603(t4,t3,C_SCHEME_FALSE);}

/* k4698 in k4684 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4687 in k4684 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 650  emitter");
t3=((C_word*)t0)[2];
f_4603(t3,t2,C_SCHEME_TRUE);}

/* k4694 in k4687 in k4684 in k4681 in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4603,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4605,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4605 in emitter in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4605,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[289]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[290]);
C_trace("c-backend.scm: 593  gen");
t6=*((C_word*)lf[3]+1);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[291],t2,C_make_character(114),t4,lf[292],C_SCHEME_TRUE,lf[293],t2,C_make_character(114),t5);}

/* k4607 */
static void C_ccall f_4609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 595  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[287],((C_word*)t0)[4],lf[288]);}

/* k4610 in k4607 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 596  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[286],((C_word*)t0)[4],C_make_character(114));}

/* k4613 in k4610 in k4607 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("c-backend.scm: 597  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_4618(2,t3,C_SCHEME_UNDEFINED);}}

/* k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 598  gen");
t3=*((C_word*)lf[3]+1);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[282],((C_word*)t0)[4],lf[283],C_SCHEME_TRUE,lf[284],C_SCHEME_TRUE,lf[285],((C_word*)t0)[4],C_make_character(59));}

/* k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 601  restore");
f_4567(t2,((C_word*)t0)[4]);}

/* k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 602  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[281]);}

/* k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 604  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[279]);}
else{
C_trace("c-backend.scm: 605  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[280]);}}

/* k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 606  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[278]);}

/* k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 607  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[277]);}
else{
t3=t2;
f_4636(2,t3,C_SCHEME_UNDEFINED);}}

/* k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 608  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[276]);}

/* k4637 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 609  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[275]);}

/* k4640 in k4637 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4652,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4656,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
C_trace("c-backend.scm: 610  make-argument-list");
t6=C_retrieve(lf[273]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[274]);}

/* k4654 in k4640 in k4637 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 610  intersperse");
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4650 in k4640 in k4637 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k4643 in k4640 in k4637 in k4634 in k4631 in k4628 in k4625 in k4622 in k4619 in k4616 in k4613 in k4610 in k4607 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 611  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[272]);}

/* restore in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4567(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4567,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4571,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4580,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4580(t8,t3,t4,C_fix(0));}

/* doloop697 in restore in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4580(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4580,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4590,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 588  gen");
t5=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[269],t2,lf[270],t3,lf[271]);}}

/* k4588 in doloop697 in restore in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4580(t4,((C_word*)t0)[2],t2,t3);}

/* k4569 in restore in trampolines in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 589  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[267],((C_word*)t0)[2],lf[268]);}

/* prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4313,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 517  gen");
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4341,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4345,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 520  lambda-literal-argument-count");
t4=C_retrieve(lf[266]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 521  lambda-literal-customizable");
t3=C_retrieve(lf[265]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4562,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 522  lambda-literal-closure-size");
t4=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4351(t3,C_SCHEME_FALSE);}}

/* k4560 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4351(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4351,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4548,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
C_trace("c-backend.scm: 523  make-variable-list");
t5=C_retrieve(lf[263]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[264]);}

/* k4546 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 523  intersperse");
t2=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 524  lambda-literal-id");
t3=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 525  lambda-literal-rest-argument");
t3=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 526  lambda-literal-rest-argument-mode");
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 527  lambda-literal-direct");
t3=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 528  lambda-literal-allocated");
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[255]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4540,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
C_trace("c-backend.scm: 530  lset-adjoin");
t7=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4372(t5,C_SCHEME_UNDEFINED);}}

/* k4538 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4372(t3,t2);}

/* k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4372(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4372,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
C_trace("c-backend.scm: 531  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4533,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 536  lambda-literal-callee-signatures");
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4531 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4513 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4514,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[255]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
C_trace("c-backend.scm: 535  lset-adjoin");
t7=C_retrieve(lf[256]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[257]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4523 in a4513 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[239],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[190]))){
C_trace("c-backend.scm: 546  string-append");
t5=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[190]),lf[246]);}
else{
t5=t4;
f_4490(2,t5,lf[247]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 538  gen");
t5=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[253],((C_word*)t0)[5],lf[254],C_SCHEME_TRUE);}}

/* k4463 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 539  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[252]);}

/* k4466 in k4463 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[250]:lf[251]);
C_trace("c-backend.scm: 540  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4469 in k4466 in k4463 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("c-backend.scm: 542  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[248]);}
else{
C_trace("c-backend.scm: 543  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[249]);}}

/* k4472 in k4469 in k4466 in k4463 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 544  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4488 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 547  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[244],t1,lf[245],C_SCHEME_TRUE);}

/* k4491 in k4488 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[242]))){
C_trace("c-backend.scm: 549  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[243],C_SCHEME_TRUE);}
else{
t3=t2;
f_4496(2,t3,C_SCHEME_UNDEFINED);}}

/* k4494 in k4491 in k4488 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 550  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[241]);}

/* k4497 in k4494 in k4491 in k4488 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 551  gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[240],((C_word*)t0)[2]);}

/* k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 552  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4387(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 553  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[238]);}}

/* k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4437,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4437(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4437(t4,C_SCHEME_FALSE);}}

/* k4435 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4437,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 555  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}
else{
t2=((C_word*)t0)[2];
f_4390(2,t2,C_SCHEME_UNDEFINED);}}

/* k4438 in k4435 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 556  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_4390(2,t2,C_SCHEME_UNDEFINED);}}

/* k4388 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[4]);}

/* k4391 in k4388 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4393,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 559  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[235]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 567  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k4423 in k4391 in k4388 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4428,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4428(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 569  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}}

/* k4426 in k4423 in k4391 in k4388 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 570  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k4397 in k4391 in k4388 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[228]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 562  gen");
t4=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[231],((C_word*)t0)[2],lf[232],C_SCHEME_TRUE,lf[233],((C_word*)t0)[2],lf[234]);}}

/* k4406 in k4397 in k4391 in k4388 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k4409 in k4406 in k4397 in k4391 in k4388 in k4385 in k4382 in k4379 in k4376 in k4373 in k4370 in k4367 in k4364 in k4361 in k4358 in k4355 in k4352 in k4349 in k4346 in k4343 in a4340 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
C_trace("c-backend.scm: 565  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[229],t2,lf[230]);}

/* k4318 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4325,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a4324 in k4318 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4325,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4329,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 574  gen");
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[226],t2,lf[227]);}

/* k4327 in a4324 in k4318 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4339,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 575  make-list");
t4=C_retrieve(lf[224]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[225]);}

/* k4337 in k4327 in a4324 in k4318 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[3]+1),t1);}

/* k4330 in k4327 in a4324 in k4318 in k4315 in prototypes in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 576  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[223]);}

/* declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4164(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4164,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4171,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 488  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[222]);}

/* k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4307,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[192]));}

/* a4306 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4307,3,t0,t1,t2);}
C_trace("c-backend.scm: 491  gen");
t3=*((C_word*)lf[3]+1);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[218],t2,lf[219],C_SCHEME_TRUE,lf[220],t2,lf[221]);}

/* k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4177(2,t4,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 495  gen");
t4=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[216],((C_word*)t0)[2],lf[217]);}}

/* k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 496  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[215]);}

/* k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4185,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4185(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4185(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4185,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4195,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
C_trace("c-backend.scm: 500  ##sys#lambda-info->string");
t6=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4201,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
C_trace("c-backend.scm: 502  gen");
t8=*((C_word*)lf[3]+1);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[212],((C_word*)t0)[5],lf[213],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4199 in k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4254,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4254(t6,t2,C_fix(0));}

/* doloop563 in k4199 in k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4254(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4254,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4264,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
C_trace("c-backend.scm: 509  gen");
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k4262 in doloop563 in k4199 in k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4254(t3,((C_word*)t0)[2],t2);}

/* k4202 in k4199 in k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4227,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4227(t9,t2,t5);}

/* doloop577 in k4202 in k4199 in k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4227,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4237,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 512  gen");
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[211]);}}

/* k4235 in doloop577 in k4202 in k4199 in k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4227(t3,((C_word*)t0)[2],t2);}

/* k4205 in k4202 in k4199 in k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 513  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[210]);}

/* k4208 in k4205 in k4202 in k4199 in k4193 in doloop545 in k4178 in k4175 in k4172 in k4169 in declarations in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4185(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4017,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4020,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4037,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4156,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 454  current-seconds");
t5=C_retrieve(lf[209]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4154 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 454  ##sys#decode-seconds");
t2=C_retrieve(lf[208]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_i_vector_ref(t1,C_fix(2));
t4=(C_word)C_i_vector_ref(t1,C_fix(3));
t5=(C_word)C_i_vector_ref(t1,C_fix(4));
t6=(C_word)C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4114,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
C_trace("c-backend.scm: 462  pad0");
f_4020(t9,t10);}

/* k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 462  pad0");
f_4020(t2,((C_word*)t0)[2]);}

/* k4116 in k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 462  pad0");
f_4020(t2,((C_word*)t0)[2]);}

/* k4120 in k4116 in k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4126,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 462  pad0");
f_4020(t2,((C_word*)t0)[2]);}

/* k4124 in k4120 in k4116 in k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4130,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4134,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4136,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4148,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 465  chicken-version");
t7=C_retrieve(lf[207]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k4146 in k4124 in k4120 in k4116 in k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 465  string-split");
t2=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[206]);}

/* k4142 in k4124 in k4120 in k4116 in k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[204]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4135 in k4124 in k4120 in k4116 in k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4136,3,t0,t1,t2);}
C_trace("string-append");
t3=*((C_word*)lf[180]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[202],t2,lf[203]);}

/* k4132 in k4124 in k4120 in k4116 in k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 463  string-intersperse");
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[201]);}

/* k4128 in k4124 in k4120 in k4116 in k4112 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 460  gen");
t2=*((C_word*)lf[3]+1);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[195],((C_word*)t0)[7],lf[196],C_SCHEME_TRUE,lf[197],C_SCHEME_TRUE,lf[198],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[199]);}

/* k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 468  gen-list");
t3=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[194]));}

/* k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 469  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4059 in k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[190]))){
C_trace("c-backend.scm: 470  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[191],C_retrieve(lf[190]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4103,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 472  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[193]);}}

/* k4101 in k4059 in k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 473  gen-list");
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[192]));}

/* k4062 in k4059 in k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 474  gen");
t3=*((C_word*)lf[3]+1);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[186],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[187],C_retrieve(lf[188]),lf[189]);}

/* k4065 in k4062 in k4059 in k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[182]))){
C_trace("c-backend.scm: 476  generate-foreign-callback-stub-prototypes");
t3=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[184]));}
else{
t3=t2;
f_4070(2,t3,C_SCHEME_UNDEFINED);}}

/* k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[185])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4085,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 478  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_4073(2,t3,C_SCHEME_UNDEFINED);}}

/* k4083 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4090,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[185]));}

/* a4089 in k4083 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4090,3,t0,t1,t2);}
C_trace("c-backend.scm: 479  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k4071 in k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4035 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[182]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 481  generate-foreign-callback-stub-prototypes");
t2=C_retrieve(lf[183]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[184]));}}

/* pad0 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_4020(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4020,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4034,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 452  number->string");
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4032 in pad0 in header in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 452  string-append");
t2=*((C_word*)lf[180]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[181],t1);}

/* expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_2532(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2532,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3985,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
C_trace("c-backend.scm: 447  expr");
t11=((C_word*)t6)[1];
f_2535(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_3985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3985,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3991,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 441  pair-for-each");
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a3990 in expr-args in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3991,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_3995(2,t5,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 443  gen");
t5=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k3993 in a3990 in expr-args in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 444  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2535(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_2535(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2535,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2539,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3979,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3979 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3979,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3974,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3974 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3974,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3969,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3969 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3969,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word ab[228],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2545,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[18]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_eqp(t3,lf[19]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[10]);
t6=(C_truep(t5)?lf[20]:lf[21]);
C_trace("c-backend.scm: 127  gen");
t7=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[9],t6);}
else{
t5=(C_word)C_eqp(t3,lf[22]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[10]);
t7=(C_word)C_fix((C_word)C_character_code(t6));
C_trace("c-backend.scm: 128  gen");
t8=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,((C_word*)t0)[9],lf[23],t7,C_make_character(41));}
else{
t6=(C_word)C_eqp(t3,lf[24]);
if(C_truep(t6)){
C_trace("c-backend.scm: 129  gen");
t7=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[9],lf[25]);}
else{
t7=(C_word)C_eqp(t3,lf[26]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[10]);
C_trace("c-backend.scm: 130  gen");
t9=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t9))(5,t9,((C_word*)t0)[9],lf[27],t8,C_make_character(41));}
else{
t8=(C_word)C_eqp(t3,lf[28]);
if(C_truep(t8)){
C_trace("c-backend.scm: 131  gen");
t9=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,((C_word*)t0)[9],lf[29]);}
else{
C_trace("c-backend.scm: 132  bomb");
t9=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t9))(3,t9,((C_word*)t0)[9],lf[30]);}}}}}}
else{
t3=(C_word)C_eqp(t1,lf[31]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_vectorp(t4))){
t5=(C_word)C_i_vector_ref(t4,C_fix(0));
C_trace("c-backend.scm: 137  gen");
t6=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[9],lf[32],t5,lf[33]);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("c-backend.scm: 138  gen");
t6=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[9],lf[34],t5,C_make_character(93));}}
else{
t4=(C_word)C_eqp(t1,lf[35]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 141  gen");
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[38]);}
else{
t5=(C_word)C_eqp(t1,lf[39]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("c-backend.scm: 150  gen");
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[9],lf[40],t6);}
else{
t6=(C_word)C_eqp(t1,lf[41]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[10]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[7],a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_2717(t11,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6],t7);}
else{
t7=(C_word)C_eqp(t1,lf[42]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 162  gen");
t9=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[44]);}
else{
t8=(C_word)C_eqp(t1,lf[45]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 167  gen");
t10=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[47]);}
else{
t9=(C_word)C_eqp(t1,lf[48]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 172  gen");
t11=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,lf[49]);}
else{
t10=(C_word)C_eqp(t1,lf[50]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 179  gen");
t12=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,lf[53]);}
else{
t11=(C_word)C_eqp(t1,lf[54]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 186  gen");
t13=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,lf[56]);}
else{
t12=(C_word)C_eqp(t1,lf[57]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 193  gen");
t14=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[59]);}
else{
t13=(C_word)C_eqp(t1,lf[60]);
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[10]);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=t14,tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 201  gen");
t16=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t16))(5,t16,t15,lf[67],t14,C_make_character(44));}
else{
t14=(C_word)C_eqp(t1,lf[68]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 211  gen");
t16=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,lf[70]);}
else{
t15=(C_word)C_eqp(t1,lf[71]);
if(C_truep(t15)){
t16=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("c-backend.scm: 215  gen");
t17=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,((C_word*)t0)[9],C_make_character(116),t16);}
else{
t16=(C_word)C_eqp(t1,lf[72]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("c-backend.scm: 218  gen");
t19=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t19))(5,t19,t17,C_make_character(116),t18,C_make_character(61));}
else{
t17=(C_word)C_eqp(t1,lf[73]);
if(C_truep(t17)){
t18=(C_word)C_i_car(((C_word*)t0)[10]);
t19=(C_word)C_i_cadr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_caddr(((C_word*)t0)[10]))){
if(C_truep(t19)){
C_trace("c-backend.scm: 227  gen");
t20=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[74],t18,lf[75]);}
else{
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3054,a[2]=t18,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cadddr(((C_word*)t0)[10]);
C_trace("c-backend.scm: 228  symbol->string");
t23=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}}
else{
if(C_truep(t19)){
C_trace("c-backend.scm: 229  gen");
t20=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[80],t18,lf[81]);}
else{
C_trace("c-backend.scm: 230  gen");
t20=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[82],t18,lf[83]);}}}
else{
t18=(C_word)C_eqp(t1,lf[84]);
if(C_truep(t18)){
t19=(C_word)C_i_car(((C_word*)t0)[10]);
t20=(C_word)C_i_cadr(((C_word*)t0)[10]);
t21=(C_word)C_i_caddr(((C_word*)t0)[10]);
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3089,a[2]=t21,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t20)){
C_trace("c-backend.scm: 237  gen");
t23=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t23))(5,t23,t22,lf[87],t19,lf[88]);}
else{
C_trace("c-backend.scm: 238  gen");
t23=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t23))(5,t23,t22,lf[89],t19,lf[90]);}}
else{
t19=(C_word)C_eqp(t1,lf[91]);
if(C_truep(t19)){
t20=(C_word)C_i_car(((C_word*)t0)[10]);
t21=(C_word)C_i_cadr(((C_word*)t0)[10]);
t22=(C_word)C_i_caddr(((C_word*)t0)[10]);
if(C_truep(t21)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3137,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3151,a[2]=t20,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3155,a[2]=t24,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 249  symbol->string");
t26=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t22);}
else{
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3172,a[2]=t20,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3176,a[2]=t24,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 254  symbol->string");
t26=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t22);}}
else{
t20=(C_word)C_eqp(t1,lf[98]);
if(C_truep(t20)){
C_trace("c-backend.scm: 258  gen");
t21=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[9],lf[99]);}
else{
t21=(C_word)C_eqp(t1,lf[100]);
if(C_truep(t21)){
t22=(C_word)C_i_cdr(((C_word*)t0)[8]);
t23=(C_word)C_i_length(t22);
t24=((C_word*)t0)[6];
t25=(C_word)C_fixnum_increase(t23);
t26=(C_word)C_i_cdr(((C_word*)t0)[10]);
t27=(C_word)C_i_pairp(t26);
t28=(C_truep(t27)?(C_word)C_i_cadr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t29=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3209,a[2]=t27,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t28,a[6]=t24,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t23,a[10]=t25,a[11]=((C_word*)t0)[6],a[12]=t22,a[13]=((C_word*)t0)[4],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[10],tmp=(C_word)a,a+=17,tmp);
C_trace("c-backend.scm: 267  source-info->string");
t30=C_retrieve(lf[129]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t29,t28);}
else{
t22=(C_word)C_eqp(t1,lf[130]);
if(C_truep(t22)){
t23=(C_word)C_i_length(((C_word*)t0)[8]);
t24=(C_word)C_fixnum_increase(t23);
t25=(C_word)C_i_car(((C_word*)t0)[10]);
t26=(C_word)C_i_cadr(((C_word*)t0)[10]);
t27=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3530,a[2]=t26,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t24,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t23,a[10]=((C_word*)t0)[9],a[11]=t25,tmp=(C_word)a,a+=12,tmp);
C_trace("c-backend.scm: 324  lambda-literal-closure-size");
t28=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,((C_word*)t0)[3]);}
else{
t23=(C_word)C_eqp(t1,lf[134]);
if(C_truep(t23)){
t24=(C_word)C_i_cdr(((C_word*)t0)[8]);
t25=(C_word)C_i_length(t24);
t26=(C_word)C_fixnum_increase(t25);
t27=(C_word)C_i_caddr(((C_word*)t0)[10]);
t28=(C_word)C_i_cadddr(((C_word*)t0)[10]);
t29=(C_word)C_eqp(t28,C_fix(0));
t30=(C_word)C_i_not(t29);
t31=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3615,a[2]=t27,a[3]=t28,a[4]=t30,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],a[8]=t24,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 352  find-lambda");
t33=((C_word*)t0)[2];
f_2490(t33,t32,t27);}
else{
t24=(C_word)C_eqp(t1,lf[136]);
if(C_truep(t24)){
t25=(C_word)C_i_length(((C_word*)t0)[8]);
t26=(C_word)C_fixnum_plus(t25,C_fix(1));
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3638,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("c-backend.scm: 369  gen");
t29=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t29))(8,t29,t27,C_SCHEME_TRUE,lf[138],t28,lf[139],t26,lf[140]);}
else{
t25=(C_word)C_eqp(t1,lf[141]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 374  gen");
t27=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t27))(4,t27,t26,C_SCHEME_TRUE,lf[143]);}
else{
t26=(C_word)C_eqp(t1,lf[144]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3676,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_car(((C_word*)t0)[10]);
C_trace("c-backend.scm: 379  gen");
t29=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t29))(5,t29,t27,lf[145],t28,C_make_character(40));}
else{
t27=(C_word)C_eqp(t1,lf[146]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t29=(C_word)C_i_car(((C_word*)t0)[10]);
t30=(C_word)C_i_length(((C_word*)t0)[8]);
C_trace("c-backend.scm: 384  gen");
t31=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t31))(6,t31,t28,lf[147],t29,lf[148],t30);}
else{
t28=(C_word)C_eqp(t1,lf[149]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t30=(C_word)C_i_cadr(((C_word*)t0)[10]);
C_trace("c-backend.scm: 392  foreign-result-conversion");
t31=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t31))(4,t31,t29,t30,lf[151]);}
else{
t29=(C_word)C_eqp(t1,lf[152]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[10]);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[10]);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3769,a[2]=t30,a[3]=t32,a[4]=t31,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 396  foreign-type-declaration");
t34=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,t30,lf[157]);}
else{
t30=(C_word)C_eqp(t1,lf[158]);
if(C_truep(t30)){
t31=(C_word)C_i_car(((C_word*)t0)[10]);
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3785,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3799,a[2]=t31,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 402  foreign-result-conversion");
t34=C_retrieve(lf[150]);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,t31,lf[163]);}
else{
t31=(C_word)C_eqp(t1,lf[164]);
if(C_truep(t31)){
t32=(C_word)C_i_car(((C_word*)t0)[10]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3815,a[2]=t32,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3843,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 408  foreign-type-declaration");
t35=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,t32,lf[169]);}
else{
t32=(C_word)C_eqp(t1,lf[170]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 415  gen");
t34=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,C_SCHEME_TRUE,lf[174]);}
else{
t33=(C_word)C_eqp(t1,lf[175]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 430  gen");
t35=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t35))(3,t35,t34,lf[177]);}
else{
C_trace("c-backend.scm: 438  bomb");
t34=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t34))(3,t34,((C_word*)t0)[9],lf[178]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k3933 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 431  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3936 in k3933 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 432  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[176]);}

/* k3939 in k3936 in k3933 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 433  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3942 in k3939 in k3936 in k3933 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 434  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k3945 in k3942 in k3939 in k3936 in k3933 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 435  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3948 in k3945 in k3942 in k3939 in k3936 in k3933 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 436  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 416  expr");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2535(t4,t2,t3,((C_word*)t0)[3]);}

/* k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 417  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[173]);}

/* k3856 in k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3858,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3871,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3871(t7,((C_word*)t0)[2],t2,t3);}

/* doloop448 in k3856 in k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_3871(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3871,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 421  gen");
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[171]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 424  gen");
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[172]);}}

/* k3892 in doloop448 in k3856 in k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
C_trace("c-backend.scm: 425  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3895 in k3892 in doloop448 in k3856 in k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 426  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k3898 in k3895 in k3892 in doloop448 in k3856 in k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
C_trace("c-backend.scm: 427  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3901 in k3898 in k3895 in k3892 in doloop448 in k3856 in k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3871(t4,((C_word*)t0)[2],t2,t3);}

/* k3879 in doloop448 in k3856 in k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 422  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3882 in k3879 in doloop448 in k3856 in k3853 in k3850 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 423  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k3841 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 408  gen");
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[167],t1,lf[168]);}

/* k3813 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 409  expr");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2535(t4,t2,t3,((C_word*)t0)[3]);}

/* k3816 in k3813 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3835,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 410  foreign-argument-conversion");
t4=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3833 in k3816 in k3813 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 410  gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[166],t1);}

/* k3819 in k3816 in k3813 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 411  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3822 in k3819 in k3816 in k3813 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 412  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[165]);}

/* k3797 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3803,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 402  foreign-type-declaration");
t3=C_retrieve(lf[156]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[162]);}

/* k3801 in k3797 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 402  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[160],t1,lf[161]);}

/* k3783 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 403  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3786 in k3783 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 404  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[159]);}

/* k3767 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3773,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 396  foreign-argument-conversion");
t3=C_retrieve(lf[155]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3771 in k3767 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 396  gen");
t2=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[154],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3749 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 397  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3752 in k3749 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 398  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[153]);}

/* k3729 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
C_trace("c-backend.scm: 392  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3693 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3698,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 387  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_3698(2,t3,C_SCHEME_UNDEFINED);}}

/* k3705 in k3693 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 388  expr-args");
t2=((C_word*)((C_word*)t0)[5])[1];
f_3985(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3696 in k3693 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 389  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3674 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 380  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3985(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3677 in k3674 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 381  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3655 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 375  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3658 in k3655 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 376  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[142]);}

/* k3636 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3641,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 370  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3985(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3639 in k3636 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 371  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[137]);}

/* k3617 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 352  lambda-literal-closure-size");
t2=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3613 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3615,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 354  gen");
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k3561 in k3613 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3566,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3596,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 356  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[135],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3566(2,t3,C_SCHEME_UNDEFINED);}}

/* k3594 in k3561 in k3613 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
C_trace("c-backend.scm: 357  gen");
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_3566(2,t4,C_SCHEME_UNDEFINED);}}

/* k3564 in k3561 in k3613 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3569,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3569(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3584,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 359  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3582 in k3564 in k3561 in k3613 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
C_trace("c-backend.scm: 360  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3569(2,t2,C_SCHEME_UNDEFINED);}}

/* k3567 in k3564 in k3561 in k3613 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3572,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
C_trace("c-backend.scm: 361  expr-args");
t3=((C_word*)((C_word*)t0)[3])[1];
f_3985(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3572(2,t3,C_SCHEME_UNDEFINED);}}

/* k3570 in k3567 in k3564 in k3561 in k3613 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 362  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 326  lambda-literal-temporaries");
t4=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3514,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 339  gen");
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3512 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3517(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 340  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[133]);}}

/* k3515 in k3512 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 341  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3985(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3518 in k3515 in k3512 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 342  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
C_trace("c-backend.scm: 327  iota");
t4=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3474 in k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3479,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 328  for-each");
t4=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a3496 in k3474 in k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3497,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 330  gen");
t5=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3499 in a3496 in k3474 in k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 331  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2535(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3502 in k3499 in a3496 in k3474 in k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 332  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3477 in k3474 in k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3487,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 336  iota");
t5=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3493 in k3477 in k3474 in k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 334  for-each");
t2=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3486 in k3477 in k3474 in k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3487,4,t0,t1,t2,t3);}
C_trace("c-backend.scm: 335  gen");
t4=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[132],t2,C_make_character(59));}

/* k3480 in k3477 in k3474 in k3471 in k3528 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 337  gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[131]);}

/* k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[16]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_3212(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[16]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3212(t3,C_SCHEME_FALSE);}}

/* k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_3212(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3212,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[16]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3419,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3423,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 270  find-lambda");
t6=((C_word*)t0)[2];
f_2490(t6,t5,t1);}
else{
t4=t3;
f_3218(t4,C_SCHEME_FALSE);}}

/* k3421 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 270  lambda-literal-closure-size");
t2=C_retrieve(lf[128]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3417 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3218(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_3218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3224,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(C_retrieve(lf[120]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2520,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 114  ->string");
t7=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3412,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 275  uncommentify");
f_2522(t4,((C_word*)t0)[3]);}}
else{
t4=t3;
f_3224(2,t4,C_SCHEME_UNDEFINED);}}

/* k3410 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 275  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[126],t1,lf[127]);}

/* k2518 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 114  string-translate");
t2=C_retrieve(lf[123]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[124],lf[125]);}

/* k3403 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 274  gen");
t2=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[121],t1,lf[122]);}

/* k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3391,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_3391 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3391,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3390,2,t0,t1);}
t2=(C_word)C_eqp(lf[39],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3247,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}
else{
if(C_truep(((C_word*)t0)[9])){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 282  lambda-literal-id");
t5=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
C_trace("c-backend.scm: 308  gen");
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k3351 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 309  expr");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2535(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3354 in k3351 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 310  gen");
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[118],((C_word*)t0)[4],lf[119]);}

/* k3357 in k3354 in k3351 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[112]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3374(t5,t3);}
else{
t5=C_retrieve(lf[117]);
t6=t4;
f_3374(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k3372 in k3357 in k3354 in k3351 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_3374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("c-backend.scm: 313  gen");
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[113],((C_word*)t0)[2],lf[114]);}
else{
C_trace("c-backend.scm: 314  gen");
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[115],((C_word*)t0)[2],lf[116]);}}

/* k3360 in k3357 in k3354 in k3351 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 315  gen");
t3=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[110],((C_word*)t0)[3],lf[111],((C_word*)t0)[2],C_make_character(44));}

/* k3363 in k3360 in k3357 in k3354 in k3351 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3368,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 316  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3985(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3366 in k3363 in k3360 in k3357 in k3354 in k3351 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 317  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[109]);}

/* k3348 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
C_trace("c-backend.scm: 283  lambda-literal-looping");
t3=C_retrieve(lf[108]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3260(2,t3,C_SCHEME_FALSE);}}

/* k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3260,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
C_trace("c-backend.scm: 284  lambda-literal-temporaries");
t3=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3310(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 299  gen");
t4=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3332 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 300  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2535(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3335 in k3332 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 301  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3308 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
C_trace("c-backend.scm: 302  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3311 in k3308 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3316(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 303  gen");
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3314 in k3311 in k3308 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3319(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 304  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k3317 in k3314 in k3311 in k3308 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 305  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3985(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3320 in k3317 in k3314 in k3311 in k3308 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 306  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[107]);}

/* k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
C_trace("c-backend.scm: 285  iota");
t4=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 286  for-each");
t4=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a3292 in k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3293,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 288  gen");
t5=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3295 in a3292 in k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3300,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 289  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2535(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3298 in k3295 in a3292 in k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 290  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3267 in k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3283,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 294  iota");
t5=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3289 in k3267 in k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 292  for-each");
t2=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3282 in k3267 in k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3283,4,t0,t1,t2,t3);}
C_trace("c-backend.scm: 293  gen");
t4=*((C_word*)lf[3]+1);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[105],t2,C_make_character(59));}

/* k3270 in k3267 in k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3275(2,t3,C_SCHEME_UNDEFINED);}
else{
C_trace("c-backend.scm: 295  gen");
t3=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[104],((C_word*)t0)[2],C_make_character(59));}}

/* k3273 in k3270 in k3267 in k3264 in k3261 in k3258 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 296  gen");
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[103]);}

/* f_3247 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3247,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3231 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(t1);
C_trace("c-backend.scm: 278  gen");
t4=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,t3,C_make_character(40),((C_word*)t0)[2],lf[102]);}

/* k3234 in k3231 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 279  expr-args");
t3=((C_word*)((C_word*)t0)[4])[1];
f_3985(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3237 in k3234 in k3231 in k3388 in k3222 in k3216 in k3210 in k3207 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 280  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[101]);}

/* k3174 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 254  uncommentify");
f_2522(((C_word*)t0)[2],t1);}

/* k3170 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 253  gen");
t2=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[95],((C_word*)t0)[2],lf[96],t1,lf[97]);}

/* k3156 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 255  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3159 in k3156 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 256  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3153 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 249  uncommentify");
f_2522(((C_word*)t0)[2],t1);}

/* k3149 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 248  gen");
t2=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[92],((C_word*)t0)[2],lf[93],t1,lf[94]);}

/* k3135 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3140,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 250  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3138 in k3135 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 251  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3087 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3092,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3110,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 239  symbol->string");
t5=*((C_word*)lf[79]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3108 in k3087 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 239  uncommentify");
f_2522(((C_word*)t0)[2],t1);}

/* k3104 in k3087 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 239  gen");
t2=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[85],t1,lf[86]);}

/* k3090 in k3087 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3095,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 240  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k3093 in k3090 in k3087 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 241  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3056 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 228  c-ify-string");
t2=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3052 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 228  gen");
t2=*((C_word*)lf[3]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[76],((C_word*)t0)[2],lf[77],t1,C_make_character(41));}

/* k3010 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 219  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2535(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2978 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 212  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2981 in k2978 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 213  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[69]);}

/* k2943 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("c-backend.scm: 207  iota");
t5=C_retrieve(lf[66]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2969 in k2943 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 202  for-each");
t2=*((C_word*)lf[65]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2956 in k2943 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2957,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 204  gen");
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[63],t3,lf[64]);}

/* k2959 in a2956 in k2943 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2964,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 205  expr");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2535(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2962 in k2959 in a2956 in k2943 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 206  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k2946 in k2943 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
C_trace("c-backend.scm: 208  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[61],t2,lf[62]);}

/* k2911 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 194  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2914 in k2911 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 195  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[58]);}

/* k2917 in k2914 in k2911 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 196  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2920 in k2917 in k2914 in k2911 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 197  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2882 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 187  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2885 in k2882 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 188  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[55]);}

/* k2888 in k2885 in k2882 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 189  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2891 in k2888 in k2885 in k2882 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 190  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2845 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 180  expr");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2535(t4,t2,t3,((C_word*)t0)[3]);}

/* k2848 in k2845 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
C_trace("c-backend.scm: 181  gen");
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[51],t4,lf[52]);}

/* k2851 in k2848 in k2845 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 182  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2854 in k2851 in k2848 in k2845 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 183  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2812 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
C_trace("c-backend.scm: 173  expr");
t4=((C_word*)((C_word*)t0)[4])[1];
f_2535(t4,t2,t3,((C_word*)t0)[3]);}

/* k2815 in k2812 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
C_trace("c-backend.scm: 174  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k2818 in k2815 in k2812 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 175  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2821 in k2818 in k2815 in k2812 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 176  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2793 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 168  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2796 in k2793 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 169  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[46]);}

/* k2766 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 163  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2769 in k2766 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
C_trace("c-backend.scm: 164  gen");
t4=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[43],t3,C_make_character(93));}

/* loop in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_2717(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2717,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2727,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
C_trace("c-backend.scm: 155  gen");
t7=*((C_word*)lf[3]+1);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
C_trace("c-backend.scm: 159  expr");
t7=((C_word*)((C_word*)t0)[2])[1];
f_2535(t7,t1,t6,t3);}}

/* k2725 in loop in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
C_trace("c-backend.scm: 156  expr");
t4=((C_word*)((C_word*)t0)[2])[1];
f_2535(t4,t2,t3,((C_word*)t0)[6]);}

/* k2728 in k2725 in loop in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("c-backend.scm: 157  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k2731 in k2728 in k2725 in loop in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
C_trace("c-backend.scm: 158  loop");
t5=((C_word*)((C_word*)t0)[3])[1];
f_2717(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2657 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
C_trace("c-backend.scm: 142  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2660 in k2657 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 143  gen");
t3=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[37]);}

/* k2663 in k2660 in k2657 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 144  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2666 in k2663 in k2660 in k2657 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("c-backend.scm: 145  gen");
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[36]);}

/* k2669 in k2666 in k2663 in k2660 in k2657 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
C_trace("c-backend.scm: 146  expr");
t4=((C_word*)((C_word*)t0)[3])[1];
f_2535(t4,t2,t3,((C_word*)t0)[2]);}

/* k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2543 in k2540 in k2537 in expr in expression in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 147  gen");
t2=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* uncommentify in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_2522(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2522,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2530,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 115  ->string");
t4=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2528 in uncommentify in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("c-backend.scm: 115  string-translate*");
t2=C_retrieve(lf[15]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[16]);}

/* find-lambda in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_fcall f_2490(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2490,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2494,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2502,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("c-backend.scm: 111  find");
t5=C_retrieve(lf[14]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a2501 in find-lambda in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2502,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 111  lambda-literal-id");
t4=C_retrieve(lf[13]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2508 in a2501 in find-lambda in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k2492 in find-lambda in ##compiler#generate-code in k2483 in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
C_trace("c-backend.scm: 112  bomb");
t2=C_retrieve(lf[11]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[12],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2467,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2473,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2481,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("c-backend.scm: 93   intersperse");
t5=C_retrieve(lf[8]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k2479 in ##compiler#gen-list in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("for-each");
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2472 in ##compiler#gen-list in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2473,3,t0,t1,t2);}
C_trace("c-backend.scm: 92   display");
t3=*((C_word*)lf[5]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,*((C_word*)lf[2]+1));}

/* ##compiler#gen in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_2446r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2446r(t0,t1,t2);}}

static void C_ccall f_2446r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2452,tmp=(C_word)a,a+=2,tmp);
C_trace("for-each");
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a2451 in ##compiler#gen in k2441 in k2438 in k2435 in k2432 in k2429 in k2426 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2452,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
C_trace("c-backend.scm: 86   newline");
t4=*((C_word*)lf[4]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,*((C_word*)lf[2]+1));}
else{
C_trace("c-backend.scm: 87   display");
t4=*((C_word*)lf[5]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,*((C_word*)lf[2]+1));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[662] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_2428c-backend.scm",(void*)f_2428},
{"f_2431c-backend.scm",(void*)f_2431},
{"f_2434c-backend.scm",(void*)f_2434},
{"f_2437c-backend.scm",(void*)f_2437},
{"f_2440c-backend.scm",(void*)f_2440},
{"f_2443c-backend.scm",(void*)f_2443},
{"f_9059c-backend.scm",(void*)f_9059},
{"f_9063c-backend.scm",(void*)f_9063},
{"f_9055c-backend.scm",(void*)f_9055},
{"f_2485c-backend.scm",(void*)f_2485},
{"f_8755c-backend.scm",(void*)f_8755},
{"f_9031c-backend.scm",(void*)f_9031},
{"f_9029c-backend.scm",(void*)f_9029},
{"f_9017c-backend.scm",(void*)f_9017},
{"f_8987c-backend.scm",(void*)f_8987},
{"f_8948c-backend.scm",(void*)f_8948},
{"f_8935c-backend.scm",(void*)f_8935},
{"f_8931c-backend.scm",(void*)f_8931},
{"f_8817c-backend.scm",(void*)f_8817},
{"f_8764c-backend.scm",(void*)f_8764},
{"f_8761c-backend.scm",(void*)f_8761},
{"f_8758c-backend.scm",(void*)f_8758},
{"f_8357c-backend.scm",(void*)f_8357},
{"f_8444c-backend.scm",(void*)f_8444},
{"f_8525c-backend.scm",(void*)f_8525},
{"f_8547c-backend.scm",(void*)f_8547},
{"f_8359c-backend.scm",(void*)f_8359},
{"f_7872c-backend.scm",(void*)f_7872},
{"f_7902c-backend.scm",(void*)f_7902},
{"f_7929c-backend.scm",(void*)f_7929},
{"f_8124c-backend.scm",(void*)f_8124},
{"f_8133c-backend.scm",(void*)f_8133},
{"f_8142c-backend.scm",(void*)f_8142},
{"f_8164c-backend.scm",(void*)f_8164},
{"f_8241c-backend.scm",(void*)f_8241},
{"f_7874c-backend.scm",(void*)f_7874},
{"f_7036c-backend.scm",(void*)f_7036},
{"f_7113c-backend.scm",(void*)f_7113},
{"f_7215c-backend.scm",(void*)f_7215},
{"f_7248c-backend.scm",(void*)f_7248},
{"f_7344c-backend.scm",(void*)f_7344},
{"f_7359c-backend.scm",(void*)f_7359},
{"f_7399c-backend.scm",(void*)f_7399},
{"f_7416c-backend.scm",(void*)f_7416},
{"f_7433c-backend.scm",(void*)f_7433},
{"f_7472c-backend.scm",(void*)f_7472},
{"f_7489c-backend.scm",(void*)f_7489},
{"f_7506c-backend.scm",(void*)f_7506},
{"f_7523c-backend.scm",(void*)f_7523},
{"f_7540c-backend.scm",(void*)f_7540},
{"f_7557c-backend.scm",(void*)f_7557},
{"f_7574c-backend.scm",(void*)f_7574},
{"f_7586c-backend.scm",(void*)f_7586},
{"f_7593c-backend.scm",(void*)f_7593},
{"f_7603c-backend.scm",(void*)f_7603},
{"f_7601c-backend.scm",(void*)f_7601},
{"f_7597c-backend.scm",(void*)f_7597},
{"f_7564c-backend.scm",(void*)f_7564},
{"f_7547c-backend.scm",(void*)f_7547},
{"f_7530c-backend.scm",(void*)f_7530},
{"f_7513c-backend.scm",(void*)f_7513},
{"f_7496c-backend.scm",(void*)f_7496},
{"f_7479c-backend.scm",(void*)f_7479},
{"f_7444c-backend.scm",(void*)f_7444},
{"f_7454c-backend.scm",(void*)f_7454},
{"f_7452c-backend.scm",(void*)f_7452},
{"f_7448c-backend.scm",(void*)f_7448},
{"f_7440c-backend.scm",(void*)f_7440},
{"f_7427c-backend.scm",(void*)f_7427},
{"f_7410c-backend.scm",(void*)f_7410},
{"f_7043c-backend.scm",(void*)f_7043},
{"f_7038c-backend.scm",(void*)f_7038},
{"f_6971c-backend.scm",(void*)f_6971},
{"f_6975c-backend.scm",(void*)f_6975},
{"f_6978c-backend.scm",(void*)f_6978},
{"f_6981c-backend.scm",(void*)f_6981},
{"f_6984c-backend.scm",(void*)f_6984},
{"f_6990c-backend.scm",(void*)f_6990},
{"f_7034c-backend.scm",(void*)f_7034},
{"f_6993c-backend.scm",(void*)f_6993},
{"f_7001c-backend.scm",(void*)f_7001},
{"f_7022c-backend.scm",(void*)f_7022},
{"f_7005c-backend.scm",(void*)f_7005},
{"f_6996c-backend.scm",(void*)f_6996},
{"f_6540c-backend.scm",(void*)f_6540},
{"f_6546c-backend.scm",(void*)f_6546},
{"f_6550c-backend.scm",(void*)f_6550},
{"f_6553c-backend.scm",(void*)f_6553},
{"f_6556c-backend.scm",(void*)f_6556},
{"f_6559c-backend.scm",(void*)f_6559},
{"f_6565c-backend.scm",(void*)f_6565},
{"f_6906c-backend.scm",(void*)f_6906},
{"f_6909c-backend.scm",(void*)f_6909},
{"f_6969c-backend.scm",(void*)f_6969},
{"f_6912c-backend.scm",(void*)f_6912},
{"f_6915c-backend.scm",(void*)f_6915},
{"f_6918c-backend.scm",(void*)f_6918},
{"f_6921c-backend.scm",(void*)f_6921},
{"f_6954c-backend.scm",(void*)f_6954},
{"f_6962c-backend.scm",(void*)f_6962},
{"f_6924c-backend.scm",(void*)f_6924},
{"f_6952c-backend.scm",(void*)f_6952},
{"f_6927c-backend.scm",(void*)f_6927},
{"f_6930c-backend.scm",(void*)f_6930},
{"f_6933c-backend.scm",(void*)f_6933},
{"f_6567c-backend.scm",(void*)f_6567},
{"f_6577c-backend.scm",(void*)f_6577},
{"f_6586c-backend.scm",(void*)f_6586},
{"f_6598c-backend.scm",(void*)f_6598},
{"f_6610c-backend.scm",(void*)f_6610},
{"f_6616c-backend.scm",(void*)f_6616},
{"f_6650c-backend.scm",(void*)f_6650},
{"f_6307c-backend.scm",(void*)f_6307},
{"f_6313c-backend.scm",(void*)f_6313},
{"f_6317c-backend.scm",(void*)f_6317},
{"f_6320c-backend.scm",(void*)f_6320},
{"f_6323c-backend.scm",(void*)f_6323},
{"f_6538c-backend.scm",(void*)f_6538},
{"f_6329c-backend.scm",(void*)f_6329},
{"f_6332c-backend.scm",(void*)f_6332},
{"f_6335c-backend.scm",(void*)f_6335},
{"f_6338c-backend.scm",(void*)f_6338},
{"f_6341c-backend.scm",(void*)f_6341},
{"f_6344c-backend.scm",(void*)f_6344},
{"f_6347c-backend.scm",(void*)f_6347},
{"f_6350c-backend.scm",(void*)f_6350},
{"f_6353c-backend.scm",(void*)f_6353},
{"f_6356c-backend.scm",(void*)f_6356},
{"f_6527c-backend.scm",(void*)f_6527},
{"f_6359c-backend.scm",(void*)f_6359},
{"f_6362c-backend.scm",(void*)f_6362},
{"f_6365c-backend.scm",(void*)f_6365},
{"f_6368c-backend.scm",(void*)f_6368},
{"f_6371c-backend.scm",(void*)f_6371},
{"f_6374c-backend.scm",(void*)f_6374},
{"f_6377c-backend.scm",(void*)f_6377},
{"f_6380c-backend.scm",(void*)f_6380},
{"f_6505c-backend.scm",(void*)f_6505},
{"f_6475c-backend.scm",(void*)f_6475},
{"f_6495c-backend.scm",(void*)f_6495},
{"f_6483c-backend.scm",(void*)f_6483},
{"f_6487c-backend.scm",(void*)f_6487},
{"f_6491c-backend.scm",(void*)f_6491},
{"f_6383c-backend.scm",(void*)f_6383},
{"f_6386c-backend.scm",(void*)f_6386},
{"f_6416c-backend.scm",(void*)f_6416},
{"f_6419c-backend.scm",(void*)f_6419},
{"f_6457c-backend.scm",(void*)f_6457},
{"f_6453c-backend.scm",(void*)f_6453},
{"f_6422c-backend.scm",(void*)f_6422},
{"f_6425c-backend.scm",(void*)f_6425},
{"f_6428c-backend.scm",(void*)f_6428},
{"f_6395c-backend.scm",(void*)f_6395},
{"f_6398c-backend.scm",(void*)f_6398},
{"f_6389c-backend.scm",(void*)f_6389},
{"f_6289c-backend.scm",(void*)f_6289},
{"f_6295c-backend.scm",(void*)f_6295},
{"f_6299c-backend.scm",(void*)f_6299},
{"f_6302c-backend.scm",(void*)f_6302},
{"f_6257c-backend.scm",(void*)f_6257},
{"f_6261c-backend.scm",(void*)f_6261},
{"f_6266c-backend.scm",(void*)f_6266},
{"f_6287c-backend.scm",(void*)f_6287},
{"f_6241c-backend.scm",(void*)f_6241},
{"f_6247c-backend.scm",(void*)f_6247},
{"f_6255c-backend.scm",(void*)f_6255},
{"f_6225c-backend.scm",(void*)f_6225},
{"f_6231c-backend.scm",(void*)f_6231},
{"f_6239c-backend.scm",(void*)f_6239},
{"f_6136c-backend.scm",(void*)f_6136},
{"f_6145c-backend.scm",(void*)f_6145},
{"f_6174c-backend.scm",(void*)f_6174},
{"f_6184c-backend.scm",(void*)f_6184},
{"f_6177c-backend.scm",(void*)f_6177},
{"f_6161c-backend.scm",(void*)f_6161},
{"f_6063c-backend.scm",(void*)f_6063},
{"f_6067c-backend.scm",(void*)f_6067},
{"f_6081c-backend.scm",(void*)f_6081},
{"f_6094c-backend.scm",(void*)f_6094},
{"f_6097c-backend.scm",(void*)f_6097},
{"f_6100c-backend.scm",(void*)f_6100},
{"f_6070c-backend.scm",(void*)f_6070},
{"f_6073c-backend.scm",(void*)f_6073},
{"f_6076c-backend.scm",(void*)f_6076},
{"f_2487c-backend.scm",(void*)f_2487},
{"f_6030c-backend.scm",(void*)f_6030},
{"f_6034c-backend.scm",(void*)f_6034},
{"f_6037c-backend.scm",(void*)f_6037},
{"f_6040c-backend.scm",(void*)f_6040},
{"f_6043c-backend.scm",(void*)f_6043},
{"f_6046c-backend.scm",(void*)f_6046},
{"f_6049c-backend.scm",(void*)f_6049},
{"f_6052c-backend.scm",(void*)f_6052},
{"f_6055c-backend.scm",(void*)f_6055},
{"f_6058c-backend.scm",(void*)f_6058},
{"f_5283c-backend.scm",(void*)f_5283},
{"f_5289c-backend.scm",(void*)f_5289},
{"f_5293c-backend.scm",(void*)f_5293},
{"f_5296c-backend.scm",(void*)f_5296},
{"f_5299c-backend.scm",(void*)f_5299},
{"f_5302c-backend.scm",(void*)f_5302},
{"f_5305c-backend.scm",(void*)f_5305},
{"f_5308c-backend.scm",(void*)f_5308},
{"f_6027c-backend.scm",(void*)f_6027},
{"f_5311c-backend.scm",(void*)f_5311},
{"f_5317c-backend.scm",(void*)f_5317},
{"f_5320c-backend.scm",(void*)f_5320},
{"f_5323c-backend.scm",(void*)f_5323},
{"f_5326c-backend.scm",(void*)f_5326},
{"f_5329c-backend.scm",(void*)f_5329},
{"f_5332c-backend.scm",(void*)f_5332},
{"f_5335c-backend.scm",(void*)f_5335},
{"f_5338c-backend.scm",(void*)f_5338},
{"f_5341c-backend.scm",(void*)f_5341},
{"f_5344c-backend.scm",(void*)f_5344},
{"f_5347c-backend.scm",(void*)f_5347},
{"f_5350c-backend.scm",(void*)f_5350},
{"f_5996c-backend.scm",(void*)f_5996},
{"f_5353c-backend.scm",(void*)f_5353},
{"f_5957c-backend.scm",(void*)f_5957},
{"f_5960c-backend.scm",(void*)f_5960},
{"f_5963c-backend.scm",(void*)f_5963},
{"f_5979c-backend.scm",(void*)f_5979},
{"f_5982c-backend.scm",(void*)f_5982},
{"f_5356c-backend.scm",(void*)f_5356},
{"f_5359c-backend.scm",(void*)f_5359},
{"f_5362c-backend.scm",(void*)f_5362},
{"f_5929c-backend.scm",(void*)f_5929},
{"f_5932c-backend.scm",(void*)f_5932},
{"f_5365c-backend.scm",(void*)f_5365},
{"f_5368c-backend.scm",(void*)f_5368},
{"f_5371c-backend.scm",(void*)f_5371},
{"f_5374c-backend.scm",(void*)f_5374},
{"f_5377c-backend.scm",(void*)f_5377},
{"f_5380c-backend.scm",(void*)f_5380},
{"f_5891c-backend.scm",(void*)f_5891},
{"f_5901c-backend.scm",(void*)f_5901},
{"f_5383c-backend.scm",(void*)f_5383},
{"f_5834c-backend.scm",(void*)f_5834},
{"f_5846c-backend.scm",(void*)f_5846},
{"f_5849c-backend.scm",(void*)f_5849},
{"f_5855c-backend.scm",(void*)f_5855},
{"f_5756c-backend.scm",(void*)f_5756},
{"f_5798c-backend.scm",(void*)f_5798},
{"f_5759c-backend.scm",(void*)f_5759},
{"f_5765c-backend.scm",(void*)f_5765},
{"f_5768c-backend.scm",(void*)f_5768},
{"f_5774c-backend.scm",(void*)f_5774},
{"f_5692c-backend.scm",(void*)f_5692},
{"f_5695c-backend.scm",(void*)f_5695},
{"f_5698c-backend.scm",(void*)f_5698},
{"f_5701c-backend.scm",(void*)f_5701},
{"f_5704c-backend.scm",(void*)f_5704},
{"f_5719c-backend.scm",(void*)f_5719},
{"f_5707c-backend.scm",(void*)f_5707},
{"f_5710c-backend.scm",(void*)f_5710},
{"f_5678c-backend.scm",(void*)f_5678},
{"f_5686c-backend.scm",(void*)f_5686},
{"f_5603c-backend.scm",(void*)f_5603},
{"f_5609c-backend.scm",(void*)f_5609},
{"f_5612c-backend.scm",(void*)f_5612},
{"f_5646c-backend.scm",(void*)f_5646},
{"f_5649c-backend.scm",(void*)f_5649},
{"f_5652c-backend.scm",(void*)f_5652},
{"f_5615c-backend.scm",(void*)f_5615},
{"f_5618c-backend.scm",(void*)f_5618},
{"f_5621c-backend.scm",(void*)f_5621},
{"f_5624c-backend.scm",(void*)f_5624},
{"f_5633c-backend.scm",(void*)f_5633},
{"f_5636c-backend.scm",(void*)f_5636},
{"f_5386c-backend.scm",(void*)f_5386},
{"f_5409c-backend.scm",(void*)f_5409},
{"f_5544c-backend.scm",(void*)f_5544},
{"f_5547c-backend.scm",(void*)f_5547},
{"f_5559c-backend.scm",(void*)f_5559},
{"f_5550c-backend.scm",(void*)f_5550},
{"f_5415c-backend.scm",(void*)f_5415},
{"f_5418c-backend.scm",(void*)f_5418},
{"f_5421c-backend.scm",(void*)f_5421},
{"f_5525c-backend.scm",(void*)f_5525},
{"f_5424c-backend.scm",(void*)f_5424},
{"f_5427c-backend.scm",(void*)f_5427},
{"f_5430c-backend.scm",(void*)f_5430},
{"f_5433c-backend.scm",(void*)f_5433},
{"f_5498c-backend.scm",(void*)f_5498},
{"f_5494c-backend.scm",(void*)f_5494},
{"f_5436c-backend.scm",(void*)f_5436},
{"f_5439c-backend.scm",(void*)f_5439},
{"f_5442c-backend.scm",(void*)f_5442},
{"f_5445c-backend.scm",(void*)f_5445},
{"f_5448c-backend.scm",(void*)f_5448},
{"f_5451c-backend.scm",(void*)f_5451},
{"f_5469c-backend.scm",(void*)f_5469},
{"f_5479c-backend.scm",(void*)f_5479},
{"f_5454c-backend.scm",(void*)f_5454},
{"f_5389c-backend.scm",(void*)f_5389},
{"f_5399c-backend.scm",(void*)f_5399},
{"f_5392c-backend.scm",(void*)f_5392},
{"f_4893c-backend.scm",(void*)f_4893},
{"f_4900c-backend.scm",(void*)f_4900},
{"f_4974c-backend.scm",(void*)f_4974},
{"f_4992c-backend.scm",(void*)f_4992},
{"f_5021c-backend.scm",(void*)f_5021},
{"f_5043c-backend.scm",(void*)f_5043},
{"f_4999c-backend.scm",(void*)f_4999},
{"f_4968c-backend.scm",(void*)f_4968},
{"f_4964c-backend.scm",(void*)f_4964},
{"f_4960c-backend.scm",(void*)f_4960},
{"f_4931c-backend.scm",(void*)f_4931},
{"f_4935c-backend.scm",(void*)f_4935},
{"f_4850c-backend.scm",(void*)f_4850},
{"f_4856c-backend.scm",(void*)f_4856},
{"f_4885c-backend.scm",(void*)f_4885},
{"f_4866c-backend.scm",(void*)f_4866},
{"f_5052c-backend.scm",(void*)f_5052},
{"f_5192c-backend.scm",(void*)f_5192},
{"f_5059c-backend.scm",(void*)f_5059},
{"f_5065c-backend.scm",(void*)f_5065},
{"f_5148c-backend.scm",(void*)f_5148},
{"f_5151c-backend.scm",(void*)f_5151},
{"f_5161c-backend.scm",(void*)f_5161},
{"f_5154c-backend.scm",(void*)f_5154},
{"f_5115c-backend.scm",(void*)f_5115},
{"f_5121c-backend.scm",(void*)f_5121},
{"f_4887c-backend.scm",(void*)f_4887},
{"f_5194c-backend.scm",(void*)f_5194},
{"f_5201c-backend.scm",(void*)f_5201},
{"f_5204c-backend.scm",(void*)f_5204},
{"f_5209c-backend.scm",(void*)f_5209},
{"f_5265c-backend.scm",(void*)f_5265},
{"f_5261c-backend.scm",(void*)f_5261},
{"f_5246c-backend.scm",(void*)f_5246},
{"f_5225c-backend.scm",(void*)f_5225},
{"f_5236c-backend.scm",(void*)f_5236},
{"f_5232c-backend.scm",(void*)f_5232},
{"f_5271c-backend.scm",(void*)f_5271},
{"f_5278c-backend.scm",(void*)f_5278},
{"f_5281c-backend.scm",(void*)f_5281},
{"f_4564c-backend.scm",(void*)f_4564},
{"f_4731c-backend.scm",(void*)f_4731},
{"f_4735c-backend.scm",(void*)f_4735},
{"f_4738c-backend.scm",(void*)f_4738},
{"f_4741c-backend.scm",(void*)f_4741},
{"f_4744c-backend.scm",(void*)f_4744},
{"f_4747c-backend.scm",(void*)f_4747},
{"f_4848c-backend.scm",(void*)f_4848},
{"f_4750c-backend.scm",(void*)f_4750},
{"f_4753c-backend.scm",(void*)f_4753},
{"f_4759c-backend.scm",(void*)f_4759},
{"f_4837c-backend.scm",(void*)f_4837},
{"f_4793c-backend.scm",(void*)f_4793},
{"f_4799c-backend.scm",(void*)f_4799},
{"f_4817c-backend.scm",(void*)f_4817},
{"f_4813c-backend.scm",(void*)f_4813},
{"f_4809c-backend.scm",(void*)f_4809},
{"f_4765c-backend.scm",(void*)f_4765},
{"f_4768c-backend.scm",(void*)f_4768},
{"f_4771c-backend.scm",(void*)f_4771},
{"f_4774c-backend.scm",(void*)f_4774},
{"f_4777c-backend.scm",(void*)f_4777},
{"f_4787c-backend.scm",(void*)f_4787},
{"f_4780c-backend.scm",(void*)f_4780},
{"f_4683c-backend.scm",(void*)f_4683},
{"f_4702c-backend.scm",(void*)f_4702},
{"f_4706c-backend.scm",(void*)f_4706},
{"f_4709c-backend.scm",(void*)f_4709},
{"f_4712c-backend.scm",(void*)f_4712},
{"f_4715c-backend.scm",(void*)f_4715},
{"f_4729c-backend.scm",(void*)f_4729},
{"f_4725c-backend.scm",(void*)f_4725},
{"f_4718c-backend.scm",(void*)f_4718},
{"f_4686c-backend.scm",(void*)f_4686},
{"f_4700c-backend.scm",(void*)f_4700},
{"f_4689c-backend.scm",(void*)f_4689},
{"f_4696c-backend.scm",(void*)f_4696},
{"f_4603c-backend.scm",(void*)f_4603},
{"f_4605c-backend.scm",(void*)f_4605},
{"f_4609c-backend.scm",(void*)f_4609},
{"f_4612c-backend.scm",(void*)f_4612},
{"f_4615c-backend.scm",(void*)f_4615},
{"f_4618c-backend.scm",(void*)f_4618},
{"f_4621c-backend.scm",(void*)f_4621},
{"f_4624c-backend.scm",(void*)f_4624},
{"f_4627c-backend.scm",(void*)f_4627},
{"f_4630c-backend.scm",(void*)f_4630},
{"f_4633c-backend.scm",(void*)f_4633},
{"f_4636c-backend.scm",(void*)f_4636},
{"f_4639c-backend.scm",(void*)f_4639},
{"f_4642c-backend.scm",(void*)f_4642},
{"f_4656c-backend.scm",(void*)f_4656},
{"f_4652c-backend.scm",(void*)f_4652},
{"f_4645c-backend.scm",(void*)f_4645},
{"f_4567c-backend.scm",(void*)f_4567},
{"f_4580c-backend.scm",(void*)f_4580},
{"f_4590c-backend.scm",(void*)f_4590},
{"f_4571c-backend.scm",(void*)f_4571},
{"f_4313c-backend.scm",(void*)f_4313},
{"f_4317c-backend.scm",(void*)f_4317},
{"f_4341c-backend.scm",(void*)f_4341},
{"f_4345c-backend.scm",(void*)f_4345},
{"f_4348c-backend.scm",(void*)f_4348},
{"f_4562c-backend.scm",(void*)f_4562},
{"f_4351c-backend.scm",(void*)f_4351},
{"f_4548c-backend.scm",(void*)f_4548},
{"f_4354c-backend.scm",(void*)f_4354},
{"f_4357c-backend.scm",(void*)f_4357},
{"f_4360c-backend.scm",(void*)f_4360},
{"f_4363c-backend.scm",(void*)f_4363},
{"f_4366c-backend.scm",(void*)f_4366},
{"f_4369c-backend.scm",(void*)f_4369},
{"f_4540c-backend.scm",(void*)f_4540},
{"f_4372c-backend.scm",(void*)f_4372},
{"f_4375c-backend.scm",(void*)f_4375},
{"f_4533c-backend.scm",(void*)f_4533},
{"f_4514c-backend.scm",(void*)f_4514},
{"f_4525c-backend.scm",(void*)f_4525},
{"f_4378c-backend.scm",(void*)f_4378},
{"f_4465c-backend.scm",(void*)f_4465},
{"f_4468c-backend.scm",(void*)f_4468},
{"f_4471c-backend.scm",(void*)f_4471},
{"f_4474c-backend.scm",(void*)f_4474},
{"f_4490c-backend.scm",(void*)f_4490},
{"f_4493c-backend.scm",(void*)f_4493},
{"f_4496c-backend.scm",(void*)f_4496},
{"f_4499c-backend.scm",(void*)f_4499},
{"f_4381c-backend.scm",(void*)f_4381},
{"f_4384c-backend.scm",(void*)f_4384},
{"f_4387c-backend.scm",(void*)f_4387},
{"f_4437c-backend.scm",(void*)f_4437},
{"f_4440c-backend.scm",(void*)f_4440},
{"f_4390c-backend.scm",(void*)f_4390},
{"f_4393c-backend.scm",(void*)f_4393},
{"f_4425c-backend.scm",(void*)f_4425},
{"f_4428c-backend.scm",(void*)f_4428},
{"f_4399c-backend.scm",(void*)f_4399},
{"f_4408c-backend.scm",(void*)f_4408},
{"f_4411c-backend.scm",(void*)f_4411},
{"f_4320c-backend.scm",(void*)f_4320},
{"f_4325c-backend.scm",(void*)f_4325},
{"f_4329c-backend.scm",(void*)f_4329},
{"f_4339c-backend.scm",(void*)f_4339},
{"f_4332c-backend.scm",(void*)f_4332},
{"f_4164c-backend.scm",(void*)f_4164},
{"f_4171c-backend.scm",(void*)f_4171},
{"f_4307c-backend.scm",(void*)f_4307},
{"f_4174c-backend.scm",(void*)f_4174},
{"f_4177c-backend.scm",(void*)f_4177},
{"f_4180c-backend.scm",(void*)f_4180},
{"f_4185c-backend.scm",(void*)f_4185},
{"f_4195c-backend.scm",(void*)f_4195},
{"f_4201c-backend.scm",(void*)f_4201},
{"f_4254c-backend.scm",(void*)f_4254},
{"f_4264c-backend.scm",(void*)f_4264},
{"f_4204c-backend.scm",(void*)f_4204},
{"f_4227c-backend.scm",(void*)f_4227},
{"f_4237c-backend.scm",(void*)f_4237},
{"f_4207c-backend.scm",(void*)f_4207},
{"f_4210c-backend.scm",(void*)f_4210},
{"f_4017c-backend.scm",(void*)f_4017},
{"f_4156c-backend.scm",(void*)f_4156},
{"f_4037c-backend.scm",(void*)f_4037},
{"f_4114c-backend.scm",(void*)f_4114},
{"f_4118c-backend.scm",(void*)f_4118},
{"f_4122c-backend.scm",(void*)f_4122},
{"f_4126c-backend.scm",(void*)f_4126},
{"f_4148c-backend.scm",(void*)f_4148},
{"f_4144c-backend.scm",(void*)f_4144},
{"f_4136c-backend.scm",(void*)f_4136},
{"f_4134c-backend.scm",(void*)f_4134},
{"f_4130c-backend.scm",(void*)f_4130},
{"f_4055c-backend.scm",(void*)f_4055},
{"f_4058c-backend.scm",(void*)f_4058},
{"f_4061c-backend.scm",(void*)f_4061},
{"f_4103c-backend.scm",(void*)f_4103},
{"f_4064c-backend.scm",(void*)f_4064},
{"f_4067c-backend.scm",(void*)f_4067},
{"f_4070c-backend.scm",(void*)f_4070},
{"f_4085c-backend.scm",(void*)f_4085},
{"f_4090c-backend.scm",(void*)f_4090},
{"f_4073c-backend.scm",(void*)f_4073},
{"f_4020c-backend.scm",(void*)f_4020},
{"f_4034c-backend.scm",(void*)f_4034},
{"f_2532c-backend.scm",(void*)f_2532},
{"f_3985c-backend.scm",(void*)f_3985},
{"f_3991c-backend.scm",(void*)f_3991},
{"f_3995c-backend.scm",(void*)f_3995},
{"f_2535c-backend.scm",(void*)f_2535},
{"f_3979c-backend.scm",(void*)f_3979},
{"f_2539c-backend.scm",(void*)f_2539},
{"f_3974c-backend.scm",(void*)f_3974},
{"f_2542c-backend.scm",(void*)f_2542},
{"f_3969c-backend.scm",(void*)f_3969},
{"f_2545c-backend.scm",(void*)f_2545},
{"f_3935c-backend.scm",(void*)f_3935},
{"f_3938c-backend.scm",(void*)f_3938},
{"f_3941c-backend.scm",(void*)f_3941},
{"f_3944c-backend.scm",(void*)f_3944},
{"f_3947c-backend.scm",(void*)f_3947},
{"f_3950c-backend.scm",(void*)f_3950},
{"f_3852c-backend.scm",(void*)f_3852},
{"f_3855c-backend.scm",(void*)f_3855},
{"f_3858c-backend.scm",(void*)f_3858},
{"f_3871c-backend.scm",(void*)f_3871},
{"f_3894c-backend.scm",(void*)f_3894},
{"f_3897c-backend.scm",(void*)f_3897},
{"f_3900c-backend.scm",(void*)f_3900},
{"f_3903c-backend.scm",(void*)f_3903},
{"f_3881c-backend.scm",(void*)f_3881},
{"f_3884c-backend.scm",(void*)f_3884},
{"f_3843c-backend.scm",(void*)f_3843},
{"f_3815c-backend.scm",(void*)f_3815},
{"f_3818c-backend.scm",(void*)f_3818},
{"f_3835c-backend.scm",(void*)f_3835},
{"f_3821c-backend.scm",(void*)f_3821},
{"f_3824c-backend.scm",(void*)f_3824},
{"f_3799c-backend.scm",(void*)f_3799},
{"f_3803c-backend.scm",(void*)f_3803},
{"f_3785c-backend.scm",(void*)f_3785},
{"f_3788c-backend.scm",(void*)f_3788},
{"f_3769c-backend.scm",(void*)f_3769},
{"f_3773c-backend.scm",(void*)f_3773},
{"f_3751c-backend.scm",(void*)f_3751},
{"f_3754c-backend.scm",(void*)f_3754},
{"f_3731c-backend.scm",(void*)f_3731},
{"f_3695c-backend.scm",(void*)f_3695},
{"f_3707c-backend.scm",(void*)f_3707},
{"f_3698c-backend.scm",(void*)f_3698},
{"f_3676c-backend.scm",(void*)f_3676},
{"f_3679c-backend.scm",(void*)f_3679},
{"f_3657c-backend.scm",(void*)f_3657},
{"f_3660c-backend.scm",(void*)f_3660},
{"f_3638c-backend.scm",(void*)f_3638},
{"f_3641c-backend.scm",(void*)f_3641},
{"f_3619c-backend.scm",(void*)f_3619},
{"f_3615c-backend.scm",(void*)f_3615},
{"f_3563c-backend.scm",(void*)f_3563},
{"f_3596c-backend.scm",(void*)f_3596},
{"f_3566c-backend.scm",(void*)f_3566},
{"f_3584c-backend.scm",(void*)f_3584},
{"f_3569c-backend.scm",(void*)f_3569},
{"f_3572c-backend.scm",(void*)f_3572},
{"f_3530c-backend.scm",(void*)f_3530},
{"f_3514c-backend.scm",(void*)f_3514},
{"f_3517c-backend.scm",(void*)f_3517},
{"f_3520c-backend.scm",(void*)f_3520},
{"f_3473c-backend.scm",(void*)f_3473},
{"f_3476c-backend.scm",(void*)f_3476},
{"f_3497c-backend.scm",(void*)f_3497},
{"f_3501c-backend.scm",(void*)f_3501},
{"f_3504c-backend.scm",(void*)f_3504},
{"f_3479c-backend.scm",(void*)f_3479},
{"f_3495c-backend.scm",(void*)f_3495},
{"f_3487c-backend.scm",(void*)f_3487},
{"f_3482c-backend.scm",(void*)f_3482},
{"f_3209c-backend.scm",(void*)f_3209},
{"f_3212c-backend.scm",(void*)f_3212},
{"f_3423c-backend.scm",(void*)f_3423},
{"f_3419c-backend.scm",(void*)f_3419},
{"f_3218c-backend.scm",(void*)f_3218},
{"f_3412c-backend.scm",(void*)f_3412},
{"f_2520c-backend.scm",(void*)f_2520},
{"f_3405c-backend.scm",(void*)f_3405},
{"f_3224c-backend.scm",(void*)f_3224},
{"f_3391c-backend.scm",(void*)f_3391},
{"f_3390c-backend.scm",(void*)f_3390},
{"f_3353c-backend.scm",(void*)f_3353},
{"f_3356c-backend.scm",(void*)f_3356},
{"f_3359c-backend.scm",(void*)f_3359},
{"f_3374c-backend.scm",(void*)f_3374},
{"f_3362c-backend.scm",(void*)f_3362},
{"f_3365c-backend.scm",(void*)f_3365},
{"f_3368c-backend.scm",(void*)f_3368},
{"f_3350c-backend.scm",(void*)f_3350},
{"f_3260c-backend.scm",(void*)f_3260},
{"f_3334c-backend.scm",(void*)f_3334},
{"f_3337c-backend.scm",(void*)f_3337},
{"f_3310c-backend.scm",(void*)f_3310},
{"f_3313c-backend.scm",(void*)f_3313},
{"f_3316c-backend.scm",(void*)f_3316},
{"f_3319c-backend.scm",(void*)f_3319},
{"f_3322c-backend.scm",(void*)f_3322},
{"f_3263c-backend.scm",(void*)f_3263},
{"f_3266c-backend.scm",(void*)f_3266},
{"f_3293c-backend.scm",(void*)f_3293},
{"f_3297c-backend.scm",(void*)f_3297},
{"f_3300c-backend.scm",(void*)f_3300},
{"f_3269c-backend.scm",(void*)f_3269},
{"f_3291c-backend.scm",(void*)f_3291},
{"f_3283c-backend.scm",(void*)f_3283},
{"f_3272c-backend.scm",(void*)f_3272},
{"f_3275c-backend.scm",(void*)f_3275},
{"f_3247c-backend.scm",(void*)f_3247},
{"f_3233c-backend.scm",(void*)f_3233},
{"f_3236c-backend.scm",(void*)f_3236},
{"f_3239c-backend.scm",(void*)f_3239},
{"f_3176c-backend.scm",(void*)f_3176},
{"f_3172c-backend.scm",(void*)f_3172},
{"f_3158c-backend.scm",(void*)f_3158},
{"f_3161c-backend.scm",(void*)f_3161},
{"f_3155c-backend.scm",(void*)f_3155},
{"f_3151c-backend.scm",(void*)f_3151},
{"f_3137c-backend.scm",(void*)f_3137},
{"f_3140c-backend.scm",(void*)f_3140},
{"f_3089c-backend.scm",(void*)f_3089},
{"f_3110c-backend.scm",(void*)f_3110},
{"f_3106c-backend.scm",(void*)f_3106},
{"f_3092c-backend.scm",(void*)f_3092},
{"f_3095c-backend.scm",(void*)f_3095},
{"f_3058c-backend.scm",(void*)f_3058},
{"f_3054c-backend.scm",(void*)f_3054},
{"f_3012c-backend.scm",(void*)f_3012},
{"f_2980c-backend.scm",(void*)f_2980},
{"f_2983c-backend.scm",(void*)f_2983},
{"f_2945c-backend.scm",(void*)f_2945},
{"f_2971c-backend.scm",(void*)f_2971},
{"f_2957c-backend.scm",(void*)f_2957},
{"f_2961c-backend.scm",(void*)f_2961},
{"f_2964c-backend.scm",(void*)f_2964},
{"f_2948c-backend.scm",(void*)f_2948},
{"f_2913c-backend.scm",(void*)f_2913},
{"f_2916c-backend.scm",(void*)f_2916},
{"f_2919c-backend.scm",(void*)f_2919},
{"f_2922c-backend.scm",(void*)f_2922},
{"f_2884c-backend.scm",(void*)f_2884},
{"f_2887c-backend.scm",(void*)f_2887},
{"f_2890c-backend.scm",(void*)f_2890},
{"f_2893c-backend.scm",(void*)f_2893},
{"f_2847c-backend.scm",(void*)f_2847},
{"f_2850c-backend.scm",(void*)f_2850},
{"f_2853c-backend.scm",(void*)f_2853},
{"f_2856c-backend.scm",(void*)f_2856},
{"f_2814c-backend.scm",(void*)f_2814},
{"f_2817c-backend.scm",(void*)f_2817},
{"f_2820c-backend.scm",(void*)f_2820},
{"f_2823c-backend.scm",(void*)f_2823},
{"f_2795c-backend.scm",(void*)f_2795},
{"f_2798c-backend.scm",(void*)f_2798},
{"f_2768c-backend.scm",(void*)f_2768},
{"f_2771c-backend.scm",(void*)f_2771},
{"f_2717c-backend.scm",(void*)f_2717},
{"f_2727c-backend.scm",(void*)f_2727},
{"f_2730c-backend.scm",(void*)f_2730},
{"f_2733c-backend.scm",(void*)f_2733},
{"f_2659c-backend.scm",(void*)f_2659},
{"f_2662c-backend.scm",(void*)f_2662},
{"f_2665c-backend.scm",(void*)f_2665},
{"f_2668c-backend.scm",(void*)f_2668},
{"f_2671c-backend.scm",(void*)f_2671},
{"f_2674c-backend.scm",(void*)f_2674},
{"f_2522c-backend.scm",(void*)f_2522},
{"f_2530c-backend.scm",(void*)f_2530},
{"f_2490c-backend.scm",(void*)f_2490},
{"f_2502c-backend.scm",(void*)f_2502},
{"f_2510c-backend.scm",(void*)f_2510},
{"f_2494c-backend.scm",(void*)f_2494},
{"f_2467c-backend.scm",(void*)f_2467},
{"f_2481c-backend.scm",(void*)f_2481},
{"f_2473c-backend.scm",(void*)f_2473},
{"f_2446c-backend.scm",(void*)f_2446},
{"f_2452c-backend.scm",(void*)f_2452},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
