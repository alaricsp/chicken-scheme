/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-11-07 15:25
   Version 4.0.0x1 - SVN rev. 12338
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-11-03 on dill (Linux)
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[821];
static double C_possibly_force_alignment;


/* from getsize */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2340(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2340(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2335(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2335(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2396)
static void C_ccall f_2396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9027)
static void C_ccall f_9027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_ccall f_9031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8997)
static void C_ccall f_8997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8985)
static void C_ccall f_8985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8955)
static void C_ccall f_8955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8916)
static void C_ccall f_8916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8903)
static void C_ccall f_8903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8899)
static void C_ccall f_8899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8785)
static void C_ccall f_8785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8732)
static C_word C_fcall f_8732(C_word *a,C_word t0);
C_noret_decl(f_8325)
static void C_ccall f_8325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8412)
static void C_fcall f_8412(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8493)
static void C_ccall f_8493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8515)
static void C_fcall f_8515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_fcall f_8327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7870)
static void C_fcall f_7870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7897)
static void C_fcall f_7897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8092)
static void C_fcall f_8092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8101)
static void C_fcall f_8101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8110)
static void C_ccall f_8110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8132)
static void C_fcall f_8132(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_fcall f_7842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7081)
static void C_fcall f_7081(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7183)
static void C_fcall f_7183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7216)
static void C_fcall f_7216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7312)
static void C_fcall f_7312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7327)
static void C_ccall f_7327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7367)
static void C_fcall f_7367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7384)
static void C_fcall f_7384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7401)
static void C_fcall f_7401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7440)
static void C_fcall f_7440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7457)
static void C_fcall f_7457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7474)
static void C_fcall f_7474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7491)
static void C_fcall f_7491(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7508)
static void C_fcall f_7508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static void C_fcall f_7525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7542)
static void C_fcall f_7542(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7561)
static void C_ccall f_7561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7565)
static void C_ccall f_7565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7532)
static void C_ccall f_7532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7498)
static void C_ccall f_7498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7464)
static void C_ccall f_7464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7447)
static void C_ccall f_7447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7412)
static void C_ccall f_7412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7395)
static void C_ccall f_7395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_fcall f_7011(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7006)
static void C_fcall f_7006(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6943)
static void C_ccall f_6943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6946)
static void C_ccall f_6946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6949)
static void C_ccall f_6949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6952)
static void C_ccall f_6952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6958)
static void C_ccall f_6958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7002)
static void C_ccall f_7002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6969)
static void C_ccall f_6969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6964)
static void C_ccall f_6964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6518)
static void C_ccall f_6518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6877)
static void C_ccall f_6877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6886)
static void C_ccall f_6886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6545)
static void C_fcall f_6545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_fcall f_6554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6566)
static void C_fcall f_6566(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6578)
static void C_fcall f_6578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_fcall f_6618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6288)
static void C_ccall f_6288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6506)
static void C_ccall f_6506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6297)
static void C_ccall f_6297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6306)
static void C_ccall f_6306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_ccall f_6318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6333)
static void C_ccall f_6333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_ccall f_6348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6443)
static void C_ccall f_6443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6384)
static void C_ccall f_6384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_ccall f_6357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6263)
static void C_ccall f_6263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6223)
static void C_ccall f_6223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6199)
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6207)
static void C_ccall f_6207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6104)
static void C_ccall f_6104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6113)
static void C_fcall f_6113(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6142)
static void C_fcall f_6142(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6145)
static void C_fcall f_6145(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6129)
static void C_fcall f_6129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6035)
static void C_ccall f_6035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6049)
static void C_fcall f_6049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6065)
static void C_ccall f_6065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6068)
static void C_ccall f_6068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6002)
static void C_ccall f_6002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6011)
static void C_ccall f_6011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_fcall f_5251(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5264)
static void C_ccall f_5264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_fcall f_5279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5291)
static void C_ccall f_5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5318)
static void C_ccall f_5318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5928)
static void C_ccall f_5928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5897)
static void C_fcall f_5897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5900)
static void C_ccall f_5900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_fcall f_5345(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static void C_ccall f_5348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_fcall f_5859(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5351)
static void C_ccall f_5351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_fcall f_5802(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5823)
static void C_fcall f_5823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5724)
static void C_ccall f_5724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5766)
static void C_fcall f_5766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5733)
static void C_fcall f_5733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_fcall f_5742(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5687)
static void C_fcall f_5687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5654)
static void C_ccall f_5654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_fcall f_5377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_ccall f_5395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_ccall f_5398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_ccall f_5410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_fcall f_5437(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5367)
static void C_ccall f_5367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_fcall f_4989(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_fcall f_4818(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_fcall f_4824(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_fcall f_5020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_fcall f_5027(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_fcall f_5116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_fcall f_4855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_fcall f_5162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_fcall f_5177(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5233)
static void C_ccall f_5233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5193)
static void C_fcall f_5193(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5239)
static void C_fcall f_5239(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_fcall f_4532(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_fcall f_4718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_fcall f_4721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_fcall f_4767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_fcall f_4571(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_fcall f_4535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_fcall f_4548(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_fcall f_4281(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_fcall f_4319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_fcall f_4340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4482)
static void C_ccall f_4482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4405)
static void C_fcall f_4405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4361)
static void C_ccall f_4361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4396)
static void C_ccall f_4396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_fcall f_4132(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_fcall f_4153(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_fcall f_4195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_fcall f_3985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_fcall f_3988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_fcall f_2500(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3953)
static void C_fcall f_3953(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_fcall f_2503(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_fcall f_3839(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3862)
static void C_ccall f_3862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_fcall f_3180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_fcall f_3186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2488)
static void C_ccall f_2488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3342)
static void C_fcall f_3342(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3278)
static void C_ccall f_3278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3108)
static void C_ccall f_3108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2852)
static void C_ccall f_2852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_fcall f_2685(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_fcall f_2490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_fcall f_2458(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8412)
static void C_fcall trf_8412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8412(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8412(t0,t1);}

C_noret_decl(trf_8515)
static void C_fcall trf_8515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8515(t0,t1);}

C_noret_decl(trf_8327)
static void C_fcall trf_8327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8327(t0,t1);}

C_noret_decl(trf_7870)
static void C_fcall trf_7870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7870(t0,t1);}

C_noret_decl(trf_7897)
static void C_fcall trf_7897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7897(t0,t1);}

C_noret_decl(trf_8092)
static void C_fcall trf_8092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8092(t0,t1);}

C_noret_decl(trf_8101)
static void C_fcall trf_8101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8101(t0,t1);}

C_noret_decl(trf_8132)
static void C_fcall trf_8132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8132(t0,t1);}

C_noret_decl(trf_7842)
static void C_fcall trf_7842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7842(t0,t1);}

C_noret_decl(trf_7081)
static void C_fcall trf_7081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7081(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7081(t0,t1);}

C_noret_decl(trf_7183)
static void C_fcall trf_7183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7183(t0,t1);}

C_noret_decl(trf_7216)
static void C_fcall trf_7216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7216(t0,t1);}

C_noret_decl(trf_7312)
static void C_fcall trf_7312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7312(t0,t1);}

C_noret_decl(trf_7367)
static void C_fcall trf_7367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7367(t0,t1);}

C_noret_decl(trf_7384)
static void C_fcall trf_7384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7384(t0,t1);}

C_noret_decl(trf_7401)
static void C_fcall trf_7401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7401(t0,t1);}

C_noret_decl(trf_7440)
static void C_fcall trf_7440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7440(t0,t1);}

C_noret_decl(trf_7457)
static void C_fcall trf_7457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7457(t0,t1);}

C_noret_decl(trf_7474)
static void C_fcall trf_7474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7474(t0,t1);}

C_noret_decl(trf_7491)
static void C_fcall trf_7491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7491(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7491(t0,t1);}

C_noret_decl(trf_7508)
static void C_fcall trf_7508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7508(t0,t1);}

C_noret_decl(trf_7525)
static void C_fcall trf_7525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7525(t0,t1);}

C_noret_decl(trf_7542)
static void C_fcall trf_7542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7542(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7542(t0,t1);}

C_noret_decl(trf_7011)
static void C_fcall trf_7011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7011(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7011(t0,t1,t2);}

C_noret_decl(trf_7006)
static void C_fcall trf_7006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7006(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7006(t0,t1);}

C_noret_decl(trf_6545)
static void C_fcall trf_6545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6545(t0,t1);}

C_noret_decl(trf_6554)
static void C_fcall trf_6554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6554(t0,t1);}

C_noret_decl(trf_6566)
static void C_fcall trf_6566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6566(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6566(t0,t1);}

C_noret_decl(trf_6578)
static void C_fcall trf_6578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6578(t0,t1);}

C_noret_decl(trf_6618)
static void C_fcall trf_6618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6618(t0,t1);}

C_noret_decl(trf_6113)
static void C_fcall trf_6113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6113(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6113(t0,t1,t2);}

C_noret_decl(trf_6142)
static void C_fcall trf_6142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6142(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6142(t0,t1);}

C_noret_decl(trf_6145)
static void C_fcall trf_6145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6145(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6145(t0,t1);}

C_noret_decl(trf_6129)
static void C_fcall trf_6129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6129(t0,t1);}

C_noret_decl(trf_6049)
static void C_fcall trf_6049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6049(t0,t1,t2);}

C_noret_decl(trf_5251)
static void C_fcall trf_5251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5251(t0,t1);}

C_noret_decl(trf_5279)
static void C_fcall trf_5279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5279(t0,t1);}

C_noret_decl(trf_5897)
static void C_fcall trf_5897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5897(t0,t1);}

C_noret_decl(trf_5345)
static void C_fcall trf_5345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5345(t0,t1);}

C_noret_decl(trf_5859)
static void C_fcall trf_5859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5859(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5859(t0,t1,t2,t3);}

C_noret_decl(trf_5802)
static void C_fcall trf_5802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5802(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5802(t0,t1);}

C_noret_decl(trf_5823)
static void C_fcall trf_5823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5823(t0,t1);}

C_noret_decl(trf_5766)
static void C_fcall trf_5766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5766(t0,t1);}

C_noret_decl(trf_5733)
static void C_fcall trf_5733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5733(t0,t1);}

C_noret_decl(trf_5742)
static void C_fcall trf_5742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5742(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5742(t0,t1);}

C_noret_decl(trf_5687)
static void C_fcall trf_5687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5687(t0,t1);}

C_noret_decl(trf_5377)
static void C_fcall trf_5377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5377(t0,t1);}

C_noret_decl(trf_5437)
static void C_fcall trf_5437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5437(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5437(t0,t1,t2,t3);}

C_noret_decl(trf_4989)
static void C_fcall trf_4989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4989(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4989(t0,t1,t2,t3);}

C_noret_decl(trf_4818)
static void C_fcall trf_4818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4818(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4818(t0,t1);}

C_noret_decl(trf_4824)
static void C_fcall trf_4824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4824(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4824(t0,t1,t2,t3);}

C_noret_decl(trf_5020)
static void C_fcall trf_5020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5020(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5020(t0,t1,t2,t3);}

C_noret_decl(trf_5027)
static void C_fcall trf_5027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5027(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5027(t0,t1);}

C_noret_decl(trf_5116)
static void C_fcall trf_5116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5116(t0,t1);}

C_noret_decl(trf_4855)
static void C_fcall trf_4855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4855(t0,t1);}

C_noret_decl(trf_5162)
static void C_fcall trf_5162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5162(t0,t1,t2);}

C_noret_decl(trf_5177)
static void C_fcall trf_5177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5177(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5177(t0,t1,t2,t3);}

C_noret_decl(trf_5193)
static void C_fcall trf_5193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5193(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5193(t0,t1);}

C_noret_decl(trf_5239)
static void C_fcall trf_5239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5239(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5239(t0,t1,t2,t3);}

C_noret_decl(trf_4532)
static void C_fcall trf_4532(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4532(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4532(t0,t1);}

C_noret_decl(trf_4718)
static void C_fcall trf_4718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4718(t0,t1);}

C_noret_decl(trf_4721)
static void C_fcall trf_4721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4721(t0,t1);}

C_noret_decl(trf_4767)
static void C_fcall trf_4767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4767(t0,t1);}

C_noret_decl(trf_4571)
static void C_fcall trf_4571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4571(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4571(t0,t1,t2);}

C_noret_decl(trf_4535)
static void C_fcall trf_4535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4535(t0,t1);}

C_noret_decl(trf_4548)
static void C_fcall trf_4548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4548(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4548(t0,t1,t2,t3);}

C_noret_decl(trf_4281)
static void C_fcall trf_4281(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4281(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4281(t0,t1);}

C_noret_decl(trf_4319)
static void C_fcall trf_4319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4319(t0,t1);}

C_noret_decl(trf_4340)
static void C_fcall trf_4340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4340(t0,t1);}

C_noret_decl(trf_4405)
static void C_fcall trf_4405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4405(t0,t1);}

C_noret_decl(trf_4132)
static void C_fcall trf_4132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4132(t0,t1);}

C_noret_decl(trf_4153)
static void C_fcall trf_4153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4153(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4153(t0,t1,t2,t3);}

C_noret_decl(trf_4222)
static void C_fcall trf_4222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4222(t0,t1,t2);}

C_noret_decl(trf_4195)
static void C_fcall trf_4195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4195(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4195(t0,t1,t2);}

C_noret_decl(trf_3985)
static void C_fcall trf_3985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3985(t0,t1);}

C_noret_decl(trf_3988)
static void C_fcall trf_3988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3988(t0,t1);}

C_noret_decl(trf_2500)
static void C_fcall trf_2500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2500(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2500(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3953)
static void C_fcall trf_3953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3953(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3953(t0,t1,t2,t3);}

C_noret_decl(trf_2503)
static void C_fcall trf_2503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2503(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2503(t0,t1,t2,t3);}

C_noret_decl(trf_3839)
static void C_fcall trf_3839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3839(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3839(t0,t1,t2,t3);}

C_noret_decl(trf_3180)
static void C_fcall trf_3180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3180(t0,t1);}

C_noret_decl(trf_3186)
static void C_fcall trf_3186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3186(t0,t1);}

C_noret_decl(trf_3342)
static void C_fcall trf_3342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3342(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3342(t0,t1);}

C_noret_decl(trf_2685)
static void C_fcall trf_2685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2685(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2685(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2490)
static void C_fcall trf_2490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2490(t0,t1);}

C_noret_decl(trf_2458)
static void C_fcall trf_2458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2458(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2458(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2414)){
C_save(t1);
C_rereclaim2(2414*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,821);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],12,"\003sysfor-each");
lf[5]=C_h_intern(&lf[5],17,"\010compilergen-list");
lf[6]=C_h_intern(&lf[6],11,"intersperse");
lf[7]=C_h_intern(&lf[7],18,"\010compilerunique-id");
lf[8]=C_h_intern(&lf[8],22,"\010compilergenerate-code");
lf[9]=C_h_intern(&lf[9],13,"\010compilerbomb");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[11]=C_h_intern(&lf[11],17,"lambda-literal-id");
lf[12]=C_h_intern(&lf[12],4,"find");
lf[13]=C_h_intern(&lf[13],17,"string-translate*");
lf[14]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[15]=C_h_intern(&lf[15],8,"->string");
lf[16]=C_h_intern(&lf[16],14,"\004coreimmediate");
lf[17]=C_h_intern(&lf[17],4,"bool");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[20]=C_h_intern(&lf[20],4,"char");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[22]=C_h_intern(&lf[22],3,"nil");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[24]=C_h_intern(&lf[24],3,"fix");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[26]=C_h_intern(&lf[26],3,"eof");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[29]=C_h_intern(&lf[29],12,"\004coreliteral");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[33]=C_h_intern(&lf[33],2,"if");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[37]=C_h_intern(&lf[37],9,"\004coreproc");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[39]=C_h_intern(&lf[39],9,"\004corebind");
lf[40]=C_h_intern(&lf[40],8,"\004coreref");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[43]=C_h_intern(&lf[43],10,"\004coreunbox");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[46]=C_h_intern(&lf[46],13,"\004coreupdate_i");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[48]=C_h_intern(&lf[48],11,"\004coreupdate");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[52]=C_h_intern(&lf[52],16,"\004coreupdatebox_i");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[55]=C_h_intern(&lf[55],14,"\004coreupdatebox");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[58]=C_h_intern(&lf[58],12,"\004coreclosure");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[63]=C_h_intern(&lf[63],8,"for-each");
lf[64]=C_h_intern(&lf[64],4,"iota");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[66]=C_h_intern(&lf[66],8,"\004corebox");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[69]=C_h_intern(&lf[69],10,"\004corelocal");
lf[70]=C_h_intern(&lf[70],13,"\004coresetlocal");
lf[71]=C_h_intern(&lf[71],11,"\004coreglobal");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[76]=C_h_intern(&lf[76],21,"\010compilerc-ify-string");
lf[77]=C_h_intern(&lf[77],14,"symbol->string");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[82]=C_h_intern(&lf[82],14,"\004coresetglobal");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[89]=C_h_intern(&lf[89],16,"\004coresetglobal_i");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[96]=C_h_intern(&lf[96],14,"\004coreundefined");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[98]=C_h_intern(&lf[98],9,"\004corecall");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[104]=C_h_intern(&lf[104],26,"lambda-literal-temporaries");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[106]=C_h_intern(&lf[106],22,"lambda-literal-looping");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[110]=C_h_intern(&lf[110],6,"unsafe");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[115]=C_h_intern(&lf[115],19,"no-procedure-checks");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[118]=C_h_intern(&lf[118],24,"\010compileremit-trace-info");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[121]=C_h_intern(&lf[121],16,"string-translate");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[126]=C_h_intern(&lf[126],27,"lambda-literal-closure-size");
lf[127]=C_h_intern(&lf[127],28,"\010compilersource-info->string");
lf[128]=C_h_intern(&lf[128],12,"\004corerecurse");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[132]=C_h_intern(&lf[132],16,"\004coredirect_call");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[134]=C_h_intern(&lf[134],13,"\004corecallunit");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[139]=C_h_intern(&lf[139],11,"\004corereturn");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[142]=C_h_intern(&lf[142],11,"\004coreinline");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[144]=C_h_intern(&lf[144],20,"\004coreinline_allocate");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[147]=C_h_intern(&lf[147],15,"\004coreinline_ref");
lf[148]=C_h_intern(&lf[148],34,"\010compilerforeign-result-conversion");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[150]=C_h_intern(&lf[150],18,"\004coreinline_update");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[153]=C_h_intern(&lf[153],36,"\010compilerforeign-argument-conversion");
lf[154]=C_h_intern(&lf[154],33,"\010compilerforeign-type-declaration");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[156]=C_h_intern(&lf[156],19,"\004coreinline_loc_ref");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[162]=C_h_intern(&lf[162],22,"\004coreinline_loc_update");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[168]=C_h_intern(&lf[168],11,"\004coreswitch");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[173]=C_h_intern(&lf[173],9,"\004corecond");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[177]=C_h_intern(&lf[177],13,"pair-for-each");
lf[178]=C_h_intern(&lf[178],13,"string-append");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[180]=C_h_intern(&lf[180],30,"\010compilerexternal-protos-first");
lf[181]=C_h_intern(&lf[181],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[182]=C_h_intern(&lf[182],22,"foreign-callback-stubs");
lf[183]=C_h_intern(&lf[183],29,"\010compilerforeign-declarations");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[186]=C_h_intern(&lf[186],28,"\010compilertarget-include-file");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[188]=C_h_intern(&lf[188],18,"\010compilerunit-name");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[190]=C_h_intern(&lf[190],19,"\010compilerused-units");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[192]=C_h_intern(&lf[192],27,"\010compilercompiler-arguments");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[198]=C_h_intern(&lf[198],18,"string-intersperse");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[202]=C_h_intern(&lf[202],7,"\003sysmap");
lf[203]=C_h_intern(&lf[203],12,"string-split");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[205]=C_h_intern(&lf[205],15,"chicken-version");
lf[206]=C_h_intern(&lf[206],18,"\003sysdecode-seconds");
lf[207]=C_h_intern(&lf[207],15,"current-seconds");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[212]=C_h_intern(&lf[212],23,"\003syslambda-info->string");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[222]=C_h_intern(&lf[222],9,"make-list");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[226]=C_h_intern(&lf[226],4,"none");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[237]=C_h_intern(&lf[237],8,"toplevel");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[240]=C_h_intern(&lf[240],27,"\010compileremit-unsafe-marker");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[253]=C_h_intern(&lf[253],21,"small-parameter-limit");
lf[254]=C_h_intern(&lf[254],11,"lset-adjoin");
lf[255]=C_h_intern(&lf[255],1,"=");
lf[256]=C_h_intern(&lf[256],32,"lambda-literal-callee-signatures");
lf[257]=C_h_intern(&lf[257],24,"lambda-literal-allocated");
lf[258]=C_h_intern(&lf[258],21,"lambda-literal-direct");
lf[259]=C_h_intern(&lf[259],33,"lambda-literal-rest-argument-mode");
lf[260]=C_h_intern(&lf[260],28,"lambda-literal-rest-argument");
lf[261]=C_h_intern(&lf[261],27,"\010compilermake-variable-list");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[263]=C_h_intern(&lf[263],27,"lambda-literal-customizable");
lf[264]=C_h_intern(&lf[264],29,"lambda-literal-argument-count");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[271]=C_h_intern(&lf[271],27,"\010compilermake-argument-list");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[311]=C_h_intern(&lf[311],6,"vector");
lf[312]=C_h_intern(&lf[312],23,"lambda-literal-external");
lf[313]=C_h_intern(&lf[313],14,"\003syscopy-bytes");
lf[314]=C_h_intern(&lf[314],11,"make-string");
lf[315]=C_h_intern(&lf[315],6,"modulo");
lf[316]=C_h_intern(&lf[316],3,"fx/");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[320]=C_h_intern(&lf[320],19,"\003sysundefined-value");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[331]=C_h_intern(&lf[331],23,"\010compilerencode-literal");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[333]=C_h_intern(&lf[333],32,"\010compilerblock-variable-literal\077");
lf[334]=C_h_intern(&lf[334],20,"\010compilerbig-fixnum\077");
lf[335]=C_h_intern(&lf[335],7,"sprintf");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[337]=C_h_intern(&lf[337],25,"\010compilerwords-per-flonum");
lf[338]=C_h_intern(&lf[338],6,"reduce");
lf[339]=C_h_intern(&lf[339],1,"+");
lf[340]=C_h_intern(&lf[340],12,"vector->list");
lf[341]=C_h_intern(&lf[341],14,"\010compilerwords");
lf[342]=C_h_intern(&lf[342],15,"\003sysbytevector\077");
lf[343]=C_h_intern(&lf[343],19,"\010compilerimmediate\077");
lf[344]=C_h_intern(&lf[344],19,"lambda-literal-body");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[357]=C_h_intern(&lf[357],4,"list");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[396]=C_h_intern(&lf[396],26,"\010compilertarget-stack-size");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[399]=C_h_intern(&lf[399],30,"\010compilertarget-heap-shrinkage");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[401]=C_h_intern(&lf[401],27,"\010compilertarget-heap-growth");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[403]=C_h_intern(&lf[403],33,"\010compilertarget-initial-heap-size");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[406]=C_h_intern(&lf[406],25,"\010compilertarget-heap-size");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[410]=C_h_intern(&lf[410],40,"\010compilerdisable-stack-overflow-checking");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[416]=C_h_intern(&lf[416],4,"fold");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[419]=C_h_intern(&lf[419],28,"\010compilerinsert-timer-checks");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[424]=C_h_intern(&lf[424],14,"no-argc-checks");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[471]=C_h_intern(&lf[471],16,"\010compilercleanup");
lf[472]=C_h_intern(&lf[472],18,"\010compilerdebugging");
lf[473]=C_h_intern(&lf[473],1,"o");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[479]=C_h_intern(&lf[479],18,"\010compilerreal-name");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[481]=C_h_intern(&lf[481],25,"emit-procedure-table-info");
lf[482]=C_h_intern(&lf[482],31,"generate-foreign-callback-stubs");
lf[483]=C_h_intern(&lf[483],31,"\010compilergenerate-foreign-stubs");
lf[484]=C_h_intern(&lf[484],29,"\010compilerforeign-lambda-stubs");
lf[485]=C_h_intern(&lf[485],36,"\010compilergenerate-external-variables");
lf[486]=C_h_intern(&lf[486],27,"\010compilerexternal-variables");
lf[487]=C_h_intern(&lf[487],1,"p");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[508]=C_h_intern(&lf[508],11,"string-copy");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[510]=C_h_intern(&lf[510],13,"list-tabulate");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[513]=C_h_intern(&lf[513],41,"\010compilergenerate-foreign-callback-header");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[523]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[526]=C_h_intern(&lf[526],4,"void");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[551]=C_h_intern(&lf[551],21,"foreign-stub-callback");
lf[552]=C_h_intern(&lf[552],16,"foreign-stub-cps");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[554]=C_h_intern(&lf[554],27,"foreign-stub-argument-names");
lf[555]=C_h_intern(&lf[555],17,"foreign-stub-body");
lf[556]=C_h_intern(&lf[556],17,"foreign-stub-name");
lf[557]=C_h_intern(&lf[557],24,"foreign-stub-return-type");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[560]=C_h_intern(&lf[560],27,"foreign-stub-argument-types");
lf[561]=C_h_intern(&lf[561],19,"\010compilerreal-name2");
lf[562]=C_h_intern(&lf[562],15,"foreign-stub-id");
lf[563]=C_h_intern(&lf[563],5,"float");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[565]=C_h_intern(&lf[565],8,"c-string");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[569]=C_h_intern(&lf[569],16,"nonnull-c-string");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[572]=C_h_intern(&lf[572],3,"ref");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[574]=C_h_intern(&lf[574],5,"const");
lf[575]=C_h_intern(&lf[575],7,"pointer");
lf[576]=C_h_intern(&lf[576],9,"c-pointer");
lf[577]=C_h_intern(&lf[577],15,"nonnull-pointer");
lf[578]=C_h_intern(&lf[578],17,"nonnull-c-pointer");
lf[579]=C_h_intern(&lf[579],8,"function");
lf[580]=C_h_intern(&lf[580],8,"instance");
lf[581]=C_h_intern(&lf[581],16,"nonnull-instance");
lf[582]=C_h_intern(&lf[582],12,"instance-ref");
lf[583]=C_h_intern(&lf[583],18,"\003syshash-table-ref");
lf[584]=C_h_intern(&lf[584],27,"\010compilerforeign-type-table");
lf[585]=C_h_intern(&lf[585],17,"nonnull-c-string*");
lf[586]=C_h_intern(&lf[586],25,"nonnull-unsigned-c-string");
lf[587]=C_h_intern(&lf[587],26,"nonnull-unsigned-c-string*");
lf[588]=C_h_intern(&lf[588],6,"symbol");
lf[589]=C_h_intern(&lf[589],9,"c-string*");
lf[590]=C_h_intern(&lf[590],17,"unsigned-c-string");
lf[591]=C_h_intern(&lf[591],18,"unsigned-c-string*");
lf[592]=C_h_intern(&lf[592],6,"double");
lf[593]=C_h_intern(&lf[593],16,"unsigned-integer");
lf[594]=C_h_intern(&lf[594],18,"unsigned-integer32");
lf[595]=C_h_intern(&lf[595],4,"long");
lf[596]=C_h_intern(&lf[596],7,"integer");
lf[597]=C_h_intern(&lf[597],9,"integer32");
lf[598]=C_h_intern(&lf[598],13,"unsigned-long");
lf[599]=C_h_intern(&lf[599],6,"number");
lf[600]=C_h_intern(&lf[600],9,"integer64");
lf[601]=C_h_intern(&lf[601],13,"c-string-list");
lf[602]=C_h_intern(&lf[602],14,"c-string-list*");
lf[603]=C_h_intern(&lf[603],3,"int");
lf[604]=C_h_intern(&lf[604],5,"int32");
lf[605]=C_h_intern(&lf[605],5,"short");
lf[606]=C_h_intern(&lf[606],14,"unsigned-short");
lf[607]=C_h_intern(&lf[607],13,"scheme-object");
lf[608]=C_h_intern(&lf[608],13,"unsigned-char");
lf[609]=C_h_intern(&lf[609],12,"unsigned-int");
lf[610]=C_h_intern(&lf[610],14,"unsigned-int32");
lf[611]=C_h_intern(&lf[611],4,"byte");
lf[612]=C_h_intern(&lf[612],13,"unsigned-byte");
lf[613]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[614]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[625]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[626]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[627]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[628]=C_h_intern(&lf[628],36,"foreign-callback-stub-argument-types");
lf[629]=C_h_intern(&lf[629],33,"foreign-callback-stub-return-type");
lf[630]=C_h_intern(&lf[630],24,"foreign-callback-stub-id");
lf[631]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[632]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[633]=C_h_intern(&lf[633],32,"foreign-callback-stub-qualifiers");
lf[634]=C_h_intern(&lf[634],26,"foreign-callback-stub-name");
lf[635]=C_h_intern(&lf[635],4,"quit");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[652]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[653]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[655]=C_h_intern(&lf[655],11,"byte-vector");
lf[656]=C_h_intern(&lf[656],19,"nonnull-byte-vector");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[658]=C_h_intern(&lf[658],4,"blob");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[660]=C_h_intern(&lf[660],9,"u16vector");
lf[661]=C_h_intern(&lf[661],17,"nonnull-u16vector");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[663]=C_h_intern(&lf[663],8,"s8vector");
lf[664]=C_h_intern(&lf[664],16,"nonnull-s8vector");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[666]=C_h_intern(&lf[666],9,"u32vector");
lf[667]=C_h_intern(&lf[667],17,"nonnull-u32vector");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[669]=C_h_intern(&lf[669],9,"s16vector");
lf[670]=C_h_intern(&lf[670],17,"nonnull-s16vector");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[672]=C_h_intern(&lf[672],9,"s32vector");
lf[673]=C_h_intern(&lf[673],17,"nonnull-s32vector");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[675]=C_h_intern(&lf[675],9,"f32vector");
lf[676]=C_h_intern(&lf[676],17,"nonnull-f32vector");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[678]=C_h_intern(&lf[678],9,"f64vector");
lf[679]=C_h_intern(&lf[679],17,"nonnull-f64vector");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[683]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[703]=C_h_intern(&lf[703],3,"...");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[705]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_h_intern(&lf[708],9,"\003syserror");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[710]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[711]=C_h_intern(&lf[711],4,"enum");
lf[712]=C_h_intern(&lf[712],5,"union");
lf[713]=C_h_intern(&lf[713],6,"struct");
lf[714]=C_h_intern(&lf[714],8,"template");
lf[715]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[716]=C_h_intern(&lf[716],12,"nonnull-blob");
lf[717]=C_h_intern(&lf[717],8,"u8vector");
lf[718]=C_h_intern(&lf[718],16,"nonnull-u8vector");
lf[719]=C_h_intern(&lf[719],14,"scheme-pointer");
lf[720]=C_h_intern(&lf[720],22,"nonnull-scheme-pointer");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[815]=C_h_intern(&lf[815],17,"\003sysstring-append");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[817]=C_h_intern(&lf[817],5,"cons*");
lf[818]=C_h_intern(&lf[818],29,"\010compilerstring->c-identifier");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[820]=C_h_intern(&lf[820],6,"random");
C_register_lf2(lf,821,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2396,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2394 */
static void C_ccall f_2396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2397 in k2394 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2400 in k2397 in k2394 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=C_set_block_item(lf[0] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1 /* (set! gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2414,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2435,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9023,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9027,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 100  random */
t8=C_retrieve(lf[820]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,C_fix(16777216));}

/* k9025 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_9027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9031,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 100  current-seconds */
t3=C_retrieve(lf[207]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k9029 in k9025 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 100  sprintf */
t2=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[819],((C_word*)t0)[2],t1);}

/* k9021 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 99   string->c-identifier */
t2=C_retrieve(lf[818]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2453,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1 /* (set! unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[8]+1 /* (set! generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2455,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[481]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6031,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[471]+1 /* (set! cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6104,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[261]+1 /* (set! make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6193,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[271]+1 /* (set! make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6209,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[485]+1 /* (set! generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6225,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[181]+1 /* (set! generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6257,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[483]+1 /* (set! generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6275,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[482]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6508,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[513]+1 /* (set! generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6939,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[154]+1 /* (set! foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7004,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[153]+1 /* (set! foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7840,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[148]+1 /* (set! foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8325,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[331]+1 /* (set! encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8723,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8723,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8732,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8785,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t4;
f_8785(2,t6,lf[802]);}
else{
t6=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t4;
f_8785(2,t7,lf[803]);}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(C_word)C_fix((C_word)C_character_code(t2));
t8=f_8732(C_a_i(&a,4),t7);
/* c-backend.scm: 1381 string-append */
t9=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t4,lf[804],t8);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t7=t4;
f_8785(2,t7,lf[805]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t7=t4;
f_8785(2,t7,lf[806]);}
else{
t7=C_retrieve(lf[320]);
t8=(C_word)C_eqp(t7,t2);
if(C_truep(t8)){
t9=t4;
f_8785(2,t9,lf[807]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8903,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1386 big-fixnum? */
t10=C_retrieve(lf[334]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8916,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1395 number->string */
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_i_string_length(t9);
t11=f_8732(C_a_i(&a,4),t10);
/* c-backend.scm: 1398 string-append */
t12=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t12))(5,t12,t4,lf[813],t11,t9);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1403 bomb */
t9=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t4,lf[814],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8955,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=(C_word)stub2335(C_SCHEME_UNDEFINED,t10);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,1,t12);
t14=t2;
t15=(C_word)stub2340(C_SCHEME_UNDEFINED,t14);
t16=f_8732(C_a_i(&a,4),t15);
/* c-backend.scm: 1406 string-append */
t17=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,t9,t13,t16);}
else{
t9=t2;
t10=(C_word)stub2340(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8985,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=(C_word)stub2335(C_SCHEME_UNDEFINED,t12);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8732(C_a_i(&a,4),t10);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8997,a[2]=t16,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8999,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1416 list-tabulate */
t19=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t10,t18);}}}}}}}}}}}}

/* a8998 in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8999,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1416 encode-literal */
t4=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k8995 in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1413 cons* */
t2=C_retrieve(lf[817]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8983 in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1412 string-intersperse */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[816]);}

/* k8953 in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1405 ##sys#string-append */
t2=C_retrieve(lf[815]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8914 in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1395 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[811],t1,lf[812]);}

/* k8901 in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8903,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8899,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1393 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1387 string-append */
t14=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[3],lf[810],t13);}}

/* k8897 in k8901 in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1393 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[808],t1,lf[809]);}

/* k8783 in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8785,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1377 string-append */
t4=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static C_word C_fcall f_8732(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* ##compiler#foreign-result-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8325,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8327,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[608]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[776]);}
else{
t8=(C_word)C_eqp(t5,lf[603]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[604]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[777]);}
else{
t10=(C_word)C_eqp(t5,lf[609]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[610]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[778]);}
else{
t12=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[779]);}
else{
t13=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[780]);}
else{
t14=(C_word)C_eqp(t5,lf[611]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[781]);}
else{
t15=(C_word)C_eqp(t5,lf[612]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[782]);}
else{
t16=(C_word)C_eqp(t5,lf[563]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[592]));
if(C_truep(t17)){
/* c-backend.scm: 1315 sprintf */
t18=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[783],t3);}
else{
t18=(C_word)C_eqp(t5,lf[599]);
if(C_truep(t18)){
/* c-backend.scm: 1316 sprintf */
t19=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[784],t3);}
else{
t19=(C_word)C_eqp(t5,lf[569]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8412,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8412(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[565]);
if(C_truep(t21)){
t22=t20;
f_8412(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[578]);
if(C_truep(t22)){
t23=t20;
f_8412(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[589]);
if(C_truep(t23)){
t24=t20;
f_8412(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[585]);
if(C_truep(t24)){
t25=t20;
f_8412(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[590]);
if(C_truep(t25)){
t26=t20;
f_8412(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[591]);
if(C_truep(t26)){
t27=t20;
f_8412(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[586]);
if(C_truep(t27)){
t28=t20;
f_8412(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[587]);
if(C_truep(t28)){
t29=t20;
f_8412(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t29)){
t30=t20;
f_8412(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[601]);
t31=t20;
f_8412(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[602])));}}}}}}}}}}}}}}}}}}}}

/* k8410 in ##compiler#foreign-result-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_8412(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8412,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1320 sprintf */
t2=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[785],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[576]);
if(C_truep(t2)){
/* c-backend.scm: 1321 sprintf */
t3=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[786],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[597]));
if(C_truep(t4)){
/* c-backend.scm: 1322 sprintf */
t5=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[787],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t5)){
/* c-backend.scm: 1323 sprintf */
t6=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[788],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t7)){
/* c-backend.scm: 1324 sprintf */
t8=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[789],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t8)){
/* c-backend.scm: 1325 sprintf */
t9=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[790],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[598]);
if(C_truep(t9)){
/* c-backend.scm: 1326 sprintf */
t10=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[791],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[792]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[526]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[607]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[793]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1330 ##sys#hash-table-ref */
t14=C_retrieve(lf[583]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[584]),((C_word*)t0)[3]);}
else{
t14=t13;
f_8493(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k8491 in k8410 in ##compiler#foreign-result-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8493,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1332 foreign-result-conversion */
t4=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8515(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8515(t3,C_SCHEME_FALSE);}}}

/* k8513 in k8491 in k8410 in ##compiler#foreign-result-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_8515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[577]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[578]));
if(C_truep(t4)){
/* c-backend.scm: 1336 sprintf */
t5=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[4],lf[794],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[572]);
if(C_truep(t5)){
/* c-backend.scm: 1338 sprintf */
t6=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[4],lf[795],((C_word*)t0)[3]);}
else{
t6=(C_word)C_eqp(t2,lf[580]);
if(C_truep(t6)){
/* c-backend.scm: 1340 sprintf */
t7=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[4],lf[796],((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(t2,lf[581]);
if(C_truep(t7)){
/* c-backend.scm: 1342 sprintf */
t8=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[4],lf[797],((C_word*)t0)[3]);}
else{
t8=(C_word)C_eqp(t2,lf[582]);
if(C_truep(t8)){
/* c-backend.scm: 1344 sprintf */
t9=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[4],lf[798],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1345 foreign-result-conversion */
t11=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t11))(4,t11,((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(t2,lf[575]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[576]));
if(C_truep(t11)){
/* c-backend.scm: 1347 sprintf */
t12=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t12))(4,t12,((C_word*)t0)[4],lf[799],((C_word*)t0)[3]);}
else{
t12=(C_word)C_eqp(t2,lf[579]);
if(C_truep(t12)){
/* c-backend.scm: 1348 sprintf */
t13=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t13))(4,t13,((C_word*)t0)[4],lf[800],((C_word*)t0)[3]);}
else{
t13=(C_word)C_eqp(t2,lf[711]);
if(C_truep(t13)){
/* c-backend.scm: 1349 sprintf */
t14=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[4],lf[801],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1350 err */
t14=((C_word*)t0)[2];
f_8327(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
/* c-backend.scm: 1351 err */
t2=((C_word*)t0)[2];
f_8327(t2,((C_word*)t0)[4]);}}

/* err in ##compiler#foreign-result-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_8327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8327,NULL,2,t0,t1);}
/* c-backend.scm: 1306 quit */
t2=C_retrieve(lf[635]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[775],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7840,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[607]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[722]);}
else{
t6=(C_word)C_eqp(t4,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[608]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[723]);}
else{
t8=(C_word)C_eqp(t4,lf[611]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7870,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_7870(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[603]);
if(C_truep(t10)){
t11=t9;
f_7870(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[609]);
if(C_truep(t11)){
t12=t9;
f_7870(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[610]);
t13=t9;
f_7870(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[612])));}}}}}}

/* k7868 in ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7870,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[724]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[725]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[726]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[598]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[727]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_7897(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[599]);
t8=t6;
f_7897(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[563])));}}}}}}

/* k7895 in k7868 in ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7897,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[728]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[597]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[729]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[600]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[730]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[731]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[732]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[575]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[733]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[577]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[734]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[719]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[735]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[720]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[736]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[576]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[737]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[578]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[738]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[739]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[716]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[740]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[655]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[741]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[656]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[742]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[717]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[743]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[718]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[744]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[660]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[745]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[661]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[746]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[666]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[747]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[667]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[748]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[663]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[749]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[664]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[750]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[669]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[751]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[670]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[752]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[753]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[673]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[754]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[755]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[676]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[756]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[678]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[757]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[679]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[758]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[565]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8092(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
if(C_truep(t36)){
t37=t35;
f_8092(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t38=t35;
f_8092(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[591])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8090 in k7895 in k7868 in ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_8092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8092,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[759]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[569]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8101(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[585]);
if(C_truep(t4)){
t5=t3;
f_8101(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[586]);
if(C_truep(t5)){
t6=t3;
f_8101(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
t7=t3;
f_8101(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[588])));}}}}}

/* k8099 in k8090 in k7895 in k7868 in ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_8101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8101,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[760]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[761]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1279 ##sys#hash-table-ref */
t4=C_retrieve(lf[583]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[584]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8110(2,t4,C_SCHEME_FALSE);}}}}

/* k8108 in k8099 in k8090 in k7895 in k7868 in ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8110,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1281 foreign-argument-conversion */
t4=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8132(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8132(t3,C_SCHEME_FALSE);}}}

/* k8130 in k8108 in k8099 in k8090 in k7895 in k7868 in ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_8132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8132,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[575]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[762]);}
else{
t4=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[763]);}
else{
t5=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[764]);}
else{
t6=(C_word)C_eqp(t2,lf[578]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[765]);}
else{
t7=(C_word)C_eqp(t2,lf[580]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[766]);}
else{
t8=(C_word)C_eqp(t2,lf[581]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[767]);}
else{
t9=(C_word)C_eqp(t2,lf[579]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[768]);}
else{
t10=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1292 foreign-argument-conversion */
t12=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t12))(3,t12,((C_word*)t0)[3],t11);}
else{
t11=(C_word)C_eqp(t2,lf[711]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[769]);}
else{
t12=(C_word)C_eqp(t2,lf[572]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8209,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 1295 foreign-type-declaration */
t15=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t13,t14,lf[772]);}
else{
t13=(C_word)C_eqp(t2,lf[582]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1298 string-append */
t15=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t15))(5,t15,((C_word*)t0)[3],lf[773],t14,lf[774]);}
else{
/* c-backend.scm: 1299 err */
t14=((C_word*)t0)[2];
f_7842(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm: 1300 err */
t2=((C_word*)t0)[2];
f_7842(t2,((C_word*)t0)[3]);}}

/* k8207 in k8130 in k8108 in k8099 in k8090 in k7895 in k7868 in ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1295 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[770],t1,lf[771]);}

/* err in ##compiler#foreign-argument-conversion in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7842,NULL,2,t0,t1);}
/* c-backend.scm: 1233 quit */
t2=C_retrieve(lf[635]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[721],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7004,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7006,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7011,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[607]);
if(C_truep(t7)){
/* c-backend.scm: 1141 str */
t8=t5;
f_7011(t8,t1,lf[638]);}
else{
t8=(C_word)C_eqp(t6,lf[20]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[611]));
if(C_truep(t9)){
/* c-backend.scm: 1142 str */
t10=t5;
f_7011(t10,t1,lf[639]);}
else{
t10=(C_word)C_eqp(t6,lf[608]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[612]));
if(C_truep(t11)){
/* c-backend.scm: 1143 str */
t12=t5;
f_7011(t12,t1,lf[640]);}
else{
t12=(C_word)C_eqp(t6,lf[609]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[593]));
if(C_truep(t13)){
/* c-backend.scm: 1144 str */
t14=t5;
f_7011(t14,t1,lf[641]);}
else{
t14=(C_word)C_eqp(t6,lf[610]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[594]));
if(C_truep(t15)){
/* c-backend.scm: 1145 str */
t16=t5;
f_7011(t16,t1,lf[642]);}
else{
t16=(C_word)C_eqp(t6,lf[603]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7081,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7081(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[596]);
t19=t17;
f_7081(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[17])));}}}}}}}

/* k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7081(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7081,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1146 str */
t2=((C_word*)t0)[7];
f_7011(t2,((C_word*)t0)[6],lf[643]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[604]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[597]));
if(C_truep(t3)){
/* c-backend.scm: 1147 str */
t4=((C_word*)t0)[7];
f_7011(t4,((C_word*)t0)[6],lf[644]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[600]);
if(C_truep(t4)){
/* c-backend.scm: 1148 str */
t5=((C_word*)t0)[7];
f_7011(t5,((C_word*)t0)[6],lf[645]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[605]);
if(C_truep(t5)){
/* c-backend.scm: 1149 str */
t6=((C_word*)t0)[7];
f_7011(t6,((C_word*)t0)[6],lf[646]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t6)){
/* c-backend.scm: 1150 str */
t7=((C_word*)t0)[7];
f_7011(t7,((C_word*)t0)[6],lf[647]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[606]);
if(C_truep(t7)){
/* c-backend.scm: 1151 str */
t8=((C_word*)t0)[7];
f_7011(t8,((C_word*)t0)[6],lf[648]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
if(C_truep(t8)){
/* c-backend.scm: 1152 str */
t9=((C_word*)t0)[7];
f_7011(t9,((C_word*)t0)[6],lf[649]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[563]);
if(C_truep(t9)){
/* c-backend.scm: 1153 str */
t10=((C_word*)t0)[7];
f_7011(t10,((C_word*)t0)[6],lf[650]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[599]));
if(C_truep(t11)){
/* c-backend.scm: 1154 str */
t12=((C_word*)t0)[7];
f_7011(t12,((C_word*)t0)[6],lf[651]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[577]));
if(C_truep(t13)){
/* c-backend.scm: 1156 str */
t14=((C_word*)t0)[7];
f_7011(t14,((C_word*)t0)[6],lf[652]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[576]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7183(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[578]);
if(C_truep(t16)){
t17=t15;
f_7183(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[719]);
t18=t15;
f_7183(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[720])));}}}}}}}}}}}}}

/* k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7183,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1157 str */
t2=((C_word*)t0)[7];
f_7011(t2,((C_word*)t0)[6],lf[653]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[602]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[654]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[655]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[656]));
if(C_truep(t5)){
/* c-backend.scm: 1160 str */
t6=((C_word*)t0)[7];
f_7011(t6,((C_word*)t0)[6],lf[657]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[658]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7216(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[716]);
if(C_truep(t8)){
t9=t7;
f_7216(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[717]);
t10=t7;
f_7216(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[718])));}}}}}}

/* k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7216,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1161 str */
t2=((C_word*)t0)[7];
f_7011(t2,((C_word*)t0)[6],lf[659]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[660]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[661]));
if(C_truep(t3)){
/* c-backend.scm: 1162 str */
t4=((C_word*)t0)[7];
f_7011(t4,((C_word*)t0)[6],lf[662]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[663]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[664]));
if(C_truep(t5)){
/* c-backend.scm: 1163 str */
t6=((C_word*)t0)[7];
f_7011(t6,((C_word*)t0)[6],lf[665]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[666]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[667]));
if(C_truep(t7)){
/* c-backend.scm: 1164 str */
t8=((C_word*)t0)[7];
f_7011(t8,((C_word*)t0)[6],lf[668]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[669]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[670]));
if(C_truep(t9)){
/* c-backend.scm: 1165 str */
t10=((C_word*)t0)[7];
f_7011(t10,((C_word*)t0)[6],lf[671]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[672]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[673]));
if(C_truep(t11)){
/* c-backend.scm: 1166 str */
t12=((C_word*)t0)[7];
f_7011(t12,((C_word*)t0)[6],lf[674]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[675]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[676]));
if(C_truep(t13)){
/* c-backend.scm: 1167 str */
t14=((C_word*)t0)[7];
f_7011(t14,((C_word*)t0)[6],lf[677]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[678]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[679]));
if(C_truep(t15)){
/* c-backend.scm: 1168 str */
t16=((C_word*)t0)[7];
f_7011(t16,((C_word*)t0)[6],lf[680]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[569]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7312(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[565]);
if(C_truep(t18)){
t19=t17;
f_7312(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[585]);
if(C_truep(t19)){
t20=t17;
f_7312(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t20)){
t21=t17;
f_7312(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t21)){
t22=t17;
f_7312(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t22)){
t23=t17;
f_7312(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
t24=t17;
f_7312(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[588])));}}}}}}}}}}}}}}}

/* k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7312,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1171 str */
t2=((C_word*)t0)[7];
f_7011(t2,((C_word*)t0)[6],lf[681]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[526]);
if(C_truep(t2)){
/* c-backend.scm: 1172 str */
t3=((C_word*)t0)[7];
f_7011(t3,((C_word*)t0)[6],lf[682]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1174 ##sys#hash-table-ref */
t4=C_retrieve(lf[583]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[584]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7327(2,t4,C_SCHEME_FALSE);}}}}

/* k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7327,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1176 foreign-type-declaration */
t4=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1177 str */
t2=((C_word*)t0)[3];
f_7011(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7367,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_7367(t6,(C_word)C_i_memq(t5,lf[715]));}
else{
t5=t3;
f_7367(t5,C_SCHEME_FALSE);}}
else{
/* c-backend.scm: 1227 err */
t2=((C_word*)t0)[2];
f_7006(t2,((C_word*)t0)[6]);}}}}

/* k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7367,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7378,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1184 string-append */
t4=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[683],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=t2;
f_7384(t5,(C_word)C_eqp(lf[572],t4));}
else{
t4=t2;
f_7384(t4,C_SCHEME_FALSE);}}}

/* k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7384,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7395,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1187 string-append */
t4=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[684],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7401(t4,(C_word)C_eqp(lf[714],t3));}
else{
t3=t2;
f_7401(t3,C_SCHEME_FALSE);}}}

/* k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7401,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7408,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7412,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1192 foreign-type-declaration */
t5=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[689]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7440(t5,(C_word)C_eqp(lf[574],t4));}
else{
t4=t2;
f_7440(t4,C_SCHEME_FALSE);}}}

/* k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7440,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7447,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1199 foreign-type-declaration */
t4=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7457(t5,(C_word)C_eqp(lf[713],t4));}
else{
t4=t2;
f_7457(t4,C_SCHEME_FALSE);}}}

/* k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7457,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7464,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1201 ->string */
t4=C_retrieve(lf[15]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7474(t5,(C_word)C_eqp(lf[712],t4));}
else{
t4=t2;
f_7474(t4,C_SCHEME_FALSE);}}}

/* k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7474,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7481,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1203 ->string */
t4=C_retrieve(lf[15]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7491(t5,(C_word)C_eqp(lf[711],t4));}
else{
t4=t2;
f_7491(t4,C_SCHEME_FALSE);}}}

/* k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7491,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7498,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1205 ->string */
t4=C_retrieve(lf[15]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7508(t5,(C_word)C_i_memq(t4,lf[710]));}
else{
t4=t2;
f_7508(t4,C_SCHEME_FALSE);}}}

/* k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7508,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1207 ->string */
t4=C_retrieve(lf[15]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7525(t5,(C_word)C_eqp(lf[582],t4));}
else{
t4=t2;
f_7525(t4,C_SCHEME_FALSE);}}}

/* k7523 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7525,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7532,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1209 ->string */
t4=C_retrieve(lf[15]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7542(t4,(C_word)C_eqp(lf[579],t3));}
else{
t3=t2;
f_7542(t3,C_SCHEME_FALSE);}}}

/* k7540 in k7523 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7542(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7542,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7554,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7554(2,t6,lf[707]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7554(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[708]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[709],t4);}}}
else{
/* c-backend.scm: 1226 err */
t2=((C_word*)t0)[2];
f_7006(t2,((C_word*)t0)[4]);}}

/* k7552 in k7540 in k7523 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1215 foreign-type-declaration */
t3=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[706]);}

/* k7559 in k7552 in k7540 in k7523 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7569,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7571,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7570 in k7559 in k7552 in k7540 in k7523 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7571,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[703],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[704]);}
else{
/* c-backend.scm: 1222 foreign-type-declaration */
t4=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[705]);}}

/* k7567 in k7559 in k7552 in k7540 in k7523 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1218 string-intersperse */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[702]);}

/* k7563 in k7559 in k7552 in k7540 in k7523 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1214 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[699],((C_word*)t0)[2],lf[700],t1,lf[701]);}

/* k7530 in k7523 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1209 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[698],((C_word*)t0)[2]);}

/* k7513 in k7506 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1207 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[697],((C_word*)t0)[2]);}

/* k7496 in k7489 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1205 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[695],t1,lf[696],((C_word*)t0)[2]);}

/* k7479 in k7472 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1203 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[693],t1,lf[694],((C_word*)t0)[2]);}

/* k7462 in k7455 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1201 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[691],t1,lf[692],((C_word*)t0)[2]);}

/* k7445 in k7438 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1199 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[690],t1);}

/* k7410 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7416,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7420,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7422,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7421 in k7410 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7422,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[688]);}

/* k7418 in k7410 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1194 string-intersperse */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[687]);}

/* k7414 in k7410 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1191 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[685],t1,lf[686]);}

/* k7406 in k7399 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1190 str */
t2=((C_word*)t0)[3];
f_7011(t2,((C_word*)t0)[2],t1);}

/* k7393 in k7382 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1187 foreign-type-declaration */
t2=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7376 in k7365 in k7325 in k7310 in k7214 in k7181 in k7079 in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1184 foreign-type-declaration */
t2=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* str in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7011(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7011,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1139 string-append */
t3=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[637],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_7006(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7006,NULL,2,t0,t1);}
/* c-backend.scm: 1138 quit */
t2=C_retrieve(lf[635]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[636],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6939,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6943,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1120 foreign-callback-stub-name */
t5=C_retrieve(lf[634]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6946,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1121 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[633]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1122 foreign-callback-stub-return-type */
t3=C_retrieve(lf[629]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6952,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1123 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[628]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6950 in k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6952,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1125 make-argument-list */
t4=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[632]);}

/* k6956 in k6950 in k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6961,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1126 foreign-type-declaration */
t4=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[631]);}

/* k7000 in k6956 in k6950 in k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_7002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1126 gen */
t2=C_retrieve(lf[1]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k6959 in k6956 in k6950 in k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6964,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6969,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1127 pair-for-each */
t4=C_retrieve(lf[177]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6968 in k6959 in k6956 in k6950 in k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6969,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6973,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6990,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1129 foreign-type-declaration */
t8=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k6988 in a6968 in k6959 in k6956 in k6950 in k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1129 gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6971 in a6968 in k6959 in k6956 in k6950 in k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1130 gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6962 in k6959 in k6956 in k6950 in k6947 in k6944 in k6941 in ##compiler#generate-foreign-callback-header in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1132 gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6508(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6508,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6514,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6514,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6518,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1067 foreign-callback-stub-id */
t4=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6521,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1068 real-name2 */
t3=C_retrieve(lf[561]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6524,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1069 foreign-callback-stub-return-type */
t3=C_retrieve(lf[629]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1070 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[628]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1072 make-argument-list */
t4=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[627]);}

/* k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6533,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6535,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1099 fold */
t6=C_retrieve(lf[416]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[626],((C_word*)t0)[4],t1);}

/* k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1100 gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6937,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1102 cleanup */
t4=C_retrieve(lf[471]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6880(2,t3,C_SCHEME_UNDEFINED);}}

/* k6935 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1102 gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[624],t1,lf[625]);}

/* k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1103 generate-foreign-callback-header */
t3=C_retrieve(lf[513]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[623],((C_word*)t0)[2]);}

/* k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6886,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1104 gen */
t3=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[621],((C_word*)t0)[2],lf[622]);}

/* k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1105 gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[620]);}

/* k6887 in k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6892,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6922,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1106 for-each */
t4=*((C_word*)lf[63]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6921 in k6887 in k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6922,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6930,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1108 foreign-result-conversion */
t5=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[619]);}

/* k6928 in a6921 in k6887 in k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1108 gen */
t2=C_retrieve(lf[1]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[616],t1,((C_word*)t0)[2],lf[617],C_SCHEME_TRUE,lf[618]);}

/* k6890 in k6887 in k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[526],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_6895(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6920,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1113 foreign-argument-conversion */
t5=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k6918 in k6890 in k6887 in k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1113 gen */
t2=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[615],t1);}

/* k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1114 gen */
t3=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[614],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k6896 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[526],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_6901(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1115 gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k6899 in k6896 in k6893 in k6890 in k6887 in k6884 in k6881 in k6878 in k6875 in k6872 in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1116 gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[613]);}

/* compute-size in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6535,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6545,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6545(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t8)){
t9=t7;
f_6545(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t9)){
t10=t7;
f_6545(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t10)){
t11=t7;
f_6545(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t11)){
t12=t7;
f_6545(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[526]);
if(C_truep(t12)){
t13=t7;
f_6545(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t13)){
t14=t7;
f_6545(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t14)){
t15=t7;
f_6545(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t15)){
t16=t7;
f_6545(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t16)){
t17=t7;
f_6545(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[610]);
if(C_truep(t17)){
t18=t7;
f_6545(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[611]);
t19=t7;
f_6545(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[612])));}}}}}}}}}}}}

/* k6543 in compute-size in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6545,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[563]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6554(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t4)){
t5=t3;
f_6554(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[576]);
if(C_truep(t5)){
t6=t3;
f_6554(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t6)){
t7=t3;
f_6554(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t7)){
t8=t3;
f_6554(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t8)){
t9=t3;
f_6554(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t9)){
t10=t3;
f_6554(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t10)){
t11=t3;
f_6554(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
if(C_truep(t11)){
t12=t3;
f_6554(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[578]);
if(C_truep(t12)){
t13=t3;
f_6554(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[599]);
if(C_truep(t13)){
t14=t3;
f_6554(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[600]);
if(C_truep(t14)){
t15=t3;
f_6554(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
t16=t3;
f_6554(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[602])));}}}}}}}}}}}}}}

/* k6552 in k6543 in compute-size in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6554,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1081 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[564]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[565]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6566(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t4)){
t5=t3;
f_6566(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
if(C_truep(t5)){
t6=t3;
f_6566(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
t7=t3;
f_6566(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[591])));}}}}}

/* k6564 in k6552 in k6543 in compute-size in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6566(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6566,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1083 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[566],((C_word*)t0)[5],lf[567],((C_word*)t0)[5],lf[568]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[569]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6578(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[585]);
if(C_truep(t4)){
t5=t3;
f_6578(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[586]);
if(C_truep(t5)){
t6=t3;
f_6578(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
t7=t3;
f_6578(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[588])));}}}}}

/* k6576 in k6564 in k6552 in k6543 in compute-size in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6578,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1085 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[570],((C_word*)t0)[4],lf[571]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1087 ##sys#hash-table-ref */
t3=C_retrieve(lf[583]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[584]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6584(2,t3,C_SCHEME_FALSE);}}}

/* k6582 in k6576 in k6564 in k6552 in k6543 in compute-size in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6584,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1089 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6535(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[572]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6618,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6618(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[575]);
if(C_truep(t5)){
t6=t4;
f_6618(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t6)){
t7=t4;
f_6618(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t7)){
t8=t4;
f_6618(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[578]);
if(C_truep(t8)){
t9=t4;
f_6618(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[579]);
if(C_truep(t9)){
t10=t4;
f_6618(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[580]);
if(C_truep(t10)){
t11=t4;
f_6618(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[581]);
t12=t4;
f_6618(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[582])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6616 in k6582 in k6576 in k6564 in k6552 in k6543 in compute-size in k6531 in k6525 in k6522 in k6519 in k6516 in a6513 in generate-foreign-callback-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1094 string-append */
t2=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[573]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[574]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1095 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6535(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6275,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6281,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6281,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1000 foreign-stub-id */
t4=C_retrieve(lf[562]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6288,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1001 real-name2 */
t3=C_retrieve(lf[561]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1002 foreign-stub-argument-types */
t3=C_retrieve(lf[560]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6506,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1004 make-variable-list */
t5=C_retrieve(lf[261]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[559]);}

/* k6504 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6506,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[558],t1);
/* c-backend.scm: 1004 intersperse */
t3=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1005 foreign-stub-return-type */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1006 foreign-stub-name */
t3=C_retrieve(lf[556]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1007 foreign-stub-body */
t3=C_retrieve(lf[555]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1008 foreign-stub-argument-names */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_6312(2,t3,t1);}
else{
/* c-backend.scm: 1008 make-list */
t3=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1009 foreign-result-conversion */
t3=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[553]);}

/* k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1010 foreign-stub-cps */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1011 foreign-stub-callback */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1012 gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6495,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1014 cleanup */
t4=C_retrieve(lf[471]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6327(2,t3,C_SCHEME_UNDEFINED);}}

/* k6493 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1014 gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[549],t1,lf[550]);}

/* k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1016 gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[547],((C_word*)t0)[6],lf[548]);}
else{
t3=t2;
f_6330(2,t3,C_SCHEME_UNDEFINED);}}

/* k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1019 gen */
t3=C_retrieve(lf[1]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[542],((C_word*)t0)[2],lf[543],C_SCHEME_TRUE,lf[544],((C_word*)t0)[2],lf[545]);}
else{
/* c-backend.scm: 1021 gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[546],((C_word*)t0)[2],C_make_character(40));}}

/* k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[3]);}

/* k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1024 gen */
t3=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[537],C_SCHEME_TRUE,lf[538],((C_word*)t0)[2],lf[539]);}
else{
/* c-backend.scm: 1025 gen */
t3=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[540],C_SCHEME_TRUE,lf[541],((C_word*)t0)[2],C_make_character(40));}}

/* k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1027 gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[536]);}

/* k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1028 gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[535]);}

/* k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6443,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1037 iota */
t5=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k6471 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1029 for-each */
t2=*((C_word*)lf[63]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6442 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6443(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6443,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6451,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6463,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1034 symbol->string */
t7=*((C_word*)lf[77]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1034 sprintf */
t7=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[534],t3);}}

/* k6461 in a6442 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1032 foreign-type-declaration */
t2=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6449 in a6442 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1035 foreign-type-declaration */
t3=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[533]);}

/* k6453 in k6449 in a6442 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6459,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1036 foreign-argument-conversion */
t3=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6457 in k6453 in k6449 in a6442 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1031 gen */
t2=C_retrieve(lf[1]);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[530],((C_word*)t0)[3],C_make_character(41),t1,lf[531],((C_word*)t0)[2],lf[532]);}

/* k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1038 gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[529]);}
else{
t3=t2;
f_6354(2,t3,C_SCHEME_UNDEFINED);}}

/* k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6357,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1040 gen */
t4=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[520]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[526]);
if(C_truep(t4)){
/* c-backend.scm: 1051 gen */
t5=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1050 gen */
t5=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[528],((C_word*)t0)[2]);}}}

/* k6382 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1052 gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k6385 in k6382 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6421,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6425,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1053 make-argument-list */
t5=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[527]);}

/* k6423 in k6385 in k6382 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1053 intersperse */
t2=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k6419 in k6385 in k6382 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k6388 in k6385 in k6382 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[526]);
if(C_truep(t3)){
t4=t2;
f_6393(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1054 gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k6391 in k6388 in k6385 in k6382 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1055 gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[525]);}

/* k6394 in k6391 in k6388 in k6385 in k6382 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1057 gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[521],C_SCHEME_TRUE,lf[522]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1059 gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[523]);}
else{
/* c-backend.scm: 1060 gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[524]);}}}

/* k6361 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1042 gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[519],C_SCHEME_TRUE);}

/* k6364 in k6361 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1044 gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[515],C_SCHEME_TRUE,lf[516]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1046 gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[517]);}
else{
/* c-backend.scm: 1047 gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[518]);}}}

/* k6355 in k6352 in k6349 in k6346 in k6343 in k6340 in k6337 in k6334 in k6331 in k6328 in k6325 in k6322 in k6319 in k6316 in k6313 in k6310 in k6307 in k6304 in k6301 in k6298 in k6295 in k6289 in k6286 in k6283 in a6280 in ##compiler#generate-foreign-stubs in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1061 gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6263,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6262 in ##compiler#generate-foreign-callback-stub-prototypes in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6263,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6267,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 992  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k6265 in a6262 in ##compiler#generate-foreign-callback-stub-prototypes in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 993  generate-foreign-callback-header */
t3=C_retrieve(lf[513]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[514],((C_word*)t0)[2]);}

/* k6268 in k6265 in a6262 in ##compiler#generate-foreign-callback-stub-prototypes in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 994  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6225,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6229,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 977  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k6227 in ##compiler#generate-external-variables in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6234,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6233 in k6227 in ##compiler#generate-external-variables in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6234,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=(C_word)C_i_vector_ref(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(t2,C_fix(2));
t6=(C_truep(t5)?lf[511]:lf[512]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6255,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 983  foreign-type-declaration */
t8=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,t4,t3);}

/* k6253 in a6233 in k6227 in ##compiler#generate-external-variables in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 983  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6209,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6215,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 969  list-tabulate */
t5=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a6214 in ##compiler#make-argument-list in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6215,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6223,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 971  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6221 in a6214 in ##compiler#make-argument-list in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 971  string-append */
t2=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6193,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6199,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 964  list-tabulate */
t5=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a6198 in ##compiler#make-variable-list in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6199,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6207,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 966  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6205 in a6198 in ##compiler#make-variable-list in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 966  string-append */
t2=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[509],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6104,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6113,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6113(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6113(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6113,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6129,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6142,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_6142(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_6142(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_6142(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_6142(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_6142(t10,C_SCHEME_FALSE);}}}}}

/* k6140 in loop in ##compiler#cleanup in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6142(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6142,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6145,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_6145(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6152,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 955  string-copy */
t4=C_retrieve(lf[508]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_6129(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k6150 in k6140 in loop in ##compiler#cleanup in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6145(t3,t2);}

/* k6143 in k6140 in loop in ##compiler#cleanup in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6145(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_6129(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k6127 in loop in ##compiler#cleanup in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 958  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6113(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6031,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6035,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 920  gen */
t7=C_retrieve(lf[1]);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[505],C_SCHEME_TRUE,lf[506],t6,lf[507]);}

/* k6033 in emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6038,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6049,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6049(t6,t2,((C_word*)t0)[2]);}

/* doloop1226 in k6033 in emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_6049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6049,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 924  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[498]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 925  lambda-literal-id */
t5=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k6060 in doloop1226 in k6033 in emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6065,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 926  gen */
t3=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[503],t1,((C_word*)t0)[2],lf[504]);}

/* k6063 in k6060 in doloop1226 in k6033 in emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[237],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[188]))){
/* c-backend.scm: 929  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[499],C_retrieve(lf[188]),lf[500]);}
else{
/* c-backend.scm: 930  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[501]);}}
else{
/* c-backend.scm: 931  gen */
t4=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[502]);}}

/* k6066 in k6063 in k6060 in doloop1226 in k6033 in emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6049(t3,((C_word*)t0)[2],t2);}

/* k6036 in k6033 in emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 932  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[497]);}

/* k6039 in k6036 in k6033 in emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6044,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 933  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[496]);}

/* k6042 in k6039 in k6036 in k6033 in emit-procedure-table-info in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 934  gen */
t2=C_retrieve(lf[1]);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[489],C_SCHEME_TRUE,lf[490],C_SCHEME_TRUE,lf[491],C_SCHEME_TRUE,lf[492],C_SCHEME_TRUE,lf[493],C_SCHEME_TRUE,lf[494],C_SCHEME_TRUE,lf[495]);}

/* ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2455,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2458,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2490,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2500,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3985,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4132,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4281,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4532,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5239,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5162,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4855,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5020,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4818,a[2]=t2,a[3]=t19,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=t18,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5251,a[2]=t4,a[3]=t8,a[4]=t22,a[5]=t20,a[6]=t2,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
t25=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5998,a[2]=t12,a[3]=t13,a[4]=t14,a[5]=t8,a[6]=t15,a[7]=t24,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 903  debugging */
t26=C_retrieve(lf[472]);
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[487],lf[488]);}

/* k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5998,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 905  header */
t4=((C_word*)t0)[2];
f_3985(t4,t3);}

/* k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 906  declarations */
t3=((C_word*)t0)[2];
f_4132(t3,t2);}

/* k6003 in k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 907  generate-external-variables */
t3=C_retrieve(lf[485]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[486]));}

/* k6006 in k6003 in k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 908  generate-foreign-stubs */
t3=C_retrieve(lf[483]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[484]),((C_word*)t0)[3]);}

/* k6009 in k6006 in k6003 in k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 909  prototypes */
t3=((C_word*)t0)[2];
f_4281(t3,t2);}

/* k6012 in k6009 in k6006 in k6003 in k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 910  generate-foreign-callback-stubs */
t3=C_retrieve(lf[482]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[182]),((C_word*)t0)[2]);}

/* k6015 in k6012 in k6009 in k6006 in k6003 in k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 911  trampolines */
t3=((C_word*)t0)[2];
f_4532(t3,t2);}

/* k6018 in k6015 in k6012 in k6009 in k6006 in k6003 in k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 912  procedures */
t3=((C_word*)t0)[2];
f_5251(t3,t2);}

/* k6021 in k6018 in k6015 in k6012 in k6009 in k6006 in k6003 in k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6026,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 913  emit-procedure-table-info */
t3=C_retrieve(lf[481]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6024 in k6021 in k6018 in k6015 in k6012 in k6009 in k6006 in k6003 in k6000 in k5996 in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 484  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[480],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5251,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5257,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 727  lambda-literal-argument-count */
t4=C_retrieve(lf[264]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 728  lambda-literal-id */
t3=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 729  real-name */
t3=C_retrieve(lf[479]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5270,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 730  lambda-literal-allocated */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 731  lambda-literal-rest-argument */
t3=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5273,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 732  lambda-literal-customizable */
t5=C_retrieve(lf[263]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5995,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 733  lambda-literal-closure-size */
t4=C_retrieve(lf[126]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5279(t3,C_SCHEME_FALSE);}}

/* k5993 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5279(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5279,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 735  make-variable-list */
t5=C_retrieve(lf[261]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[478]);}

/* k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5288,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 736  make-argument-list */
t3=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[477]);}

/* k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5291,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 737  intersperse */
t4=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 738  intersperse */
t4=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 739  lambda-literal-external */
t3=C_retrieve(lf[312]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 740  lambda-literal-looping */
t3=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5303,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 741  lambda-literal-direct */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 742  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 743  lambda-literal-temporaries */
t3=C_retrieve(lf[104]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[188]))){
/* c-backend.scm: 745  string-append */
t3=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[188]),lf[475]);}
else{
t3=t2;
f_5312(2,t3,lf[476]);}}

/* k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 747  debugging */
t3=C_retrieve(lf[472]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[473],lf[474],((C_word*)t0)[14]);}
else{
t3=t2;
f_5315(2,t3,C_SCHEME_UNDEFINED);}}

/* k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 748  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5321,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5964,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 749  cleanup */
t4=C_retrieve(lf[471]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5962 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 749  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[469],t1,lf[470],C_SCHEME_TRUE);}

/* k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[237],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 758  gen */
t5=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[463]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 751  gen */
t5=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[468]);}}

/* k5923 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[466]:lf[467]);
/* c-backend.scm: 752  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k5926 in k5923 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 754  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[464]);}
else{
/* c-backend.scm: 755  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[465]);}}

/* k5929 in k5926 in k5923 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 756  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5945 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[188]))){
t3=t2;
f_5950(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 760  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[462]);}}

/* k5948 in k5945 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 761  gen */
t2=C_retrieve(lf[1]);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[456],C_SCHEME_TRUE,lf[457],C_SCHEME_TRUE,lf[458],C_SCHEME_TRUE,lf[459],((C_word*)t0)[2],lf[460],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[461],((C_word*)t0)[2]);}

/* k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 766  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5330(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 767  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[455]);}}

/* k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5897,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_5897(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_5897(t4,C_SCHEME_FALSE);}}

/* k5895 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5897,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 769  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[454]);}
else{
t2=((C_word*)t0)[2];
f_5333(2,t2,C_SCHEME_UNDEFINED);}}

/* k5898 in k5895 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 770  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_5333(2,t2,C_SCHEME_UNDEFINED);}}

/* k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[15]);}

/* k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 772  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[453]);}
else{
t3=t2;
f_5339(2,t3,C_SCHEME_UNDEFINED);}}

/* k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5342,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 773  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[452]);}

/* k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5345,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[226]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_5345(t5,t4);}
else{
t4=t2;
f_5345(t4,C_SCHEME_UNDEFINED);}}

/* k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5345,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 775  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[451]);}

/* k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 777  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[449],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5859,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5859(t8,t2,((C_word*)t0)[20],t4);}}

/* doloop979 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5859(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5859,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5869,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 781  gen */
t6=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[450],t2,C_make_character(59));}}

/* k5867 in doloop979 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5859(t4,((C_word*)t0)[2],t2,t3);}

/* k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[237],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 783  fold */
t6=C_retrieve(lf[416]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 817  gen */
t5=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[430]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5724,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_5802(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_5802(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k5800 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5802(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5802,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 831  gen */
t2=C_retrieve(lf[1]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[440],C_SCHEME_TRUE,lf[441],C_SCHEME_TRUE,lf[442],((C_word*)t0)[3],lf[443]);}
else{
/* c-backend.scm: 834  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[444],((C_word*)t0)[3],lf[445]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5814,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5814(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 836  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[448]);}}}

/* k5812 in k5800 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 837  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[447]);}
else{
t3=t2;
f_5817(2,t3,C_SCHEME_UNDEFINED);}}

/* k5815 in k5812 in k5800 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5823,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[110]);
t4=t2;
f_5823(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[410]))));}
else{
t3=t2;
f_5823(t3,C_SCHEME_FALSE);}}

/* k5821 in k5815 in k5812 in k5800 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 839  gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[446]);}
else{
t2=((C_word*)t0)[2];
f_5724(2,t2,C_SCHEME_UNDEFINED);}}

/* k5722 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5727,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5766,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[110]);
if(C_truep(t4)){
t5=t3;
f_5766(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[424]);
t6=t3;
f_5766(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5766(t4,C_SCHEME_FALSE);}}

/* k5764 in k5722 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5766(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[226]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 843  gen */
t4=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[434],((C_word*)t0)[3],lf[435],((C_word*)t0)[3],lf[436]);}
else{
t4=((C_word*)t0)[2];
f_5727(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 844  gen */
t3=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[437],((C_word*)t0)[3],lf[438],((C_word*)t0)[3],lf[439]);}}
else{
t2=((C_word*)t0)[2];
f_5727(2,t2,C_SCHEME_UNDEFINED);}}

/* k5725 in k5722 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5733,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5733(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_5733(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_5733(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k5731 in k5725 in k5722 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5733,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[419]))){
/* c-backend.scm: 846  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[433]);}
else{
t3=t2;
f_5736(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_5354(2,t2,C_SCHEME_UNDEFINED);}}

/* k5734 in k5731 in k5725 in k5722 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5742,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_5742(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_5742(t3,C_SCHEME_FALSE);}}

/* k5740 in k5734 in k5731 in k5725 in k5722 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5742(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 848  gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[431]);}
else{
/* c-backend.scm: 849  gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[432]);}}

/* k5658 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 818  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[429]);}

/* k5661 in k5658 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 819  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[428]);}

/* k5664 in k5661 in k5658 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 821  gen */
t5=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 822  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[427]);}}

/* k5667 in k5664 in k5661 in k5658 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 823  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[425],((C_word*)t0)[3],lf[426]);}

/* k5670 in k5667 in k5664 in k5661 in k5658 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5687,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[110]);
if(C_truep(t4)){
t5=t3;
f_5687(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[424]);
if(C_truep(t5)){
t6=t3;
f_5687(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_5687(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5685 in k5670 in k5667 in k5664 in k5661 in k5658 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 825  gen */
t2=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[421],((C_word*)t0)[2],lf[422],((C_word*)t0)[2],lf[423]);}
else{
t2=((C_word*)t0)[3];
f_5675(2,t2,C_SCHEME_UNDEFINED);}}

/* k5673 in k5670 in k5667 in k5664 in k5661 in k5658 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[419]))){
/* c-backend.scm: 826  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[420]);}
else{
t3=t2;
f_5678(2,t3,C_SCHEME_UNDEFINED);}}

/* k5676 in k5673 in k5670 in k5667 in k5664 in k5661 in k5658 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 827  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[417],((C_word*)t0)[2],lf[418]);}

/* a5645 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5646,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5654,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 783  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4861(3,t5,t4,t2);}

/* k5652 in a5645 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5577,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 785  gen */
t4=C_retrieve(lf[1]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[412],C_SCHEME_TRUE,lf[413],C_SCHEME_TRUE,lf[414],((C_word*)t0)[2],lf[415]);}

/* k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[410]))){
/* c-backend.scm: 789  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[411]);}
else{
t3=t2;
f_5580(2,t3,C_SCHEME_UNDEFINED);}}

/* k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[188]))){
t3=t2;
f_5583(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5614,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[403]))){
/* c-backend.scm: 792  gen */
t4=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[404],C_retrieve(lf[403]),lf[405]);}
else{
if(C_truep(C_retrieve(lf[406]))){
/* c-backend.scm: 794  gen */
t4=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[407],C_retrieve(lf[406]),lf[408],C_SCHEME_TRUE,lf[409]);}
else{
t4=t3;
f_5614(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k5612 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[401]))){
/* c-backend.scm: 797  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[402],C_retrieve(lf[401]),C_make_character(59));}
else{
t3=t2;
f_5617(2,t3,C_SCHEME_UNDEFINED);}}

/* k5615 in k5612 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[399]))){
/* c-backend.scm: 799  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[400],C_retrieve(lf[399]),C_make_character(59));}
else{
t3=t2;
f_5620(2,t3,C_SCHEME_UNDEFINED);}}

/* k5618 in k5615 in k5612 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[396]))){
/* c-backend.scm: 801  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[397],C_retrieve(lf[396]),lf[398]);}
else{
t2=((C_word*)t0)[2];
f_5583(2,t2,C_SCHEME_UNDEFINED);}}

/* k5581 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 802  gen */
t3=C_retrieve(lf[1]);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[389],((C_word*)t0)[3],lf[390],C_SCHEME_TRUE,lf[391],((C_word*)t0)[3],lf[392],C_SCHEME_TRUE,lf[393],C_SCHEME_TRUE,lf[394],C_SCHEME_TRUE,lf[395]);}

/* k5584 in k5581 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 807  gen */
t3=C_retrieve(lf[1]);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[383],((C_word*)t0)[2],lf[384],C_SCHEME_TRUE,lf[385],C_SCHEME_TRUE,lf[386],((C_word*)t0)[2],lf[387],C_SCHEME_TRUE,lf[388]);}

/* k5587 in k5584 in k5581 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 811  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[381],((C_word*)t0)[2],lf[382]);}

/* k5590 in k5587 in k5584 in k5581 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5592,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5354(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 813  gen */
t4=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[379],((C_word*)t0)[4],lf[380]);}}

/* k5599 in k5590 in k5587 in k5584 in k5581 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 814  literal-frame */
t3=((C_word*)t0)[2];
f_4818(t3,t2);}

/* k5602 in k5599 in k5590 in k5587 in k5584 in k5581 in k5578 in k5575 in k5569 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 815  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[377],((C_word*)t0)[2],lf[378]);}

/* k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5357,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[237],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_5377(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5377(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_5377(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_5377(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_5377(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5377,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[368]:lf[369]);
/* c-backend.scm: 860  gen */
t5=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[370],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5512,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[374]:lf[375]);
/* c-backend.scm: 886  gen */
t5=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[376]);}}
else{
t2=((C_word*)t0)[10];
f_5357(2,t2,C_SCHEME_UNDEFINED);}}

/* k5510 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 888  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[372]);}
else{
/* c-backend.scm: 889  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[373],((C_word*)t0)[3]);}}

/* k5513 in k5510 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5527,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 891  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5518(2,t3,C_SCHEME_UNDEFINED);}}

/* k5525 in k5513 in k5510 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5516 in k5513 in k5510 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 893  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[371]);}

/* k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[311]);
if(C_truep(t3)){
/* c-backend.scm: 861  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_5386(2,t4,C_SCHEME_UNDEFINED);}}

/* k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 862  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[366],((C_word*)t0)[5],lf[367]);}

/* k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5392,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 864  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5392(2,t3,C_SCHEME_UNDEFINED);}}

/* k5491 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 866  gen */
t3=C_retrieve(lf[1]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[362],C_SCHEME_TRUE,lf[363],C_SCHEME_TRUE,lf[364],((C_word*)t0)[6],lf[365]);}

/* k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[357]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 870  gen */
t5=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[358],((C_word*)t0)[6],lf[359]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[311]);
if(C_truep(t5)){
/* c-backend.scm: 871  gen */
t6=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[360],((C_word*)t0)[6],lf[361]);}
else{
t6=t2;
f_5398(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 872  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[356]);}

/* k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5462,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5466,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 873  make-argument-list */
t5=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[355]);}

/* k5464 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 873  intersperse */
t2=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5460 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 874  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[353],((C_word*)t0)[5],lf[354]);}

/* k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 876  gen */
t3=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[351],((C_word*)t0)[2],lf[352]);}

/* k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 878  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[349],((C_word*)t0)[3],lf[350]);}

/* k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 879  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[348]);}

/* k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5437,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5437(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1143 in k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5437(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5437,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5447,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 883  gen */
t6=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[347],t2,C_make_character(59));}}

/* k5445 in doloop1143 in k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5437(t4,((C_word*)t0)[2],t2,t3);}

/* k5420 in k5417 in k5414 in k5411 in k5408 in k5405 in k5402 in k5399 in k5396 in k5393 in k5390 in k5387 in k5384 in k5381 in k5375 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 884  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[345],((C_word*)t0)[3],lf[346]);}
else{
t3=((C_word*)t0)[2];
f_5357(2,t3,C_SCHEME_UNDEFINED);}}

/* k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5367,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 895  lambda-literal-body */
t4=C_retrieve(lf[344]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5365 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 894  expression */
t3=((C_word*)t0)[4];
f_2500(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k5358 in k5355 in k5352 in k5349 in k5346 in k5343 in k5340 in k5337 in k5334 in k5331 in k5328 in k5325 in k5322 in k5319 in k5316 in k5313 in k5310 in k5307 in k5304 in k5301 in k5298 in k5295 in k5292 in k5289 in k5286 in k5283 in k5277 in k5274 in k5271 in k5268 in k5265 in k5262 in k5259 in a5256 in procedures in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 900  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4861,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 662  immediate? */
t4=C_retrieve(lf[343]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[337]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 666  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4861(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4928,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4932,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 667  vector->list */
t6=*((C_word*)lf[340]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 668  block-variable-literal? */
t3=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k4940 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 669  bad-literal */
f_4855(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 671  ##sys#bytevector? */
t3=*((C_word*)lf[342]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k4958 in k4940 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 671  words */
t4=C_retrieve(lf[341]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4989(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 678  bad-literal */
f_4855(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k4958 in k4940 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4989(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4989,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5011,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 677  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4861(3,t8,t6,t7);}}

/* k5009 in loop in k4958 in k4940 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 677  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4989(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4965 in k4958 in k4940 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k4934 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k4930 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 667  reduce */
t2=C_retrieve(lf[338]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[339]+1),C_fix(0),t1);}

/* k4926 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k4897 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4903,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 666  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4861(3,t4,t2,t3);}

/* k4901 in k4897 in k4866 in literal-size in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4818,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4824,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4824(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop788 in literal-frame in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4824(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4824,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4834,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4853,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 656  sprintf */
t7=C_retrieve(lf[335]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[336],t2);}}

/* k4851 in doloop788 in literal-frame in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 656  gen-lit */
t2=((C_word*)t0)[4];
f_5020(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4832 in doloop788 in literal-frame in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4824(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5020(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5020,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5160,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 682  big-fixnum? */
t6=C_retrieve(lf[334]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_5027(t5,C_SCHEME_FALSE);}}

/* k5158 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5027(t2,(C_word)C_i_not(t1));}

/* k5025 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5027(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5027,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 683  gen */
t2=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[318],((C_word*)t0)[4],lf[319]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 684  block-variable-literal? */
t3=C_retrieve(lf[333]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k5031 in k5025 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5033,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[320]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 686  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[321]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[322]:lf[323]);
/* c-backend.scm: 688  gen */
t5=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 690  gen */
t5=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[324],t4,lf[325]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 693  c-ify-string */
t6=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 698  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[329]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5116(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_5116(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k5114 in k5031 in k5025 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5116,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 702  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[332]);}
else{
/* c-backend.scm: 705  bad-literal */
f_4855(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k5117 in k5114 in k5031 in k5025 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5129,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 703  encode-literal */
t4=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5127 in k5117 in k5114 in k5031 in k5025 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 703  gen-string-constant */
t2=((C_word*)t0)[3];
f_5162(t2,((C_word*)t0)[2],t1);}

/* k5120 in k5117 in k5114 in k5031 in k5025 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 704  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[330]);}

/* k5081 in k5031 in k5025 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5083,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5089,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 695  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[328]);}

/* k5087 in k5081 in k5031 in k5025 in gen-lit in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 696  gen */
t2=C_retrieve(lf[1]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[326],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[327]);}

/* bad-literal in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4855(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4855,NULL,2,t1,t2);}
/* c-backend.scm: 659  bomb */
t3=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[317],t2);}

/* gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5162,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5169,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 709  fx/ */
t5=*((C_word*)lf[316]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5172,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 710  modulo */
t3=*((C_word*)lf[315]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k5170 in k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5172,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5177,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5177(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop874 in k5170 in k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5177(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5177,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5193,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5193(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5193(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5214,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5229,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5233,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 716  string-like-substring */
f_5239(t7,((C_word*)t0)[4],t3,t8);}}

/* k5231 in doloop874 in k5170 in k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 716  c-ify-string */
t2=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5227 in doloop874 in k5170 in k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 716  gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5212 in doloop874 in k5170 in k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5177(t4,((C_word*)t0)[2],t2,t3);}

/* k5191 in doloop874 in k5170 in k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5193(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5193,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5204,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 715  string-like-substring */
f_5239(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5202 in k5191 in doloop874 in k5170 in k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 715  c-ify-string */
t2=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5198 in k5191 in doloop874 in k5170 in k5167 in gen-string-constant in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 715  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_5239(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5239,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5246,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 720  make-string */
t7=*((C_word*)lf[314]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k5244 in string-like-substring in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5249,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 721  ##sys#copy-bytes */
t3=C_retrieve(lf[313]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5247 in k5244 in string-like-substring in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4532(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4532,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4535,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4571,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4651,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4699,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4699,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4703,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 615  lambda-literal-argument-count */
t4=C_retrieve(lf[264]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 616  lambda-literal-rest-argument */
t5=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 617  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 618  lambda-literal-id */
t3=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 619  lambda-literal-customizable */
t3=C_retrieve(lf[263]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4816,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 620  lambda-literal-closure-size */
t4=C_retrieve(lf[126]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4718(t3,C_SCHEME_FALSE);}}

/* k4814 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4718(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4718,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_4721(t5,t4);}
else{
t3=t2;
f_4721(t3,C_SCHEME_UNDEFINED);}}

/* k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4721,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 622  lambda-literal-direct */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 624  gen */
t3=C_retrieve(lf[1]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[307],((C_word*)t0)[9],lf[308],C_SCHEME_TRUE,lf[309],((C_word*)t0)[9],lf[310]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4761(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 632  lambda-literal-allocated */
t4=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k4803 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4761(2,t3,t2);}
else{
/* c-backend.scm: 632  lambda-literal-external */
t3=C_retrieve(lf[312]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4759 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[226]);
t4=t2;
f_4767(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_4767(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4765 in k4759 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4767,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[311]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 635  lset-adjoin */
t4=C_retrieve(lf[254]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[255]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  lset-adjoin */
t4=C_retrieve(lf[254]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[255]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4785,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 637  lset-adjoin */
t3=C_retrieve(lf[254]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[255]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4783 in k4765 in k4759 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4779 in k4765 in k4759 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4775 in k4765 in k4759 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4731 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 626  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[305],((C_word*)t0)[3],lf[306]);}

/* k4734 in k4731 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 627  restore */
f_4535(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4737 in k4734 in k4731 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 628  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4740 in k4737 in k4734 in k4731 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 629  make-argument-list */
t3=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[304]);}

/* k4743 in k4740 in k4737 in k4734 in k4731 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4755,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 630  intersperse */
t4=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k4753 in k4743 in k4740 in k4737 in k4734 in k4731 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4746 in k4743 in k4740 in k4737 in k4734 in k4731 in k4725 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in a4698 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 631  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[303]);}

/* k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4669 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4670,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 641  gen */
t4=C_retrieve(lf[1]);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[298],t2,lf[299],C_SCHEME_TRUE,lf[300],t2,lf[301],t2,lf[302]);}

/* k4672 in a4669 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 643  gen */
t3=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[295],((C_word*)t0)[3],lf[296],((C_word*)t0)[3],lf[297]);}

/* k4675 in k4672 in a4669 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 644  restore */
f_4535(t2,((C_word*)t0)[3]);}

/* k4678 in k4675 in k4672 in a4669 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 645  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[294],((C_word*)t0)[2],C_make_character(44));}

/* k4681 in k4678 in k4675 in k4672 in a4669 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4693,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 646  make-argument-list */
t5=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[293]);}

/* k4695 in k4681 in k4678 in k4675 in k4672 in a4669 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 646  intersperse */
t2=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4691 in k4681 in k4678 in k4675 in k4672 in a4669 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4684 in k4681 in k4678 in k4675 in k4672 in a4669 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 647  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[292]);}

/* k4652 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 649  emitter */
t4=((C_word*)t0)[3];
f_4571(t4,t3,C_SCHEME_FALSE);}

/* k4666 in k4652 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4655 in k4652 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 650  emitter */
t3=((C_word*)t0)[2];
f_4571(t3,t2,C_SCHEME_TRUE);}

/* k4662 in k4655 in k4652 in k4649 in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4571(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4571,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4573 in emitter in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4573,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[287]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[288]);
/* c-backend.scm: 593  gen */
t6=C_retrieve(lf[1]);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[289],t2,C_make_character(114),t4,lf[290],C_SCHEME_TRUE,lf[291],t2,C_make_character(114),t5);}

/* k4575 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 595  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[285],((C_word*)t0)[4],lf[286]);}

/* k4578 in k4575 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 596  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[284],((C_word*)t0)[4],C_make_character(114));}

/* k4581 in k4578 in k4575 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 597  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_4586(2,t3,C_SCHEME_UNDEFINED);}}

/* k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 598  gen */
t3=C_retrieve(lf[1]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[280],((C_word*)t0)[4],lf[281],C_SCHEME_TRUE,lf[282],C_SCHEME_TRUE,lf[283],((C_word*)t0)[4],C_make_character(59));}

/* k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 601  restore */
f_4535(t2,((C_word*)t0)[4]);}

/* k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 602  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[279]);}

/* k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 604  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[277]);}
else{
/* c-backend.scm: 605  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[278]);}}

/* k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 606  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[276]);}

/* k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4604,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 607  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[275]);}
else{
t3=t2;
f_4604(2,t3,C_SCHEME_UNDEFINED);}}

/* k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 608  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[274]);}

/* k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 609  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[273]);}

/* k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4613,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4624,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 610  make-argument-list */
t6=C_retrieve(lf[271]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[272]);}

/* k4622 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 610  intersperse */
t2=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4618 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4611 in k4608 in k4605 in k4602 in k4599 in k4596 in k4593 in k4590 in k4587 in k4584 in k4581 in k4578 in k4575 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 611  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[270]);}

/* restore in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4535(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4535,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4548,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4548(t8,t3,t4,C_fix(0));}

/* doloop689 in restore in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4548(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4548,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4558,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 588  gen */
t5=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[267],t2,lf[268],t3,lf[269]);}}

/* k4556 in doloop689 in restore in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4548(t4,((C_word*)t0)[2],t2,t3);}

/* k4537 in restore in trampolines in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 589  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[265],((C_word*)t0)[2],lf[266]);}

/* prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4281(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4281,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4285,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 517  gen */
t5=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4309,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4313,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 520  lambda-literal-argument-count */
t4=C_retrieve(lf[264]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 521  lambda-literal-customizable */
t3=C_retrieve(lf[263]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 522  lambda-literal-closure-size */
t4=C_retrieve(lf[126]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4319(t3,C_SCHEME_FALSE);}}

/* k4528 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4319(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4319,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4516,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 523  make-variable-list */
t5=C_retrieve(lf[261]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[262]);}

/* k4514 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 523  intersperse */
t2=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 524  lambda-literal-id */
t3=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 525  lambda-literal-rest-argument */
t3=C_retrieve(lf[260]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 526  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[259]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 527  lambda-literal-direct */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 528  lambda-literal-allocated */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[253]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4508,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 530  lset-adjoin */
t7=C_retrieve(lf[254]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[255]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4340(t5,C_SCHEME_UNDEFINED);}}

/* k4506 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4340(t3,t2);}

/* k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4340,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 531  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4346,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4501,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 536  lambda-literal-callee-signatures */
t5=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k4499 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4481 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4482,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[253]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 535  lset-adjoin */
t7=C_retrieve(lf[254]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[255]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4491 in a4481 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[237],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4458,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[188]))){
/* c-backend.scm: 546  string-append */
t5=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[188]),lf[244]);}
else{
t5=t4;
f_4458(2,t5,lf[245]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 538  gen */
t5=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[251],((C_word*)t0)[5],lf[252],C_SCHEME_TRUE);}}

/* k4431 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 539  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[250]);}

/* k4434 in k4431 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[248]:lf[249]);
/* c-backend.scm: 540  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4437 in k4434 in k4431 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 542  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[246]);}
else{
/* c-backend.scm: 543  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[247]);}}

/* k4440 in k4437 in k4434 in k4431 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 544  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4456 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4461,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 547  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[242],t1,lf[243],C_SCHEME_TRUE);}

/* k4459 in k4456 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[240]))){
/* c-backend.scm: 549  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[241],C_SCHEME_TRUE);}
else{
t3=t2;
f_4464(2,t3,C_SCHEME_UNDEFINED);}}

/* k4462 in k4459 in k4456 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 550  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[239]);}

/* k4465 in k4462 in k4459 in k4456 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 551  gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[238],((C_word*)t0)[2]);}

/* k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 552  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4355(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 553  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[236]);}}

/* k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4405,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4405(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4405(t4,C_SCHEME_FALSE);}}

/* k4403 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4405,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 555  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[235]);}
else{
t2=((C_word*)t0)[2];
f_4358(2,t2,C_SCHEME_UNDEFINED);}}

/* k4406 in k4403 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 556  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_4358(2,t2,C_SCHEME_UNDEFINED);}}

/* k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[4]);}

/* k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 559  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 567  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k4391 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4396(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 569  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[234]);}}

/* k4394 in k4391 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 570  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k4365 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[226]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 562  gen */
t4=C_retrieve(lf[1]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[229],((C_word*)t0)[2],lf[230],C_SCHEME_TRUE,lf[231],((C_word*)t0)[2],lf[232]);}}

/* k4374 in k4365 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k4377 in k4374 in k4365 in k4359 in k4356 in k4353 in k4350 in k4347 in k4344 in k4341 in k4338 in k4335 in k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4311 in a4308 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 565  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[227],t2,lf[228]);}

/* k4286 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4293,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a4292 in k4286 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4293,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4297,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 574  gen */
t4=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[224],t2,lf[225]);}

/* k4295 in a4292 in k4286 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4300,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4307,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 575  make-list */
t4=C_retrieve(lf[222]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[223]);}

/* k4305 in k4295 in a4292 in k4286 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4298 in k4295 in a4292 in k4286 in k4283 in prototypes in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 576  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[221]);}

/* declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4132,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4139,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 488  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[220]);}

/* k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4275,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[190]));}

/* a4274 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4275,3,t0,t1,t2);}
/* c-backend.scm: 491  gen */
t3=C_retrieve(lf[1]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[216],t2,lf[217],C_SCHEME_TRUE,lf[218],t2,lf[219]);}

/* k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4145(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 495  gen */
t4=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[214],((C_word*)t0)[2],lf[215]);}}

/* k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 496  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[213]);}

/* k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4153,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4153(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4153(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4153,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4163,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 500  ##sys#lambda-info->string */
t6=C_retrieve(lf[212]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4169,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 502  gen */
t8=C_retrieve(lf[1]);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[210],((C_word*)t0)[5],lf[211],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4167 in k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4222(t6,t2,C_fix(0));}

/* doloop559 in k4167 in k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4222,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4232,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 509  gen */
t7=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k4230 in doloop559 in k4167 in k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4222(t3,((C_word*)t0)[2],t2);}

/* k4170 in k4167 in k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4195,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4195(t9,t2,t5);}

/* doloop571 in k4170 in k4167 in k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_4195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4195,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4205,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 512  gen */
t5=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[209]);}}

/* k4203 in doloop571 in k4170 in k4167 in k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4195(t3,((C_word*)t0)[2],t2);}

/* k4173 in k4170 in k4167 in k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 513  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[208]);}

/* k4176 in k4173 in k4170 in k4167 in k4161 in doloop543 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4153(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_3985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3985,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3988,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4005,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 454  current-seconds */
t5=C_retrieve(lf[207]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k4122 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 454  ##sys#decode-seconds */
t2=C_retrieve(lf[206]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_i_vector_ref(t1,C_fix(2));
t4=(C_word)C_i_vector_ref(t1,C_fix(3));
t5=(C_word)C_i_vector_ref(t1,C_fix(4));
t6=(C_word)C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4082,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 462  pad0 */
f_3988(t9,t10);}

/* k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 462  pad0 */
f_3988(t2,((C_word*)t0)[2]);}

/* k4084 in k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 462  pad0 */
f_3988(t2,((C_word*)t0)[2]);}

/* k4088 in k4084 in k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4094,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 462  pad0 */
f_3988(t2,((C_word*)t0)[2]);}

/* k4092 in k4088 in k4084 in k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4098,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4102,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4104,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4112,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 465  chicken-version */
t7=C_retrieve(lf[205]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k4114 in k4092 in k4088 in k4084 in k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 465  string-split */
t2=C_retrieve(lf[203]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[204]);}

/* k4110 in k4092 in k4088 in k4084 in k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4103 in k4092 in k4088 in k4084 in k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4104,3,t0,t1,t2);}
/* string-append */
t3=*((C_word*)lf[178]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[200],t2,lf[201]);}

/* k4100 in k4092 in k4088 in k4084 in k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 463  string-intersperse */
t2=C_retrieve(lf[198]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[199]);}

/* k4096 in k4092 in k4088 in k4084 in k4080 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 460  gen */
t2=C_retrieve(lf[1]);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[193],((C_word*)t0)[7],lf[194],C_SCHEME_TRUE,lf[195],C_SCHEME_TRUE,lf[196],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[197]);}

/* k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 468  gen-list */
t3=C_retrieve(lf[5]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[192]));}

/* k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 469  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4027 in k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[188]))){
/* c-backend.scm: 470  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[189],C_retrieve(lf[188]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 472  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[191]);}}

/* k4069 in k4027 in k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 473  gen-list */
t2=C_retrieve(lf[5]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[190]));}

/* k4030 in k4027 in k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 474  gen */
t3=C_retrieve(lf[1]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[184],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[185],C_retrieve(lf[186]),lf[187]);}

/* k4033 in k4030 in k4027 in k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[180]))){
/* c-backend.scm: 476  generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[182]));}
else{
t3=t2;
f_4038(2,t3,C_SCHEME_UNDEFINED);}}

/* k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[183])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4053,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 478  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_4041(2,t3,C_SCHEME_UNDEFINED);}}

/* k4051 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4058,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[183]));}

/* a4057 in k4051 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4058,3,t0,t1,t2);}
/* c-backend.scm: 479  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4003 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[180]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 481  generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[181]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[182]));}}

/* pad0 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_3988(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3988,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4002,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 452  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4000 in pad0 in header in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 452  string-append */
t2=*((C_word*)lf[178]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[179],t1);}

/* expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_2500(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2500,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3953,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 447  expr */
t11=((C_word*)t6)[1];
f_2503(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_3953(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3953,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3959,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 441  pair-for-each */
t5=C_retrieve(lf[177]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a3958 in expr-args in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3959,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_3963(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 443  gen */
t5=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k3961 in a3958 in expr-args in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 444  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2503(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_2503(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2503,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2507,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3947,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3947 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3947,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3942,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3942 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3942,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3937,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_3937 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3937,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_eqp(t3,lf[17]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[10]);
t6=(C_truep(t5)?lf[18]:lf[19]);
/* c-backend.scm: 127  gen */
t7=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[9],t6);}
else{
t5=(C_word)C_eqp(t3,lf[20]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[10]);
t7=(C_word)C_fix((C_word)C_character_code(t6));
/* c-backend.scm: 128  gen */
t8=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t8))(5,t8,((C_word*)t0)[9],lf[21],t7,C_make_character(41));}
else{
t6=(C_word)C_eqp(t3,lf[22]);
if(C_truep(t6)){
/* c-backend.scm: 129  gen */
t7=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[9],lf[23]);}
else{
t7=(C_word)C_eqp(t3,lf[24]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* c-backend.scm: 130  gen */
t9=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t9))(5,t9,((C_word*)t0)[9],lf[25],t8,C_make_character(41));}
else{
t8=(C_word)C_eqp(t3,lf[26]);
if(C_truep(t8)){
/* c-backend.scm: 131  gen */
t9=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t9))(3,t9,((C_word*)t0)[9],lf[27]);}
else{
/* c-backend.scm: 132  bomb */
t9=C_retrieve(lf[9]);
((C_proc3)C_retrieve_proc(t9))(3,t9,((C_word*)t0)[9],lf[28]);}}}}}}
else{
t3=(C_word)C_eqp(t1,lf[29]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_vectorp(t4))){
t5=(C_word)C_i_vector_ref(t4,C_fix(0));
/* c-backend.scm: 137  gen */
t6=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[9],lf[30],t5,lf[31]);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 138  gen */
t6=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t6))(5,t6,((C_word*)t0)[9],lf[32],t5,C_make_character(93));}}
else{
t4=(C_word)C_eqp(t1,lf[33]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
t6=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[36]);}
else{
t5=(C_word)C_eqp(t1,lf[37]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 150  gen */
t7=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[9],lf[38],t6);}
else{
t6=(C_word)C_eqp(t1,lf[39]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[10]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[7],a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_2685(t11,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6],t7);}
else{
t7=(C_word)C_eqp(t1,lf[40]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2736,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 162  gen */
t9=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[42]);}
else{
t8=(C_word)C_eqp(t1,lf[43]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 167  gen */
t10=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[45]);}
else{
t9=(C_word)C_eqp(t1,lf[46]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 172  gen */
t11=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,lf[47]);}
else{
t10=(C_word)C_eqp(t1,lf[48]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 179  gen */
t12=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,lf[51]);}
else{
t11=(C_word)C_eqp(t1,lf[52]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2852,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
t13=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,lf[54]);}
else{
t12=(C_word)C_eqp(t1,lf[55]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
t14=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t14))(3,t14,t13,lf[57]);}
else{
t13=(C_word)C_eqp(t1,lf[58]);
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[10]);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=t14,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 201  gen */
t16=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t15,lf[65],t14,C_make_character(44));}
else{
t14=(C_word)C_eqp(t1,lf[66]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 211  gen */
t16=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t16))(3,t16,t15,lf[68]);}
else{
t15=(C_word)C_eqp(t1,lf[69]);
if(C_truep(t15)){
t16=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 215  gen */
t17=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t17))(4,t17,((C_word*)t0)[9],C_make_character(116),t16);}
else{
t16=(C_word)C_eqp(t1,lf[70]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 218  gen */
t19=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t19))(5,t19,t17,C_make_character(116),t18,C_make_character(61));}
else{
t17=(C_word)C_eqp(t1,lf[71]);
if(C_truep(t17)){
t18=(C_word)C_i_car(((C_word*)t0)[10]);
t19=(C_word)C_i_cadr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_caddr(((C_word*)t0)[10]))){
if(C_truep(t19)){
/* c-backend.scm: 227  gen */
t20=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[72],t18,lf[73]);}
else{
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3022,a[2]=t18,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3026,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cadddr(((C_word*)t0)[10]);
/* c-backend.scm: 228  symbol->string */
t23=*((C_word*)lf[77]+1);
((C_proc3)C_retrieve_proc(t23))(3,t23,t21,t22);}}
else{
if(C_truep(t19)){
/* c-backend.scm: 229  gen */
t20=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[78],t18,lf[79]);}
else{
/* c-backend.scm: 230  gen */
t20=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t20))(5,t20,((C_word*)t0)[9],lf[80],t18,lf[81]);}}}
else{
t18=(C_word)C_eqp(t1,lf[82]);
if(C_truep(t18)){
t19=(C_word)C_i_car(((C_word*)t0)[10]);
t20=(C_word)C_i_cadr(((C_word*)t0)[10]);
t21=(C_word)C_i_caddr(((C_word*)t0)[10]);
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3057,a[2]=t21,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t20)){
/* c-backend.scm: 237  gen */
t23=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t23))(5,t23,t22,lf[85],t19,lf[86]);}
else{
/* c-backend.scm: 238  gen */
t23=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t23))(5,t23,t22,lf[87],t19,lf[88]);}}
else{
t19=(C_word)C_eqp(t1,lf[89]);
if(C_truep(t19)){
t20=(C_word)C_i_car(((C_word*)t0)[10]);
t21=(C_word)C_i_cadr(((C_word*)t0)[10]);
t22=(C_word)C_i_caddr(((C_word*)t0)[10]);
if(C_truep(t21)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3119,a[2]=t20,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3123,a[2]=t24,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 249  symbol->string */
t26=*((C_word*)lf[77]+1);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t22);}
else{
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3126,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3140,a[2]=t20,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3144,a[2]=t24,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 254  symbol->string */
t26=*((C_word*)lf[77]+1);
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,t22);}}
else{
t20=(C_word)C_eqp(t1,lf[96]);
if(C_truep(t20)){
/* c-backend.scm: 258  gen */
t21=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[9],lf[97]);}
else{
t21=(C_word)C_eqp(t1,lf[98]);
if(C_truep(t21)){
t22=(C_word)C_i_cdr(((C_word*)t0)[8]);
t23=(C_word)C_i_length(t22);
t24=((C_word*)t0)[6];
t25=(C_word)C_fixnum_increase(t23);
t26=(C_word)C_i_cdr(((C_word*)t0)[10]);
t27=(C_word)C_i_pairp(t26);
t28=(C_truep(t27)?(C_word)C_i_cadr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t29=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3177,a[2]=t27,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t28,a[6]=t24,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t23,a[10]=t25,a[11]=((C_word*)t0)[6],a[12]=t22,a[13]=((C_word*)t0)[4],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[10],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 267  source-info->string */
t30=C_retrieve(lf[127]);
((C_proc3)C_retrieve_proc(t30))(3,t30,t29,t28);}
else{
t22=(C_word)C_eqp(t1,lf[128]);
if(C_truep(t22)){
t23=(C_word)C_i_length(((C_word*)t0)[8]);
t24=(C_word)C_fixnum_increase(t23);
t25=(C_word)C_i_car(((C_word*)t0)[10]);
t26=(C_word)C_i_cadr(((C_word*)t0)[10]);
t27=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3498,a[2]=t26,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t24,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t23,a[10]=((C_word*)t0)[9],a[11]=t25,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 324  lambda-literal-closure-size */
t28=C_retrieve(lf[126]);
((C_proc3)C_retrieve_proc(t28))(3,t28,t27,((C_word*)t0)[3]);}
else{
t23=(C_word)C_eqp(t1,lf[132]);
if(C_truep(t23)){
t24=(C_word)C_i_cdr(((C_word*)t0)[8]);
t25=(C_word)C_i_length(t24);
t26=(C_word)C_fixnum_increase(t25);
t27=(C_word)C_i_caddr(((C_word*)t0)[10]);
t28=(C_word)C_i_cadddr(((C_word*)t0)[10]);
t29=(C_word)C_eqp(t28,C_fix(0));
t30=(C_word)C_i_not(t29);
t31=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3583,a[2]=t27,a[3]=t28,a[4]=t30,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],a[8]=t24,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3587,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 352  find-lambda */
t33=((C_word*)t0)[2];
f_2458(t33,t32,t27);}
else{
t24=(C_word)C_eqp(t1,lf[134]);
if(C_truep(t24)){
t25=(C_word)C_i_length(((C_word*)t0)[8]);
t26=(C_word)C_fixnum_plus(t25,C_fix(1));
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 369  gen */
t29=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t29))(8,t29,t27,C_SCHEME_TRUE,lf[136],t28,lf[137],t26,lf[138]);}
else{
t25=(C_word)C_eqp(t1,lf[139]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 374  gen */
t27=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t27))(4,t27,t26,C_SCHEME_TRUE,lf[141]);}
else{
t26=(C_word)C_eqp(t1,lf[142]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3644,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 379  gen */
t29=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t29))(5,t29,t27,lf[143],t28,C_make_character(40));}
else{
t27=(C_word)C_eqp(t1,lf[144]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3663,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t29=(C_word)C_i_car(((C_word*)t0)[10]);
t30=(C_word)C_i_length(((C_word*)t0)[8]);
/* c-backend.scm: 384  gen */
t31=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t31))(6,t31,t28,lf[145],t29,lf[146],t30);}
else{
t28=(C_word)C_eqp(t1,lf[147]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3699,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t30=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* c-backend.scm: 392  foreign-result-conversion */
t31=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t31))(4,t31,t29,t30,lf[149]);}
else{
t29=(C_word)C_eqp(t1,lf[150]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[10]);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3719,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[10]);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3737,a[2]=t30,a[3]=t32,a[4]=t31,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 396  foreign-type-declaration */
t34=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,t30,lf[155]);}
else{
t30=(C_word)C_eqp(t1,lf[156]);
if(C_truep(t30)){
t31=(C_word)C_i_car(((C_word*)t0)[10]);
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3753,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3767,a[2]=t31,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 402  foreign-result-conversion */
t34=C_retrieve(lf[148]);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,t31,lf[161]);}
else{
t31=(C_word)C_eqp(t1,lf[162]);
if(C_truep(t31)){
t32=(C_word)C_i_car(((C_word*)t0)[10]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3783,a[2]=t32,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 408  foreign-type-declaration */
t35=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,t32,lf[167]);}
else{
t32=(C_word)C_eqp(t1,lf[168]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3820,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 415  gen */
t34=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t34))(4,t34,t33,C_SCHEME_TRUE,lf[172]);}
else{
t33=(C_word)C_eqp(t1,lf[173]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 430  gen */
t35=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t35))(3,t35,t34,lf[175]);}
else{
/* c-backend.scm: 438  bomb */
t34=C_retrieve(lf[9]);
((C_proc3)C_retrieve_proc(t34))(3,t34,((C_word*)t0)[9],lf[176]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k3901 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 431  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3904 in k3901 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 432  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[174]);}

/* k3907 in k3904 in k3901 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 433  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3910 in k3907 in k3904 in k3901 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 434  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k3913 in k3910 in k3907 in k3904 in k3901 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 435  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 436  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 416  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2503(t4,t2,t3,((C_word*)t0)[3]);}

/* k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 417  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[171]);}

/* k3824 in k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3826,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3839,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3839(t7,((C_word*)t0)[2],t2,t3);}

/* doloop448 in k3824 in k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_3839(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3839,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 421  gen */
t6=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[169]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 424  gen */
t6=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[170]);}}

/* k3860 in doloop448 in k3824 in k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 425  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3863 in k3860 in doloop448 in k3824 in k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 426  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k3866 in k3863 in k3860 in doloop448 in k3824 in k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 427  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3869 in k3866 in k3863 in k3860 in doloop448 in k3824 in k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3839(t4,((C_word*)t0)[2],t2,t3);}

/* k3847 in doloop448 in k3824 in k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 422  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3850 in k3847 in doloop448 in k3824 in k3821 in k3818 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 423  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k3809 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 408  gen */
t2=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[165],t1,lf[166]);}

/* k3781 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 409  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2503(t4,t2,t3,((C_word*)t0)[3]);}

/* k3784 in k3781 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3803,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 410  foreign-argument-conversion */
t4=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3801 in k3784 in k3781 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 410  gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[164],t1);}

/* k3787 in k3784 in k3781 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 411  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3790 in k3787 in k3784 in k3781 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 412  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[163]);}

/* k3765 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3771,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 402  foreign-type-declaration */
t3=C_retrieve(lf[154]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[160]);}

/* k3769 in k3765 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 402  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[158],t1,lf[159]);}

/* k3751 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 403  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3754 in k3751 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 404  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[157]);}

/* k3735 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3741,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 396  foreign-argument-conversion */
t3=C_retrieve(lf[153]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3739 in k3735 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 396  gen */
t2=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[152],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3717 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 397  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3720 in k3717 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 398  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[151]);}

/* k3697 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 392  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3661 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3666,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 387  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_3666(2,t3,C_SCHEME_UNDEFINED);}}

/* k3673 in k3661 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 388  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3953(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3664 in k3661 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 389  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3642 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 380  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3953(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3645 in k3642 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 381  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3623 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 375  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3626 in k3623 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 376  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[140]);}

/* k3604 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 370  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3953(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3607 in k3604 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 371  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[135]);}

/* k3585 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 352  lambda-literal-closure-size */
t2=C_retrieve(lf[126]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3581 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 354  gen */
t5=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k3529 in k3581 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3534,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3564,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 356  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[133],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3534(2,t3,C_SCHEME_UNDEFINED);}}

/* k3562 in k3529 in k3581 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 357  gen */
t4=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_3534(2,t4,C_SCHEME_UNDEFINED);}}

/* k3532 in k3529 in k3581 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3537(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3552,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 359  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3550 in k3532 in k3529 in k3581 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 360  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3537(2,t2,C_SCHEME_UNDEFINED);}}

/* k3535 in k3532 in k3529 in k3581 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3540,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 361  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3953(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3540(2,t3,C_SCHEME_UNDEFINED);}}

/* k3538 in k3535 in k3532 in k3529 in k3581 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 362  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 326  lambda-literal-temporaries */
t4=C_retrieve(lf[104]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3482,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 339  gen */
t4=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3480 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3485(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 340  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[131]);}}

/* k3483 in k3480 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 341  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3953(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3486 in k3483 in k3480 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 342  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 327  iota */
t4=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3442 in k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 328  for-each */
t4=*((C_word*)lf[63]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a3464 in k3442 in k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3465,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 330  gen */
t5=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3467 in a3464 in k3442 in k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 331  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2503(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3470 in k3467 in a3464 in k3442 in k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 332  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3445 in k3442 in k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3455,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 336  iota */
t5=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3461 in k3445 in k3442 in k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 334  for-each */
t2=*((C_word*)lf[63]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3454 in k3445 in k3442 in k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3455,4,t0,t1,t2,t3);}
/* c-backend.scm: 335  gen */
t4=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[130],t2,C_make_character(59));}

/* k3448 in k3445 in k3442 in k3439 in k3496 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[129]);}

/* k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[16]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_3180(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[16]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3180(t3,C_SCHEME_FALSE);}}

/* k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_3180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3180,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[16]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3387,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3391,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 270  find-lambda */
t6=((C_word*)t0)[2];
f_2458(t6,t5,t1);}
else{
t4=t3;
f_3186(t4,C_SCHEME_FALSE);}}

/* k3389 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  lambda-literal-closure-size */
t2=C_retrieve(lf[126]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3385 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3186(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_3186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3186,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(C_retrieve(lf[118]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2488,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 114  ->string */
t7=C_retrieve(lf[15]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3380,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 275  uncommentify */
f_2490(t4,((C_word*)t0)[3]);}}
else{
t4=t3;
f_3192(2,t4,C_SCHEME_UNDEFINED);}}

/* k3378 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 275  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[124],t1,lf[125]);}

/* k2486 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 114  string-translate */
t2=C_retrieve(lf[121]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[122],lf[123]);}

/* k3371 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 274  gen */
t2=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[119],t1,lf[120]);}

/* k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3359,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_3359 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3359,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=(C_word)C_eqp(lf[37],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3201,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3215,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}
else{
if(C_truep(((C_word*)t0)[9])){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 282  lambda-literal-id */
t5=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 308  gen */
t4=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k3319 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 309  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2503(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3322 in k3319 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 310  gen */
t3=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[116],((C_word*)t0)[4],lf[117]);}

/* k3325 in k3322 in k3319 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[110]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3342,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3342(t5,t3);}
else{
t5=C_retrieve(lf[115]);
t6=t4;
f_3342(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k3340 in k3325 in k3322 in k3319 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_3342(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 313  gen */
t2=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[111],((C_word*)t0)[2],lf[112]);}
else{
/* c-backend.scm: 314  gen */
t2=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[113],((C_word*)t0)[2],lf[114]);}}

/* k3328 in k3325 in k3322 in k3319 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3333,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 315  gen */
t3=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[108],((C_word*)t0)[3],lf[109],((C_word*)t0)[2],C_make_character(44));}

/* k3331 in k3328 in k3325 in k3322 in k3319 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 316  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3953(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3334 in k3331 in k3328 in k3325 in k3322 in k3319 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 317  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[107]);}

/* k3316 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 283  lambda-literal-looping */
t3=C_retrieve(lf[106]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3228(2,t3,C_SCHEME_FALSE);}}

/* k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3231,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 284  lambda-literal-temporaries */
t3=C_retrieve(lf[104]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3278(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 299  gen */
t4=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3300 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3305,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 300  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2503(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3303 in k3300 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3276 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3281,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 302  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3279 in k3276 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3284(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 303  gen */
t3=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3282 in k3279 in k3276 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3287(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 304  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k3285 in k3282 in k3279 in k3276 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 305  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3953(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3288 in k3285 in k3282 in k3279 in k3276 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 306  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[105]);}

/* k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 285  iota */
t4=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 286  for-each */
t4=*((C_word*)lf[63]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a3260 in k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3261,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 288  gen */
t5=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3263 in a3260 in k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 289  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2503(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3266 in k3263 in a3260 in k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 290  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3235 in k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3251,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 294  iota */
t5=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3257 in k3235 in k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 292  for-each */
t2=*((C_word*)lf[63]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3250 in k3235 in k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3251,4,t0,t1,t2,t3);}
/* c-backend.scm: 293  gen */
t4=C_retrieve(lf[1]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[103],t2,C_make_character(59));}

/* k3238 in k3235 in k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3243(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 295  gen */
t3=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[102],((C_word*)t0)[2],C_make_character(59));}}

/* k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 296  gen */
t2=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[101]);}

/* f_3215 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3215,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3199 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3204,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(t1);
/* c-backend.scm: 278  gen */
t4=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,t3,C_make_character(40),((C_word*)t0)[2],lf[100]);}

/* k3202 in k3199 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 279  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3953(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3205 in k3202 in k3199 in k3356 in k3190 in k3184 in k3178 in k3175 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 280  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[99]);}

/* k3142 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 254  uncommentify */
f_2490(((C_word*)t0)[2],t1);}

/* k3138 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 253  gen */
t2=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[93],((C_word*)t0)[2],lf[94],t1,lf[95]);}

/* k3124 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 255  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3127 in k3124 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 256  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3121 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 249  uncommentify */
f_2490(((C_word*)t0)[2],t1);}

/* k3117 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 248  gen */
t2=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[90],((C_word*)t0)[2],lf[91],t1,lf[92]);}

/* k3103 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3108,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 250  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3106 in k3103 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3055 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3074,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3078,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 239  symbol->string */
t5=*((C_word*)lf[77]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3076 in k3055 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  uncommentify */
f_2490(((C_word*)t0)[2],t1);}

/* k3072 in k3055 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
t2=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[83],t1,lf[84]);}

/* k3058 in k3055 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 240  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k3061 in k3058 in k3055 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 241  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3024 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  c-ify-string */
t2=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3020 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  gen */
t2=C_retrieve(lf[1]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[74],((C_word*)t0)[2],lf[75],t1,C_make_character(41));}

/* k2978 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 219  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2503(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2946 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2951,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2949 in k2946 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[67]);}

/* k2911 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 207  iota */
t5=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2937 in k2911 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 202  for-each */
t2=*((C_word*)lf[63]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2924 in k2911 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2925,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 204  gen */
t5=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[61],t3,lf[62]);}

/* k2927 in a2924 in k2911 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 205  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2503(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2930 in k2927 in a2924 in k2911 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k2914 in k2911 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 208  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[59],t2,lf[60]);}

/* k2879 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2882 in k2879 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 195  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[56]);}

/* k2885 in k2882 in k2879 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 196  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2888 in k2885 in k2882 in k2879 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 197  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2850 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2853 in k2850 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 188  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k2856 in k2853 in k2850 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 189  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2859 in k2856 in k2853 in k2850 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 190  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2813 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2503(t4,t2,t3,((C_word*)t0)[3]);}

/* k2816 in k2813 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 181  gen */
t5=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[49],t4,lf[50]);}

/* k2819 in k2816 in k2813 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 182  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2822 in k2819 in k2816 in k2813 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 183  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2780 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2503(t4,t2,t3,((C_word*)t0)[3]);}

/* k2783 in k2780 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 174  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k2786 in k2783 in k2780 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 175  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2789 in k2786 in k2783 in k2780 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 176  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2761 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 168  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2764 in k2761 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 169  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[44]);}

/* k2734 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 163  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2737 in k2734 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 164  gen */
t4=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[41],t3,C_make_character(93));}

/* loop in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_2685(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2685,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2695,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 155  gen */
t7=C_retrieve(lf[1]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 159  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2503(t7,t1,t6,t3);}}

/* k2693 in loop in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 156  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2503(t4,t2,t3,((C_word*)t0)[6]);}

/* k2696 in k2693 in loop in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 157  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k2699 in k2696 in k2693 in loop in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 158  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2685(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2625 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2628 in k2625 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
t3=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[35]);}

/* k2631 in k2628 in k2625 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2634 in k2631 in k2628 in k2625 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 145  gen */
t3=C_retrieve(lf[1]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[34]);}

/* k2637 in k2634 in k2631 in k2628 in k2625 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2503(t4,t2,t3,((C_word*)t0)[2]);}

/* k2640 in k2637 in k2634 in k2631 in k2628 in k2625 in k2511 in k2508 in k2505 in expr in expression in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
t2=C_retrieve(lf[1]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* uncommentify in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_2490(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2490,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2498,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 115  ->string */
t4=C_retrieve(lf[15]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2496 in uncommentify in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 115  string-translate* */
t2=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[14]);}

/* find-lambda in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_fcall f_2458(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2458,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2462,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2470,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 111  find */
t5=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a2469 in find-lambda in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2470,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 111  lambda-literal-id */
t4=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2476 in a2469 in find-lambda in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k2460 in find-lambda in ##compiler#generate-code in k2451 in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 112  bomb */
t2=C_retrieve(lf[9]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[10],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2435,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2441,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2449,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 93   intersperse */
t5=C_retrieve(lf[6]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k2447 in ##compiler#gen-list in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2440 in ##compiler#gen-list in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2441,3,t0,t1,t2);}
/* c-backend.scm: 92   display */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[0]));}

/* ##compiler#gen in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_2414r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2414r(t0,t1,t2);}}

static void C_ccall f_2414r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2420,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a2419 in ##compiler#gen in k2409 in k2406 in k2403 in k2400 in k2397 in k2394 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2420,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 86   newline */
t4=*((C_word*)lf[2]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_retrieve(lf[0]));}
else{
/* c-backend.scm: 87   display */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve(lf[0]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[660] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_2396c-backend.scm",(void*)f_2396},
{"f_2399c-backend.scm",(void*)f_2399},
{"f_2402c-backend.scm",(void*)f_2402},
{"f_2405c-backend.scm",(void*)f_2405},
{"f_2408c-backend.scm",(void*)f_2408},
{"f_2411c-backend.scm",(void*)f_2411},
{"f_9027c-backend.scm",(void*)f_9027},
{"f_9031c-backend.scm",(void*)f_9031},
{"f_9023c-backend.scm",(void*)f_9023},
{"f_2453c-backend.scm",(void*)f_2453},
{"f_8723c-backend.scm",(void*)f_8723},
{"f_8999c-backend.scm",(void*)f_8999},
{"f_8997c-backend.scm",(void*)f_8997},
{"f_8985c-backend.scm",(void*)f_8985},
{"f_8955c-backend.scm",(void*)f_8955},
{"f_8916c-backend.scm",(void*)f_8916},
{"f_8903c-backend.scm",(void*)f_8903},
{"f_8899c-backend.scm",(void*)f_8899},
{"f_8785c-backend.scm",(void*)f_8785},
{"f_8732c-backend.scm",(void*)f_8732},
{"f_8325c-backend.scm",(void*)f_8325},
{"f_8412c-backend.scm",(void*)f_8412},
{"f_8493c-backend.scm",(void*)f_8493},
{"f_8515c-backend.scm",(void*)f_8515},
{"f_8327c-backend.scm",(void*)f_8327},
{"f_7840c-backend.scm",(void*)f_7840},
{"f_7870c-backend.scm",(void*)f_7870},
{"f_7897c-backend.scm",(void*)f_7897},
{"f_8092c-backend.scm",(void*)f_8092},
{"f_8101c-backend.scm",(void*)f_8101},
{"f_8110c-backend.scm",(void*)f_8110},
{"f_8132c-backend.scm",(void*)f_8132},
{"f_8209c-backend.scm",(void*)f_8209},
{"f_7842c-backend.scm",(void*)f_7842},
{"f_7004c-backend.scm",(void*)f_7004},
{"f_7081c-backend.scm",(void*)f_7081},
{"f_7183c-backend.scm",(void*)f_7183},
{"f_7216c-backend.scm",(void*)f_7216},
{"f_7312c-backend.scm",(void*)f_7312},
{"f_7327c-backend.scm",(void*)f_7327},
{"f_7367c-backend.scm",(void*)f_7367},
{"f_7384c-backend.scm",(void*)f_7384},
{"f_7401c-backend.scm",(void*)f_7401},
{"f_7440c-backend.scm",(void*)f_7440},
{"f_7457c-backend.scm",(void*)f_7457},
{"f_7474c-backend.scm",(void*)f_7474},
{"f_7491c-backend.scm",(void*)f_7491},
{"f_7508c-backend.scm",(void*)f_7508},
{"f_7525c-backend.scm",(void*)f_7525},
{"f_7542c-backend.scm",(void*)f_7542},
{"f_7554c-backend.scm",(void*)f_7554},
{"f_7561c-backend.scm",(void*)f_7561},
{"f_7571c-backend.scm",(void*)f_7571},
{"f_7569c-backend.scm",(void*)f_7569},
{"f_7565c-backend.scm",(void*)f_7565},
{"f_7532c-backend.scm",(void*)f_7532},
{"f_7515c-backend.scm",(void*)f_7515},
{"f_7498c-backend.scm",(void*)f_7498},
{"f_7481c-backend.scm",(void*)f_7481},
{"f_7464c-backend.scm",(void*)f_7464},
{"f_7447c-backend.scm",(void*)f_7447},
{"f_7412c-backend.scm",(void*)f_7412},
{"f_7422c-backend.scm",(void*)f_7422},
{"f_7420c-backend.scm",(void*)f_7420},
{"f_7416c-backend.scm",(void*)f_7416},
{"f_7408c-backend.scm",(void*)f_7408},
{"f_7395c-backend.scm",(void*)f_7395},
{"f_7378c-backend.scm",(void*)f_7378},
{"f_7011c-backend.scm",(void*)f_7011},
{"f_7006c-backend.scm",(void*)f_7006},
{"f_6939c-backend.scm",(void*)f_6939},
{"f_6943c-backend.scm",(void*)f_6943},
{"f_6946c-backend.scm",(void*)f_6946},
{"f_6949c-backend.scm",(void*)f_6949},
{"f_6952c-backend.scm",(void*)f_6952},
{"f_6958c-backend.scm",(void*)f_6958},
{"f_7002c-backend.scm",(void*)f_7002},
{"f_6961c-backend.scm",(void*)f_6961},
{"f_6969c-backend.scm",(void*)f_6969},
{"f_6990c-backend.scm",(void*)f_6990},
{"f_6973c-backend.scm",(void*)f_6973},
{"f_6964c-backend.scm",(void*)f_6964},
{"f_6508c-backend.scm",(void*)f_6508},
{"f_6514c-backend.scm",(void*)f_6514},
{"f_6518c-backend.scm",(void*)f_6518},
{"f_6521c-backend.scm",(void*)f_6521},
{"f_6524c-backend.scm",(void*)f_6524},
{"f_6527c-backend.scm",(void*)f_6527},
{"f_6533c-backend.scm",(void*)f_6533},
{"f_6874c-backend.scm",(void*)f_6874},
{"f_6877c-backend.scm",(void*)f_6877},
{"f_6937c-backend.scm",(void*)f_6937},
{"f_6880c-backend.scm",(void*)f_6880},
{"f_6883c-backend.scm",(void*)f_6883},
{"f_6886c-backend.scm",(void*)f_6886},
{"f_6889c-backend.scm",(void*)f_6889},
{"f_6922c-backend.scm",(void*)f_6922},
{"f_6930c-backend.scm",(void*)f_6930},
{"f_6892c-backend.scm",(void*)f_6892},
{"f_6920c-backend.scm",(void*)f_6920},
{"f_6895c-backend.scm",(void*)f_6895},
{"f_6898c-backend.scm",(void*)f_6898},
{"f_6901c-backend.scm",(void*)f_6901},
{"f_6535c-backend.scm",(void*)f_6535},
{"f_6545c-backend.scm",(void*)f_6545},
{"f_6554c-backend.scm",(void*)f_6554},
{"f_6566c-backend.scm",(void*)f_6566},
{"f_6578c-backend.scm",(void*)f_6578},
{"f_6584c-backend.scm",(void*)f_6584},
{"f_6618c-backend.scm",(void*)f_6618},
{"f_6275c-backend.scm",(void*)f_6275},
{"f_6281c-backend.scm",(void*)f_6281},
{"f_6285c-backend.scm",(void*)f_6285},
{"f_6288c-backend.scm",(void*)f_6288},
{"f_6291c-backend.scm",(void*)f_6291},
{"f_6506c-backend.scm",(void*)f_6506},
{"f_6297c-backend.scm",(void*)f_6297},
{"f_6300c-backend.scm",(void*)f_6300},
{"f_6303c-backend.scm",(void*)f_6303},
{"f_6306c-backend.scm",(void*)f_6306},
{"f_6309c-backend.scm",(void*)f_6309},
{"f_6312c-backend.scm",(void*)f_6312},
{"f_6315c-backend.scm",(void*)f_6315},
{"f_6318c-backend.scm",(void*)f_6318},
{"f_6321c-backend.scm",(void*)f_6321},
{"f_6324c-backend.scm",(void*)f_6324},
{"f_6495c-backend.scm",(void*)f_6495},
{"f_6327c-backend.scm",(void*)f_6327},
{"f_6330c-backend.scm",(void*)f_6330},
{"f_6333c-backend.scm",(void*)f_6333},
{"f_6336c-backend.scm",(void*)f_6336},
{"f_6339c-backend.scm",(void*)f_6339},
{"f_6342c-backend.scm",(void*)f_6342},
{"f_6345c-backend.scm",(void*)f_6345},
{"f_6348c-backend.scm",(void*)f_6348},
{"f_6473c-backend.scm",(void*)f_6473},
{"f_6443c-backend.scm",(void*)f_6443},
{"f_6463c-backend.scm",(void*)f_6463},
{"f_6451c-backend.scm",(void*)f_6451},
{"f_6455c-backend.scm",(void*)f_6455},
{"f_6459c-backend.scm",(void*)f_6459},
{"f_6351c-backend.scm",(void*)f_6351},
{"f_6354c-backend.scm",(void*)f_6354},
{"f_6384c-backend.scm",(void*)f_6384},
{"f_6387c-backend.scm",(void*)f_6387},
{"f_6425c-backend.scm",(void*)f_6425},
{"f_6421c-backend.scm",(void*)f_6421},
{"f_6390c-backend.scm",(void*)f_6390},
{"f_6393c-backend.scm",(void*)f_6393},
{"f_6396c-backend.scm",(void*)f_6396},
{"f_6363c-backend.scm",(void*)f_6363},
{"f_6366c-backend.scm",(void*)f_6366},
{"f_6357c-backend.scm",(void*)f_6357},
{"f_6257c-backend.scm",(void*)f_6257},
{"f_6263c-backend.scm",(void*)f_6263},
{"f_6267c-backend.scm",(void*)f_6267},
{"f_6270c-backend.scm",(void*)f_6270},
{"f_6225c-backend.scm",(void*)f_6225},
{"f_6229c-backend.scm",(void*)f_6229},
{"f_6234c-backend.scm",(void*)f_6234},
{"f_6255c-backend.scm",(void*)f_6255},
{"f_6209c-backend.scm",(void*)f_6209},
{"f_6215c-backend.scm",(void*)f_6215},
{"f_6223c-backend.scm",(void*)f_6223},
{"f_6193c-backend.scm",(void*)f_6193},
{"f_6199c-backend.scm",(void*)f_6199},
{"f_6207c-backend.scm",(void*)f_6207},
{"f_6104c-backend.scm",(void*)f_6104},
{"f_6113c-backend.scm",(void*)f_6113},
{"f_6142c-backend.scm",(void*)f_6142},
{"f_6152c-backend.scm",(void*)f_6152},
{"f_6145c-backend.scm",(void*)f_6145},
{"f_6129c-backend.scm",(void*)f_6129},
{"f_6031c-backend.scm",(void*)f_6031},
{"f_6035c-backend.scm",(void*)f_6035},
{"f_6049c-backend.scm",(void*)f_6049},
{"f_6062c-backend.scm",(void*)f_6062},
{"f_6065c-backend.scm",(void*)f_6065},
{"f_6068c-backend.scm",(void*)f_6068},
{"f_6038c-backend.scm",(void*)f_6038},
{"f_6041c-backend.scm",(void*)f_6041},
{"f_6044c-backend.scm",(void*)f_6044},
{"f_2455c-backend.scm",(void*)f_2455},
{"f_5998c-backend.scm",(void*)f_5998},
{"f_6002c-backend.scm",(void*)f_6002},
{"f_6005c-backend.scm",(void*)f_6005},
{"f_6008c-backend.scm",(void*)f_6008},
{"f_6011c-backend.scm",(void*)f_6011},
{"f_6014c-backend.scm",(void*)f_6014},
{"f_6017c-backend.scm",(void*)f_6017},
{"f_6020c-backend.scm",(void*)f_6020},
{"f_6023c-backend.scm",(void*)f_6023},
{"f_6026c-backend.scm",(void*)f_6026},
{"f_5251c-backend.scm",(void*)f_5251},
{"f_5257c-backend.scm",(void*)f_5257},
{"f_5261c-backend.scm",(void*)f_5261},
{"f_5264c-backend.scm",(void*)f_5264},
{"f_5267c-backend.scm",(void*)f_5267},
{"f_5270c-backend.scm",(void*)f_5270},
{"f_5273c-backend.scm",(void*)f_5273},
{"f_5276c-backend.scm",(void*)f_5276},
{"f_5995c-backend.scm",(void*)f_5995},
{"f_5279c-backend.scm",(void*)f_5279},
{"f_5285c-backend.scm",(void*)f_5285},
{"f_5288c-backend.scm",(void*)f_5288},
{"f_5291c-backend.scm",(void*)f_5291},
{"f_5294c-backend.scm",(void*)f_5294},
{"f_5297c-backend.scm",(void*)f_5297},
{"f_5300c-backend.scm",(void*)f_5300},
{"f_5303c-backend.scm",(void*)f_5303},
{"f_5306c-backend.scm",(void*)f_5306},
{"f_5309c-backend.scm",(void*)f_5309},
{"f_5312c-backend.scm",(void*)f_5312},
{"f_5315c-backend.scm",(void*)f_5315},
{"f_5318c-backend.scm",(void*)f_5318},
{"f_5964c-backend.scm",(void*)f_5964},
{"f_5321c-backend.scm",(void*)f_5321},
{"f_5925c-backend.scm",(void*)f_5925},
{"f_5928c-backend.scm",(void*)f_5928},
{"f_5931c-backend.scm",(void*)f_5931},
{"f_5947c-backend.scm",(void*)f_5947},
{"f_5950c-backend.scm",(void*)f_5950},
{"f_5324c-backend.scm",(void*)f_5324},
{"f_5327c-backend.scm",(void*)f_5327},
{"f_5330c-backend.scm",(void*)f_5330},
{"f_5897c-backend.scm",(void*)f_5897},
{"f_5900c-backend.scm",(void*)f_5900},
{"f_5333c-backend.scm",(void*)f_5333},
{"f_5336c-backend.scm",(void*)f_5336},
{"f_5339c-backend.scm",(void*)f_5339},
{"f_5342c-backend.scm",(void*)f_5342},
{"f_5345c-backend.scm",(void*)f_5345},
{"f_5348c-backend.scm",(void*)f_5348},
{"f_5859c-backend.scm",(void*)f_5859},
{"f_5869c-backend.scm",(void*)f_5869},
{"f_5351c-backend.scm",(void*)f_5351},
{"f_5802c-backend.scm",(void*)f_5802},
{"f_5814c-backend.scm",(void*)f_5814},
{"f_5817c-backend.scm",(void*)f_5817},
{"f_5823c-backend.scm",(void*)f_5823},
{"f_5724c-backend.scm",(void*)f_5724},
{"f_5766c-backend.scm",(void*)f_5766},
{"f_5727c-backend.scm",(void*)f_5727},
{"f_5733c-backend.scm",(void*)f_5733},
{"f_5736c-backend.scm",(void*)f_5736},
{"f_5742c-backend.scm",(void*)f_5742},
{"f_5660c-backend.scm",(void*)f_5660},
{"f_5663c-backend.scm",(void*)f_5663},
{"f_5666c-backend.scm",(void*)f_5666},
{"f_5669c-backend.scm",(void*)f_5669},
{"f_5672c-backend.scm",(void*)f_5672},
{"f_5687c-backend.scm",(void*)f_5687},
{"f_5675c-backend.scm",(void*)f_5675},
{"f_5678c-backend.scm",(void*)f_5678},
{"f_5646c-backend.scm",(void*)f_5646},
{"f_5654c-backend.scm",(void*)f_5654},
{"f_5571c-backend.scm",(void*)f_5571},
{"f_5577c-backend.scm",(void*)f_5577},
{"f_5580c-backend.scm",(void*)f_5580},
{"f_5614c-backend.scm",(void*)f_5614},
{"f_5617c-backend.scm",(void*)f_5617},
{"f_5620c-backend.scm",(void*)f_5620},
{"f_5583c-backend.scm",(void*)f_5583},
{"f_5586c-backend.scm",(void*)f_5586},
{"f_5589c-backend.scm",(void*)f_5589},
{"f_5592c-backend.scm",(void*)f_5592},
{"f_5601c-backend.scm",(void*)f_5601},
{"f_5604c-backend.scm",(void*)f_5604},
{"f_5354c-backend.scm",(void*)f_5354},
{"f_5377c-backend.scm",(void*)f_5377},
{"f_5512c-backend.scm",(void*)f_5512},
{"f_5515c-backend.scm",(void*)f_5515},
{"f_5527c-backend.scm",(void*)f_5527},
{"f_5518c-backend.scm",(void*)f_5518},
{"f_5383c-backend.scm",(void*)f_5383},
{"f_5386c-backend.scm",(void*)f_5386},
{"f_5389c-backend.scm",(void*)f_5389},
{"f_5493c-backend.scm",(void*)f_5493},
{"f_5392c-backend.scm",(void*)f_5392},
{"f_5395c-backend.scm",(void*)f_5395},
{"f_5398c-backend.scm",(void*)f_5398},
{"f_5401c-backend.scm",(void*)f_5401},
{"f_5466c-backend.scm",(void*)f_5466},
{"f_5462c-backend.scm",(void*)f_5462},
{"f_5404c-backend.scm",(void*)f_5404},
{"f_5407c-backend.scm",(void*)f_5407},
{"f_5410c-backend.scm",(void*)f_5410},
{"f_5413c-backend.scm",(void*)f_5413},
{"f_5416c-backend.scm",(void*)f_5416},
{"f_5419c-backend.scm",(void*)f_5419},
{"f_5437c-backend.scm",(void*)f_5437},
{"f_5447c-backend.scm",(void*)f_5447},
{"f_5422c-backend.scm",(void*)f_5422},
{"f_5357c-backend.scm",(void*)f_5357},
{"f_5367c-backend.scm",(void*)f_5367},
{"f_5360c-backend.scm",(void*)f_5360},
{"f_4861c-backend.scm",(void*)f_4861},
{"f_4868c-backend.scm",(void*)f_4868},
{"f_4942c-backend.scm",(void*)f_4942},
{"f_4960c-backend.scm",(void*)f_4960},
{"f_4989c-backend.scm",(void*)f_4989},
{"f_5011c-backend.scm",(void*)f_5011},
{"f_4967c-backend.scm",(void*)f_4967},
{"f_4936c-backend.scm",(void*)f_4936},
{"f_4932c-backend.scm",(void*)f_4932},
{"f_4928c-backend.scm",(void*)f_4928},
{"f_4899c-backend.scm",(void*)f_4899},
{"f_4903c-backend.scm",(void*)f_4903},
{"f_4818c-backend.scm",(void*)f_4818},
{"f_4824c-backend.scm",(void*)f_4824},
{"f_4853c-backend.scm",(void*)f_4853},
{"f_4834c-backend.scm",(void*)f_4834},
{"f_5020c-backend.scm",(void*)f_5020},
{"f_5160c-backend.scm",(void*)f_5160},
{"f_5027c-backend.scm",(void*)f_5027},
{"f_5033c-backend.scm",(void*)f_5033},
{"f_5116c-backend.scm",(void*)f_5116},
{"f_5119c-backend.scm",(void*)f_5119},
{"f_5129c-backend.scm",(void*)f_5129},
{"f_5122c-backend.scm",(void*)f_5122},
{"f_5083c-backend.scm",(void*)f_5083},
{"f_5089c-backend.scm",(void*)f_5089},
{"f_4855c-backend.scm",(void*)f_4855},
{"f_5162c-backend.scm",(void*)f_5162},
{"f_5169c-backend.scm",(void*)f_5169},
{"f_5172c-backend.scm",(void*)f_5172},
{"f_5177c-backend.scm",(void*)f_5177},
{"f_5233c-backend.scm",(void*)f_5233},
{"f_5229c-backend.scm",(void*)f_5229},
{"f_5214c-backend.scm",(void*)f_5214},
{"f_5193c-backend.scm",(void*)f_5193},
{"f_5204c-backend.scm",(void*)f_5204},
{"f_5200c-backend.scm",(void*)f_5200},
{"f_5239c-backend.scm",(void*)f_5239},
{"f_5246c-backend.scm",(void*)f_5246},
{"f_5249c-backend.scm",(void*)f_5249},
{"f_4532c-backend.scm",(void*)f_4532},
{"f_4699c-backend.scm",(void*)f_4699},
{"f_4703c-backend.scm",(void*)f_4703},
{"f_4706c-backend.scm",(void*)f_4706},
{"f_4709c-backend.scm",(void*)f_4709},
{"f_4712c-backend.scm",(void*)f_4712},
{"f_4715c-backend.scm",(void*)f_4715},
{"f_4816c-backend.scm",(void*)f_4816},
{"f_4718c-backend.scm",(void*)f_4718},
{"f_4721c-backend.scm",(void*)f_4721},
{"f_4727c-backend.scm",(void*)f_4727},
{"f_4805c-backend.scm",(void*)f_4805},
{"f_4761c-backend.scm",(void*)f_4761},
{"f_4767c-backend.scm",(void*)f_4767},
{"f_4785c-backend.scm",(void*)f_4785},
{"f_4781c-backend.scm",(void*)f_4781},
{"f_4777c-backend.scm",(void*)f_4777},
{"f_4733c-backend.scm",(void*)f_4733},
{"f_4736c-backend.scm",(void*)f_4736},
{"f_4739c-backend.scm",(void*)f_4739},
{"f_4742c-backend.scm",(void*)f_4742},
{"f_4745c-backend.scm",(void*)f_4745},
{"f_4755c-backend.scm",(void*)f_4755},
{"f_4748c-backend.scm",(void*)f_4748},
{"f_4651c-backend.scm",(void*)f_4651},
{"f_4670c-backend.scm",(void*)f_4670},
{"f_4674c-backend.scm",(void*)f_4674},
{"f_4677c-backend.scm",(void*)f_4677},
{"f_4680c-backend.scm",(void*)f_4680},
{"f_4683c-backend.scm",(void*)f_4683},
{"f_4697c-backend.scm",(void*)f_4697},
{"f_4693c-backend.scm",(void*)f_4693},
{"f_4686c-backend.scm",(void*)f_4686},
{"f_4654c-backend.scm",(void*)f_4654},
{"f_4668c-backend.scm",(void*)f_4668},
{"f_4657c-backend.scm",(void*)f_4657},
{"f_4664c-backend.scm",(void*)f_4664},
{"f_4571c-backend.scm",(void*)f_4571},
{"f_4573c-backend.scm",(void*)f_4573},
{"f_4577c-backend.scm",(void*)f_4577},
{"f_4580c-backend.scm",(void*)f_4580},
{"f_4583c-backend.scm",(void*)f_4583},
{"f_4586c-backend.scm",(void*)f_4586},
{"f_4589c-backend.scm",(void*)f_4589},
{"f_4592c-backend.scm",(void*)f_4592},
{"f_4595c-backend.scm",(void*)f_4595},
{"f_4598c-backend.scm",(void*)f_4598},
{"f_4601c-backend.scm",(void*)f_4601},
{"f_4604c-backend.scm",(void*)f_4604},
{"f_4607c-backend.scm",(void*)f_4607},
{"f_4610c-backend.scm",(void*)f_4610},
{"f_4624c-backend.scm",(void*)f_4624},
{"f_4620c-backend.scm",(void*)f_4620},
{"f_4613c-backend.scm",(void*)f_4613},
{"f_4535c-backend.scm",(void*)f_4535},
{"f_4548c-backend.scm",(void*)f_4548},
{"f_4558c-backend.scm",(void*)f_4558},
{"f_4539c-backend.scm",(void*)f_4539},
{"f_4281c-backend.scm",(void*)f_4281},
{"f_4285c-backend.scm",(void*)f_4285},
{"f_4309c-backend.scm",(void*)f_4309},
{"f_4313c-backend.scm",(void*)f_4313},
{"f_4316c-backend.scm",(void*)f_4316},
{"f_4530c-backend.scm",(void*)f_4530},
{"f_4319c-backend.scm",(void*)f_4319},
{"f_4516c-backend.scm",(void*)f_4516},
{"f_4322c-backend.scm",(void*)f_4322},
{"f_4325c-backend.scm",(void*)f_4325},
{"f_4328c-backend.scm",(void*)f_4328},
{"f_4331c-backend.scm",(void*)f_4331},
{"f_4334c-backend.scm",(void*)f_4334},
{"f_4337c-backend.scm",(void*)f_4337},
{"f_4508c-backend.scm",(void*)f_4508},
{"f_4340c-backend.scm",(void*)f_4340},
{"f_4343c-backend.scm",(void*)f_4343},
{"f_4501c-backend.scm",(void*)f_4501},
{"f_4482c-backend.scm",(void*)f_4482},
{"f_4493c-backend.scm",(void*)f_4493},
{"f_4346c-backend.scm",(void*)f_4346},
{"f_4433c-backend.scm",(void*)f_4433},
{"f_4436c-backend.scm",(void*)f_4436},
{"f_4439c-backend.scm",(void*)f_4439},
{"f_4442c-backend.scm",(void*)f_4442},
{"f_4458c-backend.scm",(void*)f_4458},
{"f_4461c-backend.scm",(void*)f_4461},
{"f_4464c-backend.scm",(void*)f_4464},
{"f_4467c-backend.scm",(void*)f_4467},
{"f_4349c-backend.scm",(void*)f_4349},
{"f_4352c-backend.scm",(void*)f_4352},
{"f_4355c-backend.scm",(void*)f_4355},
{"f_4405c-backend.scm",(void*)f_4405},
{"f_4408c-backend.scm",(void*)f_4408},
{"f_4358c-backend.scm",(void*)f_4358},
{"f_4361c-backend.scm",(void*)f_4361},
{"f_4393c-backend.scm",(void*)f_4393},
{"f_4396c-backend.scm",(void*)f_4396},
{"f_4367c-backend.scm",(void*)f_4367},
{"f_4376c-backend.scm",(void*)f_4376},
{"f_4379c-backend.scm",(void*)f_4379},
{"f_4288c-backend.scm",(void*)f_4288},
{"f_4293c-backend.scm",(void*)f_4293},
{"f_4297c-backend.scm",(void*)f_4297},
{"f_4307c-backend.scm",(void*)f_4307},
{"f_4300c-backend.scm",(void*)f_4300},
{"f_4132c-backend.scm",(void*)f_4132},
{"f_4139c-backend.scm",(void*)f_4139},
{"f_4275c-backend.scm",(void*)f_4275},
{"f_4142c-backend.scm",(void*)f_4142},
{"f_4145c-backend.scm",(void*)f_4145},
{"f_4148c-backend.scm",(void*)f_4148},
{"f_4153c-backend.scm",(void*)f_4153},
{"f_4163c-backend.scm",(void*)f_4163},
{"f_4169c-backend.scm",(void*)f_4169},
{"f_4222c-backend.scm",(void*)f_4222},
{"f_4232c-backend.scm",(void*)f_4232},
{"f_4172c-backend.scm",(void*)f_4172},
{"f_4195c-backend.scm",(void*)f_4195},
{"f_4205c-backend.scm",(void*)f_4205},
{"f_4175c-backend.scm",(void*)f_4175},
{"f_4178c-backend.scm",(void*)f_4178},
{"f_3985c-backend.scm",(void*)f_3985},
{"f_4124c-backend.scm",(void*)f_4124},
{"f_4005c-backend.scm",(void*)f_4005},
{"f_4082c-backend.scm",(void*)f_4082},
{"f_4086c-backend.scm",(void*)f_4086},
{"f_4090c-backend.scm",(void*)f_4090},
{"f_4094c-backend.scm",(void*)f_4094},
{"f_4116c-backend.scm",(void*)f_4116},
{"f_4112c-backend.scm",(void*)f_4112},
{"f_4104c-backend.scm",(void*)f_4104},
{"f_4102c-backend.scm",(void*)f_4102},
{"f_4098c-backend.scm",(void*)f_4098},
{"f_4023c-backend.scm",(void*)f_4023},
{"f_4026c-backend.scm",(void*)f_4026},
{"f_4029c-backend.scm",(void*)f_4029},
{"f_4071c-backend.scm",(void*)f_4071},
{"f_4032c-backend.scm",(void*)f_4032},
{"f_4035c-backend.scm",(void*)f_4035},
{"f_4038c-backend.scm",(void*)f_4038},
{"f_4053c-backend.scm",(void*)f_4053},
{"f_4058c-backend.scm",(void*)f_4058},
{"f_4041c-backend.scm",(void*)f_4041},
{"f_3988c-backend.scm",(void*)f_3988},
{"f_4002c-backend.scm",(void*)f_4002},
{"f_2500c-backend.scm",(void*)f_2500},
{"f_3953c-backend.scm",(void*)f_3953},
{"f_3959c-backend.scm",(void*)f_3959},
{"f_3963c-backend.scm",(void*)f_3963},
{"f_2503c-backend.scm",(void*)f_2503},
{"f_3947c-backend.scm",(void*)f_3947},
{"f_2507c-backend.scm",(void*)f_2507},
{"f_3942c-backend.scm",(void*)f_3942},
{"f_2510c-backend.scm",(void*)f_2510},
{"f_3937c-backend.scm",(void*)f_3937},
{"f_2513c-backend.scm",(void*)f_2513},
{"f_3903c-backend.scm",(void*)f_3903},
{"f_3906c-backend.scm",(void*)f_3906},
{"f_3909c-backend.scm",(void*)f_3909},
{"f_3912c-backend.scm",(void*)f_3912},
{"f_3915c-backend.scm",(void*)f_3915},
{"f_3918c-backend.scm",(void*)f_3918},
{"f_3820c-backend.scm",(void*)f_3820},
{"f_3823c-backend.scm",(void*)f_3823},
{"f_3826c-backend.scm",(void*)f_3826},
{"f_3839c-backend.scm",(void*)f_3839},
{"f_3862c-backend.scm",(void*)f_3862},
{"f_3865c-backend.scm",(void*)f_3865},
{"f_3868c-backend.scm",(void*)f_3868},
{"f_3871c-backend.scm",(void*)f_3871},
{"f_3849c-backend.scm",(void*)f_3849},
{"f_3852c-backend.scm",(void*)f_3852},
{"f_3811c-backend.scm",(void*)f_3811},
{"f_3783c-backend.scm",(void*)f_3783},
{"f_3786c-backend.scm",(void*)f_3786},
{"f_3803c-backend.scm",(void*)f_3803},
{"f_3789c-backend.scm",(void*)f_3789},
{"f_3792c-backend.scm",(void*)f_3792},
{"f_3767c-backend.scm",(void*)f_3767},
{"f_3771c-backend.scm",(void*)f_3771},
{"f_3753c-backend.scm",(void*)f_3753},
{"f_3756c-backend.scm",(void*)f_3756},
{"f_3737c-backend.scm",(void*)f_3737},
{"f_3741c-backend.scm",(void*)f_3741},
{"f_3719c-backend.scm",(void*)f_3719},
{"f_3722c-backend.scm",(void*)f_3722},
{"f_3699c-backend.scm",(void*)f_3699},
{"f_3663c-backend.scm",(void*)f_3663},
{"f_3675c-backend.scm",(void*)f_3675},
{"f_3666c-backend.scm",(void*)f_3666},
{"f_3644c-backend.scm",(void*)f_3644},
{"f_3647c-backend.scm",(void*)f_3647},
{"f_3625c-backend.scm",(void*)f_3625},
{"f_3628c-backend.scm",(void*)f_3628},
{"f_3606c-backend.scm",(void*)f_3606},
{"f_3609c-backend.scm",(void*)f_3609},
{"f_3587c-backend.scm",(void*)f_3587},
{"f_3583c-backend.scm",(void*)f_3583},
{"f_3531c-backend.scm",(void*)f_3531},
{"f_3564c-backend.scm",(void*)f_3564},
{"f_3534c-backend.scm",(void*)f_3534},
{"f_3552c-backend.scm",(void*)f_3552},
{"f_3537c-backend.scm",(void*)f_3537},
{"f_3540c-backend.scm",(void*)f_3540},
{"f_3498c-backend.scm",(void*)f_3498},
{"f_3482c-backend.scm",(void*)f_3482},
{"f_3485c-backend.scm",(void*)f_3485},
{"f_3488c-backend.scm",(void*)f_3488},
{"f_3441c-backend.scm",(void*)f_3441},
{"f_3444c-backend.scm",(void*)f_3444},
{"f_3465c-backend.scm",(void*)f_3465},
{"f_3469c-backend.scm",(void*)f_3469},
{"f_3472c-backend.scm",(void*)f_3472},
{"f_3447c-backend.scm",(void*)f_3447},
{"f_3463c-backend.scm",(void*)f_3463},
{"f_3455c-backend.scm",(void*)f_3455},
{"f_3450c-backend.scm",(void*)f_3450},
{"f_3177c-backend.scm",(void*)f_3177},
{"f_3180c-backend.scm",(void*)f_3180},
{"f_3391c-backend.scm",(void*)f_3391},
{"f_3387c-backend.scm",(void*)f_3387},
{"f_3186c-backend.scm",(void*)f_3186},
{"f_3380c-backend.scm",(void*)f_3380},
{"f_2488c-backend.scm",(void*)f_2488},
{"f_3373c-backend.scm",(void*)f_3373},
{"f_3192c-backend.scm",(void*)f_3192},
{"f_3359c-backend.scm",(void*)f_3359},
{"f_3358c-backend.scm",(void*)f_3358},
{"f_3321c-backend.scm",(void*)f_3321},
{"f_3324c-backend.scm",(void*)f_3324},
{"f_3327c-backend.scm",(void*)f_3327},
{"f_3342c-backend.scm",(void*)f_3342},
{"f_3330c-backend.scm",(void*)f_3330},
{"f_3333c-backend.scm",(void*)f_3333},
{"f_3336c-backend.scm",(void*)f_3336},
{"f_3318c-backend.scm",(void*)f_3318},
{"f_3228c-backend.scm",(void*)f_3228},
{"f_3302c-backend.scm",(void*)f_3302},
{"f_3305c-backend.scm",(void*)f_3305},
{"f_3278c-backend.scm",(void*)f_3278},
{"f_3281c-backend.scm",(void*)f_3281},
{"f_3284c-backend.scm",(void*)f_3284},
{"f_3287c-backend.scm",(void*)f_3287},
{"f_3290c-backend.scm",(void*)f_3290},
{"f_3231c-backend.scm",(void*)f_3231},
{"f_3234c-backend.scm",(void*)f_3234},
{"f_3261c-backend.scm",(void*)f_3261},
{"f_3265c-backend.scm",(void*)f_3265},
{"f_3268c-backend.scm",(void*)f_3268},
{"f_3237c-backend.scm",(void*)f_3237},
{"f_3259c-backend.scm",(void*)f_3259},
{"f_3251c-backend.scm",(void*)f_3251},
{"f_3240c-backend.scm",(void*)f_3240},
{"f_3243c-backend.scm",(void*)f_3243},
{"f_3215c-backend.scm",(void*)f_3215},
{"f_3201c-backend.scm",(void*)f_3201},
{"f_3204c-backend.scm",(void*)f_3204},
{"f_3207c-backend.scm",(void*)f_3207},
{"f_3144c-backend.scm",(void*)f_3144},
{"f_3140c-backend.scm",(void*)f_3140},
{"f_3126c-backend.scm",(void*)f_3126},
{"f_3129c-backend.scm",(void*)f_3129},
{"f_3123c-backend.scm",(void*)f_3123},
{"f_3119c-backend.scm",(void*)f_3119},
{"f_3105c-backend.scm",(void*)f_3105},
{"f_3108c-backend.scm",(void*)f_3108},
{"f_3057c-backend.scm",(void*)f_3057},
{"f_3078c-backend.scm",(void*)f_3078},
{"f_3074c-backend.scm",(void*)f_3074},
{"f_3060c-backend.scm",(void*)f_3060},
{"f_3063c-backend.scm",(void*)f_3063},
{"f_3026c-backend.scm",(void*)f_3026},
{"f_3022c-backend.scm",(void*)f_3022},
{"f_2980c-backend.scm",(void*)f_2980},
{"f_2948c-backend.scm",(void*)f_2948},
{"f_2951c-backend.scm",(void*)f_2951},
{"f_2913c-backend.scm",(void*)f_2913},
{"f_2939c-backend.scm",(void*)f_2939},
{"f_2925c-backend.scm",(void*)f_2925},
{"f_2929c-backend.scm",(void*)f_2929},
{"f_2932c-backend.scm",(void*)f_2932},
{"f_2916c-backend.scm",(void*)f_2916},
{"f_2881c-backend.scm",(void*)f_2881},
{"f_2884c-backend.scm",(void*)f_2884},
{"f_2887c-backend.scm",(void*)f_2887},
{"f_2890c-backend.scm",(void*)f_2890},
{"f_2852c-backend.scm",(void*)f_2852},
{"f_2855c-backend.scm",(void*)f_2855},
{"f_2858c-backend.scm",(void*)f_2858},
{"f_2861c-backend.scm",(void*)f_2861},
{"f_2815c-backend.scm",(void*)f_2815},
{"f_2818c-backend.scm",(void*)f_2818},
{"f_2821c-backend.scm",(void*)f_2821},
{"f_2824c-backend.scm",(void*)f_2824},
{"f_2782c-backend.scm",(void*)f_2782},
{"f_2785c-backend.scm",(void*)f_2785},
{"f_2788c-backend.scm",(void*)f_2788},
{"f_2791c-backend.scm",(void*)f_2791},
{"f_2763c-backend.scm",(void*)f_2763},
{"f_2766c-backend.scm",(void*)f_2766},
{"f_2736c-backend.scm",(void*)f_2736},
{"f_2739c-backend.scm",(void*)f_2739},
{"f_2685c-backend.scm",(void*)f_2685},
{"f_2695c-backend.scm",(void*)f_2695},
{"f_2698c-backend.scm",(void*)f_2698},
{"f_2701c-backend.scm",(void*)f_2701},
{"f_2627c-backend.scm",(void*)f_2627},
{"f_2630c-backend.scm",(void*)f_2630},
{"f_2633c-backend.scm",(void*)f_2633},
{"f_2636c-backend.scm",(void*)f_2636},
{"f_2639c-backend.scm",(void*)f_2639},
{"f_2642c-backend.scm",(void*)f_2642},
{"f_2490c-backend.scm",(void*)f_2490},
{"f_2498c-backend.scm",(void*)f_2498},
{"f_2458c-backend.scm",(void*)f_2458},
{"f_2470c-backend.scm",(void*)f_2470},
{"f_2478c-backend.scm",(void*)f_2478},
{"f_2462c-backend.scm",(void*)f_2462},
{"f_2435c-backend.scm",(void*)f_2435},
{"f_2449c-backend.scm",(void*)f_2449},
{"f_2441c-backend.scm",(void*)f_2441},
{"f_2414c-backend.scm",(void*)f_2414},
{"f_2420c-backend.scm",(void*)f_2420},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
