/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-12-08 08:53
   Version 4.0.0x3 - SVN rev. 12690
   linux-unix-gnu-x86 [ dload ptables applyhook ]
   compiled 2008-12-01 on dill (Linux)
   command line: c-backend.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature debugbuild -no-lambda-info -inline -local -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[839];
static double C_possibly_force_alignment;


/* from getsize */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2376(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2376(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2371(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2371(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9190)
static void C_ccall f_9190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9194)
static void C_ccall f_9194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9186)
static void C_ccall f_9186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8886)
static void C_ccall f_8886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9160)
static void C_ccall f_9160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9148)
static void C_ccall f_9148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9118)
static void C_ccall f_9118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9079)
static void C_ccall f_9079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9066)
static void C_ccall f_9066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_ccall f_9062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8948)
static void C_ccall f_8948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8895)
static C_word C_fcall f_8895(C_word *a,C_word t0);
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8575)
static void C_fcall f_8575(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8656)
static void C_ccall f_8656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8678)
static void C_fcall f_8678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8490)
static void C_fcall f_8490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8003)
static void C_ccall f_8003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8033)
static void C_fcall f_8033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8060)
static void C_fcall f_8060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8255)
static void C_fcall f_8255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8264)
static void C_fcall f_8264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8273)
static void C_ccall f_8273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8295)
static void C_fcall f_8295(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8372)
static void C_ccall f_8372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8005)
static void C_fcall f_8005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7244)
static void C_fcall f_7244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7346)
static void C_fcall f_7346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7379)
static void C_fcall f_7379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7475)
static void C_fcall f_7475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7490)
static void C_ccall f_7490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_fcall f_7530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_fcall f_7547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static void C_fcall f_7564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7603)
static void C_fcall f_7603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7620)
static void C_fcall f_7620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7637)
static void C_fcall f_7637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_fcall f_7654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7671)
static void C_fcall f_7671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7688)
static void C_fcall f_7688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7705)
static void C_fcall f_7705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7724)
static void C_ccall f_7724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7728)
static void C_ccall f_7728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7695)
static void C_ccall f_7695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7678)
static void C_ccall f_7678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7644)
static void C_ccall f_7644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7610)
static void C_ccall f_7610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7585)
static void C_ccall f_7585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7583)
static void C_ccall f_7583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7571)
static void C_ccall f_7571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7174)
static void C_fcall f_7174(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7169)
static void C_fcall f_7169(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7102)
static void C_ccall f_7102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7115)
static void C_ccall f_7115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7124)
static void C_ccall f_7124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7132)
static void C_ccall f_7132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7153)
static void C_ccall f_7153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7127)
static void C_ccall f_7127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6671)
static void C_ccall f_6671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6681)
static void C_ccall f_6681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6690)
static void C_ccall f_6690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7037)
static void C_ccall f_7037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7043)
static void C_ccall f_7043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7046)
static void C_ccall f_7046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7049)
static void C_ccall f_7049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7085)
static void C_ccall f_7085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_ccall f_7083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7058)
static void C_ccall f_7058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7061)
static void C_ccall f_7061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7064)
static void C_ccall f_7064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6698)
static void C_ccall f_6698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6708)
static void C_fcall f_6708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_fcall f_6717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6729)
static void C_fcall f_6729(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6741)
static void C_fcall f_6741(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6747)
static void C_ccall f_6747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6781)
static void C_fcall f_6781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6438)
static void C_ccall f_6438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6669)
static void C_ccall f_6669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6466)
static void C_ccall f_6466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6472)
static void C_ccall f_6472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6496)
static void C_ccall f_6496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6499)
static void C_ccall f_6499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6502)
static void C_ccall f_6502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6505)
static void C_ccall f_6505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6508)
static void C_ccall f_6508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6606)
static void C_ccall f_6606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6584)
static void C_ccall f_6584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6556)
static void C_ccall f_6556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6529)
static void C_ccall f_6529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6388)
static void C_ccall f_6388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6372)
static void C_ccall f_6372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6378)
static void C_ccall f_6378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_ccall f_6356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6362)
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6276)
static void C_fcall f_6276(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6305)
static void C_fcall f_6305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6315)
static void C_ccall f_6315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6308)
static void C_fcall f_6308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_fcall f_6292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6208)
static void C_fcall f_6208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6197)
static void C_ccall f_6197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6200)
static void C_ccall f_6200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6161)
static void C_ccall f_6161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6173)
static void C_ccall f_6173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_ccall f_6179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6185)
static void C_ccall f_6185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5410)
static void C_fcall f_5410(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_fcall f_5438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6084)
static void C_ccall f_6084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6087)
static void C_ccall f_6087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6109)
static void C_ccall f_6109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6056)
static void C_fcall f_6056(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6059)
static void C_ccall f_6059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_fcall f_5504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6018)
static void C_fcall f_6018(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_fcall f_5961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5973)
static void C_ccall f_5973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_fcall f_5982(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_fcall f_5925(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_fcall f_5892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5901)
static void C_fcall f_5901(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_fcall f_5846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5813)
static void C_ccall f_5813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5736)
static void C_ccall f_5736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_ccall f_5739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5779)
static void C_ccall f_5779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5745)
static void C_ccall f_5745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5751)
static void C_ccall f_5751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5763)
static void C_ccall f_5763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_fcall f_5536(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5674)
static void C_ccall f_5674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_fcall f_5596(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5101)
static void C_ccall f_5101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_fcall f_5148(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5091)
static void C_ccall f_5091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_fcall f_4977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_fcall f_4983(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5179)
static void C_fcall f_5179(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_fcall f_5186(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_fcall f_5275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_ccall f_5288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5281)
static void C_ccall f_5281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_fcall f_5014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_fcall f_5321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5331)
static void C_ccall f_5331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_fcall f_5336(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_fcall f_5352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_ccall f_5363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5398)
static void C_fcall f_5398(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5408)
static void C_ccall f_5408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_fcall f_4691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_fcall f_4877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_fcall f_4880(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_fcall f_4926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4730)
static void C_fcall f_4730(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4748)
static void C_ccall f_4748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_fcall f_4694(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_fcall f_4707(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_fcall f_4440(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_fcall f_4478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_fcall f_4499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_fcall f_4564(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4520)
static void C_ccall f_4520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4459)
static void C_ccall f_4459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4291)
static void C_fcall f_4291(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_fcall f_4312(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_fcall f_4381(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_fcall f_4354(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_fcall f_4144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4253)
static void C_ccall f_4253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_fcall f_4147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_fcall f_2536(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4112)
static void C_fcall f_4112(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_fcall f_3998(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_ccall f_3787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3699)
static void C_ccall f_3699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_ccall f_3644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_fcall f_3216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_fcall f_3222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_fcall f_3360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_fcall f_3470(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_ccall f_3378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2920)
static void C_ccall f_2920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2894)
static void C_ccall f_2894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2897)
static void C_ccall f_2897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_fcall f_2721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_fcall f_2526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_fcall f_2494(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8575)
static void C_fcall trf_8575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8575(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8575(t0,t1);}

C_noret_decl(trf_8678)
static void C_fcall trf_8678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8678(t0,t1);}

C_noret_decl(trf_8490)
static void C_fcall trf_8490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8490(t0,t1);}

C_noret_decl(trf_8033)
static void C_fcall trf_8033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8033(t0,t1);}

C_noret_decl(trf_8060)
static void C_fcall trf_8060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8060(t0,t1);}

C_noret_decl(trf_8255)
static void C_fcall trf_8255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8255(t0,t1);}

C_noret_decl(trf_8264)
static void C_fcall trf_8264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8264(t0,t1);}

C_noret_decl(trf_8295)
static void C_fcall trf_8295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8295(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8295(t0,t1);}

C_noret_decl(trf_8005)
static void C_fcall trf_8005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8005(t0,t1);}

C_noret_decl(trf_7244)
static void C_fcall trf_7244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7244(t0,t1);}

C_noret_decl(trf_7346)
static void C_fcall trf_7346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7346(t0,t1);}

C_noret_decl(trf_7379)
static void C_fcall trf_7379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7379(t0,t1);}

C_noret_decl(trf_7475)
static void C_fcall trf_7475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7475(t0,t1);}

C_noret_decl(trf_7530)
static void C_fcall trf_7530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7530(t0,t1);}

C_noret_decl(trf_7547)
static void C_fcall trf_7547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7547(t0,t1);}

C_noret_decl(trf_7564)
static void C_fcall trf_7564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7564(t0,t1);}

C_noret_decl(trf_7603)
static void C_fcall trf_7603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7603(t0,t1);}

C_noret_decl(trf_7620)
static void C_fcall trf_7620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7620(t0,t1);}

C_noret_decl(trf_7637)
static void C_fcall trf_7637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7637(t0,t1);}

C_noret_decl(trf_7654)
static void C_fcall trf_7654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7654(t0,t1);}

C_noret_decl(trf_7671)
static void C_fcall trf_7671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7671(t0,t1);}

C_noret_decl(trf_7688)
static void C_fcall trf_7688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7688(t0,t1);}

C_noret_decl(trf_7705)
static void C_fcall trf_7705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7705(t0,t1);}

C_noret_decl(trf_7174)
static void C_fcall trf_7174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7174(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7174(t0,t1,t2);}

C_noret_decl(trf_7169)
static void C_fcall trf_7169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7169(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7169(t0,t1);}

C_noret_decl(trf_6708)
static void C_fcall trf_6708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6708(t0,t1);}

C_noret_decl(trf_6717)
static void C_fcall trf_6717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6717(t0,t1);}

C_noret_decl(trf_6729)
static void C_fcall trf_6729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6729(t0,t1);}

C_noret_decl(trf_6741)
static void C_fcall trf_6741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6741(t0,t1);}

C_noret_decl(trf_6781)
static void C_fcall trf_6781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6781(t0,t1);}

C_noret_decl(trf_6276)
static void C_fcall trf_6276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6276(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6276(t0,t1,t2);}

C_noret_decl(trf_6305)
static void C_fcall trf_6305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6305(t0,t1);}

C_noret_decl(trf_6308)
static void C_fcall trf_6308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6308(t0,t1);}

C_noret_decl(trf_6292)
static void C_fcall trf_6292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6292(t0,t1);}

C_noret_decl(trf_6208)
static void C_fcall trf_6208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6208(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6208(t0,t1,t2);}

C_noret_decl(trf_5410)
static void C_fcall trf_5410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5410(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5410(t0,t1);}

C_noret_decl(trf_5438)
static void C_fcall trf_5438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5438(t0,t1);}

C_noret_decl(trf_6056)
static void C_fcall trf_6056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6056(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6056(t0,t1);}

C_noret_decl(trf_5504)
static void C_fcall trf_5504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5504(t0,t1);}

C_noret_decl(trf_6018)
static void C_fcall trf_6018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6018(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6018(t0,t1,t2,t3);}

C_noret_decl(trf_5961)
static void C_fcall trf_5961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5961(t0,t1);}

C_noret_decl(trf_5982)
static void C_fcall trf_5982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5982(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5982(t0,t1);}

C_noret_decl(trf_5925)
static void C_fcall trf_5925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5925(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5925(t0,t1);}

C_noret_decl(trf_5892)
static void C_fcall trf_5892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5892(t0,t1);}

C_noret_decl(trf_5901)
static void C_fcall trf_5901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5901(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5901(t0,t1);}

C_noret_decl(trf_5846)
static void C_fcall trf_5846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5846(t0,t1);}

C_noret_decl(trf_5536)
static void C_fcall trf_5536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5536(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5536(t0,t1);}

C_noret_decl(trf_5596)
static void C_fcall trf_5596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5596(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5596(t0,t1,t2,t3);}

C_noret_decl(trf_5148)
static void C_fcall trf_5148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5148(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5148(t0,t1,t2,t3);}

C_noret_decl(trf_4977)
static void C_fcall trf_4977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4977(t0,t1);}

C_noret_decl(trf_4983)
static void C_fcall trf_4983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4983(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4983(t0,t1,t2,t3);}

C_noret_decl(trf_5179)
static void C_fcall trf_5179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5179(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5179(t0,t1,t2,t3);}

C_noret_decl(trf_5186)
static void C_fcall trf_5186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5186(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5186(t0,t1);}

C_noret_decl(trf_5275)
static void C_fcall trf_5275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5275(t0,t1);}

C_noret_decl(trf_5014)
static void C_fcall trf_5014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5014(t0,t1);}

C_noret_decl(trf_5321)
static void C_fcall trf_5321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5321(t0,t1,t2);}

C_noret_decl(trf_5336)
static void C_fcall trf_5336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5336(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5336(t0,t1,t2,t3);}

C_noret_decl(trf_5352)
static void C_fcall trf_5352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5352(t0,t1);}

C_noret_decl(trf_5398)
static void C_fcall trf_5398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5398(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5398(t0,t1,t2,t3);}

C_noret_decl(trf_4691)
static void C_fcall trf_4691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4691(t0,t1);}

C_noret_decl(trf_4877)
static void C_fcall trf_4877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4877(t0,t1);}

C_noret_decl(trf_4880)
static void C_fcall trf_4880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4880(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4880(t0,t1);}

C_noret_decl(trf_4926)
static void C_fcall trf_4926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4926(t0,t1);}

C_noret_decl(trf_4730)
static void C_fcall trf_4730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4730(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4730(t0,t1,t2);}

C_noret_decl(trf_4694)
static void C_fcall trf_4694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4694(t0,t1);}

C_noret_decl(trf_4707)
static void C_fcall trf_4707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4707(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4707(t0,t1,t2,t3);}

C_noret_decl(trf_4440)
static void C_fcall trf_4440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4440(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4440(t0,t1);}

C_noret_decl(trf_4478)
static void C_fcall trf_4478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4478(t0,t1);}

C_noret_decl(trf_4499)
static void C_fcall trf_4499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4499(t0,t1);}

C_noret_decl(trf_4564)
static void C_fcall trf_4564(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4564(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4564(t0,t1);}

C_noret_decl(trf_4291)
static void C_fcall trf_4291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4291(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4291(t0,t1);}

C_noret_decl(trf_4312)
static void C_fcall trf_4312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4312(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4312(t0,t1,t2,t3);}

C_noret_decl(trf_4381)
static void C_fcall trf_4381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4381(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4381(t0,t1,t2);}

C_noret_decl(trf_4354)
static void C_fcall trf_4354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4354(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4354(t0,t1,t2);}

C_noret_decl(trf_4144)
static void C_fcall trf_4144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4144(t0,t1);}

C_noret_decl(trf_4147)
static void C_fcall trf_4147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4147(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4147(t0,t1);}

C_noret_decl(trf_2536)
static void C_fcall trf_2536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2536(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2536(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4112)
static void C_fcall trf_4112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4112(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4112(t0,t1,t2,t3);}

C_noret_decl(trf_2539)
static void C_fcall trf_2539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2539(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2539(t0,t1,t2,t3);}

C_noret_decl(trf_3998)
static void C_fcall trf_3998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3998(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3998(t0,t1,t2,t3);}

C_noret_decl(trf_3216)
static void C_fcall trf_3216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3216(t0,t1);}

C_noret_decl(trf_3222)
static void C_fcall trf_3222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3222(t0,t1);}

C_noret_decl(trf_3360)
static void C_fcall trf_3360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3360(t0,t1);}

C_noret_decl(trf_3470)
static void C_fcall trf_3470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3470(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3470(t0,t1);}

C_noret_decl(trf_2721)
static void C_fcall trf_2721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2721(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2721(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2526)
static void C_fcall trf_2526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2526(t0,t1);}

C_noret_decl(trf_2494)
static void C_fcall trf_2494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2494(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2494(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2414)){
C_save(t1);
C_rereclaim2(2414*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,839);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],12,"\003sysfor-each");
lf[5]=C_h_intern(&lf[5],17,"\010compilergen-list");
lf[6]=C_h_intern(&lf[6],11,"intersperse");
lf[7]=C_h_intern(&lf[7],18,"\010compilerunique-id");
lf[8]=C_h_intern(&lf[8],22,"\010compilergenerate-code");
lf[9]=C_h_intern(&lf[9],13,"\010compilerbomb");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[11]=C_h_intern(&lf[11],17,"lambda-literal-id");
lf[12]=C_h_intern(&lf[12],4,"find");
lf[13]=C_h_intern(&lf[13],17,"string-translate*");
lf[14]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[15]=C_h_intern(&lf[15],8,"->string");
lf[16]=C_h_intern(&lf[16],14,"\004coreimmediate");
lf[17]=C_h_intern(&lf[17],4,"bool");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[20]=C_h_intern(&lf[20],4,"char");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[22]=C_h_intern(&lf[22],3,"nil");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[24]=C_h_intern(&lf[24],3,"fix");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[26]=C_h_intern(&lf[26],3,"eof");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[29]=C_h_intern(&lf[29],12,"\004coreliteral");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[33]=C_h_intern(&lf[33],2,"if");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[37]=C_h_intern(&lf[37],9,"\004coreproc");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[39]=C_h_intern(&lf[39],9,"\004corebind");
lf[40]=C_h_intern(&lf[40],8,"\004coreref");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[43]=C_h_intern(&lf[43],10,"\004coreunbox");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[46]=C_h_intern(&lf[46],13,"\004coreupdate_i");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[48]=C_h_intern(&lf[48],11,"\004coreupdate");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[52]=C_h_intern(&lf[52],16,"\004coreupdatebox_i");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[55]=C_h_intern(&lf[55],14,"\004coreupdatebox");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[58]=C_h_intern(&lf[58],12,"\004coreclosure");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[63]=C_h_intern(&lf[63],8,"for-each");
lf[64]=C_h_intern(&lf[64],4,"iota");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[66]=C_h_intern(&lf[66],8,"\004corebox");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[69]=C_h_intern(&lf[69],10,"\004corelocal");
lf[70]=C_h_intern(&lf[70],13,"\004coresetlocal");
lf[71]=C_h_intern(&lf[71],11,"\004coreglobal");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[76]=C_h_intern(&lf[76],21,"\010compilerc-ify-string");
lf[77]=C_h_intern(&lf[77],14,"symbol->string");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[82]=C_h_intern(&lf[82],14,"\004coresetglobal");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[89]=C_h_intern(&lf[89],16,"\004coresetglobal_i");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[96]=C_h_intern(&lf[96],14,"\004coreundefined");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[98]=C_h_intern(&lf[98],9,"\004corecall");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[104]=C_h_intern(&lf[104],26,"lambda-literal-temporaries");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[106]=C_h_intern(&lf[106],22,"lambda-literal-looping");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[113]=C_h_intern(&lf[113],13,"string-append");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\032C_retrieve_symbol_proc(lf[");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[129]=C_h_intern(&lf[129],6,"unsafe");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[134]=C_h_intern(&lf[134],19,"no-procedure-checks");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[137]=C_h_intern(&lf[137],24,"\010compileremit-trace-info");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[140]=C_h_intern(&lf[140],16,"string-translate");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[145]=C_h_intern(&lf[145],27,"lambda-literal-closure-size");
lf[146]=C_h_intern(&lf[146],28,"\010compilersource-info->string");
lf[147]=C_h_intern(&lf[147],12,"\004corerecurse");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[151]=C_h_intern(&lf[151],16,"\004coredirect_call");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[153]=C_h_intern(&lf[153],13,"\004corecallunit");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[158]=C_h_intern(&lf[158],11,"\004corereturn");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[161]=C_h_intern(&lf[161],11,"\004coreinline");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[163]=C_h_intern(&lf[163],20,"\004coreinline_allocate");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[166]=C_h_intern(&lf[166],15,"\004coreinline_ref");
lf[167]=C_h_intern(&lf[167],34,"\010compilerforeign-result-conversion");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[169]=C_h_intern(&lf[169],18,"\004coreinline_update");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[172]=C_h_intern(&lf[172],36,"\010compilerforeign-argument-conversion");
lf[173]=C_h_intern(&lf[173],33,"\010compilerforeign-type-declaration");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[175]=C_h_intern(&lf[175],19,"\004coreinline_loc_ref");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[181]=C_h_intern(&lf[181],22,"\004coreinline_loc_update");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_h_intern(&lf[187],11,"\004coreswitch");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[192]=C_h_intern(&lf[192],9,"\004corecond");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[196]=C_h_intern(&lf[196],13,"pair-for-each");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[198]=C_h_intern(&lf[198],30,"\010compilerexternal-protos-first");
lf[199]=C_h_intern(&lf[199],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[200]=C_h_intern(&lf[200],22,"foreign-callback-stubs");
lf[201]=C_h_intern(&lf[201],29,"\010compilerforeign-declarations");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[204]=C_h_intern(&lf[204],28,"\010compilertarget-include-file");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[206]=C_h_intern(&lf[206],18,"\010compilerunit-name");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[208]=C_h_intern(&lf[208],19,"\010compilerused-units");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[210]=C_h_intern(&lf[210],27,"\010compilercompiler-arguments");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[216]=C_h_intern(&lf[216],18,"string-intersperse");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[220]=C_h_intern(&lf[220],7,"\003sysmap");
lf[221]=C_h_intern(&lf[221],12,"string-split");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[223]=C_h_intern(&lf[223],15,"chicken-version");
lf[224]=C_h_intern(&lf[224],18,"\003sysdecode-seconds");
lf[225]=C_h_intern(&lf[225],15,"current-seconds");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[230]=C_h_intern(&lf[230],23,"\003syslambda-info->string");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[240]=C_h_intern(&lf[240],9,"make-list");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[244]=C_h_intern(&lf[244],4,"none");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[255]=C_h_intern(&lf[255],8,"toplevel");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[258]=C_h_intern(&lf[258],27,"\010compileremit-unsafe-marker");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[271]=C_h_intern(&lf[271],21,"small-parameter-limit");
lf[272]=C_h_intern(&lf[272],11,"lset-adjoin");
lf[273]=C_h_intern(&lf[273],1,"=");
lf[274]=C_h_intern(&lf[274],32,"lambda-literal-callee-signatures");
lf[275]=C_h_intern(&lf[275],24,"lambda-literal-allocated");
lf[276]=C_h_intern(&lf[276],21,"lambda-literal-direct");
lf[277]=C_h_intern(&lf[277],33,"lambda-literal-rest-argument-mode");
lf[278]=C_h_intern(&lf[278],28,"lambda-literal-rest-argument");
lf[279]=C_h_intern(&lf[279],27,"\010compilermake-variable-list");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[281]=C_h_intern(&lf[281],27,"lambda-literal-customizable");
lf[282]=C_h_intern(&lf[282],29,"lambda-literal-argument-count");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[289]=C_h_intern(&lf[289],27,"\010compilermake-argument-list");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[329]=C_h_intern(&lf[329],6,"vector");
lf[330]=C_h_intern(&lf[330],23,"lambda-literal-external");
lf[331]=C_h_intern(&lf[331],14,"\003syscopy-bytes");
lf[332]=C_h_intern(&lf[332],11,"make-string");
lf[333]=C_h_intern(&lf[333],6,"modulo");
lf[334]=C_h_intern(&lf[334],3,"fx/");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[338]=C_h_intern(&lf[338],19,"\003sysundefined-value");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[349]=C_h_intern(&lf[349],23,"\010compilerencode-literal");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[351]=C_h_intern(&lf[351],32,"\010compilerblock-variable-literal\077");
lf[352]=C_h_intern(&lf[352],20,"\010compilerbig-fixnum\077");
lf[353]=C_h_intern(&lf[353],7,"sprintf");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[355]=C_h_intern(&lf[355],25,"\010compilerwords-per-flonum");
lf[356]=C_h_intern(&lf[356],6,"reduce");
lf[357]=C_h_intern(&lf[357],1,"+");
lf[358]=C_h_intern(&lf[358],12,"vector->list");
lf[359]=C_h_intern(&lf[359],14,"\010compilerwords");
lf[360]=C_h_intern(&lf[360],15,"\003sysbytevector\077");
lf[361]=C_h_intern(&lf[361],19,"\010compilerimmediate\077");
lf[362]=C_h_intern(&lf[362],19,"lambda-literal-body");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[375]=C_h_intern(&lf[375],4,"list");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[414]=C_h_intern(&lf[414],26,"\010compilertarget-stack-size");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[417]=C_h_intern(&lf[417],30,"\010compilertarget-heap-shrinkage");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[419]=C_h_intern(&lf[419],27,"\010compilertarget-heap-growth");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[421]=C_h_intern(&lf[421],33,"\010compilertarget-initial-heap-size");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[424]=C_h_intern(&lf[424],25,"\010compilertarget-heap-size");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[428]=C_h_intern(&lf[428],40,"\010compilerdisable-stack-overflow-checking");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[434]=C_h_intern(&lf[434],4,"fold");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[437]=C_h_intern(&lf[437],28,"\010compilerinsert-timer-checks");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[442]=C_h_intern(&lf[442],14,"no-argc-checks");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[489]=C_h_intern(&lf[489],16,"\010compilercleanup");
lf[490]=C_h_intern(&lf[490],18,"\010compilerdebugging");
lf[491]=C_h_intern(&lf[491],1,"o");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[497]=C_h_intern(&lf[497],18,"\010compilerreal-name");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[499]=C_h_intern(&lf[499],25,"emit-procedure-table-info");
lf[500]=C_h_intern(&lf[500],31,"generate-foreign-callback-stubs");
lf[501]=C_h_intern(&lf[501],31,"\010compilergenerate-foreign-stubs");
lf[502]=C_h_intern(&lf[502],29,"\010compilerforeign-lambda-stubs");
lf[503]=C_h_intern(&lf[503],36,"\010compilergenerate-external-variables");
lf[504]=C_h_intern(&lf[504],27,"\010compilerexternal-variables");
lf[505]=C_h_intern(&lf[505],1,"p");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[523]=C_h_intern(&lf[523],29,"\010compilerstring->c-identifier");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[527]=C_h_intern(&lf[527],11,"string-copy");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[529]=C_h_intern(&lf[529],13,"list-tabulate");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[532]=C_h_intern(&lf[532],41,"\010compilergenerate-foreign-callback-header");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[545]=C_h_intern(&lf[545],4,"void");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[570]=C_h_intern(&lf[570],21,"foreign-stub-callback");
lf[571]=C_h_intern(&lf[571],16,"foreign-stub-cps");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[573]=C_h_intern(&lf[573],27,"foreign-stub-argument-names");
lf[574]=C_h_intern(&lf[574],17,"foreign-stub-body");
lf[575]=C_h_intern(&lf[575],17,"foreign-stub-name");
lf[576]=C_h_intern(&lf[576],24,"foreign-stub-return-type");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[579]=C_h_intern(&lf[579],27,"foreign-stub-argument-types");
lf[580]=C_h_intern(&lf[580],19,"\010compilerreal-name2");
lf[581]=C_h_intern(&lf[581],15,"foreign-stub-id");
lf[582]=C_h_intern(&lf[582],5,"float");
lf[583]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[584]=C_h_intern(&lf[584],8,"c-string");
lf[585]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[586]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[587]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[588]=C_h_intern(&lf[588],16,"nonnull-c-string");
lf[589]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[590]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[591]=C_h_intern(&lf[591],3,"ref");
lf[592]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[593]=C_h_intern(&lf[593],5,"const");
lf[594]=C_h_intern(&lf[594],7,"pointer");
lf[595]=C_h_intern(&lf[595],9,"c-pointer");
lf[596]=C_h_intern(&lf[596],15,"nonnull-pointer");
lf[597]=C_h_intern(&lf[597],17,"nonnull-c-pointer");
lf[598]=C_h_intern(&lf[598],8,"function");
lf[599]=C_h_intern(&lf[599],8,"instance");
lf[600]=C_h_intern(&lf[600],16,"nonnull-instance");
lf[601]=C_h_intern(&lf[601],12,"instance-ref");
lf[602]=C_h_intern(&lf[602],18,"\003syshash-table-ref");
lf[603]=C_h_intern(&lf[603],27,"\010compilerforeign-type-table");
lf[604]=C_h_intern(&lf[604],17,"nonnull-c-string*");
lf[605]=C_h_intern(&lf[605],25,"nonnull-unsigned-c-string");
lf[606]=C_h_intern(&lf[606],26,"nonnull-unsigned-c-string*");
lf[607]=C_h_intern(&lf[607],6,"symbol");
lf[608]=C_h_intern(&lf[608],9,"c-string*");
lf[609]=C_h_intern(&lf[609],17,"unsigned-c-string");
lf[610]=C_h_intern(&lf[610],18,"unsigned-c-string*");
lf[611]=C_h_intern(&lf[611],6,"double");
lf[612]=C_h_intern(&lf[612],16,"unsigned-integer");
lf[613]=C_h_intern(&lf[613],18,"unsigned-integer32");
lf[614]=C_h_intern(&lf[614],4,"long");
lf[615]=C_h_intern(&lf[615],7,"integer");
lf[616]=C_h_intern(&lf[616],9,"integer32");
lf[617]=C_h_intern(&lf[617],13,"unsigned-long");
lf[618]=C_h_intern(&lf[618],6,"number");
lf[619]=C_h_intern(&lf[619],9,"integer64");
lf[620]=C_h_intern(&lf[620],13,"c-string-list");
lf[621]=C_h_intern(&lf[621],14,"c-string-list*");
lf[622]=C_h_intern(&lf[622],3,"int");
lf[623]=C_h_intern(&lf[623],5,"int32");
lf[624]=C_h_intern(&lf[624],5,"short");
lf[625]=C_h_intern(&lf[625],14,"unsigned-short");
lf[626]=C_h_intern(&lf[626],13,"scheme-object");
lf[627]=C_h_intern(&lf[627],13,"unsigned-char");
lf[628]=C_h_intern(&lf[628],12,"unsigned-int");
lf[629]=C_h_intern(&lf[629],14,"unsigned-int32");
lf[630]=C_h_intern(&lf[630],4,"byte");
lf[631]=C_h_intern(&lf[631],13,"unsigned-byte");
lf[632]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[647]=C_h_intern(&lf[647],36,"foreign-callback-stub-argument-types");
lf[648]=C_h_intern(&lf[648],33,"foreign-callback-stub-return-type");
lf[649]=C_h_intern(&lf[649],24,"foreign-callback-stub-id");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[652]=C_h_intern(&lf[652],32,"foreign-callback-stub-qualifiers");
lf[653]=C_h_intern(&lf[653],26,"foreign-callback-stub-name");
lf[654]=C_h_intern(&lf[654],4,"quit");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[666]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[669]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[672]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[674]=C_h_intern(&lf[674],11,"byte-vector");
lf[675]=C_h_intern(&lf[675],19,"nonnull-byte-vector");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[677]=C_h_intern(&lf[677],4,"blob");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[679]=C_h_intern(&lf[679],9,"u16vector");
lf[680]=C_h_intern(&lf[680],17,"nonnull-u16vector");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[682]=C_h_intern(&lf[682],8,"s8vector");
lf[683]=C_h_intern(&lf[683],16,"nonnull-s8vector");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[685]=C_h_intern(&lf[685],9,"u32vector");
lf[686]=C_h_intern(&lf[686],17,"nonnull-u32vector");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[688]=C_h_intern(&lf[688],9,"s16vector");
lf[689]=C_h_intern(&lf[689],17,"nonnull-s16vector");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[691]=C_h_intern(&lf[691],9,"s32vector");
lf[692]=C_h_intern(&lf[692],17,"nonnull-s32vector");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[694]=C_h_intern(&lf[694],9,"f32vector");
lf[695]=C_h_intern(&lf[695],17,"nonnull-f32vector");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[697]=C_h_intern(&lf[697],9,"f64vector");
lf[698]=C_h_intern(&lf[698],17,"nonnull-f64vector");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[705]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[710]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[711]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[713]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[722]=C_h_intern(&lf[722],3,"...");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[727]=C_h_intern(&lf[727],9,"\003syserror");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[729]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[730]=C_h_intern(&lf[730],4,"enum");
lf[731]=C_h_intern(&lf[731],5,"union");
lf[732]=C_h_intern(&lf[732],6,"struct");
lf[733]=C_h_intern(&lf[733],8,"template");
lf[734]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[735]=C_h_intern(&lf[735],12,"nonnull-blob");
lf[736]=C_h_intern(&lf[736],8,"u8vector");
lf[737]=C_h_intern(&lf[737],16,"nonnull-u8vector");
lf[738]=C_h_intern(&lf[738],14,"scheme-pointer");
lf[739]=C_h_intern(&lf[739],22,"nonnull-scheme-pointer");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[834]=C_h_intern(&lf[834],17,"\003sysstring-append");
lf[835]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[836]=C_h_intern(&lf[836],5,"cons*");
lf[837]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[838]=C_h_intern(&lf[838],6,"random");
C_register_lf2(lf,839,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2432,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2430 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2435,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2433 in k2430 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2436 in k2433 in k2430 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2447,2,t0,t1);}
t2=C_set_block_item(lf[0] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1 /* (set! gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2450,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2471,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9186,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9190,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 100  random */
((C_proc3)C_retrieve_symbol_proc(lf[838]))(3,*((C_word*)lf[838]+1),t7,C_fix(16777216));}

/* k9188 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9194,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 100  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[225]))(2,*((C_word*)lf[225]+1),t2);}

/* k9192 in k9188 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 100  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[353]))(5,*((C_word*)lf[353]+1),((C_word*)t0)[3],lf[837],((C_word*)t0)[2],t1);}

/* k9184 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 99   string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[523]))(3,*((C_word*)lf[523]+1),((C_word*)t0)[2],t1);}

/* k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1 /* (set! unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[8]+1 /* (set! generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2491,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[499]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6190,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[489]+1 /* (set! cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6267,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[279]+1 /* (set! make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6356,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[289]+1 /* (set! make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6372,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[503]+1 /* (set! generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6388,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[199]+1 /* (set! generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6420,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[501]+1 /* (set! generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6438,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[500]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6671,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[532]+1 /* (set! generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7102,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[173]+1 /* (set! foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7167,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[172]+1 /* (set! foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8003,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[167]+1 /* (set! foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8488,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[349]+1 /* (set! encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8886,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_8886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8886,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8895,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8948,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t4;
f_8948(2,t6,lf[821]);}
else{
t6=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t4;
f_8948(2,t7,lf[822]);}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(C_word)C_fix((C_word)C_character_code(t2));
t8=f_8895(C_a_i(&a,4),t7);
/* c-backend.scm: 1408 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t4,lf[823],t8);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t7=t4;
f_8948(2,t7,lf[824]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t7=t4;
f_8948(2,t7,lf[825]);}
else{
t7=C_retrieve(lf[338]);
t8=(C_word)C_eqp(t7,t2);
if(C_truep(t8)){
t9=t4;
f_8948(2,t9,lf[826]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9066,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1413 big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),t9,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9079,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1422 number->string */
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_i_string_length(t9);
t11=f_8895(C_a_i(&a,4),t10);
/* c-backend.scm: 1425 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t4,lf[832],t11,t9);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1430 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),t4,lf[833],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9118,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=(C_word)stub2371(C_SCHEME_UNDEFINED,t10);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,1,t12);
t14=t2;
t15=(C_word)stub2376(C_SCHEME_UNDEFINED,t14);
t16=f_8895(C_a_i(&a,4),t15);
/* c-backend.scm: 1433 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t9,t13,t16);}
else{
t9=t2;
t10=(C_word)stub2376(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9148,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=(C_word)stub2371(C_SCHEME_UNDEFINED,t12);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8895(C_a_i(&a,4),t10);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9160,a[2]=t16,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9162,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1443 list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t17,t10,t18);}}}}}}}}}}}}

/* a9161 in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9162,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1443 encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t1,t3);}

/* k9158 in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1440 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[836]))(5,*((C_word*)lf[836]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9146 in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1439 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[835]);}

/* k9116 in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1432 ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[834]))(4,*((C_word*)lf[834]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9077 in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1422 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[830],t1,lf[831]);}

/* k9064 in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9066,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9062,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1420 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1414 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[829],t13);}}

/* k9060 in k9064 in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_9062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1420 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[827],t1,lf[828]);}

/* k8946 in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_8948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8948,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1404 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static C_word C_fcall f_8895(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* ##compiler#foreign-result-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8488,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8490,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[627]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[795]);}
else{
t8=(C_word)C_eqp(t5,lf[622]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[623]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[796]);}
else{
t10=(C_word)C_eqp(t5,lf[628]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[629]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[797]);}
else{
t12=(C_word)C_eqp(t5,lf[624]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[798]);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[799]);}
else{
t14=(C_word)C_eqp(t5,lf[630]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[800]);}
else{
t15=(C_word)C_eqp(t5,lf[631]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[801]);}
else{
t16=(C_word)C_eqp(t5,lf[582]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[611]));
if(C_truep(t17)){
/* c-backend.scm: 1342 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t1,lf[802],t3);}
else{
t18=(C_word)C_eqp(t5,lf[618]);
if(C_truep(t18)){
/* c-backend.scm: 1343 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t1,lf[803],t3);}
else{
t19=(C_word)C_eqp(t5,lf[588]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8575,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8575(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t21)){
t22=t20;
f_8575(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[597]);
if(C_truep(t22)){
t23=t20;
f_8575(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t23)){
t24=t20;
f_8575(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t24)){
t25=t20;
f_8575(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t25)){
t26=t20;
f_8575(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[610]);
if(C_truep(t26)){
t27=t20;
f_8575(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t27)){
t28=t20;
f_8575(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t28)){
t29=t20;
f_8575(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t29)){
t30=t20;
f_8575(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[620]);
t31=t20;
f_8575(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[621])));}}}}}}}}}}}}}}}}}}}}

/* k8573 in ##compiler#foreign-result-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8575(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8575,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1347 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[804],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t2)){
/* c-backend.scm: 1348 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[805],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[616]));
if(C_truep(t4)){
/* c-backend.scm: 1349 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[806],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
if(C_truep(t5)){
/* c-backend.scm: 1350 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[807],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[613]));
if(C_truep(t7)){
/* c-backend.scm: 1351 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[808],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t8)){
/* c-backend.scm: 1352 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[809],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t9)){
/* c-backend.scm: 1353 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[810],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[811]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[545]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[626]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[812]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1357 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t13,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t14=t13;
f_8656(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k8654 in k8573 in ##compiler#foreign-result-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_8656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8656,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1359 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8678(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8678(t3,C_SCHEME_FALSE);}}}

/* k8676 in k8654 in k8573 in ##compiler#foreign-result-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[596]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[597]));
if(C_truep(t4)){
/* c-backend.scm: 1363 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[813],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[591]);
if(C_truep(t5)){
/* c-backend.scm: 1365 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[814],((C_word*)t0)[3]);}
else{
t6=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t6)){
/* c-backend.scm: 1367 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[815],((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t7)){
/* c-backend.scm: 1369 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[816],((C_word*)t0)[3]);}
else{
t8=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t8)){
/* c-backend.scm: 1371 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[817],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(t2,lf[593]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1372 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(t2,lf[594]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[595]));
if(C_truep(t11)){
/* c-backend.scm: 1374 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[818],((C_word*)t0)[3]);}
else{
t12=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t12)){
/* c-backend.scm: 1375 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[819],((C_word*)t0)[3]);}
else{
t13=(C_word)C_eqp(t2,lf[730]);
if(C_truep(t13)){
/* c-backend.scm: 1376 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[820],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1377 err */
t14=((C_word*)t0)[2];
f_8490(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
/* c-backend.scm: 1378 err */
t2=((C_word*)t0)[2];
f_8490(t2,((C_word*)t0)[4]);}}

/* err in ##compiler#foreign-result-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8490,NULL,2,t0,t1);}
/* c-backend.scm: 1333 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[794],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_8003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8003,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8005,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[626]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[741]);}
else{
t6=(C_word)C_eqp(t4,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[627]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[742]);}
else{
t8=(C_word)C_eqp(t4,lf[630]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8033,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_8033(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[622]);
if(C_truep(t10)){
t11=t9;
f_8033(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[628]);
if(C_truep(t11)){
t12=t9;
f_8033(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[629]);
t13=t9;
f_8033(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[631])));}}}}}}

/* k8031 in ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8033,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[743]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[624]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[744]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[625]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[745]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[746]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[611]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_8060(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[618]);
t8=t6;
f_8060(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[582])));}}}}}}

/* k8058 in k8031 in ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8060,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[747]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[616]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[748]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[749]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[750]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[613]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[751]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[594]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[752]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[753]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[738]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[754]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[739]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[755]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[756]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[757]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[677]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[758]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[735]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[759]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[674]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[760]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[761]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[736]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[762]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[737]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[763]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[679]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[764]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[680]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[765]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[685]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[766]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[686]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[767]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[682]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[768]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[683]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[769]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[688]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[770]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[689]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[771]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[691]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[772]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[773]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[694]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[774]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[695]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[775]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[697]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[776]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[698]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[777]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8255(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t36)){
t37=t35;
f_8255(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[609]);
t38=t35;
f_8255(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[610])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8253 in k8058 in k8031 in ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8255,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[778]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8264(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t4)){
t5=t3;
f_8264(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t5)){
t6=t3;
f_8264(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
t7=t3;
f_8264(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[607])));}}}}}

/* k8262 in k8253 in k8058 in k8031 in ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8264,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[779]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[780]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1306 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t3,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8273(2,t4,C_SCHEME_FALSE);}}}}

/* k8271 in k8262 in k8253 in k8058 in k8031 in ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_8273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8273,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1308 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8295(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8295(t3,C_SCHEME_FALSE);}}}

/* k8293 in k8271 in k8262 in k8253 in k8058 in k8031 in ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8295(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8295,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[594]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[781]);}
else{
t4=(C_word)C_eqp(t2,lf[596]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[782]);}
else{
t5=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[783]);}
else{
t6=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[784]);}
else{
t7=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[785]);}
else{
t8=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[786]);}
else{
t9=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[787]);}
else{
t10=(C_word)C_eqp(t2,lf[593]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1319 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),((C_word*)t0)[3],t11);}
else{
t11=(C_word)C_eqp(t2,lf[730]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[788]);}
else{
t12=(C_word)C_eqp(t2,lf[591]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8372,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 1322 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t13,t14,lf[791]);}
else{
t13=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1325 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[792],t14,lf[793]);}
else{
/* c-backend.scm: 1326 err */
t14=((C_word*)t0)[2];
f_8005(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm: 1327 err */
t2=((C_word*)t0)[2];
f_8005(t2,((C_word*)t0)[3]);}}

/* k8370 in k8293 in k8271 in k8262 in k8253 in k8058 in k8031 in ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_8372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1322 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[789],t1,lf[790]);}

/* err in ##compiler#foreign-argument-conversion in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_8005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8005,NULL,2,t0,t1);}
/* c-backend.scm: 1260 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[740],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7167,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7169,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7174,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[626]);
if(C_truep(t7)){
/* c-backend.scm: 1168 str */
t8=t5;
f_7174(t8,t1,lf[657]);}
else{
t8=(C_word)C_eqp(t6,lf[20]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[630]));
if(C_truep(t9)){
/* c-backend.scm: 1169 str */
t10=t5;
f_7174(t10,t1,lf[658]);}
else{
t10=(C_word)C_eqp(t6,lf[627]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[631]));
if(C_truep(t11)){
/* c-backend.scm: 1170 str */
t12=t5;
f_7174(t12,t1,lf[659]);}
else{
t12=(C_word)C_eqp(t6,lf[628]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[612]));
if(C_truep(t13)){
/* c-backend.scm: 1171 str */
t14=t5;
f_7174(t14,t1,lf[660]);}
else{
t14=(C_word)C_eqp(t6,lf[629]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[613]));
if(C_truep(t15)){
/* c-backend.scm: 1172 str */
t16=t5;
f_7174(t16,t1,lf[661]);}
else{
t16=(C_word)C_eqp(t6,lf[622]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7244,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7244(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[615]);
t19=t17;
f_7244(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[17])));}}}}}}}

/* k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7244,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1173 str */
t2=((C_word*)t0)[7];
f_7174(t2,((C_word*)t0)[6],lf[662]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[623]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[616]));
if(C_truep(t3)){
/* c-backend.scm: 1174 str */
t4=((C_word*)t0)[7];
f_7174(t4,((C_word*)t0)[6],lf[663]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t4)){
/* c-backend.scm: 1175 str */
t5=((C_word*)t0)[7];
f_7174(t5,((C_word*)t0)[6],lf[664]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[624]);
if(C_truep(t5)){
/* c-backend.scm: 1176 str */
t6=((C_word*)t0)[7];
f_7174(t6,((C_word*)t0)[6],lf[665]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t6)){
/* c-backend.scm: 1177 str */
t7=((C_word*)t0)[7];
f_7174(t7,((C_word*)t0)[6],lf[666]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[625]);
if(C_truep(t7)){
/* c-backend.scm: 1178 str */
t8=((C_word*)t0)[7];
f_7174(t8,((C_word*)t0)[6],lf[667]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t8)){
/* c-backend.scm: 1179 str */
t9=((C_word*)t0)[7];
f_7174(t9,((C_word*)t0)[6],lf[668]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t9)){
/* c-backend.scm: 1180 str */
t10=((C_word*)t0)[7];
f_7174(t10,((C_word*)t0)[6],lf[669]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[611]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[618]));
if(C_truep(t11)){
/* c-backend.scm: 1181 str */
t12=((C_word*)t0)[7];
f_7174(t12,((C_word*)t0)[6],lf[670]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t13)){
/* c-backend.scm: 1183 str */
t14=((C_word*)t0)[7];
f_7174(t14,((C_word*)t0)[6],lf[671]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7346(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t16)){
t17=t15;
f_7346(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[738]);
t18=t15;
f_7346(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[739])));}}}}}}}}}}}}}

/* k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7346,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1184 str */
t2=((C_word*)t0)[7];
f_7174(t2,((C_word*)t0)[6],lf[672]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[621]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[673]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[674]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[675]));
if(C_truep(t5)){
/* c-backend.scm: 1187 str */
t6=((C_word*)t0)[7];
f_7174(t6,((C_word*)t0)[6],lf[676]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[677]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7379,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7379(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[735]);
if(C_truep(t8)){
t9=t7;
f_7379(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[736]);
t10=t7;
f_7379(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[737])));}}}}}}

/* k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7379,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1188 str */
t2=((C_word*)t0)[7];
f_7174(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[679]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[680]));
if(C_truep(t3)){
/* c-backend.scm: 1189 str */
t4=((C_word*)t0)[7];
f_7174(t4,((C_word*)t0)[6],lf[681]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[682]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[683]));
if(C_truep(t5)){
/* c-backend.scm: 1190 str */
t6=((C_word*)t0)[7];
f_7174(t6,((C_word*)t0)[6],lf[684]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[685]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[686]));
if(C_truep(t7)){
/* c-backend.scm: 1191 str */
t8=((C_word*)t0)[7];
f_7174(t8,((C_word*)t0)[6],lf[687]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[688]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[689]));
if(C_truep(t9)){
/* c-backend.scm: 1192 str */
t10=((C_word*)t0)[7];
f_7174(t10,((C_word*)t0)[6],lf[690]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[691]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[692]));
if(C_truep(t11)){
/* c-backend.scm: 1193 str */
t12=((C_word*)t0)[7];
f_7174(t12,((C_word*)t0)[6],lf[693]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[694]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[695]));
if(C_truep(t13)){
/* c-backend.scm: 1194 str */
t14=((C_word*)t0)[7];
f_7174(t14,((C_word*)t0)[6],lf[696]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[697]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[698]));
if(C_truep(t15)){
/* c-backend.scm: 1195 str */
t16=((C_word*)t0)[7];
f_7174(t16,((C_word*)t0)[6],lf[699]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7475(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t18)){
t19=t17;
f_7475(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[604]);
if(C_truep(t19)){
t20=t17;
f_7475(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t20)){
t21=t17;
f_7475(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[605]);
if(C_truep(t21)){
t22=t17;
f_7475(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[606]);
if(C_truep(t22)){
t23=t17;
f_7475(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[610]);
t24=t17;
f_7475(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[607])));}}}}}}}}}}}}}}}

/* k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7475,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1198 str */
t2=((C_word*)t0)[7];
f_7174(t2,((C_word*)t0)[6],lf[700]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[545]);
if(C_truep(t2)){
/* c-backend.scm: 1199 str */
t3=((C_word*)t0)[7];
f_7174(t3,((C_word*)t0)[6],lf[701]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1201 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t3,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7490(2,t4,C_SCHEME_FALSE);}}}}

/* k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7490,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1203 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1204 str */
t2=((C_word*)t0)[3];
f_7174(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7530,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_7530(t6,(C_word)C_i_memq(t5,lf[734]));}
else{
t5=t3;
f_7530(t5,C_SCHEME_FALSE);}}
else{
/* c-backend.scm: 1254 err */
t2=((C_word*)t0)[2];
f_7169(t2,((C_word*)t0)[6]);}}}}

/* k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7530,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7541,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1211 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t3,lf[702],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=t2;
f_7547(t5,(C_word)C_eqp(lf[591],t4));}
else{
t4=t2;
f_7547(t4,C_SCHEME_FALSE);}}}

/* k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7547,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7558,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1214 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t3,lf[703],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7564(t4,(C_word)C_eqp(lf[733],t3));}
else{
t3=t2;
f_7564(t3,C_SCHEME_FALSE);}}}

/* k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7564,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7571,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1219 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t3,t4,lf[708]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7603(t5,(C_word)C_eqp(lf[593],t4));}
else{
t4=t2;
f_7603(t4,C_SCHEME_FALSE);}}}

/* k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7603,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7610,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1226 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7620(t5,(C_word)C_eqp(lf[732],t4));}
else{
t4=t2;
f_7620(t4,C_SCHEME_FALSE);}}}

/* k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7620,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7627,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1228 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7637(t5,(C_word)C_eqp(lf[731],t4));}
else{
t4=t2;
f_7637(t4,C_SCHEME_FALSE);}}}

/* k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7637,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7644,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1230 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7654(t5,(C_word)C_eqp(lf[730],t4));}
else{
t4=t2;
f_7654(t4,C_SCHEME_FALSE);}}}

/* k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7654,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7661,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1232 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7671(t5,(C_word)C_i_memq(t4,lf[729]));}
else{
t4=t2;
f_7671(t4,C_SCHEME_FALSE);}}}

/* k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7671,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7678,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1234 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7688(t5,(C_word)C_eqp(lf[601],t4));}
else{
t4=t2;
f_7688(t4,C_SCHEME_FALSE);}}}

/* k7686 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7688,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7695,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1236 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7705(t4,(C_word)C_eqp(lf[598],t3));}
else{
t3=t2;
f_7705(t3,C_SCHEME_FALSE);}}}

/* k7703 in k7686 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7705,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7717,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7717(2,t6,lf[726]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7717(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[727]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[728],t4);}}}
else{
/* c-backend.scm: 1253 err */
t2=((C_word*)t0)[2];
f_7169(t2,((C_word*)t0)[4]);}}

/* k7715 in k7703 in k7686 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1242 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[725]);}

/* k7722 in k7715 in k7703 in k7686 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7732,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7734,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7733 in k7722 in k7715 in k7703 in k7686 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7734,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[722],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[723]);}
else{
/* c-backend.scm: 1249 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t1,t2,lf[724]);}}

/* k7730 in k7722 in k7715 in k7703 in k7686 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1245 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[721]);}

/* k7726 in k7722 in k7715 in k7703 in k7686 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1241 string-append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[113]+1)))(9,*((C_word*)lf[113]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[718],((C_word*)t0)[2],lf[719],t1,lf[720]);}

/* k7693 in k7686 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1236 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],t1,lf[717],((C_word*)t0)[2]);}

/* k7676 in k7669 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1234 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],t1,lf[716],((C_word*)t0)[2]);}

/* k7659 in k7652 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1232 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[714],t1,lf[715],((C_word*)t0)[2]);}

/* k7642 in k7635 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1230 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[712],t1,lf[713],((C_word*)t0)[2]);}

/* k7625 in k7618 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1228 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[710],t1,lf[711],((C_word*)t0)[2]);}

/* k7608 in k7601 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1226 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[709],t1);}

/* k7573 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7579,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7583,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7585,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7584 in k7573 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7585,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t1,t2,lf[707]);}

/* k7581 in k7573 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1221 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[706]);}

/* k7577 in k7573 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1218 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[704],t1,lf[705]);}

/* k7569 in k7562 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1217 str */
t2=((C_word*)t0)[3];
f_7174(t2,((C_word*)t0)[2],t1);}

/* k7556 in k7545 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1214 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7539 in k7528 in k7488 in k7473 in k7377 in k7344 in k7242 in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1211 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* str in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7174(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7174,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1166 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t1,t2,lf[656],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_7169(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7169,NULL,2,t0,t1);}
/* c-backend.scm: 1165 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[655],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7102,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7106,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1147 foreign-callback-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[653]))(3,*((C_word*)lf[653]+1),t4,t3);}

/* k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7109,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1148 foreign-callback-stub-qualifiers */
((C_proc3)C_retrieve_symbol_proc(lf[652]))(3,*((C_word*)lf[652]+1),t2,((C_word*)t0)[2]);}

/* k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1149 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[648]))(3,*((C_word*)lf[648]+1),t2,((C_word*)t0)[2]);}

/* k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7115,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1150 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[647]))(3,*((C_word*)lf[647]+1),t2,((C_word*)t0)[2]);}

/* k7113 in k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7115,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1152 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t3,t2,lf[651]);}

/* k7119 in k7113 in k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7124,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1153 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t3,((C_word*)t0)[2],lf[650]);}

/* k7163 in k7119 in k7113 in k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1153 gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k7122 in k7119 in k7113 in k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7127,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7132,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1154 pair-for-each */
((C_proc5)C_retrieve_symbol_proc(lf[196]))(5,*((C_word*)lf[196]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7131 in k7122 in k7119 in k7113 in k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7132,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7136,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7153,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1156 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t5,t6,t7);}

/* k7151 in a7131 in k7122 in k7119 in k7113 in k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1156 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* k7134 in a7131 in k7122 in k7119 in k7113 in k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1157 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7125 in k7122 in k7119 in k7113 in k7110 in k7107 in k7104 in ##compiler#generate-foreign-callback-header in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1159 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6671,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6677,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6677,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6681,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1094 foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[649]))(3,*((C_word*)lf[649]+1),t3,t2);}

/* k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6684,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1095 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[580]))(4,*((C_word*)lf[580]+1),t2,t1,((C_word*)t0)[2]);}

/* k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6687,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1096 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[648]))(3,*((C_word*)lf[648]+1),t2,((C_word*)t0)[2]);}

/* k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1097 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[647]))(3,*((C_word*)lf[647]+1),t2,((C_word*)t0)[3]);}

/* k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6690,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1099 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t3,t2,lf[646]);}

/* k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6696,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6698,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1126 fold */
((C_proc6)C_retrieve_symbol_proc(lf[434]))(6,*((C_word*)lf[434]+1),t5,((C_word*)t3)[1],lf[645],((C_word*)t0)[4],t1);}

/* k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1127 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1129 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_7043(2,t3,C_SCHEME_UNDEFINED);}}

/* k7098 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1129 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[643],t1,lf[644]);}

/* k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1130 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[532]))(4,*((C_word*)lf[532]+1),t2,lf[642],((C_word*)t0)[2]);}

/* k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1131 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_make_character(123),C_SCHEME_TRUE,lf[640],((C_word*)t0)[2],lf[641]);}

/* k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1132 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[639]);}

/* k7050 in k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7085,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1133 for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7084 in k7050 in k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7085,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7093,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1135 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t4,t3,lf[638]);}

/* k7091 in a7084 in k7050 in k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1135 gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[635],t1,((C_word*)t0)[2],lf[636],C_SCHEME_TRUE,lf[637]);}

/* k7053 in k7050 in k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[545],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_7058(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7083,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1140 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t4,((C_word*)t0)[4]);}}

/* k7081 in k7053 in k7050 in k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1140 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[634],t1);}

/* k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7061,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1141 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[633],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7064,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[545],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_7064(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1142 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k7062 in k7059 in k7056 in k7053 in k7050 in k7047 in k7044 in k7041 in k7038 in k7035 in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_7064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1143 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[632]);}

/* compute-size in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6698,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6708,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6708(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[622]);
if(C_truep(t8)){
t9=t7;
f_6708(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[623]);
if(C_truep(t9)){
t10=t7;
f_6708(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[624]);
if(C_truep(t10)){
t11=t7;
f_6708(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t11)){
t12=t7;
f_6708(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[545]);
if(C_truep(t12)){
t13=t7;
f_6708(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
t14=t7;
f_6708(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[626]);
if(C_truep(t14)){
t15=t7;
f_6708(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[627]);
if(C_truep(t15)){
t16=t7;
f_6708(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[628]);
if(C_truep(t16)){
t17=t7;
f_6708(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[629]);
if(C_truep(t17)){
t18=t7;
f_6708(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[630]);
t19=t7;
f_6708(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[631])));}}}}}}}}}}}}

/* k6706 in compute-size in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6708,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6717(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[611]);
if(C_truep(t4)){
t5=t3;
f_6717(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t5)){
t6=t3;
f_6717(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[612]);
if(C_truep(t6)){
t7=t3;
f_6717(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[613]);
if(C_truep(t7)){
t8=t3;
f_6717(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t8)){
t9=t3;
f_6717(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[615]);
if(C_truep(t9)){
t10=t3;
f_6717(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[616]);
if(C_truep(t10)){
t11=t3;
f_6717(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t11)){
t12=t3;
f_6717(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t12)){
t13=t3;
f_6717(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[618]);
if(C_truep(t13)){
t14=t3;
f_6717(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t14)){
t15=t3;
f_6717(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
t16=t3;
f_6717(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[621])));}}}}}}}}}}}}}}

/* k6715 in k6706 in compute-size in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6717,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1108 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[583]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6729(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t4)){
t5=t3;
f_6729(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
if(C_truep(t5)){
t6=t3;
f_6729(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
t7=t3;
f_6729(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[610])));}}}}}

/* k6727 in k6715 in k6706 in compute-size in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6729,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1110 string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[113]+1)))(8,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[585],((C_word*)t0)[5],lf[586],((C_word*)t0)[5],lf[587]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6741(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t4)){
t5=t3;
f_6741(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t5)){
t6=t3;
f_6741(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
t7=t3;
f_6741(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[607])));}}}}}

/* k6739 in k6727 in k6715 in k6706 in compute-size in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6741,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1112 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[589],((C_word*)t0)[4],lf[590]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1114 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t2,C_retrieve(lf[603]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6747(2,t3,C_SCHEME_FALSE);}}}

/* k6745 in k6739 in k6727 in k6715 in k6706 in compute-size in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6747,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1116 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6698(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[591]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6781,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6781(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[594]);
if(C_truep(t5)){
t6=t4;
f_6781(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t6)){
t7=t4;
f_6781(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[596]);
if(C_truep(t7)){
t8=t4;
f_6781(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t8)){
t9=t4;
f_6781(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t9)){
t10=t4;
f_6781(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t10)){
t11=t4;
f_6781(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[600]);
t12=t4;
f_6781(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[601])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6779 in k6745 in k6739 in k6727 in k6715 in k6706 in compute-size in k6694 in k6688 in k6685 in k6682 in k6679 in a6676 in generate-foreign-callback-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1121 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[592]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1122 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6698(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6438,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6444,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6444,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6448,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1027 foreign-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[581]))(3,*((C_word*)lf[581]+1),t3,t2);}

/* k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6451,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1028 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[580]))(4,*((C_word*)lf[580]+1),t2,t1,((C_word*)t0)[2]);}

/* k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6454,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1029 foreign-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[579]))(3,*((C_word*)lf[579]+1),t2,((C_word*)t0)[2]);}

/* k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6669,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1031 make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t4,t2,lf[578]);}

/* k6667 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6669,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[577],t1);
/* c-backend.scm: 1031 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t2,C_make_character(44));}

/* k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1032 foreign-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[576]))(3,*((C_word*)lf[576]+1),t2,((C_word*)t0)[2]);}

/* k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1033 foreign-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[575]))(3,*((C_word*)lf[575]+1),t2,((C_word*)t0)[2]);}

/* k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1034 foreign-stub-body */
((C_proc3)C_retrieve_symbol_proc(lf[574]))(3,*((C_word*)lf[574]+1),t2,((C_word*)t0)[2]);}

/* k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1035 foreign-stub-argument-names */
((C_proc3)C_retrieve_symbol_proc(lf[573]))(3,*((C_word*)lf[573]+1),t2,((C_word*)t0)[2]);}

/* k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_6475(2,t3,t1);}
else{
/* c-backend.scm: 1035 make-list */
((C_proc4)C_retrieve_symbol_proc(lf[240]))(4,*((C_word*)lf[240]+1),t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1036 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t2,((C_word*)t0)[9],lf[572]);}

/* k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1037 foreign-stub-cps */
((C_proc3)C_retrieve_symbol_proc(lf[571]))(3,*((C_word*)lf[571]+1),t2,((C_word*)t0)[2]);}

/* k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1038 foreign-stub-callback */
((C_proc3)C_retrieve_symbol_proc(lf[570]))(3,*((C_word*)lf[570]+1),t2,((C_word*)t0)[2]);}

/* k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1039 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6658,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1041 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6490(2,t3,C_SCHEME_UNDEFINED);}}

/* k6656 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1041 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[568],t1,lf[569]);}

/* k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1043 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[566],((C_word*)t0)[6],lf[567]);}
else{
t3=t2;
f_6493(2,t3,C_SCHEME_UNDEFINED);}}

/* k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1046 gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[561],((C_word*)t0)[2],lf[562],C_SCHEME_TRUE,lf[563],((C_word*)t0)[2],lf[564]);}
else{
/* c-backend.scm: 1048 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[565],((C_word*)t0)[2],C_make_character(40));}}

/* k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[3]);}

/* k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1051 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[556],C_SCHEME_TRUE,lf[557],((C_word*)t0)[2],lf[558]);}
else{
/* c-backend.scm: 1052 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[559],C_SCHEME_TRUE,lf[560],((C_word*)t0)[2],C_make_character(40));}}

/* k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1054 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[555]);}

/* k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1055 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[554]);}

/* k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6606,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1064 iota */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t4,((C_word*)t0)[6]);}

/* k6634 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1056 for-each */
((C_proc6)C_retrieve_proc(*((C_word*)lf[63]+1)))(6,*((C_word*)lf[63]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6605 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6606,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6614,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6626,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1061 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t6,t4);}
else{
/* c-backend.scm: 1061 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t6,lf[553],t3);}}

/* k6624 in a6605 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1059 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6612 in a6605 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1062 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[552]);}

/* k6616 in k6612 in a6605 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6622,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1063 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k6620 in k6616 in k6612 in a6605 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1058 gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[549],((C_word*)t0)[3],C_make_character(41),t1,lf[550],((C_word*)t0)[2],lf[551]);}

/* k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1065 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[548]);}
else{
t3=t2;
f_6517(2,t3,C_SCHEME_UNDEFINED);}}

/* k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6520,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6526,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1067 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[539]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[545]);
if(C_truep(t4)){
/* c-backend.scm: 1078 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1077 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[547],((C_word*)t0)[2]);}}}

/* k6545 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1079 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(40));}

/* k6548 in k6545 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6584,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6588,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1080 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[2],lf[546]);}

/* k6586 in k6548 in k6545 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1080 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k6582 in k6548 in k6545 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k6551 in k6548 in k6545 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6556,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[545]);
if(C_truep(t3)){
t4=t2;
f_6556(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1081 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k6554 in k6551 in k6548 in k6545 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1082 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[544]);}

/* k6557 in k6554 in k6551 in k6548 in k6545 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1084 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[540],C_SCHEME_TRUE,lf[541]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1086 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[542]);}
else{
/* c-backend.scm: 1087 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[543]);}}}

/* k6524 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6529,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1069 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[538],C_SCHEME_TRUE);}

/* k6527 in k6524 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1071 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[534],C_SCHEME_TRUE,lf[535]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1073 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[536]);}
else{
/* c-backend.scm: 1074 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[537]);}}}

/* k6518 in k6515 in k6512 in k6509 in k6506 in k6503 in k6500 in k6497 in k6494 in k6491 in k6488 in k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6452 in k6449 in k6446 in a6443 in ##compiler#generate-foreign-stubs in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1088 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6426,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6425 in ##compiler#generate-foreign-callback-stub-prototypes in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6426,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6430,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1019 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6428 in a6425 in ##compiler#generate-foreign-callback-stub-prototypes in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6433,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1020 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[532]))(4,*((C_word*)lf[532]+1),t2,lf[533],((C_word*)t0)[2]);}

/* k6431 in k6428 in a6425 in ##compiler#generate-foreign-callback-stub-prototypes in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1021 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6388,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6392,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1004 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6390 in ##compiler#generate-external-variables in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6397,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6396 in k6390 in ##compiler#generate-external-variables in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6397,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=(C_word)C_i_vector_ref(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(t2,C_fix(2));
t6=(C_truep(t5)?lf[530]:lf[531]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6418,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1010 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t7,t4,t3);}

/* k6416 in a6396 in k6390 in ##compiler#generate-external-variables in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1010 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6372,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6378,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 996  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t1,t2,t4);}

/* a6377 in ##compiler#make-argument-list in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6378,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6386,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 998  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6384 in a6377 in ##compiler#make-argument-list in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 998  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6356,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6362,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 991  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t1,t2,t4);}

/* a6361 in ##compiler#make-variable-list in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6362,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 993  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6368 in a6361 in ##compiler#make-variable-list in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 993  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[528],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6267,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6276,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6276(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6276(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6276,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6292,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6305,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_6305(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_6305(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_6305(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_6305(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_6305(t10,C_SCHEME_FALSE);}}}}}

/* k6303 in loop in ##compiler#cleanup in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6305,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6308,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_6308(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6315,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 982  string-copy */
((C_proc3)C_retrieve_symbol_proc(lf[527]))(3,*((C_word*)lf[527]+1),t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_6292(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k6313 in k6303 in loop in ##compiler#cleanup in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6308(t3,t2);}

/* k6306 in k6303 in loop in ##compiler#cleanup in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_6292(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k6290 in loop in ##compiler#cleanup in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 985  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6276(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6190,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6194,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 947  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[524],C_SCHEME_TRUE,lf[525],t6,lf[526]);}

/* k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6197,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6208,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6208(t6,t2,((C_word*)t0)[2]);}

/* doloop1262 in k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6208,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 951  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[516]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6221,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 952  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t4);}}

/* k6219 in doloop1262 in k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6224,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6253,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 953  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[523]))(3,*((C_word*)lf[523]+1),t3,((C_word*)t0)[2]);}

/* k6251 in k6219 in doloop1262 in k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 953  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[521],((C_word*)t0)[2],C_make_character(58),t1,lf[522]);}

/* k6222 in k6219 in doloop1262 in k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 956  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[517],C_retrieve(lf[206]),lf[518]);}
else{
/* c-backend.scm: 957  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[519]);}}
else{
/* c-backend.scm: 958  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[520]);}}

/* k6225 in k6222 in k6219 in doloop1262 in k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6208(t3,((C_word*)t0)[2],t2);}

/* k6195 in k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6200,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 959  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[515]);}

/* k6198 in k6195 in k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6203,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 960  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[514]);}

/* k6201 in k6198 in k6195 in k6192 in emit-procedure-table-info in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 961  gen */
((C_proc15)C_retrieve_symbol_proc(lf[1]))(15,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[507],C_SCHEME_TRUE,lf[508],C_SCHEME_TRUE,lf[509],C_SCHEME_TRUE,lf[510],C_SCHEME_TRUE,lf[511],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}

/* ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2491,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2526,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2536,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4144,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4291,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4440,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4691,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5398,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5321,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5014,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5179,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4977,a[2]=t2,a[3]=t19,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5020,a[2]=t18,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5410,a[2]=t4,a[3]=t8,a[4]=t22,a[5]=t20,a[6]=t2,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
t25=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6157,a[2]=t12,a[3]=t13,a[4]=t14,a[5]=t8,a[6]=t15,a[7]=t24,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 930  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[490]))(4,*((C_word*)lf[490]+1),t25,lf[505],lf[506]);}

/* k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6157,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 932  header */
t4=((C_word*)t0)[2];
f_4144(t4,t3);}

/* k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6164,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 933  declarations */
t3=((C_word*)t0)[2];
f_4291(t3,t2);}

/* k6162 in k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 934  generate-external-variables */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t2,C_retrieve(lf[504]));}

/* k6165 in k6162 in k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 935  generate-foreign-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[501]))(4,*((C_word*)lf[501]+1),t2,C_retrieve(lf[502]),((C_word*)t0)[3]);}

/* k6168 in k6165 in k6162 in k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 936  prototypes */
t3=((C_word*)t0)[2];
f_4440(t3,t2);}

/* k6171 in k6168 in k6165 in k6162 in k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 937  generate-foreign-callback-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[500]))(4,*((C_word*)lf[500]+1),t2,C_retrieve(lf[200]),((C_word*)t0)[2]);}

/* k6174 in k6171 in k6168 in k6165 in k6162 in k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 938  trampolines */
t3=((C_word*)t0)[2];
f_4691(t3,t2);}

/* k6177 in k6174 in k6171 in k6168 in k6165 in k6162 in k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 939  procedures */
t3=((C_word*)t0)[2];
f_5410(t3,t2);}

/* k6180 in k6177 in k6174 in k6171 in k6168 in k6165 in k6162 in k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6185,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 940  emit-procedure-table-info */
((C_proc4)C_retrieve_symbol_proc(lf[499]))(4,*((C_word*)lf[499]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6183 in k6180 in k6177 in k6174 in k6171 in k6168 in k6165 in k6162 in k6159 in k6155 in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 511  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[498],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5410(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5410,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5416,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 754  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 755  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[6]);}

/* k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5426,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 756  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[497]))(4,*((C_word*)lf[497]+1),t2,t1,((C_word*)t0)[2]);}

/* k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5429,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 757  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,((C_word*)t0)[6]);}

/* k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 758  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[7]);}

/* k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5432,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 759  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t4,((C_word*)t0)[8]);}

/* k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6154,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 760  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5438(t3,C_SCHEME_FALSE);}}

/* k6152 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5438(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5438,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 762  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t4,((C_word*)t0)[13],lf[496]);}

/* k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5447,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 763  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t2,((C_word*)t0)[13],lf[495]);}

/* k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5450,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 764  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,t3,C_make_character(44));}

/* k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 765  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,t3,C_make_character(44));}

/* k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 766  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t2,((C_word*)t0)[12]);}

/* k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 767  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t2,((C_word*)t0)[13]);}

/* k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 768  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[14]);}

/* k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 769  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[15]);}

/* k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 770  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[16]);}

/* k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 772  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t2,C_retrieve(lf[206]),lf[493]);}
else{
t3=t2;
f_5471(2,t3,lf[494]);}}

/* k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 774  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[490]))(5,*((C_word*)lf[490]+1),t2,lf[491],lf[492],((C_word*)t0)[14]);}
else{
t3=t2;
f_5474(2,t3,C_SCHEME_UNDEFINED);}}

/* k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 775  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6123,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 776  cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}

/* k6121 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 776  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[487],t1,lf[488],C_SCHEME_TRUE);}

/* k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 785  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[481]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6084,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 778  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[486]);}}

/* k6082 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[484]:lf[485]);
/* c-backend.scm: 779  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,t3);}

/* k6085 in k6082 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 781  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[482]);}
else{
/* c-backend.scm: 782  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[483]);}}

/* k6088 in k6085 in k6082 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 783  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6104 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=t2;
f_6109(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 787  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[480]);}}

/* k6107 in k6104 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 788  gen */
((C_proc16)C_retrieve_symbol_proc(lf[1]))(16,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[474],C_SCHEME_TRUE,lf[475],C_SCHEME_TRUE,lf[476],C_SCHEME_TRUE,lf[477],((C_word*)t0)[2],lf[478],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[479],((C_word*)t0)[2]);}

/* k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 793  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5489(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 794  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[473]);}}

/* k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6056,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_6056(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6056(t4,C_SCHEME_FALSE);}}

/* k6054 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6056(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6056,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 796  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[472]);}
else{
t2=((C_word*)t0)[2];
f_5492(2,t2,C_SCHEME_UNDEFINED);}}

/* k6057 in k6054 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 797  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_5492(2,t2,C_SCHEME_UNDEFINED);}}

/* k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[15]);}

/* k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 799  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[471]);}
else{
t3=t2;
f_5498(2,t3,C_SCHEME_UNDEFINED);}}

/* k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 800  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[470]);}

/* k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[244]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_5504(t5,t4);}
else{
t4=t2;
f_5504(t4,C_SCHEME_UNDEFINED);}}

/* k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5504,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 802  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[469]);}

/* k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 804  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[467],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6018,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_6018(t8,t2,((C_word*)t0)[20],t4);}}

/* doloop1015 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_6018(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6018,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6028,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 808  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[468],t2,C_make_character(59));}}

/* k6026 in doloop1015 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_6018(t4,((C_word*)t0)[2],t2,t3);}

/* k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5805,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 810  fold */
((C_proc5)C_retrieve_symbol_proc(lf[434]))(5,*((C_word*)lf[434]+1),t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 844  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[448]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5883,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_5961(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_5961(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k5959 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5961,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 858  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[458],C_SCHEME_TRUE,lf[459],C_SCHEME_TRUE,lf[460],((C_word*)t0)[3],lf[461]);}
else{
/* c-backend.scm: 861  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[462],((C_word*)t0)[3],lf[463]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5973,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5973(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 863  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[466]);}}}

/* k5971 in k5959 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 864  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[465]);}
else{
t3=t2;
f_5976(2,t3,C_SCHEME_UNDEFINED);}}

/* k5974 in k5971 in k5959 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5982,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[129]);
t4=t2;
f_5982(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[428]))));}
else{
t3=t2;
f_5982(t3,C_SCHEME_FALSE);}}

/* k5980 in k5974 in k5971 in k5959 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5982(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 866  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[464]);}
else{
t2=((C_word*)t0)[2];
f_5883(2,t2,C_SCHEME_UNDEFINED);}}

/* k5881 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5925,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[129]);
if(C_truep(t4)){
t5=t3;
f_5925(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[442]);
t6=t3;
f_5925(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5925(t4,C_SCHEME_FALSE);}}

/* k5923 in k5881 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5925(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[244]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 870  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[452],((C_word*)t0)[3],lf[453],((C_word*)t0)[3],lf[454]);}
else{
t4=((C_word*)t0)[2];
f_5886(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 871  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[455],((C_word*)t0)[3],lf[456],((C_word*)t0)[3],lf[457]);}}
else{
t2=((C_word*)t0)[2];
f_5886(2,t2,C_SCHEME_UNDEFINED);}}

/* k5884 in k5881 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5892,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5892(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_5892(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_5892(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k5890 in k5884 in k5881 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5892,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[437]))){
/* c-backend.scm: 873  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[451]);}
else{
t3=t2;
f_5895(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_5513(2,t2,C_SCHEME_UNDEFINED);}}

/* k5893 in k5890 in k5884 in k5881 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5901,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_5901(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_5901(t3,C_SCHEME_FALSE);}}

/* k5899 in k5893 in k5890 in k5884 in k5881 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5901(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 875  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[449]);}
else{
/* c-backend.scm: 876  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[450]);}}

/* k5817 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 845  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[447]);}

/* k5820 in k5817 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 846  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[446]);}

/* k5823 in k5820 in k5817 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 848  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 849  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[445]);}}

/* k5826 in k5823 in k5820 in k5817 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 850  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[443],((C_word*)t0)[3],lf[444]);}

/* k5829 in k5826 in k5823 in k5820 in k5817 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5834,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5846,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[129]);
if(C_truep(t4)){
t5=t3;
f_5846(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[442]);
if(C_truep(t5)){
t6=t3;
f_5846(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_5846(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5844 in k5829 in k5826 in k5823 in k5820 in k5817 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 852  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[439],((C_word*)t0)[2],lf[440],((C_word*)t0)[2],lf[441]);}
else{
t2=((C_word*)t0)[3];
f_5834(2,t2,C_SCHEME_UNDEFINED);}}

/* k5832 in k5829 in k5826 in k5823 in k5820 in k5817 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[437]))){
/* c-backend.scm: 853  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[438]);}
else{
t3=t2;
f_5837(2,t3,C_SCHEME_UNDEFINED);}}

/* k5835 in k5832 in k5829 in k5826 in k5823 in k5820 in k5817 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 854  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[435],((C_word*)t0)[2],lf[436]);}

/* a5804 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5805,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5813,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 810  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5020(3,t5,t4,t2);}

/* k5811 in a5804 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5730,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5736,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 812  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[430],C_SCHEME_TRUE,lf[431],C_SCHEME_TRUE,lf[432],((C_word*)t0)[2],lf[433]);}

/* k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[428]))){
/* c-backend.scm: 816  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[429]);}
else{
t3=t2;
f_5739(2,t3,C_SCHEME_UNDEFINED);}}

/* k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=t2;
f_5742(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5773,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[421]))){
/* c-backend.scm: 819  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[422],C_retrieve(lf[421]),lf[423]);}
else{
if(C_truep(C_retrieve(lf[424]))){
/* c-backend.scm: 821  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[425],C_retrieve(lf[424]),lf[426],C_SCHEME_TRUE,lf[427]);}
else{
t4=t3;
f_5773(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k5771 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[419]))){
/* c-backend.scm: 824  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[420],C_retrieve(lf[419]),C_make_character(59));}
else{
t3=t2;
f_5776(2,t3,C_SCHEME_UNDEFINED);}}

/* k5774 in k5771 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[417]))){
/* c-backend.scm: 826  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[418],C_retrieve(lf[417]),C_make_character(59));}
else{
t3=t2;
f_5779(2,t3,C_SCHEME_UNDEFINED);}}

/* k5777 in k5774 in k5771 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[414]))){
/* c-backend.scm: 828  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[415],C_retrieve(lf[414]),lf[416]);}
else{
t2=((C_word*)t0)[2];
f_5742(2,t2,C_SCHEME_UNDEFINED);}}

/* k5740 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 829  gen */
((C_proc16)C_retrieve_symbol_proc(lf[1]))(16,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[407],((C_word*)t0)[3],lf[408],C_SCHEME_TRUE,lf[409],((C_word*)t0)[3],lf[410],C_SCHEME_TRUE,lf[411],C_SCHEME_TRUE,lf[412],C_SCHEME_TRUE,lf[413]);}

/* k5743 in k5740 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 834  gen */
((C_proc14)C_retrieve_symbol_proc(lf[1]))(14,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[401],((C_word*)t0)[2],lf[402],C_SCHEME_TRUE,lf[403],C_SCHEME_TRUE,lf[404],((C_word*)t0)[2],lf[405],C_SCHEME_TRUE,lf[406]);}

/* k5746 in k5743 in k5740 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 838  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[399],((C_word*)t0)[2],lf[400]);}

/* k5749 in k5746 in k5743 in k5740 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5751,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5513(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 840  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[397],((C_word*)t0)[4],lf[398]);}}

/* k5758 in k5749 in k5746 in k5743 in k5740 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 841  literal-frame */
t3=((C_word*)t0)[2];
f_4977(t3,t2);}

/* k5761 in k5758 in k5749 in k5746 in k5743 in k5740 in k5737 in k5734 in k5728 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 842  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[395],((C_word*)t0)[2],lf[396]);}

/* k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[255],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_5536(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5536(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_5536(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_5536(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_5536(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5536(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5536,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[386]:lf[387]);
/* c-backend.scm: 887  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t4,lf[388],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5671,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[392]:lf[393]);
/* c-backend.scm: 913  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t4,lf[394]);}}
else{
t2=((C_word*)t0)[10];
f_5516(2,t2,C_SCHEME_UNDEFINED);}}

/* k5669 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5674,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 915  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[3],lf[390]);}
else{
/* c-backend.scm: 916  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[391],((C_word*)t0)[3]);}}

/* k5672 in k5669 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 918  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5677(2,t3,C_SCHEME_UNDEFINED);}}

/* k5684 in k5672 in k5669 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5675 in k5672 in k5669 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 920  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[389]);}

/* k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[329]);
if(C_truep(t3)){
/* c-backend.scm: 888  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t4=t2;
f_5545(2,t4,C_SCHEME_UNDEFINED);}}

/* k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 889  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[384],((C_word*)t0)[5],lf[385]);}

/* k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 891  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5551(2,t3,C_SCHEME_UNDEFINED);}}

/* k5650 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 893  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t2,lf[380],C_SCHEME_TRUE,lf[381],C_SCHEME_TRUE,lf[382],((C_word*)t0)[6],lf[383]);}

/* k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[375]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 897  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[376],((C_word*)t0)[6],lf[377]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[329]);
if(C_truep(t5)){
/* c-backend.scm: 898  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[6],lf[379]);}
else{
t6=t2;
f_5557(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 899  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[374]);}

/* k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5621,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5625,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 900  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[5],lf[373]);}

/* k5623 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 900  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k5619 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 901  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[371],((C_word*)t0)[5],lf[372]);}

/* k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 903  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[369],((C_word*)t0)[2],lf[370]);}

/* k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 905  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[367],((C_word*)t0)[3],lf[368]);}

/* k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 906  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[366]);}

/* k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5596,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5596(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1179 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5596(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5596,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5606,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 910  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[365],t2,C_make_character(59));}}

/* k5604 in doloop1179 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5596(t4,((C_word*)t0)[2],t2,t3);}

/* k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5534 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 911  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[363],((C_word*)t0)[3],lf[364]);}
else{
t3=((C_word*)t0)[2];
f_5516(2,t3,C_SCHEME_UNDEFINED);}}

/* k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5519,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 922  lambda-literal-body */
((C_proc3)C_retrieve_symbol_proc(lf[362]))(3,*((C_word*)lf[362]+1),t3,((C_word*)t0)[2]);}

/* k5524 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 921  expression */
t3=((C_word*)t0)[4];
f_2536(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k5517 in k5514 in k5511 in k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in a5415 in procedures in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 927  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5020,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 689  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[361]))(3,*((C_word*)lf[361]+1),t3,t2);}

/* k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[355]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 693  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5020(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5087,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5091,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 694  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[358]+1)))(3,*((C_word*)lf[358]+1),t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 695  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,((C_word*)t0)[4]);}}}}}}}

/* k5099 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5101,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 696  bad-literal */
f_5014(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 698  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[360]+1)))(3,*((C_word*)lf[360]+1),t2,((C_word*)t0)[4]);}}}}

/* k5117 in k5099 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5119,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 698  words */
((C_proc3)C_retrieve_symbol_proc(lf[359]))(3,*((C_word*)lf[359]+1),t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5148(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 705  bad-literal */
f_5014(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k5117 in k5099 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5148(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5148,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5170,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 704  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5020(3,t8,t6,t7);}}

/* k5168 in loop in k5117 in k5099 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 704  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5148(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5124 in k5117 in k5099 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k5093 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k5089 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 694  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[356]))(5,*((C_word*)lf[356]+1),((C_word*)t0)[2],*((C_word*)lf[357]+1),C_fix(0),t1);}

/* k5085 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k5056 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5062,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 693  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5020(3,t4,t2,t3);}

/* k5060 in k5056 in k5025 in literal-size in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4977,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4983(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop824 in literal-frame in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4983(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4983,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4993,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5012,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 683  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t6,lf[354],t2);}}

/* k5010 in doloop824 in literal-frame in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 683  gen-lit */
t2=((C_word*)t0)[4];
f_5179(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4991 in doloop824 in literal-frame in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4983(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5179(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5179,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5319,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 709  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),t5,t2);}
else{
t5=t4;
f_5186(t5,C_SCHEME_FALSE);}}

/* k5317 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5186(t2,(C_word)C_i_not(t1));}

/* k5184 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5186(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5186,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 710  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[336],((C_word*)t0)[4],lf[337]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 711  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,((C_word*)t0)[4]);}}

/* k5190 in k5184 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5192,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[338]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 713  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[339]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[340]:lf[341]);
/* c-backend.scm: 715  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 717  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[342],t4,lf[343]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 720  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 725  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[347]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5275(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_5275(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k5273 in k5190 in k5184 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5275,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5278,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 729  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[350]);}
else{
/* c-backend.scm: 732  bad-literal */
f_5014(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k5276 in k5273 in k5190 in k5184 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5281,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5288,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 730  encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t3,((C_word*)t0)[2]);}

/* k5286 in k5276 in k5273 in k5190 in k5184 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 730  gen-string-constant */
t2=((C_word*)t0)[3];
f_5321(t2,((C_word*)t0)[2],t1);}

/* k5279 in k5276 in k5273 in k5190 in k5184 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 731  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[348]);}

/* k5240 in k5190 in k5184 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5242,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5248,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 722  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[346]);}

/* k5246 in k5240 in k5190 in k5184 in gen-lit in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 723  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),((C_word*)t0)[5],lf[344],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[345]);}

/* bad-literal in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5014(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5014,NULL,2,t1,t2);}
/* c-backend.scm: 686  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),t1,lf[335],t2);}

/* gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5321,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5328,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 736  fx/ */
((C_proc4)C_retrieve_proc(*((C_word*)lf[334]+1)))(4,*((C_word*)lf[334]+1),t4,t3,C_fix(80));}

/* k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5331,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 737  modulo */
((C_proc4)C_retrieve_proc(*((C_word*)lf[333]+1)))(4,*((C_word*)lf[333]+1),t2,((C_word*)t0)[5],C_fix(80));}

/* k5329 in k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5331,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5336,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5336(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop910 in k5329 in k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5336(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5336,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5352,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5352(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5352(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5373,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5388,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5392,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 743  string-like-substring */
f_5398(t7,((C_word*)t0)[4],t3,t8);}}

/* k5390 in doloop910 in k5329 in k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 743  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k5386 in doloop910 in k5329 in k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 743  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5371 in doloop910 in k5329 in k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5336(t4,((C_word*)t0)[2],t2,t3);}

/* k5350 in doloop910 in k5329 in k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5352,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5359,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5363,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 742  string-like-substring */
f_5398(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5361 in k5350 in doloop910 in k5329 in k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 742  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k5357 in k5350 in doloop910 in k5329 in k5326 in gen-string-constant in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 742  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_5398(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5398,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5405,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 747  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[332]+1)))(3,*((C_word*)lf[332]+1),t6,t5);}

/* k5403 in string-like-substring in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5408,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 748  ##sys#copy-bytes */
((C_proc7)C_retrieve_symbol_proc(lf[331]))(7,*((C_word*)lf[331]+1),t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5406 in k5403 in string-like-substring in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_5408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4691,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4694,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4730,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4810,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4858,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4862,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 642  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4862,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 643  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t4,((C_word*)t0)[2]);}

/* k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 644  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 645  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2]);}

/* k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 646  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4975,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 647  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4877(t3,C_SCHEME_FALSE);}}

/* k4973 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4877(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4877,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_4880(t5,t4);}
else{
t3=t2;
f_4880(t3,C_SCHEME_UNDEFINED);}}

/* k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4880,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 649  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[2]);}

/* k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4892,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 651  gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[325],((C_word*)t0)[9],lf[326],C_SCHEME_TRUE,lf[327],((C_word*)t0)[9],lf[328]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4920(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 659  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t3,((C_word*)t0)[2]);}}}}

/* k4962 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4920(2,t3,t2);}
else{
/* c-backend.scm: 659  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4918 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4920,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[244]);
t4=t2;
f_4926(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_4926(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4924 in k4918 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4926,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[329]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 662  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t3,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 663  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t3,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 664  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t2,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4942 in k4924 in k4918 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4938 in k4924 in k4918 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4934 in k4924 in k4918 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4890 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 653  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[323],((C_word*)t0)[3],lf[324]);}

/* k4893 in k4890 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4898,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 654  restore */
f_4694(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4896 in k4893 in k4890 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 655  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4899 in k4896 in k4893 in k4890 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4904,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 656  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t2,((C_word*)((C_word*)t0)[2])[1],lf[322]);}

/* k4902 in k4899 in k4896 in k4893 in k4890 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4914,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 657  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,t1,C_make_character(44));}

/* k4912 in k4902 in k4899 in k4896 in k4893 in k4890 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4905 in k4902 in k4899 in k4896 in k4893 in k4890 in k4884 in k4878 in k4875 in k4872 in k4869 in k4866 in k4863 in k4860 in a4857 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 658  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[321]);}

/* k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4813,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4828 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4829,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 668  gen */
((C_proc13)C_retrieve_symbol_proc(lf[1]))(13,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[316],t2,lf[317],C_SCHEME_TRUE,lf[318],t2,lf[319],t2,lf[320]);}

/* k4831 in a4828 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 670  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[313],((C_word*)t0)[3],lf[314],((C_word*)t0)[3],lf[315]);}

/* k4834 in k4831 in a4828 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4839,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 671  restore */
f_4694(t2,((C_word*)t0)[3]);}

/* k4837 in k4834 in k4831 in a4828 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 672  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[312],((C_word*)t0)[2],C_make_character(44));}

/* k4840 in k4837 in k4834 in k4831 in a4828 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4852,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4856,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 673  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[2],lf[311]);}

/* k4854 in k4840 in k4837 in k4834 in k4831 in a4828 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 673  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4850 in k4840 in k4837 in k4834 in k4831 in a4828 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4843 in k4840 in k4837 in k4834 in k4831 in a4828 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 674  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[310]);}

/* k4811 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 676  emitter */
t4=((C_word*)t0)[3];
f_4730(t4,t3,C_SCHEME_FALSE);}

/* k4825 in k4811 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4814 in k4811 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4816,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 677  emitter */
t3=((C_word*)t0)[2];
f_4730(t3,t2,C_SCHEME_TRUE);}

/* k4821 in k4814 in k4811 in k4808 in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4730(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4730,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4732,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4732 in emitter in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4732,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[305]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[306]);
/* c-backend.scm: 620  gen */
((C_proc14)C_retrieve_symbol_proc(lf[1]))(14,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[307],t2,C_make_character(114),t4,lf[308],C_SCHEME_TRUE,lf[309],t2,C_make_character(114),t5);}

/* k4734 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 622  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[303],((C_word*)t0)[4],lf[304]);}

/* k4737 in k4734 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 623  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[302],((C_word*)t0)[4],C_make_character(114));}

/* k4740 in k4737 in k4734 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 624  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t3=t2;
f_4745(2,t3,C_SCHEME_UNDEFINED);}}

/* k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 625  gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),t2,lf[298],((C_word*)t0)[4],lf[299],C_SCHEME_TRUE,lf[300],C_SCHEME_TRUE,lf[301],((C_word*)t0)[4],C_make_character(59));}

/* k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 628  restore */
f_4694(t2,((C_word*)t0)[4]);}

/* k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 629  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[297]);}

/* k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 631  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[295]);}
else{
/* c-backend.scm: 632  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[296]);}}

/* k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 633  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[294]);}

/* k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 634  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[293]);}
else{
t3=t2;
f_4763(2,t3,C_SCHEME_UNDEFINED);}}

/* k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 635  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[292]);}

/* k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[291]);}

/* k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4783,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 637  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,t5,lf[290]);}

/* k4781 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 637  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4777 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in k4746 in k4743 in k4740 in k4737 in k4734 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 638  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[288]);}

/* restore in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4694(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4694,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4698,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4707,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4707(t8,t3,t4,C_fix(0));}

/* doloop725 in restore in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4707(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4707,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4717,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 615  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[285],t2,lf[286],t3,lf[287]);}}

/* k4715 in doloop725 in restore in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4707(t4,((C_word*)t0)[2],t2,t3);}

/* k4696 in restore in trampolines in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 616  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[283],((C_word*)t0)[2],lf[284]);}

/* prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4440(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4440,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 544  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE);}

/* k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4468,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4472,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 547  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 548  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4689,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 549  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4478(t3,C_SCHEME_FALSE);}}

/* k4687 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4478(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4478,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4675,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 550  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t3,t4,lf[280]);}

/* k4673 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 550  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 551  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2]);}

/* k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 552  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[2]);}

/* k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 553  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 554  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[2]);}

/* k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 555  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,((C_word*)t0)[2]);}

/* k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[271]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4667,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 557  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t5,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4499(t5,C_SCHEME_UNDEFINED);}}

/* k4665 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4499(t3,t2);}

/* k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4499,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 558  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4660,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 563  lambda-literal-callee-signatures */
((C_proc3)C_retrieve_symbol_proc(lf[274]))(3,*((C_word*)lf[274]+1),t4,((C_word*)t0)[2]);}

/* k4658 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4640 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4641,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[271]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4652,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 562  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t5,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4650 in a4640 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4617,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 573  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t4,C_retrieve(lf[206]),lf[262]);}
else{
t5=t4;
f_4617(2,t5,lf[263]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 565  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,lf[269],((C_word*)t0)[5],lf[270],C_SCHEME_TRUE);}}

/* k4590 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 566  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[268]);}

/* k4593 in k4590 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[266]:lf[267]);
/* c-backend.scm: 567  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,t3);}

/* k4596 in k4593 in k4590 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 569  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[264]);}
else{
/* c-backend.scm: 570  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[265]);}}

/* k4599 in k4596 in k4593 in k4590 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 571  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4615 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4620,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 574  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,lf[260],t1,lf[261],C_SCHEME_TRUE);}

/* k4618 in k4615 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4623,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[258]))){
/* c-backend.scm: 576  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[259],C_SCHEME_TRUE);}
else{
t3=t2;
f_4623(2,t3,C_SCHEME_UNDEFINED);}}

/* k4621 in k4618 in k4615 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 577  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[257]);}

/* k4624 in k4621 in k4618 in k4615 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 578  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[256],((C_word*)t0)[2]);}

/* k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 579  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4514(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 580  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[254]);}}

/* k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4564(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4564(t4,C_SCHEME_FALSE);}}

/* k4562 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4564(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4564,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 582  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[253]);}
else{
t2=((C_word*)t0)[2];
f_4517(2,t2,C_SCHEME_UNDEFINED);}}

/* k4565 in k4562 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 583  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_4517(2,t2,C_SCHEME_UNDEFINED);}}

/* k4515 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[4]);}

/* k4518 in k4515 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4520,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 586  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[251]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 594  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k4550 in k4518 in k4515 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4555,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4555(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 596  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[252]);}}

/* k4553 in k4550 in k4518 in k4515 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 597  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k4524 in k4518 in k4515 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4526,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[244]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 589  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[247],((C_word*)t0)[2],lf[248],C_SCHEME_TRUE,lf[249],((C_word*)t0)[2],lf[250]);}}

/* k4533 in k4524 in k4518 in k4515 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k4536 in k4533 in k4524 in k4518 in k4515 in k4512 in k4509 in k4506 in k4503 in k4500 in k4497 in k4494 in k4491 in k4488 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in a4467 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 592  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[245],t2,lf[246]);}

/* k4445 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4452,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a4451 in k4445 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4452,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4456,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 601  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[242],t2,lf[243]);}

/* k4454 in a4451 in k4445 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4459,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 602  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[240]))(4,*((C_word*)lf[240]+1),t3,((C_word*)t0)[2],lf[241]);}

/* k4464 in k4454 in a4451 in k4445 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4457 in k4454 in a4451 in k4445 in k4442 in prototypes in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 603  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[239]);}

/* declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4291(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4291,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4298,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 515  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[238]);}

/* k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4434,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[208]));}

/* a4433 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4434,3,t0,t1,t2);}
/* c-backend.scm: 518  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[234],t2,lf[235],C_SCHEME_TRUE,lf[236],t2,lf[237]);}

/* k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4304(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 522  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[232],((C_word*)t0)[2],lf[233]);}}

/* k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 523  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[231]);}

/* k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4307,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4312(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4312(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4312,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4322,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 527  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t4,t5);}}

/* k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4328,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 529  gen */
((C_proc12)C_retrieve_symbol_proc(lf[1]))(12,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[228],((C_word*)t0)[5],lf[229],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4326 in k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4381(t6,t2,C_fix(0));}

/* doloop595 in k4326 in k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4381(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4381,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4391,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 536  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,C_make_character(44),t6);}}

/* k4389 in doloop595 in k4326 in k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4381(t3,((C_word*)t0)[2],t2);}

/* k4329 in k4326 in k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4354,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4354(t9,t2,t5);}

/* doloop607 in k4329 in k4326 in k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4354(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4354,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4364,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 539  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[227]);}}

/* k4362 in doloop607 in k4329 in k4326 in k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4354(t3,((C_word*)t0)[2],t2);}

/* k4332 in k4329 in k4326 in k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 540  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[226]);}

/* k4335 in k4332 in k4329 in k4326 in k4320 in doloop579 in k4305 in k4302 in k4299 in k4296 in declarations in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4312(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4144,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4147,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4164,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4283,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 481  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[225]))(2,*((C_word*)lf[225]+1),t4);}

/* k4281 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 481  ##sys#decode-seconds */
((C_proc4)C_retrieve_symbol_proc(lf[224]))(4,*((C_word*)lf[224]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_i_vector_ref(t1,C_fix(2));
t4=(C_word)C_i_vector_ref(t1,C_fix(3));
t5=(C_word)C_i_vector_ref(t1,C_fix(4));
t6=(C_word)C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4182,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4241,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 489  pad0 */
f_4147(t9,t10);}

/* k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 489  pad0 */
f_4147(t2,((C_word*)t0)[2]);}

/* k4243 in k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 489  pad0 */
f_4147(t2,((C_word*)t0)[2]);}

/* k4247 in k4243 in k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4253,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 489  pad0 */
f_4147(t2,((C_word*)t0)[2]);}

/* k4251 in k4247 in k4243 in k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4257,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4261,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4263,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4271,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4275,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 492  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t6,C_SCHEME_TRUE);}

/* k4273 in k4251 in k4247 in k4243 in k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 492  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),((C_word*)t0)[2],t1,lf[222]);}

/* k4269 in k4251 in k4247 in k4243 in k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4262 in k4251 in k4247 in k4243 in k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4263,3,t0,t1,t2);}
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t1,lf[218],t2,lf[219]);}

/* k4259 in k4251 in k4247 in k4243 in k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 490  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[217]);}

/* k4255 in k4251 in k4247 in k4243 in k4239 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 487  gen */
((C_proc21)C_retrieve_symbol_proc(lf[1]))(21,*((C_word*)lf[1]+1),((C_word*)t0)[8],lf[211],((C_word*)t0)[7],lf[212],C_SCHEME_TRUE,lf[213],C_SCHEME_TRUE,lf[214],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[215]);}

/* k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 495  gen-list */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),t2,C_retrieve(lf[210]));}

/* k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4188,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 496  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4186 in k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4191,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 497  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[207],C_retrieve(lf[206]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4230,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 499  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,lf[209]);}}

/* k4228 in k4186 in k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 500  gen-list */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),((C_word*)t0)[2],C_retrieve(lf[208]));}

/* k4189 in k4186 in k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4194,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 501  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[202],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[203],C_retrieve(lf[204]),lf[205]);}

/* k4192 in k4189 in k4186 in k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4197,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[198]))){
/* c-backend.scm: 503  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t2,C_retrieve(lf[200]));}
else{
t3=t2;
f_4197(2,t3,C_SCHEME_UNDEFINED);}}

/* k4195 in k4192 in k4189 in k4186 in k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4200,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[201])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4212,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 505  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_4200(2,t3,C_SCHEME_UNDEFINED);}}

/* k4210 in k4195 in k4192 in k4189 in k4186 in k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4217,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[201]));}

/* a4216 in k4210 in k4195 in k4192 in k4189 in k4186 in k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4217,3,t0,t1,t2);}
/* c-backend.scm: 506  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,t2);}

/* k4198 in k4195 in k4192 in k4189 in k4186 in k4183 in k4180 in k4162 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[198]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 508  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),((C_word*)t0)[2],C_retrieve(lf[200]));}}

/* pad0 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4147(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4147,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4161,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 479  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4159 in pad0 in header in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 479  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[197],t1);}

/* expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_2536(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2536,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 474  expr */
t11=((C_word*)t6)[1];
f_2539(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_4112(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4112,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4118,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 468  pair-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[196]))(4,*((C_word*)lf[196]+1),t1,t4,t2);}

/* a4117 in expr-args in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4118,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_4122(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 470  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}}

/* k4120 in a4117 in expr-args in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 471  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2539(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2539,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2543,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4106,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_4106 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4106,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(3)));}

/* k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4101,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_4101 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4101,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4096,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_4096 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4096,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[16]);
if(C_truep(t2)){
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(C_word)C_eqp(t3,lf[17]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[10]);
t6=(C_truep(t5)?lf[18]:lf[19]);
/* c-backend.scm: 127  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[9],t6);}
else{
t5=(C_word)C_eqp(t3,lf[20]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[10]);
t7=(C_word)C_fix((C_word)C_character_code(t6));
/* c-backend.scm: 128  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[21],t7,C_make_character(41));}
else{
t6=(C_word)C_eqp(t3,lf[22]);
if(C_truep(t6)){
/* c-backend.scm: 129  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[23]);}
else{
t7=(C_word)C_eqp(t3,lf[24]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* c-backend.scm: 130  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[25],t8,C_make_character(41));}
else{
t8=(C_word)C_eqp(t3,lf[26]);
if(C_truep(t8)){
/* c-backend.scm: 131  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[27]);}
else{
/* c-backend.scm: 132  bomb */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),((C_word*)t0)[9],lf[28]);}}}}}}
else{
t3=(C_word)C_eqp(t1,lf[29]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_vectorp(t4))){
t5=(C_word)C_i_vector_ref(t4,C_fix(0));
/* c-backend.scm: 137  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[30],t5,lf[31]);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 138  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[32],t5,C_make_character(93));}}
else{
t4=(C_word)C_eqp(t1,lf[33]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[36]);}
else{
t5=(C_word)C_eqp(t1,lf[37]);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 150  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[38],t6);}
else{
t6=(C_word)C_eqp(t1,lf[39]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[10]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[7],a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_2721(t11,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6],t7);}
else{
t7=(C_word)C_eqp(t1,lf[40]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 162  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t8,lf[42]);}
else{
t8=(C_word)C_eqp(t1,lf[43]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 167  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t9,lf[45]);}
else{
t9=(C_word)C_eqp(t1,lf[46]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 172  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t10,lf[47]);}
else{
t10=(C_word)C_eqp(t1,lf[48]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 179  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t11,lf[51]);}
else{
t11=(C_word)C_eqp(t1,lf[52]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2888,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t12,lf[54]);}
else{
t12=(C_word)C_eqp(t1,lf[55]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t13,lf[57]);}
else{
t13=(C_word)C_eqp(t1,lf[58]);
if(C_truep(t13)){
t14=(C_word)C_i_car(((C_word*)t0)[10]);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=t14,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 201  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t15,lf[65],t14,C_make_character(44));}
else{
t14=(C_word)C_eqp(t1,lf[66]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 211  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t15,lf[68]);}
else{
t15=(C_word)C_eqp(t1,lf[69]);
if(C_truep(t15)){
t16=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 215  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[9],C_make_character(116),t16);}
else{
t16=(C_word)C_eqp(t1,lf[70]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 218  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t17,C_make_character(116),t18,C_make_character(61));}
else{
t17=(C_word)C_eqp(t1,lf[71]);
if(C_truep(t17)){
t18=(C_word)C_i_car(((C_word*)t0)[10]);
t19=(C_word)C_i_cadr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_caddr(((C_word*)t0)[10]))){
if(C_truep(t19)){
/* c-backend.scm: 227  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[72],t18,lf[73]);}
else{
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3058,a[2]=t18,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3062,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cadddr(((C_word*)t0)[10]);
/* c-backend.scm: 228  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t21,t22);}}
else{
if(C_truep(t19)){
/* c-backend.scm: 229  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[78],t18,lf[79]);}
else{
/* c-backend.scm: 230  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[80],t18,lf[81]);}}}
else{
t18=(C_word)C_eqp(t1,lf[82]);
if(C_truep(t18)){
t19=(C_word)C_i_car(((C_word*)t0)[10]);
t20=(C_word)C_i_cadr(((C_word*)t0)[10]);
t21=(C_word)C_i_caddr(((C_word*)t0)[10]);
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3093,a[2]=t21,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t20)){
/* c-backend.scm: 237  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t22,lf[85],t19,lf[86]);}
else{
/* c-backend.scm: 238  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t22,lf[87],t19,lf[88]);}}
else{
t19=(C_word)C_eqp(t1,lf[89]);
if(C_truep(t19)){
t20=(C_word)C_i_car(((C_word*)t0)[10]);
t21=(C_word)C_i_cadr(((C_word*)t0)[10]);
t22=(C_word)C_i_caddr(((C_word*)t0)[10]);
if(C_truep(t21)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3141,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3155,a[2]=t20,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3159,a[2]=t24,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 249  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t25,t22);}
else{
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3176,a[2]=t20,a[3]=t23,tmp=(C_word)a,a+=4,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3180,a[2]=t24,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 254  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t25,t22);}}
else{
t20=(C_word)C_eqp(t1,lf[96]);
if(C_truep(t20)){
/* c-backend.scm: 258  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[9],lf[97]);}
else{
t21=(C_word)C_eqp(t1,lf[98]);
if(C_truep(t21)){
t22=(C_word)C_i_cdr(((C_word*)t0)[8]);
t23=(C_word)C_i_length(t22);
t24=((C_word*)t0)[6];
t25=(C_word)C_fixnum_increase(t23);
t26=(C_word)C_i_cdr(((C_word*)t0)[10]);
t27=(C_word)C_i_pairp(t26);
t28=(C_truep(t27)?(C_word)C_i_cadr(((C_word*)t0)[10]):C_SCHEME_FALSE);
t29=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3213,a[2]=t27,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t28,a[6]=t24,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t23,a[10]=t25,a[11]=((C_word*)t0)[6],a[12]=t22,a[13]=((C_word*)t0)[4],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[10],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 267  source-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t29,t28);}
else{
t22=(C_word)C_eqp(t1,lf[147]);
if(C_truep(t22)){
t23=(C_word)C_i_length(((C_word*)t0)[8]);
t24=(C_word)C_fixnum_increase(t23);
t25=(C_word)C_i_car(((C_word*)t0)[10]);
t26=(C_word)C_i_cadr(((C_word*)t0)[10]);
t27=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3657,a[2]=t26,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t24,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t23,a[10]=((C_word*)t0)[9],a[11]=t25,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 351  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t27,((C_word*)t0)[3]);}
else{
t23=(C_word)C_eqp(t1,lf[151]);
if(C_truep(t23)){
t24=(C_word)C_i_cdr(((C_word*)t0)[8]);
t25=(C_word)C_i_length(t24);
t26=(C_word)C_fixnum_increase(t25);
t27=(C_word)C_i_caddr(((C_word*)t0)[10]);
t28=(C_word)C_i_cadddr(((C_word*)t0)[10]);
t29=(C_word)C_eqp(t28,C_fix(0));
t30=(C_word)C_i_not(t29);
t31=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3742,a[2]=t27,a[3]=t28,a[4]=t30,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],a[8]=t24,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3746,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 379  find-lambda */
t33=((C_word*)t0)[2];
f_2494(t33,t32,t27);}
else{
t24=(C_word)C_eqp(t1,lf[153]);
if(C_truep(t24)){
t25=(C_word)C_i_length(((C_word*)t0)[8]);
t26=(C_word)C_fixnum_plus(t25,C_fix(1));
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 396  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t27,C_SCHEME_TRUE,lf[155],t28,lf[156],t26,lf[157]);}
else{
t25=(C_word)C_eqp(t1,lf[158]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3784,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 401  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t26,C_SCHEME_TRUE,lf[160]);}
else{
t26=(C_word)C_eqp(t1,lf[161]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3803,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_car(((C_word*)t0)[10]);
/* c-backend.scm: 406  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t27,lf[162],t28,C_make_character(40));}
else{
t27=(C_word)C_eqp(t1,lf[163]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3822,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t29=(C_word)C_i_car(((C_word*)t0)[10]);
t30=(C_word)C_i_length(((C_word*)t0)[8]);
/* c-backend.scm: 411  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t28,lf[164],t29,lf[165],t30);}
else{
t28=(C_word)C_eqp(t1,lf[166]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3858,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t30=(C_word)C_i_cadr(((C_word*)t0)[10]);
/* c-backend.scm: 419  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t29,t30,lf[168]);}
else{
t29=(C_word)C_eqp(t1,lf[169]);
if(C_truep(t29)){
t30=(C_word)C_i_cadr(((C_word*)t0)[10]);
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3878,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[10]);
t33=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3896,a[2]=t30,a[3]=t32,a[4]=t31,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 423  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t33,t30,lf[174]);}
else{
t30=(C_word)C_eqp(t1,lf[175]);
if(C_truep(t30)){
t31=(C_word)C_i_car(((C_word*)t0)[10]);
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3926,a[2]=t31,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 429  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t33,t31,lf[180]);}
else{
t31=(C_word)C_eqp(t1,lf[181]);
if(C_truep(t31)){
t32=(C_word)C_i_car(((C_word*)t0)[10]);
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3942,a[2]=t32,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3970,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 435  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t34,t32,lf[186]);}
else{
t32=(C_word)C_eqp(t1,lf[187]);
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 442  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t33,C_SCHEME_TRUE,lf[191]);}
else{
t33=(C_word)C_eqp(t1,lf[192]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 457  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t34,lf[194]);}
else{
/* c-backend.scm: 465  bomb */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),((C_word*)t0)[9],lf[195]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4060 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 458  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k4063 in k4060 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 459  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[193]);}

/* k4066 in k4063 in k4060 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 460  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k4069 in k4066 in k4063 in k4060 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 461  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4072 in k4069 in k4066 in k4063 in k4060 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4077,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 462  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k4075 in k4072 in k4069 in k4066 in k4063 in k4060 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 463  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 443  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2539(t4,t2,t3,((C_word*)t0)[3]);}

/* k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 444  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[190]);}

/* k3983 in k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3985,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3998,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3998(t7,((C_word*)t0)[2],t2,t3);}

/* doloop484 in k3983 in k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_3998(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3998,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 448  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[188]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 451  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[189]);}}

/* k4019 in doloop484 in k3983 in k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 452  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k4022 in k4019 in doloop484 in k3983 in k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 453  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4025 in k4022 in k4019 in doloop484 in k3983 in k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 454  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k4028 in k4025 in k4022 in k4019 in doloop484 in k3983 in k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3998(t4,((C_word*)t0)[2],t2,t3);}

/* k4006 in doloop484 in k3983 in k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4011,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 449  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k4009 in k4006 in doloop484 in k3983 in k3980 in k3977 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 450  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* k3968 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 435  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[184],t1,lf[185]);}

/* k3940 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 436  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2539(t4,t2,t3,((C_word*)t0)[3]);}

/* k3943 in k3940 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3962,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 437  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t3,((C_word*)t0)[2]);}

/* k3960 in k3943 in k3940 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 437  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[183],t1);}

/* k3946 in k3943 in k3940 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 438  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k3949 in k3946 in k3943 in k3940 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 439  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[182]);}

/* k3924 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3930,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 429  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[179]);}

/* k3928 in k3924 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 429  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[177],t1,lf[178]);}

/* k3910 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 430  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k3913 in k3910 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 431  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[176]);}

/* k3894 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3900,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 423  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k3898 in k3894 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 423  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[171],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3876 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 424  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k3879 in k3876 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 425  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[170]);}

/* k3856 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 419  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3820 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 414  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}
else{
t3=t2;
f_3825(2,t3,C_SCHEME_UNDEFINED);}}

/* k3832 in k3820 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 415  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4112(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3823 in k3820 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 416  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3801 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 407  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4112(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3804 in k3801 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 408  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3782 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 402  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k3785 in k3782 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 403  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[159]);}

/* k3763 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 397  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4112(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3766 in k3763 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 398  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[154]);}

/* k3744 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 379  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3740 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3690,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 381  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],C_make_character(40));}

/* k3688 in k3740 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3723,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 383  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,lf[152],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3693(2,t3,C_SCHEME_UNDEFINED);}}

/* k3721 in k3688 in k3740 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 384  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_3693(2,t4,C_SCHEME_UNDEFINED);}}

/* k3691 in k3688 in k3740 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3696(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3711,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 386  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3709 in k3691 in k3688 in k3740 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 387  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3696(2,t2,C_SCHEME_UNDEFINED);}}

/* k3694 in k3691 in k3688 in k3740 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3699,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 388  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4112(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3699(2,t3,C_SCHEME_UNDEFINED);}}

/* k3697 in k3694 in k3691 in k3688 in k3740 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 389  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 353  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3641,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 366  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3639 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3644(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 367  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[150]);}}

/* k3642 in k3639 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 368  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4112(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3645 in k3642 in k3639 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 369  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 354  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3601 in k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 355  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3623 in k3601 in k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3624,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 357  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3626 in a3623 in k3601 in k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 358  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2539(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3629 in k3626 in a3623 in k3601 in k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 359  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3604 in k3601 in k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3614,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 363  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3620 in k3604 in k3601 in k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 361  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3613 in k3604 in k3601 in k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3614,4,t0,t1,t2,t3);}
/* c-backend.scm: 362  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[149],t2,C_make_character(59));}

/* k3607 in k3604 in k3601 in k3598 in k3655 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 364  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[148]);}

/* k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[16]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_3216(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[16]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3216(t3,C_SCHEME_FALSE);}}

/* k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_3216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3216,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[16]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3546,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3550,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 270  find-lambda */
t6=((C_word*)t0)[2];
f_2494(t6,t5,t1);}
else{
t4=t3;
f_3222(t4,C_SCHEME_FALSE);}}

/* k3548 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3544 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3222(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_3222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3222,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(C_retrieve(lf[137]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2524,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 114  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3539,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 275  uncommentify */
f_2526(t4,((C_word*)t0)[3]);}}
else{
t4=t3;
f_3228(2,t4,C_SCHEME_UNDEFINED);}}

/* k3537 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 275  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[143],t1,lf[144]);}

/* k2522 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 114  string-translate */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[2],t1,lf[141],lf[142]);}

/* k3530 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 274  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[138],t1,lf[139]);}

/* k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3518,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* f_3518 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3518,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
t2=(C_word)C_eqp(lf[37],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3251,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[10]);}
else{
if(C_truep(((C_word*)t0)[9])){
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3264,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 282  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t4,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3509,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}}}

/* f_3509 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3509,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* k3506 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(lf[71],t1);
if(C_truep(t2)){
t3=C_retrieve(lf[129]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_3360(t4,C_SCHEME_FALSE);}
else{
t4=C_retrieve(lf[134]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
f_3360(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
f_3360(t6,(C_word)C_i_not(t5));}}}
else{
t3=((C_word*)t0)[3];
f_3360(t3,C_SCHEME_FALSE);}}

/* k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_3360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3360,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3442,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 335  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}

/* k3447 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 336  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2539(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3450 in k3447 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 337  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_make_character(59),C_SCHEME_TRUE,lf[135],((C_word*)t0)[4],lf[136]);}

/* k3453 in k3450 in k3447 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[129]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3470(t5,t3);}
else{
t5=C_retrieve(lf[134]);
t6=t4;
f_3470(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k3468 in k3453 in k3450 in k3447 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_3470(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 340  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[130],((C_word*)t0)[2],lf[131]);}
else{
/* c-backend.scm: 341  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[132],((C_word*)t0)[2],lf[133]);}}

/* k3456 in k3453 in k3450 in k3447 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 342  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[127],((C_word*)t0)[3],lf[128],((C_word*)t0)[2],C_make_character(44));}

/* k3459 in k3456 in k3453 in k3450 in k3447 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 343  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4112(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3462 in k3459 in k3456 in k3453 in k3450 in k3447 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 344  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[126]);}

/* f_3442 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3442,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
t2=(C_word)C_i_car(t1);
t3=(C_word)C_i_cadr(t1);
t4=(C_word)C_i_caddr(t1);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3375,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t6,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 316  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t7,C_SCHEME_TRUE,lf[124],((C_word*)t0)[2],lf[125]);}

/* k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3416,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 318  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3423,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3430,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 325  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3434,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3441,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 329  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}}}

/* k3439 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 329  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[122],t1,lf[123]);}

/* k3432 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* c-backend.scm: 330  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[120],((C_word*)t0)[2],lf[121]);}

/* k3428 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 325  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[118],t1,lf[119]);}

/* k3421 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
/* c-backend.scm: 326  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[116],((C_word*)((C_word*)t0)[3])[1],lf[117]);}

/* k3414 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 318  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[114],t1,lf[115]);}

/* k3389 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 320  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[109],((C_word*)((C_word*)t0)[5])[1],lf[110]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3408,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
/* c-backend.scm: 322  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t4,t5);}}

/* k3406 in k3389 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 322  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3402 in k3389 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 321  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[111],((C_word*)((C_word*)t0)[2])[1],lf[112],t1,C_make_character(41));}

/* k3376 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 331  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[108],((C_word*)t0)[3],C_make_character(44),((C_word*)((C_word*)t0)[2])[1],C_make_character(44));}

/* k3379 in k3376 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 332  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4112(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3382 in k3379 in k3376 in k3373 in k3361 in k3358 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 333  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[107]);}

/* k3352 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 283  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3264(2,t3,C_SCHEME_FALSE);}}

/* k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3264,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 284  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3314(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 299  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3336 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3341,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 300  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2539(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3339 in k3336 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3312 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 302  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3315 in k3312 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3320(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 303  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3318 in k3315 in k3312 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3323(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 304  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k3321 in k3318 in k3315 in k3312 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 305  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4112(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3324 in k3321 in k3318 in k3315 in k3312 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 306  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[105]);}

/* k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 285  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 286  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3296 in k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3297,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 288  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3299 in a3296 in k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 289  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2539(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3302 in k3299 in a3296 in k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 290  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3271 in k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3287,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 294  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3293 in k3271 in k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 292  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3286 in k3271 in k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3287,4,t0,t1,t2,t3);}
/* c-backend.scm: 293  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[103],t2,C_make_character(59));}

/* k3274 in k3271 in k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3279,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3279(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 295  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[102],((C_word*)t0)[2],C_make_character(59));}}

/* k3277 in k3274 in k3271 in k3268 in k3265 in k3262 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 296  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[101]);}

/* f_3251 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3251,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(2)));}

/* k3235 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(t1);
/* c-backend.scm: 278  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t3,C_make_character(40),((C_word*)t0)[2],lf[100]);}

/* k3238 in k3235 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 279  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4112(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3241 in k3238 in k3235 in k3515 in k3226 in k3220 in k3214 in k3211 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 280  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[99]);}

/* k3178 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 254  uncommentify */
f_2526(((C_word*)t0)[2],t1);}

/* k3174 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 253  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[93],((C_word*)t0)[2],lf[94],t1,lf[95]);}

/* k3160 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3165,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 255  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k3163 in k3160 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 256  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3157 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 249  uncommentify */
f_2526(((C_word*)t0)[2],t1);}

/* k3153 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 248  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[90],((C_word*)t0)[2],lf[91],t1,lf[92]);}

/* k3139 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 250  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k3142 in k3139 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3091 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3096,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3114,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 239  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t4,((C_word*)t0)[2]);}

/* k3112 in k3091 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  uncommentify */
f_2526(((C_word*)t0)[2],t1);}

/* k3108 in k3091 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[83],t1,lf[84]);}

/* k3094 in k3091 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3099,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 240  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k3097 in k3094 in k3091 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 241  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3060 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3056 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[74],((C_word*)t0)[2],lf[75],t1,C_make_character(41));}

/* k3014 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 219  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2539(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2982 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2985 in k2982 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[67]);}

/* k2947 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2952,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 207  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2973 in k2947 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 202  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2960 in k2947 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2961,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 204  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t4,lf[61],t3,lf[62]);}

/* k2963 in a2960 in k2947 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 205  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2539(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2966 in k2963 in a2960 in k2947 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}

/* k2950 in k2947 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 208  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[59],t2,lf[60]);}

/* k2915 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2918 in k2915 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 195  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[56]);}

/* k2921 in k2918 in k2915 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 196  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2924 in k2921 in k2918 in k2915 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 197  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2886 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2889 in k2886 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 188  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[53]);}

/* k2892 in k2889 in k2886 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2897,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 189  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2895 in k2892 in k2889 in k2886 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 190  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2849 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2539(t4,t2,t3,((C_word*)t0)[3]);}

/* k2852 in k2849 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2857,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 181  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[49],t4,lf[50]);}

/* k2855 in k2852 in k2849 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 182  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2858 in k2855 in k2852 in k2849 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 183  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2816 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2539(t4,t2,t3,((C_word*)t0)[3]);}

/* k2819 in k2816 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 174  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(44),t3,C_make_character(44));}

/* k2822 in k2819 in k2816 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 175  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2825 in k2822 in k2819 in k2816 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 176  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2797 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 168  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2800 in k2797 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 169  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[44]);}

/* k2770 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 163  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2773 in k2770 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 164  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[41],t3,C_make_character(93));}

/* loop in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_2721(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2721,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2731,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 155  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 159  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2539(t7,t1,t6,t3);}}

/* k2729 in loop in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 156  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2539(t4,t2,t3,((C_word*)t0)[6]);}

/* k2732 in k2729 in loop in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 157  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(59));}

/* k2735 in k2732 in k2729 in loop in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 158  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2721(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2661 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2664 in k2661 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[35]);}

/* k2667 in k2664 in k2661 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2670 in k2667 in k2664 in k2661 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 145  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(125),C_SCHEME_TRUE,lf[34]);}

/* k2673 in k2670 in k2667 in k2664 in k2661 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2539(t4,t2,t3,((C_word*)t0)[2]);}

/* k2676 in k2673 in k2670 in k2667 in k2664 in k2661 in k2547 in k2544 in k2541 in expr in expression in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* uncommentify in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_2526(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2526,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2534,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 115  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k2532 in uncommentify in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 115  string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,lf[14]);}

/* find-lambda in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_fcall f_2494(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2494,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2498,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2506,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 111  find */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t3,t4,((C_word*)t0)[2]);}

/* a2505 in find-lambda in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2506,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 111  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k2512 in a2505 in find-lambda in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k2496 in find-lambda in ##compiler#generate-code in k2487 in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 112  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2471,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2477,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2485,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 93   intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t4,t2,C_make_character(32));}

/* k2483 in ##compiler#gen-list in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2476 in ##compiler#gen-list in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2477,3,t0,t1,t2);}
/* c-backend.scm: 92   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t1,t2,C_retrieve(lf[0]));}

/* ##compiler#gen in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_2450r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2450r(t0,t1,t2);}}

static void C_ccall f_2450r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2456,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a2455 in ##compiler#gen in k2445 in k2442 in k2439 in k2436 in k2433 in k2430 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2456,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 86   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t1,C_retrieve(lf[0]));}
else{
/* c-backend.scm: 87   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t1,t2,C_retrieve(lf[0]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[678] = {
{"toplevel:c_backend_scm",(void*)C_backend_toplevel},
{"f_2432:c_backend_scm",(void*)f_2432},
{"f_2435:c_backend_scm",(void*)f_2435},
{"f_2438:c_backend_scm",(void*)f_2438},
{"f_2441:c_backend_scm",(void*)f_2441},
{"f_2444:c_backend_scm",(void*)f_2444},
{"f_2447:c_backend_scm",(void*)f_2447},
{"f_9190:c_backend_scm",(void*)f_9190},
{"f_9194:c_backend_scm",(void*)f_9194},
{"f_9186:c_backend_scm",(void*)f_9186},
{"f_2489:c_backend_scm",(void*)f_2489},
{"f_8886:c_backend_scm",(void*)f_8886},
{"f_9162:c_backend_scm",(void*)f_9162},
{"f_9160:c_backend_scm",(void*)f_9160},
{"f_9148:c_backend_scm",(void*)f_9148},
{"f_9118:c_backend_scm",(void*)f_9118},
{"f_9079:c_backend_scm",(void*)f_9079},
{"f_9066:c_backend_scm",(void*)f_9066},
{"f_9062:c_backend_scm",(void*)f_9062},
{"f_8948:c_backend_scm",(void*)f_8948},
{"f_8895:c_backend_scm",(void*)f_8895},
{"f_8488:c_backend_scm",(void*)f_8488},
{"f_8575:c_backend_scm",(void*)f_8575},
{"f_8656:c_backend_scm",(void*)f_8656},
{"f_8678:c_backend_scm",(void*)f_8678},
{"f_8490:c_backend_scm",(void*)f_8490},
{"f_8003:c_backend_scm",(void*)f_8003},
{"f_8033:c_backend_scm",(void*)f_8033},
{"f_8060:c_backend_scm",(void*)f_8060},
{"f_8255:c_backend_scm",(void*)f_8255},
{"f_8264:c_backend_scm",(void*)f_8264},
{"f_8273:c_backend_scm",(void*)f_8273},
{"f_8295:c_backend_scm",(void*)f_8295},
{"f_8372:c_backend_scm",(void*)f_8372},
{"f_8005:c_backend_scm",(void*)f_8005},
{"f_7167:c_backend_scm",(void*)f_7167},
{"f_7244:c_backend_scm",(void*)f_7244},
{"f_7346:c_backend_scm",(void*)f_7346},
{"f_7379:c_backend_scm",(void*)f_7379},
{"f_7475:c_backend_scm",(void*)f_7475},
{"f_7490:c_backend_scm",(void*)f_7490},
{"f_7530:c_backend_scm",(void*)f_7530},
{"f_7547:c_backend_scm",(void*)f_7547},
{"f_7564:c_backend_scm",(void*)f_7564},
{"f_7603:c_backend_scm",(void*)f_7603},
{"f_7620:c_backend_scm",(void*)f_7620},
{"f_7637:c_backend_scm",(void*)f_7637},
{"f_7654:c_backend_scm",(void*)f_7654},
{"f_7671:c_backend_scm",(void*)f_7671},
{"f_7688:c_backend_scm",(void*)f_7688},
{"f_7705:c_backend_scm",(void*)f_7705},
{"f_7717:c_backend_scm",(void*)f_7717},
{"f_7724:c_backend_scm",(void*)f_7724},
{"f_7734:c_backend_scm",(void*)f_7734},
{"f_7732:c_backend_scm",(void*)f_7732},
{"f_7728:c_backend_scm",(void*)f_7728},
{"f_7695:c_backend_scm",(void*)f_7695},
{"f_7678:c_backend_scm",(void*)f_7678},
{"f_7661:c_backend_scm",(void*)f_7661},
{"f_7644:c_backend_scm",(void*)f_7644},
{"f_7627:c_backend_scm",(void*)f_7627},
{"f_7610:c_backend_scm",(void*)f_7610},
{"f_7575:c_backend_scm",(void*)f_7575},
{"f_7585:c_backend_scm",(void*)f_7585},
{"f_7583:c_backend_scm",(void*)f_7583},
{"f_7579:c_backend_scm",(void*)f_7579},
{"f_7571:c_backend_scm",(void*)f_7571},
{"f_7558:c_backend_scm",(void*)f_7558},
{"f_7541:c_backend_scm",(void*)f_7541},
{"f_7174:c_backend_scm",(void*)f_7174},
{"f_7169:c_backend_scm",(void*)f_7169},
{"f_7102:c_backend_scm",(void*)f_7102},
{"f_7106:c_backend_scm",(void*)f_7106},
{"f_7109:c_backend_scm",(void*)f_7109},
{"f_7112:c_backend_scm",(void*)f_7112},
{"f_7115:c_backend_scm",(void*)f_7115},
{"f_7121:c_backend_scm",(void*)f_7121},
{"f_7165:c_backend_scm",(void*)f_7165},
{"f_7124:c_backend_scm",(void*)f_7124},
{"f_7132:c_backend_scm",(void*)f_7132},
{"f_7153:c_backend_scm",(void*)f_7153},
{"f_7136:c_backend_scm",(void*)f_7136},
{"f_7127:c_backend_scm",(void*)f_7127},
{"f_6671:c_backend_scm",(void*)f_6671},
{"f_6677:c_backend_scm",(void*)f_6677},
{"f_6681:c_backend_scm",(void*)f_6681},
{"f_6684:c_backend_scm",(void*)f_6684},
{"f_6687:c_backend_scm",(void*)f_6687},
{"f_6690:c_backend_scm",(void*)f_6690},
{"f_6696:c_backend_scm",(void*)f_6696},
{"f_7037:c_backend_scm",(void*)f_7037},
{"f_7040:c_backend_scm",(void*)f_7040},
{"f_7100:c_backend_scm",(void*)f_7100},
{"f_7043:c_backend_scm",(void*)f_7043},
{"f_7046:c_backend_scm",(void*)f_7046},
{"f_7049:c_backend_scm",(void*)f_7049},
{"f_7052:c_backend_scm",(void*)f_7052},
{"f_7085:c_backend_scm",(void*)f_7085},
{"f_7093:c_backend_scm",(void*)f_7093},
{"f_7055:c_backend_scm",(void*)f_7055},
{"f_7083:c_backend_scm",(void*)f_7083},
{"f_7058:c_backend_scm",(void*)f_7058},
{"f_7061:c_backend_scm",(void*)f_7061},
{"f_7064:c_backend_scm",(void*)f_7064},
{"f_6698:c_backend_scm",(void*)f_6698},
{"f_6708:c_backend_scm",(void*)f_6708},
{"f_6717:c_backend_scm",(void*)f_6717},
{"f_6729:c_backend_scm",(void*)f_6729},
{"f_6741:c_backend_scm",(void*)f_6741},
{"f_6747:c_backend_scm",(void*)f_6747},
{"f_6781:c_backend_scm",(void*)f_6781},
{"f_6438:c_backend_scm",(void*)f_6438},
{"f_6444:c_backend_scm",(void*)f_6444},
{"f_6448:c_backend_scm",(void*)f_6448},
{"f_6451:c_backend_scm",(void*)f_6451},
{"f_6454:c_backend_scm",(void*)f_6454},
{"f_6669:c_backend_scm",(void*)f_6669},
{"f_6460:c_backend_scm",(void*)f_6460},
{"f_6463:c_backend_scm",(void*)f_6463},
{"f_6466:c_backend_scm",(void*)f_6466},
{"f_6469:c_backend_scm",(void*)f_6469},
{"f_6472:c_backend_scm",(void*)f_6472},
{"f_6475:c_backend_scm",(void*)f_6475},
{"f_6478:c_backend_scm",(void*)f_6478},
{"f_6481:c_backend_scm",(void*)f_6481},
{"f_6484:c_backend_scm",(void*)f_6484},
{"f_6487:c_backend_scm",(void*)f_6487},
{"f_6658:c_backend_scm",(void*)f_6658},
{"f_6490:c_backend_scm",(void*)f_6490},
{"f_6493:c_backend_scm",(void*)f_6493},
{"f_6496:c_backend_scm",(void*)f_6496},
{"f_6499:c_backend_scm",(void*)f_6499},
{"f_6502:c_backend_scm",(void*)f_6502},
{"f_6505:c_backend_scm",(void*)f_6505},
{"f_6508:c_backend_scm",(void*)f_6508},
{"f_6511:c_backend_scm",(void*)f_6511},
{"f_6636:c_backend_scm",(void*)f_6636},
{"f_6606:c_backend_scm",(void*)f_6606},
{"f_6626:c_backend_scm",(void*)f_6626},
{"f_6614:c_backend_scm",(void*)f_6614},
{"f_6618:c_backend_scm",(void*)f_6618},
{"f_6622:c_backend_scm",(void*)f_6622},
{"f_6514:c_backend_scm",(void*)f_6514},
{"f_6517:c_backend_scm",(void*)f_6517},
{"f_6547:c_backend_scm",(void*)f_6547},
{"f_6550:c_backend_scm",(void*)f_6550},
{"f_6588:c_backend_scm",(void*)f_6588},
{"f_6584:c_backend_scm",(void*)f_6584},
{"f_6553:c_backend_scm",(void*)f_6553},
{"f_6556:c_backend_scm",(void*)f_6556},
{"f_6559:c_backend_scm",(void*)f_6559},
{"f_6526:c_backend_scm",(void*)f_6526},
{"f_6529:c_backend_scm",(void*)f_6529},
{"f_6520:c_backend_scm",(void*)f_6520},
{"f_6420:c_backend_scm",(void*)f_6420},
{"f_6426:c_backend_scm",(void*)f_6426},
{"f_6430:c_backend_scm",(void*)f_6430},
{"f_6433:c_backend_scm",(void*)f_6433},
{"f_6388:c_backend_scm",(void*)f_6388},
{"f_6392:c_backend_scm",(void*)f_6392},
{"f_6397:c_backend_scm",(void*)f_6397},
{"f_6418:c_backend_scm",(void*)f_6418},
{"f_6372:c_backend_scm",(void*)f_6372},
{"f_6378:c_backend_scm",(void*)f_6378},
{"f_6386:c_backend_scm",(void*)f_6386},
{"f_6356:c_backend_scm",(void*)f_6356},
{"f_6362:c_backend_scm",(void*)f_6362},
{"f_6370:c_backend_scm",(void*)f_6370},
{"f_6267:c_backend_scm",(void*)f_6267},
{"f_6276:c_backend_scm",(void*)f_6276},
{"f_6305:c_backend_scm",(void*)f_6305},
{"f_6315:c_backend_scm",(void*)f_6315},
{"f_6308:c_backend_scm",(void*)f_6308},
{"f_6292:c_backend_scm",(void*)f_6292},
{"f_6190:c_backend_scm",(void*)f_6190},
{"f_6194:c_backend_scm",(void*)f_6194},
{"f_6208:c_backend_scm",(void*)f_6208},
{"f_6221:c_backend_scm",(void*)f_6221},
{"f_6253:c_backend_scm",(void*)f_6253},
{"f_6224:c_backend_scm",(void*)f_6224},
{"f_6227:c_backend_scm",(void*)f_6227},
{"f_6197:c_backend_scm",(void*)f_6197},
{"f_6200:c_backend_scm",(void*)f_6200},
{"f_6203:c_backend_scm",(void*)f_6203},
{"f_2491:c_backend_scm",(void*)f_2491},
{"f_6157:c_backend_scm",(void*)f_6157},
{"f_6161:c_backend_scm",(void*)f_6161},
{"f_6164:c_backend_scm",(void*)f_6164},
{"f_6167:c_backend_scm",(void*)f_6167},
{"f_6170:c_backend_scm",(void*)f_6170},
{"f_6173:c_backend_scm",(void*)f_6173},
{"f_6176:c_backend_scm",(void*)f_6176},
{"f_6179:c_backend_scm",(void*)f_6179},
{"f_6182:c_backend_scm",(void*)f_6182},
{"f_6185:c_backend_scm",(void*)f_6185},
{"f_5410:c_backend_scm",(void*)f_5410},
{"f_5416:c_backend_scm",(void*)f_5416},
{"f_5420:c_backend_scm",(void*)f_5420},
{"f_5423:c_backend_scm",(void*)f_5423},
{"f_5426:c_backend_scm",(void*)f_5426},
{"f_5429:c_backend_scm",(void*)f_5429},
{"f_5432:c_backend_scm",(void*)f_5432},
{"f_5435:c_backend_scm",(void*)f_5435},
{"f_6154:c_backend_scm",(void*)f_6154},
{"f_5438:c_backend_scm",(void*)f_5438},
{"f_5444:c_backend_scm",(void*)f_5444},
{"f_5447:c_backend_scm",(void*)f_5447},
{"f_5450:c_backend_scm",(void*)f_5450},
{"f_5453:c_backend_scm",(void*)f_5453},
{"f_5456:c_backend_scm",(void*)f_5456},
{"f_5459:c_backend_scm",(void*)f_5459},
{"f_5462:c_backend_scm",(void*)f_5462},
{"f_5465:c_backend_scm",(void*)f_5465},
{"f_5468:c_backend_scm",(void*)f_5468},
{"f_5471:c_backend_scm",(void*)f_5471},
{"f_5474:c_backend_scm",(void*)f_5474},
{"f_5477:c_backend_scm",(void*)f_5477},
{"f_6123:c_backend_scm",(void*)f_6123},
{"f_5480:c_backend_scm",(void*)f_5480},
{"f_6084:c_backend_scm",(void*)f_6084},
{"f_6087:c_backend_scm",(void*)f_6087},
{"f_6090:c_backend_scm",(void*)f_6090},
{"f_6106:c_backend_scm",(void*)f_6106},
{"f_6109:c_backend_scm",(void*)f_6109},
{"f_5483:c_backend_scm",(void*)f_5483},
{"f_5486:c_backend_scm",(void*)f_5486},
{"f_5489:c_backend_scm",(void*)f_5489},
{"f_6056:c_backend_scm",(void*)f_6056},
{"f_6059:c_backend_scm",(void*)f_6059},
{"f_5492:c_backend_scm",(void*)f_5492},
{"f_5495:c_backend_scm",(void*)f_5495},
{"f_5498:c_backend_scm",(void*)f_5498},
{"f_5501:c_backend_scm",(void*)f_5501},
{"f_5504:c_backend_scm",(void*)f_5504},
{"f_5507:c_backend_scm",(void*)f_5507},
{"f_6018:c_backend_scm",(void*)f_6018},
{"f_6028:c_backend_scm",(void*)f_6028},
{"f_5510:c_backend_scm",(void*)f_5510},
{"f_5961:c_backend_scm",(void*)f_5961},
{"f_5973:c_backend_scm",(void*)f_5973},
{"f_5976:c_backend_scm",(void*)f_5976},
{"f_5982:c_backend_scm",(void*)f_5982},
{"f_5883:c_backend_scm",(void*)f_5883},
{"f_5925:c_backend_scm",(void*)f_5925},
{"f_5886:c_backend_scm",(void*)f_5886},
{"f_5892:c_backend_scm",(void*)f_5892},
{"f_5895:c_backend_scm",(void*)f_5895},
{"f_5901:c_backend_scm",(void*)f_5901},
{"f_5819:c_backend_scm",(void*)f_5819},
{"f_5822:c_backend_scm",(void*)f_5822},
{"f_5825:c_backend_scm",(void*)f_5825},
{"f_5828:c_backend_scm",(void*)f_5828},
{"f_5831:c_backend_scm",(void*)f_5831},
{"f_5846:c_backend_scm",(void*)f_5846},
{"f_5834:c_backend_scm",(void*)f_5834},
{"f_5837:c_backend_scm",(void*)f_5837},
{"f_5805:c_backend_scm",(void*)f_5805},
{"f_5813:c_backend_scm",(void*)f_5813},
{"f_5730:c_backend_scm",(void*)f_5730},
{"f_5736:c_backend_scm",(void*)f_5736},
{"f_5739:c_backend_scm",(void*)f_5739},
{"f_5773:c_backend_scm",(void*)f_5773},
{"f_5776:c_backend_scm",(void*)f_5776},
{"f_5779:c_backend_scm",(void*)f_5779},
{"f_5742:c_backend_scm",(void*)f_5742},
{"f_5745:c_backend_scm",(void*)f_5745},
{"f_5748:c_backend_scm",(void*)f_5748},
{"f_5751:c_backend_scm",(void*)f_5751},
{"f_5760:c_backend_scm",(void*)f_5760},
{"f_5763:c_backend_scm",(void*)f_5763},
{"f_5513:c_backend_scm",(void*)f_5513},
{"f_5536:c_backend_scm",(void*)f_5536},
{"f_5671:c_backend_scm",(void*)f_5671},
{"f_5674:c_backend_scm",(void*)f_5674},
{"f_5686:c_backend_scm",(void*)f_5686},
{"f_5677:c_backend_scm",(void*)f_5677},
{"f_5542:c_backend_scm",(void*)f_5542},
{"f_5545:c_backend_scm",(void*)f_5545},
{"f_5548:c_backend_scm",(void*)f_5548},
{"f_5652:c_backend_scm",(void*)f_5652},
{"f_5551:c_backend_scm",(void*)f_5551},
{"f_5554:c_backend_scm",(void*)f_5554},
{"f_5557:c_backend_scm",(void*)f_5557},
{"f_5560:c_backend_scm",(void*)f_5560},
{"f_5625:c_backend_scm",(void*)f_5625},
{"f_5621:c_backend_scm",(void*)f_5621},
{"f_5563:c_backend_scm",(void*)f_5563},
{"f_5566:c_backend_scm",(void*)f_5566},
{"f_5569:c_backend_scm",(void*)f_5569},
{"f_5572:c_backend_scm",(void*)f_5572},
{"f_5575:c_backend_scm",(void*)f_5575},
{"f_5578:c_backend_scm",(void*)f_5578},
{"f_5596:c_backend_scm",(void*)f_5596},
{"f_5606:c_backend_scm",(void*)f_5606},
{"f_5581:c_backend_scm",(void*)f_5581},
{"f_5516:c_backend_scm",(void*)f_5516},
{"f_5526:c_backend_scm",(void*)f_5526},
{"f_5519:c_backend_scm",(void*)f_5519},
{"f_5020:c_backend_scm",(void*)f_5020},
{"f_5027:c_backend_scm",(void*)f_5027},
{"f_5101:c_backend_scm",(void*)f_5101},
{"f_5119:c_backend_scm",(void*)f_5119},
{"f_5148:c_backend_scm",(void*)f_5148},
{"f_5170:c_backend_scm",(void*)f_5170},
{"f_5126:c_backend_scm",(void*)f_5126},
{"f_5095:c_backend_scm",(void*)f_5095},
{"f_5091:c_backend_scm",(void*)f_5091},
{"f_5087:c_backend_scm",(void*)f_5087},
{"f_5058:c_backend_scm",(void*)f_5058},
{"f_5062:c_backend_scm",(void*)f_5062},
{"f_4977:c_backend_scm",(void*)f_4977},
{"f_4983:c_backend_scm",(void*)f_4983},
{"f_5012:c_backend_scm",(void*)f_5012},
{"f_4993:c_backend_scm",(void*)f_4993},
{"f_5179:c_backend_scm",(void*)f_5179},
{"f_5319:c_backend_scm",(void*)f_5319},
{"f_5186:c_backend_scm",(void*)f_5186},
{"f_5192:c_backend_scm",(void*)f_5192},
{"f_5275:c_backend_scm",(void*)f_5275},
{"f_5278:c_backend_scm",(void*)f_5278},
{"f_5288:c_backend_scm",(void*)f_5288},
{"f_5281:c_backend_scm",(void*)f_5281},
{"f_5242:c_backend_scm",(void*)f_5242},
{"f_5248:c_backend_scm",(void*)f_5248},
{"f_5014:c_backend_scm",(void*)f_5014},
{"f_5321:c_backend_scm",(void*)f_5321},
{"f_5328:c_backend_scm",(void*)f_5328},
{"f_5331:c_backend_scm",(void*)f_5331},
{"f_5336:c_backend_scm",(void*)f_5336},
{"f_5392:c_backend_scm",(void*)f_5392},
{"f_5388:c_backend_scm",(void*)f_5388},
{"f_5373:c_backend_scm",(void*)f_5373},
{"f_5352:c_backend_scm",(void*)f_5352},
{"f_5363:c_backend_scm",(void*)f_5363},
{"f_5359:c_backend_scm",(void*)f_5359},
{"f_5398:c_backend_scm",(void*)f_5398},
{"f_5405:c_backend_scm",(void*)f_5405},
{"f_5408:c_backend_scm",(void*)f_5408},
{"f_4691:c_backend_scm",(void*)f_4691},
{"f_4858:c_backend_scm",(void*)f_4858},
{"f_4862:c_backend_scm",(void*)f_4862},
{"f_4865:c_backend_scm",(void*)f_4865},
{"f_4868:c_backend_scm",(void*)f_4868},
{"f_4871:c_backend_scm",(void*)f_4871},
{"f_4874:c_backend_scm",(void*)f_4874},
{"f_4975:c_backend_scm",(void*)f_4975},
{"f_4877:c_backend_scm",(void*)f_4877},
{"f_4880:c_backend_scm",(void*)f_4880},
{"f_4886:c_backend_scm",(void*)f_4886},
{"f_4964:c_backend_scm",(void*)f_4964},
{"f_4920:c_backend_scm",(void*)f_4920},
{"f_4926:c_backend_scm",(void*)f_4926},
{"f_4944:c_backend_scm",(void*)f_4944},
{"f_4940:c_backend_scm",(void*)f_4940},
{"f_4936:c_backend_scm",(void*)f_4936},
{"f_4892:c_backend_scm",(void*)f_4892},
{"f_4895:c_backend_scm",(void*)f_4895},
{"f_4898:c_backend_scm",(void*)f_4898},
{"f_4901:c_backend_scm",(void*)f_4901},
{"f_4904:c_backend_scm",(void*)f_4904},
{"f_4914:c_backend_scm",(void*)f_4914},
{"f_4907:c_backend_scm",(void*)f_4907},
{"f_4810:c_backend_scm",(void*)f_4810},
{"f_4829:c_backend_scm",(void*)f_4829},
{"f_4833:c_backend_scm",(void*)f_4833},
{"f_4836:c_backend_scm",(void*)f_4836},
{"f_4839:c_backend_scm",(void*)f_4839},
{"f_4842:c_backend_scm",(void*)f_4842},
{"f_4856:c_backend_scm",(void*)f_4856},
{"f_4852:c_backend_scm",(void*)f_4852},
{"f_4845:c_backend_scm",(void*)f_4845},
{"f_4813:c_backend_scm",(void*)f_4813},
{"f_4827:c_backend_scm",(void*)f_4827},
{"f_4816:c_backend_scm",(void*)f_4816},
{"f_4823:c_backend_scm",(void*)f_4823},
{"f_4730:c_backend_scm",(void*)f_4730},
{"f_4732:c_backend_scm",(void*)f_4732},
{"f_4736:c_backend_scm",(void*)f_4736},
{"f_4739:c_backend_scm",(void*)f_4739},
{"f_4742:c_backend_scm",(void*)f_4742},
{"f_4745:c_backend_scm",(void*)f_4745},
{"f_4748:c_backend_scm",(void*)f_4748},
{"f_4751:c_backend_scm",(void*)f_4751},
{"f_4754:c_backend_scm",(void*)f_4754},
{"f_4757:c_backend_scm",(void*)f_4757},
{"f_4760:c_backend_scm",(void*)f_4760},
{"f_4763:c_backend_scm",(void*)f_4763},
{"f_4766:c_backend_scm",(void*)f_4766},
{"f_4769:c_backend_scm",(void*)f_4769},
{"f_4783:c_backend_scm",(void*)f_4783},
{"f_4779:c_backend_scm",(void*)f_4779},
{"f_4772:c_backend_scm",(void*)f_4772},
{"f_4694:c_backend_scm",(void*)f_4694},
{"f_4707:c_backend_scm",(void*)f_4707},
{"f_4717:c_backend_scm",(void*)f_4717},
{"f_4698:c_backend_scm",(void*)f_4698},
{"f_4440:c_backend_scm",(void*)f_4440},
{"f_4444:c_backend_scm",(void*)f_4444},
{"f_4468:c_backend_scm",(void*)f_4468},
{"f_4472:c_backend_scm",(void*)f_4472},
{"f_4475:c_backend_scm",(void*)f_4475},
{"f_4689:c_backend_scm",(void*)f_4689},
{"f_4478:c_backend_scm",(void*)f_4478},
{"f_4675:c_backend_scm",(void*)f_4675},
{"f_4481:c_backend_scm",(void*)f_4481},
{"f_4484:c_backend_scm",(void*)f_4484},
{"f_4487:c_backend_scm",(void*)f_4487},
{"f_4490:c_backend_scm",(void*)f_4490},
{"f_4493:c_backend_scm",(void*)f_4493},
{"f_4496:c_backend_scm",(void*)f_4496},
{"f_4667:c_backend_scm",(void*)f_4667},
{"f_4499:c_backend_scm",(void*)f_4499},
{"f_4502:c_backend_scm",(void*)f_4502},
{"f_4660:c_backend_scm",(void*)f_4660},
{"f_4641:c_backend_scm",(void*)f_4641},
{"f_4652:c_backend_scm",(void*)f_4652},
{"f_4505:c_backend_scm",(void*)f_4505},
{"f_4592:c_backend_scm",(void*)f_4592},
{"f_4595:c_backend_scm",(void*)f_4595},
{"f_4598:c_backend_scm",(void*)f_4598},
{"f_4601:c_backend_scm",(void*)f_4601},
{"f_4617:c_backend_scm",(void*)f_4617},
{"f_4620:c_backend_scm",(void*)f_4620},
{"f_4623:c_backend_scm",(void*)f_4623},
{"f_4626:c_backend_scm",(void*)f_4626},
{"f_4508:c_backend_scm",(void*)f_4508},
{"f_4511:c_backend_scm",(void*)f_4511},
{"f_4514:c_backend_scm",(void*)f_4514},
{"f_4564:c_backend_scm",(void*)f_4564},
{"f_4567:c_backend_scm",(void*)f_4567},
{"f_4517:c_backend_scm",(void*)f_4517},
{"f_4520:c_backend_scm",(void*)f_4520},
{"f_4552:c_backend_scm",(void*)f_4552},
{"f_4555:c_backend_scm",(void*)f_4555},
{"f_4526:c_backend_scm",(void*)f_4526},
{"f_4535:c_backend_scm",(void*)f_4535},
{"f_4538:c_backend_scm",(void*)f_4538},
{"f_4447:c_backend_scm",(void*)f_4447},
{"f_4452:c_backend_scm",(void*)f_4452},
{"f_4456:c_backend_scm",(void*)f_4456},
{"f_4466:c_backend_scm",(void*)f_4466},
{"f_4459:c_backend_scm",(void*)f_4459},
{"f_4291:c_backend_scm",(void*)f_4291},
{"f_4298:c_backend_scm",(void*)f_4298},
{"f_4434:c_backend_scm",(void*)f_4434},
{"f_4301:c_backend_scm",(void*)f_4301},
{"f_4304:c_backend_scm",(void*)f_4304},
{"f_4307:c_backend_scm",(void*)f_4307},
{"f_4312:c_backend_scm",(void*)f_4312},
{"f_4322:c_backend_scm",(void*)f_4322},
{"f_4328:c_backend_scm",(void*)f_4328},
{"f_4381:c_backend_scm",(void*)f_4381},
{"f_4391:c_backend_scm",(void*)f_4391},
{"f_4331:c_backend_scm",(void*)f_4331},
{"f_4354:c_backend_scm",(void*)f_4354},
{"f_4364:c_backend_scm",(void*)f_4364},
{"f_4334:c_backend_scm",(void*)f_4334},
{"f_4337:c_backend_scm",(void*)f_4337},
{"f_4144:c_backend_scm",(void*)f_4144},
{"f_4283:c_backend_scm",(void*)f_4283},
{"f_4164:c_backend_scm",(void*)f_4164},
{"f_4241:c_backend_scm",(void*)f_4241},
{"f_4245:c_backend_scm",(void*)f_4245},
{"f_4249:c_backend_scm",(void*)f_4249},
{"f_4253:c_backend_scm",(void*)f_4253},
{"f_4275:c_backend_scm",(void*)f_4275},
{"f_4271:c_backend_scm",(void*)f_4271},
{"f_4263:c_backend_scm",(void*)f_4263},
{"f_4261:c_backend_scm",(void*)f_4261},
{"f_4257:c_backend_scm",(void*)f_4257},
{"f_4182:c_backend_scm",(void*)f_4182},
{"f_4185:c_backend_scm",(void*)f_4185},
{"f_4188:c_backend_scm",(void*)f_4188},
{"f_4230:c_backend_scm",(void*)f_4230},
{"f_4191:c_backend_scm",(void*)f_4191},
{"f_4194:c_backend_scm",(void*)f_4194},
{"f_4197:c_backend_scm",(void*)f_4197},
{"f_4212:c_backend_scm",(void*)f_4212},
{"f_4217:c_backend_scm",(void*)f_4217},
{"f_4200:c_backend_scm",(void*)f_4200},
{"f_4147:c_backend_scm",(void*)f_4147},
{"f_4161:c_backend_scm",(void*)f_4161},
{"f_2536:c_backend_scm",(void*)f_2536},
{"f_4112:c_backend_scm",(void*)f_4112},
{"f_4118:c_backend_scm",(void*)f_4118},
{"f_4122:c_backend_scm",(void*)f_4122},
{"f_2539:c_backend_scm",(void*)f_2539},
{"f_4106:c_backend_scm",(void*)f_4106},
{"f_2543:c_backend_scm",(void*)f_2543},
{"f_4101:c_backend_scm",(void*)f_4101},
{"f_2546:c_backend_scm",(void*)f_2546},
{"f_4096:c_backend_scm",(void*)f_4096},
{"f_2549:c_backend_scm",(void*)f_2549},
{"f_4062:c_backend_scm",(void*)f_4062},
{"f_4065:c_backend_scm",(void*)f_4065},
{"f_4068:c_backend_scm",(void*)f_4068},
{"f_4071:c_backend_scm",(void*)f_4071},
{"f_4074:c_backend_scm",(void*)f_4074},
{"f_4077:c_backend_scm",(void*)f_4077},
{"f_3979:c_backend_scm",(void*)f_3979},
{"f_3982:c_backend_scm",(void*)f_3982},
{"f_3985:c_backend_scm",(void*)f_3985},
{"f_3998:c_backend_scm",(void*)f_3998},
{"f_4021:c_backend_scm",(void*)f_4021},
{"f_4024:c_backend_scm",(void*)f_4024},
{"f_4027:c_backend_scm",(void*)f_4027},
{"f_4030:c_backend_scm",(void*)f_4030},
{"f_4008:c_backend_scm",(void*)f_4008},
{"f_4011:c_backend_scm",(void*)f_4011},
{"f_3970:c_backend_scm",(void*)f_3970},
{"f_3942:c_backend_scm",(void*)f_3942},
{"f_3945:c_backend_scm",(void*)f_3945},
{"f_3962:c_backend_scm",(void*)f_3962},
{"f_3948:c_backend_scm",(void*)f_3948},
{"f_3951:c_backend_scm",(void*)f_3951},
{"f_3926:c_backend_scm",(void*)f_3926},
{"f_3930:c_backend_scm",(void*)f_3930},
{"f_3912:c_backend_scm",(void*)f_3912},
{"f_3915:c_backend_scm",(void*)f_3915},
{"f_3896:c_backend_scm",(void*)f_3896},
{"f_3900:c_backend_scm",(void*)f_3900},
{"f_3878:c_backend_scm",(void*)f_3878},
{"f_3881:c_backend_scm",(void*)f_3881},
{"f_3858:c_backend_scm",(void*)f_3858},
{"f_3822:c_backend_scm",(void*)f_3822},
{"f_3834:c_backend_scm",(void*)f_3834},
{"f_3825:c_backend_scm",(void*)f_3825},
{"f_3803:c_backend_scm",(void*)f_3803},
{"f_3806:c_backend_scm",(void*)f_3806},
{"f_3784:c_backend_scm",(void*)f_3784},
{"f_3787:c_backend_scm",(void*)f_3787},
{"f_3765:c_backend_scm",(void*)f_3765},
{"f_3768:c_backend_scm",(void*)f_3768},
{"f_3746:c_backend_scm",(void*)f_3746},
{"f_3742:c_backend_scm",(void*)f_3742},
{"f_3690:c_backend_scm",(void*)f_3690},
{"f_3723:c_backend_scm",(void*)f_3723},
{"f_3693:c_backend_scm",(void*)f_3693},
{"f_3711:c_backend_scm",(void*)f_3711},
{"f_3696:c_backend_scm",(void*)f_3696},
{"f_3699:c_backend_scm",(void*)f_3699},
{"f_3657:c_backend_scm",(void*)f_3657},
{"f_3641:c_backend_scm",(void*)f_3641},
{"f_3644:c_backend_scm",(void*)f_3644},
{"f_3647:c_backend_scm",(void*)f_3647},
{"f_3600:c_backend_scm",(void*)f_3600},
{"f_3603:c_backend_scm",(void*)f_3603},
{"f_3624:c_backend_scm",(void*)f_3624},
{"f_3628:c_backend_scm",(void*)f_3628},
{"f_3631:c_backend_scm",(void*)f_3631},
{"f_3606:c_backend_scm",(void*)f_3606},
{"f_3622:c_backend_scm",(void*)f_3622},
{"f_3614:c_backend_scm",(void*)f_3614},
{"f_3609:c_backend_scm",(void*)f_3609},
{"f_3213:c_backend_scm",(void*)f_3213},
{"f_3216:c_backend_scm",(void*)f_3216},
{"f_3550:c_backend_scm",(void*)f_3550},
{"f_3546:c_backend_scm",(void*)f_3546},
{"f_3222:c_backend_scm",(void*)f_3222},
{"f_3539:c_backend_scm",(void*)f_3539},
{"f_2524:c_backend_scm",(void*)f_2524},
{"f_3532:c_backend_scm",(void*)f_3532},
{"f_3228:c_backend_scm",(void*)f_3228},
{"f_3518:c_backend_scm",(void*)f_3518},
{"f_3517:c_backend_scm",(void*)f_3517},
{"f_3509:c_backend_scm",(void*)f_3509},
{"f_3508:c_backend_scm",(void*)f_3508},
{"f_3360:c_backend_scm",(void*)f_3360},
{"f_3449:c_backend_scm",(void*)f_3449},
{"f_3452:c_backend_scm",(void*)f_3452},
{"f_3455:c_backend_scm",(void*)f_3455},
{"f_3470:c_backend_scm",(void*)f_3470},
{"f_3458:c_backend_scm",(void*)f_3458},
{"f_3461:c_backend_scm",(void*)f_3461},
{"f_3464:c_backend_scm",(void*)f_3464},
{"f_3442:c_backend_scm",(void*)f_3442},
{"f_3363:c_backend_scm",(void*)f_3363},
{"f_3375:c_backend_scm",(void*)f_3375},
{"f_3441:c_backend_scm",(void*)f_3441},
{"f_3434:c_backend_scm",(void*)f_3434},
{"f_3430:c_backend_scm",(void*)f_3430},
{"f_3423:c_backend_scm",(void*)f_3423},
{"f_3416:c_backend_scm",(void*)f_3416},
{"f_3391:c_backend_scm",(void*)f_3391},
{"f_3408:c_backend_scm",(void*)f_3408},
{"f_3404:c_backend_scm",(void*)f_3404},
{"f_3378:c_backend_scm",(void*)f_3378},
{"f_3381:c_backend_scm",(void*)f_3381},
{"f_3384:c_backend_scm",(void*)f_3384},
{"f_3354:c_backend_scm",(void*)f_3354},
{"f_3264:c_backend_scm",(void*)f_3264},
{"f_3338:c_backend_scm",(void*)f_3338},
{"f_3341:c_backend_scm",(void*)f_3341},
{"f_3314:c_backend_scm",(void*)f_3314},
{"f_3317:c_backend_scm",(void*)f_3317},
{"f_3320:c_backend_scm",(void*)f_3320},
{"f_3323:c_backend_scm",(void*)f_3323},
{"f_3326:c_backend_scm",(void*)f_3326},
{"f_3267:c_backend_scm",(void*)f_3267},
{"f_3270:c_backend_scm",(void*)f_3270},
{"f_3297:c_backend_scm",(void*)f_3297},
{"f_3301:c_backend_scm",(void*)f_3301},
{"f_3304:c_backend_scm",(void*)f_3304},
{"f_3273:c_backend_scm",(void*)f_3273},
{"f_3295:c_backend_scm",(void*)f_3295},
{"f_3287:c_backend_scm",(void*)f_3287},
{"f_3276:c_backend_scm",(void*)f_3276},
{"f_3279:c_backend_scm",(void*)f_3279},
{"f_3251:c_backend_scm",(void*)f_3251},
{"f_3237:c_backend_scm",(void*)f_3237},
{"f_3240:c_backend_scm",(void*)f_3240},
{"f_3243:c_backend_scm",(void*)f_3243},
{"f_3180:c_backend_scm",(void*)f_3180},
{"f_3176:c_backend_scm",(void*)f_3176},
{"f_3162:c_backend_scm",(void*)f_3162},
{"f_3165:c_backend_scm",(void*)f_3165},
{"f_3159:c_backend_scm",(void*)f_3159},
{"f_3155:c_backend_scm",(void*)f_3155},
{"f_3141:c_backend_scm",(void*)f_3141},
{"f_3144:c_backend_scm",(void*)f_3144},
{"f_3093:c_backend_scm",(void*)f_3093},
{"f_3114:c_backend_scm",(void*)f_3114},
{"f_3110:c_backend_scm",(void*)f_3110},
{"f_3096:c_backend_scm",(void*)f_3096},
{"f_3099:c_backend_scm",(void*)f_3099},
{"f_3062:c_backend_scm",(void*)f_3062},
{"f_3058:c_backend_scm",(void*)f_3058},
{"f_3016:c_backend_scm",(void*)f_3016},
{"f_2984:c_backend_scm",(void*)f_2984},
{"f_2987:c_backend_scm",(void*)f_2987},
{"f_2949:c_backend_scm",(void*)f_2949},
{"f_2975:c_backend_scm",(void*)f_2975},
{"f_2961:c_backend_scm",(void*)f_2961},
{"f_2965:c_backend_scm",(void*)f_2965},
{"f_2968:c_backend_scm",(void*)f_2968},
{"f_2952:c_backend_scm",(void*)f_2952},
{"f_2917:c_backend_scm",(void*)f_2917},
{"f_2920:c_backend_scm",(void*)f_2920},
{"f_2923:c_backend_scm",(void*)f_2923},
{"f_2926:c_backend_scm",(void*)f_2926},
{"f_2888:c_backend_scm",(void*)f_2888},
{"f_2891:c_backend_scm",(void*)f_2891},
{"f_2894:c_backend_scm",(void*)f_2894},
{"f_2897:c_backend_scm",(void*)f_2897},
{"f_2851:c_backend_scm",(void*)f_2851},
{"f_2854:c_backend_scm",(void*)f_2854},
{"f_2857:c_backend_scm",(void*)f_2857},
{"f_2860:c_backend_scm",(void*)f_2860},
{"f_2818:c_backend_scm",(void*)f_2818},
{"f_2821:c_backend_scm",(void*)f_2821},
{"f_2824:c_backend_scm",(void*)f_2824},
{"f_2827:c_backend_scm",(void*)f_2827},
{"f_2799:c_backend_scm",(void*)f_2799},
{"f_2802:c_backend_scm",(void*)f_2802},
{"f_2772:c_backend_scm",(void*)f_2772},
{"f_2775:c_backend_scm",(void*)f_2775},
{"f_2721:c_backend_scm",(void*)f_2721},
{"f_2731:c_backend_scm",(void*)f_2731},
{"f_2734:c_backend_scm",(void*)f_2734},
{"f_2737:c_backend_scm",(void*)f_2737},
{"f_2663:c_backend_scm",(void*)f_2663},
{"f_2666:c_backend_scm",(void*)f_2666},
{"f_2669:c_backend_scm",(void*)f_2669},
{"f_2672:c_backend_scm",(void*)f_2672},
{"f_2675:c_backend_scm",(void*)f_2675},
{"f_2678:c_backend_scm",(void*)f_2678},
{"f_2526:c_backend_scm",(void*)f_2526},
{"f_2534:c_backend_scm",(void*)f_2534},
{"f_2494:c_backend_scm",(void*)f_2494},
{"f_2506:c_backend_scm",(void*)f_2506},
{"f_2514:c_backend_scm",(void*)f_2514},
{"f_2498:c_backend_scm",(void*)f_2498},
{"f_2471:c_backend_scm",(void*)f_2471},
{"f_2485:c_backend_scm",(void*)f_2485},
{"f_2477:c_backend_scm",(void*)f_2477},
{"f_2450:c_backend_scm",(void*)f_2450},
{"f_2456:c_backend_scm",(void*)f_2456},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
