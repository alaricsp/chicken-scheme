/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-05-02 09:52
   Version 3.2.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook hostpcre ]
   SVN rev. 10674	compiled 2008-04-30 on debian (Linux)
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[814];
static double C_possibly_force_alignment;


/* from getsize in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1050(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1050(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1046(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1046(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1100)
static void C_ccall f_1100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8807)
static void C_ccall f_8807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8811)
static void C_ccall f_8811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8803)
static void C_ccall f_8803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8503)
static void C_ccall f_8503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8779)
static void C_ccall f_8779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8777)
static void C_ccall f_8777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8765)
static void C_ccall f_8765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8735)
static void C_ccall f_8735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8696)
static void C_ccall f_8696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8683)
static void C_ccall f_8683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8565)
static void C_ccall f_8565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8512)
static C_word C_fcall f_8512(C_word *a,C_word t0);
C_noret_decl(f_8509)
static C_word C_fcall f_8509(C_word t0);
C_noret_decl(f_8506)
static C_word C_fcall f_8506(C_word t0);
C_noret_decl(f_7729)
static void C_ccall f_7729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7816)
static void C_fcall f_7816(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7897)
static void C_ccall f_7897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8332)
static void C_fcall f_8332(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_fcall f_8274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8238)
static void C_fcall f_8238(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8203)
static void C_fcall f_8203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8155)
static void C_fcall f_8155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8107)
static void C_fcall f_8107(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8059)
static void C_fcall f_8059(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8024)
static void C_fcall f_8024(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7988)
static void C_fcall f_7988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7952)
static void C_fcall f_7952(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7930)
static void C_fcall f_7930(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7925)
static void C_fcall f_7925(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_fcall f_7920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7731)
static void C_fcall f_7731(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6896)
static void C_ccall f_6896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6926)
static void C_fcall f_6926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6953)
static void C_fcall f_6953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7148)
static void C_fcall f_7148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7157)
static void C_fcall f_7157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7166)
static void C_ccall f_7166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7554)
static void C_fcall f_7554(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7521)
static void C_fcall f_7521(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7531)
static void C_ccall f_7531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7489)
static void C_fcall f_7489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7454)
static void C_fcall f_7454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7384)
static void C_fcall f_7384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7339)
static void C_fcall f_7339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_fcall f_7307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7275)
static void C_fcall f_7275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7243)
static void C_fcall f_7243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7211)
static void C_fcall f_7211(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_fcall f_7189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6898)
static void C_fcall f_6898(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5756)
static void C_fcall f_5756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5858)
static void C_fcall f_5858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_fcall f_5891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_fcall f_5987(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6002)
static void C_ccall f_6002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6619)
static void C_fcall f_6619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6635)
static void C_ccall f_6635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_fcall f_6639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6650)
static void C_ccall f_6650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6646)
static void C_ccall f_6646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6573)
static void C_fcall f_6573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_fcall f_6523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_fcall f_6473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_fcall f_6434(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6395)
static void C_fcall f_6395(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6356)
static void C_fcall f_6356(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6317)
static void C_fcall f_6317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6257)
static void C_fcall f_6257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6218)
static void C_fcall f_6218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_fcall f_6182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6146)
static void C_fcall f_6146(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6110)
static void C_fcall f_6110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_fcall f_6074(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6048)
static void C_fcall f_6048(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6039)
static void C_fcall f_6039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6034)
static void C_fcall f_6034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_fcall f_5686(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5681)
static void C_fcall f_5681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5621)
static void C_ccall f_5621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5564)
static void C_ccall f_5564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5220)
static void C_fcall f_5220(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_fcall f_5229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_fcall f_5241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_fcall f_5253(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5293)
static void C_fcall f_5293(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5002)
static void C_ccall f_5002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_ccall f_5005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_ccall f_5017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5134)
static void C_ccall f_5134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5059)
static void C_ccall f_5059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4932)
static void C_ccall f_4932(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4885)
static void C_ccall f_4885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4897)
static void C_fcall f_4897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4769)
static void C_fcall f_4769(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4798)
static void C_fcall f_4798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4808)
static void C_ccall f_4808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_fcall f_4801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_fcall f_4785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4687)
static void C_ccall f_4687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1150)
static void C_ccall f_1150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_ccall f_4661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_fcall f_3907(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3932)
static void C_ccall f_3932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_fcall f_3935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3959)
static void C_ccall f_3959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static void C_ccall f_4603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_ccall f_4606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_fcall f_4553(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_ccall f_4556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_fcall f_4001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_fcall f_4515(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_fcall f_4458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4479)
static void C_fcall f_4479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_fcall f_4422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_fcall f_4389(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_fcall f_4398(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4325)
static void C_ccall f_4325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4343)
static void C_fcall f_4343(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4273)
static void C_ccall f_4273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4276)
static void C_ccall f_4276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_fcall f_4033(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4093)
static void C_fcall f_4093(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_fcall f_3645(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_fcall f_3474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_fcall f_3480(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3490)
static void C_ccall f_3490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_fcall f_3676(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_fcall f_3683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_fcall f_3772(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_fcall f_3511(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_fcall f_3818(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_fcall f_3833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3870)
static void C_ccall f_3870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_fcall f_3849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3856)
static void C_ccall f_3856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_fcall f_3895(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_fcall f_3188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_fcall f_3374(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_fcall f_3377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_fcall f_3423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3330)
static void C_ccall f_3330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_fcall f_3227(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_ccall f_3269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_fcall f_3191(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3195)
static void C_ccall f_3195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_fcall f_2937(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_fcall f_2975(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_ccall f_3172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_fcall f_2996(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3002)
static void C_ccall f_3002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_fcall f_3061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3014)
static void C_ccall f_3014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_ccall f_3052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3023)
static void C_ccall f_3023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_ccall f_3035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_fcall f_2788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2809)
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_fcall f_2878(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_fcall f_2851(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_fcall f_2622(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_ccall f_2780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_fcall f_2648(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_ccall f_2669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_fcall f_2625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_fcall f_1195(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2590)
static void C_fcall f_2590(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_fcall f_1198(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static void C_ccall f_2472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_fcall f_2491(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2419)
static void C_ccall f_2419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2408)
static void C_ccall f_2408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2235)
static void C_ccall f_2235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_ccall f_2204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_fcall f_1842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_fcall f_1848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_fcall f_1999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1891)
static void C_ccall f_1891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static void C_ccall f_1783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1556)
static void C_ccall f_1556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1486)
static void C_ccall f_1486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1431)
static void C_ccall f_1431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_fcall f_1380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1109)
static void C_ccall f_1109r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1115)
static void C_ccall f_1115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_7816)
static void C_fcall trf_7816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7816(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7816(t0,t1);}

C_noret_decl(trf_8332)
static void C_fcall trf_8332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8332(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8332(t0,t1);}

C_noret_decl(trf_8274)
static void C_fcall trf_8274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8274(t0,t1);}

C_noret_decl(trf_8238)
static void C_fcall trf_8238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8238(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8238(t0,t1);}

C_noret_decl(trf_8203)
static void C_fcall trf_8203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8203(t0,t1);}

C_noret_decl(trf_8155)
static void C_fcall trf_8155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8155(t0,t1);}

C_noret_decl(trf_8107)
static void C_fcall trf_8107(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8107(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8107(t0,t1);}

C_noret_decl(trf_8059)
static void C_fcall trf_8059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8059(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8059(t0,t1);}

C_noret_decl(trf_8024)
static void C_fcall trf_8024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8024(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8024(t0,t1);}

C_noret_decl(trf_7988)
static void C_fcall trf_7988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7988(t0,t1);}

C_noret_decl(trf_7952)
static void C_fcall trf_7952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7952(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7952(t0,t1);}

C_noret_decl(trf_7930)
static void C_fcall trf_7930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7930(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7930(t0,t1);}

C_noret_decl(trf_7925)
static void C_fcall trf_7925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7925(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7925(t0,t1);}

C_noret_decl(trf_7920)
static void C_fcall trf_7920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7920(t0,t1);}

C_noret_decl(trf_7731)
static void C_fcall trf_7731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7731(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7731(t0,t1);}

C_noret_decl(trf_6926)
static void C_fcall trf_6926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6926(t0,t1);}

C_noret_decl(trf_6953)
static void C_fcall trf_6953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6953(t0,t1);}

C_noret_decl(trf_7148)
static void C_fcall trf_7148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7148(t0,t1);}

C_noret_decl(trf_7157)
static void C_fcall trf_7157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7157(t0,t1);}

C_noret_decl(trf_7554)
static void C_fcall trf_7554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7554(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7554(t0,t1);}

C_noret_decl(trf_7521)
static void C_fcall trf_7521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7521(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7521(t0,t1);}

C_noret_decl(trf_7489)
static void C_fcall trf_7489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7489(t0,t1);}

C_noret_decl(trf_7454)
static void C_fcall trf_7454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7454(t0,t1);}

C_noret_decl(trf_7384)
static void C_fcall trf_7384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7384(t0,t1);}

C_noret_decl(trf_7339)
static void C_fcall trf_7339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7339(t0,t1);}

C_noret_decl(trf_7307)
static void C_fcall trf_7307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7307(t0,t1);}

C_noret_decl(trf_7275)
static void C_fcall trf_7275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7275(t0,t1);}

C_noret_decl(trf_7243)
static void C_fcall trf_7243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7243(t0,t1);}

C_noret_decl(trf_7211)
static void C_fcall trf_7211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7211(t0,t1);}

C_noret_decl(trf_7189)
static void C_fcall trf_7189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7189(t0,t1);}

C_noret_decl(trf_6898)
static void C_fcall trf_6898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6898(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6898(t0,t1);}

C_noret_decl(trf_5756)
static void C_fcall trf_5756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5756(t0,t1);}

C_noret_decl(trf_5858)
static void C_fcall trf_5858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5858(t0,t1);}

C_noret_decl(trf_5891)
static void C_fcall trf_5891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5891(t0,t1);}

C_noret_decl(trf_5987)
static void C_fcall trf_5987(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5987(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5987(t0,t1);}

C_noret_decl(trf_6619)
static void C_fcall trf_6619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6619(t0,t1);}

C_noret_decl(trf_6639)
static void C_fcall trf_6639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6639(t0,t1);}

C_noret_decl(trf_6573)
static void C_fcall trf_6573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6573(t0,t1);}

C_noret_decl(trf_6523)
static void C_fcall trf_6523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6523(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6523(t0,t1);}

C_noret_decl(trf_6473)
static void C_fcall trf_6473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6473(t0,t1);}

C_noret_decl(trf_6434)
static void C_fcall trf_6434(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6434(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6434(t0,t1);}

C_noret_decl(trf_6395)
static void C_fcall trf_6395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6395(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6395(t0,t1);}

C_noret_decl(trf_6356)
static void C_fcall trf_6356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6356(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6356(t0,t1);}

C_noret_decl(trf_6317)
static void C_fcall trf_6317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6317(t0,t1);}

C_noret_decl(trf_6257)
static void C_fcall trf_6257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6257(t0,t1);}

C_noret_decl(trf_6218)
static void C_fcall trf_6218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6218(t0,t1);}

C_noret_decl(trf_6182)
static void C_fcall trf_6182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6182(t0,t1);}

C_noret_decl(trf_6146)
static void C_fcall trf_6146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6146(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6146(t0,t1);}

C_noret_decl(trf_6110)
static void C_fcall trf_6110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6110(t0,t1);}

C_noret_decl(trf_6074)
static void C_fcall trf_6074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6074(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6074(t0,t1);}

C_noret_decl(trf_6048)
static void C_fcall trf_6048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6048(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6048(t0,t1,t2);}

C_noret_decl(trf_6039)
static void C_fcall trf_6039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6039(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6039(t0,t1,t2);}

C_noret_decl(trf_6034)
static void C_fcall trf_6034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6034(t0,t1);}

C_noret_decl(trf_5686)
static void C_fcall trf_5686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5686(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5686(t0,t1,t2);}

C_noret_decl(trf_5681)
static void C_fcall trf_5681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5681(t0,t1);}

C_noret_decl(trf_5220)
static void C_fcall trf_5220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5220(t0,t1);}

C_noret_decl(trf_5229)
static void C_fcall trf_5229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5229(t0,t1);}

C_noret_decl(trf_5241)
static void C_fcall trf_5241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5241(t0,t1);}

C_noret_decl(trf_5253)
static void C_fcall trf_5253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5253(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5253(t0,t1);}

C_noret_decl(trf_5293)
static void C_fcall trf_5293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5293(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5293(t0,t1);}

C_noret_decl(trf_4897)
static void C_fcall trf_4897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4897(t0,t1);}

C_noret_decl(trf_4769)
static void C_fcall trf_4769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4769(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4769(t0,t1,t2);}

C_noret_decl(trf_4798)
static void C_fcall trf_4798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4798(t0,t1);}

C_noret_decl(trf_4801)
static void C_fcall trf_4801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4801(t0,t1);}

C_noret_decl(trf_4785)
static void C_fcall trf_4785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4785(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4785(t0,t1);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4705(t0,t1,t2);}

C_noret_decl(trf_3907)
static void C_fcall trf_3907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3907(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3907(t0,t1);}

C_noret_decl(trf_3935)
static void C_fcall trf_3935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3935(t0,t1);}

C_noret_decl(trf_4553)
static void C_fcall trf_4553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4553(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4553(t0,t1);}

C_noret_decl(trf_4001)
static void C_fcall trf_4001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4001(t0,t1);}

C_noret_decl(trf_4515)
static void C_fcall trf_4515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4515(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4515(t0,t1,t2,t3);}

C_noret_decl(trf_4458)
static void C_fcall trf_4458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4458(t0,t1);}

C_noret_decl(trf_4479)
static void C_fcall trf_4479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4479(t0,t1);}

C_noret_decl(trf_4422)
static void C_fcall trf_4422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4422(t0,t1);}

C_noret_decl(trf_4389)
static void C_fcall trf_4389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4389(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4389(t0,t1);}

C_noret_decl(trf_4398)
static void C_fcall trf_4398(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4398(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4398(t0,t1);}

C_noret_decl(trf_4343)
static void C_fcall trf_4343(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4343(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4343(t0,t1);}

C_noret_decl(trf_4033)
static void C_fcall trf_4033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4033(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4033(t0,t1);}

C_noret_decl(trf_4093)
static void C_fcall trf_4093(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4093(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4093(t0,t1,t2,t3);}

C_noret_decl(trf_3645)
static void C_fcall trf_3645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3645(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3645(t0,t1,t2,t3);}

C_noret_decl(trf_3474)
static void C_fcall trf_3474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3474(t0,t1);}

C_noret_decl(trf_3480)
static void C_fcall trf_3480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3480(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3480(t0,t1,t2,t3);}

C_noret_decl(trf_3676)
static void C_fcall trf_3676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3676(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3676(t0,t1,t2,t3);}

C_noret_decl(trf_3683)
static void C_fcall trf_3683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3683(t0,t1);}

C_noret_decl(trf_3772)
static void C_fcall trf_3772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3772(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3772(t0,t1);}

C_noret_decl(trf_3511)
static void C_fcall trf_3511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3511(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3511(t0,t1);}

C_noret_decl(trf_3818)
static void C_fcall trf_3818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3818(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3818(t0,t1,t2);}

C_noret_decl(trf_3833)
static void C_fcall trf_3833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3833(t0,t1,t2,t3);}

C_noret_decl(trf_3849)
static void C_fcall trf_3849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3849(t0,t1);}

C_noret_decl(trf_3895)
static void C_fcall trf_3895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3895(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3895(t0,t1,t2,t3);}

C_noret_decl(trf_3188)
static void C_fcall trf_3188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3188(t0,t1);}

C_noret_decl(trf_3374)
static void C_fcall trf_3374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3374(t0,t1);}

C_noret_decl(trf_3377)
static void C_fcall trf_3377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3377(t0,t1);}

C_noret_decl(trf_3423)
static void C_fcall trf_3423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3423(t0,t1);}

C_noret_decl(trf_3227)
static void C_fcall trf_3227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3227(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3227(t0,t1,t2);}

C_noret_decl(trf_3191)
static void C_fcall trf_3191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3191(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3191(t0,t1);}

C_noret_decl(trf_3204)
static void C_fcall trf_3204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3204(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3204(t0,t1,t2,t3);}

C_noret_decl(trf_2937)
static void C_fcall trf_2937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2937(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2937(t0,t1);}

C_noret_decl(trf_2975)
static void C_fcall trf_2975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2975(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2975(t0,t1);}

C_noret_decl(trf_2996)
static void C_fcall trf_2996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2996(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2996(t0,t1);}

C_noret_decl(trf_3061)
static void C_fcall trf_3061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3061(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3061(t0,t1);}

C_noret_decl(trf_2788)
static void C_fcall trf_2788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2788(t0,t1);}

C_noret_decl(trf_2809)
static void C_fcall trf_2809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2809(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2809(t0,t1,t2,t3);}

C_noret_decl(trf_2878)
static void C_fcall trf_2878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2878(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2878(t0,t1,t2);}

C_noret_decl(trf_2851)
static void C_fcall trf_2851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2851(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2851(t0,t1,t2);}

C_noret_decl(trf_2622)
static void C_fcall trf_2622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2622(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2622(t0,t1);}

C_noret_decl(trf_2648)
static void C_fcall trf_2648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2648(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2648(t0,t1);}

C_noret_decl(trf_2625)
static void C_fcall trf_2625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2625(t0,t1);}

C_noret_decl(trf_1195)
static void C_fcall trf_1195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1195(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1195(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2590)
static void C_fcall trf_2590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2590(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2590(t0,t1,t2,t3);}

C_noret_decl(trf_1198)
static void C_fcall trf_1198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1198(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1198(t0,t1,t2,t3);}

C_noret_decl(trf_2491)
static void C_fcall trf_2491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2491(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2491(t0,t1,t2,t3);}

C_noret_decl(trf_1842)
static void C_fcall trf_1842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1842(t0,t1);}

C_noret_decl(trf_1848)
static void C_fcall trf_1848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1848(t0,t1);}

C_noret_decl(trf_1999)
static void C_fcall trf_1999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1999(t0,t1);}

C_noret_decl(trf_1380)
static void C_fcall trf_1380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1380(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1380(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1153)
static void C_fcall trf_1153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1153(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1153(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2336)){
C_save(t1);
C_rereclaim2(2336*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,814);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],15,"\010compileroutput");
lf[2]=C_h_intern(&lf[2],12,"\010compilergen");
lf[3]=C_h_intern(&lf[3],7,"newline");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],17,"\010compilergen-list");
lf[7]=C_h_intern(&lf[7],11,"intersperse");
lf[8]=C_h_intern(&lf[8],18,"\010compilerunique-id");
lf[9]=C_h_intern(&lf[9],22,"\010compilergenerate-code");
lf[10]=C_h_intern(&lf[10],13,"\010compilerbomb");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[12]=C_h_intern(&lf[12],17,"lambda-literal-id");
lf[13]=C_h_intern(&lf[13],4,"find");
lf[14]=C_h_intern(&lf[14],14,"\004coreimmediate");
lf[15]=C_h_intern(&lf[15],4,"bool");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[18]=C_h_intern(&lf[18],4,"char");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[20]=C_h_intern(&lf[20],3,"nil");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[22]=C_h_intern(&lf[22],3,"fix");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[24]=C_h_intern(&lf[24],3,"eof");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[27]=C_h_intern(&lf[27],12,"\004coreliteral");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[31]=C_h_intern(&lf[31],2,"if");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[35]=C_h_intern(&lf[35],9,"\004coreproc");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[37]=C_h_intern(&lf[37],9,"\004corebind");
lf[38]=C_h_intern(&lf[38],8,"\004coreref");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[41]=C_h_intern(&lf[41],10,"\004coreunbox");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[44]=C_h_intern(&lf[44],13,"\004coreupdate_i");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[46]=C_h_intern(&lf[46],11,"\004coreupdate");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[50]=C_h_intern(&lf[50],16,"\004coreupdatebox_i");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[53]=C_h_intern(&lf[53],14,"\004coreupdatebox");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[56]=C_h_intern(&lf[56],12,"\004coreclosure");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[61]=C_h_intern(&lf[61],8,"for-each");
lf[62]=C_h_intern(&lf[62],4,"iota");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[64]=C_h_intern(&lf[64],8,"\004corebox");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[67]=C_h_intern(&lf[67],10,"\004corelocal");
lf[68]=C_h_intern(&lf[68],13,"\004coresetlocal");
lf[69]=C_h_intern(&lf[69],11,"\004coreglobal");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[74]=C_h_intern(&lf[74],21,"\010compilerc-ify-string");
lf[75]=C_h_intern(&lf[75],14,"symbol->string");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[80]=C_h_intern(&lf[80],14,"\004coresetglobal");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1,");
lf[85]=C_h_intern(&lf[85],16,"\004coresetglobal_i");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\004],0,");
lf[90]=C_h_intern(&lf[90],14,"\004coreundefined");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[92]=C_h_intern(&lf[92],9,"\004corecall");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[98]=C_h_intern(&lf[98],26,"lambda-literal-temporaries");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_h_intern(&lf[100],22,"lambda-literal-looping");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[104]=C_h_intern(&lf[104],6,"unsafe");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[109]=C_h_intern(&lf[109],19,"no-procedure-checks");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[112]=C_h_intern(&lf[112],24,"\010compileremit-trace-info");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[115]=C_h_intern(&lf[115],16,"string-translate");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[118]=C_h_intern(&lf[118],8,"->string");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[121]=C_h_intern(&lf[121],17,"string-translate*");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[123]=C_h_intern(&lf[123],27,"lambda-literal-closure-size");
lf[124]=C_h_intern(&lf[124],28,"\010compilersource-info->string");
lf[125]=C_h_intern(&lf[125],12,"\004corerecurse");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[129]=C_h_intern(&lf[129],16,"\004coredirect_call");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[131]=C_h_intern(&lf[131],13,"\004corecallunit");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[136]=C_h_intern(&lf[136],11,"\004corereturn");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[139]=C_h_intern(&lf[139],11,"\004coreinline");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[141]=C_h_intern(&lf[141],20,"\004coreinline_allocate");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[144]=C_h_intern(&lf[144],15,"\004coreinline_ref");
lf[145]=C_h_intern(&lf[145],34,"\010compilerforeign-result-conversion");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[147]=C_h_intern(&lf[147],18,"\004coreinline_update");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[150]=C_h_intern(&lf[150],36,"\010compilerforeign-argument-conversion");
lf[151]=C_h_intern(&lf[151],33,"\010compilerforeign-type-declaration");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_h_intern(&lf[153],19,"\004coreinline_loc_ref");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[159]=C_h_intern(&lf[159],22,"\004coreinline_loc_update");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_h_intern(&lf[165],11,"\004coreswitch");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[170]=C_h_intern(&lf[170],9,"\004corecond");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[174]=C_h_intern(&lf[174],13,"pair-for-each");
lf[175]=C_h_intern(&lf[175],13,"string-append");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[177]=C_h_intern(&lf[177],30,"\010compilerexternal-protos-first");
lf[178]=C_h_intern(&lf[178],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[179]=C_h_intern(&lf[179],22,"foreign-callback-stubs");
lf[180]=C_h_intern(&lf[180],29,"\010compilerforeign-declarations");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[183]=C_h_intern(&lf[183],28,"\010compilertarget-include-file");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[185]=C_h_intern(&lf[185],18,"\010compilerunit-name");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[187]=C_h_intern(&lf[187],19,"\010compilerused-units");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[189]=C_h_intern(&lf[189],27,"\010compilercompiler-arguments");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[195]=C_h_intern(&lf[195],18,"string-intersperse");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[199]=C_h_intern(&lf[199],7,"\003sysmap");
lf[200]=C_h_intern(&lf[200],12,"string-split");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[202]=C_h_intern(&lf[202],15,"chicken-version");
lf[203]=C_h_intern(&lf[203],15,"\003sysmatch-error");
lf[204]=C_h_intern(&lf[204],18,"\003sysdecode-seconds");
lf[205]=C_h_intern(&lf[205],15,"current-seconds");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[210]=C_h_intern(&lf[210],23,"\003syslambda-info->string");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[220]=C_h_intern(&lf[220],9,"make-list");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[224]=C_h_intern(&lf[224],4,"none");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[235]=C_h_intern(&lf[235],8,"toplevel");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[238]=C_h_intern(&lf[238],27,"\010compileremit-unsafe-marker");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[251]=C_h_intern(&lf[251],21,"small-parameter-limit");
lf[252]=C_h_intern(&lf[252],11,"lset-adjoin");
lf[253]=C_h_intern(&lf[253],1,"=");
lf[254]=C_h_intern(&lf[254],32,"lambda-literal-callee-signatures");
lf[255]=C_h_intern(&lf[255],24,"lambda-literal-allocated");
lf[256]=C_h_intern(&lf[256],21,"lambda-literal-direct");
lf[257]=C_h_intern(&lf[257],33,"lambda-literal-rest-argument-mode");
lf[258]=C_h_intern(&lf[258],28,"lambda-literal-rest-argument");
lf[259]=C_h_intern(&lf[259],27,"\010compilermake-variable-list");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[261]=C_h_intern(&lf[261],27,"lambda-literal-customizable");
lf[262]=C_h_intern(&lf[262],29,"lambda-literal-argument-count");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[269]=C_h_intern(&lf[269],27,"\010compilermake-argument-list");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[309]=C_h_intern(&lf[309],6,"vector");
lf[310]=C_h_intern(&lf[310],23,"lambda-literal-external");
lf[311]=C_h_intern(&lf[311],14,"\003syscopy-bytes");
lf[312]=C_h_intern(&lf[312],11,"make-string");
lf[313]=C_h_intern(&lf[313],6,"modulo");
lf[314]=C_h_intern(&lf[314],3,"fx/");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[328]=C_h_intern(&lf[328],23,"\010compilerencode-literal");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[330]=C_h_intern(&lf[330],32,"\010compilerblock-variable-literal\077");
lf[331]=C_h_intern(&lf[331],20,"\010compilerbig-fixnum\077");
lf[332]=C_h_intern(&lf[332],7,"sprintf");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[334]=C_h_intern(&lf[334],25,"\010compilerwords-per-flonum");
lf[335]=C_h_intern(&lf[335],6,"reduce");
lf[336]=C_h_intern(&lf[336],1,"+");
lf[337]=C_h_intern(&lf[337],12,"vector->list");
lf[338]=C_h_intern(&lf[338],14,"\010compilerwords");
lf[339]=C_h_intern(&lf[339],15,"\003sysbytevector\077");
lf[340]=C_h_intern(&lf[340],19,"\010compilerimmediate\077");
lf[341]=C_h_intern(&lf[341],19,"lambda-literal-body");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[354]=C_h_intern(&lf[354],4,"list");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[393]=C_h_intern(&lf[393],26,"\010compilertarget-stack-size");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[396]=C_h_intern(&lf[396],30,"\010compilertarget-heap-shrinkage");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[398]=C_h_intern(&lf[398],27,"\010compilertarget-heap-growth");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[400]=C_h_intern(&lf[400],33,"\010compilertarget-initial-heap-size");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[403]=C_h_intern(&lf[403],25,"\010compilertarget-heap-size");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[407]=C_h_intern(&lf[407],40,"\010compilerdisable-stack-overflow-checking");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[413]=C_h_intern(&lf[413],4,"fold");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[416]=C_h_intern(&lf[416],28,"\010compilerinsert-timer-checks");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[421]=C_h_intern(&lf[421],14,"no-argc-checks");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[468]=C_h_intern(&lf[468],16,"\010compilercleanup");
lf[469]=C_h_intern(&lf[469],18,"\010compilerdebugging");
lf[470]=C_h_intern(&lf[470],1,"o");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[476]=C_h_intern(&lf[476],18,"\010compilerreal-name");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[478]=C_h_intern(&lf[478],25,"emit-procedure-table-info");
lf[479]=C_h_intern(&lf[479],31,"generate-foreign-callback-stubs");
lf[480]=C_h_intern(&lf[480],31,"\010compilergenerate-foreign-stubs");
lf[481]=C_h_intern(&lf[481],29,"\010compilerforeign-lambda-stubs");
lf[482]=C_h_intern(&lf[482],36,"\010compilergenerate-external-variables");
lf[483]=C_h_intern(&lf[483],27,"\010compilerexternal-variables");
lf[484]=C_h_intern(&lf[484],1,"p");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[505]=C_h_intern(&lf[505],11,"string-copy");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[507]=C_h_intern(&lf[507],13,"list-tabulate");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[510]=C_h_intern(&lf[510],41,"\010compilergenerate-foreign-callback-header");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[523]=C_h_intern(&lf[523],4,"void");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[548]=C_h_intern(&lf[548],21,"foreign-stub-callback");
lf[549]=C_h_intern(&lf[549],16,"foreign-stub-cps");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_h_intern(&lf[551],27,"foreign-stub-argument-names");
lf[552]=C_h_intern(&lf[552],17,"foreign-stub-body");
lf[553]=C_h_intern(&lf[553],17,"foreign-stub-name");
lf[554]=C_h_intern(&lf[554],24,"foreign-stub-return-type");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[557]=C_h_intern(&lf[557],27,"foreign-stub-argument-types");
lf[558]=C_h_intern(&lf[558],19,"\010compilerreal-name2");
lf[559]=C_h_intern(&lf[559],15,"foreign-stub-id");
lf[560]=C_h_intern(&lf[560],5,"float");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[562]=C_h_intern(&lf[562],8,"c-string");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[566]=C_h_intern(&lf[566],16,"nonnull-c-string");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[569]=C_h_intern(&lf[569],3,"ref");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[571]=C_h_intern(&lf[571],5,"const");
lf[572]=C_h_intern(&lf[572],7,"pointer");
lf[573]=C_h_intern(&lf[573],9,"c-pointer");
lf[574]=C_h_intern(&lf[574],15,"nonnull-pointer");
lf[575]=C_h_intern(&lf[575],17,"nonnull-c-pointer");
lf[576]=C_h_intern(&lf[576],8,"function");
lf[577]=C_h_intern(&lf[577],8,"instance");
lf[578]=C_h_intern(&lf[578],16,"nonnull-instance");
lf[579]=C_h_intern(&lf[579],12,"instance-ref");
lf[580]=C_h_intern(&lf[580],18,"\003syshash-table-ref");
lf[581]=C_h_intern(&lf[581],27,"\010compilerforeign-type-table");
lf[582]=C_h_intern(&lf[582],17,"nonnull-c-string*");
lf[583]=C_h_intern(&lf[583],25,"nonnull-unsigned-c-string");
lf[584]=C_h_intern(&lf[584],26,"nonnull-unsigned-c-string*");
lf[585]=C_h_intern(&lf[585],6,"symbol");
lf[586]=C_h_intern(&lf[586],9,"c-string*");
lf[587]=C_h_intern(&lf[587],17,"unsigned-c-string");
lf[588]=C_h_intern(&lf[588],18,"unsigned-c-string*");
lf[589]=C_h_intern(&lf[589],6,"double");
lf[590]=C_h_intern(&lf[590],16,"unsigned-integer");
lf[591]=C_h_intern(&lf[591],18,"unsigned-integer32");
lf[592]=C_h_intern(&lf[592],4,"long");
lf[593]=C_h_intern(&lf[593],7,"integer");
lf[594]=C_h_intern(&lf[594],9,"integer32");
lf[595]=C_h_intern(&lf[595],13,"unsigned-long");
lf[596]=C_h_intern(&lf[596],6,"number");
lf[597]=C_h_intern(&lf[597],9,"integer64");
lf[598]=C_h_intern(&lf[598],13,"c-string-list");
lf[599]=C_h_intern(&lf[599],14,"c-string-list*");
lf[600]=C_h_intern(&lf[600],3,"int");
lf[601]=C_h_intern(&lf[601],5,"int32");
lf[602]=C_h_intern(&lf[602],5,"short");
lf[603]=C_h_intern(&lf[603],14,"unsigned-short");
lf[604]=C_h_intern(&lf[604],13,"scheme-object");
lf[605]=C_h_intern(&lf[605],13,"unsigned-char");
lf[606]=C_h_intern(&lf[606],12,"unsigned-int");
lf[607]=C_h_intern(&lf[607],14,"unsigned-int32");
lf[608]=C_h_intern(&lf[608],4,"byte");
lf[609]=C_h_intern(&lf[609],13,"unsigned-byte");
lf[610]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[611]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[612]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[613]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[614]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[625]=C_h_intern(&lf[625],36,"foreign-callback-stub-argument-types");
lf[626]=C_h_intern(&lf[626],33,"foreign-callback-stub-return-type");
lf[627]=C_h_intern(&lf[627],24,"foreign-callback-stub-id");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[630]=C_h_intern(&lf[630],32,"foreign-callback-stub-qualifiers");
lf[631]=C_h_intern(&lf[631],26,"foreign-callback-stub-name");
lf[632]=C_h_intern(&lf[632],4,"quit");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[652]=C_h_intern(&lf[652],11,"byte-vector");
lf[653]=C_h_intern(&lf[653],19,"nonnull-byte-vector");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[655]=C_h_intern(&lf[655],4,"blob");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[657]=C_h_intern(&lf[657],9,"u16vector");
lf[658]=C_h_intern(&lf[658],17,"nonnull-u16vector");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[660]=C_h_intern(&lf[660],8,"s8vector");
lf[661]=C_h_intern(&lf[661],16,"nonnull-s8vector");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[663]=C_h_intern(&lf[663],9,"u32vector");
lf[664]=C_h_intern(&lf[664],17,"nonnull-u32vector");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[666]=C_h_intern(&lf[666],9,"s16vector");
lf[667]=C_h_intern(&lf[667],17,"nonnull-s16vector");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[669]=C_h_intern(&lf[669],9,"s32vector");
lf[670]=C_h_intern(&lf[670],17,"nonnull-s32vector");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[672]=C_h_intern(&lf[672],9,"f32vector");
lf[673]=C_h_intern(&lf[673],17,"nonnull-f32vector");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[675]=C_h_intern(&lf[675],9,"f64vector");
lf[676]=C_h_intern(&lf[676],17,"nonnull-f64vector");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[683]=C_h_intern(&lf[683],8,"template");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[690]=C_h_intern(&lf[690],6,"struct");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[693]=C_h_intern(&lf[693],5,"union");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[696]=C_h_intern(&lf[696],4,"enum");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[705]=C_h_intern(&lf[705],3,"...");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_h_intern(&lf[709],12,"nonnull-blob");
lf[710]=C_h_intern(&lf[710],8,"u8vector");
lf[711]=C_h_intern(&lf[711],16,"nonnull-u8vector");
lf[712]=C_h_intern(&lf[712],14,"scheme-pointer");
lf[713]=C_h_intern(&lf[713],22,"nonnull-scheme-pointer");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[808]=C_h_intern(&lf[808],17,"\003sysstring-append");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[810]=C_h_intern(&lf[810],5,"cons*");
lf[811]=C_h_intern(&lf[811],29,"\010compilerstring->c-identifier");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[813]=C_h_intern(&lf[813],6,"random");
C_register_lf2(lf,814,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1091,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1089 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1094,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1092 in k1089 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1097,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1095 in k1092 in k1089 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_set_block_item(lf[1],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1109,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1130,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8803,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8807,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 100  random */
t9=C_retrieve(lf[813]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_fix(16777216));}

/* k8805 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8811,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 100  current-seconds */
t3=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8809 in k8805 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 100  sprintf */
t2=C_retrieve(lf[332]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[812],((C_word*)t0)[2],t1);}

/* k8801 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 99   string->c-identifier */
t2=C_retrieve(lf[811]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1148,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1150,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4687,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[468]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4760,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[259]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4849,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4865,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[482]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4881,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4932,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[480]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4950,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[479]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5183,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[510]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5614,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5679,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6896,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7729,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8503,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[51],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8503,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8506,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8509,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8512,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8565,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t7)){
t8=t6;
f_8565(2,t8,lf[795]);}
else{
t8=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t8)){
t9=t6;
f_8565(2,t9,lf[796]);}
else{
if(C_truep((C_word)C_charp(t2))){
t9=(C_word)C_fix((C_word)C_character_code(t2));
t10=f_8512(C_a_i(&a,4),t9);
/* c-backend.scm: 1355 string-append */
t11=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[797],t10);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t9=t6;
f_8565(2,t9,lf[798]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t9=t6;
f_8565(2,t9,lf[799]);}
else{
t9=C_retrieve(lf[0]);
t10=(C_word)C_eqp(t9,t2);
if(C_truep(t10)){
t11=t6;
f_8565(2,t11,lf[800]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8683,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1360 big-fixnum? */
t12=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8696,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1369 number->string */
C_number_to_string(3,0,t11,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t11=(C_word)C_slot(t2,C_fix(1));
t12=(C_word)C_i_string_length(t11);
t13=f_8512(C_a_i(&a,4),t12);
/* c-backend.scm: 1372 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t6,lf[806],t13,t11);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1377 bomb */
t11=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[807],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8735,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t12=f_8506(t2);
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_string(&a,1,t13);
t15=f_8509(t2);
t16=f_8512(C_a_i(&a,4),t15);
/* c-backend.scm: 1380 string-append */
t17=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,t11,t14,t16);}
else{
t11=f_8509(t2);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8765,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=f_8506(t2);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8512(C_a_i(&a,4),t11);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8777,a[2]=t16,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8779,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1390 list-tabulate */
t19=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t11,t18);}}}}}}}}}}}}

/* a8778 in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8779,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1390 encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k8775 in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1387 cons* */
t2=C_retrieve(lf[810]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8763 in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1386 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[809]);}

/* k8733 in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1379 ##sys#string-append */
t2=C_retrieve(lf[808]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8694 in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1369 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[804],t1,lf[805]);}

/* k8681 in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8683,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1367 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1361 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[3],lf[803],t13);}}

/* k8677 in k8681 in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1367 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[801],t1,lf[802]);}

/* k8563 in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_8565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8565,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1351 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static C_word C_fcall f_8512(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* getsize in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static C_word C_fcall f_8509(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1050(C_SCHEME_UNDEFINED,t1));}

/* getbits in ##compiler#encode-literal in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static C_word C_fcall f_8506(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1046(C_SCHEME_UNDEFINED,t1));}

/* ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_7729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7729,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7731,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[769]);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[601]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[770]);}
else{
t10=(C_word)C_eqp(t5,lf[606]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[607]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[771]);}
else{
t12=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[772]);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[773]);}
else{
t14=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[774]);}
else{
t15=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[775]);}
else{
t16=(C_word)C_eqp(t5,lf[560]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[589]));
if(C_truep(t17)){
/* c-backend.scm: 1289 sprintf */
t18=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[776],t3);}
else{
t18=(C_word)C_eqp(t5,lf[596]);
if(C_truep(t18)){
/* c-backend.scm: 1290 sprintf */
t19=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[777],t3);}
else{
t19=(C_word)C_eqp(t5,lf[566]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7816,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_7816(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[562]);
if(C_truep(t21)){
t22=t20;
f_7816(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[575]);
if(C_truep(t22)){
t23=t20;
f_7816(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[586]);
if(C_truep(t23)){
t24=t20;
f_7816(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[582]);
if(C_truep(t24)){
t25=t20;
f_7816(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[587]);
if(C_truep(t25)){
t26=t20;
f_7816(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t26)){
t27=t20;
f_7816(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[583]);
if(C_truep(t27)){
t28=t20;
f_7816(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t28)){
t29=t20;
f_7816(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[585]);
if(C_truep(t29)){
t30=t20;
f_7816(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[598]);
t31=t20;
f_7816(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[599])));}}}}}}}}}}}}}}}}}}}}

/* k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7816(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7816,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1294 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[778],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t2)){
/* c-backend.scm: 1295 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[779],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t4)){
/* c-backend.scm: 1296 sprintf */
t5=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[780],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t5)){
/* c-backend.scm: 1297 sprintf */
t6=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[781],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
/* c-backend.scm: 1298 sprintf */
t8=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[782],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t8)){
/* c-backend.scm: 1299 sprintf */
t9=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[783],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t9)){
/* c-backend.scm: 1300 sprintf */
t10=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[784],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[785]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[523]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[604]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[786]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1304 ##sys#hash-table-ref */
t14=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t14=t13;
f_7897(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_7897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7897,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1306 foreign-result-conversion */
t4=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7925,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7930,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7952,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7952(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7952(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[575]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7988,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7988(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7988(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[569]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8024,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_8024(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_8024(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8059,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_8059(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_8059(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_8059(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8107,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_8107(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_8107(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_8107(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[579]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8155,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t21=t17;
f_8155(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_8155(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_8155(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8203,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_8203(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_8203(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[572]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8238,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_8238(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_8238(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[573]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8274,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_8274(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_8274(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[3]);
t24=(C_word)C_eqp(t23,lf[576]);
if(C_truep(t24)){
t25=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=(C_word)C_i_cadr(((C_word*)t0)[3]);
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* c-backend.scm: 1308 sprintf */
t28=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t28))(4,t28,((C_word*)t0)[5],lf[793],((C_word*)t0)[4]);}
else{
/* c-backend.scm: 1308 g1021 */
t26=t2;
f_7920(t26,((C_word*)t0)[5]);}}
else{
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8332,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(((C_word*)t0)[3]);
t27=(C_word)C_eqp(t26,lf[696]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[3]);
t30=t25;
f_8332(t30,(C_word)C_i_nullp(t29));}
else{
t29=t25;
f_8332(t29,C_SCHEME_FALSE);}}
else{
t28=t25;
f_8332(t28,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1308 g1021 */
t5=t2;
f_7920(t5,((C_word*)t0)[5]);}}
else{
/* c-backend.scm: 1325 err */
t2=((C_word*)t0)[2];
f_7731(t2,((C_word*)t0)[5]);}}}

/* k8330 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_8332(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[794],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[4]);}}

/* k8272 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_8274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1018 */
t3=((C_word*)t0)[4];
f_7925(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[3]);}}

/* k8236 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_8238(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1018 */
t3=((C_word*)t0)[4];
f_7925(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[3]);}}

/* k8201 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_8203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[4]);}}

/* k8153 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_8155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[792],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[4]);}}

/* k8105 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_8107(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[791],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[4]);}}

/* k8057 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_8059(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[790],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[4]);}}

/* k8022 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_8024(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1312 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[789],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[4]);}}

/* k7986 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1012 */
t3=((C_word*)t0)[4];
f_7930(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[3]);}}

/* k7950 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7952(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1012 */
t3=((C_word*)t0)[4];
f_7930(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7920(t2,((C_word*)t0)[3]);}}

/* g1012 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7930(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7930,NULL,2,t0,t1);}
/* c-backend.scm: 1310 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[788],((C_word*)t0)[2]);}

/* g1018 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7925(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7925,NULL,2,t0,t1);}
/* c-backend.scm: 1321 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[787],((C_word*)t0)[2]);}

/* g1021 in k7895 in k7814 in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7920,NULL,2,t0,t1);}
/* c-backend.scm: 1324 err */
t2=((C_word*)t0)[2];
f_7731(t2,t1);}

/* err in ##compiler#foreign-result-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7731(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7731,NULL,2,t0,t1);}
/* c-backend.scm: 1280 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[768],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6896,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6898,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[604]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[715]);}
else{
t6=(C_word)C_eqp(t4,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[716]);}
else{
t8=(C_word)C_eqp(t4,lf[608]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6926,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_6926(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[600]);
if(C_truep(t10)){
t11=t9;
f_6926(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[606]);
if(C_truep(t11)){
t12=t9;
f_6926(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[607]);
t13=t9;
f_6926(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[609])));}}}}}}

/* k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6926,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[717]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[718]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[603]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[719]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[720]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6953(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
t8=t6;
f_6953(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[560])));}}}}}}

/* k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6953,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[721]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[722]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[723]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[724]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[725]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[572]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[726]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[574]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[727]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[712]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[728]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[713]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[729]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[730]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[575]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[731]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[655]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[732]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[709]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[733]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[652]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[734]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[653]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[735]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[710]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[736]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[711]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[737]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[657]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[738]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[739]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[663]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[740]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[664]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[741]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[660]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[742]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[661]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[743]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[666]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[744]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[667]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[745]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[669]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[746]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[670]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[747]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[748]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[673]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[749]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[750]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[676]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[751]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[562]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_7148(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[586]);
if(C_truep(t36)){
t37=t35;
f_7148(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
t38=t35;
f_7148(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[588])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[752]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7157(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_7157(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_7157(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_7157(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7157,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[753]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[754]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1256 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7166(2,t4,C_SCHEME_FALSE);}}}}

/* k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_7166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7166,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1258 foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(t3,lf[572]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7211,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[3]);
t8=t5;
f_7211(t8,(C_word)C_i_nullp(t7));}
else{
t7=t5;
f_7211(t7,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7243,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7243(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7243(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[573]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7275,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7275(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7275(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[575]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7307,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7307(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7307(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7339,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_7339(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7339(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7339(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7384,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_7384(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_7384(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_7384(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[576]);
if(C_truep(t16)){
t17=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cadr(((C_word*)t0)[3]);
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
t20=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[761]);}
else{
/* c-backend.scm: 1260 g948 */
t18=t2;
f_7189(t18,((C_word*)t0)[4]);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7454,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_7454(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_7454(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[696]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7489,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_7489(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_7489(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[569]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7521,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_7521(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_7521(t25,C_SCHEME_FALSE);}}
else{
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7554,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_car(((C_word*)t0)[3]);
t25=(C_word)C_eqp(t24,lf[579]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t29=t23;
f_7554(t29,(C_word)C_i_nullp(t28));}
else{
t28=t23;
f_7554(t28,C_SCHEME_FALSE);}}
else{
t27=t23;
f_7554(t27,C_SCHEME_FALSE);}}
else{
t26=t23;
f_7554(t26,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1260 g948 */
t3=t2;
f_7189(t3,((C_word*)t0)[4]);}}
else{
/* c-backend.scm: 1274 err */
t2=((C_word*)t0)[2];
f_6898(t2,((C_word*)t0)[4]);}}}

/* k7552 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7554(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 1260 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],lf[766],t2,lf[767]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7519 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7521(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7521,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7531,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1260 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[765]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7529 in k7519 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_7531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1260 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[763],t1,lf[764]);}

/* k7487 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[762]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7452 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1260 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7382 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[760]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7337 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[759]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7305 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[758]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7273 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[757]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7241 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[756]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* k7209 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[755]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7189(t2,((C_word*)t0)[3]);}}

/* g948 in k7164 in k7155 in k7146 in k6951 in k6924 in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_7189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7189,NULL,2,t0,t1);}
/* c-backend.scm: 1273 err */
t2=((C_word*)t0)[2];
f_6898(t2,t1);}

/* err in ##compiler#foreign-argument-conversion in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6898(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6898,NULL,2,t0,t1);}
/* c-backend.scm: 1210 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[714],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5679,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5681,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5686,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[604]);
if(C_truep(t7)){
/* c-backend.scm: 1130 str */
t8=t5;
f_5686(t8,t1,lf[635]);}
else{
t8=(C_word)C_eqp(t6,lf[18]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[608]));
if(C_truep(t9)){
/* c-backend.scm: 1131 str */
t10=t5;
f_5686(t10,t1,lf[636]);}
else{
t10=(C_word)C_eqp(t6,lf[605]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[609]));
if(C_truep(t11)){
/* c-backend.scm: 1132 str */
t12=t5;
f_5686(t12,t1,lf[637]);}
else{
t12=(C_word)C_eqp(t6,lf[606]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[590]));
if(C_truep(t13)){
/* c-backend.scm: 1133 str */
t14=t5;
f_5686(t14,t1,lf[638]);}
else{
t14=(C_word)C_eqp(t6,lf[607]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[591]));
if(C_truep(t15)){
/* c-backend.scm: 1134 str */
t16=t5;
f_5686(t16,t1,lf[639]);}
else{
t16=(C_word)C_eqp(t6,lf[600]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5756,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5756(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[593]);
t19=t17;
f_5756(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[15])));}}}}}}}

/* k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5756,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1135 str */
t2=((C_word*)t0)[7];
f_5686(t2,((C_word*)t0)[6],lf[640]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[594]));
if(C_truep(t3)){
/* c-backend.scm: 1136 str */
t4=((C_word*)t0)[7];
f_5686(t4,((C_word*)t0)[6],lf[641]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t4)){
/* c-backend.scm: 1137 str */
t5=((C_word*)t0)[7];
f_5686(t5,((C_word*)t0)[6],lf[642]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t5)){
/* c-backend.scm: 1138 str */
t6=((C_word*)t0)[7];
f_5686(t6,((C_word*)t0)[6],lf[643]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t6)){
/* c-backend.scm: 1139 str */
t7=((C_word*)t0)[7];
f_5686(t7,((C_word*)t0)[6],lf[644]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
if(C_truep(t7)){
/* c-backend.scm: 1140 str */
t8=((C_word*)t0)[7];
f_5686(t8,((C_word*)t0)[6],lf[645]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t8)){
/* c-backend.scm: 1141 str */
t9=((C_word*)t0)[7];
f_5686(t9,((C_word*)t0)[6],lf[646]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
if(C_truep(t9)){
/* c-backend.scm: 1142 str */
t10=((C_word*)t0)[7];
f_5686(t10,((C_word*)t0)[6],lf[647]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t11)){
/* c-backend.scm: 1143 str */
t12=((C_word*)t0)[7];
f_5686(t12,((C_word*)t0)[6],lf[648]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[572]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[574]));
if(C_truep(t13)){
/* c-backend.scm: 1145 str */
t14=((C_word*)t0)[7];
f_5686(t14,((C_word*)t0)[6],lf[649]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_5858(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t16)){
t17=t15;
f_5858(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[712]);
t18=t15;
f_5858(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[713])));}}}}}}}}}}}}}

/* k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5858,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1146 str */
t2=((C_word*)t0)[7];
f_5686(t2,((C_word*)t0)[6],lf[650]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[599]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[651]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[652]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[653]));
if(C_truep(t5)){
/* c-backend.scm: 1149 str */
t6=((C_word*)t0)[7];
f_5686(t6,((C_word*)t0)[6],lf[654]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[655]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5891(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[709]);
if(C_truep(t8)){
t9=t7;
f_5891(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[710]);
t10=t7;
f_5891(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[711])));}}}}}}

/* k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5891,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1150 str */
t2=((C_word*)t0)[7];
f_5686(t2,((C_word*)t0)[6],lf[656]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[657]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[658]));
if(C_truep(t3)){
/* c-backend.scm: 1151 str */
t4=((C_word*)t0)[7];
f_5686(t4,((C_word*)t0)[6],lf[659]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[660]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[661]));
if(C_truep(t5)){
/* c-backend.scm: 1152 str */
t6=((C_word*)t0)[7];
f_5686(t6,((C_word*)t0)[6],lf[662]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[663]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[664]));
if(C_truep(t7)){
/* c-backend.scm: 1153 str */
t8=((C_word*)t0)[7];
f_5686(t8,((C_word*)t0)[6],lf[665]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[666]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[667]));
if(C_truep(t9)){
/* c-backend.scm: 1154 str */
t10=((C_word*)t0)[7];
f_5686(t10,((C_word*)t0)[6],lf[668]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[669]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[670]));
if(C_truep(t11)){
/* c-backend.scm: 1155 str */
t12=((C_word*)t0)[7];
f_5686(t12,((C_word*)t0)[6],lf[671]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[672]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[673]));
if(C_truep(t13)){
/* c-backend.scm: 1156 str */
t14=((C_word*)t0)[7];
f_5686(t14,((C_word*)t0)[6],lf[674]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[675]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[676]));
if(C_truep(t15)){
/* c-backend.scm: 1157 str */
t16=((C_word*)t0)[7];
f_5686(t16,((C_word*)t0)[6],lf[677]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[566]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5987(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
if(C_truep(t18)){
t19=t17;
f_5987(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t19)){
t20=t17;
f_5987(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t20)){
t21=t17;
f_5987(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[583]);
if(C_truep(t21)){
t22=t17;
f_5987(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t22)){
t23=t17;
f_5987(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t24=t17;
f_5987(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[585])));}}}}}}}}}}}}}}}

/* k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5987(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5987,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1160 str */
t2=((C_word*)t0)[7];
f_5686(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t2)){
/* c-backend.scm: 1161 str */
t3=((C_word*)t0)[7];
f_5686(t3,((C_word*)t0)[6],lf[679]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1163 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_6002(2,t4,C_SCHEME_FALSE);}}}}

/* k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6002,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1165 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1166 str */
t2=((C_word*)t0)[3];
f_5686(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6039,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6048,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[572]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6074,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[4]);
t10=t7;
f_6074(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_6074(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[574]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6110,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[4]);
t12=t9;
f_6110(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_6110(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[573]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6146,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[4]);
t14=t11;
f_6146(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_6146(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[575]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6182,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[4]);
t16=t13;
f_6182(t16,(C_word)C_i_nullp(t15));}
else{
t15=t13;
f_6182(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[569]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6218,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[4]);
t18=t15;
f_6218(t18,(C_word)C_i_nullp(t17));}
else{
t17=t15;
f_6218(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[683]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6257,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[4]);
t20=t17;
f_6257(t20,(C_word)C_i_listp(t19));}
else{
t19=t17;
f_6257(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6317,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[4]);
t22=t19;
f_6317(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_6317(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[690]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6356,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6356(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6356(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[693]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6395,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6395(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6395(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[696]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6434,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[4]);
t28=t25;
f_6434(t28,(C_word)C_i_nullp(t27));}
else{
t27=t25;
f_6434(t27,C_SCHEME_FALSE);}}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[577]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6473,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t29))){
t30=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t31=t27;
f_6473(t31,(C_word)C_i_nullp(t30));}
else{
t30=t27;
f_6473(t30,C_SCHEME_FALSE);}}
else{
t29=t27;
f_6473(t29,C_SCHEME_FALSE);}}
else{
t27=(C_word)C_i_car(((C_word*)t0)[4]);
t28=(C_word)C_eqp(t27,lf[578]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6523,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t30))){
t31=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t33=t29;
f_6523(t33,(C_word)C_i_nullp(t32));}
else{
t32=t29;
f_6523(t32,C_SCHEME_FALSE);}}
else{
t31=t29;
f_6523(t31,C_SCHEME_FALSE);}}
else{
t29=(C_word)C_i_car(((C_word*)t0)[4]);
t30=(C_word)C_eqp(t29,lf[579]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6573,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t32))){
t33=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t33))){
t34=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t35=t31;
f_6573(t35,(C_word)C_i_nullp(t34));}
else{
t34=t31;
f_6573(t34,C_SCHEME_FALSE);}}
else{
t33=t31;
f_6573(t33,C_SCHEME_FALSE);}}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6619,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[4]);
t33=(C_word)C_eqp(t32,lf[576]);
if(C_truep(t33)){
t34=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t34))){
t35=(C_word)C_i_cddr(((C_word*)t0)[4]);
t36=t31;
f_6619(t36,(C_word)C_i_pairp(t35));}
else{
t35=t31;
f_6619(t35,C_SCHEME_FALSE);}}
else{
t34=t31;
f_6619(t34,C_SCHEME_FALSE);}}}}}}}}}}}}}}}
else{
/* c-backend.scm: 1168 g871 */
t5=t2;
f_6034(t5,((C_word*)t0)[6]);}}
else{
/* c-backend.scm: 1204 err */
t2=((C_word*)t0)[2];
f_5681(t2,((C_word*)t0)[6]);}}}}

/* k6617 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6635,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[708]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[4]);}}

/* k6633 in k6617 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6639,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_stringp(t3);
t5=t2;
f_6639(t5,(C_truep(t4)?t3:C_SCHEME_FALSE));}
else{
t4=t2;
f_6639(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6639(t3,C_SCHEME_FALSE);}}

/* k6637 in k6633 in k6617 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6639,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[700]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6646,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6650,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6652,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6651 in k6637 in k6633 in k6617 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6652,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[705],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[706]);}
else{
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[707]);}}

/* k6648 in k6637 in k6633 in k6617 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[704]);}

/* k6644 in k6637 in k6633 in k6617 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[701],((C_word*)t0)[2],lf[702],t1,lf[703]);}

/* k6571 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6573,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t5=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[4]);}}

/* k6584 in k6571 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[699],((C_word*)t0)[2]);}

/* k6521 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g868 */
t4=((C_word*)t0)[4];
f_6039(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[3]);}}

/* k6471 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g868 */
t4=((C_word*)t0)[4];
f_6039(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[3]);}}

/* k6432 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6434(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6434,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[4]);}}

/* k6442 in k6432 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[697],t1,lf[698],((C_word*)t0)[2]);}

/* k6393 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6395(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6395,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[4]);}}

/* k6403 in k6393 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[694],t1,lf[695],((C_word*)t0)[2]);}

/* k6354 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6356(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6356,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[4]);}}

/* k6364 in k6354 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[691],t1,lf[692],((C_word*)t0)[2]);}

/* k6315 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6317,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[4]);}}

/* k6325 in k6315 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[689],t1);}

/* k6255 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6257,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6270,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6274,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[688]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[3]);}}

/* k6272 in k6255 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6278,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6282,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6284,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6283 in k6272 in k6255 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6284,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[687]);}

/* k6280 in k6272 in k6255 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[686]);}

/* k6276 in k6272 in k6255 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[684],t1,lf[685]);}

/* k6268 in k6255 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 str */
t2=((C_word*)t0)[3];
f_5686(t2,((C_word*)t0)[2],t1);}

/* k6216 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6218,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6228,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1172 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[682],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[4]);}}

/* k6226 in k6216 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1172 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6180 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6048(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[3]);}}

/* k6144 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6146(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6048(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[3]);}}

/* k6108 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6048(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[3]);}}

/* k6072 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6074(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6048(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6034(t2,((C_word*)t0)[3]);}}

/* g858 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6048(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6048,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6056,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1170 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[681],((C_word*)t0)[2]);}

/* k6054 in g858 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1170 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g868 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6039,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1184 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6045 in g868 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1184 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[680],((C_word*)t0)[2]);}

/* g871 in k6000 in k5985 in k5889 in k5856 in k5754 in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_6034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6034,NULL,2,t0,t1);}
/* c-backend.scm: 1203 err */
t2=((C_word*)t0)[2];
f_5681(t2,t1);}

/* str in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5686(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5686,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1128 string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[634],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5681,NULL,2,t0,t1);}
/* c-backend.scm: 1127 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[633],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5614,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5618,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1109 foreign-callback-stub-name */
t5=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5621,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1110 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1111 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5627,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1112 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5625 in k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5627,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1114 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[629]);}

/* k5631 in k5625 in k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1115 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[628]);}

/* k5675 in k5631 in k5625 in k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1115 gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k5634 in k5631 in k5625 in k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5644,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1116 pair-for-each */
t4=C_retrieve(lf[174]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5643 in k5634 in k5631 in k5625 in k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5644,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5648,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5665,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1118 foreign-type-declaration */
t8=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k5663 in a5643 in k5634 in k5631 in k5625 in k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1118 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5646 in a5643 in k5634 in k5631 in k5625 in k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1119 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5637 in k5634 in k5631 in k5625 in k5622 in k5619 in k5616 in ##compiler#generate-foreign-callback-header in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1121 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5183,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5189,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5189,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5193,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1056 foreign-callback-stub-id */
t4=C_retrieve(lf[627]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5196,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1057 real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5199,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1058 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1059 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5202,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1061 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[624]);}

/* k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5208,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5210,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1088 fold */
t6=C_retrieve(lf[413]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[623],((C_word*)t0)[4],t1);}

/* k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5552,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1089 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5612,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1091 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5555(2,t3,C_SCHEME_UNDEFINED);}}

/* k5610 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1091 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[621],t1,lf[622]);}

/* k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1092 generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[620],((C_word*)t0)[2]);}

/* k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1093 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[618],((C_word*)t0)[2],lf[619]);}

/* k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1094 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[617]);}

/* k5562 in k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5567,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5597,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1095 for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5596 in k5562 in k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5597,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5605,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1097 foreign-result-conversion */
t5=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[616]);}

/* k5603 in a5596 in k5562 in k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1097 gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[613],t1,((C_word*)t0)[2],lf[614],C_SCHEME_TRUE,lf[615]);}

/* k5565 in k5562 in k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_5570(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5595,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1102 foreign-argument-conversion */
t5=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k5593 in k5565 in k5562 in k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1102 gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[612],t1);}

/* k5568 in k5565 in k5562 in k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5573,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1103 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[611],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k5571 in k5568 in k5565 in k5562 in k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5576,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_5576(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1104 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5574 in k5571 in k5568 in k5565 in k5562 in k5559 in k5556 in k5553 in k5550 in k5547 in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1105 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[610]);}

/* compute-size in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5210,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5220,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5220(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
if(C_truep(t8)){
t9=t7;
f_5220(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t9)){
t10=t7;
f_5220(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t10)){
t11=t7;
f_5220(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t11)){
t12=t7;
f_5220(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[523]);
if(C_truep(t12)){
t13=t7;
f_5220(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t7;
f_5220(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t14)){
t15=t7;
f_5220(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t15)){
t16=t7;
f_5220(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t16)){
t17=t7;
f_5220(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t17)){
t18=t7;
f_5220(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[608]);
t19=t7;
f_5220(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[609])));}}}}}}}}}}}}

/* k5218 in compute-size in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5220,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5229(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t4)){
t5=t3;
f_5229(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
if(C_truep(t5)){
t6=t3;
f_5229(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
if(C_truep(t6)){
t7=t3;
f_5229(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t7)){
t8=t3;
f_5229(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t8)){
t9=t3;
f_5229(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t9)){
t10=t3;
f_5229(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t10)){
t11=t3;
f_5229(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t11)){
t12=t3;
f_5229(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t12)){
t13=t3;
f_5229(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t13)){
t14=t3;
f_5229(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t14)){
t15=t3;
f_5229(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t16=t3;
f_5229(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[599])));}}}}}}}}}}}}}}

/* k5227 in k5218 in compute-size in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5229,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1070 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[561]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5241(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t4)){
t5=t3;
f_5241(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t5)){
t6=t3;
f_5241(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
t7=t3;
f_5241(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[588])));}}}}}

/* k5239 in k5227 in k5218 in compute-size in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5241,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1072 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[563],((C_word*)t0)[5],lf[564],((C_word*)t0)[5],lf[565]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5253(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_5253(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_5253(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_5253(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k5251 in k5239 in k5227 in k5218 in compute-size in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5253(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5253,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1074 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[567],((C_word*)t0)[4],lf[568]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1076 ##sys#hash-table-ref */
t3=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[581]),((C_word*)t0)[2]);}
else{
t3=t2;
f_5259(2,t3,C_SCHEME_FALSE);}}}

/* k5257 in k5251 in k5239 in k5227 in k5218 in compute-size in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5259,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1078 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5210(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[569]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5293,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_5293(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[572]);
if(C_truep(t5)){
t6=t4;
f_5293(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[573]);
if(C_truep(t6)){
t7=t4;
f_5293(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t7)){
t8=t4;
f_5293(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[575]);
if(C_truep(t8)){
t9=t4;
f_5293(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t9)){
t10=t4;
f_5293(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t10)){
t11=t4;
f_5293(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[578]);
t12=t4;
f_5293(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[579])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k5291 in k5257 in k5251 in k5239 in k5227 in k5218 in compute-size in k5206 in k5200 in k5197 in k5194 in k5191 in a5188 in generate-foreign-callback-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_5293(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1083 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[570]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1084 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5210(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4950,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4956,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4956,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 989  foreign-stub-id */
t4=C_retrieve(lf[559]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 990  real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 991  foreign-stub-argument-types */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5181,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 993  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[556]);}

/* k5179 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5181,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[555],t1);
/* c-backend.scm: 993  intersperse */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 994  foreign-stub-return-type */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 995  foreign-stub-name */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 996  foreign-stub-body */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 997  foreign-stub-argument-names */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_4987(2,t3,t1);}
else{
/* c-backend.scm: 997  make-list */
t3=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 998  foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[550]);}

/* k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 999  foreign-stub-cps */
t3=C_retrieve(lf[549]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1000 foreign-stub-callback */
t3=C_retrieve(lf[548]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1001 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5170,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1003 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5002(2,t3,C_SCHEME_UNDEFINED);}}

/* k5168 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1003 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[546],t1,lf[547]);}

/* k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1005 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[544],((C_word*)t0)[6],lf[545]);}
else{
t3=t2;
f_5005(2,t3,C_SCHEME_UNDEFINED);}}

/* k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1008 gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[539],((C_word*)t0)[2],lf[540],C_SCHEME_TRUE,lf[541],((C_word*)t0)[2],lf[542]);}
else{
/* c-backend.scm: 1010 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[543],((C_word*)t0)[2],C_make_character(40));}}

/* k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[3]);}

/* k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1013 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[534],C_SCHEME_TRUE,lf[535],((C_word*)t0)[2],lf[536]);}
else{
/* c-backend.scm: 1014 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[537],C_SCHEME_TRUE,lf[538],((C_word*)t0)[2],C_make_character(40));}}

/* k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1016 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[533]);}

/* k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1017 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[532]);}

/* k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5026,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5118,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1026 iota */
t5=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k5146 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1018 for-each */
t2=*((C_word*)lf[61]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5117 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5118,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5126,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5138,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1023 symbol->string */
t7=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1023 sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[531],t3);}}

/* k5136 in a5117 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1021 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5124 in a5117 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1024 foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[530]);}

/* k5128 in k5124 in a5117 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5134,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1025 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5132 in k5128 in k5124 in a5117 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1020 gen */
t2=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[527],((C_word*)t0)[3],C_make_character(41),t1,lf[528],((C_word*)t0)[2],lf[529]);}

/* k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1027 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[526]);}
else{
t3=t2;
f_5029(2,t3,C_SCHEME_UNDEFINED);}}

/* k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5038,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1029 gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[517]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t4)){
/* c-backend.scm: 1040 gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1039 gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[525],((C_word*)t0)[2]);}}}

/* k5057 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1041 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k5060 in k5057 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5065,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5100,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1042 make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[524]);}

/* k5098 in k5060 in k5057 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1042 intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5094 in k5060 in k5057 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k5063 in k5060 in k5057 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[523]);
if(C_truep(t3)){
t4=t2;
f_5068(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1043 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5066 in k5063 in k5060 in k5057 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1044 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[522]);}

/* k5069 in k5066 in k5063 in k5060 in k5057 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1046 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[518],C_SCHEME_TRUE,lf[519]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1048 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[520]);}
else{
/* c-backend.scm: 1049 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[521]);}}}

/* k5036 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1031 gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[516],C_SCHEME_TRUE);}

/* k5039 in k5036 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1033 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1035 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[514]);}
else{
/* c-backend.scm: 1036 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[515]);}}}

/* k5030 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k5000 in k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4964 in k4961 in k4958 in a4955 in ##compiler#generate-foreign-stubs in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1050 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4932(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4932,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4938,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a4937 in ##compiler#generate-foreign-callback-stub-prototypes in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4938,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4942,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 981  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4940 in a4937 in ##compiler#generate-foreign-callback-stub-prototypes in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4945,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 982  generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k4943 in k4940 in a4937 in ##compiler#generate-foreign-callback-stub-prototypes in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 983  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4881,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4885,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 968  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4883 in ##compiler#generate-external-variables in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4890,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a4889 in k4883 in ##compiler#generate-external-variables in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4890,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4897,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
t5=t3;
f_4897(t5,(C_word)C_eqp(t4,C_fix(3)));}
else{
t4=t3;
f_4897(t4,C_SCHEME_FALSE);}}

/* k4895 in a4889 in k4883 in ##compiler#generate-external-variables in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4897,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t5=(C_truep(t4)?lf[508]:lf[509]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4917,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 972  foreign-type-declaration */
t7=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,t2);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4915 in k4895 in a4889 in k4883 in ##compiler#generate-external-variables in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 972  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4865,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 960  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4870 in ##compiler#make-argument-list in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4871,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 962  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4877 in a4870 in ##compiler#make-argument-list in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 962  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4849,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 955  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4854 in ##compiler#make-variable-list in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4855,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 957  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4861 in a4854 in ##compiler#make-variable-list in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 957  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[506],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4760,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4769,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4769(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4769(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4769,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4785,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4798,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_4798(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_4798(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_4798(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_4798(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_4798(t10,C_SCHEME_FALSE);}}}}}

/* k4796 in loop in ##compiler#cleanup in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4798,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_4801(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4808,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 946  string-copy */
t4=C_retrieve(lf[505]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_4785(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k4806 in k4796 in loop in ##compiler#cleanup in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4801(t3,t2);}

/* k4799 in k4796 in loop in ##compiler#cleanup in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_4785(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k4783 in loop in ##compiler#cleanup in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 949  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4769(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4687,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4691,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 911  gen */
t7=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[502],C_SCHEME_TRUE,lf[503],t6,lf[504]);}

/* k4689 in emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4705,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4705(t6,t2,((C_word*)t0)[2]);}

/* do572 in k4689 in emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 915  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[495]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 916  lambda-literal-id */
t5=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k4716 in do572 in k4689 in emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4721,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 917  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[500],t1,((C_word*)t0)[2],lf[501]);}

/* k4719 in k4716 in do572 in k4689 in emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 920  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[496],C_retrieve(lf[185]),lf[497]);}
else{
/* c-backend.scm: 921  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[498]);}}
else{
/* c-backend.scm: 922  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[499]);}}

/* k4722 in k4719 in k4716 in do572 in k4689 in emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4705(t3,((C_word*)t0)[2],t2);}

/* k4692 in k4689 in emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 923  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[494]);}

/* k4695 in k4692 in k4689 in emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 924  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[493]);}

/* k4698 in k4695 in k4692 in k4689 in emit-procedure-table-info in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 925  gen */
t2=C_retrieve(lf[2]);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[486],C_SCHEME_TRUE,lf[487],C_SCHEME_TRUE,lf[488],C_SCHEME_TRUE,lf[489],C_SCHEME_TRUE,lf[490],C_SCHEME_TRUE,lf[491],C_SCHEME_TRUE,lf[492]);}

/* ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1150(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[60],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_1150,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1195,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2622,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2937,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3188,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3895,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3818,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3511,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3676,a[2]=t17,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3474,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3517,a[2]=t17,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3907,a[2]=t4,a[3]=t8,a[4]=t21,a[5]=t19,a[6]=t2,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t24=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4654,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t8,a[6]=t14,a[7]=t23,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 894  debugging */
t25=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t24,lf[484],lf[485]);}

/* k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 896  header */
t4=((C_word*)t0)[2];
f_2622(t4,t3);}

/* k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4661,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 897  declarations */
t3=((C_word*)t0)[2];
f_2788(t3,t2);}

/* k4659 in k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 898  generate-external-variables */
t3=C_retrieve(lf[482]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[483]));}

/* k4662 in k4659 in k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 899  generate-foreign-stubs */
t3=C_retrieve(lf[480]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[481]),((C_word*)t0)[3]);}

/* k4665 in k4662 in k4659 in k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 900  prototypes */
t3=((C_word*)t0)[2];
f_2937(t3,t2);}

/* k4668 in k4665 in k4662 in k4659 in k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 901  generate-foreign-callback-stubs */
t3=C_retrieve(lf[479]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[179]),((C_word*)t0)[2]);}

/* k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 902  trampolines */
t3=((C_word*)t0)[2];
f_3188(t3,t2);}

/* k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 903  procedures */
t3=((C_word*)t0)[2];
f_3907(t3,t2);}

/* k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4682,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 904  emit-procedure-table-info */
t3=C_retrieve(lf[478]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4680 in k4677 in k4674 in k4671 in k4668 in k4665 in k4662 in k4659 in k4656 in k4652 in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 475  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[477],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3907(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3907,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3913,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 718  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 719  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 720  real-name */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3926,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 721  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 722  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3929,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 723  lambda-literal-customizable */
t5=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4651,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 724  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_3935(t3,C_SCHEME_FALSE);}}

/* k4649 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3935(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3935,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 726  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[475]);}

/* k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3944,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 727  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[474]);}

/* k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3947,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 728  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 729  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 730  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 731  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3959,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 732  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 733  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_3965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 734  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 736  string-append */
t3=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[185]),lf[472]);}
else{
t3=t2;
f_3968(2,t3,lf[473]);}}

/* k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 738  debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[470],lf[471],((C_word*)t0)[14]);}
else{
t3=t2;
f_3971(2,t3,C_SCHEME_UNDEFINED);}}

/* k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 739  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4620,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 740  cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4618 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[466],t1,lf[467],C_SCHEME_TRUE);}

/* k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4603,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 749  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[460]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4581,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 742  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[465]);}}

/* k4579 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[463]:lf[464]);
/* c-backend.scm: 743  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4582 in k4579 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 745  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[461]);}
else{
/* c-backend.scm: 746  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[462]);}}

/* k4585 in k4582 in k4579 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 747  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4601 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4606(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 751  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[459]);}}

/* k4604 in k4601 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 752  gen */
t2=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[453],C_SCHEME_TRUE,lf[454],C_SCHEME_TRUE,lf[455],C_SCHEME_TRUE,lf[456],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[458],((C_word*)t0)[2]);}

/* k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 757  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_3986(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 758  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[452]);}}

/* k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4553,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_4553(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4553(t4,C_SCHEME_FALSE);}}

/* k4551 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4553(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4553,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 760  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[451]);}
else{
t2=((C_word*)t0)[2];
f_3989(2,t2,C_SCHEME_UNDEFINED);}}

/* k4554 in k4551 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 761  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3989(2,t2,C_SCHEME_UNDEFINED);}}

/* k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[15]);}

/* k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 763  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[450]);}
else{
t3=t2;
f_3995(2,t3,C_SCHEME_UNDEFINED);}}

/* k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 764  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[449]);}

/* k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[224]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_4001(t5,t4);}
else{
t4=t2;
f_4001(t4,C_SCHEME_UNDEFINED);}}

/* k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4001,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 766  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[448]);}

/* k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 768  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[446],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4515,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4515(t8,t2,((C_word*)t0)[20],t4);}}

/* do459 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4515(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4515,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4525,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 772  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[447],t2,C_make_character(59));}}

/* k4523 in do459 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4515(t4,((C_word*)t0)[2],t2,t3);}

/* k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4227,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4302,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 774  fold */
t6=C_retrieve(lf[413]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 808  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[427]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4380,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_4458(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_4458(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k4456 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4458,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 822  gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[437],C_SCHEME_TRUE,lf[438],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440]);}
else{
/* c-backend.scm: 825  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[441],((C_word*)t0)[3],lf[442]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4470(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 827  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[445]);}}}

/* k4468 in k4456 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 828  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[444]);}
else{
t3=t2;
f_4473(2,t3,C_SCHEME_UNDEFINED);}}

/* k4471 in k4468 in k4456 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[104]);
t4=t2;
f_4479(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[407]))));}
else{
t3=t2;
f_4479(t3,C_SCHEME_FALSE);}}

/* k4477 in k4471 in k4468 in k4456 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 830  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[443]);}
else{
t2=((C_word*)t0)[2];
f_4380(2,t2,C_SCHEME_UNDEFINED);}}

/* k4378 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4383,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4422,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4422(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
t6=t3;
f_4422(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_4422(t4,C_SCHEME_FALSE);}}

/* k4420 in k4378 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 834  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[431],((C_word*)t0)[3],lf[432],((C_word*)t0)[3],lf[433]);}
else{
t4=((C_word*)t0)[2];
f_4383(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 835  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[434],((C_word*)t0)[3],lf[435],((C_word*)t0)[3],lf[436]);}}
else{
t2=((C_word*)t0)[2];
f_4383(2,t2,C_SCHEME_UNDEFINED);}}

/* k4381 in k4378 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_4389(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_4389(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_4389(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k4387 in k4381 in k4378 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4389(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4389,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 837  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[430]);}
else{
t3=t2;
f_4392(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_4010(2,t2,C_SCHEME_UNDEFINED);}}

/* k4390 in k4387 in k4381 in k4378 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_4398(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_4398(t3,C_SCHEME_FALSE);}}

/* k4396 in k4390 in k4387 in k4381 in k4378 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4398(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 839  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[428]);}
else{
/* c-backend.scm: 840  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[429]);}}

/* k4314 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 809  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[426]);}

/* k4317 in k4314 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 810  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[425]);}

/* k4320 in k4317 in k4314 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 812  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 813  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[424]);}}

/* k4323 in k4320 in k4317 in k4314 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 814  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[422],((C_word*)t0)[3],lf[423]);}

/* k4326 in k4323 in k4320 in k4317 in k4314 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4331,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4343(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
if(C_truep(t5)){
t6=t3;
f_4343(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_4343(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k4341 in k4326 in k4323 in k4320 in k4317 in k4314 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4343(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 816  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[418],((C_word*)t0)[2],lf[419],((C_word*)t0)[2],lf[420]);}
else{
t2=((C_word*)t0)[3];
f_4331(2,t2,C_SCHEME_UNDEFINED);}}

/* k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 817  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[417]);}
else{
t3=t2;
f_4334(2,t3,C_SCHEME_UNDEFINED);}}

/* k4332 in k4329 in k4326 in k4323 in k4320 in k4317 in k4314 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 818  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[414],((C_word*)t0)[2],lf[415]);}

/* a4301 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4302,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4310,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 774  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3517(3,t5,t4,t2);}

/* k4308 in a4301 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4227,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4233,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 776  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[409],C_SCHEME_TRUE,lf[410],C_SCHEME_TRUE,lf[411],((C_word*)t0)[2],lf[412]);}

/* k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[407]))){
/* c-backend.scm: 780  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[408]);}
else{
t3=t2;
f_4236(2,t3,C_SCHEME_UNDEFINED);}}

/* k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4239(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4270,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[400]))){
/* c-backend.scm: 783  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[401],C_retrieve(lf[400]),lf[402]);}
else{
if(C_truep(C_retrieve(lf[403]))){
/* c-backend.scm: 785  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[404],C_retrieve(lf[403]),lf[405],C_SCHEME_TRUE,lf[406]);}
else{
t4=t3;
f_4270(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k4268 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4273,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[398]))){
/* c-backend.scm: 788  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[399],C_retrieve(lf[398]),C_make_character(59));}
else{
t3=t2;
f_4273(2,t3,C_SCHEME_UNDEFINED);}}

/* k4271 in k4268 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4276,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[396]))){
/* c-backend.scm: 790  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[397],C_retrieve(lf[396]),C_make_character(59));}
else{
t3=t2;
f_4276(2,t3,C_SCHEME_UNDEFINED);}}

/* k4274 in k4271 in k4268 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[393]))){
/* c-backend.scm: 792  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[394],C_retrieve(lf[393]),lf[395]);}
else{
t2=((C_word*)t0)[2];
f_4239(2,t2,C_SCHEME_UNDEFINED);}}

/* k4237 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 793  gen */
t3=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[386],((C_word*)t0)[3],lf[387],C_SCHEME_TRUE,lf[388],((C_word*)t0)[3],lf[389],C_SCHEME_TRUE,lf[390],C_SCHEME_TRUE,lf[391],C_SCHEME_TRUE,lf[392]);}

/* k4240 in k4237 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 798  gen */
t3=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[380],((C_word*)t0)[2],lf[381],C_SCHEME_TRUE,lf[382],C_SCHEME_TRUE,lf[383],((C_word*)t0)[2],lf[384],C_SCHEME_TRUE,lf[385]);}

/* k4243 in k4240 in k4237 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 802  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[2],lf[379]);}

/* k4246 in k4243 in k4240 in k4237 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4010(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 804  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[376],((C_word*)t0)[4],lf[377]);}}

/* k4255 in k4246 in k4243 in k4240 in k4237 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 805  literal-frame */
t3=((C_word*)t0)[2];
f_3474(t3,t2);}

/* k4258 in k4255 in k4246 in k4243 in k4240 in k4237 in k4234 in k4231 in k4225 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 806  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[374],((C_word*)t0)[2],lf[375]);}

/* k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[235],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_4033(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_4033(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_4033(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_4033(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_4033(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4033(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4033,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[365]:lf[366]);
/* c-backend.scm: 851  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[367],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[371]:lf[372]);
/* c-backend.scm: 877  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[373]);}}
else{
t2=((C_word*)t0)[10];
f_4013(2,t2,C_SCHEME_UNDEFINED);}}

/* k4166 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4171,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 879  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[369]);}
else{
/* c-backend.scm: 880  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[370],((C_word*)t0)[3]);}}

/* k4169 in k4166 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 882  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4174(2,t3,C_SCHEME_UNDEFINED);}}

/* k4181 in k4169 in k4166 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4172 in k4169 in k4166 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 884  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[368]);}

/* k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[309]);
if(C_truep(t3)){
/* c-backend.scm: 852  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_4042(2,t4,C_SCHEME_UNDEFINED);}}

/* k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 853  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[363],((C_word*)t0)[5],lf[364]);}

/* k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 855  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4048(2,t3,C_SCHEME_UNDEFINED);}}

/* k4147 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 857  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[359],C_SCHEME_TRUE,lf[360],C_SCHEME_TRUE,lf[361],((C_word*)t0)[6],lf[362]);}

/* k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[354]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 861  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[355],((C_word*)t0)[6],lf[356]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[309]);
if(C_truep(t5)){
/* c-backend.scm: 862  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[357],((C_word*)t0)[6],lf[358]);}
else{
t6=t2;
f_4054(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 863  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[353]);}

/* k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4118,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 864  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[352]);}

/* k4120 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 864  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4116 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 865  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[350],((C_word*)t0)[5],lf[351]);}

/* k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 867  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[348],((C_word*)t0)[2],lf[349]);}

/* k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4069,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 869  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[346],((C_word*)t0)[3],lf[347]);}

/* k4070 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 870  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[345]);}

/* k4073 in k4070 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4078,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4093,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4093(t7,t2,t3,((C_word*)t0)[2]);}

/* do503 in k4073 in k4070 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_4093(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4093,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4103,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 874  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[344],t2,C_make_character(59));}}

/* k4101 in do503 in k4073 in k4070 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4093(t4,((C_word*)t0)[2],t2,t3);}

/* k4076 in k4073 in k4070 in k4067 in k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4031 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 875  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[342],((C_word*)t0)[3],lf[343]);}
else{
t3=((C_word*)t0)[2];
f_4013(2,t3,C_SCHEME_UNDEFINED);}}

/* k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 886  lambda-literal-body */
t4=C_retrieve(lf[341]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4021 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 885  expression */
t3=((C_word*)t0)[4];
f_1195(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3996 in k3993 in k3990 in k3987 in k3984 in k3981 in k3978 in k3975 in k3972 in k3969 in k3966 in k3963 in k3960 in k3957 in k3954 in k3951 in k3948 in k3945 in k3942 in k3939 in k3933 in k3930 in k3927 in k3924 in k3921 in k3918 in k3915 in a3912 in procedures in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 891  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3517,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 653  immediate? */
t4=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[334]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 657  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3517(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3584,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 658  vector->list */
t6=*((C_word*)lf[337]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 659  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k3596 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3598,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 660  bad-literal */
f_3511(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 662  ##sys#bytevector? */
t3=*((C_word*)lf[339]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k3614 in k3596 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3623,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 662  words */
t4=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3645(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 669  bad-literal */
f_3511(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k3614 in k3596 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3645(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3645,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3667,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 668  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3517(3,t8,t6,t7);}}

/* k3665 in loop in k3614 in k3596 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 668  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3645(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3621 in k3614 in k3596 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k3590 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3586 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 658  reduce */
t2=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[336]+1),C_fix(0),t1);}

/* k3582 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k3553 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3559,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 657  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3517(3,t4,t2,t3);}

/* k3557 in k3553 in k3522 in literal-size in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3474,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3480(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* do389 in literal-frame in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3480(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3480,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3490,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3509,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 647  sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[333],t2);}}

/* k3507 in do389 in literal-frame in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 647  gen-lit */
t2=((C_word*)t0)[4];
f_3676(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3488 in do389 in literal-frame in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3480(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3676(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3676,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3816,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 673  big-fixnum? */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_3683(t5,C_SCHEME_FALSE);}}

/* k3814 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3683(t2,(C_word)C_i_not(t1));}

/* k3681 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3683,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 674  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[316],((C_word*)t0)[4],lf[317]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 675  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k3687 in k3681 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[0]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 677  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[318]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[319]:lf[320]);
/* c-backend.scm: 679  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 681  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[321],t4,lf[322]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 684  c-ify-string */
t6=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 689  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[326]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_3772(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_3772(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k3770 in k3687 in k3681 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3772(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3772,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 693  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[329]);}
else{
/* c-backend.scm: 696  bad-literal */
f_3511(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k3773 in k3770 in k3687 in k3681 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3778,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3785,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 694  encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3783 in k3773 in k3770 in k3687 in k3681 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 694  gen-string-constant */
t2=((C_word*)t0)[3];
f_3818(t2,((C_word*)t0)[2],t1);}

/* k3776 in k3773 in k3770 in k3687 in k3681 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 695  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[327]);}

/* k3737 in k3687 in k3681 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3739,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3745,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 686  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[325]);}

/* k3743 in k3737 in k3687 in k3681 in gen-lit in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 687  gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[323],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[324]);}

/* bad-literal in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3511(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3511,NULL,2,t1,t2);}
/* c-backend.scm: 650  bomb */
t3=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[315],t2);}

/* gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3818(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3818,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3825,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 700  fx/ */
t5=*((C_word*)lf[314]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3828,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 701  modulo */
t3=*((C_word*)lf[313]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k3826 in k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3833,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3833(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do420 in k3826 in k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3833,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3849(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_3849(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3870,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3885,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3889,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 707  string-like-substring */
f_3895(t7,((C_word*)t0)[4],t3,t8);}}

/* k3887 in do420 in k3826 in k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 707  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3883 in do420 in k3826 in k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 707  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k3868 in do420 in k3826 in k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3833(t4,((C_word*)t0)[2],t2,t3);}

/* k3847 in do420 in k3826 in k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3849,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3856,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3860,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 706  string-like-substring */
f_3895(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3858 in k3847 in do420 in k3826 in k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 706  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3854 in k3847 in do420 in k3826 in k3823 in gen-string-constant in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 706  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3895(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3895,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3902,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 711  make-string */
t7=*((C_word*)lf[312]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k3900 in string-like-substring in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3905,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 712  ##sys#copy-bytes */
t3=C_retrieve(lf[311]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k3903 in k3900 in string-like-substring in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3188,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3191,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3227,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3307,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3355,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3355,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3359,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 606  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3359,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 607  lambda-literal-rest-argument */
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 608  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 609  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 610  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 611  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3374(t3,C_SCHEME_FALSE);}}

/* k3470 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3374(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3374,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_3377(t5,t4);}
else{
t3=t2;
f_3377(t3,C_SCHEME_UNDEFINED);}}

/* k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3377,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 613  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3389,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 615  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[305],((C_word*)t0)[9],lf[306],C_SCHEME_TRUE,lf[307],((C_word*)t0)[9],lf[308]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3417(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 623  lambda-literal-allocated */
t4=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k3459 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3417(2,t3,t2);}
else{
/* c-backend.scm: 623  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3415 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3417,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[224]);
t4=t2;
f_3423(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3423(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3421 in k3415 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3423,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[309]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 626  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 627  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 628  lset-adjoin */
t3=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3439 in k3421 in k3415 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3435 in k3421 in k3415 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3431 in k3421 in k3415 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3387 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 617  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[303],((C_word*)t0)[3],lf[304]);}

/* k3390 in k3387 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 618  restore */
f_3191(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3393 in k3390 in k3387 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3398,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 619  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3396 in k3393 in k3390 in k3387 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 620  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[302]);}

/* k3399 in k3396 in k3393 in k3390 in k3387 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 621  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k3409 in k3399 in k3396 in k3393 in k3390 in k3387 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3402 in k3399 in k3396 in k3393 in k3390 in k3387 in k3381 in k3375 in k3372 in k3369 in k3366 in k3363 in k3360 in k3357 in a3354 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 622  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[301]);}

/* k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3325 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3326,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3330,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 632  gen */
t4=C_retrieve(lf[2]);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[296],t2,lf[297],C_SCHEME_TRUE,lf[298],t2,lf[299],t2,lf[300]);}

/* k3328 in a3325 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3333,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 634  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[293],((C_word*)t0)[3],lf[294],((C_word*)t0)[3],lf[295]);}

/* k3331 in k3328 in a3325 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 635  restore */
f_3191(t2,((C_word*)t0)[3]);}

/* k3334 in k3331 in k3328 in a3325 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[292],((C_word*)t0)[2],C_make_character(44));}

/* k3337 in k3334 in k3331 in k3328 in a3325 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3342,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3349,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3353,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 637  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[291]);}

/* k3351 in k3337 in k3334 in k3331 in k3328 in a3325 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 637  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3347 in k3337 in k3334 in k3331 in k3328 in a3325 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3340 in k3337 in k3334 in k3331 in k3328 in a3325 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 638  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[290]);}

/* k3308 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 640  emitter */
t4=((C_word*)t0)[3];
f_3227(t4,t3,C_SCHEME_FALSE);}

/* k3322 in k3308 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3311 in k3308 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 641  emitter */
t3=((C_word*)t0)[2];
f_3227(t3,t2,C_SCHEME_TRUE);}

/* k3318 in k3311 in k3308 in k3305 in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3227(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3227,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3229,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_3229 in emitter in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3229,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[285]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[286]);
/* c-backend.scm: 584  gen */
t6=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[287],t2,C_make_character(114),t4,lf[288],C_SCHEME_TRUE,lf[289],t2,C_make_character(114),t5);}

/* k3231 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 586  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[283],((C_word*)t0)[4],lf[284]);}

/* k3234 in k3231 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 587  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[282],((C_word*)t0)[4],C_make_character(114));}

/* k3237 in k3234 in k3231 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 588  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_3242(2,t3,C_SCHEME_UNDEFINED);}}

/* k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 589  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[278],((C_word*)t0)[4],lf[279],C_SCHEME_TRUE,lf[280],C_SCHEME_TRUE,lf[281],((C_word*)t0)[4],C_make_character(59));}

/* k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 592  restore */
f_3191(t2,((C_word*)t0)[4]);}

/* k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 593  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[277]);}

/* k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 595  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[275]);}
else{
/* c-backend.scm: 596  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[276]);}}

/* k3252 in k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 597  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[274]);}

/* k3255 in k3252 in k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 598  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[273]);}
else{
t3=t2;
f_3260(2,t3,C_SCHEME_UNDEFINED);}}

/* k3258 in k3255 in k3252 in k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 599  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[272]);}

/* k3261 in k3258 in k3255 in k3252 in k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 600  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[271]);}

/* k3264 in k3261 in k3258 in k3255 in k3252 in k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3280,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 601  make-argument-list */
t6=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[270]);}

/* k3278 in k3264 in k3261 in k3258 in k3255 in k3252 in k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 601  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3274 in k3264 in k3261 in k3258 in k3255 in k3252 in k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3267 in k3264 in k3261 in k3258 in k3255 in k3252 in k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 */
static void C_ccall f_3269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 602  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[268]);}

/* restore in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3191(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3191,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3195,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3204(t8,t3,t4,C_fix(0));}

/* do338 in restore in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3204,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3214,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 579  gen */
t5=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[265],t2,lf[266],t3,lf[267]);}}

/* k3212 in do338 in restore in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3204(t4,((C_word*)t0)[2],t2,t3);}

/* k3193 in restore in trampolines in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 580  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[263],((C_word*)t0)[2],lf[264]);}

/* prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2937(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2937,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2941,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 508  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2965,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2969,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 511  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 512  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 513  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2975(t3,C_SCHEME_FALSE);}}

/* k3184 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2975(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2975(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2975,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 514  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[260]);}

/* k3170 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 514  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 515  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 516  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 517  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 518  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 519  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3164,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 521  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_2996(t5,C_SCHEME_UNDEFINED);}}

/* k3162 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2996(t3,t2);}

/* k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2996,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 522  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3002,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3138,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3157,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 527  lambda-literal-callee-signatures */
t5=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3155 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3137 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3138,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3149,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 526  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k3147 in a3137 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3114,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 537  string-append */
t5=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[185]),lf[242]);}
else{
t5=t4;
f_3114(2,t5,lf[243]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3089,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 529  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[249],((C_word*)t0)[5],lf[250],C_SCHEME_TRUE);}}

/* k3087 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 530  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[248]);}

/* k3090 in k3087 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[246]:lf[247]);
/* c-backend.scm: 531  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3093 in k3090 in k3087 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 533  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[244]);}
else{
/* c-backend.scm: 534  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[245]);}}

/* k3096 in k3093 in k3090 in k3087 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 535  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3112 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3117,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 538  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[240],t1,lf[241],C_SCHEME_TRUE);}

/* k3115 in k3112 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[238]))){
/* c-backend.scm: 540  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[239],C_SCHEME_TRUE);}
else{
t3=t2;
f_3120(2,t3,C_SCHEME_UNDEFINED);}}

/* k3118 in k3115 in k3112 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 541  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}

/* k3121 in k3118 in k3115 in k3112 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 542  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[236],((C_word*)t0)[2]);}

/* k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 543  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3011(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 544  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[234]);}}

/* k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3061,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3061(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3061(t4,C_SCHEME_FALSE);}}

/* k3059 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_3061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3061,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 546  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}
else{
t2=((C_word*)t0)[2];
f_3014(2,t2,C_SCHEME_UNDEFINED);}}

/* k3062 in k3059 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 547  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3014(2,t2,C_SCHEME_UNDEFINED);}}

/* k3012 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[4]);}

/* k3015 in k3012 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3017,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 550  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[231]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 558  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k3047 in k3015 in k3012 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3052(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 560  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[232]);}}

/* k3050 in k3047 in k3015 in k3012 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 561  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3021 in k3015 in k3012 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3023,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 553  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[227],((C_word*)t0)[2],lf[228],C_SCHEME_TRUE,lf[229],((C_word*)t0)[2],lf[230]);}}

/* k3030 in k3021 in k3015 in k3012 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k3033 in k3030 in k3021 in k3015 in k3012 in k3009 in k3006 in k3003 in k3000 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in a2964 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 556  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[225],t2,lf[226]);}

/* k2942 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2949,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a2948 in k2942 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2949,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2953,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 565  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[222],t2,lf[223]);}

/* k2951 in a2948 in k2942 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2963,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 566  make-list */
t4=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[221]);}

/* k2961 in k2951 in a2948 in k2942 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k2954 in k2951 in a2948 in k2942 in k2939 in prototypes in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 567  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[219]);}

/* declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2788,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2795,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 479  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[218]);}

/* k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2931,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[187]));}

/* a2930 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2931,3,t0,t1,t2);}
/* c-backend.scm: 482  gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[214],t2,lf[215],C_SCHEME_TRUE,lf[216],t2,lf[217]);}

/* k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_2801(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 486  gen */
t4=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[212],((C_word*)t0)[2],lf[213]);}}

/* k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 487  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[211]);}

/* k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2804,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2809(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2809(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2809,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2819,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 491  ##sys#lambda-info->string */
t6=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2825,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 493  gen */
t8=C_retrieve(lf[2]);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[208],((C_word*)t0)[5],lf[209],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k2823 in k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2878(t6,t2,C_fix(0));}

/* do274 in k2823 in k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2878(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2878,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2888,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 500  gen */
t7=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k2886 in do274 in k2823 in k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2878(t3,((C_word*)t0)[2],t2);}

/* k2826 in k2823 in k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2851(t9,t2,t5);}

/* do279 in k2826 in k2823 in k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2851(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2851,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2861,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 503  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[207]);}}

/* k2859 in do279 in k2826 in k2823 in k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2851(t3,((C_word*)t0)[2],t2);}

/* k2829 in k2826 in k2823 in k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 504  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[206]);}

/* k2832 in k2829 in k2826 in k2823 in k2817 in do268 in k2802 in k2799 in k2796 in k2793 in declarations in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2809(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2622(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2622,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2625,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2642,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2780,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 449  current-seconds */
t5=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2778 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 449  ##sys#decode-seconds */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_2648(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_2648(t3,C_SCHEME_FALSE);}}

/* k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2648(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2648,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2666,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2725,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 453  pad0 */
f_2625(t9,t10);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 453  pad0 */
f_2625(t2,((C_word*)t0)[2]);}

/* k2727 in k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 453  pad0 */
f_2625(t2,((C_word*)t0)[2]);}

/* k2731 in k2727 in k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2737,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 453  pad0 */
f_2625(t2,((C_word*)t0)[2]);}

/* k2735 in k2731 in k2727 in k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2741,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2747,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2759,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 456  chicken-version */
t7=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k2757 in k2735 in k2731 in k2727 in k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 456  string-split */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[201]);}

/* k2753 in k2735 in k2731 in k2727 in k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2746 in k2735 in k2731 in k2727 in k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2747,3,t0,t1,t2);}
/* string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[197],t2,lf[198]);}

/* k2743 in k2735 in k2731 in k2727 in k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 454  string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[196]);}

/* k2739 in k2735 in k2731 in k2727 in k2723 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 451  gen */
t2=C_retrieve(lf[2]);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[190],((C_word*)t0)[7],lf[191],C_SCHEME_TRUE,lf[192],C_SCHEME_TRUE,lf[193],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[194]);}

/* k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 459  gen-list */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[189]));}

/* k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 460  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2670 in k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 461  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[186],C_retrieve(lf[185]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2714,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 463  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[188]);}}

/* k2712 in k2670 in k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 464  gen-list */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[187]));}

/* k2673 in k2670 in k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 465  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[181],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[182],C_retrieve(lf[183]),lf[184]);}

/* k2676 in k2673 in k2670 in k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[177]))){
/* c-backend.scm: 467  generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[179]));}
else{
t3=t2;
f_2681(2,t3,C_SCHEME_UNDEFINED);}}

/* k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[180])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 469  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_2684(2,t3,C_SCHEME_UNDEFINED);}}

/* k2694 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2701,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[180]));}

/* a2700 in k2694 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2701,3,t0,t1,t2);}
/* c-backend.scm: 470  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k2682 in k2679 in k2676 in k2673 in k2670 in k2667 in k2664 in k2646 in k2640 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[177]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 472  generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[179]));}}

/* pad0 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2625(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2625,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 447  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2637 in pad0 in header in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 447  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[176],t1);}

/* expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_1195(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1195,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1198,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 442  expr */
t11=((C_word*)t6)[1];
f_1198(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2590(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2590,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2596,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 436  pair-for-each */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a2595 in expr-args in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2596,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_2600(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 438  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k2598 in a2595 in expr-args in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 439  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1198(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_1198(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word ab[209],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1198,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[14]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[16]:lf[17]);
/* c-backend.scm: 127  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[18]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 128  gen */
t16=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t1,lf[19],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t14)){
/* c-backend.scm: 129  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,lf[21]);}
else{
t15=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 130  gen */
t17=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t1,lf[23],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t16)){
/* c-backend.scm: 131  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[25]);}
else{
/* c-backend.scm: 132  bomb */
t17=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[26]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[27]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 137  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[28],t13,lf[29]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 138  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[30],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[31]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1322,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
t14=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_SCHEME_TRUE,lf[34]);}
else{
t13=(C_word)C_eqp(t9,lf[35]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 150  gen */
t15=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,lf[36],t14);}
else{
t14=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_1380(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[38]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1431,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 162  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[40]);}
else{
t16=(C_word)C_eqp(t9,lf[41]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1458,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 167  gen */
t18=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,lf[43]);}
else{
t17=(C_word)C_eqp(t9,lf[44]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1477,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 172  gen */
t19=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[45]);}
else{
t18=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1510,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 179  gen */
t20=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[49]);}
else{
t19=(C_word)C_eqp(t9,lf[50]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1547,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
t21=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t20,lf[52]);}
else{
t20=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1576,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
t22=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[55]);}
else{
t21=(C_word)C_eqp(t9,lf[56]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1608,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 201  gen */
t24=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t24))(5,t24,t23,lf[63],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[64]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1643,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 211  gen */
t24=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,lf[66]);}
else{
t23=(C_word)C_eqp(t9,lf[67]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 215  gen */
t25=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[68]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1675,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 218  gen */
t27=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t27))(5,t27,t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 227  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[70],t26,lf[71]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1717,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1721,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 228  symbol->string */
t31=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 229  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[76],t26,lf[77]);}
else{
/* c-backend.scm: 230  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[78],t26,lf[79]);}}}
else{
t26=(C_word)C_eqp(t9,lf[80]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1749,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t28)){
/* c-backend.scm: 236  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[81],t27,lf[82]);}
else{
/* c-backend.scm: 237  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[83],t27,lf[84]);}}
else{
t27=(C_word)C_eqp(t9,lf[85]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_cadr(t7))){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1783,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 245  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[86],t28,lf[87]);}
else{
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1796,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 249  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[88],t28,lf[89]);}}
else{
t28=(C_word)C_eqp(t9,lf[90]);
if(C_truep(t28)){
/* c-backend.scm: 253  gen */
t29=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t29))(3,t29,t1,lf[91]);}
else{
t29=(C_word)C_eqp(t9,lf[92]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1839,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=t36,a[5]=t32,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t31,a[9]=t33,a[10]=t3,a[11]=t30,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 262  source-info->string */
t38=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[125]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2150,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 319  lambda-literal-closure-size */
t36=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[129]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2235,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 347  find-lambda */
t41=((C_word*)t0)[2];
f_1153(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[131]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2258,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 364  gen */
t37=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t37))(8,t37,t35,C_SCHEME_TRUE,lf[133],t36,lf[134],t34,lf[135]);}
else{
t33=(C_word)C_eqp(t9,lf[136]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2277,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 369  gen */
t35=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,C_SCHEME_TRUE,lf[138]);}
else{
t34=(C_word)C_eqp(t9,lf[139]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2296,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 374  gen */
t37=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t37))(5,t37,t35,lf[140],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[141]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2315,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 379  gen */
t39=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t39))(6,t39,t36,lf[142],t37,lf[143],t38);}
else{
t36=(C_word)C_eqp(t9,lf[144]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2351,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 387  foreign-result-conversion */
t39=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t39))(4,t39,t37,t38,lf[146]);}
else{
t37=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2371,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2389,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 391  foreign-type-declaration */
t42=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t38,lf[152]);}
else{
t38=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2405,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2419,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 397  foreign-result-conversion */
t42=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t39,lf[158]);}
else{
t39=(C_word)C_eqp(t9,lf[159]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2435,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 403  foreign-type-declaration */
t43=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t43))(4,t43,t42,t40,lf[164]);}
else{
t40=(C_word)C_eqp(t9,lf[165]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2472,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 410  gen */
t42=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,C_SCHEME_TRUE,lf[169]);}
else{
t41=(C_word)C_eqp(t9,lf[170]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2555,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 425  gen */
t43=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t43))(3,t43,t42,lf[172]);}
else{
/* c-backend.scm: 433  bomb */
t42=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t42))(3,t42,t1,lf[173]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2553 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 426  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2556 in k2553 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 427  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[171]);}

/* k2559 in k2556 in k2553 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 428  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2562 in k2559 in k2556 in k2553 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 429  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2565 in k2562 in k2559 in k2556 in k2553 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 430  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2568 in k2565 in k2562 in k2559 in k2556 in k2553 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 431  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 411  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1198(t4,t2,t3,((C_word*)t0)[3]);}

/* k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 412  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}

/* k2476 in k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2478,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2491,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2491(t7,((C_word*)t0)[2],t2,t3);}

/* do215 in k2476 in k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_2491(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2491,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 416  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[166]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 419  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[167]);}}

/* k2512 in do215 in k2476 in k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 420  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2515 in k2512 in do215 in k2476 in k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 421  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2518 in k2515 in k2512 in do215 in k2476 in k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2523,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 422  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2521 in k2518 in k2515 in k2512 in do215 in k2476 in k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2491(t4,((C_word*)t0)[2],t2,t3);}

/* k2499 in do215 in k2476 in k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2504,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 417  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2502 in k2499 in do215 in k2476 in k2473 in k2470 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 418  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k2461 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 403  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[162],t1,lf[163]);}

/* k2433 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 404  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1198(t4,t2,t3,((C_word*)t0)[3]);}

/* k2436 in k2433 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 405  foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2453 in k2436 in k2433 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 405  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[161],t1);}

/* k2439 in k2436 in k2433 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 406  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2442 in k2439 in k2436 in k2433 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 407  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[160]);}

/* k2417 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2423,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 397  foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[157]);}

/* k2421 in k2417 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 397  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[155],t1,lf[156]);}

/* k2403 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2408,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 398  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2406 in k2403 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 399  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[154]);}

/* k2387 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2393,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 391  foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2391 in k2387 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 391  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_make_character(41),t1);}

/* k2369 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 392  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2372 in k2369 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 393  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[148]);}

/* k2349 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 387  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k2313 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 382  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_2318(2,t3,C_SCHEME_UNDEFINED);}}

/* k2325 in k2313 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 383  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2590(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2316 in k2313 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 384  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2294 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 375  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2590(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2297 in k2294 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 376  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2275 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 370  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k2278 in k2275 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 371  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[137]);}

/* k2256 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 365  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2590(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2259 in k2256 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 366  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[132]);}

/* k2237 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 347  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2233 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2235,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 349  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k2181 in k2233 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2216,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 351  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[130],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_2186(2,t3,C_SCHEME_UNDEFINED);}}

/* k2214 in k2181 in k2233 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 352  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_2186(2,t4,C_SCHEME_UNDEFINED);}}

/* k2184 in k2181 in k2233 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_2189(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2204,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 354  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k2202 in k2184 in k2181 in k2233 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 355  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2189(2,t2,C_SCHEME_UNDEFINED);}}

/* k2187 in k2184 in k2181 in k2233 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 356  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2590(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_2192(2,t3,C_SCHEME_UNDEFINED);}}

/* k2190 in k2187 in k2184 in k2181 in k2233 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 357  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 321  lambda-literal-temporaries */
t4=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2134,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 334  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k2132 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2137(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 335  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[128]);}}

/* k2135 in k2132 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 336  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2590(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2138 in k2135 in k2132 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 322  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k2094 in k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 323  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2116 in k2094 in k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2117,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 325  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k2119 in a2116 in k2094 in k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 326  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1198(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2122 in k2119 in a2116 in k2094 in k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 327  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2097 in k2094 in k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2107,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 331  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k2113 in k2097 in k2094 in k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 329  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2106 in k2097 in k2094 in k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2107,4,t0,t1,t2,t3);}
/* c-backend.scm: 330  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[127],t2,C_make_character(59));}

/* k2100 in k2097 in k2094 in k2091 in k2148 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 332  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[126]);}

/* k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[15]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_1842(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1842(t3,C_SCHEME_FALSE);}}

/* k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_1842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1842,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2039,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 265  find-lambda */
t6=((C_word*)t0)[2];
f_1153(t6,t5,t1);}
else{
t4=t3;
f_1848(t4,C_SCHEME_FALSE);}}

/* k2041 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 265  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2037 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1848(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_1848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1848,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_retrieve(lf[112]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2025,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1183,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 114  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1193,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 115  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}}
else{
t4=t3;
f_1854(2,t4,C_SCHEME_UNDEFINED);}}

/* k1191 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 115  string-translate* */
t2=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[122]);}

/* k2030 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[119],t1,lf[120]);}

/* k1181 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 114  string-translate */
t2=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[116],lf[117]);}

/* k2023 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 269  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[113],t1,lf[114]);}

/* k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[35],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 273  gen */
t7=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[94]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 277  lambda-literal-id */
t6=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 303  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k1976 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 304  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1198(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k1979 in k1976 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 305  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[110],((C_word*)t0)[4],lf[111]);}

/* k1982 in k1979 in k1976 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1999(t5,t3);}
else{
t5=C_retrieve(lf[109]);
t6=t4;
f_1999(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k1997 in k1982 in k1979 in k1976 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_1999(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 308  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[105],((C_word*)t0)[2],lf[106]);}
else{
/* c-backend.scm: 309  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[107],((C_word*)t0)[2],lf[108]);}}

/* k1985 in k1982 in k1979 in k1976 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 310  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[102],((C_word*)t0)[3],lf[103],((C_word*)t0)[2],C_make_character(44));}

/* k1988 in k1985 in k1982 in k1979 in k1976 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 311  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2590(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1991 in k1988 in k1985 in k1982 in k1979 in k1976 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 312  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[101]);}

/* k1973 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 278  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_1885(2,t3,C_SCHEME_FALSE);}}

/* k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 279  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_1935(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 294  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k1957 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 295  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1198(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1960 in k1957 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 296  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1933 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 297  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k1936 in k1933 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1941(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 298  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k1939 in k1936 in k1933 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1944(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 299  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k1942 in k1939 in k1936 in k1933 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 300  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2590(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1945 in k1942 in k1939 in k1936 in k1933 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[99]);}

/* k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 280  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 281  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a1917 in k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1918,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 283  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k1920 in a1917 in k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 284  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1198(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1923 in k1920 in a1917 in k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 285  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1892 in k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1908,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 289  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k1914 in k1892 in k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 287  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1907 in k1892 in k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1908,4,t0,t1,t2,t3);}
/* c-backend.scm: 288  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[97],t2,C_make_character(59));}

/* k1895 in k1892 in k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1900(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 290  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[96],((C_word*)t0)[2],C_make_character(59));}}

/* k1898 in k1895 in k1892 in k1889 in k1886 in k1883 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 291  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[95]);}

/* k1864 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 274  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2590(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1867 in k1864 in k1852 in k1846 in k1840 in k1837 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 275  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[93]);}

/* k1794 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 250  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1797 in k1794 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1781 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 246  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1784 in k1781 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1747 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1752,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 238  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1750 in k1747 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1719 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1715 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[72],((C_word*)t0)[2],lf[73],t1,C_make_character(41));}

/* k1673 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 219  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1198(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1641 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1644 in k1641 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[65]);}

/* k1606 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 207  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k1632 in k1606 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 202  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1619 in k1606 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1620,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 204  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[59],t3,lf[60]);}

/* k1622 in a1619 in k1606 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 205  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1198(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1625 in k1622 in a1619 in k1606 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k1609 in k1606 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 208  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[57],t2,lf[58]);}

/* k1574 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1577 in k1574 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 195  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k1580 in k1577 in k1574 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 196  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1583 in k1580 in k1577 in k1574 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 197  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1545 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1548 in k1545 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 188  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[51]);}

/* k1551 in k1548 in k1545 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1556,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 189  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1554 in k1551 in k1548 in k1545 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 190  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1508 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1198(t4,t2,t3,((C_word*)t0)[3]);}

/* k1511 in k1508 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 181  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[47],t4,lf[48]);}

/* k1514 in k1511 in k1508 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1519,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 182  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1517 in k1514 in k1511 in k1508 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 183  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1475 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1198(t4,t2,t3,((C_word*)t0)[3]);}

/* k1478 in k1475 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 174  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k1481 in k1478 in k1475 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 175  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1484 in k1481 in k1478 in k1475 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 176  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1456 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1461,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 168  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1459 in k1456 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 169  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[42]);}

/* k1429 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1434,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 163  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1432 in k1429 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 164  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[39],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_1380(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1380,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 155  gen */
t7=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 159  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1198(t7,t1,t6,t3);}}

/* k1388 in loop in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 156  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1198(t4,t2,t3,((C_word*)t0)[6]);}

/* k1391 in k1388 in loop in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 157  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k1394 in k1391 in k1388 in loop in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 158  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1380(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k1320 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1323 in k1320 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k1326 in k1323 in k1320 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1329 in k1326 in k1323 in k1320 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 145  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[32]);}

/* k1332 in k1329 in k1326 in k1323 in k1320 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1198(t4,t2,t3,((C_word*)t0)[2]);}

/* k1335 in k1332 in k1329 in k1326 in k1323 in k1320 in expr in expression in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_fcall f_1153(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1153,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1157,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1165,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 111  find */
t5=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1164 in find-lambda in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1165,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1173,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 111  lambda-literal-id */
t4=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1171 in a1164 in find-lambda in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k1155 in find-lambda in ##compiler#generate-code in k1146 in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 112  bomb */
t2=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[11],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1130,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1136,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1144,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 93   intersperse */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k1142 in ##compiler#gen-list in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1135 in ##compiler#gen-list in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1136,3,t0,t1,t2);}
/* c-backend.scm: 92   display */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[1]));}

/* ##compiler#gen in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1109(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_1109r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1109r(t0,t1,t2);}}

static void C_ccall f_1109r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1115,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a1114 in ##compiler#gen in k1101 in k1098 in k1095 in k1092 in k1089 */
static void C_ccall f_1115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1115,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 86   newline */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_retrieve(lf[1]));}
else{
/* c-backend.scm: 87   display */
t4=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve(lf[1]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[674] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_1091c-backend.scm",(void*)f_1091},
{"f_1094c-backend.scm",(void*)f_1094},
{"f_1097c-backend.scm",(void*)f_1097},
{"f_1100c-backend.scm",(void*)f_1100},
{"f_1103c-backend.scm",(void*)f_1103},
{"f_8807c-backend.scm",(void*)f_8807},
{"f_8811c-backend.scm",(void*)f_8811},
{"f_8803c-backend.scm",(void*)f_8803},
{"f_1148c-backend.scm",(void*)f_1148},
{"f_8503c-backend.scm",(void*)f_8503},
{"f_8779c-backend.scm",(void*)f_8779},
{"f_8777c-backend.scm",(void*)f_8777},
{"f_8765c-backend.scm",(void*)f_8765},
{"f_8735c-backend.scm",(void*)f_8735},
{"f_8696c-backend.scm",(void*)f_8696},
{"f_8683c-backend.scm",(void*)f_8683},
{"f_8679c-backend.scm",(void*)f_8679},
{"f_8565c-backend.scm",(void*)f_8565},
{"f_8512c-backend.scm",(void*)f_8512},
{"f_8509c-backend.scm",(void*)f_8509},
{"f_8506c-backend.scm",(void*)f_8506},
{"f_7729c-backend.scm",(void*)f_7729},
{"f_7816c-backend.scm",(void*)f_7816},
{"f_7897c-backend.scm",(void*)f_7897},
{"f_8332c-backend.scm",(void*)f_8332},
{"f_8274c-backend.scm",(void*)f_8274},
{"f_8238c-backend.scm",(void*)f_8238},
{"f_8203c-backend.scm",(void*)f_8203},
{"f_8155c-backend.scm",(void*)f_8155},
{"f_8107c-backend.scm",(void*)f_8107},
{"f_8059c-backend.scm",(void*)f_8059},
{"f_8024c-backend.scm",(void*)f_8024},
{"f_7988c-backend.scm",(void*)f_7988},
{"f_7952c-backend.scm",(void*)f_7952},
{"f_7930c-backend.scm",(void*)f_7930},
{"f_7925c-backend.scm",(void*)f_7925},
{"f_7920c-backend.scm",(void*)f_7920},
{"f_7731c-backend.scm",(void*)f_7731},
{"f_6896c-backend.scm",(void*)f_6896},
{"f_6926c-backend.scm",(void*)f_6926},
{"f_6953c-backend.scm",(void*)f_6953},
{"f_7148c-backend.scm",(void*)f_7148},
{"f_7157c-backend.scm",(void*)f_7157},
{"f_7166c-backend.scm",(void*)f_7166},
{"f_7554c-backend.scm",(void*)f_7554},
{"f_7521c-backend.scm",(void*)f_7521},
{"f_7531c-backend.scm",(void*)f_7531},
{"f_7489c-backend.scm",(void*)f_7489},
{"f_7454c-backend.scm",(void*)f_7454},
{"f_7384c-backend.scm",(void*)f_7384},
{"f_7339c-backend.scm",(void*)f_7339},
{"f_7307c-backend.scm",(void*)f_7307},
{"f_7275c-backend.scm",(void*)f_7275},
{"f_7243c-backend.scm",(void*)f_7243},
{"f_7211c-backend.scm",(void*)f_7211},
{"f_7189c-backend.scm",(void*)f_7189},
{"f_6898c-backend.scm",(void*)f_6898},
{"f_5679c-backend.scm",(void*)f_5679},
{"f_5756c-backend.scm",(void*)f_5756},
{"f_5858c-backend.scm",(void*)f_5858},
{"f_5891c-backend.scm",(void*)f_5891},
{"f_5987c-backend.scm",(void*)f_5987},
{"f_6002c-backend.scm",(void*)f_6002},
{"f_6619c-backend.scm",(void*)f_6619},
{"f_6635c-backend.scm",(void*)f_6635},
{"f_6639c-backend.scm",(void*)f_6639},
{"f_6652c-backend.scm",(void*)f_6652},
{"f_6650c-backend.scm",(void*)f_6650},
{"f_6646c-backend.scm",(void*)f_6646},
{"f_6573c-backend.scm",(void*)f_6573},
{"f_6586c-backend.scm",(void*)f_6586},
{"f_6523c-backend.scm",(void*)f_6523},
{"f_6473c-backend.scm",(void*)f_6473},
{"f_6434c-backend.scm",(void*)f_6434},
{"f_6444c-backend.scm",(void*)f_6444},
{"f_6395c-backend.scm",(void*)f_6395},
{"f_6405c-backend.scm",(void*)f_6405},
{"f_6356c-backend.scm",(void*)f_6356},
{"f_6366c-backend.scm",(void*)f_6366},
{"f_6317c-backend.scm",(void*)f_6317},
{"f_6327c-backend.scm",(void*)f_6327},
{"f_6257c-backend.scm",(void*)f_6257},
{"f_6274c-backend.scm",(void*)f_6274},
{"f_6284c-backend.scm",(void*)f_6284},
{"f_6282c-backend.scm",(void*)f_6282},
{"f_6278c-backend.scm",(void*)f_6278},
{"f_6270c-backend.scm",(void*)f_6270},
{"f_6218c-backend.scm",(void*)f_6218},
{"f_6228c-backend.scm",(void*)f_6228},
{"f_6182c-backend.scm",(void*)f_6182},
{"f_6146c-backend.scm",(void*)f_6146},
{"f_6110c-backend.scm",(void*)f_6110},
{"f_6074c-backend.scm",(void*)f_6074},
{"f_6048c-backend.scm",(void*)f_6048},
{"f_6056c-backend.scm",(void*)f_6056},
{"f_6039c-backend.scm",(void*)f_6039},
{"f_6047c-backend.scm",(void*)f_6047},
{"f_6034c-backend.scm",(void*)f_6034},
{"f_5686c-backend.scm",(void*)f_5686},
{"f_5681c-backend.scm",(void*)f_5681},
{"f_5614c-backend.scm",(void*)f_5614},
{"f_5618c-backend.scm",(void*)f_5618},
{"f_5621c-backend.scm",(void*)f_5621},
{"f_5624c-backend.scm",(void*)f_5624},
{"f_5627c-backend.scm",(void*)f_5627},
{"f_5633c-backend.scm",(void*)f_5633},
{"f_5677c-backend.scm",(void*)f_5677},
{"f_5636c-backend.scm",(void*)f_5636},
{"f_5644c-backend.scm",(void*)f_5644},
{"f_5665c-backend.scm",(void*)f_5665},
{"f_5648c-backend.scm",(void*)f_5648},
{"f_5639c-backend.scm",(void*)f_5639},
{"f_5183c-backend.scm",(void*)f_5183},
{"f_5189c-backend.scm",(void*)f_5189},
{"f_5193c-backend.scm",(void*)f_5193},
{"f_5196c-backend.scm",(void*)f_5196},
{"f_5199c-backend.scm",(void*)f_5199},
{"f_5202c-backend.scm",(void*)f_5202},
{"f_5208c-backend.scm",(void*)f_5208},
{"f_5549c-backend.scm",(void*)f_5549},
{"f_5552c-backend.scm",(void*)f_5552},
{"f_5612c-backend.scm",(void*)f_5612},
{"f_5555c-backend.scm",(void*)f_5555},
{"f_5558c-backend.scm",(void*)f_5558},
{"f_5561c-backend.scm",(void*)f_5561},
{"f_5564c-backend.scm",(void*)f_5564},
{"f_5597c-backend.scm",(void*)f_5597},
{"f_5605c-backend.scm",(void*)f_5605},
{"f_5567c-backend.scm",(void*)f_5567},
{"f_5595c-backend.scm",(void*)f_5595},
{"f_5570c-backend.scm",(void*)f_5570},
{"f_5573c-backend.scm",(void*)f_5573},
{"f_5576c-backend.scm",(void*)f_5576},
{"f_5210c-backend.scm",(void*)f_5210},
{"f_5220c-backend.scm",(void*)f_5220},
{"f_5229c-backend.scm",(void*)f_5229},
{"f_5241c-backend.scm",(void*)f_5241},
{"f_5253c-backend.scm",(void*)f_5253},
{"f_5259c-backend.scm",(void*)f_5259},
{"f_5293c-backend.scm",(void*)f_5293},
{"f_4950c-backend.scm",(void*)f_4950},
{"f_4956c-backend.scm",(void*)f_4956},
{"f_4960c-backend.scm",(void*)f_4960},
{"f_4963c-backend.scm",(void*)f_4963},
{"f_4966c-backend.scm",(void*)f_4966},
{"f_5181c-backend.scm",(void*)f_5181},
{"f_4972c-backend.scm",(void*)f_4972},
{"f_4975c-backend.scm",(void*)f_4975},
{"f_4978c-backend.scm",(void*)f_4978},
{"f_4981c-backend.scm",(void*)f_4981},
{"f_4984c-backend.scm",(void*)f_4984},
{"f_4987c-backend.scm",(void*)f_4987},
{"f_4990c-backend.scm",(void*)f_4990},
{"f_4993c-backend.scm",(void*)f_4993},
{"f_4996c-backend.scm",(void*)f_4996},
{"f_4999c-backend.scm",(void*)f_4999},
{"f_5170c-backend.scm",(void*)f_5170},
{"f_5002c-backend.scm",(void*)f_5002},
{"f_5005c-backend.scm",(void*)f_5005},
{"f_5008c-backend.scm",(void*)f_5008},
{"f_5011c-backend.scm",(void*)f_5011},
{"f_5014c-backend.scm",(void*)f_5014},
{"f_5017c-backend.scm",(void*)f_5017},
{"f_5020c-backend.scm",(void*)f_5020},
{"f_5023c-backend.scm",(void*)f_5023},
{"f_5148c-backend.scm",(void*)f_5148},
{"f_5118c-backend.scm",(void*)f_5118},
{"f_5138c-backend.scm",(void*)f_5138},
{"f_5126c-backend.scm",(void*)f_5126},
{"f_5130c-backend.scm",(void*)f_5130},
{"f_5134c-backend.scm",(void*)f_5134},
{"f_5026c-backend.scm",(void*)f_5026},
{"f_5029c-backend.scm",(void*)f_5029},
{"f_5059c-backend.scm",(void*)f_5059},
{"f_5062c-backend.scm",(void*)f_5062},
{"f_5100c-backend.scm",(void*)f_5100},
{"f_5096c-backend.scm",(void*)f_5096},
{"f_5065c-backend.scm",(void*)f_5065},
{"f_5068c-backend.scm",(void*)f_5068},
{"f_5071c-backend.scm",(void*)f_5071},
{"f_5038c-backend.scm",(void*)f_5038},
{"f_5041c-backend.scm",(void*)f_5041},
{"f_5032c-backend.scm",(void*)f_5032},
{"f_4932c-backend.scm",(void*)f_4932},
{"f_4938c-backend.scm",(void*)f_4938},
{"f_4942c-backend.scm",(void*)f_4942},
{"f_4945c-backend.scm",(void*)f_4945},
{"f_4881c-backend.scm",(void*)f_4881},
{"f_4885c-backend.scm",(void*)f_4885},
{"f_4890c-backend.scm",(void*)f_4890},
{"f_4897c-backend.scm",(void*)f_4897},
{"f_4917c-backend.scm",(void*)f_4917},
{"f_4865c-backend.scm",(void*)f_4865},
{"f_4871c-backend.scm",(void*)f_4871},
{"f_4879c-backend.scm",(void*)f_4879},
{"f_4849c-backend.scm",(void*)f_4849},
{"f_4855c-backend.scm",(void*)f_4855},
{"f_4863c-backend.scm",(void*)f_4863},
{"f_4760c-backend.scm",(void*)f_4760},
{"f_4769c-backend.scm",(void*)f_4769},
{"f_4798c-backend.scm",(void*)f_4798},
{"f_4808c-backend.scm",(void*)f_4808},
{"f_4801c-backend.scm",(void*)f_4801},
{"f_4785c-backend.scm",(void*)f_4785},
{"f_4687c-backend.scm",(void*)f_4687},
{"f_4691c-backend.scm",(void*)f_4691},
{"f_4705c-backend.scm",(void*)f_4705},
{"f_4718c-backend.scm",(void*)f_4718},
{"f_4721c-backend.scm",(void*)f_4721},
{"f_4724c-backend.scm",(void*)f_4724},
{"f_4694c-backend.scm",(void*)f_4694},
{"f_4697c-backend.scm",(void*)f_4697},
{"f_4700c-backend.scm",(void*)f_4700},
{"f_1150c-backend.scm",(void*)f_1150},
{"f_4654c-backend.scm",(void*)f_4654},
{"f_4658c-backend.scm",(void*)f_4658},
{"f_4661c-backend.scm",(void*)f_4661},
{"f_4664c-backend.scm",(void*)f_4664},
{"f_4667c-backend.scm",(void*)f_4667},
{"f_4670c-backend.scm",(void*)f_4670},
{"f_4673c-backend.scm",(void*)f_4673},
{"f_4676c-backend.scm",(void*)f_4676},
{"f_4679c-backend.scm",(void*)f_4679},
{"f_4682c-backend.scm",(void*)f_4682},
{"f_3907c-backend.scm",(void*)f_3907},
{"f_3913c-backend.scm",(void*)f_3913},
{"f_3917c-backend.scm",(void*)f_3917},
{"f_3920c-backend.scm",(void*)f_3920},
{"f_3923c-backend.scm",(void*)f_3923},
{"f_3926c-backend.scm",(void*)f_3926},
{"f_3929c-backend.scm",(void*)f_3929},
{"f_3932c-backend.scm",(void*)f_3932},
{"f_4651c-backend.scm",(void*)f_4651},
{"f_3935c-backend.scm",(void*)f_3935},
{"f_3941c-backend.scm",(void*)f_3941},
{"f_3944c-backend.scm",(void*)f_3944},
{"f_3947c-backend.scm",(void*)f_3947},
{"f_3950c-backend.scm",(void*)f_3950},
{"f_3953c-backend.scm",(void*)f_3953},
{"f_3956c-backend.scm",(void*)f_3956},
{"f_3959c-backend.scm",(void*)f_3959},
{"f_3962c-backend.scm",(void*)f_3962},
{"f_3965c-backend.scm",(void*)f_3965},
{"f_3968c-backend.scm",(void*)f_3968},
{"f_3971c-backend.scm",(void*)f_3971},
{"f_3974c-backend.scm",(void*)f_3974},
{"f_4620c-backend.scm",(void*)f_4620},
{"f_3977c-backend.scm",(void*)f_3977},
{"f_4581c-backend.scm",(void*)f_4581},
{"f_4584c-backend.scm",(void*)f_4584},
{"f_4587c-backend.scm",(void*)f_4587},
{"f_4603c-backend.scm",(void*)f_4603},
{"f_4606c-backend.scm",(void*)f_4606},
{"f_3980c-backend.scm",(void*)f_3980},
{"f_3983c-backend.scm",(void*)f_3983},
{"f_3986c-backend.scm",(void*)f_3986},
{"f_4553c-backend.scm",(void*)f_4553},
{"f_4556c-backend.scm",(void*)f_4556},
{"f_3989c-backend.scm",(void*)f_3989},
{"f_3992c-backend.scm",(void*)f_3992},
{"f_3995c-backend.scm",(void*)f_3995},
{"f_3998c-backend.scm",(void*)f_3998},
{"f_4001c-backend.scm",(void*)f_4001},
{"f_4004c-backend.scm",(void*)f_4004},
{"f_4515c-backend.scm",(void*)f_4515},
{"f_4525c-backend.scm",(void*)f_4525},
{"f_4007c-backend.scm",(void*)f_4007},
{"f_4458c-backend.scm",(void*)f_4458},
{"f_4470c-backend.scm",(void*)f_4470},
{"f_4473c-backend.scm",(void*)f_4473},
{"f_4479c-backend.scm",(void*)f_4479},
{"f_4380c-backend.scm",(void*)f_4380},
{"f_4422c-backend.scm",(void*)f_4422},
{"f_4383c-backend.scm",(void*)f_4383},
{"f_4389c-backend.scm",(void*)f_4389},
{"f_4392c-backend.scm",(void*)f_4392},
{"f_4398c-backend.scm",(void*)f_4398},
{"f_4316c-backend.scm",(void*)f_4316},
{"f_4319c-backend.scm",(void*)f_4319},
{"f_4322c-backend.scm",(void*)f_4322},
{"f_4325c-backend.scm",(void*)f_4325},
{"f_4328c-backend.scm",(void*)f_4328},
{"f_4343c-backend.scm",(void*)f_4343},
{"f_4331c-backend.scm",(void*)f_4331},
{"f_4334c-backend.scm",(void*)f_4334},
{"f_4302c-backend.scm",(void*)f_4302},
{"f_4310c-backend.scm",(void*)f_4310},
{"f_4227c-backend.scm",(void*)f_4227},
{"f_4233c-backend.scm",(void*)f_4233},
{"f_4236c-backend.scm",(void*)f_4236},
{"f_4270c-backend.scm",(void*)f_4270},
{"f_4273c-backend.scm",(void*)f_4273},
{"f_4276c-backend.scm",(void*)f_4276},
{"f_4239c-backend.scm",(void*)f_4239},
{"f_4242c-backend.scm",(void*)f_4242},
{"f_4245c-backend.scm",(void*)f_4245},
{"f_4248c-backend.scm",(void*)f_4248},
{"f_4257c-backend.scm",(void*)f_4257},
{"f_4260c-backend.scm",(void*)f_4260},
{"f_4010c-backend.scm",(void*)f_4010},
{"f_4033c-backend.scm",(void*)f_4033},
{"f_4168c-backend.scm",(void*)f_4168},
{"f_4171c-backend.scm",(void*)f_4171},
{"f_4183c-backend.scm",(void*)f_4183},
{"f_4174c-backend.scm",(void*)f_4174},
{"f_4039c-backend.scm",(void*)f_4039},
{"f_4042c-backend.scm",(void*)f_4042},
{"f_4045c-backend.scm",(void*)f_4045},
{"f_4149c-backend.scm",(void*)f_4149},
{"f_4048c-backend.scm",(void*)f_4048},
{"f_4051c-backend.scm",(void*)f_4051},
{"f_4054c-backend.scm",(void*)f_4054},
{"f_4057c-backend.scm",(void*)f_4057},
{"f_4122c-backend.scm",(void*)f_4122},
{"f_4118c-backend.scm",(void*)f_4118},
{"f_4060c-backend.scm",(void*)f_4060},
{"f_4063c-backend.scm",(void*)f_4063},
{"f_4066c-backend.scm",(void*)f_4066},
{"f_4069c-backend.scm",(void*)f_4069},
{"f_4072c-backend.scm",(void*)f_4072},
{"f_4075c-backend.scm",(void*)f_4075},
{"f_4093c-backend.scm",(void*)f_4093},
{"f_4103c-backend.scm",(void*)f_4103},
{"f_4078c-backend.scm",(void*)f_4078},
{"f_4013c-backend.scm",(void*)f_4013},
{"f_4023c-backend.scm",(void*)f_4023},
{"f_4016c-backend.scm",(void*)f_4016},
{"f_3517c-backend.scm",(void*)f_3517},
{"f_3524c-backend.scm",(void*)f_3524},
{"f_3598c-backend.scm",(void*)f_3598},
{"f_3616c-backend.scm",(void*)f_3616},
{"f_3645c-backend.scm",(void*)f_3645},
{"f_3667c-backend.scm",(void*)f_3667},
{"f_3623c-backend.scm",(void*)f_3623},
{"f_3592c-backend.scm",(void*)f_3592},
{"f_3588c-backend.scm",(void*)f_3588},
{"f_3584c-backend.scm",(void*)f_3584},
{"f_3555c-backend.scm",(void*)f_3555},
{"f_3559c-backend.scm",(void*)f_3559},
{"f_3474c-backend.scm",(void*)f_3474},
{"f_3480c-backend.scm",(void*)f_3480},
{"f_3509c-backend.scm",(void*)f_3509},
{"f_3490c-backend.scm",(void*)f_3490},
{"f_3676c-backend.scm",(void*)f_3676},
{"f_3816c-backend.scm",(void*)f_3816},
{"f_3683c-backend.scm",(void*)f_3683},
{"f_3689c-backend.scm",(void*)f_3689},
{"f_3772c-backend.scm",(void*)f_3772},
{"f_3775c-backend.scm",(void*)f_3775},
{"f_3785c-backend.scm",(void*)f_3785},
{"f_3778c-backend.scm",(void*)f_3778},
{"f_3739c-backend.scm",(void*)f_3739},
{"f_3745c-backend.scm",(void*)f_3745},
{"f_3511c-backend.scm",(void*)f_3511},
{"f_3818c-backend.scm",(void*)f_3818},
{"f_3825c-backend.scm",(void*)f_3825},
{"f_3828c-backend.scm",(void*)f_3828},
{"f_3833c-backend.scm",(void*)f_3833},
{"f_3889c-backend.scm",(void*)f_3889},
{"f_3885c-backend.scm",(void*)f_3885},
{"f_3870c-backend.scm",(void*)f_3870},
{"f_3849c-backend.scm",(void*)f_3849},
{"f_3860c-backend.scm",(void*)f_3860},
{"f_3856c-backend.scm",(void*)f_3856},
{"f_3895c-backend.scm",(void*)f_3895},
{"f_3902c-backend.scm",(void*)f_3902},
{"f_3905c-backend.scm",(void*)f_3905},
{"f_3188c-backend.scm",(void*)f_3188},
{"f_3355c-backend.scm",(void*)f_3355},
{"f_3359c-backend.scm",(void*)f_3359},
{"f_3362c-backend.scm",(void*)f_3362},
{"f_3365c-backend.scm",(void*)f_3365},
{"f_3368c-backend.scm",(void*)f_3368},
{"f_3371c-backend.scm",(void*)f_3371},
{"f_3472c-backend.scm",(void*)f_3472},
{"f_3374c-backend.scm",(void*)f_3374},
{"f_3377c-backend.scm",(void*)f_3377},
{"f_3383c-backend.scm",(void*)f_3383},
{"f_3461c-backend.scm",(void*)f_3461},
{"f_3417c-backend.scm",(void*)f_3417},
{"f_3423c-backend.scm",(void*)f_3423},
{"f_3441c-backend.scm",(void*)f_3441},
{"f_3437c-backend.scm",(void*)f_3437},
{"f_3433c-backend.scm",(void*)f_3433},
{"f_3389c-backend.scm",(void*)f_3389},
{"f_3392c-backend.scm",(void*)f_3392},
{"f_3395c-backend.scm",(void*)f_3395},
{"f_3398c-backend.scm",(void*)f_3398},
{"f_3401c-backend.scm",(void*)f_3401},
{"f_3411c-backend.scm",(void*)f_3411},
{"f_3404c-backend.scm",(void*)f_3404},
{"f_3307c-backend.scm",(void*)f_3307},
{"f_3326c-backend.scm",(void*)f_3326},
{"f_3330c-backend.scm",(void*)f_3330},
{"f_3333c-backend.scm",(void*)f_3333},
{"f_3336c-backend.scm",(void*)f_3336},
{"f_3339c-backend.scm",(void*)f_3339},
{"f_3353c-backend.scm",(void*)f_3353},
{"f_3349c-backend.scm",(void*)f_3349},
{"f_3342c-backend.scm",(void*)f_3342},
{"f_3310c-backend.scm",(void*)f_3310},
{"f_3324c-backend.scm",(void*)f_3324},
{"f_3313c-backend.scm",(void*)f_3313},
{"f_3320c-backend.scm",(void*)f_3320},
{"f_3227c-backend.scm",(void*)f_3227},
{"f_3229c-backend.scm",(void*)f_3229},
{"f_3233c-backend.scm",(void*)f_3233},
{"f_3236c-backend.scm",(void*)f_3236},
{"f_3239c-backend.scm",(void*)f_3239},
{"f_3242c-backend.scm",(void*)f_3242},
{"f_3245c-backend.scm",(void*)f_3245},
{"f_3248c-backend.scm",(void*)f_3248},
{"f_3251c-backend.scm",(void*)f_3251},
{"f_3254c-backend.scm",(void*)f_3254},
{"f_3257c-backend.scm",(void*)f_3257},
{"f_3260c-backend.scm",(void*)f_3260},
{"f_3263c-backend.scm",(void*)f_3263},
{"f_3266c-backend.scm",(void*)f_3266},
{"f_3280c-backend.scm",(void*)f_3280},
{"f_3276c-backend.scm",(void*)f_3276},
{"f_3269c-backend.scm",(void*)f_3269},
{"f_3191c-backend.scm",(void*)f_3191},
{"f_3204c-backend.scm",(void*)f_3204},
{"f_3214c-backend.scm",(void*)f_3214},
{"f_3195c-backend.scm",(void*)f_3195},
{"f_2937c-backend.scm",(void*)f_2937},
{"f_2941c-backend.scm",(void*)f_2941},
{"f_2965c-backend.scm",(void*)f_2965},
{"f_2969c-backend.scm",(void*)f_2969},
{"f_2972c-backend.scm",(void*)f_2972},
{"f_3186c-backend.scm",(void*)f_3186},
{"f_2975c-backend.scm",(void*)f_2975},
{"f_3172c-backend.scm",(void*)f_3172},
{"f_2978c-backend.scm",(void*)f_2978},
{"f_2981c-backend.scm",(void*)f_2981},
{"f_2984c-backend.scm",(void*)f_2984},
{"f_2987c-backend.scm",(void*)f_2987},
{"f_2990c-backend.scm",(void*)f_2990},
{"f_2993c-backend.scm",(void*)f_2993},
{"f_3164c-backend.scm",(void*)f_3164},
{"f_2996c-backend.scm",(void*)f_2996},
{"f_2999c-backend.scm",(void*)f_2999},
{"f_3157c-backend.scm",(void*)f_3157},
{"f_3138c-backend.scm",(void*)f_3138},
{"f_3149c-backend.scm",(void*)f_3149},
{"f_3002c-backend.scm",(void*)f_3002},
{"f_3089c-backend.scm",(void*)f_3089},
{"f_3092c-backend.scm",(void*)f_3092},
{"f_3095c-backend.scm",(void*)f_3095},
{"f_3098c-backend.scm",(void*)f_3098},
{"f_3114c-backend.scm",(void*)f_3114},
{"f_3117c-backend.scm",(void*)f_3117},
{"f_3120c-backend.scm",(void*)f_3120},
{"f_3123c-backend.scm",(void*)f_3123},
{"f_3005c-backend.scm",(void*)f_3005},
{"f_3008c-backend.scm",(void*)f_3008},
{"f_3011c-backend.scm",(void*)f_3011},
{"f_3061c-backend.scm",(void*)f_3061},
{"f_3064c-backend.scm",(void*)f_3064},
{"f_3014c-backend.scm",(void*)f_3014},
{"f_3017c-backend.scm",(void*)f_3017},
{"f_3049c-backend.scm",(void*)f_3049},
{"f_3052c-backend.scm",(void*)f_3052},
{"f_3023c-backend.scm",(void*)f_3023},
{"f_3032c-backend.scm",(void*)f_3032},
{"f_3035c-backend.scm",(void*)f_3035},
{"f_2944c-backend.scm",(void*)f_2944},
{"f_2949c-backend.scm",(void*)f_2949},
{"f_2953c-backend.scm",(void*)f_2953},
{"f_2963c-backend.scm",(void*)f_2963},
{"f_2956c-backend.scm",(void*)f_2956},
{"f_2788c-backend.scm",(void*)f_2788},
{"f_2795c-backend.scm",(void*)f_2795},
{"f_2931c-backend.scm",(void*)f_2931},
{"f_2798c-backend.scm",(void*)f_2798},
{"f_2801c-backend.scm",(void*)f_2801},
{"f_2804c-backend.scm",(void*)f_2804},
{"f_2809c-backend.scm",(void*)f_2809},
{"f_2819c-backend.scm",(void*)f_2819},
{"f_2825c-backend.scm",(void*)f_2825},
{"f_2878c-backend.scm",(void*)f_2878},
{"f_2888c-backend.scm",(void*)f_2888},
{"f_2828c-backend.scm",(void*)f_2828},
{"f_2851c-backend.scm",(void*)f_2851},
{"f_2861c-backend.scm",(void*)f_2861},
{"f_2831c-backend.scm",(void*)f_2831},
{"f_2834c-backend.scm",(void*)f_2834},
{"f_2622c-backend.scm",(void*)f_2622},
{"f_2780c-backend.scm",(void*)f_2780},
{"f_2642c-backend.scm",(void*)f_2642},
{"f_2648c-backend.scm",(void*)f_2648},
{"f_2725c-backend.scm",(void*)f_2725},
{"f_2729c-backend.scm",(void*)f_2729},
{"f_2733c-backend.scm",(void*)f_2733},
{"f_2737c-backend.scm",(void*)f_2737},
{"f_2759c-backend.scm",(void*)f_2759},
{"f_2755c-backend.scm",(void*)f_2755},
{"f_2747c-backend.scm",(void*)f_2747},
{"f_2745c-backend.scm",(void*)f_2745},
{"f_2741c-backend.scm",(void*)f_2741},
{"f_2666c-backend.scm",(void*)f_2666},
{"f_2669c-backend.scm",(void*)f_2669},
{"f_2672c-backend.scm",(void*)f_2672},
{"f_2714c-backend.scm",(void*)f_2714},
{"f_2675c-backend.scm",(void*)f_2675},
{"f_2678c-backend.scm",(void*)f_2678},
{"f_2681c-backend.scm",(void*)f_2681},
{"f_2696c-backend.scm",(void*)f_2696},
{"f_2701c-backend.scm",(void*)f_2701},
{"f_2684c-backend.scm",(void*)f_2684},
{"f_2625c-backend.scm",(void*)f_2625},
{"f_2639c-backend.scm",(void*)f_2639},
{"f_1195c-backend.scm",(void*)f_1195},
{"f_2590c-backend.scm",(void*)f_2590},
{"f_2596c-backend.scm",(void*)f_2596},
{"f_2600c-backend.scm",(void*)f_2600},
{"f_1198c-backend.scm",(void*)f_1198},
{"f_2555c-backend.scm",(void*)f_2555},
{"f_2558c-backend.scm",(void*)f_2558},
{"f_2561c-backend.scm",(void*)f_2561},
{"f_2564c-backend.scm",(void*)f_2564},
{"f_2567c-backend.scm",(void*)f_2567},
{"f_2570c-backend.scm",(void*)f_2570},
{"f_2472c-backend.scm",(void*)f_2472},
{"f_2475c-backend.scm",(void*)f_2475},
{"f_2478c-backend.scm",(void*)f_2478},
{"f_2491c-backend.scm",(void*)f_2491},
{"f_2514c-backend.scm",(void*)f_2514},
{"f_2517c-backend.scm",(void*)f_2517},
{"f_2520c-backend.scm",(void*)f_2520},
{"f_2523c-backend.scm",(void*)f_2523},
{"f_2501c-backend.scm",(void*)f_2501},
{"f_2504c-backend.scm",(void*)f_2504},
{"f_2463c-backend.scm",(void*)f_2463},
{"f_2435c-backend.scm",(void*)f_2435},
{"f_2438c-backend.scm",(void*)f_2438},
{"f_2455c-backend.scm",(void*)f_2455},
{"f_2441c-backend.scm",(void*)f_2441},
{"f_2444c-backend.scm",(void*)f_2444},
{"f_2419c-backend.scm",(void*)f_2419},
{"f_2423c-backend.scm",(void*)f_2423},
{"f_2405c-backend.scm",(void*)f_2405},
{"f_2408c-backend.scm",(void*)f_2408},
{"f_2389c-backend.scm",(void*)f_2389},
{"f_2393c-backend.scm",(void*)f_2393},
{"f_2371c-backend.scm",(void*)f_2371},
{"f_2374c-backend.scm",(void*)f_2374},
{"f_2351c-backend.scm",(void*)f_2351},
{"f_2315c-backend.scm",(void*)f_2315},
{"f_2327c-backend.scm",(void*)f_2327},
{"f_2318c-backend.scm",(void*)f_2318},
{"f_2296c-backend.scm",(void*)f_2296},
{"f_2299c-backend.scm",(void*)f_2299},
{"f_2277c-backend.scm",(void*)f_2277},
{"f_2280c-backend.scm",(void*)f_2280},
{"f_2258c-backend.scm",(void*)f_2258},
{"f_2261c-backend.scm",(void*)f_2261},
{"f_2239c-backend.scm",(void*)f_2239},
{"f_2235c-backend.scm",(void*)f_2235},
{"f_2183c-backend.scm",(void*)f_2183},
{"f_2216c-backend.scm",(void*)f_2216},
{"f_2186c-backend.scm",(void*)f_2186},
{"f_2204c-backend.scm",(void*)f_2204},
{"f_2189c-backend.scm",(void*)f_2189},
{"f_2192c-backend.scm",(void*)f_2192},
{"f_2150c-backend.scm",(void*)f_2150},
{"f_2134c-backend.scm",(void*)f_2134},
{"f_2137c-backend.scm",(void*)f_2137},
{"f_2140c-backend.scm",(void*)f_2140},
{"f_2093c-backend.scm",(void*)f_2093},
{"f_2096c-backend.scm",(void*)f_2096},
{"f_2117c-backend.scm",(void*)f_2117},
{"f_2121c-backend.scm",(void*)f_2121},
{"f_2124c-backend.scm",(void*)f_2124},
{"f_2099c-backend.scm",(void*)f_2099},
{"f_2115c-backend.scm",(void*)f_2115},
{"f_2107c-backend.scm",(void*)f_2107},
{"f_2102c-backend.scm",(void*)f_2102},
{"f_1839c-backend.scm",(void*)f_1839},
{"f_1842c-backend.scm",(void*)f_1842},
{"f_2043c-backend.scm",(void*)f_2043},
{"f_2039c-backend.scm",(void*)f_2039},
{"f_1848c-backend.scm",(void*)f_1848},
{"f_1193c-backend.scm",(void*)f_1193},
{"f_2032c-backend.scm",(void*)f_2032},
{"f_1183c-backend.scm",(void*)f_1183},
{"f_2025c-backend.scm",(void*)f_2025},
{"f_1854c-backend.scm",(void*)f_1854},
{"f_1978c-backend.scm",(void*)f_1978},
{"f_1981c-backend.scm",(void*)f_1981},
{"f_1984c-backend.scm",(void*)f_1984},
{"f_1999c-backend.scm",(void*)f_1999},
{"f_1987c-backend.scm",(void*)f_1987},
{"f_1990c-backend.scm",(void*)f_1990},
{"f_1993c-backend.scm",(void*)f_1993},
{"f_1975c-backend.scm",(void*)f_1975},
{"f_1885c-backend.scm",(void*)f_1885},
{"f_1959c-backend.scm",(void*)f_1959},
{"f_1962c-backend.scm",(void*)f_1962},
{"f_1935c-backend.scm",(void*)f_1935},
{"f_1938c-backend.scm",(void*)f_1938},
{"f_1941c-backend.scm",(void*)f_1941},
{"f_1944c-backend.scm",(void*)f_1944},
{"f_1947c-backend.scm",(void*)f_1947},
{"f_1888c-backend.scm",(void*)f_1888},
{"f_1891c-backend.scm",(void*)f_1891},
{"f_1918c-backend.scm",(void*)f_1918},
{"f_1922c-backend.scm",(void*)f_1922},
{"f_1925c-backend.scm",(void*)f_1925},
{"f_1894c-backend.scm",(void*)f_1894},
{"f_1916c-backend.scm",(void*)f_1916},
{"f_1908c-backend.scm",(void*)f_1908},
{"f_1897c-backend.scm",(void*)f_1897},
{"f_1900c-backend.scm",(void*)f_1900},
{"f_1866c-backend.scm",(void*)f_1866},
{"f_1869c-backend.scm",(void*)f_1869},
{"f_1796c-backend.scm",(void*)f_1796},
{"f_1799c-backend.scm",(void*)f_1799},
{"f_1783c-backend.scm",(void*)f_1783},
{"f_1786c-backend.scm",(void*)f_1786},
{"f_1749c-backend.scm",(void*)f_1749},
{"f_1752c-backend.scm",(void*)f_1752},
{"f_1721c-backend.scm",(void*)f_1721},
{"f_1717c-backend.scm",(void*)f_1717},
{"f_1675c-backend.scm",(void*)f_1675},
{"f_1643c-backend.scm",(void*)f_1643},
{"f_1646c-backend.scm",(void*)f_1646},
{"f_1608c-backend.scm",(void*)f_1608},
{"f_1634c-backend.scm",(void*)f_1634},
{"f_1620c-backend.scm",(void*)f_1620},
{"f_1624c-backend.scm",(void*)f_1624},
{"f_1627c-backend.scm",(void*)f_1627},
{"f_1611c-backend.scm",(void*)f_1611},
{"f_1576c-backend.scm",(void*)f_1576},
{"f_1579c-backend.scm",(void*)f_1579},
{"f_1582c-backend.scm",(void*)f_1582},
{"f_1585c-backend.scm",(void*)f_1585},
{"f_1547c-backend.scm",(void*)f_1547},
{"f_1550c-backend.scm",(void*)f_1550},
{"f_1553c-backend.scm",(void*)f_1553},
{"f_1556c-backend.scm",(void*)f_1556},
{"f_1510c-backend.scm",(void*)f_1510},
{"f_1513c-backend.scm",(void*)f_1513},
{"f_1516c-backend.scm",(void*)f_1516},
{"f_1519c-backend.scm",(void*)f_1519},
{"f_1477c-backend.scm",(void*)f_1477},
{"f_1480c-backend.scm",(void*)f_1480},
{"f_1483c-backend.scm",(void*)f_1483},
{"f_1486c-backend.scm",(void*)f_1486},
{"f_1458c-backend.scm",(void*)f_1458},
{"f_1461c-backend.scm",(void*)f_1461},
{"f_1431c-backend.scm",(void*)f_1431},
{"f_1434c-backend.scm",(void*)f_1434},
{"f_1380c-backend.scm",(void*)f_1380},
{"f_1390c-backend.scm",(void*)f_1390},
{"f_1393c-backend.scm",(void*)f_1393},
{"f_1396c-backend.scm",(void*)f_1396},
{"f_1322c-backend.scm",(void*)f_1322},
{"f_1325c-backend.scm",(void*)f_1325},
{"f_1328c-backend.scm",(void*)f_1328},
{"f_1331c-backend.scm",(void*)f_1331},
{"f_1334c-backend.scm",(void*)f_1334},
{"f_1337c-backend.scm",(void*)f_1337},
{"f_1153c-backend.scm",(void*)f_1153},
{"f_1165c-backend.scm",(void*)f_1165},
{"f_1173c-backend.scm",(void*)f_1173},
{"f_1157c-backend.scm",(void*)f_1157},
{"f_1130c-backend.scm",(void*)f_1130},
{"f_1144c-backend.scm",(void*)f_1144},
{"f_1136c-backend.scm",(void*)f_1136},
{"f_1109c-backend.scm",(void*)f_1109},
{"f_1115c-backend.scm",(void*)f_1115},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
