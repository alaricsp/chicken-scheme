/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-04-18 09:46
   Version 3.1.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   SVN rev. 10129	compiled 2008-03-23 on debian (Linux)
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[814];
static double C_possibly_force_alignment;


/* from getsize in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1050(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1050(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1046(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1046(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8799)
static void C_ccall f_8799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8803)
static void C_ccall f_8803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8795)
static void C_ccall f_8795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8495)
static void C_ccall f_8495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8769)
static void C_ccall f_8769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8757)
static void C_ccall f_8757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8727)
static void C_ccall f_8727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8675)
static void C_ccall f_8675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8671)
static void C_ccall f_8671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8557)
static void C_ccall f_8557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8504)
static C_word C_fcall f_8504(C_word *a,C_word t0);
C_noret_decl(f_8501)
static C_word C_fcall f_8501(C_word t0);
C_noret_decl(f_8498)
static C_word C_fcall f_8498(C_word t0);
C_noret_decl(f_7721)
static void C_ccall f_7721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7808)
static void C_fcall f_7808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8324)
static void C_fcall f_8324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8266)
static void C_fcall f_8266(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8230)
static void C_fcall f_8230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8195)
static void C_fcall f_8195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8147)
static void C_fcall f_8147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8099)
static void C_fcall f_8099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8051)
static void C_fcall f_8051(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8016)
static void C_fcall f_8016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7980)
static void C_fcall f_7980(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7944)
static void C_fcall f_7944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_fcall f_7922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_fcall f_7917(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7912)
static void C_fcall f_7912(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7723)
static void C_fcall f_7723(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_ccall f_6888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6918)
static void C_fcall f_6918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6945)
static void C_fcall f_6945(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_fcall f_7140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7149)
static void C_fcall f_7149(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7546)
static void C_fcall f_7546(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7513)
static void C_fcall f_7513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7523)
static void C_ccall f_7523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_fcall f_7481(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7446)
static void C_fcall f_7446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7376)
static void C_fcall f_7376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7331)
static void C_fcall f_7331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7299)
static void C_fcall f_7299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7267)
static void C_fcall f_7267(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7235)
static void C_fcall f_7235(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7203)
static void C_fcall f_7203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7181)
static void C_fcall f_7181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6890)
static void C_fcall f_6890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5748)
static void C_fcall f_5748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5850)
static void C_fcall f_5850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_fcall f_5883(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_fcall f_5979(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6611)
static void C_fcall f_6611(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6631)
static void C_fcall f_6631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6642)
static void C_ccall f_6642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6565)
static void C_fcall f_6565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6515)
static void C_fcall f_6515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_fcall f_6465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_fcall f_6426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_fcall f_6387(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6348)
static void C_fcall f_6348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6309)
static void C_fcall f_6309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6319)
static void C_ccall f_6319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6249)
static void C_fcall f_6249(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6276)
static void C_ccall f_6276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6270)
static void C_ccall f_6270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_fcall f_6210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_fcall f_6174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6138)
static void C_fcall f_6138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6102)
static void C_fcall f_6102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6066)
static void C_fcall f_6066(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6040)
static void C_fcall f_6040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6048)
static void C_ccall f_6048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6031)
static void C_fcall f_6031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_fcall f_6026(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5673)
static void C_fcall f_5673(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_ccall f_5636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5181)
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5188)
static void C_ccall f_5188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5191)
static void C_ccall f_5191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5553)
static void C_ccall f_5553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5597)
static void C_ccall f_5597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5212)
static void C_fcall f_5212(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5221)
static void C_fcall f_5221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5233)
static void C_fcall f_5233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_fcall f_5245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_fcall f_5285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4948)
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4997)
static void C_ccall f_4997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5009)
static void C_ccall f_5009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_ccall f_5012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5015)
static void C_ccall f_5015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_ccall f_5140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5057)
static void C_ccall f_5057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5063)
static void C_ccall f_5063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4889)
static void C_fcall f_4889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_ccall f_4909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4761)
static void C_fcall f_4761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4790)
static void C_fcall f_4790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_fcall f_4793(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_fcall f_4777(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_fcall f_4697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_fcall f_3899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4643)
static void C_ccall f_4643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_fcall f_3927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4576)
static void C_ccall f_4576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_fcall f_4545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_fcall f_3993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4507)
static void C_fcall f_4507(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4450)
static void C_fcall f_4450(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_fcall f_4471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_fcall f_4414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4381)
static void C_fcall f_4381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4390)
static void C_fcall f_4390(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_fcall f_4335(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4265)
static void C_ccall f_4265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_fcall f_4025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4052)
static void C_ccall f_4052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4085)
static void C_fcall f_4085(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_fcall f_3637(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_ccall f_3615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3547)
static void C_ccall f_3547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_fcall f_3466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_fcall f_3668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_fcall f_3675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_fcall f_3764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3503)
static void C_fcall f_3503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_fcall f_3810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_fcall f_3825(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_ccall f_3862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_fcall f_3841(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_fcall f_3887(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_fcall f_3180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_ccall f_3357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_fcall f_3366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_fcall f_3369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_fcall f_3415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3390)
static void C_ccall f_3390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3334)
static void C_ccall f_3334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_fcall f_3219(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3183)
static void C_fcall f_3183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_fcall f_2929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2967)
static void C_fcall f_2967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_fcall f_2988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3090)
static void C_ccall f_3090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_fcall f_3053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3041)
static void C_ccall f_3041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_ccall f_2955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_fcall f_2780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_fcall f_2801(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_fcall f_2870(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2880)
static void C_ccall f_2880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_fcall f_2843(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_fcall f_2614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_fcall f_2640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_fcall f_2617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_fcall f_1187(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_fcall f_1190(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_fcall f_2483(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_fcall f_1834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_fcall f_1840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_fcall f_1991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_fcall f_1145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_7808)
static void C_fcall trf_7808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7808(t0,t1);}

C_noret_decl(trf_8324)
static void C_fcall trf_8324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8324(t0,t1);}

C_noret_decl(trf_8266)
static void C_fcall trf_8266(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8266(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8266(t0,t1);}

C_noret_decl(trf_8230)
static void C_fcall trf_8230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8230(t0,t1);}

C_noret_decl(trf_8195)
static void C_fcall trf_8195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8195(t0,t1);}

C_noret_decl(trf_8147)
static void C_fcall trf_8147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8147(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8147(t0,t1);}

C_noret_decl(trf_8099)
static void C_fcall trf_8099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8099(t0,t1);}

C_noret_decl(trf_8051)
static void C_fcall trf_8051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8051(t0,t1);}

C_noret_decl(trf_8016)
static void C_fcall trf_8016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8016(t0,t1);}

C_noret_decl(trf_7980)
static void C_fcall trf_7980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7980(t0,t1);}

C_noret_decl(trf_7944)
static void C_fcall trf_7944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7944(t0,t1);}

C_noret_decl(trf_7922)
static void C_fcall trf_7922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7922(t0,t1);}

C_noret_decl(trf_7917)
static void C_fcall trf_7917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7917(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7917(t0,t1);}

C_noret_decl(trf_7912)
static void C_fcall trf_7912(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7912(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7912(t0,t1);}

C_noret_decl(trf_7723)
static void C_fcall trf_7723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7723(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7723(t0,t1);}

C_noret_decl(trf_6918)
static void C_fcall trf_6918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6918(t0,t1);}

C_noret_decl(trf_6945)
static void C_fcall trf_6945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6945(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6945(t0,t1);}

C_noret_decl(trf_7140)
static void C_fcall trf_7140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7140(t0,t1);}

C_noret_decl(trf_7149)
static void C_fcall trf_7149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7149(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7149(t0,t1);}

C_noret_decl(trf_7546)
static void C_fcall trf_7546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7546(t0,t1);}

C_noret_decl(trf_7513)
static void C_fcall trf_7513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7513(t0,t1);}

C_noret_decl(trf_7481)
static void C_fcall trf_7481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7481(t0,t1);}

C_noret_decl(trf_7446)
static void C_fcall trf_7446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7446(t0,t1);}

C_noret_decl(trf_7376)
static void C_fcall trf_7376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7376(t0,t1);}

C_noret_decl(trf_7331)
static void C_fcall trf_7331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7331(t0,t1);}

C_noret_decl(trf_7299)
static void C_fcall trf_7299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7299(t0,t1);}

C_noret_decl(trf_7267)
static void C_fcall trf_7267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7267(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7267(t0,t1);}

C_noret_decl(trf_7235)
static void C_fcall trf_7235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7235(t0,t1);}

C_noret_decl(trf_7203)
static void C_fcall trf_7203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7203(t0,t1);}

C_noret_decl(trf_7181)
static void C_fcall trf_7181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7181(t0,t1);}

C_noret_decl(trf_6890)
static void C_fcall trf_6890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6890(t0,t1);}

C_noret_decl(trf_5748)
static void C_fcall trf_5748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5748(t0,t1);}

C_noret_decl(trf_5850)
static void C_fcall trf_5850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5850(t0,t1);}

C_noret_decl(trf_5883)
static void C_fcall trf_5883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5883(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5883(t0,t1);}

C_noret_decl(trf_5979)
static void C_fcall trf_5979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5979(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5979(t0,t1);}

C_noret_decl(trf_6611)
static void C_fcall trf_6611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6611(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6611(t0,t1);}

C_noret_decl(trf_6631)
static void C_fcall trf_6631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6631(t0,t1);}

C_noret_decl(trf_6565)
static void C_fcall trf_6565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6565(t0,t1);}

C_noret_decl(trf_6515)
static void C_fcall trf_6515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6515(t0,t1);}

C_noret_decl(trf_6465)
static void C_fcall trf_6465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6465(t0,t1);}

C_noret_decl(trf_6426)
static void C_fcall trf_6426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6426(t0,t1);}

C_noret_decl(trf_6387)
static void C_fcall trf_6387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6387(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6387(t0,t1);}

C_noret_decl(trf_6348)
static void C_fcall trf_6348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6348(t0,t1);}

C_noret_decl(trf_6309)
static void C_fcall trf_6309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6309(t0,t1);}

C_noret_decl(trf_6249)
static void C_fcall trf_6249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6249(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6249(t0,t1);}

C_noret_decl(trf_6210)
static void C_fcall trf_6210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6210(t0,t1);}

C_noret_decl(trf_6174)
static void C_fcall trf_6174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6174(t0,t1);}

C_noret_decl(trf_6138)
static void C_fcall trf_6138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6138(t0,t1);}

C_noret_decl(trf_6102)
static void C_fcall trf_6102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6102(t0,t1);}

C_noret_decl(trf_6066)
static void C_fcall trf_6066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6066(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6066(t0,t1);}

C_noret_decl(trf_6040)
static void C_fcall trf_6040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6040(t0,t1,t2);}

C_noret_decl(trf_6031)
static void C_fcall trf_6031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6031(t0,t1,t2);}

C_noret_decl(trf_6026)
static void C_fcall trf_6026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6026(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6026(t0,t1);}

C_noret_decl(trf_5678)
static void C_fcall trf_5678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5678(t0,t1,t2);}

C_noret_decl(trf_5673)
static void C_fcall trf_5673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5673(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5673(t0,t1);}

C_noret_decl(trf_5212)
static void C_fcall trf_5212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5212(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5212(t0,t1);}

C_noret_decl(trf_5221)
static void C_fcall trf_5221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5221(t0,t1);}

C_noret_decl(trf_5233)
static void C_fcall trf_5233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5233(t0,t1);}

C_noret_decl(trf_5245)
static void C_fcall trf_5245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5245(t0,t1);}

C_noret_decl(trf_5285)
static void C_fcall trf_5285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5285(t0,t1);}

C_noret_decl(trf_4889)
static void C_fcall trf_4889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4889(t0,t1);}

C_noret_decl(trf_4761)
static void C_fcall trf_4761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4761(t0,t1,t2);}

C_noret_decl(trf_4790)
static void C_fcall trf_4790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4790(t0,t1);}

C_noret_decl(trf_4793)
static void C_fcall trf_4793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4793(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4793(t0,t1);}

C_noret_decl(trf_4777)
static void C_fcall trf_4777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4777(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4777(t0,t1);}

C_noret_decl(trf_4697)
static void C_fcall trf_4697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4697(t0,t1,t2);}

C_noret_decl(trf_3899)
static void C_fcall trf_3899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3899(t0,t1);}

C_noret_decl(trf_3927)
static void C_fcall trf_3927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3927(t0,t1);}

C_noret_decl(trf_4545)
static void C_fcall trf_4545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4545(t0,t1);}

C_noret_decl(trf_3993)
static void C_fcall trf_3993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3993(t0,t1);}

C_noret_decl(trf_4507)
static void C_fcall trf_4507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4507(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4507(t0,t1,t2,t3);}

C_noret_decl(trf_4450)
static void C_fcall trf_4450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4450(t0,t1);}

C_noret_decl(trf_4471)
static void C_fcall trf_4471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4471(t0,t1);}

C_noret_decl(trf_4414)
static void C_fcall trf_4414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4414(t0,t1);}

C_noret_decl(trf_4381)
static void C_fcall trf_4381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4381(t0,t1);}

C_noret_decl(trf_4390)
static void C_fcall trf_4390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4390(t0,t1);}

C_noret_decl(trf_4335)
static void C_fcall trf_4335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4335(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4335(t0,t1);}

C_noret_decl(trf_4025)
static void C_fcall trf_4025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4025(t0,t1);}

C_noret_decl(trf_4085)
static void C_fcall trf_4085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4085(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4085(t0,t1,t2,t3);}

C_noret_decl(trf_3637)
static void C_fcall trf_3637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3637(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3637(t0,t1,t2,t3);}

C_noret_decl(trf_3466)
static void C_fcall trf_3466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3466(t0,t1);}

C_noret_decl(trf_3472)
static void C_fcall trf_3472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3472(t0,t1,t2,t3);}

C_noret_decl(trf_3668)
static void C_fcall trf_3668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3668(t0,t1,t2,t3);}

C_noret_decl(trf_3675)
static void C_fcall trf_3675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3675(t0,t1);}

C_noret_decl(trf_3764)
static void C_fcall trf_3764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3764(t0,t1);}

C_noret_decl(trf_3503)
static void C_fcall trf_3503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3503(t0,t1);}

C_noret_decl(trf_3810)
static void C_fcall trf_3810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3810(t0,t1,t2);}

C_noret_decl(trf_3825)
static void C_fcall trf_3825(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3825(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3825(t0,t1,t2,t3);}

C_noret_decl(trf_3841)
static void C_fcall trf_3841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3841(t0,t1);}

C_noret_decl(trf_3887)
static void C_fcall trf_3887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3887(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3887(t0,t1,t2,t3);}

C_noret_decl(trf_3180)
static void C_fcall trf_3180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3180(t0,t1);}

C_noret_decl(trf_3366)
static void C_fcall trf_3366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3366(t0,t1);}

C_noret_decl(trf_3369)
static void C_fcall trf_3369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3369(t0,t1);}

C_noret_decl(trf_3415)
static void C_fcall trf_3415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3415(t0,t1);}

C_noret_decl(trf_3219)
static void C_fcall trf_3219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3219(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3219(t0,t1,t2);}

C_noret_decl(trf_3183)
static void C_fcall trf_3183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3183(t0,t1);}

C_noret_decl(trf_3196)
static void C_fcall trf_3196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3196(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3196(t0,t1,t2,t3);}

C_noret_decl(trf_2929)
static void C_fcall trf_2929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2929(t0,t1);}

C_noret_decl(trf_2967)
static void C_fcall trf_2967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2967(t0,t1);}

C_noret_decl(trf_2988)
static void C_fcall trf_2988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2988(t0,t1);}

C_noret_decl(trf_3053)
static void C_fcall trf_3053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3053(t0,t1);}

C_noret_decl(trf_2780)
static void C_fcall trf_2780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2780(t0,t1);}

C_noret_decl(trf_2801)
static void C_fcall trf_2801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2801(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2801(t0,t1,t2,t3);}

C_noret_decl(trf_2870)
static void C_fcall trf_2870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2870(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2870(t0,t1,t2);}

C_noret_decl(trf_2843)
static void C_fcall trf_2843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2843(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2843(t0,t1,t2);}

C_noret_decl(trf_2614)
static void C_fcall trf_2614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2614(t0,t1);}

C_noret_decl(trf_2640)
static void C_fcall trf_2640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2640(t0,t1);}

C_noret_decl(trf_2617)
static void C_fcall trf_2617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2617(t0,t1);}

C_noret_decl(trf_1187)
static void C_fcall trf_1187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1187(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1187(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2582)
static void C_fcall trf_2582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2582(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2582(t0,t1,t2,t3);}

C_noret_decl(trf_1190)
static void C_fcall trf_1190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1190(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1190(t0,t1,t2,t3);}

C_noret_decl(trf_2483)
static void C_fcall trf_2483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2483(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2483(t0,t1,t2,t3);}

C_noret_decl(trf_1834)
static void C_fcall trf_1834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1834(t0,t1);}

C_noret_decl(trf_1840)
static void C_fcall trf_1840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1840(t0,t1);}

C_noret_decl(trf_1991)
static void C_fcall trf_1991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1991(t0,t1);}

C_noret_decl(trf_1372)
static void C_fcall trf_1372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1372(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1372(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1145)
static void C_fcall trf_1145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1145(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1145(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2336)){
C_save(t1);
C_rereclaim2(2336*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,814);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],15,"\010compileroutput");
lf[2]=C_h_intern(&lf[2],12,"\010compilergen");
lf[3]=C_h_intern(&lf[3],7,"newline");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],17,"\010compilergen-list");
lf[7]=C_h_intern(&lf[7],11,"intersperse");
lf[8]=C_h_intern(&lf[8],18,"\010compilerunique-id");
lf[9]=C_h_intern(&lf[9],22,"\010compilergenerate-code");
lf[10]=C_h_intern(&lf[10],13,"\010compilerbomb");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[12]=C_h_intern(&lf[12],17,"lambda-literal-id");
lf[13]=C_h_intern(&lf[13],4,"find");
lf[14]=C_h_intern(&lf[14],14,"\004coreimmediate");
lf[15]=C_h_intern(&lf[15],4,"bool");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[18]=C_h_intern(&lf[18],4,"char");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[20]=C_h_intern(&lf[20],3,"nil");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[22]=C_h_intern(&lf[22],3,"fix");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[24]=C_h_intern(&lf[24],3,"eof");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[27]=C_h_intern(&lf[27],12,"\004coreliteral");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[31]=C_h_intern(&lf[31],2,"if");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[35]=C_h_intern(&lf[35],9,"\004coreproc");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[37]=C_h_intern(&lf[37],9,"\004corebind");
lf[38]=C_h_intern(&lf[38],8,"\004coreref");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[41]=C_h_intern(&lf[41],10,"\004coreunbox");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[44]=C_h_intern(&lf[44],13,"\004coreupdate_i");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[46]=C_h_intern(&lf[46],11,"\004coreupdate");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[50]=C_h_intern(&lf[50],16,"\004coreupdatebox_i");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[53]=C_h_intern(&lf[53],14,"\004coreupdatebox");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[56]=C_h_intern(&lf[56],12,"\004coreclosure");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[61]=C_h_intern(&lf[61],8,"for-each");
lf[62]=C_h_intern(&lf[62],4,"iota");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[64]=C_h_intern(&lf[64],8,"\004corebox");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[67]=C_h_intern(&lf[67],10,"\004corelocal");
lf[68]=C_h_intern(&lf[68],13,"\004coresetlocal");
lf[69]=C_h_intern(&lf[69],11,"\004coreglobal");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[74]=C_h_intern(&lf[74],21,"\010compilerc-ify-string");
lf[75]=C_h_intern(&lf[75],14,"symbol->string");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[80]=C_h_intern(&lf[80],14,"\004coresetglobal");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1,");
lf[85]=C_h_intern(&lf[85],16,"\004coresetglobal_i");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\004],0,");
lf[90]=C_h_intern(&lf[90],14,"\004coreundefined");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[92]=C_h_intern(&lf[92],9,"\004corecall");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[98]=C_h_intern(&lf[98],26,"lambda-literal-temporaries");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_h_intern(&lf[100],22,"lambda-literal-looping");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[104]=C_h_intern(&lf[104],6,"unsafe");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[109]=C_h_intern(&lf[109],19,"no-procedure-checks");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[112]=C_h_intern(&lf[112],24,"\010compileremit-trace-info");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[115]=C_h_intern(&lf[115],16,"string-translate");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[118]=C_h_intern(&lf[118],8,"->string");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[121]=C_h_intern(&lf[121],17,"string-translate*");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[123]=C_h_intern(&lf[123],27,"lambda-literal-closure-size");
lf[124]=C_h_intern(&lf[124],28,"\010compilersource-info->string");
lf[125]=C_h_intern(&lf[125],12,"\004corerecurse");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[129]=C_h_intern(&lf[129],16,"\004coredirect_call");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[131]=C_h_intern(&lf[131],13,"\004corecallunit");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[136]=C_h_intern(&lf[136],11,"\004corereturn");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[139]=C_h_intern(&lf[139],11,"\004coreinline");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[141]=C_h_intern(&lf[141],20,"\004coreinline_allocate");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[144]=C_h_intern(&lf[144],15,"\004coreinline_ref");
lf[145]=C_h_intern(&lf[145],34,"\010compilerforeign-result-conversion");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[147]=C_h_intern(&lf[147],18,"\004coreinline_update");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[150]=C_h_intern(&lf[150],36,"\010compilerforeign-argument-conversion");
lf[151]=C_h_intern(&lf[151],33,"\010compilerforeign-type-declaration");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_h_intern(&lf[153],19,"\004coreinline_loc_ref");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[159]=C_h_intern(&lf[159],22,"\004coreinline_loc_update");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_h_intern(&lf[165],11,"\004coreswitch");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[170]=C_h_intern(&lf[170],9,"\004corecond");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[174]=C_h_intern(&lf[174],13,"pair-for-each");
lf[175]=C_h_intern(&lf[175],13,"string-append");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[177]=C_h_intern(&lf[177],30,"\010compilerexternal-protos-first");
lf[178]=C_h_intern(&lf[178],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[179]=C_h_intern(&lf[179],22,"foreign-callback-stubs");
lf[180]=C_h_intern(&lf[180],29,"\010compilerforeign-declarations");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[183]=C_h_intern(&lf[183],28,"\010compilertarget-include-file");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[185]=C_h_intern(&lf[185],18,"\010compilerunit-name");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[187]=C_h_intern(&lf[187],19,"\010compilerused-units");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[189]=C_h_intern(&lf[189],27,"\010compilercompiler-arguments");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[195]=C_h_intern(&lf[195],18,"string-intersperse");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[199]=C_h_intern(&lf[199],7,"\003sysmap");
lf[200]=C_h_intern(&lf[200],12,"string-split");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[202]=C_h_intern(&lf[202],15,"chicken-version");
lf[203]=C_h_intern(&lf[203],15,"\003sysmatch-error");
lf[204]=C_h_intern(&lf[204],18,"\003sysdecode-seconds");
lf[205]=C_h_intern(&lf[205],15,"current-seconds");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[210]=C_h_intern(&lf[210],23,"\003syslambda-info->string");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[220]=C_h_intern(&lf[220],9,"make-list");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[224]=C_h_intern(&lf[224],4,"none");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[235]=C_h_intern(&lf[235],8,"toplevel");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[238]=C_h_intern(&lf[238],27,"\010compileremit-unsafe-marker");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[251]=C_h_intern(&lf[251],21,"small-parameter-limit");
lf[252]=C_h_intern(&lf[252],11,"lset-adjoin");
lf[253]=C_h_intern(&lf[253],1,"=");
lf[254]=C_h_intern(&lf[254],32,"lambda-literal-callee-signatures");
lf[255]=C_h_intern(&lf[255],24,"lambda-literal-allocated");
lf[256]=C_h_intern(&lf[256],21,"lambda-literal-direct");
lf[257]=C_h_intern(&lf[257],33,"lambda-literal-rest-argument-mode");
lf[258]=C_h_intern(&lf[258],28,"lambda-literal-rest-argument");
lf[259]=C_h_intern(&lf[259],27,"\010compilermake-variable-list");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[261]=C_h_intern(&lf[261],27,"lambda-literal-customizable");
lf[262]=C_h_intern(&lf[262],29,"lambda-literal-argument-count");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[269]=C_h_intern(&lf[269],27,"\010compilermake-argument-list");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[309]=C_h_intern(&lf[309],6,"vector");
lf[310]=C_h_intern(&lf[310],23,"lambda-literal-external");
lf[311]=C_h_intern(&lf[311],14,"\003syscopy-bytes");
lf[312]=C_h_intern(&lf[312],11,"make-string");
lf[313]=C_h_intern(&lf[313],6,"modulo");
lf[314]=C_h_intern(&lf[314],3,"fx/");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[328]=C_h_intern(&lf[328],23,"\010compilerencode-literal");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[330]=C_h_intern(&lf[330],32,"\010compilerblock-variable-literal\077");
lf[331]=C_h_intern(&lf[331],20,"\010compilerbig-fixnum\077");
lf[332]=C_h_intern(&lf[332],7,"sprintf");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[334]=C_h_intern(&lf[334],25,"\010compilerwords-per-flonum");
lf[335]=C_h_intern(&lf[335],6,"reduce");
lf[336]=C_h_intern(&lf[336],1,"+");
lf[337]=C_h_intern(&lf[337],12,"vector->list");
lf[338]=C_h_intern(&lf[338],14,"\010compilerwords");
lf[339]=C_h_intern(&lf[339],15,"\003sysbytevector\077");
lf[340]=C_h_intern(&lf[340],19,"\010compilerimmediate\077");
lf[341]=C_h_intern(&lf[341],19,"lambda-literal-body");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[354]=C_h_intern(&lf[354],4,"list");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[393]=C_h_intern(&lf[393],26,"\010compilertarget-stack-size");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[396]=C_h_intern(&lf[396],30,"\010compilertarget-heap-shrinkage");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[398]=C_h_intern(&lf[398],27,"\010compilertarget-heap-growth");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[400]=C_h_intern(&lf[400],33,"\010compilertarget-initial-heap-size");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[403]=C_h_intern(&lf[403],25,"\010compilertarget-heap-size");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[407]=C_h_intern(&lf[407],40,"\010compilerdisable-stack-overflow-checking");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[413]=C_h_intern(&lf[413],4,"fold");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[416]=C_h_intern(&lf[416],28,"\010compilerinsert-timer-checks");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[421]=C_h_intern(&lf[421],14,"no-argc-checks");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[468]=C_h_intern(&lf[468],16,"\010compilercleanup");
lf[469]=C_h_intern(&lf[469],18,"\010compilerdebugging");
lf[470]=C_h_intern(&lf[470],1,"o");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[476]=C_h_intern(&lf[476],18,"\010compilerreal-name");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[478]=C_h_intern(&lf[478],25,"emit-procedure-table-info");
lf[479]=C_h_intern(&lf[479],31,"generate-foreign-callback-stubs");
lf[480]=C_h_intern(&lf[480],31,"\010compilergenerate-foreign-stubs");
lf[481]=C_h_intern(&lf[481],29,"\010compilerforeign-lambda-stubs");
lf[482]=C_h_intern(&lf[482],36,"\010compilergenerate-external-variables");
lf[483]=C_h_intern(&lf[483],27,"\010compilerexternal-variables");
lf[484]=C_h_intern(&lf[484],1,"p");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[505]=C_h_intern(&lf[505],11,"string-copy");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[507]=C_h_intern(&lf[507],13,"list-tabulate");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[510]=C_h_intern(&lf[510],41,"\010compilergenerate-foreign-callback-header");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[523]=C_h_intern(&lf[523],4,"void");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[548]=C_h_intern(&lf[548],21,"foreign-stub-callback");
lf[549]=C_h_intern(&lf[549],16,"foreign-stub-cps");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_h_intern(&lf[551],27,"foreign-stub-argument-names");
lf[552]=C_h_intern(&lf[552],17,"foreign-stub-body");
lf[553]=C_h_intern(&lf[553],17,"foreign-stub-name");
lf[554]=C_h_intern(&lf[554],24,"foreign-stub-return-type");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[557]=C_h_intern(&lf[557],27,"foreign-stub-argument-types");
lf[558]=C_h_intern(&lf[558],19,"\010compilerreal-name2");
lf[559]=C_h_intern(&lf[559],15,"foreign-stub-id");
lf[560]=C_h_intern(&lf[560],5,"float");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[562]=C_h_intern(&lf[562],8,"c-string");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[566]=C_h_intern(&lf[566],16,"nonnull-c-string");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[569]=C_h_intern(&lf[569],3,"ref");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[571]=C_h_intern(&lf[571],5,"const");
lf[572]=C_h_intern(&lf[572],7,"pointer");
lf[573]=C_h_intern(&lf[573],9,"c-pointer");
lf[574]=C_h_intern(&lf[574],15,"nonnull-pointer");
lf[575]=C_h_intern(&lf[575],17,"nonnull-c-pointer");
lf[576]=C_h_intern(&lf[576],8,"function");
lf[577]=C_h_intern(&lf[577],8,"instance");
lf[578]=C_h_intern(&lf[578],16,"nonnull-instance");
lf[579]=C_h_intern(&lf[579],12,"instance-ref");
lf[580]=C_h_intern(&lf[580],18,"\003syshash-table-ref");
lf[581]=C_h_intern(&lf[581],27,"\010compilerforeign-type-table");
lf[582]=C_h_intern(&lf[582],17,"nonnull-c-string*");
lf[583]=C_h_intern(&lf[583],25,"nonnull-unsigned-c-string");
lf[584]=C_h_intern(&lf[584],26,"nonnull-unsigned-c-string*");
lf[585]=C_h_intern(&lf[585],6,"symbol");
lf[586]=C_h_intern(&lf[586],9,"c-string*");
lf[587]=C_h_intern(&lf[587],17,"unsigned-c-string");
lf[588]=C_h_intern(&lf[588],18,"unsigned-c-string*");
lf[589]=C_h_intern(&lf[589],6,"double");
lf[590]=C_h_intern(&lf[590],16,"unsigned-integer");
lf[591]=C_h_intern(&lf[591],18,"unsigned-integer32");
lf[592]=C_h_intern(&lf[592],4,"long");
lf[593]=C_h_intern(&lf[593],7,"integer");
lf[594]=C_h_intern(&lf[594],9,"integer32");
lf[595]=C_h_intern(&lf[595],13,"unsigned-long");
lf[596]=C_h_intern(&lf[596],6,"number");
lf[597]=C_h_intern(&lf[597],9,"integer64");
lf[598]=C_h_intern(&lf[598],13,"c-string-list");
lf[599]=C_h_intern(&lf[599],14,"c-string-list*");
lf[600]=C_h_intern(&lf[600],3,"int");
lf[601]=C_h_intern(&lf[601],5,"int32");
lf[602]=C_h_intern(&lf[602],5,"short");
lf[603]=C_h_intern(&lf[603],14,"unsigned-short");
lf[604]=C_h_intern(&lf[604],13,"scheme-object");
lf[605]=C_h_intern(&lf[605],13,"unsigned-char");
lf[606]=C_h_intern(&lf[606],12,"unsigned-int");
lf[607]=C_h_intern(&lf[607],14,"unsigned-int32");
lf[608]=C_h_intern(&lf[608],4,"byte");
lf[609]=C_h_intern(&lf[609],13,"unsigned-byte");
lf[610]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[611]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[612]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[613]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[614]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[625]=C_h_intern(&lf[625],36,"foreign-callback-stub-argument-types");
lf[626]=C_h_intern(&lf[626],33,"foreign-callback-stub-return-type");
lf[627]=C_h_intern(&lf[627],24,"foreign-callback-stub-id");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[630]=C_h_intern(&lf[630],32,"foreign-callback-stub-qualifiers");
lf[631]=C_h_intern(&lf[631],26,"foreign-callback-stub-name");
lf[632]=C_h_intern(&lf[632],4,"quit");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[652]=C_h_intern(&lf[652],11,"byte-vector");
lf[653]=C_h_intern(&lf[653],19,"nonnull-byte-vector");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[655]=C_h_intern(&lf[655],4,"blob");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[657]=C_h_intern(&lf[657],9,"u16vector");
lf[658]=C_h_intern(&lf[658],17,"nonnull-u16vector");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[660]=C_h_intern(&lf[660],8,"s8vector");
lf[661]=C_h_intern(&lf[661],16,"nonnull-s8vector");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[663]=C_h_intern(&lf[663],9,"u32vector");
lf[664]=C_h_intern(&lf[664],17,"nonnull-u32vector");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[666]=C_h_intern(&lf[666],9,"s16vector");
lf[667]=C_h_intern(&lf[667],17,"nonnull-s16vector");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[669]=C_h_intern(&lf[669],9,"s32vector");
lf[670]=C_h_intern(&lf[670],17,"nonnull-s32vector");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[672]=C_h_intern(&lf[672],9,"f32vector");
lf[673]=C_h_intern(&lf[673],17,"nonnull-f32vector");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[675]=C_h_intern(&lf[675],9,"f64vector");
lf[676]=C_h_intern(&lf[676],17,"nonnull-f64vector");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[683]=C_h_intern(&lf[683],8,"template");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[690]=C_h_intern(&lf[690],6,"struct");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[693]=C_h_intern(&lf[693],5,"union");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[696]=C_h_intern(&lf[696],4,"enum");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[705]=C_h_intern(&lf[705],3,"...");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_h_intern(&lf[709],12,"nonnull-blob");
lf[710]=C_h_intern(&lf[710],8,"u8vector");
lf[711]=C_h_intern(&lf[711],16,"nonnull-u8vector");
lf[712]=C_h_intern(&lf[712],14,"scheme-pointer");
lf[713]=C_h_intern(&lf[713],22,"nonnull-scheme-pointer");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[808]=C_h_intern(&lf[808],17,"\003sysstring-append");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[810]=C_h_intern(&lf[810],5,"cons*");
lf[811]=C_h_intern(&lf[811],29,"\010compilerstring->c-identifier");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[813]=C_h_intern(&lf[813],6,"random");
C_register_lf2(lf,814,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1087 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1090 in k1087 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1093 in k1090 in k1087 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_set_block_item(lf[1],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1101,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1122,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8795,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8799,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 100  random */
t9=C_retrieve(lf[813]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_fix(16777216));}

/* k8797 in k1093 in k1090 in k1087 */
static void C_ccall f_8799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8803,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 100  current-seconds */
t3=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8801 in k8797 in k1093 in k1090 in k1087 */
static void C_ccall f_8803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 100  sprintf */
t2=C_retrieve(lf[332]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[812],((C_word*)t0)[2],t1);}

/* k8793 in k1093 in k1090 in k1087 */
static void C_ccall f_8795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 99   string->c-identifier */
t2=C_retrieve(lf[811]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1142,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4679,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[468]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4752,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[259]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4841,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4857,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[482]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4873,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4924,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[480]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4942,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[479]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5175,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[510]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5606,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5671,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6888,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7721,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8495,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[51],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8495,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8498,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8501,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8504,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8557,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t7)){
t8=t6;
f_8557(2,t8,lf[795]);}
else{
t8=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t8)){
t9=t6;
f_8557(2,t9,lf[796]);}
else{
if(C_truep((C_word)C_charp(t2))){
t9=(C_word)C_fix((C_word)C_character_code(t2));
t10=f_8504(C_a_i(&a,4),t9);
/* c-backend.scm: 1355 string-append */
t11=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[797],t10);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t9=t6;
f_8557(2,t9,lf[798]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t9=t6;
f_8557(2,t9,lf[799]);}
else{
t9=C_retrieve(lf[0]);
t10=(C_word)C_eqp(t9,t2);
if(C_truep(t10)){
t11=t6;
f_8557(2,t11,lf[800]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8675,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1360 big-fixnum? */
t12=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8688,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1369 number->string */
C_number_to_string(3,0,t11,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t11=(C_word)C_slot(t2,C_fix(1));
t12=(C_word)C_i_string_length(t11);
t13=f_8504(C_a_i(&a,4),t12);
/* c-backend.scm: 1372 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t6,lf[806],t13,t11);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1377 bomb */
t11=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[807],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8727,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t12=f_8498(t2);
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_string(&a,1,t13);
t15=f_8501(t2);
t16=f_8504(C_a_i(&a,4),t15);
/* c-backend.scm: 1380 string-append */
t17=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,t11,t14,t16);}
else{
t11=f_8501(t2);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8757,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=f_8498(t2);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8504(C_a_i(&a,4),t11);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8769,a[2]=t16,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8771,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1390 list-tabulate */
t19=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t11,t18);}}}}}}}}}}}}

/* a8770 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8771,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1390 encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k8767 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1387 cons* */
t2=C_retrieve(lf[810]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8755 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1386 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[809]);}

/* k8725 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1379 ##sys#string-append */
t2=C_retrieve(lf[808]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8686 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1369 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[804],t1,lf[805]);}

/* k8673 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8675,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8671,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1367 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1361 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[3],lf[803],t13);}}

/* k8669 in k8673 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1367 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[801],t1,lf[802]);}

/* k8555 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8557,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1351 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static C_word C_fcall f_8504(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* getsize in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static C_word C_fcall f_8501(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1050(C_SCHEME_UNDEFINED,t1));}

/* getbits in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static C_word C_fcall f_8498(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1046(C_SCHEME_UNDEFINED,t1));}

/* ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_7721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7721,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7723,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[769]);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[601]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[770]);}
else{
t10=(C_word)C_eqp(t5,lf[606]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[607]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[771]);}
else{
t12=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[772]);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[773]);}
else{
t14=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[774]);}
else{
t15=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[775]);}
else{
t16=(C_word)C_eqp(t5,lf[560]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[589]));
if(C_truep(t17)){
/* c-backend.scm: 1289 sprintf */
t18=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[776],t3);}
else{
t18=(C_word)C_eqp(t5,lf[596]);
if(C_truep(t18)){
/* c-backend.scm: 1290 sprintf */
t19=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[777],t3);}
else{
t19=(C_word)C_eqp(t5,lf[566]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7808,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_7808(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[562]);
if(C_truep(t21)){
t22=t20;
f_7808(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[575]);
if(C_truep(t22)){
t23=t20;
f_7808(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[586]);
if(C_truep(t23)){
t24=t20;
f_7808(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[582]);
if(C_truep(t24)){
t25=t20;
f_7808(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[587]);
if(C_truep(t25)){
t26=t20;
f_7808(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t26)){
t27=t20;
f_7808(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[583]);
if(C_truep(t27)){
t28=t20;
f_7808(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t28)){
t29=t20;
f_7808(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[585]);
if(C_truep(t29)){
t30=t20;
f_7808(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[598]);
t31=t20;
f_7808(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[599])));}}}}}}}}}}}}}}}}}}}}

/* k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7808,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1294 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[778],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t2)){
/* c-backend.scm: 1295 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[779],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t4)){
/* c-backend.scm: 1296 sprintf */
t5=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[780],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t5)){
/* c-backend.scm: 1297 sprintf */
t6=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[781],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
/* c-backend.scm: 1298 sprintf */
t8=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[782],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t8)){
/* c-backend.scm: 1299 sprintf */
t9=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[783],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t9)){
/* c-backend.scm: 1300 sprintf */
t10=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[784],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[785]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[523]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[604]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[786]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1304 ##sys#hash-table-ref */
t14=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t14=t13;
f_7889(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7889,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1306 foreign-result-conversion */
t4=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7917,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7922,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7944,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7944(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7944(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[575]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7980,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7980(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7980(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[569]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8016,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_8016(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_8016(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8051,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_8051(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_8051(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_8051(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8099,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_8099(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_8099(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_8099(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[579]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8147,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t21=t17;
f_8147(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_8147(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_8147(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8195,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_8195(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_8195(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[572]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8230,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_8230(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_8230(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[573]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8266,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_8266(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_8266(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[3]);
t24=(C_word)C_eqp(t23,lf[576]);
if(C_truep(t24)){
t25=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=(C_word)C_i_cadr(((C_word*)t0)[3]);
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* c-backend.scm: 1308 sprintf */
t28=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t28))(4,t28,((C_word*)t0)[5],lf[793],((C_word*)t0)[4]);}
else{
/* c-backend.scm: 1308 g1021 */
t26=t2;
f_7912(t26,((C_word*)t0)[5]);}}
else{
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8324,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(((C_word*)t0)[3]);
t27=(C_word)C_eqp(t26,lf[696]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[3]);
t30=t25;
f_8324(t30,(C_word)C_i_nullp(t29));}
else{
t29=t25;
f_8324(t29,C_SCHEME_FALSE);}}
else{
t28=t25;
f_8324(t28,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1308 g1021 */
t5=t2;
f_7912(t5,((C_word*)t0)[5]);}}
else{
/* c-backend.scm: 1325 err */
t2=((C_word*)t0)[2];
f_7723(t2,((C_word*)t0)[5]);}}}

/* k8322 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[794],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[4]);}}

/* k8264 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8266(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1018 */
t3=((C_word*)t0)[4];
f_7917(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[3]);}}

/* k8228 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1018 */
t3=((C_word*)t0)[4];
f_7917(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[3]);}}

/* k8193 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[4]);}}

/* k8145 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8147(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[792],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[4]);}}

/* k8097 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[791],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[4]);}}

/* k8049 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[790],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[4]);}}

/* k8014 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1312 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[789],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[4]);}}

/* k7978 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1012 */
t3=((C_word*)t0)[4];
f_7922(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[3]);}}

/* k7942 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1012 */
t3=((C_word*)t0)[4];
f_7922(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7912(t2,((C_word*)t0)[3]);}}

/* g1012 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7922,NULL,2,t0,t1);}
/* c-backend.scm: 1310 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[788],((C_word*)t0)[2]);}

/* g1018 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7917(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7917,NULL,2,t0,t1);}
/* c-backend.scm: 1321 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[787],((C_word*)t0)[2]);}

/* g1021 in k7887 in k7806 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7912(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7912,NULL,2,t0,t1);}
/* c-backend.scm: 1324 err */
t2=((C_word*)t0)[2];
f_7723(t2,t1);}

/* err in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7723(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7723,NULL,2,t0,t1);}
/* c-backend.scm: 1280 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[768],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6888,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6890,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[604]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[715]);}
else{
t6=(C_word)C_eqp(t4,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[716]);}
else{
t8=(C_word)C_eqp(t4,lf[608]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6918,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_6918(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[600]);
if(C_truep(t10)){
t11=t9;
f_6918(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[606]);
if(C_truep(t11)){
t12=t9;
f_6918(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[607]);
t13=t9;
f_6918(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[609])));}}}}}}

/* k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6918,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[717]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[718]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[603]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[719]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[720]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6945(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
t8=t6;
f_6945(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[560])));}}}}}}

/* k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6945(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6945,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[721]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[722]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[723]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[724]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[725]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[572]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[726]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[574]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[727]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[712]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[728]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[713]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[729]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[730]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[575]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[731]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[655]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[732]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[709]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[733]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[652]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[734]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[653]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[735]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[710]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[736]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[711]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[737]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[657]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[738]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[739]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[663]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[740]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[664]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[741]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[660]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[742]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[661]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[743]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[666]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[744]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[667]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[745]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[669]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[746]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[670]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[747]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[748]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[673]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[749]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[750]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[676]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[751]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[562]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_7140(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[586]);
if(C_truep(t36)){
t37=t35;
f_7140(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
t38=t35;
f_7140(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[588])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7140,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[752]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7149(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_7149(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_7149(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_7149(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7149(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7149,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[753]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[754]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1256 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7158(2,t4,C_SCHEME_FALSE);}}}}

/* k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7158,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1258 foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7181,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(t3,lf[572]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7203,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[3]);
t8=t5;
f_7203(t8,(C_word)C_i_nullp(t7));}
else{
t7=t5;
f_7203(t7,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7235,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7235(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7235(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[573]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7267,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7267(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7267(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[575]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7299,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7299(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7299(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7331,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_7331(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7331(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7331(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7376,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_7376(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_7376(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_7376(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[576]);
if(C_truep(t16)){
t17=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cadr(((C_word*)t0)[3]);
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
t20=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[761]);}
else{
/* c-backend.scm: 1260 g948 */
t18=t2;
f_7181(t18,((C_word*)t0)[4]);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7446,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_7446(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_7446(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[696]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7481,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_7481(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_7481(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[569]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7513,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_7513(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_7513(t25,C_SCHEME_FALSE);}}
else{
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7546,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_car(((C_word*)t0)[3]);
t25=(C_word)C_eqp(t24,lf[579]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t29=t23;
f_7546(t29,(C_word)C_i_nullp(t28));}
else{
t28=t23;
f_7546(t28,C_SCHEME_FALSE);}}
else{
t27=t23;
f_7546(t27,C_SCHEME_FALSE);}}
else{
t26=t23;
f_7546(t26,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1260 g948 */
t3=t2;
f_7181(t3,((C_word*)t0)[4]);}}
else{
/* c-backend.scm: 1274 err */
t2=((C_word*)t0)[2];
f_6890(t2,((C_word*)t0)[4]);}}}

/* k7544 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 1260 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],lf[766],t2,lf[767]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7511 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7513,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7523,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1260 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[765]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7521 in k7511 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_7523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1260 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[763],t1,lf[764]);}

/* k7479 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[762]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7444 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1260 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7374 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[760]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7329 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[759]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7297 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[758]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7265 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7267(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[757]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7233 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[756]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* k7201 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[755]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7181(t2,((C_word*)t0)[3]);}}

/* g948 in k7156 in k7147 in k7138 in k6943 in k6916 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7181,NULL,2,t0,t1);}
/* c-backend.scm: 1273 err */
t2=((C_word*)t0)[2];
f_6890(t2,t1);}

/* err in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6890,NULL,2,t0,t1);}
/* c-backend.scm: 1210 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[714],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5671,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5673,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5678,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[604]);
if(C_truep(t7)){
/* c-backend.scm: 1130 str */
t8=t5;
f_5678(t8,t1,lf[635]);}
else{
t8=(C_word)C_eqp(t6,lf[18]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[608]));
if(C_truep(t9)){
/* c-backend.scm: 1131 str */
t10=t5;
f_5678(t10,t1,lf[636]);}
else{
t10=(C_word)C_eqp(t6,lf[605]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[609]));
if(C_truep(t11)){
/* c-backend.scm: 1132 str */
t12=t5;
f_5678(t12,t1,lf[637]);}
else{
t12=(C_word)C_eqp(t6,lf[606]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[590]));
if(C_truep(t13)){
/* c-backend.scm: 1133 str */
t14=t5;
f_5678(t14,t1,lf[638]);}
else{
t14=(C_word)C_eqp(t6,lf[607]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[591]));
if(C_truep(t15)){
/* c-backend.scm: 1134 str */
t16=t5;
f_5678(t16,t1,lf[639]);}
else{
t16=(C_word)C_eqp(t6,lf[600]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5748,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5748(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[593]);
t19=t17;
f_5748(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[15])));}}}}}}}

/* k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5748,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1135 str */
t2=((C_word*)t0)[7];
f_5678(t2,((C_word*)t0)[6],lf[640]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[594]));
if(C_truep(t3)){
/* c-backend.scm: 1136 str */
t4=((C_word*)t0)[7];
f_5678(t4,((C_word*)t0)[6],lf[641]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t4)){
/* c-backend.scm: 1137 str */
t5=((C_word*)t0)[7];
f_5678(t5,((C_word*)t0)[6],lf[642]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t5)){
/* c-backend.scm: 1138 str */
t6=((C_word*)t0)[7];
f_5678(t6,((C_word*)t0)[6],lf[643]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t6)){
/* c-backend.scm: 1139 str */
t7=((C_word*)t0)[7];
f_5678(t7,((C_word*)t0)[6],lf[644]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
if(C_truep(t7)){
/* c-backend.scm: 1140 str */
t8=((C_word*)t0)[7];
f_5678(t8,((C_word*)t0)[6],lf[645]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t8)){
/* c-backend.scm: 1141 str */
t9=((C_word*)t0)[7];
f_5678(t9,((C_word*)t0)[6],lf[646]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
if(C_truep(t9)){
/* c-backend.scm: 1142 str */
t10=((C_word*)t0)[7];
f_5678(t10,((C_word*)t0)[6],lf[647]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t11)){
/* c-backend.scm: 1143 str */
t12=((C_word*)t0)[7];
f_5678(t12,((C_word*)t0)[6],lf[648]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[572]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[574]));
if(C_truep(t13)){
/* c-backend.scm: 1145 str */
t14=((C_word*)t0)[7];
f_5678(t14,((C_word*)t0)[6],lf[649]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_5850(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t16)){
t17=t15;
f_5850(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[712]);
t18=t15;
f_5850(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[713])));}}}}}}}}}}}}}

/* k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5850,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1146 str */
t2=((C_word*)t0)[7];
f_5678(t2,((C_word*)t0)[6],lf[650]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[599]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[651]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[652]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[653]));
if(C_truep(t5)){
/* c-backend.scm: 1149 str */
t6=((C_word*)t0)[7];
f_5678(t6,((C_word*)t0)[6],lf[654]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[655]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5883(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[709]);
if(C_truep(t8)){
t9=t7;
f_5883(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[710]);
t10=t7;
f_5883(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[711])));}}}}}}

/* k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5883(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5883,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1150 str */
t2=((C_word*)t0)[7];
f_5678(t2,((C_word*)t0)[6],lf[656]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[657]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[658]));
if(C_truep(t3)){
/* c-backend.scm: 1151 str */
t4=((C_word*)t0)[7];
f_5678(t4,((C_word*)t0)[6],lf[659]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[660]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[661]));
if(C_truep(t5)){
/* c-backend.scm: 1152 str */
t6=((C_word*)t0)[7];
f_5678(t6,((C_word*)t0)[6],lf[662]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[663]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[664]));
if(C_truep(t7)){
/* c-backend.scm: 1153 str */
t8=((C_word*)t0)[7];
f_5678(t8,((C_word*)t0)[6],lf[665]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[666]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[667]));
if(C_truep(t9)){
/* c-backend.scm: 1154 str */
t10=((C_word*)t0)[7];
f_5678(t10,((C_word*)t0)[6],lf[668]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[669]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[670]));
if(C_truep(t11)){
/* c-backend.scm: 1155 str */
t12=((C_word*)t0)[7];
f_5678(t12,((C_word*)t0)[6],lf[671]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[672]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[673]));
if(C_truep(t13)){
/* c-backend.scm: 1156 str */
t14=((C_word*)t0)[7];
f_5678(t14,((C_word*)t0)[6],lf[674]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[675]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[676]));
if(C_truep(t15)){
/* c-backend.scm: 1157 str */
t16=((C_word*)t0)[7];
f_5678(t16,((C_word*)t0)[6],lf[677]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[566]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5979(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
if(C_truep(t18)){
t19=t17;
f_5979(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t19)){
t20=t17;
f_5979(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t20)){
t21=t17;
f_5979(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[583]);
if(C_truep(t21)){
t22=t17;
f_5979(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t22)){
t23=t17;
f_5979(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t24=t17;
f_5979(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[585])));}}}}}}}}}}}}}}}

/* k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5979(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5979,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1160 str */
t2=((C_word*)t0)[7];
f_5678(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t2)){
/* c-backend.scm: 1161 str */
t3=((C_word*)t0)[7];
f_5678(t3,((C_word*)t0)[6],lf[679]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1163 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_5994(2,t4,C_SCHEME_FALSE);}}}}

/* k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5994,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1165 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1166 str */
t2=((C_word*)t0)[3];
f_5678(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6031,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6040,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[572]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6066,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[4]);
t10=t7;
f_6066(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_6066(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[574]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6102,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[4]);
t12=t9;
f_6102(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_6102(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[573]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6138,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[4]);
t14=t11;
f_6138(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_6138(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[575]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6174,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[4]);
t16=t13;
f_6174(t16,(C_word)C_i_nullp(t15));}
else{
t15=t13;
f_6174(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[569]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6210,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[4]);
t18=t15;
f_6210(t18,(C_word)C_i_nullp(t17));}
else{
t17=t15;
f_6210(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[683]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6249,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[4]);
t20=t17;
f_6249(t20,(C_word)C_i_listp(t19));}
else{
t19=t17;
f_6249(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6309,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[4]);
t22=t19;
f_6309(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_6309(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[690]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6348,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6348(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6348(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[693]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6387,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6387(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6387(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[696]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6426,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[4]);
t28=t25;
f_6426(t28,(C_word)C_i_nullp(t27));}
else{
t27=t25;
f_6426(t27,C_SCHEME_FALSE);}}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[577]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6465,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t29))){
t30=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t31=t27;
f_6465(t31,(C_word)C_i_nullp(t30));}
else{
t30=t27;
f_6465(t30,C_SCHEME_FALSE);}}
else{
t29=t27;
f_6465(t29,C_SCHEME_FALSE);}}
else{
t27=(C_word)C_i_car(((C_word*)t0)[4]);
t28=(C_word)C_eqp(t27,lf[578]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6515,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t30))){
t31=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t33=t29;
f_6515(t33,(C_word)C_i_nullp(t32));}
else{
t32=t29;
f_6515(t32,C_SCHEME_FALSE);}}
else{
t31=t29;
f_6515(t31,C_SCHEME_FALSE);}}
else{
t29=(C_word)C_i_car(((C_word*)t0)[4]);
t30=(C_word)C_eqp(t29,lf[579]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6565,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t32))){
t33=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t33))){
t34=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t35=t31;
f_6565(t35,(C_word)C_i_nullp(t34));}
else{
t34=t31;
f_6565(t34,C_SCHEME_FALSE);}}
else{
t33=t31;
f_6565(t33,C_SCHEME_FALSE);}}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6611,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[4]);
t33=(C_word)C_eqp(t32,lf[576]);
if(C_truep(t33)){
t34=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t34))){
t35=(C_word)C_i_cddr(((C_word*)t0)[4]);
t36=t31;
f_6611(t36,(C_word)C_i_pairp(t35));}
else{
t35=t31;
f_6611(t35,C_SCHEME_FALSE);}}
else{
t34=t31;
f_6611(t34,C_SCHEME_FALSE);}}}}}}}}}}}}}}}
else{
/* c-backend.scm: 1168 g871 */
t5=t2;
f_6026(t5,((C_word*)t0)[6]);}}
else{
/* c-backend.scm: 1204 err */
t2=((C_word*)t0)[2];
f_5673(t2,((C_word*)t0)[6]);}}}}

/* k6609 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6611(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6611,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6627,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[708]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[4]);}}

/* k6625 in k6609 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_stringp(t3);
t5=t2;
f_6631(t5,(C_truep(t4)?t3:C_SCHEME_FALSE));}
else{
t4=t2;
f_6631(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6631(t3,C_SCHEME_FALSE);}}

/* k6629 in k6625 in k6609 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6631,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[700]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6638,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6642,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6644,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6643 in k6629 in k6625 in k6609 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6644,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[705],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[706]);}
else{
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[707]);}}

/* k6640 in k6629 in k6625 in k6609 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[704]);}

/* k6636 in k6629 in k6625 in k6609 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[701],((C_word*)t0)[2],lf[702],t1,lf[703]);}

/* k6563 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6565,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6578,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t5=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[4]);}}

/* k6576 in k6563 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[699],((C_word*)t0)[2]);}

/* k6513 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g868 */
t4=((C_word*)t0)[4];
f_6031(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[3]);}}

/* k6463 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g868 */
t4=((C_word*)t0)[4];
f_6031(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[3]);}}

/* k6424 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6426,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[4]);}}

/* k6434 in k6424 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[697],t1,lf[698],((C_word*)t0)[2]);}

/* k6385 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6387(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6387,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[4]);}}

/* k6395 in k6385 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[694],t1,lf[695],((C_word*)t0)[2]);}

/* k6346 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6348,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6358,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[4]);}}

/* k6356 in k6346 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[691],t1,lf[692],((C_word*)t0)[2]);}

/* k6307 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6309,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6319,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[4]);}}

/* k6317 in k6307 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[689],t1);}

/* k6247 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6249(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6249,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6266,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[688]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[3]);}}

/* k6264 in k6247 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6270,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6274,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6276,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6275 in k6264 in k6247 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6276,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[687]);}

/* k6272 in k6264 in k6247 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[686]);}

/* k6268 in k6264 in k6247 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[684],t1,lf[685]);}

/* k6260 in k6247 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 str */
t2=((C_word*)t0)[3];
f_5678(t2,((C_word*)t0)[2],t1);}

/* k6208 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6210,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6220,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1172 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[682],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[4]);}}

/* k6218 in k6208 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1172 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6172 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6040(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[3]);}}

/* k6136 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6040(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[3]);}}

/* k6100 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6040(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[3]);}}

/* k6064 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6066(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6040(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6026(t2,((C_word*)t0)[3]);}}

/* g858 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6040,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6048,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1170 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[681],((C_word*)t0)[2]);}

/* k6046 in g858 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1170 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g868 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6031,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6039,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1184 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6037 in g868 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1184 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[680],((C_word*)t0)[2]);}

/* g871 in k5992 in k5977 in k5881 in k5848 in k5746 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6026(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6026,NULL,2,t0,t1);}
/* c-backend.scm: 1203 err */
t2=((C_word*)t0)[2];
f_5673(t2,t1);}

/* str in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5678,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1128 string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[634],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5673(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5673,NULL,2,t0,t1);}
/* c-backend.scm: 1127 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[633],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5606,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5610,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1109 foreign-callback-stub-name */
t5=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5613,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1110 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1111 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5619,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1112 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5617 in k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5619,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1114 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[629]);}

/* k5623 in k5617 in k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1115 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[628]);}

/* k5667 in k5623 in k5617 in k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1115 gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k5626 in k5623 in k5617 in k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5631,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5636,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1116 pair-for-each */
t4=C_retrieve(lf[174]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5635 in k5626 in k5623 in k5617 in k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5636,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5640,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5657,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1118 foreign-type-declaration */
t8=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k5655 in a5635 in k5626 in k5623 in k5617 in k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1118 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5638 in a5635 in k5626 in k5623 in k5617 in k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1119 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5629 in k5626 in k5623 in k5617 in k5614 in k5611 in k5608 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1121 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5175,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5181,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5181,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5185,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1056 foreign-callback-stub-id */
t4=C_retrieve(lf[627]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5188,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1057 real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5191,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1058 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1059 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5194,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1061 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[624]);}

/* k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5200,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5202,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1088 fold */
t6=C_retrieve(lf[413]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[623],((C_word*)t0)[4],t1);}

/* k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1089 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5604,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1091 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5547(2,t3,C_SCHEME_UNDEFINED);}}

/* k5602 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1091 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[621],t1,lf[622]);}

/* k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1092 generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[620],((C_word*)t0)[2]);}

/* k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5553,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1093 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[618],((C_word*)t0)[2],lf[619]);}

/* k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1094 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[617]);}

/* k5554 in k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5589,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1095 for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5588 in k5554 in k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5589,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5597,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1097 foreign-result-conversion */
t5=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[616]);}

/* k5595 in a5588 in k5554 in k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1097 gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[613],t1,((C_word*)t0)[2],lf[614],C_SCHEME_TRUE,lf[615]);}

/* k5557 in k5554 in k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_5562(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5587,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1102 foreign-argument-conversion */
t5=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k5585 in k5557 in k5554 in k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1102 gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[612],t1);}

/* k5560 in k5557 in k5554 in k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5565,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1103 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[611],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k5563 in k5560 in k5557 in k5554 in k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_5568(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1104 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5566 in k5563 in k5560 in k5557 in k5554 in k5551 in k5548 in k5545 in k5542 in k5539 in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1105 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[610]);}

/* compute-size in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5202,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5212,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5212(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
if(C_truep(t8)){
t9=t7;
f_5212(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t9)){
t10=t7;
f_5212(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t10)){
t11=t7;
f_5212(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t11)){
t12=t7;
f_5212(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[523]);
if(C_truep(t12)){
t13=t7;
f_5212(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t7;
f_5212(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t14)){
t15=t7;
f_5212(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t15)){
t16=t7;
f_5212(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t16)){
t17=t7;
f_5212(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t17)){
t18=t7;
f_5212(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[608]);
t19=t7;
f_5212(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[609])));}}}}}}}}}}}}

/* k5210 in compute-size in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5212(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5212,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5221(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t4)){
t5=t3;
f_5221(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
if(C_truep(t5)){
t6=t3;
f_5221(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
if(C_truep(t6)){
t7=t3;
f_5221(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t7)){
t8=t3;
f_5221(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t8)){
t9=t3;
f_5221(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t9)){
t10=t3;
f_5221(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t10)){
t11=t3;
f_5221(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t11)){
t12=t3;
f_5221(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t12)){
t13=t3;
f_5221(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t13)){
t14=t3;
f_5221(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t14)){
t15=t3;
f_5221(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t16=t3;
f_5221(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[599])));}}}}}}}}}}}}}}

/* k5219 in k5210 in compute-size in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5221,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1070 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[561]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5233(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t4)){
t5=t3;
f_5233(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t5)){
t6=t3;
f_5233(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
t7=t3;
f_5233(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[588])));}}}}}

/* k5231 in k5219 in k5210 in compute-size in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5233,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1072 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[563],((C_word*)t0)[5],lf[564],((C_word*)t0)[5],lf[565]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5245(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_5245(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_5245(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_5245(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k5243 in k5231 in k5219 in k5210 in compute-size in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5245,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1074 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[567],((C_word*)t0)[4],lf[568]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1076 ##sys#hash-table-ref */
t3=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[581]),((C_word*)t0)[2]);}
else{
t3=t2;
f_5251(2,t3,C_SCHEME_FALSE);}}}

/* k5249 in k5243 in k5231 in k5219 in k5210 in compute-size in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5251,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1078 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5202(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[569]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_5285(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[572]);
if(C_truep(t5)){
t6=t4;
f_5285(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[573]);
if(C_truep(t6)){
t7=t4;
f_5285(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t7)){
t8=t4;
f_5285(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[575]);
if(C_truep(t8)){
t9=t4;
f_5285(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t9)){
t10=t4;
f_5285(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t10)){
t11=t4;
f_5285(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[578]);
t12=t4;
f_5285(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[579])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k5283 in k5249 in k5243 in k5231 in k5219 in k5210 in compute-size in k5198 in k5192 in k5189 in k5186 in k5183 in a5180 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1083 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[570]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1084 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5202(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4942,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4948,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4948,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4952,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 989  foreign-stub-id */
t4=C_retrieve(lf[559]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 990  real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4958,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 991  foreign-stub-argument-types */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4958,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5173,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 993  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[556]);}

/* k5171 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5173,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[555],t1);
/* c-backend.scm: 993  intersperse */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 994  foreign-stub-return-type */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 995  foreign-stub-name */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 996  foreign-stub-body */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 997  foreign-stub-argument-names */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_4979(2,t3,t1);}
else{
/* c-backend.scm: 997  make-list */
t3=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 998  foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[550]);}

/* k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 999  foreign-stub-cps */
t3=C_retrieve(lf[549]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1000 foreign-stub-callback */
t3=C_retrieve(lf[548]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1001 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5162,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1003 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4994(2,t3,C_SCHEME_UNDEFINED);}}

/* k5160 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1003 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[546],t1,lf[547]);}

/* k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1005 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[544],((C_word*)t0)[6],lf[545]);}
else{
t3=t2;
f_4997(2,t3,C_SCHEME_UNDEFINED);}}

/* k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1008 gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[539],((C_word*)t0)[2],lf[540],C_SCHEME_TRUE,lf[541],((C_word*)t0)[2],lf[542]);}
else{
/* c-backend.scm: 1010 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[543],((C_word*)t0)[2],C_make_character(40));}}

/* k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[3]);}

/* k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1013 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[534],C_SCHEME_TRUE,lf[535],((C_word*)t0)[2],lf[536]);}
else{
/* c-backend.scm: 1014 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[537],C_SCHEME_TRUE,lf[538],((C_word*)t0)[2],C_make_character(40));}}

/* k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1016 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[533]);}

/* k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1017 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[532]);}

/* k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5110,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1026 iota */
t5=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k5138 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1018 for-each */
t2=*((C_word*)lf[61]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5109 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5110,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5118,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5130,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1023 symbol->string */
t7=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1023 sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[531],t3);}}

/* k5128 in a5109 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1021 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5116 in a5109 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1024 foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[530]);}

/* k5120 in k5116 in a5109 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1025 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5124 in k5120 in k5116 in a5109 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1020 gen */
t2=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[527],((C_word*)t0)[3],C_make_character(41),t1,lf[528],((C_word*)t0)[2],lf[529]);}

/* k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1027 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[526]);}
else{
t3=t2;
f_5021(2,t3,C_SCHEME_UNDEFINED);}}

/* k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1029 gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[517]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t4)){
/* c-backend.scm: 1040 gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1039 gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[525],((C_word*)t0)[2]);}}}

/* k5049 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1041 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k5052 in k5049 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5088,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5092,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1042 make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[524]);}

/* k5090 in k5052 in k5049 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1042 intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5086 in k5052 in k5049 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k5055 in k5052 in k5049 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[523]);
if(C_truep(t3)){
t4=t2;
f_5060(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1043 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5058 in k5055 in k5052 in k5049 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1044 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[522]);}

/* k5061 in k5058 in k5055 in k5052 in k5049 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1046 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[518],C_SCHEME_TRUE,lf[519]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1048 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[520]);}
else{
/* c-backend.scm: 1049 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[521]);}}}

/* k5028 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1031 gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[516],C_SCHEME_TRUE);}

/* k5031 in k5028 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1033 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1035 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[514]);}
else{
/* c-backend.scm: 1036 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[515]);}}}

/* k5022 in k5019 in k5016 in k5013 in k5010 in k5007 in k5004 in k5001 in k4998 in k4995 in k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4956 in k4953 in k4950 in a4947 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1050 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4924,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4930,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a4929 in ##compiler#generate-foreign-callback-stub-prototypes in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4930,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4934,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 981  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4932 in a4929 in ##compiler#generate-foreign-callback-stub-prototypes in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 982  generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k4935 in k4932 in a4929 in ##compiler#generate-foreign-callback-stub-prototypes in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 983  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4873,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4877,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 968  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4875 in ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4882,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a4881 in k4875 in ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4882,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4889,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
t5=t3;
f_4889(t5,(C_word)C_eqp(t4,C_fix(3)));}
else{
t4=t3;
f_4889(t4,C_SCHEME_FALSE);}}

/* k4887 in a4881 in k4875 in ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4889,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t5=(C_truep(t4)?lf[508]:lf[509]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4909,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 972  foreign-type-declaration */
t7=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,t2);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4907 in k4887 in a4881 in k4875 in ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 972  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4857,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4863,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 960  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4862 in ##compiler#make-argument-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4863,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 962  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4869 in a4862 in ##compiler#make-argument-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 962  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4841,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4847,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 955  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4846 in ##compiler#make-variable-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4847,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 957  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4853 in a4846 in ##compiler#make-variable-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 957  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[506],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4752,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4761,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4761(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4761,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4777,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4790,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_4790(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_4790(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_4790(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_4790(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_4790(t10,C_SCHEME_FALSE);}}}}}

/* k4788 in loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4790,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_4793(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4800,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 946  string-copy */
t4=C_retrieve(lf[505]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_4777(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k4798 in k4788 in loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4793(t3,t2);}

/* k4791 in k4788 in loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4793(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_4777(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k4775 in loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4777(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 949  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4761(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4679,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4683,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 911  gen */
t7=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[502],C_SCHEME_TRUE,lf[503],t6,lf[504]);}

/* k4681 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4697(t6,t2,((C_word*)t0)[2]);}

/* do572 in k4681 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4697,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 915  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[495]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 916  lambda-literal-id */
t5=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k4708 in do572 in k4681 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4713,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 917  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[500],t1,((C_word*)t0)[2],lf[501]);}

/* k4711 in k4708 in do572 in k4681 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4716,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 920  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[496],C_retrieve(lf[185]),lf[497]);}
else{
/* c-backend.scm: 921  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[498]);}}
else{
/* c-backend.scm: 922  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[499]);}}

/* k4714 in k4711 in k4708 in do572 in k4681 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4697(t3,((C_word*)t0)[2],t2);}

/* k4684 in k4681 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4689,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 923  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[494]);}

/* k4687 in k4684 in k4681 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 924  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[493]);}

/* k4690 in k4687 in k4684 in k4681 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 925  gen */
t2=C_retrieve(lf[2]);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[486],C_SCHEME_TRUE,lf[487],C_SCHEME_TRUE,lf[488],C_SCHEME_TRUE,lf[489],C_SCHEME_TRUE,lf[490],C_SCHEME_TRUE,lf[491],C_SCHEME_TRUE,lf[492]);}

/* ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[60],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_1142,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1145,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2614,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2780,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2929,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3887,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3810,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3503,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3668,a[2]=t17,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3466,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3509,a[2]=t17,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3899,a[2]=t4,a[3]=t8,a[4]=t21,a[5]=t19,a[6]=t2,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t24=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4646,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t8,a[6]=t14,a[7]=t23,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 894  debugging */
t25=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t24,lf[484],lf[485]);}

/* k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 896  header */
t4=((C_word*)t0)[2];
f_2614(t4,t3);}

/* k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 897  declarations */
t3=((C_word*)t0)[2];
f_2780(t3,t2);}

/* k4651 in k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 898  generate-external-variables */
t3=C_retrieve(lf[482]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[483]));}

/* k4654 in k4651 in k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 899  generate-foreign-stubs */
t3=C_retrieve(lf[480]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[481]),((C_word*)t0)[3]);}

/* k4657 in k4654 in k4651 in k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 900  prototypes */
t3=((C_word*)t0)[2];
f_2929(t3,t2);}

/* k4660 in k4657 in k4654 in k4651 in k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 901  generate-foreign-callback-stubs */
t3=C_retrieve(lf[479]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[179]),((C_word*)t0)[2]);}

/* k4663 in k4660 in k4657 in k4654 in k4651 in k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 902  trampolines */
t3=((C_word*)t0)[2];
f_3180(t3,t2);}

/* k4666 in k4663 in k4660 in k4657 in k4654 in k4651 in k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 903  procedures */
t3=((C_word*)t0)[2];
f_3899(t3,t2);}

/* k4669 in k4666 in k4663 in k4660 in k4657 in k4654 in k4651 in k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 904  emit-procedure-table-info */
t3=C_retrieve(lf[478]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4672 in k4669 in k4666 in k4663 in k4660 in k4657 in k4654 in k4651 in k4648 in k4644 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 475  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[477],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3899,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3905,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 718  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 719  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 720  real-name */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3918,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 721  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 722  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 723  lambda-literal-customizable */
t5=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4643,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 724  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_3927(t3,C_SCHEME_FALSE);}}

/* k4641 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3927(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3927,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 726  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[475]);}

/* k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3936,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 727  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[474]);}

/* k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3939,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 728  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 729  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 730  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 731  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 732  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 733  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 734  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 736  string-append */
t3=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[185]),lf[472]);}
else{
t3=t2;
f_3960(2,t3,lf[473]);}}

/* k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 738  debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[470],lf[471],((C_word*)t0)[14]);}
else{
t3=t2;
f_3963(2,t3,C_SCHEME_UNDEFINED);}}

/* k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 739  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4612,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 740  cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4610 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[466],t1,lf[467],C_SCHEME_TRUE);}

/* k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 749  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[460]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4573,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 742  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[465]);}}

/* k4571 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[463]:lf[464]);
/* c-backend.scm: 743  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4574 in k4571 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 745  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[461]);}
else{
/* c-backend.scm: 746  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[462]);}}

/* k4577 in k4574 in k4571 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 747  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4593 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4598(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 751  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[459]);}}

/* k4596 in k4593 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 752  gen */
t2=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[453],C_SCHEME_TRUE,lf[454],C_SCHEME_TRUE,lf[455],C_SCHEME_TRUE,lf[456],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[458],((C_word*)t0)[2]);}

/* k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 757  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_3978(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 758  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[452]);}}

/* k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4545,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_4545(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4545(t4,C_SCHEME_FALSE);}}

/* k4543 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4545,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 760  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[451]);}
else{
t2=((C_word*)t0)[2];
f_3981(2,t2,C_SCHEME_UNDEFINED);}}

/* k4546 in k4543 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 761  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3981(2,t2,C_SCHEME_UNDEFINED);}}

/* k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[15]);}

/* k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 763  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[450]);}
else{
t3=t2;
f_3987(2,t3,C_SCHEME_UNDEFINED);}}

/* k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 764  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[449]);}

/* k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[224]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_3993(t5,t4);}
else{
t4=t2;
f_3993(t4,C_SCHEME_UNDEFINED);}}

/* k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3993,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 766  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[448]);}

/* k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 768  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[446],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4507,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4507(t8,t2,((C_word*)t0)[20],t4);}}

/* do459 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4507(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4507,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4517,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 772  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[447],t2,C_make_character(59));}}

/* k4515 in do459 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4507(t4,((C_word*)t0)[2],t2,t3);}

/* k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4219,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4294,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 774  fold */
t6=C_retrieve(lf[413]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4308,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 808  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[427]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4372,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4450,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_4450(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_4450(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k4448 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4450,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 822  gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[437],C_SCHEME_TRUE,lf[438],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440]);}
else{
/* c-backend.scm: 825  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[441],((C_word*)t0)[3],lf[442]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4462(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 827  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[445]);}}}

/* k4460 in k4448 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 828  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[444]);}
else{
t3=t2;
f_4465(2,t3,C_SCHEME_UNDEFINED);}}

/* k4463 in k4460 in k4448 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[104]);
t4=t2;
f_4471(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[407]))));}
else{
t3=t2;
f_4471(t3,C_SCHEME_FALSE);}}

/* k4469 in k4463 in k4460 in k4448 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 830  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[443]);}
else{
t2=((C_word*)t0)[2];
f_4372(2,t2,C_SCHEME_UNDEFINED);}}

/* k4370 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4375,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4414,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4414(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
t6=t3;
f_4414(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_4414(t4,C_SCHEME_FALSE);}}

/* k4412 in k4370 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 834  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[431],((C_word*)t0)[3],lf[432],((C_word*)t0)[3],lf[433]);}
else{
t4=((C_word*)t0)[2];
f_4375(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 835  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[434],((C_word*)t0)[3],lf[435],((C_word*)t0)[3],lf[436]);}}
else{
t2=((C_word*)t0)[2];
f_4375(2,t2,C_SCHEME_UNDEFINED);}}

/* k4373 in k4370 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4381,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_4381(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_4381(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_4381(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k4379 in k4373 in k4370 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4381,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 837  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[430]);}
else{
t3=t2;
f_4384(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_4002(2,t2,C_SCHEME_UNDEFINED);}}

/* k4382 in k4379 in k4373 in k4370 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4390,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_4390(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_4390(t3,C_SCHEME_FALSE);}}

/* k4388 in k4382 in k4379 in k4373 in k4370 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 839  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[428]);}
else{
/* c-backend.scm: 840  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[429]);}}

/* k4306 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 809  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[426]);}

/* k4309 in k4306 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 810  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[425]);}

/* k4312 in k4309 in k4306 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 812  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 813  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[424]);}}

/* k4315 in k4312 in k4309 in k4306 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 814  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[422],((C_word*)t0)[3],lf[423]);}

/* k4318 in k4315 in k4312 in k4309 in k4306 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4335,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4335(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
if(C_truep(t5)){
t6=t3;
f_4335(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_4335(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k4333 in k4318 in k4315 in k4312 in k4309 in k4306 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4335(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 816  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[418],((C_word*)t0)[2],lf[419],((C_word*)t0)[2],lf[420]);}
else{
t2=((C_word*)t0)[3];
f_4323(2,t2,C_SCHEME_UNDEFINED);}}

/* k4321 in k4318 in k4315 in k4312 in k4309 in k4306 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 817  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[417]);}
else{
t3=t2;
f_4326(2,t3,C_SCHEME_UNDEFINED);}}

/* k4324 in k4321 in k4318 in k4315 in k4312 in k4309 in k4306 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 818  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[414],((C_word*)t0)[2],lf[415]);}

/* a4293 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4294,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4302,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 774  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3509(3,t5,t4,t2);}

/* k4300 in a4293 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4219,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4225,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 776  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[409],C_SCHEME_TRUE,lf[410],C_SCHEME_TRUE,lf[411],((C_word*)t0)[2],lf[412]);}

/* k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[407]))){
/* c-backend.scm: 780  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[408]);}
else{
t3=t2;
f_4228(2,t3,C_SCHEME_UNDEFINED);}}

/* k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4231(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4262,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[400]))){
/* c-backend.scm: 783  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[401],C_retrieve(lf[400]),lf[402]);}
else{
if(C_truep(C_retrieve(lf[403]))){
/* c-backend.scm: 785  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[404],C_retrieve(lf[403]),lf[405],C_SCHEME_TRUE,lf[406]);}
else{
t4=t3;
f_4262(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k4260 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4265,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[398]))){
/* c-backend.scm: 788  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[399],C_retrieve(lf[398]),C_make_character(59));}
else{
t3=t2;
f_4265(2,t3,C_SCHEME_UNDEFINED);}}

/* k4263 in k4260 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[396]))){
/* c-backend.scm: 790  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[397],C_retrieve(lf[396]),C_make_character(59));}
else{
t3=t2;
f_4268(2,t3,C_SCHEME_UNDEFINED);}}

/* k4266 in k4263 in k4260 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[393]))){
/* c-backend.scm: 792  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[394],C_retrieve(lf[393]),lf[395]);}
else{
t2=((C_word*)t0)[2];
f_4231(2,t2,C_SCHEME_UNDEFINED);}}

/* k4229 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 793  gen */
t3=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[386],((C_word*)t0)[3],lf[387],C_SCHEME_TRUE,lf[388],((C_word*)t0)[3],lf[389],C_SCHEME_TRUE,lf[390],C_SCHEME_TRUE,lf[391],C_SCHEME_TRUE,lf[392]);}

/* k4232 in k4229 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 798  gen */
t3=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[380],((C_word*)t0)[2],lf[381],C_SCHEME_TRUE,lf[382],C_SCHEME_TRUE,lf[383],((C_word*)t0)[2],lf[384],C_SCHEME_TRUE,lf[385]);}

/* k4235 in k4232 in k4229 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 802  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[2],lf[379]);}

/* k4238 in k4235 in k4232 in k4229 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4002(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 804  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[376],((C_word*)t0)[4],lf[377]);}}

/* k4247 in k4238 in k4235 in k4232 in k4229 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 805  literal-frame */
t3=((C_word*)t0)[2];
f_3466(t3,t2);}

/* k4250 in k4247 in k4238 in k4235 in k4232 in k4229 in k4226 in k4223 in k4217 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 806  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[374],((C_word*)t0)[2],lf[375]);}

/* k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[235],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_4025(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_4025(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_4025(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_4025(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_4025(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4025,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[365]:lf[366]);
/* c-backend.scm: 851  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[367],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[371]:lf[372]);
/* c-backend.scm: 877  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[373]);}}
else{
t2=((C_word*)t0)[10];
f_4005(2,t2,C_SCHEME_UNDEFINED);}}

/* k4158 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 879  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[369]);}
else{
/* c-backend.scm: 880  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[370],((C_word*)t0)[3]);}}

/* k4161 in k4158 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 882  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4166(2,t3,C_SCHEME_UNDEFINED);}}

/* k4173 in k4161 in k4158 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4164 in k4161 in k4158 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 884  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[368]);}

/* k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[309]);
if(C_truep(t3)){
/* c-backend.scm: 852  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_4034(2,t4,C_SCHEME_UNDEFINED);}}

/* k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 853  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[363],((C_word*)t0)[5],lf[364]);}

/* k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 855  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4040(2,t3,C_SCHEME_UNDEFINED);}}

/* k4139 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 857  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[359],C_SCHEME_TRUE,lf[360],C_SCHEME_TRUE,lf[361],((C_word*)t0)[6],lf[362]);}

/* k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[354]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 861  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[355],((C_word*)t0)[6],lf[356]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[309]);
if(C_truep(t5)){
/* c-backend.scm: 862  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[357],((C_word*)t0)[6],lf[358]);}
else{
t6=t2;
f_4046(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 863  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[353]);}

/* k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4052,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4114,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 864  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[352]);}

/* k4112 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 864  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4108 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 865  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[350],((C_word*)t0)[5],lf[351]);}

/* k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 867  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[348],((C_word*)t0)[2],lf[349]);}

/* k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 869  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[346],((C_word*)t0)[3],lf[347]);}

/* k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 870  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[345]);}

/* k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4085,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4085(t7,t2,t3,((C_word*)t0)[2]);}

/* do503 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4085(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4085,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4095,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 874  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[344],t2,C_make_character(59));}}

/* k4093 in do503 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4085(t4,((C_word*)t0)[2],t2,t3);}

/* k4068 in k4065 in k4062 in k4059 in k4056 in k4053 in k4050 in k4047 in k4044 in k4041 in k4038 in k4035 in k4032 in k4029 in k4023 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 875  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[342],((C_word*)t0)[3],lf[343]);}
else{
t3=((C_word*)t0)[2];
f_4005(2,t3,C_SCHEME_UNDEFINED);}}

/* k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4008,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 886  lambda-literal-body */
t4=C_retrieve(lf[341]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4013 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 885  expression */
t3=((C_word*)t0)[4];
f_1187(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k4006 in k4003 in k4000 in k3997 in k3994 in k3991 in k3988 in k3985 in k3982 in k3979 in k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in a3904 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 891  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3509,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 653  immediate? */
t4=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3516,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[334]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 657  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3509(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3576,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3580,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3584,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 658  vector->list */
t6=*((C_word*)lf[337]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 659  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k3588 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3590,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 660  bad-literal */
f_3503(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 662  ##sys#bytevector? */
t3=*((C_word*)lf[339]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k3606 in k3588 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3608,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 662  words */
t4=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3637(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 669  bad-literal */
f_3503(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k3606 in k3588 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3637(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3637,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3659,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 668  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3509(3,t8,t6,t7);}}

/* k3657 in loop in k3606 in k3588 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 668  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3637(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3613 in k3606 in k3588 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k3582 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3578 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 658  reduce */
t2=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[336]+1),C_fix(0),t1);}

/* k3574 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k3545 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3551,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 657  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3509(3,t4,t2,t3);}

/* k3549 in k3545 in k3514 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3466,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3472(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* do389 in literal-frame in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3472,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3482,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3501,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 647  sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[333],t2);}}

/* k3499 in do389 in literal-frame in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 647  gen-lit */
t2=((C_word*)t0)[4];
f_3668(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3480 in do389 in literal-frame in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3472(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3668(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3668,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3808,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 673  big-fixnum? */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_3675(t5,C_SCHEME_FALSE);}}

/* k3806 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3675(t2,(C_word)C_i_not(t1));}

/* k3673 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3675,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 674  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[316],((C_word*)t0)[4],lf[317]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 675  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k3679 in k3673 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[0]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 677  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[318]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[319]:lf[320]);
/* c-backend.scm: 679  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 681  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[321],t4,lf[322]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3731,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 684  c-ify-string */
t6=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 689  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[326]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_3764(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_3764(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k3762 in k3679 in k3673 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3764,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 693  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[329]);}
else{
/* c-backend.scm: 696  bad-literal */
f_3503(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k3765 in k3762 in k3679 in k3673 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3777,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 694  encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3775 in k3765 in k3762 in k3679 in k3673 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 694  gen-string-constant */
t2=((C_word*)t0)[3];
f_3810(t2,((C_word*)t0)[2],t1);}

/* k3768 in k3765 in k3762 in k3679 in k3673 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 695  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[327]);}

/* k3729 in k3679 in k3673 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3731,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3737,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 686  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[325]);}

/* k3735 in k3729 in k3679 in k3673 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 687  gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[323],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[324]);}

/* bad-literal in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3503(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3503,NULL,2,t1,t2);}
/* c-backend.scm: 650  bomb */
t3=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[315],t2);}

/* gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3810,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3817,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 700  fx/ */
t5=*((C_word*)lf[314]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3820,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 701  modulo */
t3=*((C_word*)lf[313]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k3818 in k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3820,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3825,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3825(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do420 in k3818 in k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3825(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3825,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3841(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_3841(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3862,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3877,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3881,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 707  string-like-substring */
f_3887(t7,((C_word*)t0)[4],t3,t8);}}

/* k3879 in do420 in k3818 in k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 707  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3875 in do420 in k3818 in k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 707  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k3860 in do420 in k3818 in k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3825(t4,((C_word*)t0)[2],t2,t3);}

/* k3839 in do420 in k3818 in k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3841,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3848,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3852,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 706  string-like-substring */
f_3887(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3850 in k3839 in do420 in k3818 in k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 706  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3846 in k3839 in do420 in k3818 in k3815 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 706  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3887(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3887,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3894,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 711  make-string */
t7=*((C_word*)lf[312]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k3892 in string-like-substring in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3897,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 712  ##sys#copy-bytes */
t3=C_retrieve(lf[311]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k3895 in k3892 in string-like-substring in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3180,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3183,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3219,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3299,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3347,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3347,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3351,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 606  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 607  lambda-literal-rest-argument */
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3357,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 608  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 609  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 610  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3464,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 611  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3366(t3,C_SCHEME_FALSE);}}

/* k3462 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3366(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3366,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_3369(t5,t4);}
else{
t3=t2;
f_3369(t3,C_SCHEME_UNDEFINED);}}

/* k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3369,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 613  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 615  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[305],((C_word*)t0)[9],lf[306],C_SCHEME_TRUE,lf[307],((C_word*)t0)[9],lf[308]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3409(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 623  lambda-literal-allocated */
t4=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k3451 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3409(2,t3,t2);}
else{
/* c-backend.scm: 623  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3407 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[224]);
t4=t2;
f_3415(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3415(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3413 in k3407 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3415,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[309]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 626  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 627  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 628  lset-adjoin */
t3=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3431 in k3413 in k3407 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3427 in k3413 in k3407 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3423 in k3413 in k3407 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3379 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 617  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[303],((C_word*)t0)[3],lf[304]);}

/* k3382 in k3379 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 618  restore */
f_3183(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3385 in k3382 in k3379 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 619  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3388 in k3385 in k3382 in k3379 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 620  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[302]);}

/* k3391 in k3388 in k3385 in k3382 in k3379 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3403,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 621  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k3401 in k3391 in k3388 in k3385 in k3382 in k3379 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3394 in k3391 in k3388 in k3385 in k3382 in k3379 in k3373 in k3367 in k3364 in k3361 in k3358 in k3355 in k3352 in k3349 in a3346 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 622  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[301]);}

/* k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3317 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3318,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 632  gen */
t4=C_retrieve(lf[2]);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[296],t2,lf[297],C_SCHEME_TRUE,lf[298],t2,lf[299],t2,lf[300]);}

/* k3320 in a3317 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3325,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 634  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[293],((C_word*)t0)[3],lf[294],((C_word*)t0)[3],lf[295]);}

/* k3323 in k3320 in a3317 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 635  restore */
f_3183(t2,((C_word*)t0)[3]);}

/* k3326 in k3323 in k3320 in a3317 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[292],((C_word*)t0)[2],C_make_character(44));}

/* k3329 in k3326 in k3323 in k3320 in a3317 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3334,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3341,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3345,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 637  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[291]);}

/* k3343 in k3329 in k3326 in k3323 in k3320 in a3317 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 637  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3339 in k3329 in k3326 in k3323 in k3320 in a3317 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3332 in k3329 in k3326 in k3323 in k3320 in a3317 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 638  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[290]);}

/* k3300 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 640  emitter */
t4=((C_word*)t0)[3];
f_3219(t4,t3,C_SCHEME_FALSE);}

/* k3314 in k3300 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3303 in k3300 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 641  emitter */
t3=((C_word*)t0)[2];
f_3219(t3,t2,C_SCHEME_TRUE);}

/* k3310 in k3303 in k3300 in k3297 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3219(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3219,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_3221 in emitter in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3221,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[285]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[286]);
/* c-backend.scm: 584  gen */
t6=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[287],t2,C_make_character(114),t4,lf[288],C_SCHEME_TRUE,lf[289],t2,C_make_character(114),t5);}

/* k3223 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 586  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[283],((C_word*)t0)[4],lf[284]);}

/* k3226 in k3223 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 587  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[282],((C_word*)t0)[4],C_make_character(114));}

/* k3229 in k3226 in k3223 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 588  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_3234(2,t3,C_SCHEME_UNDEFINED);}}

/* k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 589  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[278],((C_word*)t0)[4],lf[279],C_SCHEME_TRUE,lf[280],C_SCHEME_TRUE,lf[281],((C_word*)t0)[4],C_make_character(59));}

/* k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 592  restore */
f_3183(t2,((C_word*)t0)[4]);}

/* k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 593  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[277]);}

/* k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 595  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[275]);}
else{
/* c-backend.scm: 596  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[276]);}}

/* k3244 in k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 597  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[274]);}

/* k3247 in k3244 in k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 598  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[273]);}
else{
t3=t2;
f_3252(2,t3,C_SCHEME_UNDEFINED);}}

/* k3250 in k3247 in k3244 in k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 599  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[272]);}

/* k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 600  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[271]);}

/* k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 601  make-argument-list */
t6=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[270]);}

/* k3270 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 601  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3266 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3259 in k3256 in k3253 in k3250 in k3247 in k3244 in k3241 in k3238 in k3235 in k3232 in k3229 in k3226 in k3223 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 602  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[268]);}

/* restore in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3183(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3183,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3187,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3196,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3196(t8,t3,t4,C_fix(0));}

/* do338 in restore in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3196(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3196,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3206,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 579  gen */
t5=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[265],t2,lf[266],t3,lf[267]);}}

/* k3204 in do338 in restore in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3196(t4,((C_word*)t0)[2],t2,t3);}

/* k3185 in restore in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 580  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[263],((C_word*)t0)[2],lf[264]);}

/* prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2929,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 508  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2957,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2961,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 511  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 512  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 513  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2967(t3,C_SCHEME_FALSE);}}

/* k3176 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2967(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2967,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3164,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 514  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[260]);}

/* k3162 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 514  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 515  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 516  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 517  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 518  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 519  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3156,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 521  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_2988(t5,C_SCHEME_UNDEFINED);}}

/* k3154 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2988(t3,t2);}

/* k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2988,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 522  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3130,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3149,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 527  lambda-literal-callee-signatures */
t5=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3147 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3129 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3130,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 526  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k3139 in a3129 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 537  string-append */
t5=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[185]),lf[242]);}
else{
t5=t4;
f_3106(2,t5,lf[243]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3081,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 529  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[249],((C_word*)t0)[5],lf[250],C_SCHEME_TRUE);}}

/* k3079 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 530  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[248]);}

/* k3082 in k3079 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[246]:lf[247]);
/* c-backend.scm: 531  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3085 in k3082 in k3079 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 533  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[244]);}
else{
/* c-backend.scm: 534  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[245]);}}

/* k3088 in k3085 in k3082 in k3079 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 535  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3104 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3109,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 538  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[240],t1,lf[241],C_SCHEME_TRUE);}

/* k3107 in k3104 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3109,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3112,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[238]))){
/* c-backend.scm: 540  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[239],C_SCHEME_TRUE);}
else{
t3=t2;
f_3112(2,t3,C_SCHEME_UNDEFINED);}}

/* k3110 in k3107 in k3104 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3115,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 541  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}

/* k3113 in k3110 in k3107 in k3104 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 542  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[236],((C_word*)t0)[2]);}

/* k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 543  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3003(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 544  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[234]);}}

/* k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3053,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3053(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3053(t4,C_SCHEME_FALSE);}}

/* k3051 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3053,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 546  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}
else{
t2=((C_word*)t0)[2];
f_3006(2,t2,C_SCHEME_UNDEFINED);}}

/* k3054 in k3051 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 547  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3006(2,t2,C_SCHEME_UNDEFINED);}}

/* k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[4]);}

/* k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3009,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 550  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[231]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 558  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k3039 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3044,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3044(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 560  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[232]);}}

/* k3042 in k3039 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 561  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3013 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 553  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[227],((C_word*)t0)[2],lf[228],C_SCHEME_TRUE,lf[229],((C_word*)t0)[2],lf[230]);}}

/* k3022 in k3013 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k3025 in k3022 in k3013 in k3007 in k3004 in k3001 in k2998 in k2995 in k2992 in k2989 in k2986 in k2983 in k2980 in k2977 in k2974 in k2971 in k2968 in k2965 in k2962 in k2959 in a2956 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 556  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[225],t2,lf[226]);}

/* k2934 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2941,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a2940 in k2934 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2941,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2945,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 565  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[222],t2,lf[223]);}

/* k2943 in a2940 in k2934 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 566  make-list */
t4=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[221]);}

/* k2953 in k2943 in a2940 in k2934 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k2946 in k2943 in a2940 in k2934 in k2931 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 567  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[219]);}

/* declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2780,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2787,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 479  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[218]);}

/* k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2923,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[187]));}

/* a2922 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2923,3,t0,t1,t2);}
/* c-backend.scm: 482  gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[214],t2,lf[215],C_SCHEME_TRUE,lf[216],t2,lf[217]);}

/* k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_2793(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 486  gen */
t4=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[212],((C_word*)t0)[2],lf[213]);}}

/* k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 487  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[211]);}

/* k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2801,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2801(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2801(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2801,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2811,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 491  ##sys#lambda-info->string */
t6=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2817,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 493  gen */
t8=C_retrieve(lf[2]);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[208],((C_word*)t0)[5],lf[209],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2870,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2870(t6,t2,C_fix(0));}

/* do274 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2870(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2870,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2880,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 500  gen */
t7=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k2878 in do274 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2870(t3,((C_word*)t0)[2],t2);}

/* k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2843,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_2843(t9,t2,t5);}

/* do279 in k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2843(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2843,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2853,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 503  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[207]);}}

/* k2851 in do279 in k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2843(t3,((C_word*)t0)[2],t2);}

/* k2821 in k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 504  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[206]);}

/* k2824 in k2821 in k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2801(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2614,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2617,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2634,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 449  current-seconds */
t5=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2770 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 449  ##sys#decode-seconds */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_2640(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_2640(t3,C_SCHEME_FALSE);}}

/* k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2640,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2717,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 453  pad0 */
f_2617(t9,t10);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 453  pad0 */
f_2617(t2,((C_word*)t0)[2]);}

/* k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 453  pad0 */
f_2617(t2,((C_word*)t0)[2]);}

/* k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2729,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 453  pad0 */
f_2617(t2,((C_word*)t0)[2]);}

/* k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2733,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2739,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2751,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 456  chicken-version */
t7=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k2749 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 456  string-split */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[201]);}

/* k2745 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2738 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2739,3,t0,t1,t2);}
/* string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[197],t2,lf[198]);}

/* k2735 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 454  string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[196]);}

/* k2731 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 451  gen */
t2=C_retrieve(lf[2]);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[190],((C_word*)t0)[7],lf[191],C_SCHEME_TRUE,lf[192],C_SCHEME_TRUE,lf[193],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[194]);}

/* k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 459  gen-list */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[189]));}

/* k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 460  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 461  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[186],C_retrieve(lf[185]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 463  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[188]);}}

/* k2704 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 464  gen-list */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[187]));}

/* k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 465  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[181],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[182],C_retrieve(lf[183]),lf[184]);}

/* k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[177]))){
/* c-backend.scm: 467  generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[179]));}
else{
t3=t2;
f_2673(2,t3,C_SCHEME_UNDEFINED);}}

/* k2671 in k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[180])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2688,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 469  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_2676(2,t3,C_SCHEME_UNDEFINED);}}

/* k2686 in k2671 in k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2693,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[180]));}

/* a2692 in k2686 in k2671 in k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2693,3,t0,t1,t2);}
/* c-backend.scm: 470  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k2674 in k2671 in k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[177]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 472  generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[179]));}}

/* pad0 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2617(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2617,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 447  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2629 in pad0 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 447  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[176],t1);}

/* expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1187(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1187,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2582,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 442  expr */
t11=((C_word*)t6)[1];
f_1190(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2582,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2588,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 436  pair-for-each */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a2587 in expr-args in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_2592(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 438  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k2590 in a2587 in expr-args in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 439  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1190(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word ab[209],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1190,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[14]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[16]:lf[17]);
/* c-backend.scm: 127  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[18]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 128  gen */
t16=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t1,lf[19],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t14)){
/* c-backend.scm: 129  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,lf[21]);}
else{
t15=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 130  gen */
t17=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t1,lf[23],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t16)){
/* c-backend.scm: 131  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[25]);}
else{
/* c-backend.scm: 132  bomb */
t17=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[26]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[27]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 137  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[28],t13,lf[29]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 138  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[30],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[31]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1314,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
t14=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_SCHEME_TRUE,lf[34]);}
else{
t13=(C_word)C_eqp(t9,lf[35]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 150  gen */
t15=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,lf[36],t14);}
else{
t14=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_1372(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[38]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1423,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 162  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[40]);}
else{
t16=(C_word)C_eqp(t9,lf[41]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1450,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 167  gen */
t18=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,lf[43]);}
else{
t17=(C_word)C_eqp(t9,lf[44]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1469,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 172  gen */
t19=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[45]);}
else{
t18=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1502,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 179  gen */
t20=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[49]);}
else{
t19=(C_word)C_eqp(t9,lf[50]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1539,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
t21=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t20,lf[52]);}
else{
t20=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1568,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
t22=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[55]);}
else{
t21=(C_word)C_eqp(t9,lf[56]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1600,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 201  gen */
t24=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t24))(5,t24,t23,lf[63],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[64]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1635,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 211  gen */
t24=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,lf[66]);}
else{
t23=(C_word)C_eqp(t9,lf[67]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 215  gen */
t25=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[68]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1667,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 218  gen */
t27=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t27))(5,t27,t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 227  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[70],t26,lf[71]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1709,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 228  symbol->string */
t31=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 229  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[76],t26,lf[77]);}
else{
/* c-backend.scm: 230  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[78],t26,lf[79]);}}}
else{
t26=(C_word)C_eqp(t9,lf[80]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1741,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t28)){
/* c-backend.scm: 236  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[81],t27,lf[82]);}
else{
/* c-backend.scm: 237  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[83],t27,lf[84]);}}
else{
t27=(C_word)C_eqp(t9,lf[85]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_cadr(t7))){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1775,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 245  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[86],t28,lf[87]);}
else{
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1788,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 249  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[88],t28,lf[89]);}}
else{
t28=(C_word)C_eqp(t9,lf[90]);
if(C_truep(t28)){
/* c-backend.scm: 253  gen */
t29=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t29))(3,t29,t1,lf[91]);}
else{
t29=(C_word)C_eqp(t9,lf[92]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1831,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=t36,a[5]=t32,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t31,a[9]=t33,a[10]=t3,a[11]=t30,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 262  source-info->string */
t38=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[125]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2142,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 319  lambda-literal-closure-size */
t36=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[129]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2227,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2231,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 347  find-lambda */
t41=((C_word*)t0)[2];
f_1145(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[131]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2250,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 364  gen */
t37=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t37))(8,t37,t35,C_SCHEME_TRUE,lf[133],t36,lf[134],t34,lf[135]);}
else{
t33=(C_word)C_eqp(t9,lf[136]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2269,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 369  gen */
t35=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,C_SCHEME_TRUE,lf[138]);}
else{
t34=(C_word)C_eqp(t9,lf[139]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2288,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 374  gen */
t37=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t37))(5,t37,t35,lf[140],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[141]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2307,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 379  gen */
t39=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t39))(6,t39,t36,lf[142],t37,lf[143],t38);}
else{
t36=(C_word)C_eqp(t9,lf[144]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2343,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 387  foreign-result-conversion */
t39=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t39))(4,t39,t37,t38,lf[146]);}
else{
t37=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2363,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2381,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 391  foreign-type-declaration */
t42=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t38,lf[152]);}
else{
t38=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2397,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2411,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 397  foreign-result-conversion */
t42=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t39,lf[158]);}
else{
t39=(C_word)C_eqp(t9,lf[159]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2427,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 403  foreign-type-declaration */
t43=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t43))(4,t43,t42,t40,lf[164]);}
else{
t40=(C_word)C_eqp(t9,lf[165]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2464,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 410  gen */
t42=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,C_SCHEME_TRUE,lf[169]);}
else{
t41=(C_word)C_eqp(t9,lf[170]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2547,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 425  gen */
t43=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t43))(3,t43,t42,lf[172]);}
else{
/* c-backend.scm: 433  bomb */
t42=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t42))(3,t42,t1,lf[173]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 426  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 427  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[171]);}

/* k2551 in k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 428  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2554 in k2551 in k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 429  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2557 in k2554 in k2551 in k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 430  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 431  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 411  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1190(t4,t2,t3,((C_word*)t0)[3]);}

/* k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 412  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}

/* k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2483,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2483(t7,((C_word*)t0)[2],t2,t3);}

/* do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2483(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2483,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 416  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[166]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 419  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[167]);}}

/* k2504 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 420  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2507 in k2504 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 421  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2510 in k2507 in k2504 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 422  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2513 in k2510 in k2507 in k2504 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2483(t4,((C_word*)t0)[2],t2,t3);}

/* k2491 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 417  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2494 in k2491 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 418  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k2453 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 403  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[162],t1,lf[163]);}

/* k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 404  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1190(t4,t2,t3,((C_word*)t0)[3]);}

/* k2428 in k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 405  foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2445 in k2428 in k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 405  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[161],t1);}

/* k2431 in k2428 in k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 406  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2434 in k2431 in k2428 in k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 407  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[160]);}

/* k2409 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 397  foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[157]);}

/* k2413 in k2409 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 397  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[155],t1,lf[156]);}

/* k2395 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 398  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2398 in k2395 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 399  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[154]);}

/* k2379 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2385,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 391  foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2383 in k2379 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 391  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_make_character(41),t1);}

/* k2361 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 392  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2364 in k2361 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 393  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[148]);}

/* k2341 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 387  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k2305 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 382  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_2310(2,t3,C_SCHEME_UNDEFINED);}}

/* k2317 in k2305 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 383  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2582(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2308 in k2305 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 384  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2286 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 375  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2289 in k2286 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 376  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2267 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 370  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2270 in k2267 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 371  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[137]);}

/* k2248 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 365  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2251 in k2248 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 366  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[132]);}

/* k2229 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 347  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 349  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2208,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 351  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[130],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_2178(2,t3,C_SCHEME_UNDEFINED);}}

/* k2206 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 352  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_2178(2,t4,C_SCHEME_UNDEFINED);}}

/* k2176 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_2181(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 354  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k2194 in k2176 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 355  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2181(2,t2,C_SCHEME_UNDEFINED);}}

/* k2179 in k2176 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 356  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2582(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_2184(2,t3,C_SCHEME_UNDEFINED);}}

/* k2182 in k2179 in k2176 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 357  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 321  lambda-literal-temporaries */
t4=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2126,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 334  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k2124 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2129(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 335  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[128]);}}

/* k2127 in k2124 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 336  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2130 in k2127 in k2124 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 322  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 323  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2108 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2109,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 325  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k2111 in a2108 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 326  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2114 in k2111 in a2108 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 327  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2089 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2099,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 331  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k2105 in k2089 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 329  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2098 in k2089 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2099,4,t0,t1,t2,t3);}
/* c-backend.scm: 330  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[127],t2,C_make_character(59));}

/* k2092 in k2089 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 332  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[126]);}

/* k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[15]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_1834(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1834(t3,C_SCHEME_FALSE);}}

/* k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1834,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2031,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2035,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 265  find-lambda */
t6=((C_word*)t0)[2];
f_1145(t6,t5,t1);}
else{
t4=t3;
f_1840(t4,C_SCHEME_FALSE);}}

/* k2033 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 265  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2029 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1840(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1840,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_retrieve(lf[112]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1175,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 114  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2024,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1185,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 115  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}}
else{
t4=t3;
f_1846(2,t4,C_SCHEME_UNDEFINED);}}

/* k1183 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 115  string-translate* */
t2=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[122]);}

/* k2022 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[119],t1,lf[120]);}

/* k1173 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 114  string-translate */
t2=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[116],lf[117]);}

/* k2015 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 269  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[113],t1,lf[114]);}

/* k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[35],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 273  gen */
t7=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[94]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 277  lambda-literal-id */
t6=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 303  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 304  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1190(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 305  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[110],((C_word*)t0)[4],lf[111]);}

/* k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1991(t5,t3);}
else{
t5=C_retrieve(lf[109]);
t6=t4;
f_1991(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k1989 in k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 308  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[105],((C_word*)t0)[2],lf[106]);}
else{
/* c-backend.scm: 309  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[107],((C_word*)t0)[2],lf[108]);}}

/* k1977 in k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 310  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[102],((C_word*)t0)[3],lf[103],((C_word*)t0)[2],C_make_character(44));}

/* k1980 in k1977 in k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 311  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 312  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[101]);}

/* k1965 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 278  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_1877(2,t3,C_SCHEME_FALSE);}}

/* k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 279  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_1927(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 294  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k1949 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 295  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1952 in k1949 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 296  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 297  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k1928 in k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1933(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 298  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k1931 in k1928 in k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1936(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 299  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k1934 in k1931 in k1928 in k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 300  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1937 in k1934 in k1931 in k1928 in k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[99]);}

/* k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 280  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 281  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a1909 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1910,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 283  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k1912 in a1909 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 284  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1915 in k1912 in a1909 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 285  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1900,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 289  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k1906 in k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 287  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1899 in k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1900,4,t0,t1,t2,t3);}
/* c-backend.scm: 288  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[97],t2,C_make_character(59));}

/* k1887 in k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1892(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 290  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[96],((C_word*)t0)[2],C_make_character(59));}}

/* k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 291  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[95]);}

/* k1856 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 274  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1859 in k1856 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 275  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[93]);}

/* k1786 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 250  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1789 in k1786 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1773 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 246  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1776 in k1773 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1739 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 238  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1742 in k1739 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1711 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1707 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[72],((C_word*)t0)[2],lf[73],t1,C_make_character(41));}

/* k1665 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 219  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1633 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1636 in k1633 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[65]);}

/* k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 207  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k1624 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 202  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1611 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1612,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 204  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[59],t3,lf[60]);}

/* k1614 in a1611 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 205  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1617 in k1614 in a1611 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k1601 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 208  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[57],t2,lf[58]);}

/* k1566 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1569 in k1566 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 195  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k1572 in k1569 in k1566 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 196  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1575 in k1572 in k1569 in k1566 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 197  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1537 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1540 in k1537 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 188  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[51]);}

/* k1543 in k1540 in k1537 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 189  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1546 in k1543 in k1540 in k1537 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 190  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1500 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1190(t4,t2,t3,((C_word*)t0)[3]);}

/* k1503 in k1500 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 181  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[47],t4,lf[48]);}

/* k1506 in k1503 in k1500 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 182  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1509 in k1506 in k1503 in k1500 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 183  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1467 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1190(t4,t2,t3,((C_word*)t0)[3]);}

/* k1470 in k1467 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 174  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k1473 in k1470 in k1467 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 175  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1476 in k1473 in k1470 in k1467 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 176  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1448 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 168  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1451 in k1448 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 169  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[42]);}

/* k1421 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 163  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1424 in k1421 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 164  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[39],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1372,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 155  gen */
t7=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 159  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1190(t7,t1,t6,t3);}}

/* k1380 in loop in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 156  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1190(t4,t2,t3,((C_word*)t0)[6]);}

/* k1383 in k1380 in loop in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 157  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k1386 in k1383 in k1380 in loop in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 158  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1372(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k1318 in k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1321 in k1318 in k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 145  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[32]);}

/* k1324 in k1321 in k1318 in k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1145,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1149,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 111  find */
t5=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1156 in find-lambda in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1157,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 111  lambda-literal-id */
t4=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1163 in a1156 in find-lambda in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k1147 in find-lambda in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 112  bomb */
t2=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[11],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k1093 in k1090 in k1087 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1122,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1128,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1136,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 93   intersperse */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k1134 in ##compiler#gen-list in k1093 in k1090 in k1087 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1127 in ##compiler#gen-list in k1093 in k1090 in k1087 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1128,3,t0,t1,t2);}
/* c-backend.scm: 92   display */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[1]));}

/* ##compiler#gen in k1093 in k1090 in k1087 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_1101r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1101r(t0,t1,t2);}}

static void C_ccall f_1101r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1107,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a1106 in ##compiler#gen in k1093 in k1090 in k1087 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1107,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 86   newline */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_retrieve(lf[1]));}
else{
/* c-backend.scm: 87   display */
t4=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve(lf[1]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[672] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_1089c-backend.scm",(void*)f_1089},
{"f_1092c-backend.scm",(void*)f_1092},
{"f_1095c-backend.scm",(void*)f_1095},
{"f_8799c-backend.scm",(void*)f_8799},
{"f_8803c-backend.scm",(void*)f_8803},
{"f_8795c-backend.scm",(void*)f_8795},
{"f_1140c-backend.scm",(void*)f_1140},
{"f_8495c-backend.scm",(void*)f_8495},
{"f_8771c-backend.scm",(void*)f_8771},
{"f_8769c-backend.scm",(void*)f_8769},
{"f_8757c-backend.scm",(void*)f_8757},
{"f_8727c-backend.scm",(void*)f_8727},
{"f_8688c-backend.scm",(void*)f_8688},
{"f_8675c-backend.scm",(void*)f_8675},
{"f_8671c-backend.scm",(void*)f_8671},
{"f_8557c-backend.scm",(void*)f_8557},
{"f_8504c-backend.scm",(void*)f_8504},
{"f_8501c-backend.scm",(void*)f_8501},
{"f_8498c-backend.scm",(void*)f_8498},
{"f_7721c-backend.scm",(void*)f_7721},
{"f_7808c-backend.scm",(void*)f_7808},
{"f_7889c-backend.scm",(void*)f_7889},
{"f_8324c-backend.scm",(void*)f_8324},
{"f_8266c-backend.scm",(void*)f_8266},
{"f_8230c-backend.scm",(void*)f_8230},
{"f_8195c-backend.scm",(void*)f_8195},
{"f_8147c-backend.scm",(void*)f_8147},
{"f_8099c-backend.scm",(void*)f_8099},
{"f_8051c-backend.scm",(void*)f_8051},
{"f_8016c-backend.scm",(void*)f_8016},
{"f_7980c-backend.scm",(void*)f_7980},
{"f_7944c-backend.scm",(void*)f_7944},
{"f_7922c-backend.scm",(void*)f_7922},
{"f_7917c-backend.scm",(void*)f_7917},
{"f_7912c-backend.scm",(void*)f_7912},
{"f_7723c-backend.scm",(void*)f_7723},
{"f_6888c-backend.scm",(void*)f_6888},
{"f_6918c-backend.scm",(void*)f_6918},
{"f_6945c-backend.scm",(void*)f_6945},
{"f_7140c-backend.scm",(void*)f_7140},
{"f_7149c-backend.scm",(void*)f_7149},
{"f_7158c-backend.scm",(void*)f_7158},
{"f_7546c-backend.scm",(void*)f_7546},
{"f_7513c-backend.scm",(void*)f_7513},
{"f_7523c-backend.scm",(void*)f_7523},
{"f_7481c-backend.scm",(void*)f_7481},
{"f_7446c-backend.scm",(void*)f_7446},
{"f_7376c-backend.scm",(void*)f_7376},
{"f_7331c-backend.scm",(void*)f_7331},
{"f_7299c-backend.scm",(void*)f_7299},
{"f_7267c-backend.scm",(void*)f_7267},
{"f_7235c-backend.scm",(void*)f_7235},
{"f_7203c-backend.scm",(void*)f_7203},
{"f_7181c-backend.scm",(void*)f_7181},
{"f_6890c-backend.scm",(void*)f_6890},
{"f_5671c-backend.scm",(void*)f_5671},
{"f_5748c-backend.scm",(void*)f_5748},
{"f_5850c-backend.scm",(void*)f_5850},
{"f_5883c-backend.scm",(void*)f_5883},
{"f_5979c-backend.scm",(void*)f_5979},
{"f_5994c-backend.scm",(void*)f_5994},
{"f_6611c-backend.scm",(void*)f_6611},
{"f_6627c-backend.scm",(void*)f_6627},
{"f_6631c-backend.scm",(void*)f_6631},
{"f_6644c-backend.scm",(void*)f_6644},
{"f_6642c-backend.scm",(void*)f_6642},
{"f_6638c-backend.scm",(void*)f_6638},
{"f_6565c-backend.scm",(void*)f_6565},
{"f_6578c-backend.scm",(void*)f_6578},
{"f_6515c-backend.scm",(void*)f_6515},
{"f_6465c-backend.scm",(void*)f_6465},
{"f_6426c-backend.scm",(void*)f_6426},
{"f_6436c-backend.scm",(void*)f_6436},
{"f_6387c-backend.scm",(void*)f_6387},
{"f_6397c-backend.scm",(void*)f_6397},
{"f_6348c-backend.scm",(void*)f_6348},
{"f_6358c-backend.scm",(void*)f_6358},
{"f_6309c-backend.scm",(void*)f_6309},
{"f_6319c-backend.scm",(void*)f_6319},
{"f_6249c-backend.scm",(void*)f_6249},
{"f_6266c-backend.scm",(void*)f_6266},
{"f_6276c-backend.scm",(void*)f_6276},
{"f_6274c-backend.scm",(void*)f_6274},
{"f_6270c-backend.scm",(void*)f_6270},
{"f_6262c-backend.scm",(void*)f_6262},
{"f_6210c-backend.scm",(void*)f_6210},
{"f_6220c-backend.scm",(void*)f_6220},
{"f_6174c-backend.scm",(void*)f_6174},
{"f_6138c-backend.scm",(void*)f_6138},
{"f_6102c-backend.scm",(void*)f_6102},
{"f_6066c-backend.scm",(void*)f_6066},
{"f_6040c-backend.scm",(void*)f_6040},
{"f_6048c-backend.scm",(void*)f_6048},
{"f_6031c-backend.scm",(void*)f_6031},
{"f_6039c-backend.scm",(void*)f_6039},
{"f_6026c-backend.scm",(void*)f_6026},
{"f_5678c-backend.scm",(void*)f_5678},
{"f_5673c-backend.scm",(void*)f_5673},
{"f_5606c-backend.scm",(void*)f_5606},
{"f_5610c-backend.scm",(void*)f_5610},
{"f_5613c-backend.scm",(void*)f_5613},
{"f_5616c-backend.scm",(void*)f_5616},
{"f_5619c-backend.scm",(void*)f_5619},
{"f_5625c-backend.scm",(void*)f_5625},
{"f_5669c-backend.scm",(void*)f_5669},
{"f_5628c-backend.scm",(void*)f_5628},
{"f_5636c-backend.scm",(void*)f_5636},
{"f_5657c-backend.scm",(void*)f_5657},
{"f_5640c-backend.scm",(void*)f_5640},
{"f_5631c-backend.scm",(void*)f_5631},
{"f_5175c-backend.scm",(void*)f_5175},
{"f_5181c-backend.scm",(void*)f_5181},
{"f_5185c-backend.scm",(void*)f_5185},
{"f_5188c-backend.scm",(void*)f_5188},
{"f_5191c-backend.scm",(void*)f_5191},
{"f_5194c-backend.scm",(void*)f_5194},
{"f_5200c-backend.scm",(void*)f_5200},
{"f_5541c-backend.scm",(void*)f_5541},
{"f_5544c-backend.scm",(void*)f_5544},
{"f_5604c-backend.scm",(void*)f_5604},
{"f_5547c-backend.scm",(void*)f_5547},
{"f_5550c-backend.scm",(void*)f_5550},
{"f_5553c-backend.scm",(void*)f_5553},
{"f_5556c-backend.scm",(void*)f_5556},
{"f_5589c-backend.scm",(void*)f_5589},
{"f_5597c-backend.scm",(void*)f_5597},
{"f_5559c-backend.scm",(void*)f_5559},
{"f_5587c-backend.scm",(void*)f_5587},
{"f_5562c-backend.scm",(void*)f_5562},
{"f_5565c-backend.scm",(void*)f_5565},
{"f_5568c-backend.scm",(void*)f_5568},
{"f_5202c-backend.scm",(void*)f_5202},
{"f_5212c-backend.scm",(void*)f_5212},
{"f_5221c-backend.scm",(void*)f_5221},
{"f_5233c-backend.scm",(void*)f_5233},
{"f_5245c-backend.scm",(void*)f_5245},
{"f_5251c-backend.scm",(void*)f_5251},
{"f_5285c-backend.scm",(void*)f_5285},
{"f_4942c-backend.scm",(void*)f_4942},
{"f_4948c-backend.scm",(void*)f_4948},
{"f_4952c-backend.scm",(void*)f_4952},
{"f_4955c-backend.scm",(void*)f_4955},
{"f_4958c-backend.scm",(void*)f_4958},
{"f_5173c-backend.scm",(void*)f_5173},
{"f_4964c-backend.scm",(void*)f_4964},
{"f_4967c-backend.scm",(void*)f_4967},
{"f_4970c-backend.scm",(void*)f_4970},
{"f_4973c-backend.scm",(void*)f_4973},
{"f_4976c-backend.scm",(void*)f_4976},
{"f_4979c-backend.scm",(void*)f_4979},
{"f_4982c-backend.scm",(void*)f_4982},
{"f_4985c-backend.scm",(void*)f_4985},
{"f_4988c-backend.scm",(void*)f_4988},
{"f_4991c-backend.scm",(void*)f_4991},
{"f_5162c-backend.scm",(void*)f_5162},
{"f_4994c-backend.scm",(void*)f_4994},
{"f_4997c-backend.scm",(void*)f_4997},
{"f_5000c-backend.scm",(void*)f_5000},
{"f_5003c-backend.scm",(void*)f_5003},
{"f_5006c-backend.scm",(void*)f_5006},
{"f_5009c-backend.scm",(void*)f_5009},
{"f_5012c-backend.scm",(void*)f_5012},
{"f_5015c-backend.scm",(void*)f_5015},
{"f_5140c-backend.scm",(void*)f_5140},
{"f_5110c-backend.scm",(void*)f_5110},
{"f_5130c-backend.scm",(void*)f_5130},
{"f_5118c-backend.scm",(void*)f_5118},
{"f_5122c-backend.scm",(void*)f_5122},
{"f_5126c-backend.scm",(void*)f_5126},
{"f_5018c-backend.scm",(void*)f_5018},
{"f_5021c-backend.scm",(void*)f_5021},
{"f_5051c-backend.scm",(void*)f_5051},
{"f_5054c-backend.scm",(void*)f_5054},
{"f_5092c-backend.scm",(void*)f_5092},
{"f_5088c-backend.scm",(void*)f_5088},
{"f_5057c-backend.scm",(void*)f_5057},
{"f_5060c-backend.scm",(void*)f_5060},
{"f_5063c-backend.scm",(void*)f_5063},
{"f_5030c-backend.scm",(void*)f_5030},
{"f_5033c-backend.scm",(void*)f_5033},
{"f_5024c-backend.scm",(void*)f_5024},
{"f_4924c-backend.scm",(void*)f_4924},
{"f_4930c-backend.scm",(void*)f_4930},
{"f_4934c-backend.scm",(void*)f_4934},
{"f_4937c-backend.scm",(void*)f_4937},
{"f_4873c-backend.scm",(void*)f_4873},
{"f_4877c-backend.scm",(void*)f_4877},
{"f_4882c-backend.scm",(void*)f_4882},
{"f_4889c-backend.scm",(void*)f_4889},
{"f_4909c-backend.scm",(void*)f_4909},
{"f_4857c-backend.scm",(void*)f_4857},
{"f_4863c-backend.scm",(void*)f_4863},
{"f_4871c-backend.scm",(void*)f_4871},
{"f_4841c-backend.scm",(void*)f_4841},
{"f_4847c-backend.scm",(void*)f_4847},
{"f_4855c-backend.scm",(void*)f_4855},
{"f_4752c-backend.scm",(void*)f_4752},
{"f_4761c-backend.scm",(void*)f_4761},
{"f_4790c-backend.scm",(void*)f_4790},
{"f_4800c-backend.scm",(void*)f_4800},
{"f_4793c-backend.scm",(void*)f_4793},
{"f_4777c-backend.scm",(void*)f_4777},
{"f_4679c-backend.scm",(void*)f_4679},
{"f_4683c-backend.scm",(void*)f_4683},
{"f_4697c-backend.scm",(void*)f_4697},
{"f_4710c-backend.scm",(void*)f_4710},
{"f_4713c-backend.scm",(void*)f_4713},
{"f_4716c-backend.scm",(void*)f_4716},
{"f_4686c-backend.scm",(void*)f_4686},
{"f_4689c-backend.scm",(void*)f_4689},
{"f_4692c-backend.scm",(void*)f_4692},
{"f_1142c-backend.scm",(void*)f_1142},
{"f_4646c-backend.scm",(void*)f_4646},
{"f_4650c-backend.scm",(void*)f_4650},
{"f_4653c-backend.scm",(void*)f_4653},
{"f_4656c-backend.scm",(void*)f_4656},
{"f_4659c-backend.scm",(void*)f_4659},
{"f_4662c-backend.scm",(void*)f_4662},
{"f_4665c-backend.scm",(void*)f_4665},
{"f_4668c-backend.scm",(void*)f_4668},
{"f_4671c-backend.scm",(void*)f_4671},
{"f_4674c-backend.scm",(void*)f_4674},
{"f_3899c-backend.scm",(void*)f_3899},
{"f_3905c-backend.scm",(void*)f_3905},
{"f_3909c-backend.scm",(void*)f_3909},
{"f_3912c-backend.scm",(void*)f_3912},
{"f_3915c-backend.scm",(void*)f_3915},
{"f_3918c-backend.scm",(void*)f_3918},
{"f_3921c-backend.scm",(void*)f_3921},
{"f_3924c-backend.scm",(void*)f_3924},
{"f_4643c-backend.scm",(void*)f_4643},
{"f_3927c-backend.scm",(void*)f_3927},
{"f_3933c-backend.scm",(void*)f_3933},
{"f_3936c-backend.scm",(void*)f_3936},
{"f_3939c-backend.scm",(void*)f_3939},
{"f_3942c-backend.scm",(void*)f_3942},
{"f_3945c-backend.scm",(void*)f_3945},
{"f_3948c-backend.scm",(void*)f_3948},
{"f_3951c-backend.scm",(void*)f_3951},
{"f_3954c-backend.scm",(void*)f_3954},
{"f_3957c-backend.scm",(void*)f_3957},
{"f_3960c-backend.scm",(void*)f_3960},
{"f_3963c-backend.scm",(void*)f_3963},
{"f_3966c-backend.scm",(void*)f_3966},
{"f_4612c-backend.scm",(void*)f_4612},
{"f_3969c-backend.scm",(void*)f_3969},
{"f_4573c-backend.scm",(void*)f_4573},
{"f_4576c-backend.scm",(void*)f_4576},
{"f_4579c-backend.scm",(void*)f_4579},
{"f_4595c-backend.scm",(void*)f_4595},
{"f_4598c-backend.scm",(void*)f_4598},
{"f_3972c-backend.scm",(void*)f_3972},
{"f_3975c-backend.scm",(void*)f_3975},
{"f_3978c-backend.scm",(void*)f_3978},
{"f_4545c-backend.scm",(void*)f_4545},
{"f_4548c-backend.scm",(void*)f_4548},
{"f_3981c-backend.scm",(void*)f_3981},
{"f_3984c-backend.scm",(void*)f_3984},
{"f_3987c-backend.scm",(void*)f_3987},
{"f_3990c-backend.scm",(void*)f_3990},
{"f_3993c-backend.scm",(void*)f_3993},
{"f_3996c-backend.scm",(void*)f_3996},
{"f_4507c-backend.scm",(void*)f_4507},
{"f_4517c-backend.scm",(void*)f_4517},
{"f_3999c-backend.scm",(void*)f_3999},
{"f_4450c-backend.scm",(void*)f_4450},
{"f_4462c-backend.scm",(void*)f_4462},
{"f_4465c-backend.scm",(void*)f_4465},
{"f_4471c-backend.scm",(void*)f_4471},
{"f_4372c-backend.scm",(void*)f_4372},
{"f_4414c-backend.scm",(void*)f_4414},
{"f_4375c-backend.scm",(void*)f_4375},
{"f_4381c-backend.scm",(void*)f_4381},
{"f_4384c-backend.scm",(void*)f_4384},
{"f_4390c-backend.scm",(void*)f_4390},
{"f_4308c-backend.scm",(void*)f_4308},
{"f_4311c-backend.scm",(void*)f_4311},
{"f_4314c-backend.scm",(void*)f_4314},
{"f_4317c-backend.scm",(void*)f_4317},
{"f_4320c-backend.scm",(void*)f_4320},
{"f_4335c-backend.scm",(void*)f_4335},
{"f_4323c-backend.scm",(void*)f_4323},
{"f_4326c-backend.scm",(void*)f_4326},
{"f_4294c-backend.scm",(void*)f_4294},
{"f_4302c-backend.scm",(void*)f_4302},
{"f_4219c-backend.scm",(void*)f_4219},
{"f_4225c-backend.scm",(void*)f_4225},
{"f_4228c-backend.scm",(void*)f_4228},
{"f_4262c-backend.scm",(void*)f_4262},
{"f_4265c-backend.scm",(void*)f_4265},
{"f_4268c-backend.scm",(void*)f_4268},
{"f_4231c-backend.scm",(void*)f_4231},
{"f_4234c-backend.scm",(void*)f_4234},
{"f_4237c-backend.scm",(void*)f_4237},
{"f_4240c-backend.scm",(void*)f_4240},
{"f_4249c-backend.scm",(void*)f_4249},
{"f_4252c-backend.scm",(void*)f_4252},
{"f_4002c-backend.scm",(void*)f_4002},
{"f_4025c-backend.scm",(void*)f_4025},
{"f_4160c-backend.scm",(void*)f_4160},
{"f_4163c-backend.scm",(void*)f_4163},
{"f_4175c-backend.scm",(void*)f_4175},
{"f_4166c-backend.scm",(void*)f_4166},
{"f_4031c-backend.scm",(void*)f_4031},
{"f_4034c-backend.scm",(void*)f_4034},
{"f_4037c-backend.scm",(void*)f_4037},
{"f_4141c-backend.scm",(void*)f_4141},
{"f_4040c-backend.scm",(void*)f_4040},
{"f_4043c-backend.scm",(void*)f_4043},
{"f_4046c-backend.scm",(void*)f_4046},
{"f_4049c-backend.scm",(void*)f_4049},
{"f_4114c-backend.scm",(void*)f_4114},
{"f_4110c-backend.scm",(void*)f_4110},
{"f_4052c-backend.scm",(void*)f_4052},
{"f_4055c-backend.scm",(void*)f_4055},
{"f_4058c-backend.scm",(void*)f_4058},
{"f_4061c-backend.scm",(void*)f_4061},
{"f_4064c-backend.scm",(void*)f_4064},
{"f_4067c-backend.scm",(void*)f_4067},
{"f_4085c-backend.scm",(void*)f_4085},
{"f_4095c-backend.scm",(void*)f_4095},
{"f_4070c-backend.scm",(void*)f_4070},
{"f_4005c-backend.scm",(void*)f_4005},
{"f_4015c-backend.scm",(void*)f_4015},
{"f_4008c-backend.scm",(void*)f_4008},
{"f_3509c-backend.scm",(void*)f_3509},
{"f_3516c-backend.scm",(void*)f_3516},
{"f_3590c-backend.scm",(void*)f_3590},
{"f_3608c-backend.scm",(void*)f_3608},
{"f_3637c-backend.scm",(void*)f_3637},
{"f_3659c-backend.scm",(void*)f_3659},
{"f_3615c-backend.scm",(void*)f_3615},
{"f_3584c-backend.scm",(void*)f_3584},
{"f_3580c-backend.scm",(void*)f_3580},
{"f_3576c-backend.scm",(void*)f_3576},
{"f_3547c-backend.scm",(void*)f_3547},
{"f_3551c-backend.scm",(void*)f_3551},
{"f_3466c-backend.scm",(void*)f_3466},
{"f_3472c-backend.scm",(void*)f_3472},
{"f_3501c-backend.scm",(void*)f_3501},
{"f_3482c-backend.scm",(void*)f_3482},
{"f_3668c-backend.scm",(void*)f_3668},
{"f_3808c-backend.scm",(void*)f_3808},
{"f_3675c-backend.scm",(void*)f_3675},
{"f_3681c-backend.scm",(void*)f_3681},
{"f_3764c-backend.scm",(void*)f_3764},
{"f_3767c-backend.scm",(void*)f_3767},
{"f_3777c-backend.scm",(void*)f_3777},
{"f_3770c-backend.scm",(void*)f_3770},
{"f_3731c-backend.scm",(void*)f_3731},
{"f_3737c-backend.scm",(void*)f_3737},
{"f_3503c-backend.scm",(void*)f_3503},
{"f_3810c-backend.scm",(void*)f_3810},
{"f_3817c-backend.scm",(void*)f_3817},
{"f_3820c-backend.scm",(void*)f_3820},
{"f_3825c-backend.scm",(void*)f_3825},
{"f_3881c-backend.scm",(void*)f_3881},
{"f_3877c-backend.scm",(void*)f_3877},
{"f_3862c-backend.scm",(void*)f_3862},
{"f_3841c-backend.scm",(void*)f_3841},
{"f_3852c-backend.scm",(void*)f_3852},
{"f_3848c-backend.scm",(void*)f_3848},
{"f_3887c-backend.scm",(void*)f_3887},
{"f_3894c-backend.scm",(void*)f_3894},
{"f_3897c-backend.scm",(void*)f_3897},
{"f_3180c-backend.scm",(void*)f_3180},
{"f_3347c-backend.scm",(void*)f_3347},
{"f_3351c-backend.scm",(void*)f_3351},
{"f_3354c-backend.scm",(void*)f_3354},
{"f_3357c-backend.scm",(void*)f_3357},
{"f_3360c-backend.scm",(void*)f_3360},
{"f_3363c-backend.scm",(void*)f_3363},
{"f_3464c-backend.scm",(void*)f_3464},
{"f_3366c-backend.scm",(void*)f_3366},
{"f_3369c-backend.scm",(void*)f_3369},
{"f_3375c-backend.scm",(void*)f_3375},
{"f_3453c-backend.scm",(void*)f_3453},
{"f_3409c-backend.scm",(void*)f_3409},
{"f_3415c-backend.scm",(void*)f_3415},
{"f_3433c-backend.scm",(void*)f_3433},
{"f_3429c-backend.scm",(void*)f_3429},
{"f_3425c-backend.scm",(void*)f_3425},
{"f_3381c-backend.scm",(void*)f_3381},
{"f_3384c-backend.scm",(void*)f_3384},
{"f_3387c-backend.scm",(void*)f_3387},
{"f_3390c-backend.scm",(void*)f_3390},
{"f_3393c-backend.scm",(void*)f_3393},
{"f_3403c-backend.scm",(void*)f_3403},
{"f_3396c-backend.scm",(void*)f_3396},
{"f_3299c-backend.scm",(void*)f_3299},
{"f_3318c-backend.scm",(void*)f_3318},
{"f_3322c-backend.scm",(void*)f_3322},
{"f_3325c-backend.scm",(void*)f_3325},
{"f_3328c-backend.scm",(void*)f_3328},
{"f_3331c-backend.scm",(void*)f_3331},
{"f_3345c-backend.scm",(void*)f_3345},
{"f_3341c-backend.scm",(void*)f_3341},
{"f_3334c-backend.scm",(void*)f_3334},
{"f_3302c-backend.scm",(void*)f_3302},
{"f_3316c-backend.scm",(void*)f_3316},
{"f_3305c-backend.scm",(void*)f_3305},
{"f_3312c-backend.scm",(void*)f_3312},
{"f_3219c-backend.scm",(void*)f_3219},
{"f_3221c-backend.scm",(void*)f_3221},
{"f_3225c-backend.scm",(void*)f_3225},
{"f_3228c-backend.scm",(void*)f_3228},
{"f_3231c-backend.scm",(void*)f_3231},
{"f_3234c-backend.scm",(void*)f_3234},
{"f_3237c-backend.scm",(void*)f_3237},
{"f_3240c-backend.scm",(void*)f_3240},
{"f_3243c-backend.scm",(void*)f_3243},
{"f_3246c-backend.scm",(void*)f_3246},
{"f_3249c-backend.scm",(void*)f_3249},
{"f_3252c-backend.scm",(void*)f_3252},
{"f_3255c-backend.scm",(void*)f_3255},
{"f_3258c-backend.scm",(void*)f_3258},
{"f_3272c-backend.scm",(void*)f_3272},
{"f_3268c-backend.scm",(void*)f_3268},
{"f_3261c-backend.scm",(void*)f_3261},
{"f_3183c-backend.scm",(void*)f_3183},
{"f_3196c-backend.scm",(void*)f_3196},
{"f_3206c-backend.scm",(void*)f_3206},
{"f_3187c-backend.scm",(void*)f_3187},
{"f_2929c-backend.scm",(void*)f_2929},
{"f_2933c-backend.scm",(void*)f_2933},
{"f_2957c-backend.scm",(void*)f_2957},
{"f_2961c-backend.scm",(void*)f_2961},
{"f_2964c-backend.scm",(void*)f_2964},
{"f_3178c-backend.scm",(void*)f_3178},
{"f_2967c-backend.scm",(void*)f_2967},
{"f_3164c-backend.scm",(void*)f_3164},
{"f_2970c-backend.scm",(void*)f_2970},
{"f_2973c-backend.scm",(void*)f_2973},
{"f_2976c-backend.scm",(void*)f_2976},
{"f_2979c-backend.scm",(void*)f_2979},
{"f_2982c-backend.scm",(void*)f_2982},
{"f_2985c-backend.scm",(void*)f_2985},
{"f_3156c-backend.scm",(void*)f_3156},
{"f_2988c-backend.scm",(void*)f_2988},
{"f_2991c-backend.scm",(void*)f_2991},
{"f_3149c-backend.scm",(void*)f_3149},
{"f_3130c-backend.scm",(void*)f_3130},
{"f_3141c-backend.scm",(void*)f_3141},
{"f_2994c-backend.scm",(void*)f_2994},
{"f_3081c-backend.scm",(void*)f_3081},
{"f_3084c-backend.scm",(void*)f_3084},
{"f_3087c-backend.scm",(void*)f_3087},
{"f_3090c-backend.scm",(void*)f_3090},
{"f_3106c-backend.scm",(void*)f_3106},
{"f_3109c-backend.scm",(void*)f_3109},
{"f_3112c-backend.scm",(void*)f_3112},
{"f_3115c-backend.scm",(void*)f_3115},
{"f_2997c-backend.scm",(void*)f_2997},
{"f_3000c-backend.scm",(void*)f_3000},
{"f_3003c-backend.scm",(void*)f_3003},
{"f_3053c-backend.scm",(void*)f_3053},
{"f_3056c-backend.scm",(void*)f_3056},
{"f_3006c-backend.scm",(void*)f_3006},
{"f_3009c-backend.scm",(void*)f_3009},
{"f_3041c-backend.scm",(void*)f_3041},
{"f_3044c-backend.scm",(void*)f_3044},
{"f_3015c-backend.scm",(void*)f_3015},
{"f_3024c-backend.scm",(void*)f_3024},
{"f_3027c-backend.scm",(void*)f_3027},
{"f_2936c-backend.scm",(void*)f_2936},
{"f_2941c-backend.scm",(void*)f_2941},
{"f_2945c-backend.scm",(void*)f_2945},
{"f_2955c-backend.scm",(void*)f_2955},
{"f_2948c-backend.scm",(void*)f_2948},
{"f_2780c-backend.scm",(void*)f_2780},
{"f_2787c-backend.scm",(void*)f_2787},
{"f_2923c-backend.scm",(void*)f_2923},
{"f_2790c-backend.scm",(void*)f_2790},
{"f_2793c-backend.scm",(void*)f_2793},
{"f_2796c-backend.scm",(void*)f_2796},
{"f_2801c-backend.scm",(void*)f_2801},
{"f_2811c-backend.scm",(void*)f_2811},
{"f_2817c-backend.scm",(void*)f_2817},
{"f_2870c-backend.scm",(void*)f_2870},
{"f_2880c-backend.scm",(void*)f_2880},
{"f_2820c-backend.scm",(void*)f_2820},
{"f_2843c-backend.scm",(void*)f_2843},
{"f_2853c-backend.scm",(void*)f_2853},
{"f_2823c-backend.scm",(void*)f_2823},
{"f_2826c-backend.scm",(void*)f_2826},
{"f_2614c-backend.scm",(void*)f_2614},
{"f_2772c-backend.scm",(void*)f_2772},
{"f_2634c-backend.scm",(void*)f_2634},
{"f_2640c-backend.scm",(void*)f_2640},
{"f_2717c-backend.scm",(void*)f_2717},
{"f_2721c-backend.scm",(void*)f_2721},
{"f_2725c-backend.scm",(void*)f_2725},
{"f_2729c-backend.scm",(void*)f_2729},
{"f_2751c-backend.scm",(void*)f_2751},
{"f_2747c-backend.scm",(void*)f_2747},
{"f_2739c-backend.scm",(void*)f_2739},
{"f_2737c-backend.scm",(void*)f_2737},
{"f_2733c-backend.scm",(void*)f_2733},
{"f_2658c-backend.scm",(void*)f_2658},
{"f_2661c-backend.scm",(void*)f_2661},
{"f_2664c-backend.scm",(void*)f_2664},
{"f_2706c-backend.scm",(void*)f_2706},
{"f_2667c-backend.scm",(void*)f_2667},
{"f_2670c-backend.scm",(void*)f_2670},
{"f_2673c-backend.scm",(void*)f_2673},
{"f_2688c-backend.scm",(void*)f_2688},
{"f_2693c-backend.scm",(void*)f_2693},
{"f_2676c-backend.scm",(void*)f_2676},
{"f_2617c-backend.scm",(void*)f_2617},
{"f_2631c-backend.scm",(void*)f_2631},
{"f_1187c-backend.scm",(void*)f_1187},
{"f_2582c-backend.scm",(void*)f_2582},
{"f_2588c-backend.scm",(void*)f_2588},
{"f_2592c-backend.scm",(void*)f_2592},
{"f_1190c-backend.scm",(void*)f_1190},
{"f_2547c-backend.scm",(void*)f_2547},
{"f_2550c-backend.scm",(void*)f_2550},
{"f_2553c-backend.scm",(void*)f_2553},
{"f_2556c-backend.scm",(void*)f_2556},
{"f_2559c-backend.scm",(void*)f_2559},
{"f_2562c-backend.scm",(void*)f_2562},
{"f_2464c-backend.scm",(void*)f_2464},
{"f_2467c-backend.scm",(void*)f_2467},
{"f_2470c-backend.scm",(void*)f_2470},
{"f_2483c-backend.scm",(void*)f_2483},
{"f_2506c-backend.scm",(void*)f_2506},
{"f_2509c-backend.scm",(void*)f_2509},
{"f_2512c-backend.scm",(void*)f_2512},
{"f_2515c-backend.scm",(void*)f_2515},
{"f_2493c-backend.scm",(void*)f_2493},
{"f_2496c-backend.scm",(void*)f_2496},
{"f_2455c-backend.scm",(void*)f_2455},
{"f_2427c-backend.scm",(void*)f_2427},
{"f_2430c-backend.scm",(void*)f_2430},
{"f_2447c-backend.scm",(void*)f_2447},
{"f_2433c-backend.scm",(void*)f_2433},
{"f_2436c-backend.scm",(void*)f_2436},
{"f_2411c-backend.scm",(void*)f_2411},
{"f_2415c-backend.scm",(void*)f_2415},
{"f_2397c-backend.scm",(void*)f_2397},
{"f_2400c-backend.scm",(void*)f_2400},
{"f_2381c-backend.scm",(void*)f_2381},
{"f_2385c-backend.scm",(void*)f_2385},
{"f_2363c-backend.scm",(void*)f_2363},
{"f_2366c-backend.scm",(void*)f_2366},
{"f_2343c-backend.scm",(void*)f_2343},
{"f_2307c-backend.scm",(void*)f_2307},
{"f_2319c-backend.scm",(void*)f_2319},
{"f_2310c-backend.scm",(void*)f_2310},
{"f_2288c-backend.scm",(void*)f_2288},
{"f_2291c-backend.scm",(void*)f_2291},
{"f_2269c-backend.scm",(void*)f_2269},
{"f_2272c-backend.scm",(void*)f_2272},
{"f_2250c-backend.scm",(void*)f_2250},
{"f_2253c-backend.scm",(void*)f_2253},
{"f_2231c-backend.scm",(void*)f_2231},
{"f_2227c-backend.scm",(void*)f_2227},
{"f_2175c-backend.scm",(void*)f_2175},
{"f_2208c-backend.scm",(void*)f_2208},
{"f_2178c-backend.scm",(void*)f_2178},
{"f_2196c-backend.scm",(void*)f_2196},
{"f_2181c-backend.scm",(void*)f_2181},
{"f_2184c-backend.scm",(void*)f_2184},
{"f_2142c-backend.scm",(void*)f_2142},
{"f_2126c-backend.scm",(void*)f_2126},
{"f_2129c-backend.scm",(void*)f_2129},
{"f_2132c-backend.scm",(void*)f_2132},
{"f_2085c-backend.scm",(void*)f_2085},
{"f_2088c-backend.scm",(void*)f_2088},
{"f_2109c-backend.scm",(void*)f_2109},
{"f_2113c-backend.scm",(void*)f_2113},
{"f_2116c-backend.scm",(void*)f_2116},
{"f_2091c-backend.scm",(void*)f_2091},
{"f_2107c-backend.scm",(void*)f_2107},
{"f_2099c-backend.scm",(void*)f_2099},
{"f_2094c-backend.scm",(void*)f_2094},
{"f_1831c-backend.scm",(void*)f_1831},
{"f_1834c-backend.scm",(void*)f_1834},
{"f_2035c-backend.scm",(void*)f_2035},
{"f_2031c-backend.scm",(void*)f_2031},
{"f_1840c-backend.scm",(void*)f_1840},
{"f_1185c-backend.scm",(void*)f_1185},
{"f_2024c-backend.scm",(void*)f_2024},
{"f_1175c-backend.scm",(void*)f_1175},
{"f_2017c-backend.scm",(void*)f_2017},
{"f_1846c-backend.scm",(void*)f_1846},
{"f_1970c-backend.scm",(void*)f_1970},
{"f_1973c-backend.scm",(void*)f_1973},
{"f_1976c-backend.scm",(void*)f_1976},
{"f_1991c-backend.scm",(void*)f_1991},
{"f_1979c-backend.scm",(void*)f_1979},
{"f_1982c-backend.scm",(void*)f_1982},
{"f_1985c-backend.scm",(void*)f_1985},
{"f_1967c-backend.scm",(void*)f_1967},
{"f_1877c-backend.scm",(void*)f_1877},
{"f_1951c-backend.scm",(void*)f_1951},
{"f_1954c-backend.scm",(void*)f_1954},
{"f_1927c-backend.scm",(void*)f_1927},
{"f_1930c-backend.scm",(void*)f_1930},
{"f_1933c-backend.scm",(void*)f_1933},
{"f_1936c-backend.scm",(void*)f_1936},
{"f_1939c-backend.scm",(void*)f_1939},
{"f_1880c-backend.scm",(void*)f_1880},
{"f_1883c-backend.scm",(void*)f_1883},
{"f_1910c-backend.scm",(void*)f_1910},
{"f_1914c-backend.scm",(void*)f_1914},
{"f_1917c-backend.scm",(void*)f_1917},
{"f_1886c-backend.scm",(void*)f_1886},
{"f_1908c-backend.scm",(void*)f_1908},
{"f_1900c-backend.scm",(void*)f_1900},
{"f_1889c-backend.scm",(void*)f_1889},
{"f_1892c-backend.scm",(void*)f_1892},
{"f_1858c-backend.scm",(void*)f_1858},
{"f_1861c-backend.scm",(void*)f_1861},
{"f_1788c-backend.scm",(void*)f_1788},
{"f_1791c-backend.scm",(void*)f_1791},
{"f_1775c-backend.scm",(void*)f_1775},
{"f_1778c-backend.scm",(void*)f_1778},
{"f_1741c-backend.scm",(void*)f_1741},
{"f_1744c-backend.scm",(void*)f_1744},
{"f_1713c-backend.scm",(void*)f_1713},
{"f_1709c-backend.scm",(void*)f_1709},
{"f_1667c-backend.scm",(void*)f_1667},
{"f_1635c-backend.scm",(void*)f_1635},
{"f_1638c-backend.scm",(void*)f_1638},
{"f_1600c-backend.scm",(void*)f_1600},
{"f_1626c-backend.scm",(void*)f_1626},
{"f_1612c-backend.scm",(void*)f_1612},
{"f_1616c-backend.scm",(void*)f_1616},
{"f_1619c-backend.scm",(void*)f_1619},
{"f_1603c-backend.scm",(void*)f_1603},
{"f_1568c-backend.scm",(void*)f_1568},
{"f_1571c-backend.scm",(void*)f_1571},
{"f_1574c-backend.scm",(void*)f_1574},
{"f_1577c-backend.scm",(void*)f_1577},
{"f_1539c-backend.scm",(void*)f_1539},
{"f_1542c-backend.scm",(void*)f_1542},
{"f_1545c-backend.scm",(void*)f_1545},
{"f_1548c-backend.scm",(void*)f_1548},
{"f_1502c-backend.scm",(void*)f_1502},
{"f_1505c-backend.scm",(void*)f_1505},
{"f_1508c-backend.scm",(void*)f_1508},
{"f_1511c-backend.scm",(void*)f_1511},
{"f_1469c-backend.scm",(void*)f_1469},
{"f_1472c-backend.scm",(void*)f_1472},
{"f_1475c-backend.scm",(void*)f_1475},
{"f_1478c-backend.scm",(void*)f_1478},
{"f_1450c-backend.scm",(void*)f_1450},
{"f_1453c-backend.scm",(void*)f_1453},
{"f_1423c-backend.scm",(void*)f_1423},
{"f_1426c-backend.scm",(void*)f_1426},
{"f_1372c-backend.scm",(void*)f_1372},
{"f_1382c-backend.scm",(void*)f_1382},
{"f_1385c-backend.scm",(void*)f_1385},
{"f_1388c-backend.scm",(void*)f_1388},
{"f_1314c-backend.scm",(void*)f_1314},
{"f_1317c-backend.scm",(void*)f_1317},
{"f_1320c-backend.scm",(void*)f_1320},
{"f_1323c-backend.scm",(void*)f_1323},
{"f_1326c-backend.scm",(void*)f_1326},
{"f_1329c-backend.scm",(void*)f_1329},
{"f_1145c-backend.scm",(void*)f_1145},
{"f_1157c-backend.scm",(void*)f_1157},
{"f_1165c-backend.scm",(void*)f_1165},
{"f_1149c-backend.scm",(void*)f_1149},
{"f_1122c-backend.scm",(void*)f_1122},
{"f_1136c-backend.scm",(void*)f_1136},
{"f_1128c-backend.scm",(void*)f_1128},
{"f_1101c-backend.scm",(void*)f_1101},
{"f_1107c-backend.scm",(void*)f_1107},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
