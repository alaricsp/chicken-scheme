/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-11 10:07
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-01-28 on dill (Linux)
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[814];
static double C_possibly_force_alignment;


/* from getsize in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1050(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1050(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1046(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1046(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8795)
static void C_ccall f_8795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8787)
static void C_ccall f_8787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8487)
static void C_ccall f_8487(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8763)
static void C_ccall f_8763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8761)
static void C_ccall f_8761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8749)
static void C_ccall f_8749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8719)
static void C_ccall f_8719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8680)
static void C_ccall f_8680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8663)
static void C_ccall f_8663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8549)
static void C_ccall f_8549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8496)
static C_word C_fcall f_8496(C_word *a,C_word t0);
C_noret_decl(f_8493)
static C_word C_fcall f_8493(C_word t0);
C_noret_decl(f_8490)
static C_word C_fcall f_8490(C_word t0);
C_noret_decl(f_7713)
static void C_ccall f_7713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7800)
static void C_fcall f_7800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8316)
static void C_fcall f_8316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8258)
static void C_fcall f_8258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8222)
static void C_fcall f_8222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8187)
static void C_fcall f_8187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8139)
static void C_fcall f_8139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8091)
static void C_fcall f_8091(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8043)
static void C_fcall f_8043(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8008)
static void C_fcall f_8008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7972)
static void C_fcall f_7972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7936)
static void C_fcall f_7936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_fcall f_7914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_fcall f_7909(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7904)
static void C_fcall f_7904(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7715)
static void C_fcall f_7715(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6910)
static void C_fcall f_6910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_fcall f_6937(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7132)
static void C_fcall f_7132(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_fcall f_7141(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7150)
static void C_ccall f_7150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7538)
static void C_fcall f_7538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_fcall f_7505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7473)
static void C_fcall f_7473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7438)
static void C_fcall f_7438(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7368)
static void C_fcall f_7368(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7323)
static void C_fcall f_7323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7291)
static void C_fcall f_7291(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7259)
static void C_fcall f_7259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7227)
static void C_fcall f_7227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_fcall f_7195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7173)
static void C_fcall f_7173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6882)
static void C_fcall f_6882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5740)
static void C_fcall f_5740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5842)
static void C_fcall f_5842(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_fcall f_5875(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_fcall f_5971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6603)
static void C_fcall f_6603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6623)
static void C_fcall f_6623(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6630)
static void C_ccall f_6630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6557)
static void C_fcall f_6557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6570)
static void C_ccall f_6570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6507)
static void C_fcall f_6507(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_fcall f_6457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_fcall f_6418(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6379)
static void C_fcall f_6379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6389)
static void C_ccall f_6389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6340)
static void C_fcall f_6340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_fcall f_6301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_ccall f_6311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6241)
static void C_fcall f_6241(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6266)
static void C_ccall f_6266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6254)
static void C_ccall f_6254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6202)
static void C_fcall f_6202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6212)
static void C_ccall f_6212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_fcall f_6166(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6130)
static void C_fcall f_6130(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_fcall f_6094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_fcall f_6058(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6032)
static void C_fcall f_6032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6040)
static void C_ccall f_6040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_fcall f_6023(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6018)
static void C_fcall f_6018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_fcall f_5670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5665)
static void C_fcall f_5665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5608)
static void C_ccall f_5608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5620)
static void C_ccall f_5620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5204)
static void C_fcall f_5204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_fcall f_5213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5225)
static void C_fcall f_5225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_fcall f_5237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5277)
static void C_fcall f_5277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4971)
static void C_ccall f_4971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5122)
static void C_ccall f_5122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5046)
static void C_ccall f_5046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_ccall f_5049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5022)
static void C_ccall f_5022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4881)
static void C_fcall f_4881(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4849)
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4753)
static void C_fcall f_4753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4782)
static void C_fcall f_4782(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_fcall f_4785(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_fcall f_4769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_fcall f_4689(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4705)
static void C_ccall f_4705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4708)
static void C_ccall f_4708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4645)
static void C_ccall f_4645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4666)
static void C_ccall f_4666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_fcall f_3891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3901)
static void C_ccall f_3901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3904)
static void C_ccall f_3904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3916)
static void C_ccall f_3916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_fcall f_3919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3940)
static void C_ccall f_3940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3955)
static void C_ccall f_3955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_ccall f_3970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_fcall f_4537(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3979)
static void C_ccall f_3979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3982)
static void C_ccall f_3982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_fcall f_3985(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_fcall f_4499(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_fcall f_4442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4463)
static void C_fcall f_4463(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_fcall f_4406(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_fcall f_4373(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_fcall f_4382(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_fcall f_4327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_ccall f_4315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_ccall f_4254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_fcall f_4017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4035)
static void C_ccall f_4035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_fcall f_4077(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3600)
static void C_ccall f_3600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_fcall f_3629(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3607)
static void C_ccall f_3607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3458)
static void C_fcall f_3458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_fcall f_3464(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_fcall f_3660(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_fcall f_3667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_fcall f_3756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_fcall f_3495(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_fcall f_3802(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_fcall f_3817(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_fcall f_3833(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3844)
static void C_ccall f_3844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_fcall f_3879(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3172)
static void C_fcall f_3172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_fcall f_3358(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_fcall f_3361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_fcall f_3407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_ccall f_3382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_fcall f_3211(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_fcall f_3175(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_fcall f_3188(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3179)
static void C_ccall f_3179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2921)
static void C_fcall f_2921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2949)
static void C_ccall f_2949(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_fcall f_2959(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_fcall f_2980(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_ccall f_2995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_fcall f_3045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2780)
static void C_fcall f_2780(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_fcall f_2801(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_fcall f_2862(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_fcall f_2843(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_fcall f_2614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_fcall f_2640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_ccall f_2721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2751)
static void C_ccall f_2751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2706)
static void C_ccall f_2706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_ccall f_2688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_fcall f_2617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_fcall f_1187(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2582)
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_fcall f_1190(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2550)
static void C_ccall f_2550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2559)
static void C_ccall f_2559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_fcall f_2483(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2512)
static void C_ccall f_2512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2175)
static void C_ccall f_2175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_fcall f_1834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_fcall f_1840(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_fcall f_1991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1478)
static void C_ccall f_1478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_fcall f_1145(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1107)
static void C_ccall f_1107(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_7800)
static void C_fcall trf_7800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7800(t0,t1);}

C_noret_decl(trf_8316)
static void C_fcall trf_8316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8316(t0,t1);}

C_noret_decl(trf_8258)
static void C_fcall trf_8258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8258(t0,t1);}

C_noret_decl(trf_8222)
static void C_fcall trf_8222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8222(t0,t1);}

C_noret_decl(trf_8187)
static void C_fcall trf_8187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8187(t0,t1);}

C_noret_decl(trf_8139)
static void C_fcall trf_8139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8139(t0,t1);}

C_noret_decl(trf_8091)
static void C_fcall trf_8091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8091(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8091(t0,t1);}

C_noret_decl(trf_8043)
static void C_fcall trf_8043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8043(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8043(t0,t1);}

C_noret_decl(trf_8008)
static void C_fcall trf_8008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8008(t0,t1);}

C_noret_decl(trf_7972)
static void C_fcall trf_7972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7972(t0,t1);}

C_noret_decl(trf_7936)
static void C_fcall trf_7936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7936(t0,t1);}

C_noret_decl(trf_7914)
static void C_fcall trf_7914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7914(t0,t1);}

C_noret_decl(trf_7909)
static void C_fcall trf_7909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7909(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7909(t0,t1);}

C_noret_decl(trf_7904)
static void C_fcall trf_7904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7904(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7904(t0,t1);}

C_noret_decl(trf_7715)
static void C_fcall trf_7715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7715(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7715(t0,t1);}

C_noret_decl(trf_6910)
static void C_fcall trf_6910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6910(t0,t1);}

C_noret_decl(trf_6937)
static void C_fcall trf_6937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6937(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6937(t0,t1);}

C_noret_decl(trf_7132)
static void C_fcall trf_7132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7132(t0,t1);}

C_noret_decl(trf_7141)
static void C_fcall trf_7141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7141(t0,t1);}

C_noret_decl(trf_7538)
static void C_fcall trf_7538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7538(t0,t1);}

C_noret_decl(trf_7505)
static void C_fcall trf_7505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7505(t0,t1);}

C_noret_decl(trf_7473)
static void C_fcall trf_7473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7473(t0,t1);}

C_noret_decl(trf_7438)
static void C_fcall trf_7438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7438(t0,t1);}

C_noret_decl(trf_7368)
static void C_fcall trf_7368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7368(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7368(t0,t1);}

C_noret_decl(trf_7323)
static void C_fcall trf_7323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7323(t0,t1);}

C_noret_decl(trf_7291)
static void C_fcall trf_7291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7291(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7291(t0,t1);}

C_noret_decl(trf_7259)
static void C_fcall trf_7259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7259(t0,t1);}

C_noret_decl(trf_7227)
static void C_fcall trf_7227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7227(t0,t1);}

C_noret_decl(trf_7195)
static void C_fcall trf_7195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7195(t0,t1);}

C_noret_decl(trf_7173)
static void C_fcall trf_7173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7173(t0,t1);}

C_noret_decl(trf_6882)
static void C_fcall trf_6882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6882(t0,t1);}

C_noret_decl(trf_5740)
static void C_fcall trf_5740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5740(t0,t1);}

C_noret_decl(trf_5842)
static void C_fcall trf_5842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5842(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5842(t0,t1);}

C_noret_decl(trf_5875)
static void C_fcall trf_5875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5875(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5875(t0,t1);}

C_noret_decl(trf_5971)
static void C_fcall trf_5971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5971(t0,t1);}

C_noret_decl(trf_6603)
static void C_fcall trf_6603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6603(t0,t1);}

C_noret_decl(trf_6623)
static void C_fcall trf_6623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6623(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6623(t0,t1);}

C_noret_decl(trf_6557)
static void C_fcall trf_6557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6557(t0,t1);}

C_noret_decl(trf_6507)
static void C_fcall trf_6507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6507(t0,t1);}

C_noret_decl(trf_6457)
static void C_fcall trf_6457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6457(t0,t1);}

C_noret_decl(trf_6418)
static void C_fcall trf_6418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6418(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6418(t0,t1);}

C_noret_decl(trf_6379)
static void C_fcall trf_6379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6379(t0,t1);}

C_noret_decl(trf_6340)
static void C_fcall trf_6340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6340(t0,t1);}

C_noret_decl(trf_6301)
static void C_fcall trf_6301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6301(t0,t1);}

C_noret_decl(trf_6241)
static void C_fcall trf_6241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6241(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6241(t0,t1);}

C_noret_decl(trf_6202)
static void C_fcall trf_6202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6202(t0,t1);}

C_noret_decl(trf_6166)
static void C_fcall trf_6166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6166(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6166(t0,t1);}

C_noret_decl(trf_6130)
static void C_fcall trf_6130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6130(t0,t1);}

C_noret_decl(trf_6094)
static void C_fcall trf_6094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6094(t0,t1);}

C_noret_decl(trf_6058)
static void C_fcall trf_6058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6058(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6058(t0,t1);}

C_noret_decl(trf_6032)
static void C_fcall trf_6032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6032(t0,t1,t2);}

C_noret_decl(trf_6023)
static void C_fcall trf_6023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6023(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6023(t0,t1,t2);}

C_noret_decl(trf_6018)
static void C_fcall trf_6018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6018(t0,t1);}

C_noret_decl(trf_5670)
static void C_fcall trf_5670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5670(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5670(t0,t1,t2);}

C_noret_decl(trf_5665)
static void C_fcall trf_5665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5665(t0,t1);}

C_noret_decl(trf_5204)
static void C_fcall trf_5204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5204(t0,t1);}

C_noret_decl(trf_5213)
static void C_fcall trf_5213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5213(t0,t1);}

C_noret_decl(trf_5225)
static void C_fcall trf_5225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5225(t0,t1);}

C_noret_decl(trf_5237)
static void C_fcall trf_5237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5237(t0,t1);}

C_noret_decl(trf_5277)
static void C_fcall trf_5277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5277(t0,t1);}

C_noret_decl(trf_4881)
static void C_fcall trf_4881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4881(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4881(t0,t1);}

C_noret_decl(trf_4753)
static void C_fcall trf_4753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4753(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4753(t0,t1,t2);}

C_noret_decl(trf_4782)
static void C_fcall trf_4782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4782(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4782(t0,t1);}

C_noret_decl(trf_4785)
static void C_fcall trf_4785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4785(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4785(t0,t1);}

C_noret_decl(trf_4769)
static void C_fcall trf_4769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4769(t0,t1);}

C_noret_decl(trf_4689)
static void C_fcall trf_4689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4689(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4689(t0,t1,t2);}

C_noret_decl(trf_3891)
static void C_fcall trf_3891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3891(t0,t1);}

C_noret_decl(trf_3919)
static void C_fcall trf_3919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3919(t0,t1);}

C_noret_decl(trf_4537)
static void C_fcall trf_4537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4537(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4537(t0,t1);}

C_noret_decl(trf_3985)
static void C_fcall trf_3985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3985(t0,t1);}

C_noret_decl(trf_4499)
static void C_fcall trf_4499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4499(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4499(t0,t1,t2,t3);}

C_noret_decl(trf_4442)
static void C_fcall trf_4442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4442(t0,t1);}

C_noret_decl(trf_4463)
static void C_fcall trf_4463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4463(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4463(t0,t1);}

C_noret_decl(trf_4406)
static void C_fcall trf_4406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4406(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4406(t0,t1);}

C_noret_decl(trf_4373)
static void C_fcall trf_4373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4373(t0,t1);}

C_noret_decl(trf_4382)
static void C_fcall trf_4382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4382(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4382(t0,t1);}

C_noret_decl(trf_4327)
static void C_fcall trf_4327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4327(t0,t1);}

C_noret_decl(trf_4017)
static void C_fcall trf_4017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4017(t0,t1);}

C_noret_decl(trf_4077)
static void C_fcall trf_4077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4077(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4077(t0,t1,t2,t3);}

C_noret_decl(trf_3629)
static void C_fcall trf_3629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3629(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3629(t0,t1,t2,t3);}

C_noret_decl(trf_3458)
static void C_fcall trf_3458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3458(t0,t1);}

C_noret_decl(trf_3464)
static void C_fcall trf_3464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3464(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3464(t0,t1,t2,t3);}

C_noret_decl(trf_3660)
static void C_fcall trf_3660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3660(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3660(t0,t1,t2,t3);}

C_noret_decl(trf_3667)
static void C_fcall trf_3667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3667(t0,t1);}

C_noret_decl(trf_3756)
static void C_fcall trf_3756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3756(t0,t1);}

C_noret_decl(trf_3495)
static void C_fcall trf_3495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3495(t0,t1);}

C_noret_decl(trf_3802)
static void C_fcall trf_3802(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3802(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3802(t0,t1,t2);}

C_noret_decl(trf_3817)
static void C_fcall trf_3817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3817(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3817(t0,t1,t2,t3);}

C_noret_decl(trf_3833)
static void C_fcall trf_3833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3833(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3833(t0,t1);}

C_noret_decl(trf_3879)
static void C_fcall trf_3879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3879(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3879(t0,t1,t2,t3);}

C_noret_decl(trf_3172)
static void C_fcall trf_3172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3172(t0,t1);}

C_noret_decl(trf_3358)
static void C_fcall trf_3358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3358(t0,t1);}

C_noret_decl(trf_3361)
static void C_fcall trf_3361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3361(t0,t1);}

C_noret_decl(trf_3407)
static void C_fcall trf_3407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3407(t0,t1);}

C_noret_decl(trf_3211)
static void C_fcall trf_3211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3211(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3211(t0,t1,t2);}

C_noret_decl(trf_3175)
static void C_fcall trf_3175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3175(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3175(t0,t1);}

C_noret_decl(trf_3188)
static void C_fcall trf_3188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3188(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3188(t0,t1,t2,t3);}

C_noret_decl(trf_2921)
static void C_fcall trf_2921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2921(t0,t1);}

C_noret_decl(trf_2959)
static void C_fcall trf_2959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2959(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2959(t0,t1);}

C_noret_decl(trf_2980)
static void C_fcall trf_2980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2980(t0,t1);}

C_noret_decl(trf_3045)
static void C_fcall trf_3045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3045(t0,t1);}

C_noret_decl(trf_2780)
static void C_fcall trf_2780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2780(t0,t1);}

C_noret_decl(trf_2801)
static void C_fcall trf_2801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2801(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2801(t0,t1,t2,t3);}

C_noret_decl(trf_2862)
static void C_fcall trf_2862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2862(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2862(t0,t1,t2);}

C_noret_decl(trf_2843)
static void C_fcall trf_2843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2843(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2843(t0,t1,t2);}

C_noret_decl(trf_2614)
static void C_fcall trf_2614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2614(t0,t1);}

C_noret_decl(trf_2640)
static void C_fcall trf_2640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2640(t0,t1);}

C_noret_decl(trf_2617)
static void C_fcall trf_2617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2617(t0,t1);}

C_noret_decl(trf_1187)
static void C_fcall trf_1187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1187(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1187(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2582)
static void C_fcall trf_2582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2582(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2582(t0,t1,t2,t3);}

C_noret_decl(trf_1190)
static void C_fcall trf_1190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1190(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1190(t0,t1,t2,t3);}

C_noret_decl(trf_2483)
static void C_fcall trf_2483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2483(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2483(t0,t1,t2,t3);}

C_noret_decl(trf_1834)
static void C_fcall trf_1834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1834(t0,t1);}

C_noret_decl(trf_1840)
static void C_fcall trf_1840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1840(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1840(t0,t1);}

C_noret_decl(trf_1991)
static void C_fcall trf_1991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1991(t0,t1);}

C_noret_decl(trf_1372)
static void C_fcall trf_1372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1372(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1372(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1145)
static void C_fcall trf_1145(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1145(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1145(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2336)){
C_save(t1);
C_rereclaim2(2336*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,814);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],15,"\010compileroutput");
lf[2]=C_h_intern(&lf[2],12,"\010compilergen");
lf[3]=C_h_intern(&lf[3],7,"newline");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],17,"\010compilergen-list");
lf[7]=C_h_intern(&lf[7],11,"intersperse");
lf[8]=C_h_intern(&lf[8],18,"\010compilerunique-id");
lf[9]=C_h_intern(&lf[9],22,"\010compilergenerate-code");
lf[10]=C_h_intern(&lf[10],13,"\010compilerbomb");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[12]=C_h_intern(&lf[12],17,"lambda-literal-id");
lf[13]=C_h_intern(&lf[13],4,"find");
lf[14]=C_h_intern(&lf[14],14,"\004coreimmediate");
lf[15]=C_h_intern(&lf[15],4,"bool");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[18]=C_h_intern(&lf[18],4,"char");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[20]=C_h_intern(&lf[20],3,"nil");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[22]=C_h_intern(&lf[22],3,"fix");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[24]=C_h_intern(&lf[24],3,"eof");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[27]=C_h_intern(&lf[27],12,"\004coreliteral");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[31]=C_h_intern(&lf[31],2,"if");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[35]=C_h_intern(&lf[35],9,"\004coreproc");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[37]=C_h_intern(&lf[37],9,"\004corebind");
lf[38]=C_h_intern(&lf[38],8,"\004coreref");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[41]=C_h_intern(&lf[41],10,"\004coreunbox");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[44]=C_h_intern(&lf[44],13,"\004coreupdate_i");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[46]=C_h_intern(&lf[46],11,"\004coreupdate");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[50]=C_h_intern(&lf[50],16,"\004coreupdatebox_i");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[53]=C_h_intern(&lf[53],14,"\004coreupdatebox");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[56]=C_h_intern(&lf[56],12,"\004coreclosure");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[61]=C_h_intern(&lf[61],8,"for-each");
lf[62]=C_h_intern(&lf[62],4,"iota");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[64]=C_h_intern(&lf[64],8,"\004corebox");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[67]=C_h_intern(&lf[67],10,"\004corelocal");
lf[68]=C_h_intern(&lf[68],13,"\004coresetlocal");
lf[69]=C_h_intern(&lf[69],11,"\004coreglobal");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[74]=C_h_intern(&lf[74],21,"\010compilerc-ify-string");
lf[75]=C_h_intern(&lf[75],14,"symbol->string");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[80]=C_h_intern(&lf[80],14,"\004coresetglobal");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1,");
lf[85]=C_h_intern(&lf[85],16,"\004coresetglobal_i");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\004],0,");
lf[90]=C_h_intern(&lf[90],14,"\004coreundefined");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[92]=C_h_intern(&lf[92],9,"\004corecall");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[98]=C_h_intern(&lf[98],26,"lambda-literal-temporaries");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_h_intern(&lf[100],22,"lambda-literal-looping");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[104]=C_h_intern(&lf[104],6,"unsafe");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[109]=C_h_intern(&lf[109],19,"no-procedure-checks");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[112]=C_h_intern(&lf[112],24,"\010compileremit-trace-info");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[115]=C_h_intern(&lf[115],16,"string-translate");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[118]=C_h_intern(&lf[118],8,"->string");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[121]=C_h_intern(&lf[121],17,"string-translate*");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[123]=C_h_intern(&lf[123],27,"lambda-literal-closure-size");
lf[124]=C_h_intern(&lf[124],28,"\010compilersource-info->string");
lf[125]=C_h_intern(&lf[125],12,"\004corerecurse");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[129]=C_h_intern(&lf[129],16,"\004coredirect_call");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[131]=C_h_intern(&lf[131],13,"\004corecallunit");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[136]=C_h_intern(&lf[136],11,"\004corereturn");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[139]=C_h_intern(&lf[139],11,"\004coreinline");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[141]=C_h_intern(&lf[141],20,"\004coreinline_allocate");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[144]=C_h_intern(&lf[144],15,"\004coreinline_ref");
lf[145]=C_h_intern(&lf[145],34,"\010compilerforeign-result-conversion");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[147]=C_h_intern(&lf[147],18,"\004coreinline_update");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[150]=C_h_intern(&lf[150],36,"\010compilerforeign-argument-conversion");
lf[151]=C_h_intern(&lf[151],33,"\010compilerforeign-type-declaration");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_h_intern(&lf[153],19,"\004coreinline_loc_ref");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[159]=C_h_intern(&lf[159],22,"\004coreinline_loc_update");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_h_intern(&lf[165],11,"\004coreswitch");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[170]=C_h_intern(&lf[170],9,"\004corecond");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[174]=C_h_intern(&lf[174],13,"pair-for-each");
lf[175]=C_h_intern(&lf[175],13,"string-append");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[177]=C_h_intern(&lf[177],30,"\010compilerexternal-protos-first");
lf[178]=C_h_intern(&lf[178],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[179]=C_h_intern(&lf[179],22,"foreign-callback-stubs");
lf[180]=C_h_intern(&lf[180],29,"\010compilerforeign-declarations");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[183]=C_h_intern(&lf[183],28,"\010compilertarget-include-file");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[185]=C_h_intern(&lf[185],18,"\010compilerunit-name");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[187]=C_h_intern(&lf[187],19,"\010compilerused-units");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[189]=C_h_intern(&lf[189],27,"\010compilercompiler-arguments");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[195]=C_h_intern(&lf[195],18,"string-intersperse");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[199]=C_h_intern(&lf[199],7,"\003sysmap");
lf[200]=C_h_intern(&lf[200],12,"string-split");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[202]=C_h_intern(&lf[202],15,"chicken-version");
lf[203]=C_h_intern(&lf[203],15,"\003sysmatch-error");
lf[204]=C_h_intern(&lf[204],18,"\003sysdecode-seconds");
lf[205]=C_h_intern(&lf[205],15,"current-seconds");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[210]=C_h_intern(&lf[210],23,"\003syslambda-info->string");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[220]=C_h_intern(&lf[220],9,"make-list");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[224]=C_h_intern(&lf[224],4,"none");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[235]=C_h_intern(&lf[235],8,"toplevel");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[238]=C_h_intern(&lf[238],27,"\010compileremit-unsafe-marker");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[251]=C_h_intern(&lf[251],21,"small-parameter-limit");
lf[252]=C_h_intern(&lf[252],11,"lset-adjoin");
lf[253]=C_h_intern(&lf[253],1,"=");
lf[254]=C_h_intern(&lf[254],32,"lambda-literal-callee-signatures");
lf[255]=C_h_intern(&lf[255],24,"lambda-literal-allocated");
lf[256]=C_h_intern(&lf[256],21,"lambda-literal-direct");
lf[257]=C_h_intern(&lf[257],33,"lambda-literal-rest-argument-mode");
lf[258]=C_h_intern(&lf[258],28,"lambda-literal-rest-argument");
lf[259]=C_h_intern(&lf[259],27,"\010compilermake-variable-list");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[261]=C_h_intern(&lf[261],27,"lambda-literal-customizable");
lf[262]=C_h_intern(&lf[262],29,"lambda-literal-argument-count");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[269]=C_h_intern(&lf[269],27,"\010compilermake-argument-list");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[309]=C_h_intern(&lf[309],6,"vector");
lf[310]=C_h_intern(&lf[310],23,"lambda-literal-external");
lf[311]=C_h_intern(&lf[311],14,"\003syscopy-bytes");
lf[312]=C_h_intern(&lf[312],11,"make-string");
lf[313]=C_h_intern(&lf[313],6,"modulo");
lf[314]=C_h_intern(&lf[314],3,"fx/");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[328]=C_h_intern(&lf[328],23,"\010compilerencode-literal");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[330]=C_h_intern(&lf[330],32,"\010compilerblock-variable-literal\077");
lf[331]=C_h_intern(&lf[331],20,"\010compilerbig-fixnum\077");
lf[332]=C_h_intern(&lf[332],7,"sprintf");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[334]=C_h_intern(&lf[334],25,"\010compilerwords-per-flonum");
lf[335]=C_h_intern(&lf[335],6,"reduce");
lf[336]=C_h_intern(&lf[336],1,"+");
lf[337]=C_h_intern(&lf[337],12,"vector->list");
lf[338]=C_h_intern(&lf[338],14,"\010compilerwords");
lf[339]=C_h_intern(&lf[339],15,"\003sysbytevector\077");
lf[340]=C_h_intern(&lf[340],19,"\010compilerimmediate\077");
lf[341]=C_h_intern(&lf[341],19,"lambda-literal-body");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[354]=C_h_intern(&lf[354],4,"list");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[393]=C_h_intern(&lf[393],26,"\010compilertarget-stack-size");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[396]=C_h_intern(&lf[396],30,"\010compilertarget-heap-shrinkage");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[398]=C_h_intern(&lf[398],27,"\010compilertarget-heap-growth");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[400]=C_h_intern(&lf[400],33,"\010compilertarget-initial-heap-size");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[403]=C_h_intern(&lf[403],25,"\010compilertarget-heap-size");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[407]=C_h_intern(&lf[407],40,"\010compilerdisable-stack-overflow-checking");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[413]=C_h_intern(&lf[413],4,"fold");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[416]=C_h_intern(&lf[416],28,"\010compilerinsert-timer-checks");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[421]=C_h_intern(&lf[421],14,"no-argc-checks");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[468]=C_h_intern(&lf[468],16,"\010compilercleanup");
lf[469]=C_h_intern(&lf[469],18,"\010compilerdebugging");
lf[470]=C_h_intern(&lf[470],1,"o");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[476]=C_h_intern(&lf[476],18,"\010compilerreal-name");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[478]=C_h_intern(&lf[478],25,"emit-procedure-table-info");
lf[479]=C_h_intern(&lf[479],31,"generate-foreign-callback-stubs");
lf[480]=C_h_intern(&lf[480],31,"\010compilergenerate-foreign-stubs");
lf[481]=C_h_intern(&lf[481],29,"\010compilerforeign-lambda-stubs");
lf[482]=C_h_intern(&lf[482],36,"\010compilergenerate-external-variables");
lf[483]=C_h_intern(&lf[483],27,"\010compilerexternal-variables");
lf[484]=C_h_intern(&lf[484],1,"p");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[505]=C_h_intern(&lf[505],11,"string-copy");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[507]=C_h_intern(&lf[507],13,"list-tabulate");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[510]=C_h_intern(&lf[510],41,"\010compilergenerate-foreign-callback-header");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[523]=C_h_intern(&lf[523],4,"void");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[548]=C_h_intern(&lf[548],21,"foreign-stub-callback");
lf[549]=C_h_intern(&lf[549],16,"foreign-stub-cps");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_h_intern(&lf[551],27,"foreign-stub-argument-names");
lf[552]=C_h_intern(&lf[552],17,"foreign-stub-body");
lf[553]=C_h_intern(&lf[553],17,"foreign-stub-name");
lf[554]=C_h_intern(&lf[554],24,"foreign-stub-return-type");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[557]=C_h_intern(&lf[557],27,"foreign-stub-argument-types");
lf[558]=C_h_intern(&lf[558],19,"\010compilerreal-name2");
lf[559]=C_h_intern(&lf[559],15,"foreign-stub-id");
lf[560]=C_h_intern(&lf[560],5,"float");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[562]=C_h_intern(&lf[562],8,"c-string");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[566]=C_h_intern(&lf[566],16,"nonnull-c-string");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[569]=C_h_intern(&lf[569],3,"ref");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[571]=C_h_intern(&lf[571],5,"const");
lf[572]=C_h_intern(&lf[572],7,"pointer");
lf[573]=C_h_intern(&lf[573],9,"c-pointer");
lf[574]=C_h_intern(&lf[574],15,"nonnull-pointer");
lf[575]=C_h_intern(&lf[575],17,"nonnull-c-pointer");
lf[576]=C_h_intern(&lf[576],8,"function");
lf[577]=C_h_intern(&lf[577],8,"instance");
lf[578]=C_h_intern(&lf[578],16,"nonnull-instance");
lf[579]=C_h_intern(&lf[579],12,"instance-ref");
lf[580]=C_h_intern(&lf[580],18,"\003syshash-table-ref");
lf[581]=C_h_intern(&lf[581],27,"\010compilerforeign-type-table");
lf[582]=C_h_intern(&lf[582],17,"nonnull-c-string*");
lf[583]=C_h_intern(&lf[583],25,"nonnull-unsigned-c-string");
lf[584]=C_h_intern(&lf[584],26,"nonnull-unsigned-c-string*");
lf[585]=C_h_intern(&lf[585],6,"symbol");
lf[586]=C_h_intern(&lf[586],9,"c-string*");
lf[587]=C_h_intern(&lf[587],17,"unsigned-c-string");
lf[588]=C_h_intern(&lf[588],18,"unsigned-c-string*");
lf[589]=C_h_intern(&lf[589],6,"double");
lf[590]=C_h_intern(&lf[590],16,"unsigned-integer");
lf[591]=C_h_intern(&lf[591],18,"unsigned-integer32");
lf[592]=C_h_intern(&lf[592],4,"long");
lf[593]=C_h_intern(&lf[593],7,"integer");
lf[594]=C_h_intern(&lf[594],9,"integer32");
lf[595]=C_h_intern(&lf[595],13,"unsigned-long");
lf[596]=C_h_intern(&lf[596],6,"number");
lf[597]=C_h_intern(&lf[597],9,"integer64");
lf[598]=C_h_intern(&lf[598],13,"c-string-list");
lf[599]=C_h_intern(&lf[599],14,"c-string-list*");
lf[600]=C_h_intern(&lf[600],3,"int");
lf[601]=C_h_intern(&lf[601],5,"int32");
lf[602]=C_h_intern(&lf[602],5,"short");
lf[603]=C_h_intern(&lf[603],14,"unsigned-short");
lf[604]=C_h_intern(&lf[604],13,"scheme-object");
lf[605]=C_h_intern(&lf[605],13,"unsigned-char");
lf[606]=C_h_intern(&lf[606],12,"unsigned-int");
lf[607]=C_h_intern(&lf[607],14,"unsigned-int32");
lf[608]=C_h_intern(&lf[608],4,"byte");
lf[609]=C_h_intern(&lf[609],13,"unsigned-byte");
lf[610]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[611]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[612]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[613]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[614]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[625]=C_h_intern(&lf[625],36,"foreign-callback-stub-argument-types");
lf[626]=C_h_intern(&lf[626],33,"foreign-callback-stub-return-type");
lf[627]=C_h_intern(&lf[627],24,"foreign-callback-stub-id");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[630]=C_h_intern(&lf[630],32,"foreign-callback-stub-qualifiers");
lf[631]=C_h_intern(&lf[631],26,"foreign-callback-stub-name");
lf[632]=C_h_intern(&lf[632],4,"quit");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[652]=C_h_intern(&lf[652],11,"byte-vector");
lf[653]=C_h_intern(&lf[653],19,"nonnull-byte-vector");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[655]=C_h_intern(&lf[655],4,"blob");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[657]=C_h_intern(&lf[657],9,"u16vector");
lf[658]=C_h_intern(&lf[658],17,"nonnull-u16vector");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[660]=C_h_intern(&lf[660],8,"s8vector");
lf[661]=C_h_intern(&lf[661],16,"nonnull-s8vector");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[663]=C_h_intern(&lf[663],9,"u32vector");
lf[664]=C_h_intern(&lf[664],17,"nonnull-u32vector");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[666]=C_h_intern(&lf[666],9,"s16vector");
lf[667]=C_h_intern(&lf[667],17,"nonnull-s16vector");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[669]=C_h_intern(&lf[669],9,"s32vector");
lf[670]=C_h_intern(&lf[670],17,"nonnull-s32vector");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[672]=C_h_intern(&lf[672],9,"f32vector");
lf[673]=C_h_intern(&lf[673],17,"nonnull-f32vector");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[675]=C_h_intern(&lf[675],9,"f64vector");
lf[676]=C_h_intern(&lf[676],17,"nonnull-f64vector");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[683]=C_h_intern(&lf[683],8,"template");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[690]=C_h_intern(&lf[690],6,"struct");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[693]=C_h_intern(&lf[693],5,"union");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[696]=C_h_intern(&lf[696],4,"enum");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[705]=C_h_intern(&lf[705],3,"...");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_h_intern(&lf[709],12,"nonnull-blob");
lf[710]=C_h_intern(&lf[710],8,"u8vector");
lf[711]=C_h_intern(&lf[711],16,"nonnull-u8vector");
lf[712]=C_h_intern(&lf[712],14,"scheme-pointer");
lf[713]=C_h_intern(&lf[713],22,"nonnull-scheme-pointer");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[808]=C_h_intern(&lf[808],17,"\003sysstring-append");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[810]=C_h_intern(&lf[810],5,"cons*");
lf[811]=C_h_intern(&lf[811],29,"\010compilerstring->c-identifier");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[813]=C_h_intern(&lf[813],6,"random");
C_register_lf2(lf,814,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1087 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1090 in k1087 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1093 in k1090 in k1087 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_set_block_item(lf[1],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1101,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1122,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8787,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8791,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 100  random */
t9=C_retrieve(lf[813]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_fix(16777216));}

/* k8789 in k1093 in k1090 in k1087 */
static void C_ccall f_8791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8795,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 100  current-seconds */
t3=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8793 in k8789 in k1093 in k1090 in k1087 */
static void C_ccall f_8795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 100  sprintf */
t2=C_retrieve(lf[332]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[812],((C_word*)t0)[2],t1);}

/* k8785 in k1093 in k1090 in k1087 */
static void C_ccall f_8787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 99   string->c-identifier */
t2=C_retrieve(lf[811]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1142,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4671,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[468]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4744,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[259]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4833,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4849,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[482]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4865,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4916,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[480]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4934,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[479]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5167,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[510]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5598,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5663,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6880,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7713,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8487,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8487(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[51],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8487,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8490,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8493,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8496,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8549,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t7)){
t8=t6;
f_8549(2,t8,lf[795]);}
else{
t8=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t8)){
t9=t6;
f_8549(2,t9,lf[796]);}
else{
if(C_truep((C_word)C_charp(t2))){
t9=(C_word)C_fix((C_word)C_character_code(t2));
t10=f_8496(C_a_i(&a,4),t9);
/* c-backend.scm: 1355 string-append */
t11=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[797],t10);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t9=t6;
f_8549(2,t9,lf[798]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t9=t6;
f_8549(2,t9,lf[799]);}
else{
t9=C_retrieve(lf[0]);
t10=(C_word)C_eqp(t9,t2);
if(C_truep(t10)){
t11=t6;
f_8549(2,t11,lf[800]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8667,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1360 big-fixnum? */
t12=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8680,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1369 number->string */
C_number_to_string(3,0,t11,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t11=(C_word)C_slot(t2,C_fix(1));
t12=(C_word)C_i_string_length(t11);
t13=f_8496(C_a_i(&a,4),t12);
/* c-backend.scm: 1372 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t14))(5,t14,t6,lf[806],t13,t11);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1377 bomb */
t11=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[807],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8719,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t12=f_8490(t2);
t13=(C_word)C_make_character((C_word)C_unfix(t12));
t14=(C_word)C_a_i_string(&a,1,t13);
t15=f_8493(t2);
t16=f_8496(C_a_i(&a,4),t15);
/* c-backend.scm: 1380 string-append */
t17=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t17))(4,t17,t11,t14,t16);}
else{
t11=f_8493(t2);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8749,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=f_8490(t2);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8496(C_a_i(&a,4),t11);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8761,a[2]=t16,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8763,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1390 list-tabulate */
t19=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t17,t11,t18);}}}}}}}}}}}}

/* a8762 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8763,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1390 encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k8759 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1387 cons* */
t2=C_retrieve(lf[810]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8747 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1386 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[809]);}

/* k8717 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1379 ##sys#string-append */
t2=C_retrieve(lf[808]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8678 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1369 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[804],t1,lf[805]);}

/* k8665 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8667,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8663,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1367 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1361 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[3],lf[803],t13);}}

/* k8661 in k8665 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1367 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[801],t1,lf[802]);}

/* k8547 in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_8549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8549,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1351 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static C_word C_fcall f_8496(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* getsize in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static C_word C_fcall f_8493(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1050(C_SCHEME_UNDEFINED,t1));}

/* getbits in ##compiler#encode-literal in k1138 in k1093 in k1090 in k1087 */
static C_word C_fcall f_8490(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1046(C_SCHEME_UNDEFINED,t1));}

/* ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_7713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7713,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7715,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[769]);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[601]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[770]);}
else{
t10=(C_word)C_eqp(t5,lf[606]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[607]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[771]);}
else{
t12=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[772]);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[773]);}
else{
t14=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[774]);}
else{
t15=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[775]);}
else{
t16=(C_word)C_eqp(t5,lf[560]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[589]));
if(C_truep(t17)){
/* c-backend.scm: 1289 sprintf */
t18=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[776],t3);}
else{
t18=(C_word)C_eqp(t5,lf[596]);
if(C_truep(t18)){
/* c-backend.scm: 1290 sprintf */
t19=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[777],t3);}
else{
t19=(C_word)C_eqp(t5,lf[566]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7800,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_7800(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[562]);
if(C_truep(t21)){
t22=t20;
f_7800(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[575]);
if(C_truep(t22)){
t23=t20;
f_7800(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[586]);
if(C_truep(t23)){
t24=t20;
f_7800(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[582]);
if(C_truep(t24)){
t25=t20;
f_7800(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[587]);
if(C_truep(t25)){
t26=t20;
f_7800(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t26)){
t27=t20;
f_7800(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[583]);
if(C_truep(t27)){
t28=t20;
f_7800(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t28)){
t29=t20;
f_7800(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[585]);
if(C_truep(t29)){
t30=t20;
f_7800(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[598]);
t31=t20;
f_7800(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[599])));}}}}}}}}}}}}}}}}}}}}

/* k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7800,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1294 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[778],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t2)){
/* c-backend.scm: 1295 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[779],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t4)){
/* c-backend.scm: 1296 sprintf */
t5=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[780],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t5)){
/* c-backend.scm: 1297 sprintf */
t6=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[781],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
/* c-backend.scm: 1298 sprintf */
t8=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[782],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t8)){
/* c-backend.scm: 1299 sprintf */
t9=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[783],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t9)){
/* c-backend.scm: 1300 sprintf */
t10=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[784],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[785]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[523]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[604]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[786]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1304 ##sys#hash-table-ref */
t14=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t14=t13;
f_7881(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1306 foreign-result-conversion */
t4=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7904,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7914,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7936,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7936(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7936(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[575]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7972,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7972(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7972(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[569]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8008,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_8008(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_8008(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8043,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_8043(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_8043(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_8043(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8091,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_8091(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_8091(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_8091(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[579]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8139,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t21=t17;
f_8139(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_8139(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_8139(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8187,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_8187(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_8187(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[572]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8222,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_8222(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_8222(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[573]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8258,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_8258(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_8258(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[3]);
t24=(C_word)C_eqp(t23,lf[576]);
if(C_truep(t24)){
t25=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=(C_word)C_i_cadr(((C_word*)t0)[3]);
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* c-backend.scm: 1308 sprintf */
t28=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t28))(4,t28,((C_word*)t0)[5],lf[793],((C_word*)t0)[4]);}
else{
/* c-backend.scm: 1308 g1021 */
t26=t2;
f_7904(t26,((C_word*)t0)[5]);}}
else{
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8316,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(((C_word*)t0)[3]);
t27=(C_word)C_eqp(t26,lf[696]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[3]);
t30=t25;
f_8316(t30,(C_word)C_i_nullp(t29));}
else{
t29=t25;
f_8316(t29,C_SCHEME_FALSE);}}
else{
t28=t25;
f_8316(t28,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1308 g1021 */
t5=t2;
f_7904(t5,((C_word*)t0)[5]);}}
else{
/* c-backend.scm: 1325 err */
t2=((C_word*)t0)[2];
f_7715(t2,((C_word*)t0)[5]);}}}

/* k8314 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[794],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[4]);}}

/* k8256 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1018 */
t3=((C_word*)t0)[4];
f_7909(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[3]);}}

/* k8220 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1018 */
t3=((C_word*)t0)[4];
f_7909(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[3]);}}

/* k8185 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[4]);}}

/* k8137 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[792],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[4]);}}

/* k8089 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8091(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[791],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[4]);}}

/* k8041 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8043(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[790],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[4]);}}

/* k8006 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_8008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1312 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[789],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[4]);}}

/* k7970 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7972(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1012 */
t3=((C_word*)t0)[4];
f_7914(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[3]);}}

/* k7934 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1308 g1012 */
t3=((C_word*)t0)[4];
f_7914(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1308 g1021 */
t2=((C_word*)t0)[2];
f_7904(t2,((C_word*)t0)[3]);}}

/* g1012 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7914,NULL,2,t0,t1);}
/* c-backend.scm: 1310 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[788],((C_word*)t0)[2]);}

/* g1018 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7909(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7909,NULL,2,t0,t1);}
/* c-backend.scm: 1321 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[787],((C_word*)t0)[2]);}

/* g1021 in k7879 in k7798 in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7904(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7904,NULL,2,t0,t1);}
/* c-backend.scm: 1324 err */
t2=((C_word*)t0)[2];
f_7715(t2,t1);}

/* err in ##compiler#foreign-result-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7715(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7715,NULL,2,t0,t1);}
/* c-backend.scm: 1280 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[768],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6880,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6882,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[604]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[715]);}
else{
t6=(C_word)C_eqp(t4,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[716]);}
else{
t8=(C_word)C_eqp(t4,lf[608]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6910,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_6910(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[600]);
if(C_truep(t10)){
t11=t9;
f_6910(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[606]);
if(C_truep(t11)){
t12=t9;
f_6910(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[607]);
t13=t9;
f_6910(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[609])));}}}}}}

/* k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6910,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[717]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[718]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[603]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[719]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[720]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6937(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
t8=t6;
f_6937(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[560])));}}}}}}

/* k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6937(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6937,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[721]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[722]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[723]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[724]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[725]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[572]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[726]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[574]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[727]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[712]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[728]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[713]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[729]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[730]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[575]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[731]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[655]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[732]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[709]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[733]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[652]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[734]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[653]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[735]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[710]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[736]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[711]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[737]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[657]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[738]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[739]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[663]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[740]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[664]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[741]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[660]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[742]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[661]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[743]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[666]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[744]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[667]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[745]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[669]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[746]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[670]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[747]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[748]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[673]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[749]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[750]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[676]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[751]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[562]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_7132(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[586]);
if(C_truep(t36)){
t37=t35;
f_7132(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
t38=t35;
f_7132(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[588])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7132,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[752]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7141(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_7141(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_7141(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_7141(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7141(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7141,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[753]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[754]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1256 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7150(2,t4,C_SCHEME_FALSE);}}}}

/* k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_7150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7150,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1258 foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7173,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(t3,lf[572]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7195,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[3]);
t8=t5;
f_7195(t8,(C_word)C_i_nullp(t7));}
else{
t7=t5;
f_7195(t7,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7227,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7227(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7227(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[573]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7259,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7259(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7259(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[575]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7291,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7291(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7291(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7323,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_7323(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7323(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7323(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7368,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_7368(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_7368(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_7368(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[576]);
if(C_truep(t16)){
t17=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cadr(((C_word*)t0)[3]);
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
t20=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[761]);}
else{
/* c-backend.scm: 1260 g948 */
t18=t2;
f_7173(t18,((C_word*)t0)[4]);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7438,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_7438(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_7438(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[696]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7473,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_7473(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_7473(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[569]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7505,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_7505(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_7505(t25,C_SCHEME_FALSE);}}
else{
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7538,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_car(((C_word*)t0)[3]);
t25=(C_word)C_eqp(t24,lf[579]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t29=t23;
f_7538(t29,(C_word)C_i_nullp(t28));}
else{
t28=t23;
f_7538(t28,C_SCHEME_FALSE);}}
else{
t27=t23;
f_7538(t27,C_SCHEME_FALSE);}}
else{
t26=t23;
f_7538(t26,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1260 g948 */
t3=t2;
f_7173(t3,((C_word*)t0)[4]);}}
else{
/* c-backend.scm: 1274 err */
t2=((C_word*)t0)[2];
f_6882(t2,((C_word*)t0)[4]);}}}

/* k7536 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 1260 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],lf[766],t2,lf[767]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7503 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7505,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1260 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[765]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7513 in k7503 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1260 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[763],t1,lf[764]);}

/* k7471 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[762]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7436 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1260 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7366 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7368(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[760]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7321 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[759]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7289 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7291(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[758]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7257 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[757]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7225 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[756]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* k7193 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[755]);}
else{
/* c-backend.scm: 1260 g948 */
t2=((C_word*)t0)[2];
f_7173(t2,((C_word*)t0)[3]);}}

/* g948 in k7148 in k7139 in k7130 in k6935 in k6908 in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_7173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7173,NULL,2,t0,t1);}
/* c-backend.scm: 1273 err */
t2=((C_word*)t0)[2];
f_6882(t2,t1);}

/* err in ##compiler#foreign-argument-conversion in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6882,NULL,2,t0,t1);}
/* c-backend.scm: 1210 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[714],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5663,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5670,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[604]);
if(C_truep(t7)){
/* c-backend.scm: 1130 str */
t8=t5;
f_5670(t8,t1,lf[635]);}
else{
t8=(C_word)C_eqp(t6,lf[18]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[608]));
if(C_truep(t9)){
/* c-backend.scm: 1131 str */
t10=t5;
f_5670(t10,t1,lf[636]);}
else{
t10=(C_word)C_eqp(t6,lf[605]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[609]));
if(C_truep(t11)){
/* c-backend.scm: 1132 str */
t12=t5;
f_5670(t12,t1,lf[637]);}
else{
t12=(C_word)C_eqp(t6,lf[606]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[590]));
if(C_truep(t13)){
/* c-backend.scm: 1133 str */
t14=t5;
f_5670(t14,t1,lf[638]);}
else{
t14=(C_word)C_eqp(t6,lf[607]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[591]));
if(C_truep(t15)){
/* c-backend.scm: 1134 str */
t16=t5;
f_5670(t16,t1,lf[639]);}
else{
t16=(C_word)C_eqp(t6,lf[600]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5740,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5740(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[593]);
t19=t17;
f_5740(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[15])));}}}}}}}

/* k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5740,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1135 str */
t2=((C_word*)t0)[7];
f_5670(t2,((C_word*)t0)[6],lf[640]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[594]));
if(C_truep(t3)){
/* c-backend.scm: 1136 str */
t4=((C_word*)t0)[7];
f_5670(t4,((C_word*)t0)[6],lf[641]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t4)){
/* c-backend.scm: 1137 str */
t5=((C_word*)t0)[7];
f_5670(t5,((C_word*)t0)[6],lf[642]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t5)){
/* c-backend.scm: 1138 str */
t6=((C_word*)t0)[7];
f_5670(t6,((C_word*)t0)[6],lf[643]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t6)){
/* c-backend.scm: 1139 str */
t7=((C_word*)t0)[7];
f_5670(t7,((C_word*)t0)[6],lf[644]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
if(C_truep(t7)){
/* c-backend.scm: 1140 str */
t8=((C_word*)t0)[7];
f_5670(t8,((C_word*)t0)[6],lf[645]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t8)){
/* c-backend.scm: 1141 str */
t9=((C_word*)t0)[7];
f_5670(t9,((C_word*)t0)[6],lf[646]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
if(C_truep(t9)){
/* c-backend.scm: 1142 str */
t10=((C_word*)t0)[7];
f_5670(t10,((C_word*)t0)[6],lf[647]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t11)){
/* c-backend.scm: 1143 str */
t12=((C_word*)t0)[7];
f_5670(t12,((C_word*)t0)[6],lf[648]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[572]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[574]));
if(C_truep(t13)){
/* c-backend.scm: 1145 str */
t14=((C_word*)t0)[7];
f_5670(t14,((C_word*)t0)[6],lf[649]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_5842(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t16)){
t17=t15;
f_5842(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[712]);
t18=t15;
f_5842(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[713])));}}}}}}}}}}}}}

/* k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5842(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5842,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1146 str */
t2=((C_word*)t0)[7];
f_5670(t2,((C_word*)t0)[6],lf[650]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[599]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[651]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[652]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[653]));
if(C_truep(t5)){
/* c-backend.scm: 1149 str */
t6=((C_word*)t0)[7];
f_5670(t6,((C_word*)t0)[6],lf[654]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[655]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5875(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[709]);
if(C_truep(t8)){
t9=t7;
f_5875(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[710]);
t10=t7;
f_5875(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[711])));}}}}}}

/* k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5875(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5875,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1150 str */
t2=((C_word*)t0)[7];
f_5670(t2,((C_word*)t0)[6],lf[656]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[657]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[658]));
if(C_truep(t3)){
/* c-backend.scm: 1151 str */
t4=((C_word*)t0)[7];
f_5670(t4,((C_word*)t0)[6],lf[659]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[660]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[661]));
if(C_truep(t5)){
/* c-backend.scm: 1152 str */
t6=((C_word*)t0)[7];
f_5670(t6,((C_word*)t0)[6],lf[662]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[663]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[664]));
if(C_truep(t7)){
/* c-backend.scm: 1153 str */
t8=((C_word*)t0)[7];
f_5670(t8,((C_word*)t0)[6],lf[665]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[666]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[667]));
if(C_truep(t9)){
/* c-backend.scm: 1154 str */
t10=((C_word*)t0)[7];
f_5670(t10,((C_word*)t0)[6],lf[668]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[669]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[670]));
if(C_truep(t11)){
/* c-backend.scm: 1155 str */
t12=((C_word*)t0)[7];
f_5670(t12,((C_word*)t0)[6],lf[671]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[672]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[673]));
if(C_truep(t13)){
/* c-backend.scm: 1156 str */
t14=((C_word*)t0)[7];
f_5670(t14,((C_word*)t0)[6],lf[674]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[675]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[676]));
if(C_truep(t15)){
/* c-backend.scm: 1157 str */
t16=((C_word*)t0)[7];
f_5670(t16,((C_word*)t0)[6],lf[677]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[566]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5971(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
if(C_truep(t18)){
t19=t17;
f_5971(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t19)){
t20=t17;
f_5971(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t20)){
t21=t17;
f_5971(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[583]);
if(C_truep(t21)){
t22=t17;
f_5971(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t22)){
t23=t17;
f_5971(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t24=t17;
f_5971(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[585])));}}}}}}}}}}}}}}}

/* k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5971,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1160 str */
t2=((C_word*)t0)[7];
f_5670(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t2)){
/* c-backend.scm: 1161 str */
t3=((C_word*)t0)[7];
f_5670(t3,((C_word*)t0)[6],lf[679]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1163 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_5986(2,t4,C_SCHEME_FALSE);}}}}

/* k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5986,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1165 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1166 str */
t2=((C_word*)t0)[3];
f_5670(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6018,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6023,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6032,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[572]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6058,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[4]);
t10=t7;
f_6058(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_6058(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[574]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6094,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[4]);
t12=t9;
f_6094(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_6094(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[573]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6130,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[4]);
t14=t11;
f_6130(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_6130(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[575]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6166,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[4]);
t16=t13;
f_6166(t16,(C_word)C_i_nullp(t15));}
else{
t15=t13;
f_6166(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[569]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6202,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[4]);
t18=t15;
f_6202(t18,(C_word)C_i_nullp(t17));}
else{
t17=t15;
f_6202(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[683]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6241,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[4]);
t20=t17;
f_6241(t20,(C_word)C_i_listp(t19));}
else{
t19=t17;
f_6241(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6301,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[4]);
t22=t19;
f_6301(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_6301(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[690]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6340,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6340(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6340(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[693]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6379,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6379(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6379(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[696]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6418,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[4]);
t28=t25;
f_6418(t28,(C_word)C_i_nullp(t27));}
else{
t27=t25;
f_6418(t27,C_SCHEME_FALSE);}}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[577]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6457,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t29))){
t30=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t31=t27;
f_6457(t31,(C_word)C_i_nullp(t30));}
else{
t30=t27;
f_6457(t30,C_SCHEME_FALSE);}}
else{
t29=t27;
f_6457(t29,C_SCHEME_FALSE);}}
else{
t27=(C_word)C_i_car(((C_word*)t0)[4]);
t28=(C_word)C_eqp(t27,lf[578]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6507,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t30))){
t31=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t33=t29;
f_6507(t33,(C_word)C_i_nullp(t32));}
else{
t32=t29;
f_6507(t32,C_SCHEME_FALSE);}}
else{
t31=t29;
f_6507(t31,C_SCHEME_FALSE);}}
else{
t29=(C_word)C_i_car(((C_word*)t0)[4]);
t30=(C_word)C_eqp(t29,lf[579]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6557,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t32))){
t33=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t33))){
t34=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t35=t31;
f_6557(t35,(C_word)C_i_nullp(t34));}
else{
t34=t31;
f_6557(t34,C_SCHEME_FALSE);}}
else{
t33=t31;
f_6557(t33,C_SCHEME_FALSE);}}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6603,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[4]);
t33=(C_word)C_eqp(t32,lf[576]);
if(C_truep(t33)){
t34=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t34))){
t35=(C_word)C_i_cddr(((C_word*)t0)[4]);
t36=t31;
f_6603(t36,(C_word)C_i_pairp(t35));}
else{
t35=t31;
f_6603(t35,C_SCHEME_FALSE);}}
else{
t34=t31;
f_6603(t34,C_SCHEME_FALSE);}}}}}}}}}}}}}}}
else{
/* c-backend.scm: 1168 g871 */
t5=t2;
f_6018(t5,((C_word*)t0)[6]);}}
else{
/* c-backend.scm: 1204 err */
t2=((C_word*)t0)[2];
f_5665(t2,((C_word*)t0)[6]);}}}}

/* k6601 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6603,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6619,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[708]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[4]);}}

/* k6617 in k6601 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_stringp(t3);
t5=t2;
f_6623(t5,(C_truep(t4)?t3:C_SCHEME_FALSE));}
else{
t4=t2;
f_6623(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6623(t3,C_SCHEME_FALSE);}}

/* k6621 in k6617 in k6601 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6623(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6623,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[700]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6630,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6634,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6636,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6635 in k6621 in k6617 in k6601 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6636,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[705],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[706]);}
else{
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[707]);}}

/* k6632 in k6621 in k6617 in k6601 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[704]);}

/* k6628 in k6621 in k6617 in k6601 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[701],((C_word*)t0)[2],lf[702],t1,lf[703]);}

/* k6555 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6557,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t5=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[4]);}}

/* k6568 in k6555 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[699],((C_word*)t0)[2]);}

/* k6505 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g868 */
t4=((C_word*)t0)[4];
f_6023(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[3]);}}

/* k6455 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g868 */
t4=((C_word*)t0)[4];
f_6023(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[3]);}}

/* k6416 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6418(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6418,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[4]);}}

/* k6426 in k6416 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[697],t1,lf[698],((C_word*)t0)[2]);}

/* k6377 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6379,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[4]);}}

/* k6387 in k6377 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[694],t1,lf[695],((C_word*)t0)[2]);}

/* k6338 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6340,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[4]);}}

/* k6348 in k6338 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[691],t1,lf[692],((C_word*)t0)[2]);}

/* k6299 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6301,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6311,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[4]);}}

/* k6309 in k6299 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[689],t1);}

/* k6239 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6241(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6241,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6258,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1168 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[688]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[3]);}}

/* k6256 in k6239 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6262,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6266,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6268,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6267 in k6256 in k6239 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6268,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[687]);}

/* k6264 in k6256 in k6239 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[686]);}

/* k6260 in k6256 in k6239 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[684],t1,lf[685]);}

/* k6252 in k6239 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1168 str */
t2=((C_word*)t0)[3];
f_5670(t2,((C_word*)t0)[2],t1);}

/* k6200 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6202,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6212,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1172 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[682],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[4]);}}

/* k6210 in k6200 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1172 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6164 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6166(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6032(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[3]);}}

/* k6128 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6032(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[3]);}}

/* k6092 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6032(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[3]);}}

/* k6056 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6058(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1168 g858 */
t3=((C_word*)t0)[4];
f_6032(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1168 g871 */
t2=((C_word*)t0)[2];
f_6018(t2,((C_word*)t0)[3]);}}

/* g858 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6032,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6040,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1170 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[681],((C_word*)t0)[2]);}

/* k6038 in g858 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1170 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g868 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6023(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6023,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6031,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1184 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6029 in g868 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1184 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[680],((C_word*)t0)[2]);}

/* g871 in k5984 in k5969 in k5873 in k5840 in k5738 in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_6018(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6018,NULL,2,t0,t1);}
/* c-backend.scm: 1203 err */
t2=((C_word*)t0)[2];
f_5665(t2,t1);}

/* str in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5670(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5670,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1128 string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[634],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5665,NULL,2,t0,t1);}
/* c-backend.scm: 1127 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[633],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5598,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5602,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1109 foreign-callback-stub-name */
t5=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1110 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1111 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5611,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1112 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5609 in k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1114 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[629]);}

/* k5615 in k5609 in k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5661,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1115 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[628]);}

/* k5659 in k5615 in k5609 in k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1115 gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k5618 in k5615 in k5609 in k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5628,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1116 pair-for-each */
t4=C_retrieve(lf[174]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5627 in k5618 in k5615 in k5609 in k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5628,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5632,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5649,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1118 foreign-type-declaration */
t8=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k5647 in a5627 in k5618 in k5615 in k5609 in k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1118 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5630 in a5627 in k5618 in k5615 in k5609 in k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1119 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5621 in k5618 in k5615 in k5609 in k5606 in k5603 in k5600 in ##compiler#generate-foreign-callback-header in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1121 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5167,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5173,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5173,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1056 foreign-callback-stub-id */
t4=C_retrieve(lf[627]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5180,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1057 real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5183,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1058 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1059 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5186,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1061 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[624]);}

/* k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5192,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5194,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1088 fold */
t6=C_retrieve(lf[413]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[623],((C_word*)t0)[4],t1);}

/* k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1089 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1091 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5539(2,t3,C_SCHEME_UNDEFINED);}}

/* k5594 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1091 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[621],t1,lf[622]);}

/* k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1092 generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[620],((C_word*)t0)[2]);}

/* k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5545,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1093 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[618],((C_word*)t0)[2],lf[619]);}

/* k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1094 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[617]);}

/* k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5581,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1095 for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5580 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5581,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5589,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1097 foreign-result-conversion */
t5=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[616]);}

/* k5587 in a5580 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1097 gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[613],t1,((C_word*)t0)[2],lf[614],C_SCHEME_TRUE,lf[615]);}

/* k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_5554(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1102 foreign-argument-conversion */
t5=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k5577 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1102 gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[612],t1);}

/* k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1103 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[611],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_5560(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1104 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1105 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[610]);}

/* compute-size in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5194,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5204,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5204(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
if(C_truep(t8)){
t9=t7;
f_5204(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t9)){
t10=t7;
f_5204(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t10)){
t11=t7;
f_5204(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t11)){
t12=t7;
f_5204(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[523]);
if(C_truep(t12)){
t13=t7;
f_5204(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t7;
f_5204(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t14)){
t15=t7;
f_5204(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t15)){
t16=t7;
f_5204(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t16)){
t17=t7;
f_5204(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t17)){
t18=t7;
f_5204(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[608]);
t19=t7;
f_5204(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[609])));}}}}}}}}}}}}

/* k5202 in compute-size in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5204,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5213,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5213(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t4)){
t5=t3;
f_5213(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
if(C_truep(t5)){
t6=t3;
f_5213(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
if(C_truep(t6)){
t7=t3;
f_5213(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t7)){
t8=t3;
f_5213(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t8)){
t9=t3;
f_5213(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t9)){
t10=t3;
f_5213(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t10)){
t11=t3;
f_5213(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t11)){
t12=t3;
f_5213(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t12)){
t13=t3;
f_5213(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t13)){
t14=t3;
f_5213(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t14)){
t15=t3;
f_5213(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t16=t3;
f_5213(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[599])));}}}}}}}}}}}}}}

/* k5211 in k5202 in compute-size in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5213,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1070 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[561]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5225(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t4)){
t5=t3;
f_5225(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t5)){
t6=t3;
f_5225(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
t7=t3;
f_5225(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[588])));}}}}}

/* k5223 in k5211 in k5202 in compute-size in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5225,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1072 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[563],((C_word*)t0)[5],lf[564],((C_word*)t0)[5],lf[565]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5237,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5237(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_5237(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_5237(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_5237(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k5235 in k5223 in k5211 in k5202 in compute-size in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5237,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1074 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[567],((C_word*)t0)[4],lf[568]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1076 ##sys#hash-table-ref */
t3=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[581]),((C_word*)t0)[2]);}
else{
t3=t2;
f_5243(2,t3,C_SCHEME_FALSE);}}}

/* k5241 in k5235 in k5223 in k5211 in k5202 in compute-size in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5243,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1078 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5194(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[569]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5277,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_5277(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[572]);
if(C_truep(t5)){
t6=t4;
f_5277(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[573]);
if(C_truep(t6)){
t7=t4;
f_5277(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t7)){
t8=t4;
f_5277(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[575]);
if(C_truep(t8)){
t9=t4;
f_5277(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t9)){
t10=t4;
f_5277(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t10)){
t11=t4;
f_5277(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[578]);
t12=t4;
f_5277(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[579])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k5275 in k5241 in k5235 in k5223 in k5211 in k5202 in compute-size in k5190 in k5184 in k5181 in k5178 in k5175 in a5172 in generate-foreign-callback-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_5277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1083 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[570]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1084 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5194(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4934,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4940,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4940,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4944,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 989  foreign-stub-id */
t4=C_retrieve(lf[559]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4947,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 990  real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4950,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 991  foreign-stub-argument-types */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5165,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 993  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[556]);}

/* k5163 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5165,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[555],t1);
/* c-backend.scm: 993  intersperse */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 994  foreign-stub-return-type */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 995  foreign-stub-name */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 996  foreign-stub-body */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 997  foreign-stub-argument-names */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_4971(2,t3,t1);}
else{
/* c-backend.scm: 997  make-list */
t3=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 998  foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[550]);}

/* k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 999  foreign-stub-cps */
t3=C_retrieve(lf[549]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1000 foreign-stub-callback */
t3=C_retrieve(lf[548]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1001 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5154,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1003 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4986(2,t3,C_SCHEME_UNDEFINED);}}

/* k5152 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1003 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[546],t1,lf[547]);}

/* k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1005 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[544],((C_word*)t0)[6],lf[545]);}
else{
t3=t2;
f_4989(2,t3,C_SCHEME_UNDEFINED);}}

/* k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1008 gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[539],((C_word*)t0)[2],lf[540],C_SCHEME_TRUE,lf[541],((C_word*)t0)[2],lf[542]);}
else{
/* c-backend.scm: 1010 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[543],((C_word*)t0)[2],C_make_character(40));}}

/* k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[3]);}

/* k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1013 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[534],C_SCHEME_TRUE,lf[535],((C_word*)t0)[2],lf[536]);}
else{
/* c-backend.scm: 1014 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[537],C_SCHEME_TRUE,lf[538],((C_word*)t0)[2],C_make_character(40));}}

/* k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1016 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[533]);}

/* k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1017 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[532]);}

/* k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5102,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1026 iota */
t5=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k5130 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1018 for-each */
t2=*((C_word*)lf[61]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5101 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5102,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5110,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5122,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1023 symbol->string */
t7=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1023 sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[531],t3);}}

/* k5120 in a5101 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1021 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5108 in a5101 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1024 foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[530]);}

/* k5112 in k5108 in a5101 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1025 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5116 in k5112 in k5108 in a5101 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1020 gen */
t2=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[527],((C_word*)t0)[3],C_make_character(41),t1,lf[528],((C_word*)t0)[2],lf[529]);}

/* k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1027 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[526]);}
else{
t3=t2;
f_5013(2,t3,C_SCHEME_UNDEFINED);}}

/* k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5022,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1029 gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[517]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t4)){
/* c-backend.scm: 1040 gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1039 gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[525],((C_word*)t0)[2]);}}}

/* k5041 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5046,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1041 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k5044 in k5041 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5080,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5084,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1042 make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[524]);}

/* k5082 in k5044 in k5041 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1042 intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5078 in k5044 in k5041 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k5047 in k5044 in k5041 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[523]);
if(C_truep(t3)){
t4=t2;
f_5052(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1043 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5050 in k5047 in k5044 in k5041 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1044 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[522]);}

/* k5053 in k5050 in k5047 in k5044 in k5041 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1046 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[518],C_SCHEME_TRUE,lf[519]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1048 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[520]);}
else{
/* c-backend.scm: 1049 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[521]);}}}

/* k5020 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1031 gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[516],C_SCHEME_TRUE);}

/* k5023 in k5020 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1033 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1035 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[514]);}
else{
/* c-backend.scm: 1036 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[515]);}}}

/* k5014 in k5011 in k5008 in k5005 in k5002 in k4999 in k4996 in k4993 in k4990 in k4987 in k4984 in k4981 in k4978 in k4975 in k4972 in k4969 in k4966 in k4963 in k4960 in k4957 in k4954 in k4948 in k4945 in k4942 in a4939 in ##compiler#generate-foreign-stubs in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1050 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4916,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4922,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a4921 in ##compiler#generate-foreign-callback-stub-prototypes in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4922,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4926,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 981  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4924 in a4921 in ##compiler#generate-foreign-callback-stub-prototypes in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 982  generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k4927 in k4924 in a4921 in ##compiler#generate-foreign-callback-stub-prototypes in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 983  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4865,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4869,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 968  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4867 in ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4874,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a4873 in k4867 in ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4874,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4881,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
t5=t3;
f_4881(t5,(C_word)C_eqp(t4,C_fix(3)));}
else{
t4=t3;
f_4881(t4,C_SCHEME_FALSE);}}

/* k4879 in a4873 in k4867 in ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4881(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4881,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t5=(C_truep(t4)?lf[508]:lf[509]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4901,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 972  foreign-type-declaration */
t7=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,t2);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4899 in k4879 in a4873 in k4867 in ##compiler#generate-external-variables in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 972  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4849,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 960  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4854 in ##compiler#make-argument-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4855,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4863,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 962  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4861 in a4854 in ##compiler#make-argument-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 962  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4833,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4839,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 955  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4838 in ##compiler#make-variable-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4839,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 957  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4845 in a4838 in ##compiler#make-variable-list in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 957  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[506],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4744,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4753,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4753(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4753(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4753,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4769,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4782,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_4782(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_4782(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_4782(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_4782(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_4782(t10,C_SCHEME_FALSE);}}}}}

/* k4780 in loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4782(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4782,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4785,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_4785(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4792,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 946  string-copy */
t4=C_retrieve(lf[505]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_4769(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k4790 in k4780 in loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4785(t3,t2);}

/* k4783 in k4780 in loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4785(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_4769(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k4767 in loop in ##compiler#cleanup in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 949  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4753(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4671,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4675,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 911  gen */
t7=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[502],C_SCHEME_TRUE,lf[503],t6,lf[504]);}

/* k4673 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4689,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4689(t6,t2,((C_word*)t0)[2]);}

/* do572 in k4673 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4689(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4689,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 915  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[495]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 916  lambda-literal-id */
t5=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k4700 in do572 in k4673 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4705,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 917  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[500],t1,((C_word*)t0)[2],lf[501]);}

/* k4703 in k4700 in do572 in k4673 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 920  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[496],C_retrieve(lf[185]),lf[497]);}
else{
/* c-backend.scm: 921  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[498]);}}
else{
/* c-backend.scm: 922  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[499]);}}

/* k4706 in k4703 in k4700 in do572 in k4673 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4689(t3,((C_word*)t0)[2],t2);}

/* k4676 in k4673 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 923  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[494]);}

/* k4679 in k4676 in k4673 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 924  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[493]);}

/* k4682 in k4679 in k4676 in k4673 in emit-procedure-table-info in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 925  gen */
t2=C_retrieve(lf[2]);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[486],C_SCHEME_TRUE,lf[487],C_SCHEME_TRUE,lf[488],C_SCHEME_TRUE,lf[489],C_SCHEME_TRUE,lf[490],C_SCHEME_TRUE,lf[491],C_SCHEME_TRUE,lf[492]);}

/* ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[60],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_1142,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1145,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1187,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2614,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2780,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2921,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3172,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3879,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3802,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3495,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3660,a[2]=t17,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3458,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=t17,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3891,a[2]=t4,a[3]=t8,a[4]=t21,a[5]=t19,a[6]=t2,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t24=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4638,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t8,a[6]=t14,a[7]=t23,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 894  debugging */
t25=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t24,lf[484],lf[485]);}

/* k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 896  header */
t4=((C_word*)t0)[2];
f_2614(t4,t3);}

/* k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 897  declarations */
t3=((C_word*)t0)[2];
f_2780(t3,t2);}

/* k4643 in k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 898  generate-external-variables */
t3=C_retrieve(lf[482]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[483]));}

/* k4646 in k4643 in k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 899  generate-foreign-stubs */
t3=C_retrieve(lf[480]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[481]),((C_word*)t0)[3]);}

/* k4649 in k4646 in k4643 in k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 900  prototypes */
t3=((C_word*)t0)[2];
f_2921(t3,t2);}

/* k4652 in k4649 in k4646 in k4643 in k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 901  generate-foreign-callback-stubs */
t3=C_retrieve(lf[479]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[179]),((C_word*)t0)[2]);}

/* k4655 in k4652 in k4649 in k4646 in k4643 in k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 902  trampolines */
t3=((C_word*)t0)[2];
f_3172(t3,t2);}

/* k4658 in k4655 in k4652 in k4649 in k4646 in k4643 in k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 903  procedures */
t3=((C_word*)t0)[2];
f_3891(t3,t2);}

/* k4661 in k4658 in k4655 in k4652 in k4649 in k4646 in k4643 in k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4666,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 904  emit-procedure-table-info */
t3=C_retrieve(lf[478]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4664 in k4661 in k4658 in k4655 in k4652 in k4649 in k4646 in k4643 in k4640 in k4636 in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 475  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[477],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3891,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3897,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 718  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 719  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 720  real-name */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3910,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 721  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 722  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3913,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 723  lambda-literal-customizable */
t5=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4635,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 724  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_3919(t3,C_SCHEME_FALSE);}}

/* k4633 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3919(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3919,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 726  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[475]);}

/* k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3928,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 727  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[474]);}

/* k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3931,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 728  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 729  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 730  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 731  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 732  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 733  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_3949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 734  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 736  string-append */
t3=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[185]),lf[472]);}
else{
t3=t2;
f_3952(2,t3,lf[473]);}}

/* k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 738  debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[470],lf[471],((C_word*)t0)[14]);}
else{
t3=t2;
f_3955(2,t3,C_SCHEME_UNDEFINED);}}

/* k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 739  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4604,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 740  cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4602 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[466],t1,lf[467],C_SCHEME_TRUE);}

/* k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 749  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[460]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 742  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[465]);}}

/* k4563 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[463]:lf[464]);
/* c-backend.scm: 743  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4566 in k4563 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 745  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[461]);}
else{
/* c-backend.scm: 746  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[462]);}}

/* k4569 in k4566 in k4563 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 747  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4585 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4590(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 751  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[459]);}}

/* k4588 in k4585 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 752  gen */
t2=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[453],C_SCHEME_TRUE,lf[454],C_SCHEME_TRUE,lf[455],C_SCHEME_TRUE,lf[456],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[458],((C_word*)t0)[2]);}

/* k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 757  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_3970(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 758  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[452]);}}

/* k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_4537(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4537(t4,C_SCHEME_FALSE);}}

/* k4535 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4537(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4537,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 760  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[451]);}
else{
t2=((C_word*)t0)[2];
f_3973(2,t2,C_SCHEME_UNDEFINED);}}

/* k4538 in k4535 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 761  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3973(2,t2,C_SCHEME_UNDEFINED);}}

/* k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[15]);}

/* k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 763  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[450]);}
else{
t3=t2;
f_3979(2,t3,C_SCHEME_UNDEFINED);}}

/* k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 764  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[449]);}

/* k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[224]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_3985(t5,t4);}
else{
t4=t2;
f_3985(t4,C_SCHEME_UNDEFINED);}}

/* k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3985,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 766  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[448]);}

/* k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 768  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[446],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4499,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4499(t8,t2,((C_word*)t0)[20],t4);}}

/* do459 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4499(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4499,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4509,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 772  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[447],t2,C_make_character(59));}}

/* k4507 in do459 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4499(t4,((C_word*)t0)[2],t2,t3);}

/* k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3994,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4211,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 774  fold */
t6=C_retrieve(lf[413]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 808  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[427]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_4442(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_4442(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k4440 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4442,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 822  gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[437],C_SCHEME_TRUE,lf[438],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440]);}
else{
/* c-backend.scm: 825  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[441],((C_word*)t0)[3],lf[442]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4454(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 827  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[445]);}}}

/* k4452 in k4440 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 828  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[444]);}
else{
t3=t2;
f_4457(2,t3,C_SCHEME_UNDEFINED);}}

/* k4455 in k4452 in k4440 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[104]);
t4=t2;
f_4463(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[407]))));}
else{
t3=t2;
f_4463(t3,C_SCHEME_FALSE);}}

/* k4461 in k4455 in k4452 in k4440 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 830  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[443]);}
else{
t2=((C_word*)t0)[2];
f_4364(2,t2,C_SCHEME_UNDEFINED);}}

/* k4362 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4406,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4406(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
t6=t3;
f_4406(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_4406(t4,C_SCHEME_FALSE);}}

/* k4404 in k4362 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4406(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 834  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[431],((C_word*)t0)[3],lf[432],((C_word*)t0)[3],lf[433]);}
else{
t4=((C_word*)t0)[2];
f_4367(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 835  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[434],((C_word*)t0)[3],lf[435],((C_word*)t0)[3],lf[436]);}}
else{
t2=((C_word*)t0)[2];
f_4367(2,t2,C_SCHEME_UNDEFINED);}}

/* k4365 in k4362 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_4373(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_4373(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_4373(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k4371 in k4365 in k4362 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4373,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 837  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[430]);}
else{
t3=t2;
f_4376(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_3994(2,t2,C_SCHEME_UNDEFINED);}}

/* k4374 in k4371 in k4365 in k4362 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_4382(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_4382(t3,C_SCHEME_FALSE);}}

/* k4380 in k4374 in k4371 in k4365 in k4362 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4382(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 839  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[428]);}
else{
/* c-backend.scm: 840  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[429]);}}

/* k4298 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 809  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[426]);}

/* k4301 in k4298 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 810  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[425]);}

/* k4304 in k4301 in k4298 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 812  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 813  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[424]);}}

/* k4307 in k4304 in k4301 in k4298 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 814  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[422],((C_word*)t0)[3],lf[423]);}

/* k4310 in k4307 in k4304 in k4301 in k4298 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4327(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
if(C_truep(t5)){
t6=t3;
f_4327(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_4327(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k4325 in k4310 in k4307 in k4304 in k4301 in k4298 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 816  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[418],((C_word*)t0)[2],lf[419],((C_word*)t0)[2],lf[420]);}
else{
t2=((C_word*)t0)[3];
f_4315(2,t2,C_SCHEME_UNDEFINED);}}

/* k4313 in k4310 in k4307 in k4304 in k4301 in k4298 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 817  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[417]);}
else{
t3=t2;
f_4318(2,t3,C_SCHEME_UNDEFINED);}}

/* k4316 in k4313 in k4310 in k4307 in k4304 in k4301 in k4298 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 818  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[414],((C_word*)t0)[2],lf[415]);}

/* a4285 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4286,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4294,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 774  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3501(3,t5,t4,t2);}

/* k4292 in a4285 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4211,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4217,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 776  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[409],C_SCHEME_TRUE,lf[410],C_SCHEME_TRUE,lf[411],((C_word*)t0)[2],lf[412]);}

/* k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[407]))){
/* c-backend.scm: 780  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[408]);}
else{
t3=t2;
f_4220(2,t3,C_SCHEME_UNDEFINED);}}

/* k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4223(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4254,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[400]))){
/* c-backend.scm: 783  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[401],C_retrieve(lf[400]),lf[402]);}
else{
if(C_truep(C_retrieve(lf[403]))){
/* c-backend.scm: 785  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[404],C_retrieve(lf[403]),lf[405],C_SCHEME_TRUE,lf[406]);}
else{
t4=t3;
f_4254(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k4252 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[398]))){
/* c-backend.scm: 788  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[399],C_retrieve(lf[398]),C_make_character(59));}
else{
t3=t2;
f_4257(2,t3,C_SCHEME_UNDEFINED);}}

/* k4255 in k4252 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[396]))){
/* c-backend.scm: 790  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[397],C_retrieve(lf[396]),C_make_character(59));}
else{
t3=t2;
f_4260(2,t3,C_SCHEME_UNDEFINED);}}

/* k4258 in k4255 in k4252 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[393]))){
/* c-backend.scm: 792  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[394],C_retrieve(lf[393]),lf[395]);}
else{
t2=((C_word*)t0)[2];
f_4223(2,t2,C_SCHEME_UNDEFINED);}}

/* k4221 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 793  gen */
t3=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[386],((C_word*)t0)[3],lf[387],C_SCHEME_TRUE,lf[388],((C_word*)t0)[3],lf[389],C_SCHEME_TRUE,lf[390],C_SCHEME_TRUE,lf[391],C_SCHEME_TRUE,lf[392]);}

/* k4224 in k4221 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 798  gen */
t3=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[380],((C_word*)t0)[2],lf[381],C_SCHEME_TRUE,lf[382],C_SCHEME_TRUE,lf[383],((C_word*)t0)[2],lf[384],C_SCHEME_TRUE,lf[385]);}

/* k4227 in k4224 in k4221 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 802  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[2],lf[379]);}

/* k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3994(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 804  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[376],((C_word*)t0)[4],lf[377]);}}

/* k4239 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 805  literal-frame */
t3=((C_word*)t0)[2];
f_3458(t3,t2);}

/* k4242 in k4239 in k4230 in k4227 in k4224 in k4221 in k4218 in k4215 in k4209 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 806  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[374],((C_word*)t0)[2],lf[375]);}

/* k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4017,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[235],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_4017(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_4017(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_4017(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_4017(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_4017(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4017,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[365]:lf[366]);
/* c-backend.scm: 851  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[367],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4152,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[371]:lf[372]);
/* c-backend.scm: 877  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[373]);}}
else{
t2=((C_word*)t0)[10];
f_3997(2,t2,C_SCHEME_UNDEFINED);}}

/* k4150 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 879  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[369]);}
else{
/* c-backend.scm: 880  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[370],((C_word*)t0)[3]);}}

/* k4153 in k4150 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4167,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 882  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4158(2,t3,C_SCHEME_UNDEFINED);}}

/* k4165 in k4153 in k4150 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4156 in k4153 in k4150 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 884  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[368]);}

/* k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[309]);
if(C_truep(t3)){
/* c-backend.scm: 852  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_4026(2,t4,C_SCHEME_UNDEFINED);}}

/* k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 853  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[363],((C_word*)t0)[5],lf[364]);}

/* k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 855  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4032(2,t3,C_SCHEME_UNDEFINED);}}

/* k4131 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 857  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[359],C_SCHEME_TRUE,lf[360],C_SCHEME_TRUE,lf[361],((C_word*)t0)[6],lf[362]);}

/* k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[354]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 861  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[355],((C_word*)t0)[6],lf[356]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[309]);
if(C_truep(t5)){
/* c-backend.scm: 862  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[357],((C_word*)t0)[6],lf[358]);}
else{
t6=t2;
f_4038(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 863  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[353]);}

/* k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4102,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4106,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 864  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[352]);}

/* k4104 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 864  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4100 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 865  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[350],((C_word*)t0)[5],lf[351]);}

/* k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 867  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[348],((C_word*)t0)[2],lf[349]);}

/* k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 869  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[346],((C_word*)t0)[3],lf[347]);}

/* k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 870  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[345]);}

/* k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4077,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4077(t7,t2,t3,((C_word*)t0)[2]);}

/* do503 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_4077(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4077,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4087,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 874  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[344],t2,C_make_character(59));}}

/* k4085 in do503 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4077(t4,((C_word*)t0)[2],t2,t3);}

/* k4060 in k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in k4039 in k4036 in k4033 in k4030 in k4027 in k4024 in k4021 in k4015 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 875  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[342],((C_word*)t0)[3],lf[343]);}
else{
t3=((C_word*)t0)[2];
f_3997(2,t3,C_SCHEME_UNDEFINED);}}

/* k3995 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 886  lambda-literal-body */
t4=C_retrieve(lf[341]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4005 in k3995 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 885  expression */
t3=((C_word*)t0)[4];
f_1187(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k3998 in k3995 in k3992 in k3989 in k3986 in k3983 in k3980 in k3977 in k3974 in k3971 in k3968 in k3965 in k3962 in k3959 in k3956 in k3953 in k3950 in k3947 in k3944 in k3941 in k3938 in k3935 in k3932 in k3929 in k3926 in k3923 in k3917 in k3914 in k3911 in k3908 in k3905 in k3902 in k3899 in a3896 in procedures in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 891  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3501,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 653  immediate? */
t4=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[334]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 657  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3501(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3568,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3572,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 658  vector->list */
t6=*((C_word*)lf[337]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 659  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k3580 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3582,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 660  bad-literal */
f_3495(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 662  ##sys#bytevector? */
t3=*((C_word*)lf[339]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k3598 in k3580 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3600,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3607,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 662  words */
t4=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3629(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 669  bad-literal */
f_3495(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k3598 in k3580 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3629(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3629,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3651,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 668  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3501(3,t8,t6,t7);}}

/* k3649 in loop in k3598 in k3580 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 668  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3629(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3605 in k3598 in k3580 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k3574 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3570 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 658  reduce */
t2=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[336]+1),C_fix(0),t1);}

/* k3566 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k3537 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3543,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 657  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3501(3,t4,t2,t3);}

/* k3541 in k3537 in k3506 in literal-size in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3458,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3464(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* do389 in literal-frame in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3464(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3464,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3474,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3493,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 647  sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[333],t2);}}

/* k3491 in do389 in literal-frame in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 647  gen-lit */
t2=((C_word*)t0)[4];
f_3660(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3472 in do389 in literal-frame in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3464(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3660(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3660,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3800,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 673  big-fixnum? */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_3667(t5,C_SCHEME_FALSE);}}

/* k3798 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3667(t2,(C_word)C_i_not(t1));}

/* k3665 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3667,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 674  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[316],((C_word*)t0)[4],lf[317]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 675  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k3671 in k3665 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[0]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 677  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[318]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[319]:lf[320]);
/* c-backend.scm: 679  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 681  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[321],t4,lf[322]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 684  c-ify-string */
t6=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 689  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[326]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_3756(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_3756(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k3754 in k3671 in k3665 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3756,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 693  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[329]);}
else{
/* c-backend.scm: 696  bad-literal */
f_3495(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k3757 in k3754 in k3671 in k3665 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3769,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 694  encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3767 in k3757 in k3754 in k3671 in k3665 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 694  gen-string-constant */
t2=((C_word*)t0)[3];
f_3802(t2,((C_word*)t0)[2],t1);}

/* k3760 in k3757 in k3754 in k3671 in k3665 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 695  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[327]);}

/* k3721 in k3671 in k3665 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3723,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3729,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 686  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[325]);}

/* k3727 in k3721 in k3671 in k3665 in gen-lit in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 687  gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[323],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[324]);}

/* bad-literal in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3495(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3495,NULL,2,t1,t2);}
/* c-backend.scm: 650  bomb */
t3=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[315],t2);}

/* gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3802(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3802,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3809,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 700  fx/ */
t5=*((C_word*)lf[314]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3812,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 701  modulo */
t3=*((C_word*)lf[313]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k3810 in k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3812,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3817,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3817(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do420 in k3810 in k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3817(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3817,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3833(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_3833(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3854,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3869,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 707  string-like-substring */
f_3879(t7,((C_word*)t0)[4],t3,t8);}}

/* k3871 in do420 in k3810 in k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 707  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3867 in do420 in k3810 in k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 707  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k3852 in do420 in k3810 in k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3817(t4,((C_word*)t0)[2],t2,t3);}

/* k3831 in do420 in k3810 in k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3833(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3833,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3844,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 706  string-like-substring */
f_3879(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3842 in k3831 in do420 in k3810 in k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 706  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3838 in k3831 in do420 in k3810 in k3807 in gen-string-constant in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 706  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3879(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3879,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3886,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 711  make-string */
t7=*((C_word*)lf[312]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k3884 in string-like-substring in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3889,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 712  ##sys#copy-bytes */
t3=C_retrieve(lf[311]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k3887 in k3884 in string-like-substring in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3172,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3175,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3211,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3291,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3339,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3339,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3343,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 606  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 607  lambda-literal-rest-argument */
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 608  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 609  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 610  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 611  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3358(t3,C_SCHEME_FALSE);}}

/* k3454 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3358(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3358,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_3361(t5,t4);}
else{
t3=t2;
f_3361(t3,C_SCHEME_UNDEFINED);}}

/* k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3361,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 613  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 615  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[305],((C_word*)t0)[9],lf[306],C_SCHEME_TRUE,lf[307],((C_word*)t0)[9],lf[308]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3401(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 623  lambda-literal-allocated */
t4=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k3443 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3401(2,t3,t2);}
else{
/* c-backend.scm: 623  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3399 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[224]);
t4=t2;
f_3407(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3407(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3405 in k3399 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3407,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[309]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 626  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 627  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 628  lset-adjoin */
t3=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3423 in k3405 in k3399 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3419 in k3405 in k3399 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3415 in k3405 in k3399 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3371 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 617  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[303],((C_word*)t0)[3],lf[304]);}

/* k3374 in k3371 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 618  restore */
f_3175(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3377 in k3374 in k3371 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 619  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3380 in k3377 in k3374 in k3371 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3385,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 620  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[302]);}

/* k3383 in k3380 in k3377 in k3374 in k3371 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3395,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 621  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k3393 in k3383 in k3380 in k3377 in k3374 in k3371 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3386 in k3383 in k3380 in k3377 in k3374 in k3371 in k3365 in k3359 in k3356 in k3353 in k3350 in k3347 in k3344 in k3341 in a3338 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 622  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[301]);}

/* k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3294,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3309 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 632  gen */
t4=C_retrieve(lf[2]);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[296],t2,lf[297],C_SCHEME_TRUE,lf[298],t2,lf[299],t2,lf[300]);}

/* k3312 in a3309 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 634  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[293],((C_word*)t0)[3],lf[294],((C_word*)t0)[3],lf[295]);}

/* k3315 in k3312 in a3309 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 635  restore */
f_3175(t2,((C_word*)t0)[3]);}

/* k3318 in k3315 in k3312 in a3309 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[292],((C_word*)t0)[2],C_make_character(44));}

/* k3321 in k3318 in k3315 in k3312 in a3309 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3333,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 637  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[291]);}

/* k3335 in k3321 in k3318 in k3315 in k3312 in a3309 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 637  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3331 in k3321 in k3318 in k3315 in k3312 in a3309 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3324 in k3321 in k3318 in k3315 in k3312 in a3309 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 638  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[290]);}

/* k3292 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 640  emitter */
t4=((C_word*)t0)[3];
f_3211(t4,t3,C_SCHEME_FALSE);}

/* k3306 in k3292 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3295 in k3292 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 641  emitter */
t3=((C_word*)t0)[2];
f_3211(t3,t2,C_SCHEME_TRUE);}

/* k3302 in k3295 in k3292 in k3289 in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3211(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3211,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_3213 in emitter in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3213,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[285]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[286]);
/* c-backend.scm: 584  gen */
t6=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[287],t2,C_make_character(114),t4,lf[288],C_SCHEME_TRUE,lf[289],t2,C_make_character(114),t5);}

/* k3215 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 586  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[283],((C_word*)t0)[4],lf[284]);}

/* k3218 in k3215 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 587  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[282],((C_word*)t0)[4],C_make_character(114));}

/* k3221 in k3218 in k3215 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 588  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_3226(2,t3,C_SCHEME_UNDEFINED);}}

/* k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 589  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[278],((C_word*)t0)[4],lf[279],C_SCHEME_TRUE,lf[280],C_SCHEME_TRUE,lf[281],((C_word*)t0)[4],C_make_character(59));}

/* k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 592  restore */
f_3175(t2,((C_word*)t0)[4]);}

/* k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 593  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[277]);}

/* k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 595  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[275]);}
else{
/* c-backend.scm: 596  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[276]);}}

/* k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 597  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[274]);}

/* k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3244,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 598  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[273]);}
else{
t3=t2;
f_3244(2,t3,C_SCHEME_UNDEFINED);}}

/* k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 599  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[272]);}

/* k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 600  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[271]);}

/* k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3253,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3260,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3264,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 601  make-argument-list */
t6=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[270]);}

/* k3262 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 601  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3258 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3251 in k3248 in k3245 in k3242 in k3239 in k3236 in k3233 in k3230 in k3227 in k3224 in k3221 in k3218 in k3215 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 602  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[268]);}

/* restore in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3175(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3175,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3179,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3188,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3188(t8,t3,t4,C_fix(0));}

/* do338 in restore in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3188(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3188,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3198,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 579  gen */
t5=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[265],t2,lf[266],t3,lf[267]);}}

/* k3196 in do338 in restore in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3188(t4,((C_word*)t0)[2],t2,t3);}

/* k3177 in restore in trampolines in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 580  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[263],((C_word*)t0)[2],lf[264]);}

/* prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2921,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 508  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2949,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2949(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2949,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2953,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 511  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 512  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 513  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2959(t3,C_SCHEME_FALSE);}}

/* k3168 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2959(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2959(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2959,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3156,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 514  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[260]);}

/* k3154 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 514  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 515  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 516  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 517  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 518  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 519  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3148,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 521  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_2980(t5,C_SCHEME_UNDEFINED);}}

/* k3146 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2980(t3,t2);}

/* k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2980,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 522  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 527  lambda-literal-callee-signatures */
t5=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3139 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3121 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3122,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3133,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 526  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k3131 in a3121 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3098,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 537  string-append */
t5=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[185]),lf[242]);}
else{
t5=t4;
f_3098(2,t5,lf[243]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 529  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[249],((C_word*)t0)[5],lf[250],C_SCHEME_TRUE);}}

/* k3071 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 530  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[248]);}

/* k3074 in k3071 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3079,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[246]:lf[247]);
/* c-backend.scm: 531  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3077 in k3074 in k3071 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 533  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[244]);}
else{
/* c-backend.scm: 534  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[245]);}}

/* k3080 in k3077 in k3074 in k3071 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 535  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3096 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 538  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[240],t1,lf[241],C_SCHEME_TRUE);}

/* k3099 in k3096 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[238]))){
/* c-backend.scm: 540  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[239],C_SCHEME_TRUE);}
else{
t3=t2;
f_3104(2,t3,C_SCHEME_UNDEFINED);}}

/* k3102 in k3099 in k3096 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 541  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}

/* k3105 in k3102 in k3099 in k3096 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 542  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[236],((C_word*)t0)[2]);}

/* k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 543  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2995(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 544  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[234]);}}

/* k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3045,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3045(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3045(t4,C_SCHEME_FALSE);}}

/* k3043 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_3045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3045,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 546  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}
else{
t2=((C_word*)t0)[2];
f_2998(2,t2,C_SCHEME_UNDEFINED);}}

/* k3046 in k3043 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 547  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2998(2,t2,C_SCHEME_UNDEFINED);}}

/* k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[4]);}

/* k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3001,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3007,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 550  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[231]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 558  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k3031 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3036(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 560  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[232]);}}

/* k3034 in k3031 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 561  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3005 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3007,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 553  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[227],((C_word*)t0)[2],lf[228],C_SCHEME_TRUE,lf[229],((C_word*)t0)[2],lf[230]);}}

/* k3014 in k3005 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k3017 in k3014 in k3005 in k2999 in k2996 in k2993 in k2990 in k2987 in k2984 in k2981 in k2978 in k2975 in k2972 in k2969 in k2966 in k2963 in k2960 in k2957 in k2954 in k2951 in a2948 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 556  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[225],t2,lf[226]);}

/* k2926 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2933,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a2932 in k2926 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2933,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2937,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 565  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[222],t2,lf[223]);}

/* k2935 in a2932 in k2926 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2940,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 566  make-list */
t4=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[221]);}

/* k2945 in k2935 in a2932 in k2926 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k2938 in k2935 in a2932 in k2926 in k2923 in prototypes in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 567  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[219]);}

/* declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2780,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2787,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 479  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[218]);}

/* k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2915,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[187]));}

/* a2914 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2915,3,t0,t1,t2);}
/* c-backend.scm: 482  gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[214],t2,lf[215],C_SCHEME_TRUE,lf[216],t2,lf[217]);}

/* k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_2793(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 486  gen */
t4=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[212],((C_word*)t0)[2],lf[213]);}}

/* k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 487  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[211]);}

/* k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2801,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2801(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2801(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2801,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2811,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 491  ##sys#lambda-info->string */
t6=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2817,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 493  gen */
t8=C_retrieve(lf[2]);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[208],((C_word*)t0)[5],lf[209],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2862(t6,t2,C_fix(0));}

/* do274 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2862(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2862,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2872,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 500  gen */
t7=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k2870 in do274 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2862(t3,((C_word*)t0)[2],t2);}

/* k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_modulo(((C_word*)t0)[2],C_fix(8));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2843,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2843(t7,t2,t3);}

/* do279 in k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2843(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2843,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2853,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 503  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[207]);}}

/* k2851 in do279 in k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2843(t3,((C_word*)t0)[2],t2);}

/* k2821 in k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 504  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[206]);}

/* k2824 in k2821 in k2818 in k2815 in k2809 in do268 in k2794 in k2791 in k2788 in k2785 in declarations in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2801(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2614,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2617,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2634,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2772,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 449  current-seconds */
t5=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2770 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 449  ##sys#decode-seconds */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_2640(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_2640(t3,C_SCHEME_FALSE);}}

/* k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2640(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2640,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2658,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2717,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 453  pad0 */
f_2617(t9,t10);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 453  pad0 */
f_2617(t2,((C_word*)t0)[2]);}

/* k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 453  pad0 */
f_2617(t2,((C_word*)t0)[2]);}

/* k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2729,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 453  pad0 */
f_2617(t2,((C_word*)t0)[2]);}

/* k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2733,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2739,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2747,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2751,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 456  chicken-version */
t7=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k2749 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 456  string-split */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[201]);}

/* k2745 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2738 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2739,3,t0,t1,t2);}
/* string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[197],t2,lf[198]);}

/* k2735 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 454  string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[196]);}

/* k2731 in k2727 in k2723 in k2719 in k2715 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 451  gen */
t2=C_retrieve(lf[2]);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[190],((C_word*)t0)[7],lf[191],C_SCHEME_TRUE,lf[192],C_SCHEME_TRUE,lf[193],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[194]);}

/* k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 459  gen-list */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[189]));}

/* k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 460  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 461  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[186],C_retrieve(lf[185]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 463  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[188]);}}

/* k2704 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 464  gen-list */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[187]));}

/* k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 465  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[181],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[182],C_retrieve(lf[183]),lf[184]);}

/* k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[177]))){
/* c-backend.scm: 467  generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[179]));}
else{
t3=t2;
f_2673(2,t3,C_SCHEME_UNDEFINED);}}

/* k2671 in k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[180])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2688,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 469  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_2676(2,t3,C_SCHEME_UNDEFINED);}}

/* k2686 in k2671 in k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2693,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[180]));}

/* a2692 in k2686 in k2671 in k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2693,3,t0,t1,t2);}
/* c-backend.scm: 470  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k2674 in k2671 in k2668 in k2665 in k2662 in k2659 in k2656 in k2638 in k2632 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[177]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 472  generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[179]));}}

/* pad0 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2617(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2617,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2631,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 447  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2629 in pad0 in header in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 447  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[176],t1);}

/* expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1187(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1187,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2582,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 442  expr */
t11=((C_word*)t6)[1];
f_1190(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2582(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2582,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2588,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 436  pair-for-each */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a2587 in expr-args in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2588,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_2592(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 438  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k2590 in a2587 in expr-args in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 439  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1190(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word ab[209],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1190,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[14]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[16]:lf[17]);
/* c-backend.scm: 127  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[18]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 128  gen */
t16=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t1,lf[19],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t14)){
/* c-backend.scm: 129  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,lf[21]);}
else{
t15=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 130  gen */
t17=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t1,lf[23],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t16)){
/* c-backend.scm: 131  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[25]);}
else{
/* c-backend.scm: 132  bomb */
t17=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[26]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[27]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 137  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[28],t13,lf[29]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 138  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[30],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[31]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1314,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
t14=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_SCHEME_TRUE,lf[34]);}
else{
t13=(C_word)C_eqp(t9,lf[35]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 150  gen */
t15=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,lf[36],t14);}
else{
t14=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_1372(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[38]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1423,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 162  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[40]);}
else{
t16=(C_word)C_eqp(t9,lf[41]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1450,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 167  gen */
t18=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,lf[43]);}
else{
t17=(C_word)C_eqp(t9,lf[44]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1469,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 172  gen */
t19=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[45]);}
else{
t18=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1502,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 179  gen */
t20=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[49]);}
else{
t19=(C_word)C_eqp(t9,lf[50]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1539,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
t21=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t20,lf[52]);}
else{
t20=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1568,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
t22=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[55]);}
else{
t21=(C_word)C_eqp(t9,lf[56]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1600,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 201  gen */
t24=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t24))(5,t24,t23,lf[63],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[64]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1635,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 211  gen */
t24=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,lf[66]);}
else{
t23=(C_word)C_eqp(t9,lf[67]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 215  gen */
t25=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[68]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1667,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 218  gen */
t27=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t27))(5,t27,t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 227  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[70],t26,lf[71]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1709,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 228  symbol->string */
t31=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 229  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[76],t26,lf[77]);}
else{
/* c-backend.scm: 230  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[78],t26,lf[79]);}}}
else{
t26=(C_word)C_eqp(t9,lf[80]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1741,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t28)){
/* c-backend.scm: 236  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[81],t27,lf[82]);}
else{
/* c-backend.scm: 237  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[83],t27,lf[84]);}}
else{
t27=(C_word)C_eqp(t9,lf[85]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_cadr(t7))){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1775,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 245  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[86],t28,lf[87]);}
else{
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1788,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 249  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[88],t28,lf[89]);}}
else{
t28=(C_word)C_eqp(t9,lf[90]);
if(C_truep(t28)){
/* c-backend.scm: 253  gen */
t29=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t29))(3,t29,t1,lf[91]);}
else{
t29=(C_word)C_eqp(t9,lf[92]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1831,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=t36,a[5]=t32,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t31,a[9]=t33,a[10]=t3,a[11]=t30,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 262  source-info->string */
t38=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[125]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2142,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 319  lambda-literal-closure-size */
t36=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[129]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2227,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2231,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 347  find-lambda */
t41=((C_word*)t0)[2];
f_1145(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[131]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2250,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 364  gen */
t37=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t37))(8,t37,t35,C_SCHEME_TRUE,lf[133],t36,lf[134],t34,lf[135]);}
else{
t33=(C_word)C_eqp(t9,lf[136]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2269,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 369  gen */
t35=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,C_SCHEME_TRUE,lf[138]);}
else{
t34=(C_word)C_eqp(t9,lf[139]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2288,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 374  gen */
t37=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t37))(5,t37,t35,lf[140],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[141]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2307,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 379  gen */
t39=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t39))(6,t39,t36,lf[142],t37,lf[143],t38);}
else{
t36=(C_word)C_eqp(t9,lf[144]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2343,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 387  foreign-result-conversion */
t39=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t39))(4,t39,t37,t38,lf[146]);}
else{
t37=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2363,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2381,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 391  foreign-type-declaration */
t42=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t38,lf[152]);}
else{
t38=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2397,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2411,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 397  foreign-result-conversion */
t42=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t39,lf[158]);}
else{
t39=(C_word)C_eqp(t9,lf[159]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2427,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 403  foreign-type-declaration */
t43=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t43))(4,t43,t42,t40,lf[164]);}
else{
t40=(C_word)C_eqp(t9,lf[165]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2464,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 410  gen */
t42=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,C_SCHEME_TRUE,lf[169]);}
else{
t41=(C_word)C_eqp(t9,lf[170]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2547,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 425  gen */
t43=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t43))(3,t43,t42,lf[172]);}
else{
/* c-backend.scm: 433  bomb */
t42=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t42))(3,t42,t1,lf[173]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 426  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 427  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[171]);}

/* k2551 in k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 428  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2554 in k2551 in k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 429  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2557 in k2554 in k2551 in k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2562,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 430  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2560 in k2557 in k2554 in k2551 in k2548 in k2545 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 431  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 411  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1190(t4,t2,t3,((C_word*)t0)[3]);}

/* k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 412  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}

/* k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2483,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2483(t7,((C_word*)t0)[2],t2,t3);}

/* do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_2483(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2483,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 416  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[166]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 419  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[167]);}}

/* k2504 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 420  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2507 in k2504 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 421  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2510 in k2507 in k2504 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 422  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2513 in k2510 in k2507 in k2504 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2483(t4,((C_word*)t0)[2],t2,t3);}

/* k2491 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 417  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2494 in k2491 in do215 in k2468 in k2465 in k2462 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 418  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k2453 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 403  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[162],t1,lf[163]);}

/* k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 404  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1190(t4,t2,t3,((C_word*)t0)[3]);}

/* k2428 in k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 405  foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2445 in k2428 in k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 405  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[161],t1);}

/* k2431 in k2428 in k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 406  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2434 in k2431 in k2428 in k2425 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 407  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[160]);}

/* k2409 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2415,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 397  foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[157]);}

/* k2413 in k2409 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 397  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[155],t1,lf[156]);}

/* k2395 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 398  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2398 in k2395 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 399  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[154]);}

/* k2379 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2385,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 391  foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2383 in k2379 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 391  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_make_character(41),t1);}

/* k2361 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 392  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2364 in k2361 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 393  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[148]);}

/* k2341 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 387  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k2305 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 382  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_2310(2,t3,C_SCHEME_UNDEFINED);}}

/* k2317 in k2305 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 383  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2582(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2308 in k2305 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 384  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2286 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 375  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2289 in k2286 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 376  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2267 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 370  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k2270 in k2267 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 371  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[137]);}

/* k2248 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 365  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2251 in k2248 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 366  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[132]);}

/* k2229 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 347  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 349  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2208,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 351  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[130],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_2178(2,t3,C_SCHEME_UNDEFINED);}}

/* k2206 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 352  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_2178(2,t4,C_SCHEME_UNDEFINED);}}

/* k2176 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_2181(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 354  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k2194 in k2176 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 355  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2181(2,t2,C_SCHEME_UNDEFINED);}}

/* k2179 in k2176 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 356  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2582(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_2184(2,t3,C_SCHEME_UNDEFINED);}}

/* k2182 in k2179 in k2176 in k2173 in k2225 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 357  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 321  lambda-literal-temporaries */
t4=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2126,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 334  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k2124 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2129(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 335  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[128]);}}

/* k2127 in k2124 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 336  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2130 in k2127 in k2124 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 322  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 323  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2108 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2109,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 325  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k2111 in a2108 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 326  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2114 in k2111 in a2108 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 327  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2089 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2099,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 331  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k2105 in k2089 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 329  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2098 in k2089 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2099,4,t0,t1,t2,t3);}
/* c-backend.scm: 330  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[127],t2,C_make_character(59));}

/* k2092 in k2089 in k2086 in k2083 in k2140 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 332  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[126]);}

/* k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[15]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_1834(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1834(t3,C_SCHEME_FALSE);}}

/* k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1834,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2031,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2035,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 265  find-lambda */
t6=((C_word*)t0)[2];
f_1145(t6,t5,t1);}
else{
t4=t3;
f_1840(t4,C_SCHEME_FALSE);}}

/* k2033 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 265  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2029 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1840(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1840(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1840,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_retrieve(lf[112]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2017,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1175,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 114  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2024,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1185,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 115  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}}
else{
t4=t3;
f_1846(2,t4,C_SCHEME_UNDEFINED);}}

/* k1183 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 115  string-translate* */
t2=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[122]);}

/* k2022 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 270  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[119],t1,lf[120]);}

/* k1173 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 114  string-translate */
t2=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[116],lf[117]);}

/* k2015 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 269  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[113],t1,lf[114]);}

/* k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[35],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 273  gen */
t7=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[94]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1877,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 277  lambda-literal-id */
t6=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 303  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 304  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1190(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 305  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[110],((C_word*)t0)[4],lf[111]);}

/* k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1991(t5,t3);}
else{
t5=C_retrieve(lf[109]);
t6=t4;
f_1991(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k1989 in k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 308  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[105],((C_word*)t0)[2],lf[106]);}
else{
/* c-backend.scm: 309  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[107],((C_word*)t0)[2],lf[108]);}}

/* k1977 in k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 310  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[102],((C_word*)t0)[3],lf[103],((C_word*)t0)[2],C_make_character(44));}

/* k1980 in k1977 in k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 311  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 312  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[101]);}

/* k1965 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 278  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_1877(2,t3,C_SCHEME_FALSE);}}

/* k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1877,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 279  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_1927(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 294  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k1949 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 295  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1952 in k1949 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 296  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 297  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k1928 in k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1933(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 298  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k1931 in k1928 in k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1936,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1936(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 299  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k1934 in k1931 in k1928 in k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 300  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1937 in k1934 in k1931 in k1928 in k1925 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 301  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[99]);}

/* k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 280  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 281  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a1909 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1910,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 283  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k1912 in a1909 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1917,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 284  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1915 in k1912 in a1909 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 285  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1900,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 289  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k1906 in k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 287  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1899 in k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1900,4,t0,t1,t2,t3);}
/* c-backend.scm: 288  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[97],t2,C_make_character(59));}

/* k1887 in k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1892(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 290  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[96],((C_word*)t0)[2],C_make_character(59));}}

/* k1890 in k1887 in k1884 in k1881 in k1878 in k1875 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 291  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[95]);}

/* k1856 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 274  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2582(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1859 in k1856 in k1844 in k1838 in k1832 in k1829 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 275  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[93]);}

/* k1786 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 250  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1789 in k1786 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1773 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 246  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1776 in k1773 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1739 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 238  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1742 in k1739 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1711 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1707 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 228  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[72],((C_word*)t0)[2],lf[73],t1,C_make_character(41));}

/* k1665 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 219  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1633 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 212  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1636 in k1633 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 213  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[65]);}

/* k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 207  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k1624 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 202  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1611 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1612,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 204  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[59],t3,lf[60]);}

/* k1614 in a1611 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 205  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1190(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1617 in k1614 in a1611 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 206  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k1601 in k1598 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 208  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[57],t2,lf[58]);}

/* k1566 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1569 in k1566 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 195  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k1572 in k1569 in k1566 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1577,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 196  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1575 in k1572 in k1569 in k1566 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 197  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1537 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1540 in k1537 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 188  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[51]);}

/* k1543 in k1540 in k1537 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 189  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1546 in k1543 in k1540 in k1537 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 190  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1500 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1190(t4,t2,t3,((C_word*)t0)[3]);}

/* k1503 in k1500 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 181  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[47],t4,lf[48]);}

/* k1506 in k1503 in k1500 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 182  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1509 in k1506 in k1503 in k1500 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 183  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1467 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1190(t4,t2,t3,((C_word*)t0)[3]);}

/* k1470 in k1467 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 174  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k1473 in k1470 in k1467 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 175  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1476 in k1473 in k1470 in k1467 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 176  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1448 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 168  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1451 in k1448 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 169  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[42]);}

/* k1421 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1426,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 163  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1424 in k1421 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 164  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[39],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1372(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1372,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 155  gen */
t7=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 159  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1190(t7,t1,t6,t3);}}

/* k1380 in loop in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 156  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1190(t4,t2,t3,((C_word*)t0)[6]);}

/* k1383 in k1380 in loop in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 157  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k1386 in k1383 in k1380 in loop in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 158  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1372(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k1318 in k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1321 in k1318 in k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 145  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[32]);}

/* k1324 in k1321 in k1318 in k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 146  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1190(t4,t2,t3,((C_word*)t0)[2]);}

/* k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in expr in expression in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 147  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_fcall f_1145(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1145,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1149,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 111  find */
t5=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1156 in find-lambda in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1157,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1165,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 111  lambda-literal-id */
t4=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1163 in a1156 in find-lambda in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k1147 in find-lambda in ##compiler#generate-code in k1138 in k1093 in k1090 in k1087 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 112  bomb */
t2=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[11],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k1093 in k1090 in k1087 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1122,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1128,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1136,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 93   intersperse */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k1134 in ##compiler#gen-list in k1093 in k1090 in k1087 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1127 in ##compiler#gen-list in k1093 in k1090 in k1087 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1128,3,t0,t1,t2);}
/* c-backend.scm: 92   display */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[1]));}

/* ##compiler#gen in k1093 in k1090 in k1087 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_1101r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1101r(t0,t1,t2);}}

static void C_ccall f_1101r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1107,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a1106 in ##compiler#gen in k1093 in k1090 in k1087 */
static void C_ccall f_1107(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1107,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 86   newline */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_retrieve(lf[1]));}
else{
/* c-backend.scm: 87   display */
t4=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve(lf[1]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[672] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_1089c-backend.scm",(void*)f_1089},
{"f_1092c-backend.scm",(void*)f_1092},
{"f_1095c-backend.scm",(void*)f_1095},
{"f_8791c-backend.scm",(void*)f_8791},
{"f_8795c-backend.scm",(void*)f_8795},
{"f_8787c-backend.scm",(void*)f_8787},
{"f_1140c-backend.scm",(void*)f_1140},
{"f_8487c-backend.scm",(void*)f_8487},
{"f_8763c-backend.scm",(void*)f_8763},
{"f_8761c-backend.scm",(void*)f_8761},
{"f_8749c-backend.scm",(void*)f_8749},
{"f_8719c-backend.scm",(void*)f_8719},
{"f_8680c-backend.scm",(void*)f_8680},
{"f_8667c-backend.scm",(void*)f_8667},
{"f_8663c-backend.scm",(void*)f_8663},
{"f_8549c-backend.scm",(void*)f_8549},
{"f_8496c-backend.scm",(void*)f_8496},
{"f_8493c-backend.scm",(void*)f_8493},
{"f_8490c-backend.scm",(void*)f_8490},
{"f_7713c-backend.scm",(void*)f_7713},
{"f_7800c-backend.scm",(void*)f_7800},
{"f_7881c-backend.scm",(void*)f_7881},
{"f_8316c-backend.scm",(void*)f_8316},
{"f_8258c-backend.scm",(void*)f_8258},
{"f_8222c-backend.scm",(void*)f_8222},
{"f_8187c-backend.scm",(void*)f_8187},
{"f_8139c-backend.scm",(void*)f_8139},
{"f_8091c-backend.scm",(void*)f_8091},
{"f_8043c-backend.scm",(void*)f_8043},
{"f_8008c-backend.scm",(void*)f_8008},
{"f_7972c-backend.scm",(void*)f_7972},
{"f_7936c-backend.scm",(void*)f_7936},
{"f_7914c-backend.scm",(void*)f_7914},
{"f_7909c-backend.scm",(void*)f_7909},
{"f_7904c-backend.scm",(void*)f_7904},
{"f_7715c-backend.scm",(void*)f_7715},
{"f_6880c-backend.scm",(void*)f_6880},
{"f_6910c-backend.scm",(void*)f_6910},
{"f_6937c-backend.scm",(void*)f_6937},
{"f_7132c-backend.scm",(void*)f_7132},
{"f_7141c-backend.scm",(void*)f_7141},
{"f_7150c-backend.scm",(void*)f_7150},
{"f_7538c-backend.scm",(void*)f_7538},
{"f_7505c-backend.scm",(void*)f_7505},
{"f_7515c-backend.scm",(void*)f_7515},
{"f_7473c-backend.scm",(void*)f_7473},
{"f_7438c-backend.scm",(void*)f_7438},
{"f_7368c-backend.scm",(void*)f_7368},
{"f_7323c-backend.scm",(void*)f_7323},
{"f_7291c-backend.scm",(void*)f_7291},
{"f_7259c-backend.scm",(void*)f_7259},
{"f_7227c-backend.scm",(void*)f_7227},
{"f_7195c-backend.scm",(void*)f_7195},
{"f_7173c-backend.scm",(void*)f_7173},
{"f_6882c-backend.scm",(void*)f_6882},
{"f_5663c-backend.scm",(void*)f_5663},
{"f_5740c-backend.scm",(void*)f_5740},
{"f_5842c-backend.scm",(void*)f_5842},
{"f_5875c-backend.scm",(void*)f_5875},
{"f_5971c-backend.scm",(void*)f_5971},
{"f_5986c-backend.scm",(void*)f_5986},
{"f_6603c-backend.scm",(void*)f_6603},
{"f_6619c-backend.scm",(void*)f_6619},
{"f_6623c-backend.scm",(void*)f_6623},
{"f_6636c-backend.scm",(void*)f_6636},
{"f_6634c-backend.scm",(void*)f_6634},
{"f_6630c-backend.scm",(void*)f_6630},
{"f_6557c-backend.scm",(void*)f_6557},
{"f_6570c-backend.scm",(void*)f_6570},
{"f_6507c-backend.scm",(void*)f_6507},
{"f_6457c-backend.scm",(void*)f_6457},
{"f_6418c-backend.scm",(void*)f_6418},
{"f_6428c-backend.scm",(void*)f_6428},
{"f_6379c-backend.scm",(void*)f_6379},
{"f_6389c-backend.scm",(void*)f_6389},
{"f_6340c-backend.scm",(void*)f_6340},
{"f_6350c-backend.scm",(void*)f_6350},
{"f_6301c-backend.scm",(void*)f_6301},
{"f_6311c-backend.scm",(void*)f_6311},
{"f_6241c-backend.scm",(void*)f_6241},
{"f_6258c-backend.scm",(void*)f_6258},
{"f_6268c-backend.scm",(void*)f_6268},
{"f_6266c-backend.scm",(void*)f_6266},
{"f_6262c-backend.scm",(void*)f_6262},
{"f_6254c-backend.scm",(void*)f_6254},
{"f_6202c-backend.scm",(void*)f_6202},
{"f_6212c-backend.scm",(void*)f_6212},
{"f_6166c-backend.scm",(void*)f_6166},
{"f_6130c-backend.scm",(void*)f_6130},
{"f_6094c-backend.scm",(void*)f_6094},
{"f_6058c-backend.scm",(void*)f_6058},
{"f_6032c-backend.scm",(void*)f_6032},
{"f_6040c-backend.scm",(void*)f_6040},
{"f_6023c-backend.scm",(void*)f_6023},
{"f_6031c-backend.scm",(void*)f_6031},
{"f_6018c-backend.scm",(void*)f_6018},
{"f_5670c-backend.scm",(void*)f_5670},
{"f_5665c-backend.scm",(void*)f_5665},
{"f_5598c-backend.scm",(void*)f_5598},
{"f_5602c-backend.scm",(void*)f_5602},
{"f_5605c-backend.scm",(void*)f_5605},
{"f_5608c-backend.scm",(void*)f_5608},
{"f_5611c-backend.scm",(void*)f_5611},
{"f_5617c-backend.scm",(void*)f_5617},
{"f_5661c-backend.scm",(void*)f_5661},
{"f_5620c-backend.scm",(void*)f_5620},
{"f_5628c-backend.scm",(void*)f_5628},
{"f_5649c-backend.scm",(void*)f_5649},
{"f_5632c-backend.scm",(void*)f_5632},
{"f_5623c-backend.scm",(void*)f_5623},
{"f_5167c-backend.scm",(void*)f_5167},
{"f_5173c-backend.scm",(void*)f_5173},
{"f_5177c-backend.scm",(void*)f_5177},
{"f_5180c-backend.scm",(void*)f_5180},
{"f_5183c-backend.scm",(void*)f_5183},
{"f_5186c-backend.scm",(void*)f_5186},
{"f_5192c-backend.scm",(void*)f_5192},
{"f_5533c-backend.scm",(void*)f_5533},
{"f_5536c-backend.scm",(void*)f_5536},
{"f_5596c-backend.scm",(void*)f_5596},
{"f_5539c-backend.scm",(void*)f_5539},
{"f_5542c-backend.scm",(void*)f_5542},
{"f_5545c-backend.scm",(void*)f_5545},
{"f_5548c-backend.scm",(void*)f_5548},
{"f_5581c-backend.scm",(void*)f_5581},
{"f_5589c-backend.scm",(void*)f_5589},
{"f_5551c-backend.scm",(void*)f_5551},
{"f_5579c-backend.scm",(void*)f_5579},
{"f_5554c-backend.scm",(void*)f_5554},
{"f_5557c-backend.scm",(void*)f_5557},
{"f_5560c-backend.scm",(void*)f_5560},
{"f_5194c-backend.scm",(void*)f_5194},
{"f_5204c-backend.scm",(void*)f_5204},
{"f_5213c-backend.scm",(void*)f_5213},
{"f_5225c-backend.scm",(void*)f_5225},
{"f_5237c-backend.scm",(void*)f_5237},
{"f_5243c-backend.scm",(void*)f_5243},
{"f_5277c-backend.scm",(void*)f_5277},
{"f_4934c-backend.scm",(void*)f_4934},
{"f_4940c-backend.scm",(void*)f_4940},
{"f_4944c-backend.scm",(void*)f_4944},
{"f_4947c-backend.scm",(void*)f_4947},
{"f_4950c-backend.scm",(void*)f_4950},
{"f_5165c-backend.scm",(void*)f_5165},
{"f_4956c-backend.scm",(void*)f_4956},
{"f_4959c-backend.scm",(void*)f_4959},
{"f_4962c-backend.scm",(void*)f_4962},
{"f_4965c-backend.scm",(void*)f_4965},
{"f_4968c-backend.scm",(void*)f_4968},
{"f_4971c-backend.scm",(void*)f_4971},
{"f_4974c-backend.scm",(void*)f_4974},
{"f_4977c-backend.scm",(void*)f_4977},
{"f_4980c-backend.scm",(void*)f_4980},
{"f_4983c-backend.scm",(void*)f_4983},
{"f_5154c-backend.scm",(void*)f_5154},
{"f_4986c-backend.scm",(void*)f_4986},
{"f_4989c-backend.scm",(void*)f_4989},
{"f_4992c-backend.scm",(void*)f_4992},
{"f_4995c-backend.scm",(void*)f_4995},
{"f_4998c-backend.scm",(void*)f_4998},
{"f_5001c-backend.scm",(void*)f_5001},
{"f_5004c-backend.scm",(void*)f_5004},
{"f_5007c-backend.scm",(void*)f_5007},
{"f_5132c-backend.scm",(void*)f_5132},
{"f_5102c-backend.scm",(void*)f_5102},
{"f_5122c-backend.scm",(void*)f_5122},
{"f_5110c-backend.scm",(void*)f_5110},
{"f_5114c-backend.scm",(void*)f_5114},
{"f_5118c-backend.scm",(void*)f_5118},
{"f_5010c-backend.scm",(void*)f_5010},
{"f_5013c-backend.scm",(void*)f_5013},
{"f_5043c-backend.scm",(void*)f_5043},
{"f_5046c-backend.scm",(void*)f_5046},
{"f_5084c-backend.scm",(void*)f_5084},
{"f_5080c-backend.scm",(void*)f_5080},
{"f_5049c-backend.scm",(void*)f_5049},
{"f_5052c-backend.scm",(void*)f_5052},
{"f_5055c-backend.scm",(void*)f_5055},
{"f_5022c-backend.scm",(void*)f_5022},
{"f_5025c-backend.scm",(void*)f_5025},
{"f_5016c-backend.scm",(void*)f_5016},
{"f_4916c-backend.scm",(void*)f_4916},
{"f_4922c-backend.scm",(void*)f_4922},
{"f_4926c-backend.scm",(void*)f_4926},
{"f_4929c-backend.scm",(void*)f_4929},
{"f_4865c-backend.scm",(void*)f_4865},
{"f_4869c-backend.scm",(void*)f_4869},
{"f_4874c-backend.scm",(void*)f_4874},
{"f_4881c-backend.scm",(void*)f_4881},
{"f_4901c-backend.scm",(void*)f_4901},
{"f_4849c-backend.scm",(void*)f_4849},
{"f_4855c-backend.scm",(void*)f_4855},
{"f_4863c-backend.scm",(void*)f_4863},
{"f_4833c-backend.scm",(void*)f_4833},
{"f_4839c-backend.scm",(void*)f_4839},
{"f_4847c-backend.scm",(void*)f_4847},
{"f_4744c-backend.scm",(void*)f_4744},
{"f_4753c-backend.scm",(void*)f_4753},
{"f_4782c-backend.scm",(void*)f_4782},
{"f_4792c-backend.scm",(void*)f_4792},
{"f_4785c-backend.scm",(void*)f_4785},
{"f_4769c-backend.scm",(void*)f_4769},
{"f_4671c-backend.scm",(void*)f_4671},
{"f_4675c-backend.scm",(void*)f_4675},
{"f_4689c-backend.scm",(void*)f_4689},
{"f_4702c-backend.scm",(void*)f_4702},
{"f_4705c-backend.scm",(void*)f_4705},
{"f_4708c-backend.scm",(void*)f_4708},
{"f_4678c-backend.scm",(void*)f_4678},
{"f_4681c-backend.scm",(void*)f_4681},
{"f_4684c-backend.scm",(void*)f_4684},
{"f_1142c-backend.scm",(void*)f_1142},
{"f_4638c-backend.scm",(void*)f_4638},
{"f_4642c-backend.scm",(void*)f_4642},
{"f_4645c-backend.scm",(void*)f_4645},
{"f_4648c-backend.scm",(void*)f_4648},
{"f_4651c-backend.scm",(void*)f_4651},
{"f_4654c-backend.scm",(void*)f_4654},
{"f_4657c-backend.scm",(void*)f_4657},
{"f_4660c-backend.scm",(void*)f_4660},
{"f_4663c-backend.scm",(void*)f_4663},
{"f_4666c-backend.scm",(void*)f_4666},
{"f_3891c-backend.scm",(void*)f_3891},
{"f_3897c-backend.scm",(void*)f_3897},
{"f_3901c-backend.scm",(void*)f_3901},
{"f_3904c-backend.scm",(void*)f_3904},
{"f_3907c-backend.scm",(void*)f_3907},
{"f_3910c-backend.scm",(void*)f_3910},
{"f_3913c-backend.scm",(void*)f_3913},
{"f_3916c-backend.scm",(void*)f_3916},
{"f_4635c-backend.scm",(void*)f_4635},
{"f_3919c-backend.scm",(void*)f_3919},
{"f_3925c-backend.scm",(void*)f_3925},
{"f_3928c-backend.scm",(void*)f_3928},
{"f_3931c-backend.scm",(void*)f_3931},
{"f_3934c-backend.scm",(void*)f_3934},
{"f_3937c-backend.scm",(void*)f_3937},
{"f_3940c-backend.scm",(void*)f_3940},
{"f_3943c-backend.scm",(void*)f_3943},
{"f_3946c-backend.scm",(void*)f_3946},
{"f_3949c-backend.scm",(void*)f_3949},
{"f_3952c-backend.scm",(void*)f_3952},
{"f_3955c-backend.scm",(void*)f_3955},
{"f_3958c-backend.scm",(void*)f_3958},
{"f_4604c-backend.scm",(void*)f_4604},
{"f_3961c-backend.scm",(void*)f_3961},
{"f_4565c-backend.scm",(void*)f_4565},
{"f_4568c-backend.scm",(void*)f_4568},
{"f_4571c-backend.scm",(void*)f_4571},
{"f_4587c-backend.scm",(void*)f_4587},
{"f_4590c-backend.scm",(void*)f_4590},
{"f_3964c-backend.scm",(void*)f_3964},
{"f_3967c-backend.scm",(void*)f_3967},
{"f_3970c-backend.scm",(void*)f_3970},
{"f_4537c-backend.scm",(void*)f_4537},
{"f_4540c-backend.scm",(void*)f_4540},
{"f_3973c-backend.scm",(void*)f_3973},
{"f_3976c-backend.scm",(void*)f_3976},
{"f_3979c-backend.scm",(void*)f_3979},
{"f_3982c-backend.scm",(void*)f_3982},
{"f_3985c-backend.scm",(void*)f_3985},
{"f_3988c-backend.scm",(void*)f_3988},
{"f_4499c-backend.scm",(void*)f_4499},
{"f_4509c-backend.scm",(void*)f_4509},
{"f_3991c-backend.scm",(void*)f_3991},
{"f_4442c-backend.scm",(void*)f_4442},
{"f_4454c-backend.scm",(void*)f_4454},
{"f_4457c-backend.scm",(void*)f_4457},
{"f_4463c-backend.scm",(void*)f_4463},
{"f_4364c-backend.scm",(void*)f_4364},
{"f_4406c-backend.scm",(void*)f_4406},
{"f_4367c-backend.scm",(void*)f_4367},
{"f_4373c-backend.scm",(void*)f_4373},
{"f_4376c-backend.scm",(void*)f_4376},
{"f_4382c-backend.scm",(void*)f_4382},
{"f_4300c-backend.scm",(void*)f_4300},
{"f_4303c-backend.scm",(void*)f_4303},
{"f_4306c-backend.scm",(void*)f_4306},
{"f_4309c-backend.scm",(void*)f_4309},
{"f_4312c-backend.scm",(void*)f_4312},
{"f_4327c-backend.scm",(void*)f_4327},
{"f_4315c-backend.scm",(void*)f_4315},
{"f_4318c-backend.scm",(void*)f_4318},
{"f_4286c-backend.scm",(void*)f_4286},
{"f_4294c-backend.scm",(void*)f_4294},
{"f_4211c-backend.scm",(void*)f_4211},
{"f_4217c-backend.scm",(void*)f_4217},
{"f_4220c-backend.scm",(void*)f_4220},
{"f_4254c-backend.scm",(void*)f_4254},
{"f_4257c-backend.scm",(void*)f_4257},
{"f_4260c-backend.scm",(void*)f_4260},
{"f_4223c-backend.scm",(void*)f_4223},
{"f_4226c-backend.scm",(void*)f_4226},
{"f_4229c-backend.scm",(void*)f_4229},
{"f_4232c-backend.scm",(void*)f_4232},
{"f_4241c-backend.scm",(void*)f_4241},
{"f_4244c-backend.scm",(void*)f_4244},
{"f_3994c-backend.scm",(void*)f_3994},
{"f_4017c-backend.scm",(void*)f_4017},
{"f_4152c-backend.scm",(void*)f_4152},
{"f_4155c-backend.scm",(void*)f_4155},
{"f_4167c-backend.scm",(void*)f_4167},
{"f_4158c-backend.scm",(void*)f_4158},
{"f_4023c-backend.scm",(void*)f_4023},
{"f_4026c-backend.scm",(void*)f_4026},
{"f_4029c-backend.scm",(void*)f_4029},
{"f_4133c-backend.scm",(void*)f_4133},
{"f_4032c-backend.scm",(void*)f_4032},
{"f_4035c-backend.scm",(void*)f_4035},
{"f_4038c-backend.scm",(void*)f_4038},
{"f_4041c-backend.scm",(void*)f_4041},
{"f_4106c-backend.scm",(void*)f_4106},
{"f_4102c-backend.scm",(void*)f_4102},
{"f_4044c-backend.scm",(void*)f_4044},
{"f_4047c-backend.scm",(void*)f_4047},
{"f_4050c-backend.scm",(void*)f_4050},
{"f_4053c-backend.scm",(void*)f_4053},
{"f_4056c-backend.scm",(void*)f_4056},
{"f_4059c-backend.scm",(void*)f_4059},
{"f_4077c-backend.scm",(void*)f_4077},
{"f_4087c-backend.scm",(void*)f_4087},
{"f_4062c-backend.scm",(void*)f_4062},
{"f_3997c-backend.scm",(void*)f_3997},
{"f_4007c-backend.scm",(void*)f_4007},
{"f_4000c-backend.scm",(void*)f_4000},
{"f_3501c-backend.scm",(void*)f_3501},
{"f_3508c-backend.scm",(void*)f_3508},
{"f_3582c-backend.scm",(void*)f_3582},
{"f_3600c-backend.scm",(void*)f_3600},
{"f_3629c-backend.scm",(void*)f_3629},
{"f_3651c-backend.scm",(void*)f_3651},
{"f_3607c-backend.scm",(void*)f_3607},
{"f_3576c-backend.scm",(void*)f_3576},
{"f_3572c-backend.scm",(void*)f_3572},
{"f_3568c-backend.scm",(void*)f_3568},
{"f_3539c-backend.scm",(void*)f_3539},
{"f_3543c-backend.scm",(void*)f_3543},
{"f_3458c-backend.scm",(void*)f_3458},
{"f_3464c-backend.scm",(void*)f_3464},
{"f_3493c-backend.scm",(void*)f_3493},
{"f_3474c-backend.scm",(void*)f_3474},
{"f_3660c-backend.scm",(void*)f_3660},
{"f_3800c-backend.scm",(void*)f_3800},
{"f_3667c-backend.scm",(void*)f_3667},
{"f_3673c-backend.scm",(void*)f_3673},
{"f_3756c-backend.scm",(void*)f_3756},
{"f_3759c-backend.scm",(void*)f_3759},
{"f_3769c-backend.scm",(void*)f_3769},
{"f_3762c-backend.scm",(void*)f_3762},
{"f_3723c-backend.scm",(void*)f_3723},
{"f_3729c-backend.scm",(void*)f_3729},
{"f_3495c-backend.scm",(void*)f_3495},
{"f_3802c-backend.scm",(void*)f_3802},
{"f_3809c-backend.scm",(void*)f_3809},
{"f_3812c-backend.scm",(void*)f_3812},
{"f_3817c-backend.scm",(void*)f_3817},
{"f_3873c-backend.scm",(void*)f_3873},
{"f_3869c-backend.scm",(void*)f_3869},
{"f_3854c-backend.scm",(void*)f_3854},
{"f_3833c-backend.scm",(void*)f_3833},
{"f_3844c-backend.scm",(void*)f_3844},
{"f_3840c-backend.scm",(void*)f_3840},
{"f_3879c-backend.scm",(void*)f_3879},
{"f_3886c-backend.scm",(void*)f_3886},
{"f_3889c-backend.scm",(void*)f_3889},
{"f_3172c-backend.scm",(void*)f_3172},
{"f_3339c-backend.scm",(void*)f_3339},
{"f_3343c-backend.scm",(void*)f_3343},
{"f_3346c-backend.scm",(void*)f_3346},
{"f_3349c-backend.scm",(void*)f_3349},
{"f_3352c-backend.scm",(void*)f_3352},
{"f_3355c-backend.scm",(void*)f_3355},
{"f_3456c-backend.scm",(void*)f_3456},
{"f_3358c-backend.scm",(void*)f_3358},
{"f_3361c-backend.scm",(void*)f_3361},
{"f_3367c-backend.scm",(void*)f_3367},
{"f_3445c-backend.scm",(void*)f_3445},
{"f_3401c-backend.scm",(void*)f_3401},
{"f_3407c-backend.scm",(void*)f_3407},
{"f_3425c-backend.scm",(void*)f_3425},
{"f_3421c-backend.scm",(void*)f_3421},
{"f_3417c-backend.scm",(void*)f_3417},
{"f_3373c-backend.scm",(void*)f_3373},
{"f_3376c-backend.scm",(void*)f_3376},
{"f_3379c-backend.scm",(void*)f_3379},
{"f_3382c-backend.scm",(void*)f_3382},
{"f_3385c-backend.scm",(void*)f_3385},
{"f_3395c-backend.scm",(void*)f_3395},
{"f_3388c-backend.scm",(void*)f_3388},
{"f_3291c-backend.scm",(void*)f_3291},
{"f_3310c-backend.scm",(void*)f_3310},
{"f_3314c-backend.scm",(void*)f_3314},
{"f_3317c-backend.scm",(void*)f_3317},
{"f_3320c-backend.scm",(void*)f_3320},
{"f_3323c-backend.scm",(void*)f_3323},
{"f_3337c-backend.scm",(void*)f_3337},
{"f_3333c-backend.scm",(void*)f_3333},
{"f_3326c-backend.scm",(void*)f_3326},
{"f_3294c-backend.scm",(void*)f_3294},
{"f_3308c-backend.scm",(void*)f_3308},
{"f_3297c-backend.scm",(void*)f_3297},
{"f_3304c-backend.scm",(void*)f_3304},
{"f_3211c-backend.scm",(void*)f_3211},
{"f_3213c-backend.scm",(void*)f_3213},
{"f_3217c-backend.scm",(void*)f_3217},
{"f_3220c-backend.scm",(void*)f_3220},
{"f_3223c-backend.scm",(void*)f_3223},
{"f_3226c-backend.scm",(void*)f_3226},
{"f_3229c-backend.scm",(void*)f_3229},
{"f_3232c-backend.scm",(void*)f_3232},
{"f_3235c-backend.scm",(void*)f_3235},
{"f_3238c-backend.scm",(void*)f_3238},
{"f_3241c-backend.scm",(void*)f_3241},
{"f_3244c-backend.scm",(void*)f_3244},
{"f_3247c-backend.scm",(void*)f_3247},
{"f_3250c-backend.scm",(void*)f_3250},
{"f_3264c-backend.scm",(void*)f_3264},
{"f_3260c-backend.scm",(void*)f_3260},
{"f_3253c-backend.scm",(void*)f_3253},
{"f_3175c-backend.scm",(void*)f_3175},
{"f_3188c-backend.scm",(void*)f_3188},
{"f_3198c-backend.scm",(void*)f_3198},
{"f_3179c-backend.scm",(void*)f_3179},
{"f_2921c-backend.scm",(void*)f_2921},
{"f_2925c-backend.scm",(void*)f_2925},
{"f_2949c-backend.scm",(void*)f_2949},
{"f_2953c-backend.scm",(void*)f_2953},
{"f_2956c-backend.scm",(void*)f_2956},
{"f_3170c-backend.scm",(void*)f_3170},
{"f_2959c-backend.scm",(void*)f_2959},
{"f_3156c-backend.scm",(void*)f_3156},
{"f_2962c-backend.scm",(void*)f_2962},
{"f_2965c-backend.scm",(void*)f_2965},
{"f_2968c-backend.scm",(void*)f_2968},
{"f_2971c-backend.scm",(void*)f_2971},
{"f_2974c-backend.scm",(void*)f_2974},
{"f_2977c-backend.scm",(void*)f_2977},
{"f_3148c-backend.scm",(void*)f_3148},
{"f_2980c-backend.scm",(void*)f_2980},
{"f_2983c-backend.scm",(void*)f_2983},
{"f_3141c-backend.scm",(void*)f_3141},
{"f_3122c-backend.scm",(void*)f_3122},
{"f_3133c-backend.scm",(void*)f_3133},
{"f_2986c-backend.scm",(void*)f_2986},
{"f_3073c-backend.scm",(void*)f_3073},
{"f_3076c-backend.scm",(void*)f_3076},
{"f_3079c-backend.scm",(void*)f_3079},
{"f_3082c-backend.scm",(void*)f_3082},
{"f_3098c-backend.scm",(void*)f_3098},
{"f_3101c-backend.scm",(void*)f_3101},
{"f_3104c-backend.scm",(void*)f_3104},
{"f_3107c-backend.scm",(void*)f_3107},
{"f_2989c-backend.scm",(void*)f_2989},
{"f_2992c-backend.scm",(void*)f_2992},
{"f_2995c-backend.scm",(void*)f_2995},
{"f_3045c-backend.scm",(void*)f_3045},
{"f_3048c-backend.scm",(void*)f_3048},
{"f_2998c-backend.scm",(void*)f_2998},
{"f_3001c-backend.scm",(void*)f_3001},
{"f_3033c-backend.scm",(void*)f_3033},
{"f_3036c-backend.scm",(void*)f_3036},
{"f_3007c-backend.scm",(void*)f_3007},
{"f_3016c-backend.scm",(void*)f_3016},
{"f_3019c-backend.scm",(void*)f_3019},
{"f_2928c-backend.scm",(void*)f_2928},
{"f_2933c-backend.scm",(void*)f_2933},
{"f_2937c-backend.scm",(void*)f_2937},
{"f_2947c-backend.scm",(void*)f_2947},
{"f_2940c-backend.scm",(void*)f_2940},
{"f_2780c-backend.scm",(void*)f_2780},
{"f_2787c-backend.scm",(void*)f_2787},
{"f_2915c-backend.scm",(void*)f_2915},
{"f_2790c-backend.scm",(void*)f_2790},
{"f_2793c-backend.scm",(void*)f_2793},
{"f_2796c-backend.scm",(void*)f_2796},
{"f_2801c-backend.scm",(void*)f_2801},
{"f_2811c-backend.scm",(void*)f_2811},
{"f_2817c-backend.scm",(void*)f_2817},
{"f_2862c-backend.scm",(void*)f_2862},
{"f_2872c-backend.scm",(void*)f_2872},
{"f_2820c-backend.scm",(void*)f_2820},
{"f_2843c-backend.scm",(void*)f_2843},
{"f_2853c-backend.scm",(void*)f_2853},
{"f_2823c-backend.scm",(void*)f_2823},
{"f_2826c-backend.scm",(void*)f_2826},
{"f_2614c-backend.scm",(void*)f_2614},
{"f_2772c-backend.scm",(void*)f_2772},
{"f_2634c-backend.scm",(void*)f_2634},
{"f_2640c-backend.scm",(void*)f_2640},
{"f_2717c-backend.scm",(void*)f_2717},
{"f_2721c-backend.scm",(void*)f_2721},
{"f_2725c-backend.scm",(void*)f_2725},
{"f_2729c-backend.scm",(void*)f_2729},
{"f_2751c-backend.scm",(void*)f_2751},
{"f_2747c-backend.scm",(void*)f_2747},
{"f_2739c-backend.scm",(void*)f_2739},
{"f_2737c-backend.scm",(void*)f_2737},
{"f_2733c-backend.scm",(void*)f_2733},
{"f_2658c-backend.scm",(void*)f_2658},
{"f_2661c-backend.scm",(void*)f_2661},
{"f_2664c-backend.scm",(void*)f_2664},
{"f_2706c-backend.scm",(void*)f_2706},
{"f_2667c-backend.scm",(void*)f_2667},
{"f_2670c-backend.scm",(void*)f_2670},
{"f_2673c-backend.scm",(void*)f_2673},
{"f_2688c-backend.scm",(void*)f_2688},
{"f_2693c-backend.scm",(void*)f_2693},
{"f_2676c-backend.scm",(void*)f_2676},
{"f_2617c-backend.scm",(void*)f_2617},
{"f_2631c-backend.scm",(void*)f_2631},
{"f_1187c-backend.scm",(void*)f_1187},
{"f_2582c-backend.scm",(void*)f_2582},
{"f_2588c-backend.scm",(void*)f_2588},
{"f_2592c-backend.scm",(void*)f_2592},
{"f_1190c-backend.scm",(void*)f_1190},
{"f_2547c-backend.scm",(void*)f_2547},
{"f_2550c-backend.scm",(void*)f_2550},
{"f_2553c-backend.scm",(void*)f_2553},
{"f_2556c-backend.scm",(void*)f_2556},
{"f_2559c-backend.scm",(void*)f_2559},
{"f_2562c-backend.scm",(void*)f_2562},
{"f_2464c-backend.scm",(void*)f_2464},
{"f_2467c-backend.scm",(void*)f_2467},
{"f_2470c-backend.scm",(void*)f_2470},
{"f_2483c-backend.scm",(void*)f_2483},
{"f_2506c-backend.scm",(void*)f_2506},
{"f_2509c-backend.scm",(void*)f_2509},
{"f_2512c-backend.scm",(void*)f_2512},
{"f_2515c-backend.scm",(void*)f_2515},
{"f_2493c-backend.scm",(void*)f_2493},
{"f_2496c-backend.scm",(void*)f_2496},
{"f_2455c-backend.scm",(void*)f_2455},
{"f_2427c-backend.scm",(void*)f_2427},
{"f_2430c-backend.scm",(void*)f_2430},
{"f_2447c-backend.scm",(void*)f_2447},
{"f_2433c-backend.scm",(void*)f_2433},
{"f_2436c-backend.scm",(void*)f_2436},
{"f_2411c-backend.scm",(void*)f_2411},
{"f_2415c-backend.scm",(void*)f_2415},
{"f_2397c-backend.scm",(void*)f_2397},
{"f_2400c-backend.scm",(void*)f_2400},
{"f_2381c-backend.scm",(void*)f_2381},
{"f_2385c-backend.scm",(void*)f_2385},
{"f_2363c-backend.scm",(void*)f_2363},
{"f_2366c-backend.scm",(void*)f_2366},
{"f_2343c-backend.scm",(void*)f_2343},
{"f_2307c-backend.scm",(void*)f_2307},
{"f_2319c-backend.scm",(void*)f_2319},
{"f_2310c-backend.scm",(void*)f_2310},
{"f_2288c-backend.scm",(void*)f_2288},
{"f_2291c-backend.scm",(void*)f_2291},
{"f_2269c-backend.scm",(void*)f_2269},
{"f_2272c-backend.scm",(void*)f_2272},
{"f_2250c-backend.scm",(void*)f_2250},
{"f_2253c-backend.scm",(void*)f_2253},
{"f_2231c-backend.scm",(void*)f_2231},
{"f_2227c-backend.scm",(void*)f_2227},
{"f_2175c-backend.scm",(void*)f_2175},
{"f_2208c-backend.scm",(void*)f_2208},
{"f_2178c-backend.scm",(void*)f_2178},
{"f_2196c-backend.scm",(void*)f_2196},
{"f_2181c-backend.scm",(void*)f_2181},
{"f_2184c-backend.scm",(void*)f_2184},
{"f_2142c-backend.scm",(void*)f_2142},
{"f_2126c-backend.scm",(void*)f_2126},
{"f_2129c-backend.scm",(void*)f_2129},
{"f_2132c-backend.scm",(void*)f_2132},
{"f_2085c-backend.scm",(void*)f_2085},
{"f_2088c-backend.scm",(void*)f_2088},
{"f_2109c-backend.scm",(void*)f_2109},
{"f_2113c-backend.scm",(void*)f_2113},
{"f_2116c-backend.scm",(void*)f_2116},
{"f_2091c-backend.scm",(void*)f_2091},
{"f_2107c-backend.scm",(void*)f_2107},
{"f_2099c-backend.scm",(void*)f_2099},
{"f_2094c-backend.scm",(void*)f_2094},
{"f_1831c-backend.scm",(void*)f_1831},
{"f_1834c-backend.scm",(void*)f_1834},
{"f_2035c-backend.scm",(void*)f_2035},
{"f_2031c-backend.scm",(void*)f_2031},
{"f_1840c-backend.scm",(void*)f_1840},
{"f_1185c-backend.scm",(void*)f_1185},
{"f_2024c-backend.scm",(void*)f_2024},
{"f_1175c-backend.scm",(void*)f_1175},
{"f_2017c-backend.scm",(void*)f_2017},
{"f_1846c-backend.scm",(void*)f_1846},
{"f_1970c-backend.scm",(void*)f_1970},
{"f_1973c-backend.scm",(void*)f_1973},
{"f_1976c-backend.scm",(void*)f_1976},
{"f_1991c-backend.scm",(void*)f_1991},
{"f_1979c-backend.scm",(void*)f_1979},
{"f_1982c-backend.scm",(void*)f_1982},
{"f_1985c-backend.scm",(void*)f_1985},
{"f_1967c-backend.scm",(void*)f_1967},
{"f_1877c-backend.scm",(void*)f_1877},
{"f_1951c-backend.scm",(void*)f_1951},
{"f_1954c-backend.scm",(void*)f_1954},
{"f_1927c-backend.scm",(void*)f_1927},
{"f_1930c-backend.scm",(void*)f_1930},
{"f_1933c-backend.scm",(void*)f_1933},
{"f_1936c-backend.scm",(void*)f_1936},
{"f_1939c-backend.scm",(void*)f_1939},
{"f_1880c-backend.scm",(void*)f_1880},
{"f_1883c-backend.scm",(void*)f_1883},
{"f_1910c-backend.scm",(void*)f_1910},
{"f_1914c-backend.scm",(void*)f_1914},
{"f_1917c-backend.scm",(void*)f_1917},
{"f_1886c-backend.scm",(void*)f_1886},
{"f_1908c-backend.scm",(void*)f_1908},
{"f_1900c-backend.scm",(void*)f_1900},
{"f_1889c-backend.scm",(void*)f_1889},
{"f_1892c-backend.scm",(void*)f_1892},
{"f_1858c-backend.scm",(void*)f_1858},
{"f_1861c-backend.scm",(void*)f_1861},
{"f_1788c-backend.scm",(void*)f_1788},
{"f_1791c-backend.scm",(void*)f_1791},
{"f_1775c-backend.scm",(void*)f_1775},
{"f_1778c-backend.scm",(void*)f_1778},
{"f_1741c-backend.scm",(void*)f_1741},
{"f_1744c-backend.scm",(void*)f_1744},
{"f_1713c-backend.scm",(void*)f_1713},
{"f_1709c-backend.scm",(void*)f_1709},
{"f_1667c-backend.scm",(void*)f_1667},
{"f_1635c-backend.scm",(void*)f_1635},
{"f_1638c-backend.scm",(void*)f_1638},
{"f_1600c-backend.scm",(void*)f_1600},
{"f_1626c-backend.scm",(void*)f_1626},
{"f_1612c-backend.scm",(void*)f_1612},
{"f_1616c-backend.scm",(void*)f_1616},
{"f_1619c-backend.scm",(void*)f_1619},
{"f_1603c-backend.scm",(void*)f_1603},
{"f_1568c-backend.scm",(void*)f_1568},
{"f_1571c-backend.scm",(void*)f_1571},
{"f_1574c-backend.scm",(void*)f_1574},
{"f_1577c-backend.scm",(void*)f_1577},
{"f_1539c-backend.scm",(void*)f_1539},
{"f_1542c-backend.scm",(void*)f_1542},
{"f_1545c-backend.scm",(void*)f_1545},
{"f_1548c-backend.scm",(void*)f_1548},
{"f_1502c-backend.scm",(void*)f_1502},
{"f_1505c-backend.scm",(void*)f_1505},
{"f_1508c-backend.scm",(void*)f_1508},
{"f_1511c-backend.scm",(void*)f_1511},
{"f_1469c-backend.scm",(void*)f_1469},
{"f_1472c-backend.scm",(void*)f_1472},
{"f_1475c-backend.scm",(void*)f_1475},
{"f_1478c-backend.scm",(void*)f_1478},
{"f_1450c-backend.scm",(void*)f_1450},
{"f_1453c-backend.scm",(void*)f_1453},
{"f_1423c-backend.scm",(void*)f_1423},
{"f_1426c-backend.scm",(void*)f_1426},
{"f_1372c-backend.scm",(void*)f_1372},
{"f_1382c-backend.scm",(void*)f_1382},
{"f_1385c-backend.scm",(void*)f_1385},
{"f_1388c-backend.scm",(void*)f_1388},
{"f_1314c-backend.scm",(void*)f_1314},
{"f_1317c-backend.scm",(void*)f_1317},
{"f_1320c-backend.scm",(void*)f_1320},
{"f_1323c-backend.scm",(void*)f_1323},
{"f_1326c-backend.scm",(void*)f_1326},
{"f_1329c-backend.scm",(void*)f_1329},
{"f_1145c-backend.scm",(void*)f_1145},
{"f_1157c-backend.scm",(void*)f_1157},
{"f_1165c-backend.scm",(void*)f_1165},
{"f_1149c-backend.scm",(void*)f_1149},
{"f_1122c-backend.scm",(void*)f_1122},
{"f_1136c-backend.scm",(void*)f_1136},
{"f_1128c-backend.scm",(void*)f_1128},
{"f_1101c-backend.scm",(void*)f_1101},
{"f_1107c-backend.scm",(void*)f_1107},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
